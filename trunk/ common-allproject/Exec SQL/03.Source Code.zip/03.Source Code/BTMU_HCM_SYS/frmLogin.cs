﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer;
using DataEncryption;
using Config.Classes;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Com;
using System.Configuration;
using Phoenix.Lg.Bus;
namespace BTMU_HCM_SYS
{
    public partial class frmLogin : Form
    {
        public static int _userID = -1;
      
        string _conStr = null;

        public frmLogin()
        {
           
            InitializeComponent();
            _conStr = Encryption.decrypt(ConfigurationManager.AppSettings["MDConnectionString"].ToString());
           
        }

        #region variables
        DataSet _ds = null;        
        string _query = "";
        public static string _fullname = "";
        public static string _username = "";
        public static string _Department = "";
        string _pwd = "";
        #endregion           

        private void frmLogin_Load(object sender, EventArgs e)
        {                     
            txtUserName.Focus();
        }

        #region show form Main
        frmMain fMain = null;
        void showFormMain()
        {
            this.Hide();
            fMain = new frmMain();
            fMain.Show();
        }
        #endregion

        #region check data
        int checkData()
        {
            if (txtUserName.Text.Trim().Length == 0)
            {
                errorProvider1.SetError(txtUserName, "UserName can't be blank!");
                txtUserName.Focus();
                return 1;
            }

            if (txtPwd.Text.Trim().Length == 0)
            {
                errorProvider1.SetError(txtPwd, "Password can't be blank!");
                txtPwd.Focus();
                return 1;
            }

            return 0;
        }
        #endregion

        //login
        static int _count = 0;
        void login()
        {
            errorProvider1.Dispose();
            if (checkData() == 1)
            {
                return;
            }
            ////get data
            //_username = txtUserName.Text.Trim();
            //_pwd = txtPwd.Text.Trim();           

            //#region use default username
            //try
            //{
            //    //default username and password  
            //    UserSourceClass.getDataFromXML();
            //    if (_username.Equals(UserSourceClass._username) && _pwd.Equals(UserSourceClass._pwd))
            //    {
            //        showFormMain();
            //        return;
            //    }    
            //}
            //catch (System.Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
                   
            //#endregion
            
            //#region check username and password
            //_pwd = Encryption.encrypt(_pwd);

            //load users database settings
            DataAccessClass.loadDataBaseSettings();
            KYCDataAccessClass.loadDataBaseSettings();
            
            //_query = "select UserNo,UserName, Password, Lockout,Department from Users where UserName = '" + _username + 
            //        "' and Password = '" + _pwd + "'";
            //_ds = DataAccessClass.datasetQuery(_query);
            //int _iLogin = 0;
            //try
            //{
            //    _iLogin = _ds.Tables[0].Rows.Count;
            //}
            //catch
            //{
            //    return;
            //}
            //if (_iLogin == 1)
            //{                
            //    //check lockout
            //    string _lock = "";
            //    clsUserInfo.UserNo = int.Parse(_ds.Tables[0].Rows[0]["UserNo"].ToString().Trim());
            //   // clsUserInfo.UserNo = 104;
            //    _lock = _ds.Tables[0].Rows[0]["Lockout"].ToString().Trim();
            //    _Department = _ds.Tables[0].Rows[0]["Department"].ToString().Trim();

            //    clsUserInfo.UserName = _ds.Tables[0].Rows[0]["UserName"].ToString().Trim();
            //    clsUserInfo.DepartmentId = reader.GetInt16(4);
            //    if (bool.Parse(_lock))
            //    {
            //        MessageBox.Show("This user was locked!");
            //        return;
            //    }
            //    _count = 0;
            //    showFormMain();
            //}
            //else
            //{
            //    MessageBox.Show("UserName or Password is wrong! Try again!");
            //    _count++;
            //    if (_count == 3)
            //    {
            //        //no this user
            //        _query = "select UserName from Users where UserName = '" + _username + "'";
            //        _ds = DataAccessClass.datasetQuery(_query);
            //        if (_ds.Tables[0].Rows.Count == 0)
            //        {
            //            return;
            //        }
            //        //lock this user
            //        _query = "update Users set Lockout = true where UserName = '" + _username + "'";
            //        DataAccessClass.sqlOperation(_query);
            //        MessageBox.Show("You entered password wrong 3 times! This user is locked!");
            //    }
            //}
            //#endregion
            
            _username = txtUserName.Text.Trim();
            _pwd = clsMDFunction.GetMD5HashData(txtPwd.Text.Trim());
            using (SqlConnection conn = new SqlConnection(_conStr))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "dbo.spAllLogin";
                        cmd.CommandType = CommandType.StoredProcedure;
                        SqlParameter[] values = new SqlParameter[] { 
                        new SqlParameter("@UserName", _username),
                        new SqlParameter("@Password", _pwd)
                    };
                        cmd.Parameters.AddRange(values);
                        //SqlDataReader reader = null;
                        SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                        while (reader.Read())
                        {
                            _userID = reader.GetInt16(0);
                            _fullname = reader.GetString(3);
                            clsUserInfo.UserNo = _userID;
                            clsUserInfo.UserName = reader.GetString(1);
                            clsUserInfo.FullName = _fullname;
                            clsUserInfo.DepartmentId = reader.GetInt16(4);
                            //clsUserInfo.DepartmentName = reader.GetString(5);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                }
            }
            if (_userID == -1 || _fullname.Equals(String.Empty))
            {
                clsFunction.ShowWarningDialog("UserName or Password is wrong! Try again!");
                txtUserName.Focus();
                return;
            }
            showFormMain();
        }

        #region operations
        private void btLogin_Click(object sender, EventArgs e)
        {
            login();
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtPwd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.ControlKey)
            {
                login();
            }
        }

        private void txtUserName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.ControlKey)
            {
                login();
            }
        }
        #endregion
    }
}
