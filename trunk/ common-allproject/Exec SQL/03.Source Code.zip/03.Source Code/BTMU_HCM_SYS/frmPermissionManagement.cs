﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer;

namespace BTMU_HCM_SYS
{
    public partial class frmPermissionManagement : Form
    {
        public frmPermissionManagement()
        {
            InitializeComponent();
            dtgPermissionList.RowsDefaultCellStyle.BackColor = Color.White;
            dtgPermissionList.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(252, 254, 165);
        }

        #region variables
        DataSet _ds = null;
        string _query = "";
        int _rs = 0;
        DataRow _row = null;
        DataRow[] _dr = null;
        //
        string _un = "";
        string _menu = "";
        string _modify = "";
        string _delete = "";
        string _completeddate = "";
        string _approveirregular = "";
        string _inchargeIOD = "";
        #endregion

        private void frmPermissionManagement_Load(object sender, EventArgs e)
        {
            fill_dtgUserList();
            fill_cbUserName();
            fill_cbDept();
        }

        #region fill cbDept
        void fill_cbDept()
        {
            _query = "select DeptName from Department";
            _ds = DataAccessClass.datasetQuery(_query);
            try
            {
                _dr = _ds.Tables[0].Select();
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbDept.Items.Add(_dr[i]["DeptName"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion

        #region fiil_cbUserName
        void fill_cbUserName()
        {
            _query = "select UserName from Users";
            _ds = DataAccessClass.datasetQuery(_query);
            try
            {
                _dr = _ds.Tables[0].Select();
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbUserName.Items.Add(_dr[i]["UserName"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion

        #region fill dtgUserList
        void fill_dtgUserList()
        {
            try
            {
                _query = "select UserName, Menu, Modify, [Delete],CompletedDate,ApproveIrregular,InchargeIOD from Permissions";
                _ds = DataAccessClass.datasetQuery(_query);
                dtgPermissionList.DataSource = _ds.Tables[0];
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        private void dtgPermissionList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _un = dtgPermissionList[0, dtgPermissionList.CurrentCell.RowIndex].Value.ToString().Trim();
            _menu = dtgPermissionList[1, dtgPermissionList.CurrentCell.RowIndex].Value.ToString().Trim();
            _modify = dtgPermissionList[2, dtgPermissionList.CurrentCell.RowIndex].Value.ToString().Trim();
            _delete = dtgPermissionList[3, dtgPermissionList.CurrentCell.RowIndex].Value.ToString().Trim();
            _completeddate = dtgPermissionList[4, dtgPermissionList.CurrentCell.RowIndex].Value.ToString().Trim();
            _approveirregular = dtgPermissionList[5, dtgPermissionList.CurrentCell.RowIndex].Value.ToString().Trim();
            _inchargeIOD = dtgPermissionList[6, dtgPermissionList.CurrentCell.RowIndex].Value.ToString().Trim();

            cbUserName.Text = _un;
            cbUserName.Enabled = false;
            cbDept.Text = _menu;
            cbDept.Enabled = false;            
            chkModify.Checked = bool.Parse(_modify);
            chkDelete.Checked = bool.Parse(_delete);
            chbUpdateCompleteDate.Checked = bool.Parse(_completeddate);
            chbApproval.Checked = bool.Parse(_approveirregular);
            chbInchargeIOD.Checked = bool.Parse(_inchargeIOD);
        }

        void getData()
        {
            _un = cbUserName.Text.Trim();
            _menu = cbDept.Text.Trim();
            _modify = (chkModify.Checked) ? "true" : "false";
            _delete = (chkDelete.Checked) ? "true" : "false";
            _completeddate = (chbUpdateCompleteDate.Checked) ? "true" : "false";
            _approveirregular = (chbApproval.Checked) ? "true" : "false";
            _inchargeIOD = (chbInchargeIOD.Checked) ? "true" : "false";
        }

        #region operations
        private void btNew_Click(object sender, EventArgs e)
        {
            cbUserName.Text = "";
            cbUserName.Enabled = true;            
            cbDept.Text = "";
            cbDept.Enabled = true;            
            chkModify.Checked = false;
            chkDelete.Checked = false;
            chbUpdateCompleteDate.Checked = false;
        }

        private void btInsert_Click(object sender, EventArgs e)
        {            
            getData();                      
            _query = "insert into Permissions(UserName, Menu, Modify, [Delete], CompletedDate, ApproveIrregular,InchargeIOD) values('" +
                _un + "', '" + _menu + "', '" + _modify + "', '" + _delete + "', '" + _completeddate + "', '" + _approveirregular + "', '" + _inchargeIOD + "')";            
            
            _rs = DataAccessClass.sqlOperation(_query);
            if (_rs == 1)
            {
                lblMsg.Text = "Insert successfully!";
                //refresh dtgUserList
                fill_dtgUserList();
            }
            else
            {
                lblMsg.Text = "Insert failed!";
            }
        }

        private void btUpdate_Click(object sender, EventArgs e)
        {            
            getData();

            _query = "update Permissions set Modify = '" + _modify + "', [Delete] = '" + _delete + "', CompletedDate = '" + _completeddate +
                "', ApproveIrregular = '" + _approveirregular + "', InchargeIOD = '" + _inchargeIOD + "' where UserName = '" + _un + "' and Menu = '" + _menu + "'";
           
            _rs = DataAccessClass.sqlOperation(_query);
            if (_rs == 1)
            {
                lblMsg.Text = "Update successfully!";
                //refresh dtgUserList
                fill_dtgUserList();
            }
            else
            {
                lblMsg.Text = "Update failed!";
            }
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Are you sure?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                return;
            }
            getData();
            _query = "delete from Permissions where [UserName] = '" + _un + "' and Menu = '" + _menu + "'";
            _rs = DataAccessClass.sqlOperation(_query);
            if (_rs == 1)
            {
                lblMsg.Text = "Delete successfully!";
                //refresh dtgUserList
                fill_dtgUserList();
            }
            else
            {
                lblMsg.Text = "Delete failed!";
            }
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
