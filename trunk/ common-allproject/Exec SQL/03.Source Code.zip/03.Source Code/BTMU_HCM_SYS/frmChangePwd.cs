﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer;
using DataEncryption;
using Phoenix.Common.MasterData.Com;

namespace BTMU_HCM_SYS
{
    public partial class frmChangePwd : Form
    {
        public frmChangePwd()
        {
            InitializeComponent();
        }

        string _query = "";
        DataSet _ds = null;
        int _rs = 0;

        string _un = "";
        string _oldpwd = "";
        string _pwd = "";        

        private void frmChangePwd_Load(object sender, EventArgs e)
        {
            txtUserName.Text = frmLogin._username;
            txtOldPwd.Focus();
        }

        #region check data and get data
        int checkData()
        {
            if (txtOldPwd.Text.Trim().Length == 0)
            {
                errorProvider1.SetError(txtOldPwd, "Old Password can't be blank!");
                txtOldPwd.Focus();
                return 1;
            }
            //check old password
            _query = "select [Password] from MD_tblUser where [UserName] = '" + txtUserName.Text.Trim() + "'";
            _ds = DataAccessClass.datasetQuery(_query);
            _oldpwd = _ds.Tables[0].Rows[0]["Password"].ToString().Trim();
           // _oldpwd = Encryption.decrypt(_oldpwd);
            if (!_oldpwd.Equals(clsMDFunction.GetMD5HashData(txtOldPwd.Text.Trim())))
            {
                MessageBox.Show("Old password is wrong!");
                return 1;
            }
            if (txtPwd.Text.Trim().Length == 0)
            {
                errorProvider1.SetError(txtPwd, "New Password can't be blank!");
                txtPwd.Focus();
                return 1;
            }
            if (txtRePwd.Text.Trim().Length == 0)
            {
                errorProvider1.SetError(txtRePwd, "Re-New password can't be blank!");
                txtRePwd.Focus();
                return 1;
            }
            if (!txtPwd.Text.Equals(txtRePwd.Text))
            {
                errorProvider1.SetError(txtRePwd, "Password and Re-password must be same!");
                txtRePwd.Focus();
                return 1;
            }
           
            return 0;
        }

        void getData()
        {
            _un = txtUserName.Text.Trim();            
            _pwd = txtPwd.Text.Trim();
            _pwd = clsMDFunction.GetMD5HashData(_pwd);            
        }
        #endregion

        private void btUpdate_Click(object sender, EventArgs e)
        {
            errorProvider1.Dispose();
            if (checkData() == 1)
            {
                return;
            }
            getData();
            _query = "update MD_tblUser set [Password] = '" + _pwd + "'where [UserName] = '" + _un + "'";
            _rs = DataAccessClass.sqlOperation(_query);
            if (_rs > 0)
            {
                MessageBox.Show("Change password successfully!");                
            }
            else
            {
                MessageBox.Show("Change password failed!");
            } 
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
