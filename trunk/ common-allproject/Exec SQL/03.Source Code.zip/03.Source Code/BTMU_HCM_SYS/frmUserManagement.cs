﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer;

namespace BTMU_HCM_SYS
{
    public partial class frmUserManagement : Form
    {
        public frmUserManagement()
        {
            InitializeComponent();
        }

        #region variables
        DataSet _ds = null;        
        string _query = "";                
        int _rs = 0;
        DataRow _row = null;
        DataRow[] _dr = null;
        //
        string _un = "";
        string _pwd = "";        
        string _name = "";
        string _dept = "";
        string _lock = "";
        #endregion

        private void frmUserManagement_Load(object sender, EventArgs e)
        {
            fill_dtgUserList();
            fill_cbDept();
        }

        #region fill cbDept
        void fill_cbDept()
        {
            _query = "select DeptName from Department";
            _ds = DataAccessClass.datasetQuery(_query);           
            try
            {                
                _dr = _ds.Tables[0].Select();
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbDept.Items.Add(_dr[i]["DeptName"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion

        #region fill dtgUserList
        void fill_dtgUserList()
        {
            try
            {
                _query = "select UserName, FullName, Department, Lockout from Users";
                _ds = DataAccessClass.datasetQuery(_query);                
                dtgUserList.DataSource = _ds.Tables[0];
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region check data and get data
        int checkData()
        {
            if (txtUserName.Text.Trim().Length == 0)
            {
                errorProvider1.SetError(txtUserName, "UserName can't be blank!");
                txtUserName.Focus();
                return 1;
            }
            if (txtPwd.Text.Trim().Length == 0)
            {
                errorProvider1.SetError(txtPwd, "Password can't be blank!");
                txtPwd.Focus();
                return 1;
            }
            if (txtRePwd.Text.Trim().Length == 0)
            {
                errorProvider1.SetError(txtRePwd, "Re-password can't be blank!");
                txtRePwd.Focus();
                return 1;
            }
            if (!txtPwd.Text.Equals(txtRePwd.Text))
            {
                errorProvider1.SetError(txtRePwd, "Password and Re-password must be same!");
                txtRePwd.Focus();
                return 1;
            }
            if (cbDept.Text.Trim().Length == 0)
            {
                errorProvider1.SetError(cbDept, "Department can't be blank!");
                cbDept.Focus();
                return 1;
            }
            return 0;
        }

        void getData()
        {
            _un = txtUserName.Text.Trim();
            _pwd = txtPwd.Text.Trim();
            _pwd = DataEncryption.Encryption.encrypt(_pwd);           
            _dept = cbDept.Text.Trim();
            _name = txtName.Text.Trim();
            _lock = (chkLock.Checked) ? "true" : "false";
        }
        #endregion

        #region operations
        private void btNew_Click(object sender, EventArgs e)
        {
            txtUserName.Clear();
            txtUserName.ReadOnly = false;
            txtPwd.Clear();
            txtRePwd.Clear();
            cbDept.Text = "";
            txtName.Clear();
            chkLock.Checked = false;
        }

        private void btInsert_Click(object sender, EventArgs e)
        {
            errorProvider1.Dispose();
            if (checkData() == 1)
            {
                return;
            }
            getData();
            
            _query = "insert into Users(UserName, Password, FullName, Department, Lockout) values('" +
                _un + "', '" + _pwd + "', '" + _name + "', '" + _dept + "', '" + _lock + "')";
            
            _rs = DataAccessClass.sqlOperation(_query);
            if (_rs == 1)
            {               
                lblMsg.Text = "Insert successfully!";   
                //refresh dtgUserList
                fill_dtgUserList();
            }
            else
            {
                lblMsg.Text = "Insert failed!";
            }
        }

        private void btUpdate_Click(object sender, EventArgs e)
        {
            errorProvider1.Dispose();
            if (checkData() == 1)
            {
                return;
            }
            getData();
            
            _query = "update Users set Password = '" + _pwd + "', [FullName] = '" + _name + 
                "', Department = '" + _dept + "', Lockout = '" + _lock +
                "' where UserName = '" + _un + "'";
            
            _rs = DataAccessClass.sqlOperation(_query);
            if (_rs == 1)
            {
                lblMsg.Text = "Update successfully!";
                //refresh dtgUserList
                fill_dtgUserList();
            }
            else
            {
                lblMsg.Text = "Update failed!";
            }
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Are you sure?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                return;
            }
            string _sUserName = txtUserName.Text.Trim();
            if ("admin".Equals(_sUserName))
            {
                MessageBox.Show("You cannot delete User ID admin");
                return;
            }
            _query = "delete from Users where [UserName] = '" + _sUserName + "'";
            _rs = DataAccessClass.sqlOperation(_query);
            if (_rs == 1)
            {
                lblMsg.Text = "Delete successfully!";
                //refresh dtgUserList
                fill_dtgUserList();
            }
            else
            {
                lblMsg.Text = "Delete failed!";
            }
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        private void dtgUserList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _un = dtgUserList[0, dtgUserList.CurrentCell.RowIndex].Value.ToString().Trim();
            _name = dtgUserList[1, dtgUserList.CurrentCell.RowIndex].Value.ToString().Trim();
            _dept = dtgUserList[2, dtgUserList.CurrentCell.RowIndex].Value.ToString().Trim();
            _lock = dtgUserList[3, dtgUserList.CurrentCell.RowIndex].Value.ToString().Trim();

            _query = "select Password from Users where UserName = '" + _un + "'";
            _ds = DataAccessClass.datasetQuery(_query);
            if (_ds.Tables[0].Rows.Count == 0)
            {
                return;
            }
            _row = _ds.Tables[0].Rows[0];
            _pwd = _row["Password"].ToString().Trim();
            _pwd = DataEncryption.Encryption.decrypt(_pwd);
            txtUserName.Text = _un;
            txtUserName.ReadOnly = true;
            txtPwd.Text = _pwd;
            txtRePwd.Text = _pwd;
            cbDept.Text = _dept;
            txtName.Text = _name;
            chkLock.Checked = bool.Parse(_lock);
        }       
    }
}
