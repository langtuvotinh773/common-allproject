﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DataEncryption;

namespace BTMU_HCM_SYS
{
    public partial class frmDBManagement : Form
    {
        public frmDBManagement()
        {
            InitializeComponent();
        }

        void getCurrValue()
        {
            if (cbDB.Text.Equals("BTMU_HCM DataBase"))
            {                
                DataAccessLayer.DataAccessClass.getDataFromXML();                
                txtCurrSetting.Text = DataAccessLayer.DataAccessClass._path;
            }            
        }

        private void btGet_Click(object sender, EventArgs e)
        {
            getCurrValue();
        }

        private void btUpdate_Click(object sender, EventArgs e)
        {
            if (cbDB.Text.Equals("BTMU_HCM DataBase"))
            {                
                DataAccessLayer.DataAccessClass._path = txtNewSetting.Text.Trim();
                DataAccessLayer.DataAccessClass.writeDataBaseXML();
            }            
            MessageBox.Show("Update successfully!");
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbDB_SelectedIndexChanged(object sender, EventArgs e)
        {
            getCurrValue();            
        }        
    }
}
