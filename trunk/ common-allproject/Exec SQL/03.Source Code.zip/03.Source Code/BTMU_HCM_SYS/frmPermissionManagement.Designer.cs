﻿namespace BTMU_HCM_SYS
{
    partial class frmPermissionManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPermissionManagement));
            this.btNew = new System.Windows.Forms.Button();
            this.lblMsg = new System.Windows.Forms.Label();
            this.dtgPermissionList = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.btClose = new System.Windows.Forms.Button();
            this.btDelete = new System.Windows.Forms.Button();
            this.btUpdate = new System.Windows.Forms.Button();
            this.btInsert = new System.Windows.Forms.Button();
            this.chkModify = new System.Windows.Forms.CheckBox();
            this.cbDept = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.cbUserName = new System.Windows.Forms.ComboBox();
            this.chbUpdateCompleteDate = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chbApproval = new System.Windows.Forms.CheckBox();
            this.chbInchargeIOD = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgPermissionList)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btNew
            // 
            this.btNew.Location = new System.Drawing.Point(97, 520);
            this.btNew.Name = "btNew";
            this.btNew.Size = new System.Drawing.Size(75, 23);
            this.btNew.TabIndex = 35;
            this.btNew.Text = "New";
            this.btNew.UseVisualStyleBackColor = true;
            this.btNew.Click += new System.EventHandler(this.btNew_Click);
            // 
            // lblMsg
            // 
            this.lblMsg.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMsg.Location = new System.Drawing.Point(0, 553);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(680, 23);
            this.lblMsg.TabIndex = 34;
            this.lblMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtgPermissionList
            // 
            this.dtgPermissionList.AllowUserToAddRows = false;
            this.dtgPermissionList.BackgroundColor = System.Drawing.Color.White;
            this.dtgPermissionList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgPermissionList.Location = new System.Drawing.Point(12, 28);
            this.dtgPermissionList.MultiSelect = false;
            this.dtgPermissionList.Name = "dtgPermissionList";
            this.dtgPermissionList.ReadOnly = true;
            this.dtgPermissionList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgPermissionList.Size = new System.Drawing.Size(655, 380);
            this.dtgPermissionList.TabIndex = 33;
            this.dtgPermissionList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgPermissionList_CellClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 16);
            this.label5.TabIndex = 32;
            this.label5.Text = "User Permission List";
            // 
            // btClose
            // 
            this.btClose.Location = new System.Drawing.Point(481, 520);
            this.btClose.Name = "btClose";
            this.btClose.Size = new System.Drawing.Size(75, 23);
            this.btClose.TabIndex = 31;
            this.btClose.Text = "Close";
            this.btClose.UseVisualStyleBackColor = true;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // btDelete
            // 
            this.btDelete.Location = new System.Drawing.Point(385, 520);
            this.btDelete.Name = "btDelete";
            this.btDelete.Size = new System.Drawing.Size(75, 23);
            this.btDelete.TabIndex = 30;
            this.btDelete.Text = "Delete";
            this.btDelete.UseVisualStyleBackColor = true;
            this.btDelete.Click += new System.EventHandler(this.btDelete_Click);
            // 
            // btUpdate
            // 
            this.btUpdate.Location = new System.Drawing.Point(289, 520);
            this.btUpdate.Name = "btUpdate";
            this.btUpdate.Size = new System.Drawing.Size(75, 23);
            this.btUpdate.TabIndex = 29;
            this.btUpdate.Text = "Update";
            this.btUpdate.UseVisualStyleBackColor = true;
            this.btUpdate.Click += new System.EventHandler(this.btUpdate_Click);
            // 
            // btInsert
            // 
            this.btInsert.Location = new System.Drawing.Point(193, 520);
            this.btInsert.Name = "btInsert";
            this.btInsert.Size = new System.Drawing.Size(75, 23);
            this.btInsert.TabIndex = 28;
            this.btInsert.Text = "Insert";
            this.btInsert.UseVisualStyleBackColor = true;
            this.btInsert.Click += new System.EventHandler(this.btInsert_Click);
            // 
            // chkModify
            // 
            this.chkModify.AutoSize = true;
            this.chkModify.Location = new System.Drawing.Point(226, 22);
            this.chkModify.Name = "chkModify";
            this.chkModify.Size = new System.Drawing.Size(57, 17);
            this.chkModify.TabIndex = 27;
            this.chkModify.Text = "Modify";
            this.chkModify.UseVisualStyleBackColor = true;
            // 
            // cbDept
            // 
            this.cbDept.FormattingEnabled = true;
            this.cbDept.Location = new System.Drawing.Point(89, 55);
            this.cbDept.Name = "cbDept";
            this.cbDept.Size = new System.Drawing.Size(121, 21);
            this.cbDept.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Menu";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "UserName";
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Location = new System.Drawing.Point(226, 57);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(57, 17);
            this.chkDelete.TabIndex = 36;
            this.chkDelete.Text = "Delete";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // cbUserName
            // 
            this.cbUserName.FormattingEnabled = true;
            this.cbUserName.Location = new System.Drawing.Point(89, 20);
            this.cbUserName.Name = "cbUserName";
            this.cbUserName.Size = new System.Drawing.Size(121, 21);
            this.cbUserName.TabIndex = 25;
            // 
            // chbUpdateCompleteDate
            // 
            this.chbUpdateCompleteDate.AutoSize = true;
            this.chbUpdateCompleteDate.Location = new System.Drawing.Point(320, 22);
            this.chbUpdateCompleteDate.Name = "chbUpdateCompleteDate";
            this.chbUpdateCompleteDate.Size = new System.Drawing.Size(134, 17);
            this.chbUpdateCompleteDate.TabIndex = 37;
            this.chbUpdateCompleteDate.Text = "Update Complete Date";
            this.chbUpdateCompleteDate.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.chbInchargeIOD);
            this.groupBox1.Controls.Add(this.chbApproval);
            this.groupBox1.Controls.Add(this.chbUpdateCompleteDate);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbUserName);
            this.groupBox1.Controls.Add(this.cbDept);
            this.groupBox1.Controls.Add(this.chkDelete);
            this.groupBox1.Controls.Add(this.chkModify);
            this.groupBox1.Location = new System.Drawing.Point(15, 414);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(652, 100);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Information Detail";
            // 
            // chbApproval
            // 
            this.chbApproval.AutoSize = true;
            this.chbApproval.Location = new System.Drawing.Point(320, 56);
            this.chbApproval.Name = "chbApproval";
            this.chbApproval.Size = new System.Drawing.Size(107, 17);
            this.chbApproval.TabIndex = 37;
            this.chbApproval.Text = "Approve Irregular";
            this.chbApproval.UseVisualStyleBackColor = true;
            // 
            // chbInchargeIOD
            // 
            this.chbInchargeIOD.AutoSize = true;
            this.chbInchargeIOD.Location = new System.Drawing.Point(480, 22);
            this.chbInchargeIOD.Name = "chbInchargeIOD";
            this.chbInchargeIOD.Size = new System.Drawing.Size(90, 17);
            this.chbInchargeIOD.TabIndex = 37;
            this.chbInchargeIOD.Text = "Incharge IOD";
            this.chbInchargeIOD.UseVisualStyleBackColor = true;
            // 
            // frmPermissionManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(680, 576);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btNew);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.dtgPermissionList);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btClose);
            this.Controls.Add(this.btDelete);
            this.Controls.Add(this.btUpdate);
            this.Controls.Add(this.btInsert);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmPermissionManagement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Permission Management";
            this.Load += new System.EventHandler(this.frmPermissionManagement_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgPermissionList)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btNew;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.DataGridView dtgPermissionList;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btClose;
        private System.Windows.Forms.Button btDelete;
        private System.Windows.Forms.Button btUpdate;
        private System.Windows.Forms.Button btInsert;
        private System.Windows.Forms.CheckBox chkModify;
        private System.Windows.Forms.ComboBox cbDept;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkDelete;
        private System.Windows.Forms.ComboBox cbUserName;
        private System.Windows.Forms.CheckBox chbUpdateCompleteDate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chbApproval;
        private System.Windows.Forms.CheckBox chbInchargeIOD;
    }
}