﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;
using DataEncryption;

namespace BTMU_HCM_SYS
{
    class UserSourceClass
    {
        //variables for DataBase        
        public static string _username = "";
        public static string _pwd = "";            

        #region constructor to load settings from file xml
        public static void getDataFromXML()
        {
            //can't find User.config
            if (!File.Exists(@"./settings/User.config"))
            {                               
                _username = "edphcm";                
                _pwd = "edpbtmu";                              
                writeDataBaseXML();
                //loadDataBaseSettings();
                getDataFromXML();
            }

            DataSet _ds = new DataSet();
            _ds.ReadXml(@"./settings/User.config");
            DataRow _row = _ds.Tables["database"].Rows[0];            
            _username = _row["username"].ToString();
            _username = Encryption.decrypt(_username);
            _pwd = _row["pwd"].ToString();
            _pwd = Encryption.decrypt(_pwd);
        }        
        #endregion

        #region write settings into xml file
        //DataBase settings file
        public static void writeDataBaseXML()
        {            
            _username = Encryption.encrypt(_username);
            _pwd = Encryption.encrypt(_pwd);            
            try
            {
                // Error reading config file. Create and save new file.
                string xmlFrag = "<?xml version=\"1.0\" standalone=\"yes\"?>\n" +
                    "<configuration>\n" +
                    "   <database username=\"" + _username + "\" pwd=\"" + _pwd + "\" />\n" +
                    "</configuration>";
                //create folder settings
                Directory.CreateDirectory("settings");
                StreamWriter writer = new StreamWriter(@"./settings/User.config");
                writer.WriteLine(xmlFrag);
                writer.Flush();
                writer.Close();
            }
            catch
            {
                MessageBox.Show("Can't create User.config");
            }
        }
        #endregion        
    }
}
