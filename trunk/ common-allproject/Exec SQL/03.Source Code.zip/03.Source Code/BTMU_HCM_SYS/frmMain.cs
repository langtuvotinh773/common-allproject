using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using DataAccessLayer;
using ucKYC_Report;
using ucLoan_TLAD.Input;
using ucLoan_TLAD.Report;
using BTMU_HCM_SYS.CBD.Report;
using BTMU_HCM_SYS.CBD.Input;
using ucACC_Report;
using ucCBD_IrregularHandling;
using ucCBD_Report;
using ucCBD_IrregularHandling.Irregular;
using ucMO_Input;
using ucGCMS_FEE_CMS_TEAM_CBD1;
using ucGCMS_FEE_CMS_TEAM_CBD1.Forms;
using ucIOD_Input;
using CPA;
using OL;
using Phoenix.Cpa.Gui.Forms;
using System.Collections.Generic;
using Phoenix.Cpa.Bus;
using Phoenix.Ol.Gui;
using Phoenix.Common.Security.Com;
using Config.Classes;
using Phoenix.Lg.Gui.Forms;
using Phoenix.Lg.Common;
using Phoenix.Lg.Reconcile;
using Phoenix.Common.Security.Gui;
using Phoenix.Common.Log.Gui;
using Phoenix.Common.MasterData.Gui;
using Phoenix.Common.Smile.Gui;
using Phoenix.Common.MasterData.Com;
namespace BTMU_HCM_SYS
{
    /// <summary>
    /// Summary description for frmMain.
    /// </summary>
    public class frmMain : System.Windows.Forms.Form
    {
        #region control designer
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem changePasswordToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem kYCToolStripMenuItem;
        private ToolStripMenuItem inputToolStripMenuItem;
        private ToolStripMenuItem individualsToolStripMenuItem;
        private ToolStripMenuItem corporateToolStripMenuItem;
        private ToolStripMenuItem reportToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem individualsToolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem corporateToolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripMenuItem optionsToolStripMenuItem;
        private ToolStripMenuItem automaticallyUpdateToolStripMenuItem;
        private ToolStripMenuItem cBDToolStripMenuItem;
        private ToolStripMenuItem inputToolStripMenuItem1;
        private ToolStripMenuItem corporateCustomerToolStripMenuItem;
        private ToolStripMenuItem accountInformationToolStripMenuItem;
        private ToolStripMenuItem creditApplicationInformationToolStripMenuItem;
        private ToolStripMenuItem loanInformationToolStripMenuItem;
        private ToolStripMenuItem borrowerRateInformationToolStripMenuItem;
        private ToolStripMenuItem agreementControlToolStripMenuItem;
        private ToolStripMenuItem marginsToolStripMenuItem;
        private ToolStripMenuItem reportToolStripMenuItem1;
        private ToolStripMenuItem reportListToolStripMenuItem;
        private ToolStripMenuItem backOfficeToolStripMenuItem;
        private ToolStripMenuItem iODToolStripMenuItem;
        private ToolStripMenuItem dPDToolStripMenuItem;
        private ToolStripMenuItem treasuryToolStripMenuItem;
        private ToolStripMenuItem administratorToolStripMenuItem;
        private ToolStripMenuItem userManagementToolStripMenuItem;
        private ToolStripMenuItem databaseManagementToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem1;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private ToolStripMenuItem userPermissionManagementToolStripMenuItem;
        private ToolStripMenuItem creditConditionAndInstructionToolStripMenuItem;
        private ToolStripMenuItem reportLocalToolStripMenuItem;
        private ToolStripMenuItem checklistAgmtDocsCollectionToolStripMenuItem;
        private ToolStripMenuItem checklistFacilityDocsDeliveryToolStripMenuItem;
        private ToolStripMenuItem checklistMsterAgmtsDeliveryToolStripMenuItem;
        private ToolStripMenuItem creditCondAndInstSheetToolStripMenuItem;
        private ToolStripMenuItem creditConditionSheetToolStripMenuItem;
        private ToolStripMenuItem corporateCustomerClosedToolStripMenuItem;
        private ToolStripMenuItem borrowerRatingSmileUpdateToolStripMenuItem;
        private ToolStripMenuItem monthendRatesToolStripMenuItem;
        private ToolStripMenuItem bussinessToolStripMenuItem;
        private ToolStripMenuItem printFormToolStripMenuItem;
        private PrintDocument printDocument1;
        private ToolStripMenuItem borrowerRatingToolStripMenuItem;
        private ToolStripMenuItem byGradeToolStripMenuItem;
        private ToolStripMenuItem byMaturityToolStripMenuItem;
        private ToolStripMenuItem creditAppToolStripMenuItem;
        private ToolStripMenuItem customerListToolStripMenuItem;
        private ToolStripMenuItem byGroupToolStripMenuItem;
        private ToolStripMenuItem byTypeToolStripMenuItem;
        private ToolStripMenuItem byEPZToolStripMenuItem;
        private ToolStripMenuItem subIdenticalToolStripMenuItem;
        private ToolStripMenuItem industrySummaryToolStripMenuItem;
        private ToolStripMenuItem newCustomerQueryToolStripMenuItem;
        private ToolStripMenuItem rPTCreditOutstandingByDiscretionToolStripMenuItem;
        private ToolStripMenuItem outstandingCreditToolStripMenuItem;
        private ToolStripMenuItem inputToolStripMenuItem2;
        private ToolStripMenuItem reportToolStripMenuItem2;
        private ToolStripMenuItem loanToolStripMenuItem;
        private ToolStripMenuItem residentialAddressConfirmationToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripMenuItem reportDisbursementToolStripMenuItem;
        private ToolStripMenuItem reportDueDateNoticeToolStripMenuItem;
        private ToolStripMenuItem exportToExcelToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator5;
        private ToolStripMenuItem kYCQIIndividualToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator6;
        private ToolStripMenuItem kYCQICorporateToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator8;
        private ToolStripMenuItem kYCQIIndividualToolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator7;
        private ToolStripMenuItem kYCQICorporateToolStripMenuItem1;
        private ToolStripMenuItem subsidiaryInterestRateToolStripMenuItem;
        private ToolStripMenuItem aCCToolStripMenuItem;
        private ToolStripMenuItem accumulativeToolStripMenuItem;
        private ToolStripMenuItem controllingBookToolStripMenuItem;
        private ToolStripMenuItem loanInformationForSTANDARDSMILEToolStripMenuItem;
        private ToolStripMenuItem loanSTANDARDSMILEToolStripMenuItem;
        private ToolStripMenuItem subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem;
        private ToolStripMenuItem controllingPendingItemsToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator9;
        private ToolStripMenuItem dataCleansingToolStripMenuItem;
        private ToolStripMenuItem customerCodeSourceToolStripMenuItem;
        private ToolStripMenuItem customerCodeImportToolStripMenuItem;
        private ToolStripMenuItem irregularHandlingToolStripMenuItem;
        private ToolStripMenuItem newIrregularToolStripMenuItem;
        private ToolStripMenuItem viewToolStripMenuItem;
        private ToolStripMenuItem noApprovalIrreglarToolStripMenuItem;
        private ToolStripMenuItem allIrregularToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator10;
        private ToolStripMenuItem groupToolStripMenuItem;
        private ToolStripMenuItem guaranteeToolStripMenuItem;
        private ToolStripMenuItem importExporotToolStripMenuItem;
        private ToolStripMenuItem checksAndTCToolStripMenuItem;
        private ToolStripMenuItem exportServiceToolStripMenuItem;
        private ToolStripMenuItem foreignRemittanceToolStripMenuItem;
        private ToolStripMenuItem otherServiceToolStripMenuItem;
        private ToolStripMenuItem irregularHandlingToolStripMenuItem1;
        private ToolStripMenuItem viewToolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator11;
        private ToolStripMenuItem groupToolStripMenuItem1;
        private ToolStripMenuItem guaranteeToolStripMenuItem1;
        private ToolStripMenuItem importServiceToolStripMenuItem;
        private ToolStripMenuItem exportServiceToolStripMenuItem1;
        private ToolStripMenuItem checksAndTCToolStripMenuItem1;
        private ToolStripMenuItem foreignRemittanceToolStripMenuItem1;
        private ToolStripMenuItem otherServicesToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator12;
        private ToolStripSeparator toolStripSeparator13;
        private ToolStripSeparator toolStripSeparator14;
        private ToolStripMenuItem authorizedPersonToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator15;
        private ToolStripMenuItem toolStripMenuItem11;
        private ToolStripMenuItem toolStripMenuItem12;
        private ToolStripSeparator toolStripSeparator16;
        private ToolStripMenuItem toolStripMenuItem13;
        private ToolStripMenuItem toolStripMenuItem14;
        private ToolStripMenuItem toolStripMenuItem15;
        private ToolStripMenuItem toolStripMenuItem16;
        private ToolStripMenuItem toolStripMenuItem17;
        private ToolStripMenuItem toolStripMenuItem18;
        private ToolStripMenuItem toolStripMenuItem19;
        private ToolStripSeparator toolStripSeparator17;
        private ToolStripMenuItem domesticRemittanceToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator18;
        private ToolStripMenuItem accountServicesToolStripMenuItem;
        private ToolStripMenuItem reportToolStripMenuItem3;
        private ToolStripMenuItem forJPCustomersToolStripMenuItem;
        private ToolStripMenuItem forNonJPCustomersToolStripMenuItem;
        private ToolStripMenuItem irregularHandlingForToolStripMenuItem;
        private ToolStripMenuItem closeIrregularToolStripMenuItem;
        private ToolStripMenuItem comfirmationToolStripMenuItem;
        private ToolStripMenuItem confirmationToolStripMenuItem1;
        private ToolStripMenuItem accountServicesToolStripMenuItem1;
        private ToolStripMenuItem domesticRemittanceToolStripMenuItem1;
        private ToolStripMenuItem accountServicesToolStripMenuItem2;
        private ToolStripMenuItem domesticRemittanceToolStripMenuItem2;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripSeparator toolStripSeparator19;
        private ToolStripMenuItem uploadDataToolStripMenuItem;
        private ToolStripMenuItem confirmationToolStripMenuItem;
        private ToolStripMenuItem reviewIrregularToolStripMenuItem;
        private ToolStripMenuItem editIrregularToolStripMenuItem;
        private ToolStripMenuItem importAccountToolStripMenuItem1;
        private ToolStripMenuItem importAddressToolStripMenuItem;
        private ToolStripMenuItem middleOfficeToolStripMenuItem;
        private ToolStripMenuItem credlitLineToolStripMenuItem;
        private ToolStripMenuItem forCorporateToolStripMenuItem;
        private ToolStripMenuItem forBankToolStripMenuItem;
        private ToolStripMenuItem fXConfirmationToolStripMenuItem;
        private ToolStripMenuItem cMSTeamToolStripMenuItem;
        private ToolStripMenuItem manageGCMSCustomerToolStripMenuItem;
        private ToolStripMenuItem makingDebitIntructionToolStripMenuItem;
        private ToolStripMenuItem makingReportToolStripMenuItem;
        private ToolStripMenuItem holidaysConfigurationToolStripMenuItem;
        private ToolStripMenuItem borrowRatingToolStripMenuItem;
        private ToolStripMenuItem pendingItemToolStripMenuItem;
        private ToolStripMenuItem covenantToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator20;
        private ToolStripMenuItem monthlyReportToolStripMenuItem;
        private ToolStripMenuItem creditFacilityForCorporateToolStripMenuItem;
        private ToolStripMenuItem creditFacilityForBankToolStripMenuItem;
        private ToolStripMenuItem securityReportToolStripMenuItem;
        private ToolStripMenuItem instructionConditionForCorporateToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripMenuItem instructionConditionForBankToolStripMenuItem;
        private ToolStripMenuItem borrowerRatingToolStripMenuItem1;
        private ToolStripMenuItem pendingItemREquesToolStripMenuItem;
        private ToolStripMenuItem facilityReportToolStripMenuItem;
        private ToolStripMenuItem pendingItemForBRToolStripMenuItem;
        private ToolStripMenuItem maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem4;
        private ToolStripMenuItem overdueInstructionConditionForCorporateToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator21;
        private ToolStripMenuItem transactionsToolStripMenuItem;
        private ToolStripMenuItem manageTransactionsToolStripMenuItem;
        private ToolStripMenuItem transaToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator22;
        private ToolStripMenuItem createStatementToolStripMenuItem;
        private ToolStripMenuItem statementQueryToolStripMenuItem;
        private ToolStripMenuItem uploadTransactionsToolStripMenuItem;
        private ToolStripMenuItem makeTransactionReportToolStripMenuItem;
        private ToolStripMenuItem agentTransactionToolStripMenuItem;
        private ToolStripMenuItem tsCPAMainMenu;
        private ToolStripMenuItem tsCPAImportEDPList;
        private ToolStripMenuItem tsCPACustomerErrorList;
        private ToolStripMenuItem tsCPAFinalizeCPAData;
        private ToolStripMenuItem tsCPAReports;
        private ToolStripMenuItem tsCPAQuaterlyHistoryOfProfit;
        private ToolStripMenuItem tsCPAMonthReport;
        private ToolStripMenuItem tsCPACustomerTrans;
        private ToolStripMenuItem tsCPACustomerProfitability;
        private ToolStripMenuItem tsCPACustomerProfitabilityAnalysis;
        private ToolStripMenuItem tsCPACustomerCPA;
        private ToolStripMenuItem tsmOLMainMenu;
        private ToolStripMenuItem createNewOLToolStripMenuItem;
        private ToolStripMenuItem tsmOLList;
        private ToolStripMenuItem tsmOLListPending;
        private ToolStripSeparator toolStripSeparator24;
        private ToolStripMenuItem tsmOLHistoryList;
        private ToolStripMenuItem tsmCreateRepayment;
        private ToolStripMenuItem tsmRepaymentList;
        private ToolStripSeparator toolStripSeparator23;
        private ToolStripMenuItem tsmImportAccessFile;
        private ToolStripMenuItem tsmReport;
        private ToolStripMenuItem tsLGMainMenu;
        private ToolStripMenuItem tsbCreateApplicant;
        private ToolStripMenuItem tsbCreateBeneficiary;
        private ToolStripMenuItem tsbCreateReportForNonResidentApplicantLG;
        private ToolStripMenuItem tsmAppliantList;
        private ToolStripMenuItem beneficiaryListToolStripMenuItem;
        private ToolStripMenuItem tsmListOfFeeCollection;
        private ToolStripMenuItem tsmLGListSup;
        private ToolStripMenuItem tsmLGStaffList;
        private ToolStripMenuItem tsmHistoryLGList;
        private ToolStripMenuItem tsbIssueList;
        private ToolStripMenuItem tsmLGReport;
        private ToolStripMenuItem reconsileToolStripMenuItem;
        private ToolStripMenuItem reconcileSummaryToolStripMenuItem;
        private ToolStripMenuItem tsSEMainMenu;
        private ToolStripMenuItem tsMDMainMenu;
        private ToolStripMenuItem tsMDDayOffRegist;
        private ToolStripMenuItem tsSEManageUser;
        private ToolStripMenuItem tsSEListUser;
        private ToolStripMenuItem tsSEListTeam;
        private ToolStripMenuItem tsSEListDepartment;
        private ToolStripMenuItem tsSEManageAuthorization;
        private ToolStripMenuItem tsSERoleMgmt;
        private ToolStripMenuItem tsSEMenuMgmt;
        private ToolStripMenuItem tsSEFnMgmt;
        private ToolStripMenuItem tsSEAssignRoleToUser;
        private ToolStripMenuItem tsSEAssignRightToRole;
        private ToolStripMenuItem tsSEAssignMenuToRole;
        private ToolStripMenuItem tsSELogSystem;
        private ToolStripMenuItem tsMDQuotation;
        private ToolStripMenuItem tsMDImportQuotation;
        private ToolStripMenuItem tsMDPreviewQuotationTemplate;
        private ToolStripMenuItem tsMDProcessingDailyQuotationMaker;
        private ToolStripMenuItem tsMDProcessingDailyQuotationApprover;
        private ToolStripMenuItem tsMDCurrencyInquiryQuotationHistory;
        private ToolStripMenuItem tsMDInquiryQuotationHistory;
        private ToolStripMenuItem tsMDCeilingFloor;
        private ToolStripMenuItem tsMDCreateCeilingFloor;
        private ToolStripMenuItem tsMDListCeilingFloor;
        private ToolStripMenuItem tsMDThreshold;
        private ToolStripMenuItem tsMDCreateThreshold;
        private ToolStripMenuItem tsMDListThreshold;
        private ToolStripMenuItem tsSEExternalLog;
        private ToolStripMenuItem tsSETransactionLog;
        private ToolStripMenuItem tsSESmileLog;
        private ToolStripMenuItem customerInformationToolStripMenuItem;
        private ToolStripMenuItem tsbProcessingBoardRateMaker;
        private ToolStripMenuItem tsbProcessingBoardRateApprover;
        private ToolStripMenuItem tsbInquiryBoardRateHistory;
        private ToolStripMenuItem tsbCurrencyInquiryBoardRateHistory;
        private ToolStripMenuItem tsbPreviewBRsTemplate;
        private ToolStripMenuItem sBVMinMaxToolStripMenuItem;
        private ToolStripMenuItem createSBVMInMaxToolStripMenuItem;
        private ToolStripMenuItem listSBVMinMaxToolStripMenuItem;
        private ToolStripMenuItem prefixTDNoToolStripMenuItem;
        private ToolStripMenuItem createPrefixTDNoToolStripMenuItem;
        private ToolStripMenuItem listPrefixTDNoToolStripMenuItem;
        private ToolStripMenuItem defaultRateToolStripMenuItem;
        private ToolStripMenuItem createDefaultRateToolStripMenuItem;
        private ToolStripMenuItem listDefaultRateToolStripMenuItem;
        private IContainer components;
        #endregion

        public frmMain()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            clsSEAuthorizer m_Security = new clsSEAuthorizer(clsUserInfo.UserNo);
            // Disable all menu items in default
            //m_Security.DisableAllMenuItems(tsCPAMainMenu);
            //m_Security.DisableAllMenuItems(tsmOLMainMenu);
            //m_Security.DisableAllMenuItems(tsLGMainMenu);
            //m_Security.DisableAllMenuItems(tsSEMainMenu);
            //m_Security.DisableAllMenuItems(tsMDMainMenu);
            //m_Security.DisableAllMenuItems(middleOfficeToolStripMenuItem);

            //// Enable menu items from the authorized menu list
            //m_Security.EnableAllAuthorizedMenuItems(tsCPAMainMenu);
            //m_Security.EnableAllAuthorizedMenuItems(tsmOLMainMenu);
            //m_Security.EnableAllAuthorizedMenuItems(tsLGMainMenu);
            //m_Security.EnableAllAuthorizedMenuItems(tsSEMainMenu);
            //m_Security.EnableAllAuthorizedMenuItems(tsMDMainMenu);
            //m_Security.EnableAllAuthorizedMenuItems(middleOfficeToolStripMenuItem);

            //// Hide the remaining disabled menu items from the unauthorized menu list
            //m_Security.HideUnauthorizedMenuItems(tsCPAMainMenu);
            //m_Security.HideUnauthorizedMenuItems(tsmOLMainMenu);
            //m_Security.HideUnauthorizedMenuItems(tsLGMainMenu);
            //m_Security.HideUnauthorizedMenuItems(tsSEMainMenu);
            //m_Security.HideUnauthorizedMenuItems(tsMDMainMenu);
            //m_Security.HideUnauthorizedMenuItems(middleOfficeToolStripMenuItem);

            //m_Security.HideEmptyParentMenuItem(tsCPAMainMenu);
            //m_Security.HideEmptyParentMenuItem(tsmOLMainMenu);
            //m_Security.HideEmptyParentMenuItem(tsLGMainMenu);
            //m_Security.HideEmptyParentMenuItem(tsSEMainMenu);
            //m_Security.HideEmptyParentMenuItem(tsMDMainMenu);
            //m_Security.HideEmptyParentMenuItem(middleOfficeToolStripMenuItem);


            if (clsUserInfo.UserNo <= 0)
            {
                changePasswordToolStripMenuItem.Enabled = false;
            }
            else
            {
                changePasswordToolStripMenuItem.Enabled = true;
            }
            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kYCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.individualsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.corporateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.kYCQIIndividualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.kYCQICorporateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.individualsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.corporateToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.residentialAddressConfirmationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.kYCQIIndividualToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.kYCQICorporateToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.dataCleansingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.automaticallyUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cBDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.corporateCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditApplicationInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loanInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loanInformationForSTANDARDSMILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borrowerRateInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agreementControlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditConditionAndInstructionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.monthendRatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerCodeSourceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bussinessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.corporateCustomerClosedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marginsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportLocalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checklistAgmtDocsCollectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checklistFacilityDocsDeliveryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checklistMsterAgmtsDeliveryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditCondAndInstSheetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditConditionSheetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borrowerRatingSmileUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borrowerRatingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.byGradeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.byMaturityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.byGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.byTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.byEPZToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subIdenticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.industrySummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outstandingCreditToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newCustomerQueryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditAppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rPTCreditOutstandingByDiscretionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.controllingBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.controllingPendingItemsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agentTransactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.irregularHandlingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newIrregularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noApprovalIrreglarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeIrregularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reviewIrregularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allIrregularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editIrregularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.groupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.accountServicesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.domesticRemittanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.foreignRemittanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importExporotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportServiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guaranteeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checksAndTCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherServiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.forJPCustomersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forNonJPCustomersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irregularHandlingForToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.confirmationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cMSTeamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageGCMSCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makingDebitIntructionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makingReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.holidaysConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backOfficeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.loanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loanSTANDARDSMILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fXConfirmationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportDisbursementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportDueDateNoticeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToExcelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subsidiaryInterestRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDMainMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDQuotation = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDImportQuotation = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDPreviewQuotationTemplate = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDProcessingDailyQuotationMaker = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDProcessingDailyQuotationApprover = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDCurrencyInquiryQuotationHistory = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDInquiryQuotationHistory = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDDayOffRegist = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDCeilingFloor = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDCreateCeilingFloor = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDListCeilingFloor = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDThreshold = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDCreateThreshold = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMDListThreshold = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbProcessingBoardRateMaker = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbProcessingBoardRateApprover = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbInquiryBoardRateHistory = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbCurrencyInquiryBoardRateHistory = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbPreviewBRsTemplate = new System.Windows.Forms.ToolStripMenuItem();
            this.sBVMinMaxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createSBVMInMaxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listSBVMinMaxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prefixTDNoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createPrefixTDNoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listPrefixTDNoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.defaultRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createDefaultRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listDefaultRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.middleOfficeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.credlitLineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forCorporateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forBankToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pendingItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borrowRatingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pendingItemForBRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.covenantToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.monthlyReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditFacilityForCorporateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditFacilityForBankToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.securityReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instructionConditionForCorporateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instructionConditionForBankToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borrowerRatingToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pendingItemREquesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facilityReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overdueInstructionConditionForCorporateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aCCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accumulativeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iODToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irregularHandlingToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.groupToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.accountServicesToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.domesticRemittanceToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.foreignRemittanceToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.guaranteeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.importServiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportServiceToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.checksAndTCToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.otherServicesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.comfirmationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.transactionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageTransactionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uploadTransactionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.createStatementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statementQueryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makeTransactionReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dPDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.accountServicesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.domesticRemittanceToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.authorizedPersonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.confirmationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.uploadDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importAccountToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.importAddressToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treasuryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.administratorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userPermissionManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerCodeImportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPAMainMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPAImportEDPList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPACustomerErrorList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPAFinalizeCPAData = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPAReports = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPAQuaterlyHistoryOfProfit = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPAMonthReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPACustomerTrans = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPACustomerProfitability = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPACustomerProfitabilityAnalysis = new System.Windows.Forms.ToolStripMenuItem();
            this.tsCPACustomerCPA = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmOLMainMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.createNewOLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmOLList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmOLListPending = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator24 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmOLHistoryList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmCreateRepayment = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmRepaymentList = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator23 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmImportAccessFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsLGMainMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbCreateApplicant = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbCreateBeneficiary = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbCreateReportForNonResidentApplicantLG = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmAppliantList = new System.Windows.Forms.ToolStripMenuItem();
            this.beneficiaryListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmListOfFeeCollection = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmLGListSup = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmLGStaffList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmHistoryLGList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbIssueList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmLGReport = new System.Windows.Forms.ToolStripMenuItem();
            this.reconsileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reconcileSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEMainMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEManageUser = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEListUser = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEListTeam = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEListDepartment = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEManageAuthorization = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSERoleMgmt = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEMenuMgmt = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEFnMgmt = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEAssignRoleToUser = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEAssignRightToRole = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEAssignMenuToRole = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSELogSystem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSEExternalLog = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSETransactionLog = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSESmileLog = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.tsMDMainMenu,
            this.kYCToolStripMenuItem,
            this.cBDToolStripMenuItem,
            this.cMSTeamToolStripMenuItem,
            this.backOfficeToolStripMenuItem,
            this.middleOfficeToolStripMenuItem,
            this.aCCToolStripMenuItem,
            this.iODToolStripMenuItem,
            this.dPDToolStripMenuItem,
            this.treasuryToolStripMenuItem,
            this.administratorToolStripMenuItem,
            this.tsCPAMainMenu,
            this.tsmOLMainMenu,
            this.tsLGMainMenu,
            this.tsSEMainMenu,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1026, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changePasswordToolStripMenuItem,
            this.printFormToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.changePasswordToolStripMenuItem.Text = "Change password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // printFormToolStripMenuItem
            // 
            this.printFormToolStripMenuItem.Name = "printFormToolStripMenuItem";
            this.printFormToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.printFormToolStripMenuItem.Text = "Print Form";
            this.printFormToolStripMenuItem.Click += new System.EventHandler(this.printFormToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // kYCToolStripMenuItem
            // 
            this.kYCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.toolStripSeparator3,
            this.optionsToolStripMenuItem});
            this.kYCToolStripMenuItem.Name = "kYCToolStripMenuItem";
            this.kYCToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.kYCToolStripMenuItem.Text = "KYC";
            this.kYCToolStripMenuItem.Visible = false;
            // 
            // inputToolStripMenuItem
            // 
            this.inputToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.individualsToolStripMenuItem,
            this.toolStripSeparator1,
            this.corporateToolStripMenuItem,
            this.toolStripSeparator5,
            this.kYCQIIndividualToolStripMenuItem,
            this.toolStripSeparator6,
            this.kYCQICorporateToolStripMenuItem});
            this.inputToolStripMenuItem.Name = "inputToolStripMenuItem";
            this.inputToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.inputToolStripMenuItem.Text = "Input";
            // 
            // individualsToolStripMenuItem
            // 
            this.individualsToolStripMenuItem.Name = "individualsToolStripMenuItem";
            this.individualsToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.individualsToolStripMenuItem.Text = "Individuals";
            this.individualsToolStripMenuItem.Click += new System.EventHandler(this.individualsToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(164, 6);
            // 
            // corporateToolStripMenuItem
            // 
            this.corporateToolStripMenuItem.Name = "corporateToolStripMenuItem";
            this.corporateToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.corporateToolStripMenuItem.Text = "Corporate";
            this.corporateToolStripMenuItem.Click += new System.EventHandler(this.corporateToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(164, 6);
            // 
            // kYCQIIndividualToolStripMenuItem
            // 
            this.kYCQIIndividualToolStripMenuItem.Name = "kYCQIIndividualToolStripMenuItem";
            this.kYCQIIndividualToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.kYCQIIndividualToolStripMenuItem.Text = "KYC QI Individual";
            this.kYCQIIndividualToolStripMenuItem.Click += new System.EventHandler(this.kYCQIIndividualToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(164, 6);
            // 
            // kYCQICorporateToolStripMenuItem
            // 
            this.kYCQICorporateToolStripMenuItem.Name = "kYCQICorporateToolStripMenuItem";
            this.kYCQICorporateToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.kYCQICorporateToolStripMenuItem.Text = "KYC QI Corporate";
            this.kYCQICorporateToolStripMenuItem.Click += new System.EventHandler(this.kYCQICorporateToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.individualsToolStripMenuItem1,
            this.toolStripSeparator2,
            this.corporateToolStripMenuItem1,
            this.toolStripSeparator4,
            this.residentialAddressConfirmationToolStripMenuItem,
            this.toolStripSeparator8,
            this.kYCQIIndividualToolStripMenuItem1,
            this.toolStripSeparator7,
            this.kYCQICorporateToolStripMenuItem1,
            this.toolStripSeparator9,
            this.dataCleansingToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // individualsToolStripMenuItem1
            // 
            this.individualsToolStripMenuItem1.Name = "individualsToolStripMenuItem1";
            this.individualsToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.individualsToolStripMenuItem1.Text = "Individuals";
            this.individualsToolStripMenuItem1.Click += new System.EventHandler(this.individualsToolStripMenuItem1_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(164, 6);
            // 
            // corporateToolStripMenuItem1
            // 
            this.corporateToolStripMenuItem1.Name = "corporateToolStripMenuItem1";
            this.corporateToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.corporateToolStripMenuItem1.Text = "Corporate";
            this.corporateToolStripMenuItem1.Click += new System.EventHandler(this.corporateToolStripMenuItem1_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(164, 6);
            // 
            // residentialAddressConfirmationToolStripMenuItem
            // 
            this.residentialAddressConfirmationToolStripMenuItem.Name = "residentialAddressConfirmationToolStripMenuItem";
            this.residentialAddressConfirmationToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.residentialAddressConfirmationToolStripMenuItem.Text = "Export to Excel";
            this.residentialAddressConfirmationToolStripMenuItem.Click += new System.EventHandler(this.residentialAddressConfirmationToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(164, 6);
            // 
            // kYCQIIndividualToolStripMenuItem1
            // 
            this.kYCQIIndividualToolStripMenuItem1.Name = "kYCQIIndividualToolStripMenuItem1";
            this.kYCQIIndividualToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.kYCQIIndividualToolStripMenuItem1.Text = "KYC QI Individual";
            this.kYCQIIndividualToolStripMenuItem1.Click += new System.EventHandler(this.kYCQIIndividualToolStripMenuItem1_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(164, 6);
            // 
            // kYCQICorporateToolStripMenuItem1
            // 
            this.kYCQICorporateToolStripMenuItem1.Name = "kYCQICorporateToolStripMenuItem1";
            this.kYCQICorporateToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.kYCQICorporateToolStripMenuItem1.Text = "KYC QI Corporate";
            this.kYCQICorporateToolStripMenuItem1.Click += new System.EventHandler(this.kYCQICorporateToolStripMenuItem1_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(164, 6);
            // 
            // dataCleansingToolStripMenuItem
            // 
            this.dataCleansingToolStripMenuItem.Name = "dataCleansingToolStripMenuItem";
            this.dataCleansingToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.dataCleansingToolStripMenuItem.Text = "Data Cleansing";
            this.dataCleansingToolStripMenuItem.Click += new System.EventHandler(this.dataCleansingToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(113, 6);
            this.toolStripSeparator3.Visible = false;
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.automaticallyUpdateToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.optionsToolStripMenuItem.Text = "Options";
            this.optionsToolStripMenuItem.Visible = false;
            // 
            // automaticallyUpdateToolStripMenuItem
            // 
            this.automaticallyUpdateToolStripMenuItem.Name = "automaticallyUpdateToolStripMenuItem";
            this.automaticallyUpdateToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.automaticallyUpdateToolStripMenuItem.Text = "Automatically update";
            this.automaticallyUpdateToolStripMenuItem.Click += new System.EventHandler(this.automaticallyUpdateToolStripMenuItem_Click);
            // 
            // cBDToolStripMenuItem
            // 
            this.cBDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputToolStripMenuItem1,
            this.reportToolStripMenuItem1,
            this.toolStripSeparator15,
            this.irregularHandlingToolStripMenuItem,
            this.reportToolStripMenuItem3,
            this.confirmationToolStripMenuItem});
            this.cBDToolStripMenuItem.Name = "cBDToolStripMenuItem";
            this.cBDToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.cBDToolStripMenuItem.Text = "CBD";
            this.cBDToolStripMenuItem.Visible = false;
            // 
            // inputToolStripMenuItem1
            // 
            this.inputToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.corporateCustomerToolStripMenuItem,
            this.accountInformationToolStripMenuItem,
            this.creditApplicationInformationToolStripMenuItem,
            this.loanInformationToolStripMenuItem,
            this.loanInformationForSTANDARDSMILEToolStripMenuItem,
            this.borrowerRateInformationToolStripMenuItem,
            this.agreementControlToolStripMenuItem,
            this.creditConditionAndInstructionToolStripMenuItem,
            this.monthendRatesToolStripMenuItem,
            this.customerCodeSourceToolStripMenuItem,
            this.bussinessToolStripMenuItem,
            this.corporateCustomerClosedToolStripMenuItem,
            this.marginsToolStripMenuItem});
            this.inputToolStripMenuItem1.Name = "inputToolStripMenuItem1";
            this.inputToolStripMenuItem1.Size = new System.Drawing.Size(170, 22);
            this.inputToolStripMenuItem1.Text = "Input";
            // 
            // corporateCustomerToolStripMenuItem
            // 
            this.corporateCustomerToolStripMenuItem.Name = "corporateCustomerToolStripMenuItem";
            this.corporateCustomerToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.corporateCustomerToolStripMenuItem.Text = "Corporate Customer";
            this.corporateCustomerToolStripMenuItem.Click += new System.EventHandler(this.corporateCustomerToolStripMenuItem_Click);
            // 
            // accountInformationToolStripMenuItem
            // 
            this.accountInformationToolStripMenuItem.Name = "accountInformationToolStripMenuItem";
            this.accountInformationToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.accountInformationToolStripMenuItem.Text = "Account Information";
            this.accountInformationToolStripMenuItem.Click += new System.EventHandler(this.accountInformationToolStripMenuItem_Click);
            // 
            // creditApplicationInformationToolStripMenuItem
            // 
            this.creditApplicationInformationToolStripMenuItem.Name = "creditApplicationInformationToolStripMenuItem";
            this.creditApplicationInformationToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.creditApplicationInformationToolStripMenuItem.Text = "Credit Application Information";
            this.creditApplicationInformationToolStripMenuItem.Click += new System.EventHandler(this.creditApplicationInformationToolStripMenuItem_Click);
            // 
            // loanInformationToolStripMenuItem
            // 
            this.loanInformationToolStripMenuItem.Name = "loanInformationToolStripMenuItem";
            this.loanInformationToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.loanInformationToolStripMenuItem.Text = "Loan Information";
            this.loanInformationToolStripMenuItem.Click += new System.EventHandler(this.loanInformationToolStripMenuItem_Click);
            // 
            // loanInformationForSTANDARDSMILEToolStripMenuItem
            // 
            this.loanInformationForSTANDARDSMILEToolStripMenuItem.Name = "loanInformationForSTANDARDSMILEToolStripMenuItem";
            this.loanInformationForSTANDARDSMILEToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.loanInformationForSTANDARDSMILEToolStripMenuItem.Text = "Loan Information (STANDARD SMILE)";
            this.loanInformationForSTANDARDSMILEToolStripMenuItem.Click += new System.EventHandler(this.loanInformationForSTANDARDSMILEToolStripMenuItem_Click);
            // 
            // borrowerRateInformationToolStripMenuItem
            // 
            this.borrowerRateInformationToolStripMenuItem.Name = "borrowerRateInformationToolStripMenuItem";
            this.borrowerRateInformationToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.borrowerRateInformationToolStripMenuItem.Text = "Borrower Rate Information";
            this.borrowerRateInformationToolStripMenuItem.Click += new System.EventHandler(this.borrowerRateInformationToolStripMenuItem_Click);
            // 
            // agreementControlToolStripMenuItem
            // 
            this.agreementControlToolStripMenuItem.Name = "agreementControlToolStripMenuItem";
            this.agreementControlToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.agreementControlToolStripMenuItem.Text = "Agreement Control";
            this.agreementControlToolStripMenuItem.Click += new System.EventHandler(this.agreementControlToolStripMenuItem_Click);
            // 
            // creditConditionAndInstructionToolStripMenuItem
            // 
            this.creditConditionAndInstructionToolStripMenuItem.Name = "creditConditionAndInstructionToolStripMenuItem";
            this.creditConditionAndInstructionToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.creditConditionAndInstructionToolStripMenuItem.Text = "Credit Condition and Instruction";
            this.creditConditionAndInstructionToolStripMenuItem.Click += new System.EventHandler(this.creditConditionAndInstructionToolStripMenuItem_Click);
            // 
            // monthendRatesToolStripMenuItem
            // 
            this.monthendRatesToolStripMenuItem.Name = "monthendRatesToolStripMenuItem";
            this.monthendRatesToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.monthendRatesToolStripMenuItem.Text = "Month-end Rates";
            this.monthendRatesToolStripMenuItem.Click += new System.EventHandler(this.monthendRatesToolStripMenuItem_Click);
            // 
            // customerCodeSourceToolStripMenuItem
            // 
            this.customerCodeSourceToolStripMenuItem.Name = "customerCodeSourceToolStripMenuItem";
            this.customerCodeSourceToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.customerCodeSourceToolStripMenuItem.Text = "Customer Code Source";
            this.customerCodeSourceToolStripMenuItem.Visible = false;
            this.customerCodeSourceToolStripMenuItem.Click += new System.EventHandler(this.customerCodeSourceToolStripMenuItem_Click);
            // 
            // bussinessToolStripMenuItem
            // 
            this.bussinessToolStripMenuItem.Name = "bussinessToolStripMenuItem";
            this.bussinessToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.bussinessToolStripMenuItem.Text = "Business Promotion ";
            this.bussinessToolStripMenuItem.Click += new System.EventHandler(this.bussinessToolStripMenuItem_Click);
            // 
            // corporateCustomerClosedToolStripMenuItem
            // 
            this.corporateCustomerClosedToolStripMenuItem.Name = "corporateCustomerClosedToolStripMenuItem";
            this.corporateCustomerClosedToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.corporateCustomerClosedToolStripMenuItem.Text = "Corporate Customer Closed";
            this.corporateCustomerClosedToolStripMenuItem.Click += new System.EventHandler(this.corporateCustomerClosedToolStripMenuItem_Click);
            // 
            // marginsToolStripMenuItem
            // 
            this.marginsToolStripMenuItem.Name = "marginsToolStripMenuItem";
            this.marginsToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.marginsToolStripMenuItem.Text = "Margins";
            this.marginsToolStripMenuItem.Visible = false;
            this.marginsToolStripMenuItem.Click += new System.EventHandler(this.marginsToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem1
            // 
            this.reportToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportLocalToolStripMenuItem,
            this.reportListToolStripMenuItem,
            this.controllingBookToolStripMenuItem,
            this.controllingPendingItemsToolStripMenuItem,
            this.agentTransactionToolStripMenuItem});
            this.reportToolStripMenuItem1.Name = "reportToolStripMenuItem1";
            this.reportToolStripMenuItem1.Size = new System.Drawing.Size(170, 22);
            this.reportToolStripMenuItem1.Text = "Report";
            // 
            // reportLocalToolStripMenuItem
            // 
            this.reportLocalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.checklistAgmtDocsCollectionToolStripMenuItem,
            this.checklistFacilityDocsDeliveryToolStripMenuItem,
            this.checklistMsterAgmtsDeliveryToolStripMenuItem,
            this.creditCondAndInstSheetToolStripMenuItem,
            this.creditConditionSheetToolStripMenuItem,
            this.borrowerRatingSmileUpdateToolStripMenuItem});
            this.reportLocalToolStripMenuItem.Name = "reportLocalToolStripMenuItem";
            this.reportLocalToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.reportLocalToolStripMenuItem.Text = "Important Report List";
            // 
            // checklistAgmtDocsCollectionToolStripMenuItem
            // 
            this.checklistAgmtDocsCollectionToolStripMenuItem.Name = "checklistAgmtDocsCollectionToolStripMenuItem";
            this.checklistAgmtDocsCollectionToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.checklistAgmtDocsCollectionToolStripMenuItem.Text = "Checklist - Agmt Docs Collection";
            this.checklistAgmtDocsCollectionToolStripMenuItem.Click += new System.EventHandler(this.checklistAgmtDocsCollectionToolStripMenuItem_Click);
            // 
            // checklistFacilityDocsDeliveryToolStripMenuItem
            // 
            this.checklistFacilityDocsDeliveryToolStripMenuItem.Name = "checklistFacilityDocsDeliveryToolStripMenuItem";
            this.checklistFacilityDocsDeliveryToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.checklistFacilityDocsDeliveryToolStripMenuItem.Text = "Checklist - Facility Docs Delivery";
            this.checklistFacilityDocsDeliveryToolStripMenuItem.Click += new System.EventHandler(this.checklistFacilityDocsDeliveryToolStripMenuItem_Click);
            // 
            // checklistMsterAgmtsDeliveryToolStripMenuItem
            // 
            this.checklistMsterAgmtsDeliveryToolStripMenuItem.Name = "checklistMsterAgmtsDeliveryToolStripMenuItem";
            this.checklistMsterAgmtsDeliveryToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.checklistMsterAgmtsDeliveryToolStripMenuItem.Text = "Checklist - Mster Agmts Delivery";
            this.checklistMsterAgmtsDeliveryToolStripMenuItem.Click += new System.EventHandler(this.checklistMsterAgmtsDeliveryToolStripMenuItem_Click);
            // 
            // creditCondAndInstSheetToolStripMenuItem
            // 
            this.creditCondAndInstSheetToolStripMenuItem.Name = "creditCondAndInstSheetToolStripMenuItem";
            this.creditCondAndInstSheetToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.creditCondAndInstSheetToolStripMenuItem.Text = "Credit Cond and Inst Sheet";
            this.creditCondAndInstSheetToolStripMenuItem.Click += new System.EventHandler(this.creditCondAndInstSheetToolStripMenuItem_Click);
            // 
            // creditConditionSheetToolStripMenuItem
            // 
            this.creditConditionSheetToolStripMenuItem.Name = "creditConditionSheetToolStripMenuItem";
            this.creditConditionSheetToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.creditConditionSheetToolStripMenuItem.Text = "Credit Condition Sheet";
            this.creditConditionSheetToolStripMenuItem.Click += new System.EventHandler(this.creditConditionSheetToolStripMenuItem_Click);
            // 
            // borrowerRatingSmileUpdateToolStripMenuItem
            // 
            this.borrowerRatingSmileUpdateToolStripMenuItem.Name = "borrowerRatingSmileUpdateToolStripMenuItem";
            this.borrowerRatingSmileUpdateToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.borrowerRatingSmileUpdateToolStripMenuItem.Text = "Borrower Rating Smile Update";
            this.borrowerRatingSmileUpdateToolStripMenuItem.Click += new System.EventHandler(this.borrowerRatingSmileUpdateToolStripMenuItem_Click);
            // 
            // reportListToolStripMenuItem
            // 
            this.reportListToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.borrowerRatingToolStripMenuItem,
            this.customerListToolStripMenuItem,
            this.newCustomerQueryToolStripMenuItem,
            this.creditAppToolStripMenuItem,
            this.rPTCreditOutstandingByDiscretionToolStripMenuItem});
            this.reportListToolStripMenuItem.Name = "reportListToolStripMenuItem";
            this.reportListToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.reportListToolStripMenuItem.Text = "Report List";
            this.reportListToolStripMenuItem.Click += new System.EventHandler(this.reportListToolStripMenuItem_Click);
            // 
            // borrowerRatingToolStripMenuItem
            // 
            this.borrowerRatingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.byGradeToolStripMenuItem,
            this.byMaturityToolStripMenuItem});
            this.borrowerRatingToolStripMenuItem.Name = "borrowerRatingToolStripMenuItem";
            this.borrowerRatingToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.borrowerRatingToolStripMenuItem.Text = "Borrower Ratings";
            // 
            // byGradeToolStripMenuItem
            // 
            this.byGradeToolStripMenuItem.Name = "byGradeToolStripMenuItem";
            this.byGradeToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.byGradeToolStripMenuItem.Text = "by Grade";
            this.byGradeToolStripMenuItem.Click += new System.EventHandler(this.byGradeToolStripMenuItem_Click);
            // 
            // byMaturityToolStripMenuItem
            // 
            this.byMaturityToolStripMenuItem.Name = "byMaturityToolStripMenuItem";
            this.byMaturityToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.byMaturityToolStripMenuItem.Text = "by Maturity";
            this.byMaturityToolStripMenuItem.Click += new System.EventHandler(this.byMaturityToolStripMenuItem_Click);
            // 
            // customerListToolStripMenuItem
            // 
            this.customerListToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.byGroupToolStripMenuItem,
            this.byTypeToolStripMenuItem,
            this.byEPZToolStripMenuItem,
            this.subIdenticalToolStripMenuItem,
            this.industrySummaryToolStripMenuItem,
            this.outstandingCreditToolStripMenuItem});
            this.customerListToolStripMenuItem.Name = "customerListToolStripMenuItem";
            this.customerListToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.customerListToolStripMenuItem.Text = "Customer List";
            // 
            // byGroupToolStripMenuItem
            // 
            this.byGroupToolStripMenuItem.Name = "byGroupToolStripMenuItem";
            this.byGroupToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.byGroupToolStripMenuItem.Text = "by Group";
            this.byGroupToolStripMenuItem.Click += new System.EventHandler(this.byGroupToolStripMenuItem_Click);
            // 
            // byTypeToolStripMenuItem
            // 
            this.byTypeToolStripMenuItem.Name = "byTypeToolStripMenuItem";
            this.byTypeToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.byTypeToolStripMenuItem.Text = "by Type";
            this.byTypeToolStripMenuItem.Click += new System.EventHandler(this.byTypeToolStripMenuItem_Click);
            // 
            // byEPZToolStripMenuItem
            // 
            this.byEPZToolStripMenuItem.Name = "byEPZToolStripMenuItem";
            this.byEPZToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.byEPZToolStripMenuItem.Text = "EPZ";
            this.byEPZToolStripMenuItem.Click += new System.EventHandler(this.byEPZToolStripMenuItem_Click);
            // 
            // subIdenticalToolStripMenuItem
            // 
            this.subIdenticalToolStripMenuItem.Name = "subIdenticalToolStripMenuItem";
            this.subIdenticalToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.subIdenticalToolStripMenuItem.Text = "Sub Identical";
            this.subIdenticalToolStripMenuItem.Click += new System.EventHandler(this.subIdenticalToolStripMenuItem_Click);
            // 
            // industrySummaryToolStripMenuItem
            // 
            this.industrySummaryToolStripMenuItem.Name = "industrySummaryToolStripMenuItem";
            this.industrySummaryToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.industrySummaryToolStripMenuItem.Text = "Industry Summary";
            this.industrySummaryToolStripMenuItem.Click += new System.EventHandler(this.industrySummaryToolStripMenuItem_Click);
            // 
            // outstandingCreditToolStripMenuItem
            // 
            this.outstandingCreditToolStripMenuItem.Name = "outstandingCreditToolStripMenuItem";
            this.outstandingCreditToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.outstandingCreditToolStripMenuItem.Text = "Outstanding Credit";
            this.outstandingCreditToolStripMenuItem.Click += new System.EventHandler(this.outstandingCreditToolStripMenuItem_Click);
            // 
            // newCustomerQueryToolStripMenuItem
            // 
            this.newCustomerQueryToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.newCustomerQueryToolStripMenuItem.Name = "newCustomerQueryToolStripMenuItem";
            this.newCustomerQueryToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.newCustomerQueryToolStripMenuItem.Text = "New Customer Query";
            this.newCustomerQueryToolStripMenuItem.Click += new System.EventHandler(this.newCustomerQueryToolStripMenuItem_Click);
            // 
            // creditAppToolStripMenuItem
            // 
            this.creditAppToolStripMenuItem.Name = "creditAppToolStripMenuItem";
            this.creditAppToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.creditAppToolStripMenuItem.Text = "Credit Application Expiry in 3M";
            this.creditAppToolStripMenuItem.Click += new System.EventHandler(this.creditAppToolStripMenuItem_Click);
            // 
            // rPTCreditOutstandingByDiscretionToolStripMenuItem
            // 
            this.rPTCreditOutstandingByDiscretionToolStripMenuItem.Name = "rPTCreditOutstandingByDiscretionToolStripMenuItem";
            this.rPTCreditOutstandingByDiscretionToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.rPTCreditOutstandingByDiscretionToolStripMenuItem.Text = "Credit Outstanding by Discretion";
            this.rPTCreditOutstandingByDiscretionToolStripMenuItem.Click += new System.EventHandler(this.rPTCreditOutstandingByDiscretionToolStripMenuItem_Click);
            // 
            // controllingBookToolStripMenuItem
            // 
            this.controllingBookToolStripMenuItem.Name = "controllingBookToolStripMenuItem";
            this.controllingBookToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.controllingBookToolStripMenuItem.Text = "Controlling Book";
            this.controllingBookToolStripMenuItem.Click += new System.EventHandler(this.controllingBookToolStripMenuItem_Click);
            // 
            // controllingPendingItemsToolStripMenuItem
            // 
            this.controllingPendingItemsToolStripMenuItem.Name = "controllingPendingItemsToolStripMenuItem";
            this.controllingPendingItemsToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.controllingPendingItemsToolStripMenuItem.Text = "Controlling Pending Items";
            this.controllingPendingItemsToolStripMenuItem.Click += new System.EventHandler(this.controllingPendingItemsToolStripMenuItem_Click);
            // 
            // agentTransactionToolStripMenuItem
            // 
            this.agentTransactionToolStripMenuItem.Name = "agentTransactionToolStripMenuItem";
            this.agentTransactionToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.agentTransactionToolStripMenuItem.Text = "Agent transaction";
            this.agentTransactionToolStripMenuItem.Click += new System.EventHandler(this.agentTransactionToolStripMenuItem_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(167, 6);
            // 
            // irregularHandlingToolStripMenuItem
            // 
            this.irregularHandlingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newIrregularToolStripMenuItem,
            this.noApprovalIrreglarToolStripMenuItem,
            this.closeIrregularToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.reviewIrregularToolStripMenuItem,
            this.allIrregularToolStripMenuItem,
            this.editIrregularToolStripMenuItem,
            this.toolStripSeparator10,
            this.groupToolStripMenuItem,
            this.toolStripSeparator18,
            this.accountServicesToolStripMenuItem,
            this.domesticRemittanceToolStripMenuItem,
            this.foreignRemittanceToolStripMenuItem,
            this.importExporotToolStripMenuItem,
            this.exportServiceToolStripMenuItem,
            this.guaranteeToolStripMenuItem,
            this.checksAndTCToolStripMenuItem,
            this.otherServiceToolStripMenuItem});
            this.irregularHandlingToolStripMenuItem.Name = "irregularHandlingToolStripMenuItem";
            this.irregularHandlingToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.irregularHandlingToolStripMenuItem.Text = "Irregular Handling";
            // 
            // newIrregularToolStripMenuItem
            // 
            this.newIrregularToolStripMenuItem.Name = "newIrregularToolStripMenuItem";
            this.newIrregularToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.newIrregularToolStripMenuItem.Text = "New Irregular";
            this.newIrregularToolStripMenuItem.Click += new System.EventHandler(this.newIrregularToolStripMenuItem_Click);
            // 
            // noApprovalIrreglarToolStripMenuItem
            // 
            this.noApprovalIrreglarToolStripMenuItem.Name = "noApprovalIrreglarToolStripMenuItem";
            this.noApprovalIrreglarToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.noApprovalIrreglarToolStripMenuItem.Text = "Not Yet Approved Irregular";
            this.noApprovalIrreglarToolStripMenuItem.Click += new System.EventHandler(this.noApprovalIrreglarToolStripMenuItem_Click);
            // 
            // closeIrregularToolStripMenuItem
            // 
            this.closeIrregularToolStripMenuItem.Name = "closeIrregularToolStripMenuItem";
            this.closeIrregularToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.closeIrregularToolStripMenuItem.Text = "Close Irregular";
            this.closeIrregularToolStripMenuItem.Click += new System.EventHandler(this.closeIrregularToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.viewToolStripMenuItem.Text = "View Current Irregular";
            this.viewToolStripMenuItem.Click += new System.EventHandler(this.viewToolStripMenuItem_Click);
            // 
            // reviewIrregularToolStripMenuItem
            // 
            this.reviewIrregularToolStripMenuItem.Name = "reviewIrregularToolStripMenuItem";
            this.reviewIrregularToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.reviewIrregularToolStripMenuItem.Text = "Review Irregular";
            this.reviewIrregularToolStripMenuItem.Click += new System.EventHandler(this.reviewIrregularToolStripMenuItem_Click);
            // 
            // allIrregularToolStripMenuItem
            // 
            this.allIrregularToolStripMenuItem.Name = "allIrregularToolStripMenuItem";
            this.allIrregularToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.allIrregularToolStripMenuItem.Text = "View All Irregular";
            this.allIrregularToolStripMenuItem.Click += new System.EventHandler(this.allIrregularToolStripMenuItem_Click);
            // 
            // editIrregularToolStripMenuItem
            // 
            this.editIrregularToolStripMenuItem.Name = "editIrregularToolStripMenuItem";
            this.editIrregularToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.editIrregularToolStripMenuItem.Text = "Edit Irregular";
            this.editIrregularToolStripMenuItem.Click += new System.EventHandler(this.editIrregularToolStripMenuItem_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(213, 6);
            // 
            // groupToolStripMenuItem
            // 
            this.groupToolStripMenuItem.Name = "groupToolStripMenuItem";
            this.groupToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.groupToolStripMenuItem.Text = "Group";
            this.groupToolStripMenuItem.Click += new System.EventHandler(this.groupToolStripMenuItem_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(213, 6);
            // 
            // accountServicesToolStripMenuItem
            // 
            this.accountServicesToolStripMenuItem.Name = "accountServicesToolStripMenuItem";
            this.accountServicesToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.accountServicesToolStripMenuItem.Text = "Account Services";
            this.accountServicesToolStripMenuItem.Click += new System.EventHandler(this.accountServicesToolStripMenuItem_Click);
            // 
            // domesticRemittanceToolStripMenuItem
            // 
            this.domesticRemittanceToolStripMenuItem.Name = "domesticRemittanceToolStripMenuItem";
            this.domesticRemittanceToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.domesticRemittanceToolStripMenuItem.Text = "Domestic Remittance";
            this.domesticRemittanceToolStripMenuItem.Click += new System.EventHandler(this.domesticRemittanceToolStripMenuItem_Click);
            // 
            // foreignRemittanceToolStripMenuItem
            // 
            this.foreignRemittanceToolStripMenuItem.Name = "foreignRemittanceToolStripMenuItem";
            this.foreignRemittanceToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.foreignRemittanceToolStripMenuItem.Text = "Foreign Remittance";
            this.foreignRemittanceToolStripMenuItem.Click += new System.EventHandler(this.foreignRemittanceToolStripMenuItem_Click);
            // 
            // importExporotToolStripMenuItem
            // 
            this.importExporotToolStripMenuItem.Name = "importExporotToolStripMenuItem";
            this.importExporotToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.importExporotToolStripMenuItem.Text = "Import Service";
            this.importExporotToolStripMenuItem.Click += new System.EventHandler(this.importExporotToolStripMenuItem_Click);
            // 
            // exportServiceToolStripMenuItem
            // 
            this.exportServiceToolStripMenuItem.Name = "exportServiceToolStripMenuItem";
            this.exportServiceToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.exportServiceToolStripMenuItem.Text = "Export Service";
            this.exportServiceToolStripMenuItem.Click += new System.EventHandler(this.exportServiceToolStripMenuItem_Click);
            // 
            // guaranteeToolStripMenuItem
            // 
            this.guaranteeToolStripMenuItem.Name = "guaranteeToolStripMenuItem";
            this.guaranteeToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.guaranteeToolStripMenuItem.Text = "Guarantee";
            this.guaranteeToolStripMenuItem.Click += new System.EventHandler(this.guaranteeToolStripMenuItem_Click);
            // 
            // checksAndTCToolStripMenuItem
            // 
            this.checksAndTCToolStripMenuItem.Name = "checksAndTCToolStripMenuItem";
            this.checksAndTCToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.checksAndTCToolStripMenuItem.Text = "Checks and TC";
            this.checksAndTCToolStripMenuItem.Click += new System.EventHandler(this.checksAndTCToolStripMenuItem_Click);
            // 
            // otherServiceToolStripMenuItem
            // 
            this.otherServiceToolStripMenuItem.Name = "otherServiceToolStripMenuItem";
            this.otherServiceToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.otherServiceToolStripMenuItem.Text = "Other Services";
            this.otherServiceToolStripMenuItem.Click += new System.EventHandler(this.otherServiceToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem3
            // 
            this.reportToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.forJPCustomersToolStripMenuItem,
            this.forNonJPCustomersToolStripMenuItem,
            this.irregularHandlingForToolStripMenuItem});
            this.reportToolStripMenuItem3.Name = "reportToolStripMenuItem3";
            this.reportToolStripMenuItem3.Size = new System.Drawing.Size(170, 22);
            this.reportToolStripMenuItem3.Text = "Report";
            this.reportToolStripMenuItem3.Click += new System.EventHandler(this.reportToolStripMenuItem3_Click);
            // 
            // forJPCustomersToolStripMenuItem
            // 
            this.forJPCustomersToolStripMenuItem.Name = "forJPCustomersToolStripMenuItem";
            this.forJPCustomersToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.forJPCustomersToolStripMenuItem.Text = "For JP Customers";
            this.forJPCustomersToolStripMenuItem.Click += new System.EventHandler(this.forJPCustomersToolStripMenuItem_Click);
            // 
            // forNonJPCustomersToolStripMenuItem
            // 
            this.forNonJPCustomersToolStripMenuItem.Name = "forNonJPCustomersToolStripMenuItem";
            this.forNonJPCustomersToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.forNonJPCustomersToolStripMenuItem.Text = "For Non JP Customers";
            this.forNonJPCustomersToolStripMenuItem.Click += new System.EventHandler(this.forNonJPCustomersToolStripMenuItem_Click);
            // 
            // irregularHandlingForToolStripMenuItem
            // 
            this.irregularHandlingForToolStripMenuItem.Name = "irregularHandlingForToolStripMenuItem";
            this.irregularHandlingForToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.irregularHandlingForToolStripMenuItem.Text = "Irregular of All Customers  for Review";
            this.irregularHandlingForToolStripMenuItem.Click += new System.EventHandler(this.irregularHandlingForToolStripMenuItem_Click);
            // 
            // confirmationToolStripMenuItem
            // 
            this.confirmationToolStripMenuItem.Name = "confirmationToolStripMenuItem";
            this.confirmationToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.confirmationToolStripMenuItem.Text = "Confirmation";
            this.confirmationToolStripMenuItem.Click += new System.EventHandler(this.confirmationToolStripMenuItem_Click_1);
            // 
            // cMSTeamToolStripMenuItem
            // 
            this.cMSTeamToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manageGCMSCustomerToolStripMenuItem,
            this.makingDebitIntructionToolStripMenuItem,
            this.makingReportToolStripMenuItem,
            this.holidaysConfigurationToolStripMenuItem});
            this.cMSTeamToolStripMenuItem.Name = "cMSTeamToolStripMenuItem";
            this.cMSTeamToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.cMSTeamToolStripMenuItem.Text = "GCMS fee";
            this.cMSTeamToolStripMenuItem.Visible = false;
            // 
            // manageGCMSCustomerToolStripMenuItem
            // 
            this.manageGCMSCustomerToolStripMenuItem.Name = "manageGCMSCustomerToolStripMenuItem";
            this.manageGCMSCustomerToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.manageGCMSCustomerToolStripMenuItem.Text = "Manage GCMS customer";
            this.manageGCMSCustomerToolStripMenuItem.Click += new System.EventHandler(this.manageGCMSCustomerToolStripMenuItem_Click);
            // 
            // makingDebitIntructionToolStripMenuItem
            // 
            this.makingDebitIntructionToolStripMenuItem.Name = "makingDebitIntructionToolStripMenuItem";
            this.makingDebitIntructionToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.makingDebitIntructionToolStripMenuItem.Text = "Making Debit Intruction";
            this.makingDebitIntructionToolStripMenuItem.Click += new System.EventHandler(this.makingDebitIntructionToolStripMenuItem_Click);
            // 
            // makingReportToolStripMenuItem
            // 
            this.makingReportToolStripMenuItem.Name = "makingReportToolStripMenuItem";
            this.makingReportToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.makingReportToolStripMenuItem.Text = "Making report";
            this.makingReportToolStripMenuItem.Click += new System.EventHandler(this.makingReportToolStripMenuItem_Click);
            // 
            // holidaysConfigurationToolStripMenuItem
            // 
            this.holidaysConfigurationToolStripMenuItem.Name = "holidaysConfigurationToolStripMenuItem";
            this.holidaysConfigurationToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.holidaysConfigurationToolStripMenuItem.Text = "Holiday Configuration";
            this.holidaysConfigurationToolStripMenuItem.Click += new System.EventHandler(this.holidaysConfigurationToolStripMenuItem_Click);
            // 
            // backOfficeToolStripMenuItem
            // 
            this.backOfficeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputToolStripMenuItem2,
            this.reportToolStripMenuItem2});
            this.backOfficeToolStripMenuItem.Name = "backOfficeToolStripMenuItem";
            this.backOfficeToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.backOfficeToolStripMenuItem.Text = "Back Office";
            this.backOfficeToolStripMenuItem.Visible = false;
            // 
            // inputToolStripMenuItem2
            // 
            this.inputToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loanToolStripMenuItem,
            this.loanSTANDARDSMILEToolStripMenuItem,
            this.fXConfirmationToolStripMenuItem});
            this.inputToolStripMenuItem2.Name = "inputToolStripMenuItem2";
            this.inputToolStripMenuItem2.Size = new System.Drawing.Size(109, 22);
            this.inputToolStripMenuItem2.Text = "Input";
            // 
            // loanToolStripMenuItem
            // 
            this.loanToolStripMenuItem.Name = "loanToolStripMenuItem";
            this.loanToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.loanToolStripMenuItem.Text = "Loan";
            this.loanToolStripMenuItem.Click += new System.EventHandler(this.loanToolStripMenuItem_Click);
            // 
            // loanSTANDARDSMILEToolStripMenuItem
            // 
            this.loanSTANDARDSMILEToolStripMenuItem.Name = "loanSTANDARDSMILEToolStripMenuItem";
            this.loanSTANDARDSMILEToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.loanSTANDARDSMILEToolStripMenuItem.Text = "Loan (STANDARD SMILE)";
            this.loanSTANDARDSMILEToolStripMenuItem.Click += new System.EventHandler(this.loanSTANDARDSMILEToolStripMenuItem_Click);
            // 
            // fXConfirmationToolStripMenuItem
            // 
            this.fXConfirmationToolStripMenuItem.Name = "fXConfirmationToolStripMenuItem";
            this.fXConfirmationToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.fXConfirmationToolStripMenuItem.Text = "FX Confirmation";
            this.fXConfirmationToolStripMenuItem.Click += new System.EventHandler(this.fXConfirmationToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem2
            // 
            this.reportToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportDisbursementToolStripMenuItem,
            this.reportDueDateNoticeToolStripMenuItem,
            this.exportToExcelToolStripMenuItem,
            this.subsidiaryInterestRateToolStripMenuItem,
            this.subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem});
            this.reportToolStripMenuItem2.Name = "reportToolStripMenuItem2";
            this.reportToolStripMenuItem2.Size = new System.Drawing.Size(109, 22);
            this.reportToolStripMenuItem2.Text = "Report";
            // 
            // reportDisbursementToolStripMenuItem
            // 
            this.reportDisbursementToolStripMenuItem.Name = "reportDisbursementToolStripMenuItem";
            this.reportDisbursementToolStripMenuItem.Size = new System.Drawing.Size(303, 22);
            this.reportDisbursementToolStripMenuItem.Text = "Report Disbursement";
            this.reportDisbursementToolStripMenuItem.Visible = false;
            this.reportDisbursementToolStripMenuItem.Click += new System.EventHandler(this.reportDisbursementToolStripMenuItem_Click);
            // 
            // reportDueDateNoticeToolStripMenuItem
            // 
            this.reportDueDateNoticeToolStripMenuItem.Name = "reportDueDateNoticeToolStripMenuItem";
            this.reportDueDateNoticeToolStripMenuItem.Size = new System.Drawing.Size(303, 22);
            this.reportDueDateNoticeToolStripMenuItem.Text = "Report Due Date Notice";
            this.reportDueDateNoticeToolStripMenuItem.Visible = false;
            this.reportDueDateNoticeToolStripMenuItem.Click += new System.EventHandler(this.reportDueDateNoticeToolStripMenuItem_Click);
            // 
            // exportToExcelToolStripMenuItem
            // 
            this.exportToExcelToolStripMenuItem.Name = "exportToExcelToolStripMenuItem";
            this.exportToExcelToolStripMenuItem.Size = new System.Drawing.Size(303, 22);
            this.exportToExcelToolStripMenuItem.Text = "Export to Excel";
            this.exportToExcelToolStripMenuItem.Visible = false;
            this.exportToExcelToolStripMenuItem.Click += new System.EventHandler(this.exportToExcelToolStripMenuItem_Click);
            // 
            // subsidiaryInterestRateToolStripMenuItem
            // 
            this.subsidiaryInterestRateToolStripMenuItem.Name = "subsidiaryInterestRateToolStripMenuItem";
            this.subsidiaryInterestRateToolStripMenuItem.Size = new System.Drawing.Size(303, 22);
            this.subsidiaryInterestRateToolStripMenuItem.Text = "Subsidiary Interest Rate";
            this.subsidiaryInterestRateToolStripMenuItem.Click += new System.EventHandler(this.subsidiaryInterestRateToolStripMenuItem_Click);
            // 
            // subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem
            // 
            this.subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem.Name = "subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem";
            this.subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem.Size = new System.Drawing.Size(303, 22);
            this.subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem.Text = "Subsidiary Interest Rate (STANDARD SMILE)";
            this.subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem.Visible = false;
            this.subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem.Click += new System.EventHandler(this.subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem_Click);
            // 
            // tsMDMainMenu
            // 
            this.tsMDMainMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMDQuotation,
            this.tsMDDayOffRegist,
            this.tsMDCeilingFloor,
            this.tsMDThreshold,
            this.tsbProcessingBoardRateMaker,
            this.tsbProcessingBoardRateApprover,
            this.tsbInquiryBoardRateHistory,
            this.tsbCurrencyInquiryBoardRateHistory,
            this.tsbPreviewBRsTemplate,
            this.sBVMinMaxToolStripMenuItem,
            this.prefixTDNoToolStripMenuItem,
            this.defaultRateToolStripMenuItem});
            this.tsMDMainMenu.Name = "tsMDMainMenu";
            this.tsMDMainMenu.Size = new System.Drawing.Size(38, 20);
            this.tsMDMainMenu.Text = "MD";
            // 
            // tsMDQuotation
            // 
            this.tsMDQuotation.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMDImportQuotation,
            this.tsMDPreviewQuotationTemplate,
            this.tsMDProcessingDailyQuotationMaker,
            this.tsMDProcessingDailyQuotationApprover,
            this.tsMDCurrencyInquiryQuotationHistory,
            this.tsMDInquiryQuotationHistory});
            this.tsMDQuotation.Name = "tsMDQuotation";
            this.tsMDQuotation.Size = new System.Drawing.Size(263, 22);
            this.tsMDQuotation.Text = "Quotation";
            // 
            // tsMDImportQuotation
            // 
            this.tsMDImportQuotation.Name = "tsMDImportQuotation";
            this.tsMDImportQuotation.Size = new System.Drawing.Size(277, 22);
            this.tsMDImportQuotation.Text = "Import Quotation";
            this.tsMDImportQuotation.Click += new System.EventHandler(this.importQuotationToolStripMenuItem1_Click);
            // 
            // tsMDPreviewQuotationTemplate
            // 
            this.tsMDPreviewQuotationTemplate.Name = "tsMDPreviewQuotationTemplate";
            this.tsMDPreviewQuotationTemplate.Size = new System.Drawing.Size(277, 22);
            this.tsMDPreviewQuotationTemplate.Text = "Preview Quotation Template";
            this.tsMDPreviewQuotationTemplate.Click += new System.EventHandler(this.previewQuotationTemplateToolStripMenuItem1_Click);
            // 
            // tsMDProcessingDailyQuotationMaker
            // 
            this.tsMDProcessingDailyQuotationMaker.Name = "tsMDProcessingDailyQuotationMaker";
            this.tsMDProcessingDailyQuotationMaker.Size = new System.Drawing.Size(277, 22);
            this.tsMDProcessingDailyQuotationMaker.Text = "Processing Daily Quotation (Maker)";
            this.tsMDProcessingDailyQuotationMaker.Click += new System.EventHandler(this.processingDailyQuotationMakerToolStripMenuItem_Click);
            // 
            // tsMDProcessingDailyQuotationApprover
            // 
            this.tsMDProcessingDailyQuotationApprover.Name = "tsMDProcessingDailyQuotationApprover";
            this.tsMDProcessingDailyQuotationApprover.Size = new System.Drawing.Size(277, 22);
            this.tsMDProcessingDailyQuotationApprover.Text = "Processing Daily Quotation (Approver)";
            this.tsMDProcessingDailyQuotationApprover.Click += new System.EventHandler(this.processingDailToolStripMenuItem_Click);
            // 
            // tsMDCurrencyInquiryQuotationHistory
            // 
            this.tsMDCurrencyInquiryQuotationHistory.Name = "tsMDCurrencyInquiryQuotationHistory";
            this.tsMDCurrencyInquiryQuotationHistory.Size = new System.Drawing.Size(277, 22);
            this.tsMDCurrencyInquiryQuotationHistory.Text = "Currency Inquiry Quotation History";
            this.tsMDCurrencyInquiryQuotationHistory.Click += new System.EventHandler(this.currencyInToolStripMenuItem_Click);
            // 
            // tsMDInquiryQuotationHistory
            // 
            this.tsMDInquiryQuotationHistory.Name = "tsMDInquiryQuotationHistory";
            this.tsMDInquiryQuotationHistory.Size = new System.Drawing.Size(277, 22);
            this.tsMDInquiryQuotationHistory.Text = "Inquiry Quotation History";
            this.tsMDInquiryQuotationHistory.Click += new System.EventHandler(this.inquiryQuotationHistoryToolStripMenuItem1_Click);
            // 
            // tsMDDayOffRegist
            // 
            this.tsMDDayOffRegist.Name = "tsMDDayOffRegist";
            this.tsMDDayOffRegist.Size = new System.Drawing.Size(263, 22);
            this.tsMDDayOffRegist.Text = "Day Off Regist";
            this.tsMDDayOffRegist.Click += new System.EventHandler(this.dayOffRegistToolStripMenuItem_Click);
            // 
            // tsMDCeilingFloor
            // 
            this.tsMDCeilingFloor.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMDCreateCeilingFloor,
            this.tsMDListCeilingFloor});
            this.tsMDCeilingFloor.Name = "tsMDCeilingFloor";
            this.tsMDCeilingFloor.Size = new System.Drawing.Size(263, 22);
            this.tsMDCeilingFloor.Text = "Ceiling Floor";
            // 
            // tsMDCreateCeilingFloor
            // 
            this.tsMDCreateCeilingFloor.Name = "tsMDCreateCeilingFloor";
            this.tsMDCreateCeilingFloor.Size = new System.Drawing.Size(178, 22);
            this.tsMDCreateCeilingFloor.Text = "Create Ceiling Floor";
            this.tsMDCreateCeilingFloor.Click += new System.EventHandler(this.createCeilingFloorToolStripMenuItem_Click);
            // 
            // tsMDListCeilingFloor
            // 
            this.tsMDListCeilingFloor.Name = "tsMDListCeilingFloor";
            this.tsMDListCeilingFloor.Size = new System.Drawing.Size(178, 22);
            this.tsMDListCeilingFloor.Text = "List Ceiling Floor";
            this.tsMDListCeilingFloor.Click += new System.EventHandler(this.listCeilingFloorToolStripMenuItem_Click);
            // 
            // tsMDThreshold
            // 
            this.tsMDThreshold.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMDCreateThreshold,
            this.tsMDListThreshold});
            this.tsMDThreshold.Name = "tsMDThreshold";
            this.tsMDThreshold.Size = new System.Drawing.Size(263, 22);
            this.tsMDThreshold.Text = "Threshold";
            // 
            // tsMDCreateThreshold
            // 
            this.tsMDCreateThreshold.Name = "tsMDCreateThreshold";
            this.tsMDCreateThreshold.Size = new System.Drawing.Size(164, 22);
            this.tsMDCreateThreshold.Text = "Create Threshold";
            this.tsMDCreateThreshold.Click += new System.EventHandler(this.createToolStripMenuItem_Click);
            // 
            // tsMDListThreshold
            // 
            this.tsMDListThreshold.Name = "tsMDListThreshold";
            this.tsMDListThreshold.Size = new System.Drawing.Size(164, 22);
            this.tsMDListThreshold.Text = "List Threshold";
            this.tsMDListThreshold.Click += new System.EventHandler(this.listThresholdToolStripMenuItem_Click);
            // 
            // tsbProcessingBoardRateMaker
            // 
            this.tsbProcessingBoardRateMaker.Name = "tsbProcessingBoardRateMaker";
            this.tsbProcessingBoardRateMaker.Size = new System.Drawing.Size(263, 22);
            this.tsbProcessingBoardRateMaker.Text = "Processing Board Rate (Maker)";
            this.tsbProcessingBoardRateMaker.Click += new System.EventHandler(this.tsbProcessingBoardRateMaker_Click);
            // 
            // tsbProcessingBoardRateApprover
            // 
            this.tsbProcessingBoardRateApprover.Name = "tsbProcessingBoardRateApprover";
            this.tsbProcessingBoardRateApprover.Size = new System.Drawing.Size(263, 22);
            this.tsbProcessingBoardRateApprover.Text = "Processing Board Rate (Approver)";
            this.tsbProcessingBoardRateApprover.Click += new System.EventHandler(this.tsbProcessingBoardRateApprover_Click);
            // 
            // tsbInquiryBoardRateHistory
            // 
            this.tsbInquiryBoardRateHistory.Name = "tsbInquiryBoardRateHistory";
            this.tsbInquiryBoardRateHistory.Size = new System.Drawing.Size(263, 22);
            this.tsbInquiryBoardRateHistory.Text = "Inquiry Board Rate History";
            this.tsbInquiryBoardRateHistory.Click += new System.EventHandler(this.tsbInquiryBoardRateHistory_Click);
            // 
            // tsbCurrencyInquiryBoardRateHistory
            // 
            this.tsbCurrencyInquiryBoardRateHistory.Name = "tsbCurrencyInquiryBoardRateHistory";
            this.tsbCurrencyInquiryBoardRateHistory.Size = new System.Drawing.Size(263, 22);
            this.tsbCurrencyInquiryBoardRateHistory.Text = "Currency Inquiry Board Rate History";
            this.tsbCurrencyInquiryBoardRateHistory.Click += new System.EventHandler(this.tsbCurrencyInquiryBoardRateHistory_Click);
            // 
            // tsbPreviewBRsTemplate
            // 
            this.tsbPreviewBRsTemplate.Name = "tsbPreviewBRsTemplate";
            this.tsbPreviewBRsTemplate.Size = new System.Drawing.Size(263, 22);
            this.tsbPreviewBRsTemplate.Text = "Preview BR�fs template";
            this.tsbPreviewBRsTemplate.Click += new System.EventHandler(this.tsbPreviewBRsTemplate_Click);
            // 
            // sBVMinMaxToolStripMenuItem
            // 
            this.sBVMinMaxToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createSBVMInMaxToolStripMenuItem,
            this.listSBVMinMaxToolStripMenuItem});
            this.sBVMinMaxToolStripMenuItem.Name = "sBVMinMaxToolStripMenuItem";
            this.sBVMinMaxToolStripMenuItem.Size = new System.Drawing.Size(263, 22);
            this.sBVMinMaxToolStripMenuItem.Text = "SBV Min Max";
            // 
            // createSBVMInMaxToolStripMenuItem
            // 
            this.createSBVMInMaxToolStripMenuItem.Name = "createSBVMInMaxToolStripMenuItem";
            this.createSBVMInMaxToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.createSBVMInMaxToolStripMenuItem.Text = "Create SBV Min Max";
            this.createSBVMInMaxToolStripMenuItem.Click += new System.EventHandler(this.createSBVMInMaxToolStripMenuItem_Click);
            // 
            // listSBVMinMaxToolStripMenuItem
            // 
            this.listSBVMinMaxToolStripMenuItem.Name = "listSBVMinMaxToolStripMenuItem";
            this.listSBVMinMaxToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listSBVMinMaxToolStripMenuItem.Text = "List SBV Min Max";
            this.listSBVMinMaxToolStripMenuItem.Click += new System.EventHandler(this.listSBVMinMaxToolStripMenuItem_Click);
            // 
            // prefixTDNoToolStripMenuItem
            // 
            this.prefixTDNoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createPrefixTDNoToolStripMenuItem,
            this.listPrefixTDNoToolStripMenuItem});
            this.prefixTDNoToolStripMenuItem.Name = "prefixTDNoToolStripMenuItem";
            this.prefixTDNoToolStripMenuItem.Size = new System.Drawing.Size(263, 22);
            this.prefixTDNoToolStripMenuItem.Text = "Prefix TD No.";
            // 
            // createPrefixTDNoToolStripMenuItem
            // 
            this.createPrefixTDNoToolStripMenuItem.Name = "createPrefixTDNoToolStripMenuItem";
            this.createPrefixTDNoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.createPrefixTDNoToolStripMenuItem.Text = "Create Prefix TD No.";
            this.createPrefixTDNoToolStripMenuItem.Click += new System.EventHandler(this.createPrefixTDNoToolStripMenuItem_Click);
            // 
            // listPrefixTDNoToolStripMenuItem
            // 
            this.listPrefixTDNoToolStripMenuItem.Name = "listPrefixTDNoToolStripMenuItem";
            this.listPrefixTDNoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listPrefixTDNoToolStripMenuItem.Text = "List Prefix TD No.";
            this.listPrefixTDNoToolStripMenuItem.Click += new System.EventHandler(this.listPrefixTDNoToolStripMenuItem_Click);
            // 
            // defaultRateToolStripMenuItem
            // 
            this.defaultRateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createDefaultRateToolStripMenuItem,
            this.listDefaultRateToolStripMenuItem});
            this.defaultRateToolStripMenuItem.Name = "defaultRateToolStripMenuItem";
            this.defaultRateToolStripMenuItem.Size = new System.Drawing.Size(263, 22);
            this.defaultRateToolStripMenuItem.Text = "Default Rate";
            // 
            // createDefaultRateToolStripMenuItem
            // 
            this.createDefaultRateToolStripMenuItem.Name = "createDefaultRateToolStripMenuItem";
            this.createDefaultRateToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.createDefaultRateToolStripMenuItem.Text = "Create Default Rate";
            this.createDefaultRateToolStripMenuItem.Click += new System.EventHandler(this.createDefaultRateToolStripMenuItem_Click);
            // 
            // listDefaultRateToolStripMenuItem
            // 
            this.listDefaultRateToolStripMenuItem.Name = "listDefaultRateToolStripMenuItem";
            this.listDefaultRateToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.listDefaultRateToolStripMenuItem.Text = "List Default Rate";
            this.listDefaultRateToolStripMenuItem.Click += new System.EventHandler(this.listDefaultRateToolStripMenuItem_Click);
            // 
            // middleOfficeToolStripMenuItem
            // 
            this.middleOfficeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerInformationToolStripMenuItem,
            this.credlitLineToolStripMenuItem,
            this.borrowRatingToolStripMenuItem,
            this.pendingItemForBRToolStripMenuItem,
            this.covenantToolStripMenuItem,
            this.toolStripSeparator20,
            this.monthlyReportToolStripMenuItem});
            this.middleOfficeToolStripMenuItem.Name = "middleOfficeToolStripMenuItem";
            this.middleOfficeToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.middleOfficeToolStripMenuItem.Text = "Middle Office";
            // 
            // customerInformationToolStripMenuItem
            // 
            this.customerInformationToolStripMenuItem.Name = "customerInformationToolStripMenuItem";
            this.customerInformationToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.customerInformationToolStripMenuItem.Text = "Customer Information";
            this.customerInformationToolStripMenuItem.Click += new System.EventHandler(this.customerInformationToolStripMenuItem_Click);
            // 
            // credlitLineToolStripMenuItem
            // 
            this.credlitLineToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.forCorporateToolStripMenuItem,
            this.forBankToolStripMenuItem,
            this.pendingItemToolStripMenuItem});
            this.credlitLineToolStripMenuItem.Name = "credlitLineToolStripMenuItem";
            this.credlitLineToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.credlitLineToolStripMenuItem.Text = "Credlit Line";
            // 
            // forCorporateToolStripMenuItem
            // 
            this.forCorporateToolStripMenuItem.Name = "forCorporateToolStripMenuItem";
            this.forCorporateToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.forCorporateToolStripMenuItem.Text = "For Corporate";
            this.forCorporateToolStripMenuItem.Click += new System.EventHandler(this.forCorporateToolStripMenuItem_Click);
            // 
            // forBankToolStripMenuItem
            // 
            this.forBankToolStripMenuItem.Name = "forBankToolStripMenuItem";
            this.forBankToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.forBankToolStripMenuItem.Text = "For Bank";
            this.forBankToolStripMenuItem.Click += new System.EventHandler(this.forBankToolStripMenuItem_Click);
            // 
            // pendingItemToolStripMenuItem
            // 
            this.pendingItemToolStripMenuItem.Name = "pendingItemToolStripMenuItem";
            this.pendingItemToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.pendingItemToolStripMenuItem.Text = "Pending Item";
            this.pendingItemToolStripMenuItem.Click += new System.EventHandler(this.pendingItemToolStripMenuItem_Click);
            // 
            // borrowRatingToolStripMenuItem
            // 
            this.borrowRatingToolStripMenuItem.Name = "borrowRatingToolStripMenuItem";
            this.borrowRatingToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.borrowRatingToolStripMenuItem.Text = "Borrow Rating";
            this.borrowRatingToolStripMenuItem.Click += new System.EventHandler(this.borrowRatingToolStripMenuItem_Click);
            // 
            // pendingItemForBRToolStripMenuItem
            // 
            this.pendingItemForBRToolStripMenuItem.Name = "pendingItemForBRToolStripMenuItem";
            this.pendingItemForBRToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.pendingItemForBRToolStripMenuItem.Text = "Pending Item for BR";
            this.pendingItemForBRToolStripMenuItem.Click += new System.EventHandler(this.pendingItemForBRToolStripMenuItem_Click);
            // 
            // covenantToolStripMenuItem
            // 
            this.covenantToolStripMenuItem.Name = "covenantToolStripMenuItem";
            this.covenantToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.covenantToolStripMenuItem.Text = "Covenant";
            this.covenantToolStripMenuItem.Click += new System.EventHandler(this.covenantToolStripMenuItem_Click);
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(189, 6);
            // 
            // monthlyReportToolStripMenuItem
            // 
            this.monthlyReportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.creditFacilityForCorporateToolStripMenuItem,
            this.creditFacilityForBankToolStripMenuItem,
            this.securityReportToolStripMenuItem,
            this.instructionConditionForCorporateToolStripMenuItem,
            this.instructionConditionForBankToolStripMenuItem,
            this.borrowerRatingToolStripMenuItem1,
            this.pendingItemREquesToolStripMenuItem,
            this.facilityReportToolStripMenuItem,
            this.maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem,
            this.overdueInstructionConditionForCorporateToolStripMenuItem});
            this.monthlyReportToolStripMenuItem.Name = "monthlyReportToolStripMenuItem";
            this.monthlyReportToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.monthlyReportToolStripMenuItem.Text = "Monthly Report";
            // 
            // creditFacilityForCorporateToolStripMenuItem
            // 
            this.creditFacilityForCorporateToolStripMenuItem.Name = "creditFacilityForCorporateToolStripMenuItem";
            this.creditFacilityForCorporateToolStripMenuItem.Size = new System.Drawing.Size(433, 22);
            this.creditFacilityForCorporateToolStripMenuItem.Text = "Credit Facility for Corporate";
            this.creditFacilityForCorporateToolStripMenuItem.Click += new System.EventHandler(this.creditFacilityForCorporateToolStripMenuItem_Click);
            // 
            // creditFacilityForBankToolStripMenuItem
            // 
            this.creditFacilityForBankToolStripMenuItem.Name = "creditFacilityForBankToolStripMenuItem";
            this.creditFacilityForBankToolStripMenuItem.Size = new System.Drawing.Size(433, 22);
            this.creditFacilityForBankToolStripMenuItem.Text = "Credit Facility for Bank";
            this.creditFacilityForBankToolStripMenuItem.Click += new System.EventHandler(this.creditFacilityForBankToolStripMenuItem_Click);
            // 
            // securityReportToolStripMenuItem
            // 
            this.securityReportToolStripMenuItem.Name = "securityReportToolStripMenuItem";
            this.securityReportToolStripMenuItem.Size = new System.Drawing.Size(433, 22);
            this.securityReportToolStripMenuItem.Text = "Security Report";
            this.securityReportToolStripMenuItem.Click += new System.EventHandler(this.securityReportToolStripMenuItem_Click);
            // 
            // instructionConditionForCorporateToolStripMenuItem
            // 
            this.instructionConditionForCorporateToolStripMenuItem.Name = "instructionConditionForCorporateToolStripMenuItem";
            this.instructionConditionForCorporateToolStripMenuItem.Size = new System.Drawing.Size(433, 22);
            this.instructionConditionForCorporateToolStripMenuItem.Text = "Instruction Condition for Corporate";
            this.instructionConditionForCorporateToolStripMenuItem.Click += new System.EventHandler(this.instructionConditionForCorporateToolStripMenuItem_Click);
            // 
            // instructionConditionForBankToolStripMenuItem
            // 
            this.instructionConditionForBankToolStripMenuItem.Name = "instructionConditionForBankToolStripMenuItem";
            this.instructionConditionForBankToolStripMenuItem.Size = new System.Drawing.Size(433, 22);
            this.instructionConditionForBankToolStripMenuItem.Text = "Instruction Condition for Bank";
            this.instructionConditionForBankToolStripMenuItem.Click += new System.EventHandler(this.instructionConditionForBankToolStripMenuItem_Click);
            // 
            // borrowerRatingToolStripMenuItem1
            // 
            this.borrowerRatingToolStripMenuItem1.Name = "borrowerRatingToolStripMenuItem1";
            this.borrowerRatingToolStripMenuItem1.Size = new System.Drawing.Size(433, 22);
            this.borrowerRatingToolStripMenuItem1.Text = "Borrower Rating";
            this.borrowerRatingToolStripMenuItem1.Click += new System.EventHandler(this.borrowerRatingToolStripMenuItem1_Click);
            // 
            // pendingItemREquesToolStripMenuItem
            // 
            this.pendingItemREquesToolStripMenuItem.Name = "pendingItemREquesToolStripMenuItem";
            this.pendingItemREquesToolStripMenuItem.Size = new System.Drawing.Size(433, 22);
            this.pendingItemREquesToolStripMenuItem.Text = "Pending Item - Request for Borrowing";
            this.pendingItemREquesToolStripMenuItem.Click += new System.EventHandler(this.pendingItemREquesToolStripMenuItem_Click);
            // 
            // facilityReportToolStripMenuItem
            // 
            this.facilityReportToolStripMenuItem.Name = "facilityReportToolStripMenuItem";
            this.facilityReportToolStripMenuItem.Size = new System.Drawing.Size(433, 22);
            this.facilityReportToolStripMenuItem.Text = "Facility Report";
            this.facilityReportToolStripMenuItem.Click += new System.EventHandler(this.facilityReportToolStripMenuItem_Click);
            // 
            // maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem
            // 
            this.maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem.Name = "maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem";
            this.maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem.Size = new System.Drawing.Size(433, 22);
            this.maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem.Text = "Maturity Control of Action Plan for Close Watch or Worse Borrowers";
            this.maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem.Click += new System.EventHandler(this.maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem_Click);
            // 
            // overdueInstructionConditionForCorporateToolStripMenuItem
            // 
            this.overdueInstructionConditionForCorporateToolStripMenuItem.Name = "overdueInstructionConditionForCorporateToolStripMenuItem";
            this.overdueInstructionConditionForCorporateToolStripMenuItem.Size = new System.Drawing.Size(433, 22);
            this.overdueInstructionConditionForCorporateToolStripMenuItem.Text = "Overdue Instruction Condition for Corporate";
            this.overdueInstructionConditionForCorporateToolStripMenuItem.Click += new System.EventHandler(this.overdueInstructionConditionForCorporateToolStripMenuItem_Click);
            // 
            // aCCToolStripMenuItem
            // 
            this.aCCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accumulativeToolStripMenuItem});
            this.aCCToolStripMenuItem.Name = "aCCToolStripMenuItem";
            this.aCCToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.aCCToolStripMenuItem.Text = "ACC";
            this.aCCToolStripMenuItem.Visible = false;
            // 
            // accumulativeToolStripMenuItem
            // 
            this.accumulativeToolStripMenuItem.Name = "accumulativeToolStripMenuItem";
            this.accumulativeToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.accumulativeToolStripMenuItem.Text = "Accumulative Subsidiary Interest Rate";
            this.accumulativeToolStripMenuItem.Click += new System.EventHandler(this.accumulativeToolStripMenuItem_Click);
            // 
            // iODToolStripMenuItem
            // 
            this.iODToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.irregularHandlingToolStripMenuItem1,
            this.toolStripSeparator13,
            this.toolStripMenuItem1,
            this.toolStripSeparator21,
            this.transactionsToolStripMenuItem});
            this.iODToolStripMenuItem.Name = "iODToolStripMenuItem";
            this.iODToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.iODToolStripMenuItem.Text = "IOD";
            this.iODToolStripMenuItem.Visible = false;
            // 
            // irregularHandlingToolStripMenuItem1
            // 
            this.irregularHandlingToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem1,
            this.toolStripSeparator11,
            this.groupToolStripMenuItem1,
            this.toolStripSeparator12,
            this.accountServicesToolStripMenuItem2,
            this.domesticRemittanceToolStripMenuItem2,
            this.foreignRemittanceToolStripMenuItem1,
            this.guaranteeToolStripMenuItem1,
            this.importServiceToolStripMenuItem,
            this.exportServiceToolStripMenuItem1,
            this.checksAndTCToolStripMenuItem1,
            this.otherServicesToolStripMenuItem});
            this.irregularHandlingToolStripMenuItem1.Name = "irregularHandlingToolStripMenuItem1";
            this.irregularHandlingToolStripMenuItem1.Size = new System.Drawing.Size(171, 22);
            this.irregularHandlingToolStripMenuItem1.Text = "Irregular Handling";
            // 
            // viewToolStripMenuItem1
            // 
            this.viewToolStripMenuItem1.Name = "viewToolStripMenuItem1";
            this.viewToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
            this.viewToolStripMenuItem1.Text = "View Irregular";
            this.viewToolStripMenuItem1.Click += new System.EventHandler(this.viewToolStripMenuItem1_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(184, 6);
            // 
            // groupToolStripMenuItem1
            // 
            this.groupToolStripMenuItem1.Name = "groupToolStripMenuItem1";
            this.groupToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
            this.groupToolStripMenuItem1.Text = "Group";
            this.groupToolStripMenuItem1.Click += new System.EventHandler(this.groupToolStripMenuItem1_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(184, 6);
            // 
            // accountServicesToolStripMenuItem2
            // 
            this.accountServicesToolStripMenuItem2.Name = "accountServicesToolStripMenuItem2";
            this.accountServicesToolStripMenuItem2.Size = new System.Drawing.Size(187, 22);
            this.accountServicesToolStripMenuItem2.Text = "Account Services";
            this.accountServicesToolStripMenuItem2.Click += new System.EventHandler(this.accountServicesToolStripMenuItem2_Click);
            // 
            // domesticRemittanceToolStripMenuItem2
            // 
            this.domesticRemittanceToolStripMenuItem2.Name = "domesticRemittanceToolStripMenuItem2";
            this.domesticRemittanceToolStripMenuItem2.Size = new System.Drawing.Size(187, 22);
            this.domesticRemittanceToolStripMenuItem2.Text = "Domestic Remittance";
            this.domesticRemittanceToolStripMenuItem2.Click += new System.EventHandler(this.domesticRemittanceToolStripMenuItem2_Click);
            // 
            // foreignRemittanceToolStripMenuItem1
            // 
            this.foreignRemittanceToolStripMenuItem1.Name = "foreignRemittanceToolStripMenuItem1";
            this.foreignRemittanceToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
            this.foreignRemittanceToolStripMenuItem1.Text = "Foreign Remittance";
            this.foreignRemittanceToolStripMenuItem1.Click += new System.EventHandler(this.foreignRemittanceToolStripMenuItem1_Click);
            // 
            // guaranteeToolStripMenuItem1
            // 
            this.guaranteeToolStripMenuItem1.Name = "guaranteeToolStripMenuItem1";
            this.guaranteeToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
            this.guaranteeToolStripMenuItem1.Text = "Guarantee";
            this.guaranteeToolStripMenuItem1.Click += new System.EventHandler(this.guaranteeToolStripMenuItem1_Click);
            // 
            // importServiceToolStripMenuItem
            // 
            this.importServiceToolStripMenuItem.Name = "importServiceToolStripMenuItem";
            this.importServiceToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.importServiceToolStripMenuItem.Text = "Import Service";
            this.importServiceToolStripMenuItem.Click += new System.EventHandler(this.importServiceToolStripMenuItem_Click);
            // 
            // exportServiceToolStripMenuItem1
            // 
            this.exportServiceToolStripMenuItem1.Name = "exportServiceToolStripMenuItem1";
            this.exportServiceToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
            this.exportServiceToolStripMenuItem1.Text = "Export Service";
            this.exportServiceToolStripMenuItem1.Click += new System.EventHandler(this.exportServiceToolStripMenuItem1_Click);
            // 
            // checksAndTCToolStripMenuItem1
            // 
            this.checksAndTCToolStripMenuItem1.Name = "checksAndTCToolStripMenuItem1";
            this.checksAndTCToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
            this.checksAndTCToolStripMenuItem1.Text = "Checks and TC";
            this.checksAndTCToolStripMenuItem1.Click += new System.EventHandler(this.checksAndTCToolStripMenuItem1_Click);
            // 
            // otherServicesToolStripMenuItem
            // 
            this.otherServicesToolStripMenuItem.Name = "otherServicesToolStripMenuItem";
            this.otherServicesToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.otherServicesToolStripMenuItem.Text = "Other Services";
            this.otherServicesToolStripMenuItem.Click += new System.EventHandler(this.otherServicesToolStripMenuItem_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(168, 6);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comfirmationToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(171, 22);
            this.toolStripMenuItem1.Text = "Authorized Person";
            // 
            // comfirmationToolStripMenuItem
            // 
            this.comfirmationToolStripMenuItem.Name = "comfirmationToolStripMenuItem";
            this.comfirmationToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.comfirmationToolStripMenuItem.Text = "Comfirmation";
            this.comfirmationToolStripMenuItem.Click += new System.EventHandler(this.comfirmationToolStripMenuItem_Click);
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(168, 6);
            // 
            // transactionsToolStripMenuItem
            // 
            this.transactionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manageTransactionsToolStripMenuItem,
            this.transaToolStripMenuItem,
            this.uploadTransactionsToolStripMenuItem,
            this.toolStripSeparator22,
            this.createStatementToolStripMenuItem,
            this.statementQueryToolStripMenuItem,
            this.makeTransactionReportToolStripMenuItem});
            this.transactionsToolStripMenuItem.Name = "transactionsToolStripMenuItem";
            this.transactionsToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.transactionsToolStripMenuItem.Text = "Transactions";
            // 
            // manageTransactionsToolStripMenuItem
            // 
            this.manageTransactionsToolStripMenuItem.Name = "manageTransactionsToolStripMenuItem";
            this.manageTransactionsToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.manageTransactionsToolStripMenuItem.Text = "Manage Transactions";
            this.manageTransactionsToolStripMenuItem.Click += new System.EventHandler(this.manageTransactionsToolStripMenuItem_Click);
            // 
            // transaToolStripMenuItem
            // 
            this.transaToolStripMenuItem.Name = "transaToolStripMenuItem";
            this.transaToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.transaToolStripMenuItem.Text = "Transaction Query";
            this.transaToolStripMenuItem.Click += new System.EventHandler(this.transaToolStripMenuItem_Click);
            // 
            // uploadTransactionsToolStripMenuItem
            // 
            this.uploadTransactionsToolStripMenuItem.Name = "uploadTransactionsToolStripMenuItem";
            this.uploadTransactionsToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.uploadTransactionsToolStripMenuItem.Text = "Upload Transactions";
            this.uploadTransactionsToolStripMenuItem.Click += new System.EventHandler(this.uploadTransactionsToolStripMenuItem_Click);
            // 
            // toolStripSeparator22
            // 
            this.toolStripSeparator22.Name = "toolStripSeparator22";
            this.toolStripSeparator22.Size = new System.Drawing.Size(203, 6);
            // 
            // createStatementToolStripMenuItem
            // 
            this.createStatementToolStripMenuItem.Name = "createStatementToolStripMenuItem";
            this.createStatementToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.createStatementToolStripMenuItem.Text = "Create/Update CD";
            this.createStatementToolStripMenuItem.Click += new System.EventHandler(this.createStatementToolStripMenuItem_Click);
            // 
            // statementQueryToolStripMenuItem
            // 
            this.statementQueryToolStripMenuItem.Name = "statementQueryToolStripMenuItem";
            this.statementQueryToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.statementQueryToolStripMenuItem.Text = "CD Searching";
            this.statementQueryToolStripMenuItem.Click += new System.EventHandler(this.statementQueryToolStripMenuItem_Click);
            // 
            // makeTransactionReportToolStripMenuItem
            // 
            this.makeTransactionReportToolStripMenuItem.Name = "makeTransactionReportToolStripMenuItem";
            this.makeTransactionReportToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.makeTransactionReportToolStripMenuItem.Text = "Make Transaction Report";
            this.makeTransactionReportToolStripMenuItem.Click += new System.EventHandler(this.makeTransactionReportToolStripMenuItem_Click);
            // 
            // dPDToolStripMenuItem
            // 
            this.dPDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem11,
            this.toolStripSeparator14,
            this.authorizedPersonToolStripMenuItem,
            this.toolStripSeparator19,
            this.uploadDataToolStripMenuItem});
            this.dPDToolStripMenuItem.Name = "dPDToolStripMenuItem";
            this.dPDToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.dPDToolStripMenuItem.Text = "DPD";
            this.dPDToolStripMenuItem.Visible = false;
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripSeparator16,
            this.toolStripMenuItem13,
            this.toolStripSeparator17,
            this.accountServicesToolStripMenuItem1,
            this.domesticRemittanceToolStripMenuItem1,
            this.toolStripMenuItem18,
            this.toolStripMenuItem15,
            this.toolStripMenuItem16,
            this.toolStripMenuItem14,
            this.toolStripMenuItem17,
            this.toolStripMenuItem19});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(171, 22);
            this.toolStripMenuItem11.Text = "Irregular Handling";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem12.Text = "View Irregular";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(184, 6);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem13.Text = "Group";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(184, 6);
            // 
            // accountServicesToolStripMenuItem1
            // 
            this.accountServicesToolStripMenuItem1.Name = "accountServicesToolStripMenuItem1";
            this.accountServicesToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
            this.accountServicesToolStripMenuItem1.Text = "Account Services";
            this.accountServicesToolStripMenuItem1.Click += new System.EventHandler(this.accountServicesToolStripMenuItem1_Click);
            // 
            // domesticRemittanceToolStripMenuItem1
            // 
            this.domesticRemittanceToolStripMenuItem1.Name = "domesticRemittanceToolStripMenuItem1";
            this.domesticRemittanceToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
            this.domesticRemittanceToolStripMenuItem1.Text = "Domestic Remittance";
            this.domesticRemittanceToolStripMenuItem1.Click += new System.EventHandler(this.domesticRemittanceToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem18.Text = "Foreign Remittance";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.toolStripMenuItem18_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem15.Text = "Import Service";
            this.toolStripMenuItem15.Click += new System.EventHandler(this.toolStripMenuItem15_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem16.Text = "Export Service";
            this.toolStripMenuItem16.Click += new System.EventHandler(this.toolStripMenuItem16_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem14.Text = "Guarantee";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem17.Text = "Checks and TC";
            this.toolStripMenuItem17.Click += new System.EventHandler(this.toolStripMenuItem17_Click);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem19.Text = "Other Services";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.toolStripMenuItem19_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(168, 6);
            // 
            // authorizedPersonToolStripMenuItem
            // 
            this.authorizedPersonToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.confirmationToolStripMenuItem1});
            this.authorizedPersonToolStripMenuItem.Name = "authorizedPersonToolStripMenuItem";
            this.authorizedPersonToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.authorizedPersonToolStripMenuItem.Text = "Authorized Person";
            // 
            // confirmationToolStripMenuItem1
            // 
            this.confirmationToolStripMenuItem1.Name = "confirmationToolStripMenuItem1";
            this.confirmationToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.confirmationToolStripMenuItem1.Text = "Confirmation";
            this.confirmationToolStripMenuItem1.Click += new System.EventHandler(this.confirmationToolStripMenuItem1_Click);
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(168, 6);
            // 
            // uploadDataToolStripMenuItem
            // 
            this.uploadDataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importAccountToolStripMenuItem1,
            this.importAddressToolStripMenuItem});
            this.uploadDataToolStripMenuItem.Name = "uploadDataToolStripMenuItem";
            this.uploadDataToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.uploadDataToolStripMenuItem.Text = "Upload Data";
            this.uploadDataToolStripMenuItem.Click += new System.EventHandler(this.uploadDataToolStripMenuItem_Click);
            // 
            // importAccountToolStripMenuItem1
            // 
            this.importAccountToolStripMenuItem1.Name = "importAccountToolStripMenuItem1";
            this.importAccountToolStripMenuItem1.Size = new System.Drawing.Size(158, 22);
            this.importAccountToolStripMenuItem1.Text = "Import Account";
            this.importAccountToolStripMenuItem1.Click += new System.EventHandler(this.importAccountToolStripMenuItem1_Click);
            // 
            // importAddressToolStripMenuItem
            // 
            this.importAddressToolStripMenuItem.Name = "importAddressToolStripMenuItem";
            this.importAddressToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.importAddressToolStripMenuItem.Text = "Import Address";
            this.importAddressToolStripMenuItem.Click += new System.EventHandler(this.importAddressToolStripMenuItem_Click);
            // 
            // treasuryToolStripMenuItem
            // 
            this.treasuryToolStripMenuItem.Name = "treasuryToolStripMenuItem";
            this.treasuryToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.treasuryToolStripMenuItem.Text = "Treasury";
            this.treasuryToolStripMenuItem.Visible = false;
            // 
            // administratorToolStripMenuItem
            // 
            this.administratorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userManagementToolStripMenuItem,
            this.userPermissionManagementToolStripMenuItem,
            this.databaseManagementToolStripMenuItem,
            this.customerCodeImportToolStripMenuItem});
            this.administratorToolStripMenuItem.Name = "administratorToolStripMenuItem";
            this.administratorToolStripMenuItem.Size = new System.Drawing.Size(92, 20);
            this.administratorToolStripMenuItem.Text = "Administrator";
            this.administratorToolStripMenuItem.Visible = false;
            // 
            // userManagementToolStripMenuItem
            // 
            this.userManagementToolStripMenuItem.Name = "userManagementToolStripMenuItem";
            this.userManagementToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.userManagementToolStripMenuItem.Text = "User Management";
            this.userManagementToolStripMenuItem.Click += new System.EventHandler(this.userManagementToolStripMenuItem_Click);
            // 
            // userPermissionManagementToolStripMenuItem
            // 
            this.userPermissionManagementToolStripMenuItem.Name = "userPermissionManagementToolStripMenuItem";
            this.userPermissionManagementToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.userPermissionManagementToolStripMenuItem.Text = "User Permission Management";
            this.userPermissionManagementToolStripMenuItem.Click += new System.EventHandler(this.userPermissionManagementToolStripMenuItem_Click);
            // 
            // databaseManagementToolStripMenuItem
            // 
            this.databaseManagementToolStripMenuItem.Name = "databaseManagementToolStripMenuItem";
            this.databaseManagementToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.databaseManagementToolStripMenuItem.Text = "Database Management";
            this.databaseManagementToolStripMenuItem.Click += new System.EventHandler(this.databaseManagementToolStripMenuItem_Click);
            // 
            // customerCodeImportToolStripMenuItem
            // 
            this.customerCodeImportToolStripMenuItem.Name = "customerCodeImportToolStripMenuItem";
            this.customerCodeImportToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.customerCodeImportToolStripMenuItem.Text = "Customer Code Import";
            this.customerCodeImportToolStripMenuItem.Click += new System.EventHandler(this.customerCodeImportToolStripMenuItem_Click);
            // 
            // tsCPAMainMenu
            // 
            this.tsCPAMainMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsCPAImportEDPList,
            this.tsCPACustomerErrorList,
            this.tsCPAFinalizeCPAData,
            this.tsCPAReports,
            this.tsCPACustomerCPA});
            this.tsCPAMainMenu.Name = "tsCPAMainMenu";
            this.tsCPAMainMenu.Size = new System.Drawing.Size(42, 20);
            this.tsCPAMainMenu.Text = "CPA";
            this.tsCPAMainMenu.Click += new System.EventHandler(this.toolStripMenuCPA_Click);
            // 
            // tsCPAImportEDPList
            // 
            this.tsCPAImportEDPList.Name = "tsCPAImportEDPList";
            this.tsCPAImportEDPList.Size = new System.Drawing.Size(175, 22);
            this.tsCPAImportEDPList.Text = "Import EDP List";
            this.tsCPAImportEDPList.Click += new System.EventHandler(this.importEDPListToolStripMenuItem_Click);
            // 
            // tsCPACustomerErrorList
            // 
            this.tsCPACustomerErrorList.Name = "tsCPACustomerErrorList";
            this.tsCPACustomerErrorList.Size = new System.Drawing.Size(175, 22);
            this.tsCPACustomerErrorList.Text = "Customer Error List";
            this.tsCPACustomerErrorList.Click += new System.EventHandler(this.customerErrorListToolStripMenuItem_Click);
            // 
            // tsCPAFinalizeCPAData
            // 
            this.tsCPAFinalizeCPAData.Name = "tsCPAFinalizeCPAData";
            this.tsCPAFinalizeCPAData.Size = new System.Drawing.Size(175, 22);
            this.tsCPAFinalizeCPAData.Text = "Finalize CPA Data";
            this.tsCPAFinalizeCPAData.Click += new System.EventHandler(this.finalizeCPADataToolStripMenuItem_Click);
            // 
            // tsCPAReports
            // 
            this.tsCPAReports.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsCPAQuaterlyHistoryOfProfit,
            this.tsCPAMonthReport,
            this.tsCPACustomerTrans,
            this.tsCPACustomerProfitability,
            this.tsCPACustomerProfitabilityAnalysis});
            this.tsCPAReports.Name = "tsCPAReports";
            this.tsCPAReports.Size = new System.Drawing.Size(175, 22);
            this.tsCPAReports.Text = "Reports";
            // 
            // tsCPAQuaterlyHistoryOfProfit
            // 
            this.tsCPAQuaterlyHistoryOfProfit.Name = "tsCPAQuaterlyHistoryOfProfit";
            this.tsCPAQuaterlyHistoryOfProfit.Size = new System.Drawing.Size(236, 22);
            this.tsCPAQuaterlyHistoryOfProfit.Text = "Quaterly History of Profit";
            this.tsCPAQuaterlyHistoryOfProfit.Click += new System.EventHandler(this.quaterlyHistoryOfProfitToolStripMenuItem_Click);
            // 
            // tsCPAMonthReport
            // 
            this.tsCPAMonthReport.Name = "tsCPAMonthReport";
            this.tsCPAMonthReport.Size = new System.Drawing.Size(236, 22);
            this.tsCPAMonthReport.Text = "Month Report";
            this.tsCPAMonthReport.Click += new System.EventHandler(this.monthReportToolStripMenuItem_Click);
            // 
            // tsCPACustomerTrans
            // 
            this.tsCPACustomerTrans.Name = "tsCPACustomerTrans";
            this.tsCPACustomerTrans.Size = new System.Drawing.Size(236, 22);
            this.tsCPACustomerTrans.Text = "Customer Transaction";
            this.tsCPACustomerTrans.Click += new System.EventHandler(this.customerTransactionToolStripMenuItem_Click);
            // 
            // tsCPACustomerProfitability
            // 
            this.tsCPACustomerProfitability.Name = "tsCPACustomerProfitability";
            this.tsCPACustomerProfitability.Size = new System.Drawing.Size(236, 22);
            this.tsCPACustomerProfitability.Text = "Customer Profitability";
            this.tsCPACustomerProfitability.Click += new System.EventHandler(this.customerProfitabilityToolStripMenuItem_Click);
            // 
            // tsCPACustomerProfitabilityAnalysis
            // 
            this.tsCPACustomerProfitabilityAnalysis.Name = "tsCPACustomerProfitabilityAnalysis";
            this.tsCPACustomerProfitabilityAnalysis.Size = new System.Drawing.Size(236, 22);
            this.tsCPACustomerProfitabilityAnalysis.Text = "Customer Profitability Analysis";
            this.tsCPACustomerProfitabilityAnalysis.Click += new System.EventHandler(this.customerProfitabilityAnalysisToolStripMenuItem_Click);
            // 
            // tsCPACustomerCPA
            // 
            this.tsCPACustomerCPA.Name = "tsCPACustomerCPA";
            this.tsCPACustomerCPA.Size = new System.Drawing.Size(175, 22);
            this.tsCPACustomerCPA.Text = "Customer CPA List";
            this.tsCPACustomerCPA.Click += new System.EventHandler(this.customerCPAListToolStripMenuItem_Click);
            // 
            // tsmOLMainMenu
            // 
            this.tsmOLMainMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createNewOLToolStripMenuItem,
            this.tsmOLList,
            this.tsmOLListPending,
            this.toolStripSeparator24,
            this.tsmOLHistoryList,
            this.tsmCreateRepayment,
            this.tsmRepaymentList,
            this.toolStripSeparator23,
            this.tsmImportAccessFile,
            this.tsmReport});
            this.tsmOLMainMenu.Name = "tsmOLMainMenu";
            this.tsmOLMainMenu.Size = new System.Drawing.Size(34, 20);
            this.tsmOLMainMenu.Text = "OL";
            // 
            // createNewOLToolStripMenuItem
            // 
            this.createNewOLToolStripMenuItem.Name = "createNewOLToolStripMenuItem";
            this.createNewOLToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.createNewOLToolStripMenuItem.Text = "Create New OL";
            this.createNewOLToolStripMenuItem.Click += new System.EventHandler(this.createNewOLToolStripMenuItem_Click);
            // 
            // tsmOLList
            // 
            this.tsmOLList.Name = "tsmOLList";
            this.tsmOLList.Size = new System.Drawing.Size(182, 22);
            this.tsmOLList.Text = "Outstanding OL List ";
            this.tsmOLList.Click += new System.EventHandler(this.outstandingOLListToolStripMenuItem_Click);
            // 
            // tsmOLListPending
            // 
            this.tsmOLListPending.Name = "tsmOLListPending";
            this.tsmOLListPending.Size = new System.Drawing.Size(182, 22);
            this.tsmOLListPending.Text = "Pending List";
            this.tsmOLListPending.Click += new System.EventHandler(this.pendingListToolStripMenuItem_Click);
            // 
            // toolStripSeparator24
            // 
            this.toolStripSeparator24.Name = "toolStripSeparator24";
            this.toolStripSeparator24.Size = new System.Drawing.Size(179, 6);
            // 
            // tsmOLHistoryList
            // 
            this.tsmOLHistoryList.Name = "tsmOLHistoryList";
            this.tsmOLHistoryList.Size = new System.Drawing.Size(182, 22);
            this.tsmOLHistoryList.Text = "History OL List";
            this.tsmOLHistoryList.Click += new System.EventHandler(this.historyOLListToolStripMenuItem_Click);
            // 
            // tsmCreateRepayment
            // 
            this.tsmCreateRepayment.Name = "tsmCreateRepayment";
            this.tsmCreateRepayment.Size = new System.Drawing.Size(182, 22);
            this.tsmCreateRepayment.Text = "Create Repayment";
            this.tsmCreateRepayment.Click += new System.EventHandler(this.createRepaymentToolStripMenuItem_Click);
            // 
            // tsmRepaymentList
            // 
            this.tsmRepaymentList.Name = "tsmRepaymentList";
            this.tsmRepaymentList.Size = new System.Drawing.Size(182, 22);
            this.tsmRepaymentList.Text = "List Repayment";
            this.tsmRepaymentList.Click += new System.EventHandler(this.listRepaymentToolStripMenuItem_Click);
            // 
            // toolStripSeparator23
            // 
            this.toolStripSeparator23.Name = "toolStripSeparator23";
            this.toolStripSeparator23.Size = new System.Drawing.Size(179, 6);
            // 
            // tsmImportAccessFile
            // 
            this.tsmImportAccessFile.Name = "tsmImportAccessFile";
            this.tsmImportAccessFile.Size = new System.Drawing.Size(182, 22);
            this.tsmImportAccessFile.Text = "Import Access file";
            this.tsmImportAccessFile.Click += new System.EventHandler(this.importAccessFileToolStripMenuItem_Click);
            // 
            // tsmReport
            // 
            this.tsmReport.Name = "tsmReport";
            this.tsmReport.Size = new System.Drawing.Size(182, 22);
            this.tsmReport.Text = "Report";
            this.tsmReport.Click += new System.EventHandler(this.reportToolStripMenuItem4_Click);
            // 
            // tsLGMainMenu
            // 
            this.tsLGMainMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbCreateApplicant,
            this.tsbCreateBeneficiary,
            this.tsbCreateReportForNonResidentApplicantLG,
            this.tsmAppliantList,
            this.beneficiaryListToolStripMenuItem,
            this.tsmListOfFeeCollection,
            this.tsmLGListSup,
            this.tsmLGStaffList,
            this.tsmHistoryLGList,
            this.tsbIssueList,
            this.tsmLGReport,
            this.reconsileToolStripMenuItem,
            this.reconcileSummaryToolStripMenuItem});
            this.tsLGMainMenu.Name = "tsLGMainMenu";
            this.tsLGMainMenu.Size = new System.Drawing.Size(33, 20);
            this.tsLGMainMenu.Text = "LG";
            // 
            // tsbCreateApplicant
            // 
            this.tsbCreateApplicant.Name = "tsbCreateApplicant";
            this.tsbCreateApplicant.Size = new System.Drawing.Size(313, 22);
            this.tsbCreateApplicant.Text = "Create Applicant";
            this.tsbCreateApplicant.Click += new System.EventHandler(this.tsbCreateApplicant_Click);
            // 
            // tsbCreateBeneficiary
            // 
            this.tsbCreateBeneficiary.Name = "tsbCreateBeneficiary";
            this.tsbCreateBeneficiary.Size = new System.Drawing.Size(313, 22);
            this.tsbCreateBeneficiary.Text = "Create Beneficiary";
            this.tsbCreateBeneficiary.Click += new System.EventHandler(this.tsbCreateBeneficiary_Click);
            // 
            // tsbCreateReportForNonResidentApplicantLG
            // 
            this.tsbCreateReportForNonResidentApplicantLG.Name = "tsbCreateReportForNonResidentApplicantLG";
            this.tsbCreateReportForNonResidentApplicantLG.Size = new System.Drawing.Size(313, 22);
            this.tsbCreateReportForNonResidentApplicantLG.Text = "Create Report For Non-Resident Applicant LG";
            this.tsbCreateReportForNonResidentApplicantLG.Click += new System.EventHandler(this.tsbCreateReportForNonResidentApplicantLG_Click);
            // 
            // tsmAppliantList
            // 
            this.tsmAppliantList.Name = "tsmAppliantList";
            this.tsmAppliantList.Size = new System.Drawing.Size(313, 22);
            this.tsmAppliantList.Text = "List Applicant";
            this.tsmAppliantList.Click += new System.EventHandler(this.tsmAppliantList_Click);
            // 
            // beneficiaryListToolStripMenuItem
            // 
            this.beneficiaryListToolStripMenuItem.Name = "beneficiaryListToolStripMenuItem";
            this.beneficiaryListToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.beneficiaryListToolStripMenuItem.Text = "List Beneficiary";
            this.beneficiaryListToolStripMenuItem.Click += new System.EventHandler(this.beneficiaryListToolStripMenuItem_Click);
            // 
            // tsmListOfFeeCollection
            // 
            this.tsmListOfFeeCollection.Name = "tsmListOfFeeCollection";
            this.tsmListOfFeeCollection.Size = new System.Drawing.Size(313, 22);
            this.tsmListOfFeeCollection.Text = "List Of Fee Collection";
            this.tsmListOfFeeCollection.Click += new System.EventHandler(this.tsmListOfFeeCollection_Click);
            // 
            // tsmLGListSup
            // 
            this.tsmLGListSup.Name = "tsmLGListSup";
            this.tsmLGListSup.Size = new System.Drawing.Size(313, 22);
            this.tsmLGListSup.Text = "List LG Supervisor";
            this.tsmLGListSup.Click += new System.EventHandler(this.tsmLGListSup_Click);
            // 
            // tsmLGStaffList
            // 
            this.tsmLGStaffList.Name = "tsmLGStaffList";
            this.tsmLGStaffList.Size = new System.Drawing.Size(313, 22);
            this.tsmLGStaffList.Text = "List LG Staff";
            this.tsmLGStaffList.Click += new System.EventHandler(this.tsmLGStaffList_Click);
            // 
            // tsmHistoryLGList
            // 
            this.tsmHistoryLGList.Name = "tsmHistoryLGList";
            this.tsmHistoryLGList.Size = new System.Drawing.Size(313, 22);
            this.tsmHistoryLGList.Text = "List LG History";
            this.tsmHistoryLGList.Click += new System.EventHandler(this.tsmHistoryLGList_Click);
            // 
            // tsbIssueList
            // 
            this.tsbIssueList.Name = "tsbIssueList";
            this.tsbIssueList.Size = new System.Drawing.Size(313, 22);
            this.tsbIssueList.Text = "Issue LG";
            this.tsbIssueList.Click += new System.EventHandler(this.tsbIssueList_Click);
            // 
            // tsmLGReport
            // 
            this.tsmLGReport.Name = "tsmLGReport";
            this.tsmLGReport.Size = new System.Drawing.Size(313, 22);
            this.tsmLGReport.Text = "List Of Report For Non-Resident Applicant LG";
            this.tsmLGReport.Click += new System.EventHandler(this.tsmLGReport_Click);
            // 
            // reconsileToolStripMenuItem
            // 
            this.reconsileToolStripMenuItem.Name = "reconsileToolStripMenuItem";
            this.reconsileToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.reconsileToolStripMenuItem.Text = "Reconcile Data For LG Transaction";
            this.reconsileToolStripMenuItem.Click += new System.EventHandler(this.reconsileToolStripMenuItem_Click);
            // 
            // reconcileSummaryToolStripMenuItem
            // 
            this.reconcileSummaryToolStripMenuItem.Name = "reconcileSummaryToolStripMenuItem";
            this.reconcileSummaryToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.reconcileSummaryToolStripMenuItem.Text = "Reconcile Result Inquiry";
            this.reconcileSummaryToolStripMenuItem.Click += new System.EventHandler(this.reconcileSummaryToolStripMenuItem_Click);
            // 
            // tsSEMainMenu
            // 
            this.tsSEMainMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsSEManageUser,
            this.tsSEManageAuthorization,
            this.tsSELogSystem});
            this.tsSEMainMenu.Name = "tsSEMainMenu";
            this.tsSEMainMenu.Size = new System.Drawing.Size(61, 20);
            this.tsSEMainMenu.Text = "Security";
            // 
            // tsSEManageUser
            // 
            this.tsSEManageUser.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsSEListUser,
            this.tsSEListTeam,
            this.tsSEListDepartment});
            this.tsSEManageUser.Name = "tsSEManageUser";
            this.tsSEManageUser.Size = new System.Drawing.Size(192, 22);
            this.tsSEManageUser.Text = "Manage User";
            // 
            // tsSEListUser
            // 
            this.tsSEListUser.Name = "tsSEListUser";
            this.tsSEListUser.Size = new System.Drawing.Size(158, 22);
            this.tsSEListUser.Text = "List User";
            this.tsSEListUser.Click += new System.EventHandler(this.listUserToolStripMenuItem_Click);
            // 
            // tsSEListTeam
            // 
            this.tsSEListTeam.Name = "tsSEListTeam";
            this.tsSEListTeam.Size = new System.Drawing.Size(158, 22);
            this.tsSEListTeam.Text = "List Team";
            this.tsSEListTeam.Click += new System.EventHandler(this.listTeamToolStripMenuItem_Click);
            // 
            // tsSEListDepartment
            // 
            this.tsSEListDepartment.Name = "tsSEListDepartment";
            this.tsSEListDepartment.Size = new System.Drawing.Size(158, 22);
            this.tsSEListDepartment.Text = "List Department";
            this.tsSEListDepartment.Click += new System.EventHandler(this.listDepartmentToolStripMenuItem_Click);
            // 
            // tsSEManageAuthorization
            // 
            this.tsSEManageAuthorization.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsSERoleMgmt,
            this.tsSEMenuMgmt,
            this.tsSEFnMgmt,
            this.tsSEAssignRoleToUser,
            this.tsSEAssignRightToRole,
            this.tsSEAssignMenuToRole});
            this.tsSEManageAuthorization.Name = "tsSEManageAuthorization";
            this.tsSEManageAuthorization.Size = new System.Drawing.Size(192, 22);
            this.tsSEManageAuthorization.Text = "Manage Authorization";
            // 
            // tsSERoleMgmt
            // 
            this.tsSERoleMgmt.Name = "tsSERoleMgmt";
            this.tsSERoleMgmt.Size = new System.Drawing.Size(195, 22);
            this.tsSERoleMgmt.Text = "Role Management";
            this.tsSERoleMgmt.Click += new System.EventHandler(this.roleManagementToolStripMenuItem2_Click);
            // 
            // tsSEMenuMgmt
            // 
            this.tsSEMenuMgmt.Name = "tsSEMenuMgmt";
            this.tsSEMenuMgmt.Size = new System.Drawing.Size(195, 22);
            this.tsSEMenuMgmt.Text = "Menu Management";
            this.tsSEMenuMgmt.Click += new System.EventHandler(this.menuManagementToolStripMenuItem2_Click);
            // 
            // tsSEFnMgmt
            // 
            this.tsSEFnMgmt.Name = "tsSEFnMgmt";
            this.tsSEFnMgmt.Size = new System.Drawing.Size(195, 22);
            this.tsSEFnMgmt.Text = "Function Management";
            this.tsSEFnMgmt.Click += new System.EventHandler(this.functionManagementToolStripMenuItem2_Click);
            // 
            // tsSEAssignRoleToUser
            // 
            this.tsSEAssignRoleToUser.Name = "tsSEAssignRoleToUser";
            this.tsSEAssignRoleToUser.Size = new System.Drawing.Size(195, 22);
            this.tsSEAssignRoleToUser.Text = "Assign Role To User";
            this.tsSEAssignRoleToUser.Click += new System.EventHandler(this.assignRoleToUserToolStripMenuItem1_Click);
            // 
            // tsSEAssignRightToRole
            // 
            this.tsSEAssignRightToRole.Name = "tsSEAssignRightToRole";
            this.tsSEAssignRightToRole.Size = new System.Drawing.Size(195, 22);
            this.tsSEAssignRightToRole.Text = "Assign Right To Role";
            this.tsSEAssignRightToRole.Click += new System.EventHandler(this.assignRightToRoleToolStripMenuItem2_Click);
            // 
            // tsSEAssignMenuToRole
            // 
            this.tsSEAssignMenuToRole.Name = "tsSEAssignMenuToRole";
            this.tsSEAssignMenuToRole.Size = new System.Drawing.Size(195, 22);
            this.tsSEAssignMenuToRole.Text = "Assign Menu To Role";
            this.tsSEAssignMenuToRole.Click += new System.EventHandler(this.assignMenuToRoleToolStripMenuItem2_Click);
            // 
            // tsSELogSystem
            // 
            this.tsSELogSystem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsSEExternalLog,
            this.tsSETransactionLog,
            this.tsSESmileLog});
            this.tsSELogSystem.Name = "tsSELogSystem";
            this.tsSELogSystem.Size = new System.Drawing.Size(192, 22);
            this.tsSELogSystem.Text = "Log System";
            // 
            // tsSEExternalLog
            // 
            this.tsSEExternalLog.Name = "tsSEExternalLog";
            this.tsSEExternalLog.Size = new System.Drawing.Size(182, 22);
            this.tsSEExternalLog.Text = "External Log";
            this.tsSEExternalLog.Click += new System.EventHandler(this.externalLogToolStripMenuItem_Click_1);
            // 
            // tsSETransactionLog
            // 
            this.tsSETransactionLog.Name = "tsSETransactionLog";
            this.tsSETransactionLog.Size = new System.Drawing.Size(182, 22);
            this.tsSETransactionLog.Text = "Transaction Log";
            this.tsSETransactionLog.Click += new System.EventHandler(this.transactionLogToolStripMenuItem_Click_1);
            // 
            // tsSESmileLog
            // 
            this.tsSESmileLog.Name = "tsSESmileLog";
            this.tsSESmileLog.Size = new System.Drawing.Size(182, 22);
            this.tsSESmileLog.Text = "Smile Operation Log";
            this.tsSESmileLog.Click += new System.EventHandler(this.smileOperationLogToolStripMenuItem_Click_1);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.helpToolStripMenuItem1.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 431);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1026, 22);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // frmMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackgroundImage = global::BTMU_HCM_SYS.Properties.Resources.Background;
            this.ClientSize = new System.Drawing.Size(1026, 453);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "Phoenix System";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Closed += new System.EventHandler(this.frmMain_Closed);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            System.Globalization.CultureInfo objCultureInfo = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
            objCultureInfo.DateTimeFormat.DateSeparator = "/";
            objCultureInfo.DateTimeFormat.ShortDatePattern = "M/dd/yyyy";
            Application.CurrentCulture = objCultureInfo;
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new frmLogin());
        }

        #region KYC Operations
        public frmBasicInformation1 f1 = null;
        public frmBasicInformation1_Co f11 = null;
        public frmIndividualReport f2 = null;
        public frmCorporateReport f22 = null;
        public frmExportData fExportData = null;
        public frmKYC_QI_Ind fKYC_QI_Ind = null;
        public frmQIInd fQIInd = null;
        public frmKYC_QI_Corp fKYC_QI_Corp = null;
        public frmQICorp fQICorp = null;
        public frmDataCleansing fDataCleansing = null;
        #endregion

        #region CBD Operations
        public frmCorporateCust fCorporateCust = null;
        public frmCorporateCustClosed fCorporateCustClosed = null;
        public frmACInfo fACInfo = null;
        public frmCreditInfo fCreditInfo = null;
        public frmLoan fLoan = null;
        public frmLoanStdSMILE fLoanStdSMILE = null;
        public frmRatingInfo fRatingInfo = null;
        public frmAgreementControl fAgrCtrl = null;
        public frmMargins fMargins = null;
        public frmCredCondInstr fCreditCondInstr = null;
        public frmMonthendRates fMonthendRates = null;
        public frmCustomerCodeControl fCustomerCodeControl = null;
        public frmBusinessPromotion fPromotion = null;
        public frmReport fReport = null;
        public frmReportLocal fReportLocal = null;
        public frmReportLocalBRSMILE fReportLocalBRSMILE = null;
        public frmReportBR fReportBR = null;
        public frmReportCustList fReportCustList = null;
        public frmReportCredAppExp3M fReportCredAppExp3M = null;
        public frmReportCustAsOf fReportCustAsOf = null;
        public frmReportNewCustQuery fReportNewCustQuery = null;
        public frmReportCredOutstandingDiscretion fReportCredOutstandingDiscretion = null;
        public frmControllingBook fControlBook = null;
        public frmControllingPendingItems fControlPendingItems = null;

        public frmCreateIrregularHandling fNewIrregularHandling = null;
        public frmCloseIrregularHandling fCloseIrregularHandling = null;
        public frmIrregularNoApproval fIrregularNoApproval = null;
        public frmViewIrregular fViewIrregular = null;
        public frmReviewIrregularHandling fReviewIrregularHandling = null;
        public frmHistoricIrregular fHistoricIrregular = null;
        public frmGroup fGroup = null;
        public frmGuarantee fGuarantee = null;
        public frmAccountServices fAccountServices = null;
        public frmDomesticRemittance fDomesticRemittance = null;
        public frmForeignRemittance fForeignRemittance = null;
        public frmImportServices fImportServices = null;
        public frmExportServices fExportServices = null;
        public frmChecksTC fChecksTC = null;
        public frmOtherServices fOtherServices = null;
        public frmConfirmation fConfirmation = null;
        public frmConfirmationForDPD fConfirmationForDPD = null;
        public frmEditIrregularHandling fEditIrregularHandling = null;
        public frmImportCurrencyAccount fImportCurrencyAccount = null;
        public frmImportAddress fImportAddress = null;

        // agent transactions
        public frmCreditInfoAT fCreditInfoAT = null;
        public frmLoanAT fLoanAT = null;
        public frmLoanStdSmileAT fLoanStdSmileAT = null;
        public frmAgreementControlAT fAgreementControlAT = null;
        public frmCredCondInstrAT fCredCondInstrAT = null;
        public frmAgentTransactionReport fAgentTransactionReport = null;
        #endregion

        #region GCMS fee
        public frmManageGCMSCustomer fManageGCMSCustomer = null;
        public frmMakingDebitNote fMakingDebitNote = null;
        public frmMakingReport fMakingReport = null;
        public frmConfiguration fConfiguration = null;
        #endregion

        #region TLAD Operations
        public frmLoan_TLAD fLoan_TLAD = null;
        public frmLoan_TLADStdSMILE fLoan_TLADStdSMILE = null;
        public frmLoanAmortisation fAmortisation = null;
        //report
        //public frmReportDisbursement fReportDisbursement = null;
        //public frmDueDateNotice fDueDateNotice = null;
        //public frmExportToExcel fExportToExcel = null;
        public frmSubsidiaryLoan fSubsidiaryLoan = null;
        public frmSubsidiaryLoanStdSMILE fSubsidiaryLoanStdSMILE = null;
        public frmFXConfirmation fFXConfirmation = null;
        #endregion

        #region Middle Office
        //public frmCreditLineForCorporate fCreditLineForCorporate = null;
        //public frmCreditLineForBank fCreditLineForBank = null;
        //public frmBorrowRating fBorrowRating = null;
        //public frmCovenant fCovenant = null;
        //public frmPendingItemBorrowing fPendingItemBorrowing = null;
        //public frmPendingItemCreditLine fPendingItemCreditLine = null;
        //public frmTransaction fTransaction = null;
        //public frmTransactionQuery fTransactionQuery = null;
        //public frmStatement fStatement = null;
        //public frmStatementList fStatementList = null;

        #endregion

        #region ACC Operations
        public frmAccrueSubsidiaryIR fAccrueSubsidiaryIR = null;
        #endregion

        #region System
        public frmChangePwd fChangePwd = null;
        public frmUserManagement fUserMgt = null;
        public frmPermissionManagement fPermissionMgt = null;
        public frmDBManagement fDBMgt = null;
        public frmCustomerCodeImport fCustomerCodeImport = null;
        frmAbout fAbout = null;
        #endregion

        //auto update
        public static bool _auto = false;
        //report configuration
        public static string _url = "";
        public static string _path = "";

        private frmAllSmileViewLog m_SmileViewLog = null;

        #region load App.config
        public static void readAppXML()
        {
            //load settings
            try
            {
                //can't find App.config
                if (!File.Exists(@"./settings/App.config"))
                {
                    writeAppXML("false", "http://localhost/reportserver", "/CBD_HCM_Report/");
                    readAppXML();
                }

                DataSet _ds = new DataSet();
                _ds.ReadXml(@"./settings/App.config");
                DataRow _row = _ds.Tables["app"].Rows[0];
                _auto = bool.Parse(_row["auto_update"].ToString());
                _row = _ds.Tables["reportserver"].Rows[0];
                _url = _row["url"].ToString().Trim();
                frmReport._url = _url;
                _path = _row["path"].ToString().Trim();
                frmReport._path = _path;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public static void writeAppXML(string _auto, string _url, string _path)
        {
            try
            {
                // Error reading config file. Create and save new file.
                string xmlFrag = "<?xml version=\"1.0\" standalone=\"yes\"?>\n" +
                    "<configuration>\n" +
                    "   <app auto_update=\"" + _auto + "\" />\n" +
                    "   <reportserver url=\"" + _url + "\" path=\"" + _path + "\" />\n" +
                    "</configuration>";
                //create folder settings
                Directory.CreateDirectory("settings");
                StreamWriter writer = new StreamWriter(@"./settings/App.config");
                writer.WriteLine(xmlFrag);
                writer.Flush();
                writer.Close();
            }
            catch
            {
                MessageBox.Show("Can't create App.config");
            }
        }
        #endregion

        #region set menu status
        //public static bool _kycModify = false;
        //public static bool _kycDelete = false;
        //public static bool _cbdModify = false;
        //public static bool _cbdDelete = false;
        //public static bool _backModify = false;
        //public static bool _backDelete = false;
        public static bool _accModify = false;
        public static bool _accDelete = false;
        public static bool _iodModify = false;
        public static bool _iodDelete = false;
        public static bool _dpdModify = false;
        public static bool _dpdDelete = false;

        void setMenuSts(string _menu, string _modify, string _delete, string _completeddate, string _approveIrregular, string _InchargeIOD)
        {
            switch (_menu)
            {
                case "KYC":
                    kYCToolStripMenuItem.Visible = true;
                    //_kycModify = bool.Parse(_modify);
                    //_kycDelete = bool.Parse(_delete);
                    frmBasicInformation1_Co._kycModify = bool.Parse(_modify);
                    frmBasicInformation1_Co._kycDelete = bool.Parse(_delete);
                    frmBasicInformation1_Co._kycCompletedDate = bool.Parse(_completeddate);
                    frmBasicInformation1_Co._sLoginUser = frmLogin._username;

                    frmBasicInformation1._kycModify = bool.Parse(_modify);
                    frmBasicInformation1._kycDelete = bool.Parse(_delete);
                    frmBasicInformation1._kycCompletedDate = bool.Parse(_completeddate);
                    frmBasicInformation1._sLoginUser = frmLogin._username;
                    break;
                case "CBD":
                    cBDToolStripMenuItem.Visible = true;
                    //_cbdModify = bool.Parse(_modify);
                    //_cbdDelete = bool.Parse(_delete);
                    frmACInfo._cbdModify = bool.Parse(_modify);
                    frmACInfo._cbdDelete = bool.Parse(_delete);
                    frmAgreementControl._cbdModify = bool.Parse(_modify);
                    frmAgreementControl._cbdDelete = bool.Parse(_delete);
                    frmDocumentControl._cbdModify = bool.Parse(_modify);
                    frmDocumentControl._cbdDelete = bool.Parse(_delete);
                    frmDocumentControl._sLoginUser = frmLogin._username;
                    frmDocumentControlNew._cbdModify = bool.Parse(_modify);
                    frmDocumentControlNew._cbdDelete = bool.Parse(_delete);
                    frmDocumentControlNew._sLoginUser = frmLogin._username;
                    frmBusinessPromotion._cbdModify = bool.Parse(_modify);
                    frmBusinessPromotion._cbdDelete = bool.Parse(_delete);
                    frmCorporateCust._cbdModify = bool.Parse(_modify);
                    frmCorporateCust._cbdDelete = bool.Parse(_delete);
                    frmCorporateCustClosed._cbdModify = bool.Parse(_modify);
                    frmCorporateCustClosed._cbdDelete = bool.Parse(_delete);
                    frmCredCondInstr._cbdModify = bool.Parse(_modify);
                    frmCredCondInstr._cbdDelete = bool.Parse(_delete);
                    frmCreditInfo._cbdModify = bool.Parse(_modify);
                    frmCreditInfo._cbdDelete = bool.Parse(_delete);
                    frmCreditInfo._sLoginUser = frmLogin._username;
                    frmFacilityControl._cbdModify = bool.Parse(_modify);
                    frmFacilityControlNew._cbdModify = bool.Parse(_modify);
                    frmFacilityControl._sLoginUser = frmLogin._username;
                    frmFacilityControlNew._sLoginUser = frmLogin._username;
                    frmLoan._cbdModify = bool.Parse(_modify);
                    frmLoan._cbdDelete = bool.Parse(_delete);
                    frmLoanStdSMILE._cbdModify = bool.Parse(_modify);
                    frmLoanStdSMILE._cbdDelete = bool.Parse(_delete);
                    frmLoanStdSMILE._sLoginUser = frmLogin._username;
                    frmMargins._cbdModify = bool.Parse(_modify);
                    frmMargins._cbdDelete = bool.Parse(_delete);
                    frmMonthendRates._cbdModify = bool.Parse(_modify);
                    frmMonthendRates._cbdDelete = bool.Parse(_delete);
                    //frmCustomerCodeControl._cbdModify = bool.Parse(_modify);
                    //frmCustomerCodeControl._cbdDelete = bool.Parse(_delete);                    
                    frmRatingInfo._cbdModify = bool.Parse(_modify);
                    frmRatingInfo._cbdDelete = bool.Parse(_delete);
                    //------------------------------------------------------------------
                    frmCreateIrregularHandling._cbdModify = bool.Parse(_modify);
                    frmCreateIrregularHandling._sLoginUser = frmLogin._username;

                    frmCloseIrregularHandling._cbdModify = bool.Parse(_modify);
                    frmCloseIrregularHandling._sLoginUser = frmLogin._username;

                    frmIrregularNoApproval._cbdApproveIrregular = bool.Parse(_approveIrregular);
                    frmIrregularNoApproval._cbdModify = bool.Parse(_modify);
                    frmIrregularNoApproval._cbdDelete = bool.Parse(_delete);
                    frmIrregularNoApproval._sLoginUser = frmLogin._username;

                    frmEditIrregularHandling._cbdApproval = bool.Parse(_approveIrregular);
                    frmEditIrregularHandling._sLoginUser = frmLogin._username;

                    frmGroup._cbdModify = bool.Parse(_modify);
                    frmGroup._cbdDelete = bool.Parse(_delete);
                    frmGroup._sLoginUser = frmLogin._username;

                    frmAccountServices._cbdModify = bool.Parse(_modify);
                    frmAccountServices._cbdDelete = bool.Parse(_delete);
                    frmDomesticRemittance._cbdModify = bool.Parse(_modify);
                    frmDomesticRemittance._cbdDelete = bool.Parse(_delete);
                    frmGuarantee._cbdModify = bool.Parse(_modify);
                    frmGuarantee._cbdDelete = bool.Parse(_delete);
                    frmImportServices._cbdModify = bool.Parse(_modify);
                    frmImportServices._cbdDelete = bool.Parse(_delete);
                    frmExportServices._cbdModify = bool.Parse(_modify);
                    frmExportServices._cbdDelete = bool.Parse(_delete);
                    frmChecksTC._cbdModify = bool.Parse(_modify);
                    frmChecksTC._cbdDelete = bool.Parse(_delete);
                    frmForeignRemittance._cbdModify = bool.Parse(_modify);
                    frmForeignRemittance._cbdDelete = bool.Parse(_delete);
                    frmOtherServices._cbdModify = bool.Parse(_modify);
                    frmOtherServices._cbdDelete = bool.Parse(_delete);

                    // agent transaction
                    frmCreditInfoAT._cbdModify = bool.Parse(_modify);
                    frmCreditInfoAT._cbdDelete = bool.Parse(_delete);
                    frmCreditInfoAT._sLoginUser = frmLogin._username;

                    frmFacilityControlNewAT._cbdModify = bool.Parse(_modify);
                    //frmFacilityControlNewAT._cbdDelete = bool.Parse(_delete);
                    frmFacilityControlNewAT._sLoginUser = frmLogin._username;

                    frmLoanAT._cbdModify = bool.Parse(_modify);
                    frmLoanAT._cbdDelete = bool.Parse(_delete);
                    //frmLoanAT._sLoginUser = frmLogin._username;

                    frmLoanStdSmileAT._cbdModify = bool.Parse(_modify);
                    frmLoanStdSmileAT._cbdDelete = bool.Parse(_delete);
                    //frmLoanStdSmileAT._sLoginUser = frmLogin._username;

                    frmAgreementControlAT._cbdModify = bool.Parse(_modify);
                    frmAgreementControlAT._cbdDelete = bool.Parse(_delete);
                    //frmAgreementControlAT._sLoginUser = frmLogin._username;

                    frmCredCondInstrAT._cbdModify = bool.Parse(_modify);
                    frmCredCondInstrAT._cbdDelete = bool.Parse(_delete);
                    //frmCredCondInstrAT._sLoginUser = frmLogin._username;

                    break;
                case "GCMS fee":
                    cMSTeamToolStripMenuItem.Visible = true;
                    frmManageGCMSCustomer._blDelete = bool.Parse(_delete);
                    frmManageGCMSCustomer._blUpdate = bool.Parse(_modify);
                    frmManageGCMSCustomer._Login_UserName = frmLogin._username;

                    frmMakingDebitNote._blDelete = bool.Parse(_delete);
                    frmMakingDebitNote._blUpdate = bool.Parse(_modify);

                    frmMakingReport._blDelete = bool.Parse(_delete);
                    frmMakingReport._blUpdate = bool.Parse(_modify);

                    frmConfiguration._blDelete = bool.Parse(_delete);
                    frmConfiguration._blUpdate = bool.Parse(_modify);
                    break;
                case "Back Office":
                    backOfficeToolStripMenuItem.Visible = true;
                    //_backModify = bool.Parse(_modify);
                    //_backDelete = bool.Parse(_delete);
                    frmLoan_TLAD._backModify = bool.Parse(_modify);
                    frmLoan_TLAD._backDelete = bool.Parse(_delete);

                    frmLoan_TLADStdSMILE._backModify = bool.Parse(_modify);
                    frmLoan_TLADStdSMILE._backDelete = bool.Parse(_delete);
                    frmLoan_TLADStdSMILE._sLoginUser = frmLogin._username;

                    frmFXConfirmation._cbdModify = bool.Parse(_modify);
                    frmFXConfirmation._cbdDelete = bool.Parse(_delete);
                    frmFXConfirmation._Dept = frmLogin._Department;
                    frmFXConfirmation._sLoginUser = frmLogin._username;
                    break;
                case "Middle Office":
                    //middleOfficeToolStripMenuItem.Visible = true;

                    //frmCreditLineForCorporate._Modify = bool.Parse(_modify);
                    //frmCreditLineForCorporate._Delete = bool.Parse(_delete);
                    //frmCreditLineForCorporate._userName = frmLogin._username;

                    //frmCreditLineForBank._Modify = bool.Parse(_modify);
                    //frmCreditLineForBank._Delete = bool.Parse(_delete);
                    //frmCreditLineForBank._userName = frmLogin._username;

                    //frmCovenant._modify = bool.Parse(_modify);
                    //frmCovenant._delete = bool.Parse(_delete);
                    //frmCovenant._sLoginUser = frmLogin._username;

                    //frmPendingItemBorrowing._modify = bool.Parse(_modify);
                    //frmPendingItemBorrowing._delete = bool.Parse(_delete);
                    //frmPendingItemBorrowing._sLoginUser = frmLogin._username;

                    //frmBorrowRating._Modify = bool.Parse(_modify);
                    //frmBorrowRating._Delete = bool.Parse(_delete);
                    //frmBorrowRating._userName = frmLogin._username;

                    //frmPendingItemCreditLine._Modify = bool.Parse(_modify);
                    //frmPendingItemCreditLine._Delete = bool.Parse(_delete);
                    //frmPendingItemCreditLine._userName = frmLogin._username;

                    break;
                case "ACC":
                    aCCToolStripMenuItem.Visible = true;
                    _accModify = bool.Parse(_modify);
                    _accDelete = bool.Parse(_delete);
                    break;
                case "IOD":
                    iODToolStripMenuItem.Visible = true;
                    _iodModify = bool.Parse(_modify);
                    _iodDelete = bool.Parse(_delete);
                    frmConfirmation._Modify = bool.Parse(_modify);
                    frmConfirmation._userName = frmLogin._username;

                    frmTransaction._InchargeIOD = bool.Parse(_InchargeIOD);
                    frmTransaction._Dept = frmLogin._Department;

                    frmStatement._InchargeIOD = bool.Parse(_InchargeIOD);
                    frmStatement._Dept = frmLogin._Department;

                    frmUploadTransactions._InchargeIOD = bool.Parse(_InchargeIOD);
                    frmUploadTransactions._Dept = frmLogin._Department;

                    break;
                case "DPD":
                    dPDToolStripMenuItem.Visible = true;
                    _dpdModify = bool.Parse(_modify);
                    _dpdDelete = bool.Parse(_delete);

                    frmConfirmationForDPD._Modify = bool.Parse(_modify);
                    frmConfirmationForDPD._userName = frmLogin._username;

                    frmImportAddress._cbdModify = bool.Parse(_modify);

                    frmImportCurrencyAccount._cbdModify = bool.Parse(_modify);
                    frmImportCurrencyAccount._userName = frmLogin._username;
                    break;
                case "Treasury":
                    treasuryToolStripMenuItem.Visible = true;
                    break;
                case "Customer Code Control":
                    customerCodeSourceToolStripMenuItem.Visible = true;
                    frmCustomerCodeControl._cbdModify = bool.Parse(_modify);
                    frmCustomerCodeControl._cbdDelete = bool.Parse(_delete);
                    break;
                case "Administrator":
                    administratorToolStripMenuItem.Visible = true;
                    break;
            }
        }
        #endregion

        #region check type
        void checkType()
        {
            #region login as default username
            if (UserSourceClass._username.Equals(frmLogin._username))
            {
                toolStripStatusLabel1.Text = "Login as: " + clsUserInfo.FullName;
                administratorToolStripMenuItem.Visible = true;
                changePasswordToolStripMenuItem.Enabled = false;
                return;
            }
            #endregion

            #region login as an username in database
            string _query = "select Menu, Modify, [Delete],CompletedDate,ApproveIrregular,InchargeIOD from Permissions where UserName = '" +
                            frmLogin._username + "'";
            DataSet _ds = DataAccessClass.datasetQuery(_query);
            changePasswordToolStripMenuItem.Enabled = true;
            DataRow[] _dr = _ds.Tables[0].Select();
            for (int i = 0; i < _dr.Length; i++)
            {
                setMenuSts(_dr[i]["Menu"].ToString().Trim(), _dr[i]["Modify"].ToString().Trim(), _dr[i]["Delete"].ToString().Trim(),
                    _dr[i]["CompletedDate"].ToString().Trim(), _dr[i]["ApproveIrregular"].ToString().Trim(), _dr[i]["InchargeIOD"].ToString());
            }
            //login as
            toolStripStatusLabel1.Text = "Login as: " + frmLogin._username;
            #endregion
        }
        #endregion

        #region exit system
        void exitSystem()
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.IsDisposed)
                {
                    frm.Dispose();
                }
            }
            Application.Exit();
        }

        private void frmMain_Closed(object sender, System.EventArgs e)
        {
            exitSystem();
        }
        #endregion

        private void frmMain_Load(object sender, System.EventArgs e)
        {
            //load database settings
            DataAccessClass.loadDataBaseSettings();
            //load app settings
            readAppXML();
            automaticallyUpdateToolStripMenuItem.Checked = _auto;
            //checkType();
        }

        #region System
        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //new change password screen
            frmMDUserChangePassword frm = new frmMDUserChangePassword();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            exitSystem();
        }

        private void userManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fUserMgt == null || fUserMgt.IsDisposed)
            {
                fUserMgt = new frmUserManagement();
                fUserMgt.MdiParent = this;
                //fUserMgt.fMain = this;
                fUserMgt.Show();
            }
            else
            {
                fUserMgt.Visible = true;
                fUserMgt.Activate();
            }
        }

        private void userPermissionManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fPermissionMgt == null || fPermissionMgt.IsDisposed)
            {
                fPermissionMgt = new frmPermissionManagement();
                fPermissionMgt.MdiParent = this;
                //fPermissionMgt.fMain = this;
                fPermissionMgt.Show();
            }
            else
            {
                fPermissionMgt.Visible = true;
                fPermissionMgt.Activate();
            }
        }

        private void databaseManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fDBMgt == null || fDBMgt.IsDisposed)
            {
                fDBMgt = new frmDBManagement();
                fDBMgt.MdiParent = this;
                //fDBMgt.fMain = this;
                fDBMgt.Show();
            }
            else
            {
                fDBMgt.Visible = true;
                fDBMgt.Activate();
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fAbout == null || fAbout.IsDisposed)
            {
                fAbout = new frmAbout();
                fAbout.MdiParent = this;
                fAbout.Show();
            }
            else
            {
                fAbout.Activate();
            }
        }

        private void customerCodeImportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fCustomerCodeImport == null || fCustomerCodeImport.IsDisposed)
            {
                fCustomerCodeImport = new frmCustomerCodeImport();
                fCustomerCodeImport.MdiParent = this;
                fCustomerCodeImport.Show();
            }
            else
            {
                fCustomerCodeImport.Visible = true;
                fCustomerCodeImport.Activate();
            }
        }

        #region print form
        Bitmap _memoryImg = null;
        void captureScreen()
        {
            Graphics _g = this.CreateGraphics();
            Size _s = this.Size;
            _memoryImg = new Bitmap(_s.Width, _s.Height, _g);
            Graphics _memoryGraphics = Graphics.FromImage(_memoryImg);
            _memoryGraphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, _s);
        }

        private void printFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            captureScreen();
            PageSettings _pSettings = printDocument1.DefaultPageSettings;
            _pSettings.Landscape = true;
            printDocument1.DefaultPageSettings = _pSettings;
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(_memoryImg, 0, 0);
        }
        #endregion

        #endregion

        #region KYC Operations
        //input
        private void individualsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (f1 == null || f1.IsDisposed)
            {
                f1 = new frmBasicInformation1();
                f1.MdiParent = this;
                //f1.fMain = this;
                f1.Show();
            }
            else
            {
                f1.Visible = true;
                f1.Activate();
            }
        }

        private void corporateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (f11 == null || f11.IsDisposed)
            {
                f11 = new frmBasicInformation1_Co();
                f11.MdiParent = this;
                //f11.fMain = this;
                f11.Show();
            }
            else
            {
                f11.Visible = true;
                f11.Activate();
            }
        }

        //report
        private void individualsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (f2 == null || f2.IsDisposed)
            {
                f2 = new frmIndividualReport();
                f2.MdiParent = this;
                //f2.fMain = this;
                f2.Show();
            }
            else
            {
                f2.Visible = true;
                f2.Activate();
            }
        }

        private void corporateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (f22 == null || f22.IsDisposed)
            {
                f22 = new frmCorporateReport();
                f22.MdiParent = this;
                //f22.fMain = this;
                f22.Show();
            }
            else
            {
                f22.Visible = true;
                f22.Activate();
            }
        }

        private void residentialAddressConfirmationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fExportData == null || fExportData.IsDisposed)
            {
                fExportData = new frmExportData();
                fExportData.MdiParent = this;
                //fExportData.fMain = this;
                fExportData.Show();
            }
            else
            {
                fExportData.Visible = true;
                fExportData.Activate();
            }
        }

        private void automaticallyUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (automaticallyUpdateToolStripMenuItem.Checked)
            {
                automaticallyUpdateToolStripMenuItem.Checked = false;
                writeAppXML("false", _url, _path);
                readAppXML();
            }
            else
            {
                automaticallyUpdateToolStripMenuItem.Checked = true;
                writeAppXML("true", _url, _path);
                readAppXML();
            }
        }

        //KYC QI
        private void kYCQIIndividualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fKYC_QI_Ind == null || fKYC_QI_Ind.IsDisposed)
            {
                fKYC_QI_Ind = new frmKYC_QI_Ind();
                fKYC_QI_Ind.MdiParent = this;
                //fKYC_QI_Ind.fMain = this;
                fKYC_QI_Ind.Show();
            }
            else
            {
                fKYC_QI_Ind.Visible = true;
                fKYC_QI_Ind.Activate();
            }
        }

        private void kYCQIIndividualToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fQIInd == null || fQIInd.IsDisposed)
            {
                fQIInd = new frmQIInd();
                fQIInd.MdiParent = this;
                //fQIInd.fMain = this;
                fQIInd.Show();
            }
            else
            {
                fQIInd.Visible = true;
                fQIInd.Activate();
            }
        }

        private void kYCQICorporateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fKYC_QI_Corp == null || fKYC_QI_Corp.IsDisposed)
            {
                fKYC_QI_Corp = new frmKYC_QI_Corp();
                fKYC_QI_Corp.MdiParent = this;
                //fKYC_QI_Corp.fMain = this;
                fKYC_QI_Corp.Show();
            }
            else
            {
                fKYC_QI_Corp.Visible = true;
                fKYC_QI_Corp.Activate();
            }
        }

        private void kYCQICorporateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fQICorp == null || fQICorp.IsDisposed)
            {
                fQICorp = new frmQICorp();
                fQICorp.MdiParent = this;
                //fQICorp.fMain = this;
                fQICorp.Show();
            }
            else
            {
                fQICorp.Visible = true;
                fQICorp.Activate();
            }
        }

        private void dataCleansingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fDataCleansing == null || fDataCleansing.IsDisposed)
            {
                fDataCleansing = new frmDataCleansing();
                fDataCleansing.MdiParent = this;
                //fDataCleansing.fMain = this;
                fDataCleansing.Show();
            }
            else
            {
                fDataCleansing.Visible = true;
                fDataCleansing.Activate();
            }
        }
        #endregion

        #region CBD Operations

        #region input
        private void corporateCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fCorporateCust == null || fCorporateCust.IsDisposed)
            {
                fCorporateCust = new frmCorporateCust();
                fCorporateCust.MdiParent = this;
                //fCorporateCust.fMain = this;
                fCorporateCust.Show();
            }
            else
            {
                fCorporateCust.Visible = true;
                fCorporateCust.Activate();
            }
        }

        private void corporateCustomerClosedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fCorporateCustClosed == null || fCorporateCustClosed.IsDisposed)
            {
                fCorporateCustClosed = new frmCorporateCustClosed();
                fCorporateCustClosed.MdiParent = this;
                //fCorporateCustClosed.fMain = this;
                fCorporateCustClosed.Show();
            }
            else
            {
                fCorporateCustClosed.Visible = true;
                fCorporateCustClosed.Activate();
            }
        }

        private void accountInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fACInfo == null || fACInfo.IsDisposed)
            {
                fACInfo = new frmACInfo();
                fACInfo.MdiParent = this;
                //fACInfo.fMain = this;
                fACInfo.Show();
            }
            else
            {
                fACInfo.Visible = true;
                fACInfo.Activate();
            }
        }

        private void creditApplicationInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fCreditInfo == null || fCreditInfo.IsDisposed)
            {
                fCreditInfo = new frmCreditInfo();
                fCreditInfo.MdiParent = this;
                //fCreditInfo.fMain = this;
                fCreditInfo.Show();
            }
            else
            {
                fCreditInfo.Visible = true;
                fCreditInfo.Activate();
            }
        }

        private void loanInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (fLoanInfo == null || fLoanInfo.IsDisposed)
            //{
            //    fLoanInfo = new frmLoanInfo();
            //    fLoanInfo.MdiParent = this;
            //    //fLoanInfo.fMain = this;
            //    fLoanInfo.Show();
            //}
            //else
            //{
            //    fLoanInfo.Visible = true;
            //    fLoanInfo.Activate();
            //}
            if (fLoan == null || fLoan.IsDisposed)
            {
                fLoan = new frmLoan();
                fLoan.MdiParent = this;
                //fLoan.fMain = this;
                fLoan.Show();
            }
            else
            {
                fLoan.Visible = true;
                fLoan.Activate();
            }
        }

        private void loanInformationForSTANDARDSMILEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fLoanStdSMILE == null || fLoanStdSMILE.IsDisposed)
            {
                fLoanStdSMILE = new frmLoanStdSMILE();
                fLoanStdSMILE.MdiParent = this;
                //fLoanStdSMILE.fMain = this;
                fLoanStdSMILE.Show();
            }
            else
            {
                fLoanStdSMILE.Visible = true;
                fLoanStdSMILE.Activate();
            }
        }

        private void borrowerRateInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fRatingInfo == null || fRatingInfo.IsDisposed)
            {
                fRatingInfo = new frmRatingInfo();
                fRatingInfo.MdiParent = this;
                //fRatingInfo.fMain = this;
                fRatingInfo.Show();
            }
            else
            {
                fRatingInfo.Visible = true;
                fRatingInfo.Activate();
            }
        }

        private void agreementControlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fAgrCtrl == null || fAgrCtrl.IsDisposed)
            {
                fAgrCtrl = new frmAgreementControl();
                fAgrCtrl.MdiParent = this;
                //fAgrCtrl.fMain = this;
                fAgrCtrl.Show();
            }
            else
            {
                fAgrCtrl.Visible = true;
                fAgrCtrl.Activate();
            }
        }

        private void marginsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fMargins == null || fMargins.IsDisposed)
            {
                fMargins = new frmMargins();
                fMargins.MdiParent = this;
                //fMargins.fMain = this;
                fMargins.Show();
            }
            else
            {
                fMargins.Visible = true;
                fMargins.Activate();
            }
        }

        private void creditConditionAndInstructionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fCreditCondInstr == null || fCreditCondInstr.IsDisposed)
            {
                fCreditCondInstr = new frmCredCondInstr();
                fCreditCondInstr.MdiParent = this;
                //fCreditCondInstr.fMain = this;
                fCreditCondInstr.Show();
            }
            else
            {
                fCreditCondInstr.Visible = true;
                fCreditCondInstr.Activate();
            }
        }

        private void monthendRatesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fMonthendRates == null || fMonthendRates.IsDisposed)
            {
                fMonthendRates = new frmMonthendRates();
                fMonthendRates.MdiParent = this;
                //fMonthendRates.fMain = this;
                fMonthendRates.Show();
            }
            else
            {
                fMonthendRates.Visible = true;
                fMonthendRates.Activate();
            }
        }

        private void customerCodeSourceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fCustomerCodeControl == null || fCustomerCodeControl.IsDisposed)
            {
                fCustomerCodeControl = new frmCustomerCodeControl();
                fCustomerCodeControl.MdiParent = this;
                //fCustomerCodeControl.fMain = this;
                fCustomerCodeControl.Show();
            }
            else
            {
                fCustomerCodeControl.Visible = true;
                fCustomerCodeControl.Activate();
            }
        }

        private void bussinessToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fPromotion == null || fPromotion.IsDisposed)
            {
                fPromotion = new frmBusinessPromotion();
                fPromotion.MdiParent = this;
                //fPromotion.fMain = this;
                fPromotion.Show();
            }
            else
            {
                fPromotion.Visible = true;
                fPromotion.Activate();
            }
        }

        private void reportListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (fReport == null || fReport.IsDisposed)
            //{
            //    fReport = new frmReport();
            //    fReport.MdiParent = this;
            //    //fReport.fMain = this;
            //    fReport.Show();
            //}
            //else
            //{
            //    fReport.Visible = true;
            //    fReport.Activate();
            //}
        }
        #endregion

        #region Report Local List
        void callReportLocal()
        {
            //if (fReportLocal == null || fReportLocal.IsDisposed)
            //{
            fReportLocal = new frmReportLocal();
            fReportLocal.MdiParent = this;
            //fReportLocal.fMain = this;
            fReportLocal.Show();
            //}
            //else
            //{
            //    fReportLocal.Visible = true;
            //    fReportLocal.Activate();
            //}
        }

        //public static string _lbl = "";
        //public static string _report = "";

        private void checklistAgmtDocsCollectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportLocal._lbl = "Application No.";
            frmReportLocal._report = "Checklist - Agmt Docs Collection";
            callReportLocal();
        }

        private void checklistFacilityDocsDeliveryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportLocal._lbl = "Application No.";
            frmReportLocal._report = "Checklist - Facility Docs Delivery";
            callReportLocal();
        }

        private void checklistMsterAgmtsDeliveryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportLocal._lbl = "Customer Code";
            frmReportLocal._report = "Checklist - Mster Agmts Delivery";
            callReportLocal();
        }

        private void creditCondAndInstSheetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportLocal._lbl = "Serial No.";
            frmReportLocal._report = "Credit Cond and Inst Sheet";
            callReportLocal();
        }

        private void creditConditionSheetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportLocal._lbl = "Application No.";
            frmReportLocal._report = "Credit Condition Sheet";
            callReportLocal();
        }

        private void borrowerRatingSmileUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fReportLocalBRSMILE = new frmReportLocalBRSMILE();
            fReportLocalBRSMILE.MdiParent = this;
            fReportLocalBRSMILE.Show();
        }

        void callReportBR()
        {
            fReportBR = new frmReportBR();
            fReportBR.MdiParent = this;
            fReportBR.Show();
        }

        //public static string _reportBR = "";

        private void byGradeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportBR._reportBR = "Borrower Ratings - by Grade";
            callReportBR();
        }

        private void byMaturityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportBR._reportBR = "Borrower ratings - by Maturity";
            callReportBR();
        }

        private void creditAppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fReportCredAppExp3M = new frmReportCredAppExp3M();
            fReportCredAppExp3M.MdiParent = this;
            fReportCredAppExp3M.Show();
        }

        void callReportCustList()
        {
            fReportCustList = new frmReportCustList();
            fReportCustList.MdiParent = this;
            fReportCustList.Show();
        }

        //public static string _reportCustList = "";

        private void byGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportCustList._reportCustList = "Customer List - by Group";
            callReportCustList();
        }

        private void byTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportCustList._reportCustList = "Customer List - by Type";
            callReportCustList();
        }

        private void byEPZToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportCustList._reportCustList = "Customer List - EPZ";
            callReportCustList();
        }

        void callReportCustAsOf()
        {
            fReportCustAsOf = new frmReportCustAsOf();
            fReportCustAsOf.MdiParent = this;
            fReportCustAsOf.Show();
        }

        //public static string _reportCustAsOf = "";

        private void subIdenticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportCustAsOf._reportCustAsOf = "Customer List - Sub Identical";
            callReportCustAsOf();
        }

        private void industrySummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportCustList._reportCustList = "Customer List by Industry - Summary";
            callReportCustList();
        }

        private void newCustomerQueryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fReportNewCustQuery = new frmReportNewCustQuery();
            fReportNewCustQuery.MdiParent = this;
            fReportNewCustQuery.Show();
        }

        private void rPTCreditOutstandingByDiscretionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fReportCredOutstandingDiscretion = new frmReportCredOutstandingDiscretion();
            fReportCredOutstandingDiscretion.MdiParent = this;
            fReportCredOutstandingDiscretion.Show();
        }

        private void outstandingCreditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportCustAsOf._reportCustAsOf = "RPT - Outstanding Cred Cust List";
            callReportCustAsOf();
        }
        #endregion

        #region controlling book
        private void controllingBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fControlBook = new frmControllingBook();
            fControlBook.MdiParent = this;
            fControlBook.Show();
        }

        private void controllingPendingItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fControlPendingItems = new frmControllingPendingItems();
            fControlPendingItems.MdiParent = this;
            fControlPendingItems.Show();
        }
        #endregion

        #region Irregular
        private void newIrregularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fNewIrregularHandling == null || fNewIrregularHandling.IsDisposed)
            {
                fNewIrregularHandling = new frmCreateIrregularHandling();
                fNewIrregularHandling.MdiParent = this;
                fNewIrregularHandling.Show();
            }
            else
            {
                fNewIrregularHandling.Visible = true;
                fNewIrregularHandling.Activate();
            }
        }
        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fViewIrregular == null || fViewIrregular.IsDisposed)
            {
                fViewIrregular = new frmViewIrregular();
                fViewIrregular.MdiParent = this;
                fViewIrregular.Show();
            }
            else
            {
                fViewIrregular.Visible = true;
                fViewIrregular.Activate();
            }
        }
        private void noApprovalIrreglarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fIrregularNoApproval == null || fIrregularNoApproval.IsDisposed)
            {
                fIrregularNoApproval = new frmIrregularNoApproval();
                fIrregularNoApproval.MdiParent = this;
                fIrregularNoApproval.Show();
            }
            else
            {
                fIrregularNoApproval.Visible = true;
                fIrregularNoApproval.Activate();
            }
        }
        private void reviewIrregularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fReviewIrregularHandling == null || fReviewIrregularHandling.IsDisposed)
            {
                fReviewIrregularHandling = new frmReviewIrregularHandling();
                fReviewIrregularHandling.MdiParent = this;
                fReviewIrregularHandling.Show();
            }
            else
            {
                fReviewIrregularHandling.Visible = true;
                fReviewIrregularHandling.Activate();
            }
        }
        private void allIrregularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fHistoricIrregular == null || fHistoricIrregular.IsDisposed)
            {
                fHistoricIrregular = new frmHistoricIrregular();
                fHistoricIrregular.MdiParent = this;
                fHistoricIrregular.Show();
            }
            else
            {
                fHistoricIrregular.Visible = true;
                fHistoricIrregular.Activate();
            }
        }
        private void groupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fGroup == null || fGroup.IsDisposed)
            {
                fGroup = new frmGroup();
                fGroup.MdiParent = this;
                fGroup.Show();
            }
            else
            {
                fGroup.Visible = true;
                fGroup.Activate();
            }
        }
        private void guaranteeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fGuarantee == null || fGuarantee.IsDisposed)
            {
                fGuarantee = new frmGuarantee();
                fGuarantee.MdiParent = this;
                fGuarantee.Show();
            }
            else
            {
                fGuarantee.Visible = true;
                fGuarantee.Activate();
            }
        }
        private void importExporotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fImportServices == null || fImportServices.IsDisposed)
            {
                fImportServices = new frmImportServices();
                fImportServices.MdiParent = this;
                fImportServices.Show();
            }
            else
            {
                fImportServices.Visible = true;
                fImportServices.Activate();
            }
        }
        private void exportServiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fExportServices == null || fExportServices.IsDisposed)
            {
                fExportServices = new frmExportServices();
                fExportServices.MdiParent = this;
                fExportServices.Show();
            }
            else
            {
                fExportServices.Visible = true;
                fExportServices.Activate();
            }
        }
        private void checksAndTCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fChecksTC == null || fChecksTC.IsDisposed)
            {
                fChecksTC = new frmChecksTC();
                fChecksTC.MdiParent = this;
                fChecksTC.Show();
            }
            else
            {
                fChecksTC.Visible = true;
                fChecksTC.Activate();
            }
        }
        private void foreignRemittanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fForeignRemittance == null || fForeignRemittance.IsDisposed)
            {
                fForeignRemittance = new frmForeignRemittance();
                fForeignRemittance.MdiParent = this;
                fForeignRemittance.Show();
            }
            else
            {
                fForeignRemittance.Visible = true;
                fForeignRemittance.Activate();
            }
        }
        private void otherServiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fOtherServices == null || fOtherServices.IsDisposed)
            {
                fOtherServices = new frmOtherServices();
                fOtherServices.MdiParent = this;
                fOtherServices.Show();
            }
            else
            {
                fOtherServices.Visible = true;
                fOtherServices.Activate();
            }
        }
        #endregion

        #endregion

        #region TLAD Operations
        private void loanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fLoan_TLAD == null || fLoan_TLAD.IsDisposed)
            {
                fLoan_TLAD = new frmLoan_TLAD();
                fLoan_TLAD.MdiParent = this;
                //fLoan_TLAD.fMain = this;
                fLoan_TLAD.Show();
            }
            else
            {
                fLoan_TLAD.Visible = true;
                fLoan_TLAD.Activate();
            }
        }

        private void loanSTANDARDSMILEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fLoan_TLADStdSMILE == null || fLoan_TLADStdSMILE.IsDisposed)
            {
                fLoan_TLADStdSMILE = new frmLoan_TLADStdSMILE();
                fLoan_TLADStdSMILE.MdiParent = this;
                //fLoan_TLADStdSMILE.fMain = this;
                fLoan_TLADStdSMILE.Show();
            }
            else
            {
                fLoan_TLADStdSMILE.Visible = true;
                fLoan_TLADStdSMILE.Activate();
            }
        }

        private void amortisationScheduleRegisterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fAmortisation == null || fAmortisation.IsDisposed)
            {
                fAmortisation = new frmLoanAmortisation();
                fAmortisation.MdiParent = this;
                //fAmortisation.fMain = this;
                fAmortisation.Show();
            }
            else
            {
                fAmortisation.Visible = true;
                fAmortisation.Activate();
            }
        }

        //report
        private void reportDisbursementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //fReportDisbursement = new frmReportDisbursement();
            //fReportDisbursement.MdiParent = this;
            //fReportDisbursement.Show();
        }

        private void reportDueDateNoticeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //fDueDateNotice = new frmDueDateNotice();
            //fDueDateNotice.MdiParent = this;
            //fDueDateNotice.Show();
        }

        private void exportToExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //fExportToExcel = new frmExportToExcel();
            //fExportToExcel.MdiParent = this;
            //fExportToExcel.Show();
        }

        private void subsidiaryInterestRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fSubsidiaryLoan = new frmSubsidiaryLoan();
            fSubsidiaryLoan.MdiParent = this;
            fSubsidiaryLoan.Show();
        }

        private void subsidiaryInterestRateSTANDARDSMILEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fSubsidiaryLoanStdSMILE = new frmSubsidiaryLoanStdSMILE();
            fSubsidiaryLoanStdSMILE.MdiParent = this;
            fSubsidiaryLoanStdSMILE.Show();
        }
        #endregion

        #region ACC Operations
        private void accumulativeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAccrueSubsidiaryIR = new frmAccrueSubsidiaryIR();
            fAccrueSubsidiaryIR.MdiParent = this;
            fAccrueSubsidiaryIR.Show();
        }
        #endregion

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            /*frmCashConfirmation frm = new frmCashConfirmation();
            frm.MdiParent = this;
            frm.Show();*/
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            /*frmDocsConfirmation frm = new frmDocsConfirmation();
            frm.MdiParent = this;
            frm.Show();*/
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            /*frmFaxConfirmation frm = new frmFaxConfirmation();
            frm.MdiParent = this;
            frm.Show();*/
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            /*frmFXConfirmation frm = new frmFXConfirmation();
            frm.MdiParent = this;
            frm.Show();*/
        }

        private void domesticRemittanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fDomesticRemittance == null || fDomesticRemittance.IsDisposed)
            {
                fDomesticRemittance = new frmDomesticRemittance();
                fDomesticRemittance.MdiParent = this;
                fDomesticRemittance.Show();
            }
            else
            {
                fDomesticRemittance.Visible = true;
                fDomesticRemittance.Activate();
            }
        }

        private void accountServicesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fAccountServices == null || fAccountServices.IsDisposed)
            {
                fAccountServices = new frmAccountServices();
                fAccountServices.MdiParent = this;
                fAccountServices.Show();
            }
            else
            {
                fAccountServices.Visible = true;
                fAccountServices.Activate();
            }
        }

        private void confirmationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fConfirmation == null || fConfirmation.IsDisposed)
            {
                fConfirmation = new frmConfirmation();
                fConfirmation.MdiParent = this;
                fConfirmation.Show();
            }
            else
            {
                fConfirmation.Visible = true;
                fConfirmation.Activate();
            }
        }

        private void reportToolStripMenuItem3_Click(object sender, EventArgs e)
        {


        }

        private void forJPCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportIrregular frm = new frmReportIrregular();
            frm.MdiParent = this;
            frm.Show();

        }

        private void forNonJPCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportIrregularNonJan frm = new frmReportIrregularNonJan();
            frm.MdiParent = this;
            frm.Show();
        }

        private void irregularHandlingByCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportIrregularHandlingByCustomer frm = new frmReportIrregularHandlingByCustomer();
            frm.MdiParent = this;
            frm.Show();
        }

        private void irregularHandlingForToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportIrregularHandlingAllCustomer frm = new frmReportIrregularHandlingAllCustomer();
            frm.MdiParent = this;
            frm.Show();
        }

        private void closeIrregularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fCloseIrregularHandling == null || fCloseIrregularHandling.IsDisposed)
            {
                fCloseIrregularHandling = new frmCloseIrregularHandling();
                fCloseIrregularHandling.MdiParent = this;
                fCloseIrregularHandling.Show();
            }
            else
            {
                fCloseIrregularHandling.Visible = true;
                fCloseIrregularHandling.Activate();
            }

        }
        #region IOD
        private void accountServicesToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (fAccountServices == null || fAccountServices.IsDisposed)
            {
                fAccountServices = new frmAccountServices();
                fAccountServices.MdiParent = this;
                fAccountServices.Show();
            }
            else
            {
                fAccountServices.Visible = true;
                fAccountServices.Activate();
            }
        }

        private void domesticRemittanceToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (fDomesticRemittance == null || fDomesticRemittance.IsDisposed)
            {
                fDomesticRemittance = new frmDomesticRemittance();
                fDomesticRemittance.MdiParent = this;
                fDomesticRemittance.Show();
            }
            else
            {
                fDomesticRemittance.Visible = true;
                fDomesticRemittance.Activate();
            }
        }

        private void viewToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fViewIrregular == null || fViewIrregular.IsDisposed)
            {
                fViewIrregular = new frmViewIrregular();
                fViewIrregular.MdiParent = this;
                fViewIrregular.Show();
            }
            else
            {
                fViewIrregular.Visible = true;
                fViewIrregular.Activate();
            }
        }

        private void groupToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fGroup == null || fGroup.IsDisposed)
            {
                fGroup = new frmGroup();
                fGroup.MdiParent = this;
                fGroup.Show();
            }
            else
            {
                fGroup.Visible = true;
                fGroup.Activate();
            }
        }


        private void guaranteeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fGuarantee == null || fGuarantee.IsDisposed)
            {
                fGuarantee = new frmGuarantee();
                fGuarantee.MdiParent = this;
                fGuarantee.Show();
            }
            else
            {
                fGuarantee.Visible = true;
                fGuarantee.Activate();
            }
        }

        private void importServiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fImportServices == null || fImportServices.IsDisposed)
            {
                fImportServices = new frmImportServices();
                fImportServices.MdiParent = this;
                fImportServices.Show();
            }
            else
            {
                fImportServices.Visible = true;
                fImportServices.Activate();
            }
        }

        private void exportServiceToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fExportServices == null || fExportServices.IsDisposed)
            {
                fExportServices = new frmExportServices();
                fExportServices.MdiParent = this;
                fExportServices.Show();
            }
            else
            {
                fExportServices.Visible = true;
                fExportServices.Activate();
            }
        }

        private void checksAndTCToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fChecksTC == null || fChecksTC.IsDisposed)
            {
                fChecksTC = new frmChecksTC();
                fChecksTC.MdiParent = this;
                fChecksTC.Show();
            }
            else
            {
                fChecksTC.Visible = true;
                fChecksTC.Activate();
            }
        }

        private void foreignRemittanceToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fForeignRemittance == null || fForeignRemittance.IsDisposed)
            {
                fForeignRemittance = new frmForeignRemittance();
                fForeignRemittance.MdiParent = this;
                fForeignRemittance.Show();
            }
            else
            {
                fForeignRemittance.Visible = true;
                fForeignRemittance.Activate();
            }
        }

        private void otherServicesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fOtherServices == null || fOtherServices.IsDisposed)
            {
                fOtherServices = new frmOtherServices();
                fOtherServices.MdiParent = this;
                fOtherServices.Show();
            }
            else
            {
                fOtherServices.Visible = true;
                fOtherServices.Activate();
            }
        }
        private void comfirmationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fConfirmation == null || fConfirmation.IsDisposed)
            {
                fConfirmation = new frmConfirmation();
                fConfirmation.MdiParent = this;
                fConfirmation.Show();
            }
            else
            {
                fConfirmation.Visible = true;
                fConfirmation.Activate();
            }
        }

        #endregion
        #region DPD
        private void accountServicesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fAccountServices == null || fAccountServices.IsDisposed)
            {
                fAccountServices = new frmAccountServices();
                fAccountServices.MdiParent = this;
                fAccountServices.Show();
            }
            else
            {
                fAccountServices.Visible = true;
                fAccountServices.Activate();
            }
        }

        private void domesticRemittanceToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fDomesticRemittance == null || fDomesticRemittance.IsDisposed)
            {
                fDomesticRemittance = new frmDomesticRemittance();
                fDomesticRemittance.MdiParent = this;
                fDomesticRemittance.Show();
            }
            else
            {
                fDomesticRemittance.Visible = true;
                fDomesticRemittance.Activate();
            }
        }
        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            if (fViewIrregular == null || fViewIrregular.IsDisposed)
            {
                fViewIrregular = new frmViewIrregular();
                fViewIrregular.MdiParent = this;
                fViewIrregular.Show();
            }
            else
            {
                fViewIrregular.Visible = true;
                fViewIrregular.Activate();
            }
        }


        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            if (fGroup == null || fGroup.IsDisposed)
            {
                fGroup = new frmGroup();
                fGroup.MdiParent = this;
                fGroup.Show();
            }
            else
            {
                fGroup.Visible = true;
                fGroup.Activate();
            }
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            if (fGuarantee == null || fGuarantee.IsDisposed)
            {
                fGuarantee = new frmGuarantee();
                fGuarantee.MdiParent = this;
                fGuarantee.Show();
            }
            else
            {
                fGuarantee.Visible = true;
                fGuarantee.Activate();
            }
        }

        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {
            if (fImportServices == null || fImportServices.IsDisposed)
            {
                fImportServices = new frmImportServices();
                fImportServices.MdiParent = this;
                fImportServices.Show();
            }
            else
            {
                fImportServices.Visible = true;
                fImportServices.Activate();
            }
        }

        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {
            if (fExportServices == null || fExportServices.IsDisposed)
            {
                fExportServices = new frmExportServices();
                fExportServices.MdiParent = this;
                fExportServices.Show();
            }
            else
            {
                fExportServices.Visible = true;
                fExportServices.Activate();
            }
        }

        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            if (fChecksTC == null || fChecksTC.IsDisposed)
            {
                fChecksTC = new frmChecksTC();
                fChecksTC.MdiParent = this;
                fChecksTC.Show();
            }
            else
            {
                fChecksTC.Visible = true;
                fChecksTC.Activate();
            }
        }

        private void toolStripMenuItem18_Click(object sender, EventArgs e)
        {
            if (fForeignRemittance == null || fForeignRemittance.IsDisposed)
            {
                fForeignRemittance = new frmForeignRemittance();
                fForeignRemittance.MdiParent = this;
                fForeignRemittance.Show();
            }
            else
            {
                fForeignRemittance.Visible = true;
                fForeignRemittance.Activate();
            }
        }

        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
            if (fOtherServices == null || fOtherServices.IsDisposed)
            {
                fOtherServices = new frmOtherServices();
                fOtherServices.MdiParent = this;
                fOtherServices.Show();
            }
            else
            {
                fOtherServices.Visible = true;
                fOtherServices.Activate();
            }
        }

        private void confirmationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fConfirmationForDPD == null || fConfirmationForDPD.IsDisposed)
            {
                fConfirmationForDPD = new frmConfirmationForDPD();
                fConfirmationForDPD.MdiParent = this;
                fConfirmationForDPD.Show();
            }
            else
            {
                fConfirmationForDPD.Visible = true;
                fConfirmationForDPD.Activate();
            }
        }
        #endregion

        private void uploadDataToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void confirmationToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (fConfirmation == null || fConfirmation.IsDisposed)
            {
                fConfirmation = new frmConfirmation();
                fConfirmation.MdiParent = this;
                fConfirmation.Show();
            }
            else
            {
                fConfirmation.Visible = true;
                fConfirmation.Activate();
            }
        }

        private void editIrregularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fEditIrregularHandling == null || fEditIrregularHandling.IsDisposed)
            {
                fEditIrregularHandling = new frmEditIrregularHandling();
                fEditIrregularHandling.MdiParent = this;
                fEditIrregularHandling.Show();
            }
            else
            {
                fEditIrregularHandling.Visible = true;
                fEditIrregularHandling.Activate();
            }
        }

        private void importAccountToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmImportCurrencyAccount frm = new frmImportCurrencyAccount();
            frm.MdiParent = this;
            frm.Show();
        }

        private void importAddressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmImportAddress frm = new frmImportAddress();
            frm.MdiParent = this;
            frm.Show();
        }

        private void forCorporateToolStripMenuItem_Click(object sender, EventArgs e)
        {

            frmCreditLineForCorporate fCreditLineForCorporate = new frmCreditLineForCorporate();
            fCreditLineForCorporate.StartPosition = FormStartPosition.CenterScreen;
            fCreditLineForCorporate.MdiParent = this;
            fCreditLineForCorporate.Show();

        }

        private void fXConfirmationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fFXConfirmation == null || fFXConfirmation.IsDisposed)
            {
                fFXConfirmation = new frmFXConfirmation();
                fFXConfirmation.MdiParent = this;
                fFXConfirmation.Show();
            }
            else
            {
                fFXConfirmation.Visible = true;
                fFXConfirmation.Activate();
            }
        }

        private void manageGCMSCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                if (fManageGCMSCustomer == null || fManageGCMSCustomer.IsDisposed)
                {
                    fManageGCMSCustomer = new frmManageGCMSCustomer();
                    fManageGCMSCustomer.MdiParent = this;
                    fManageGCMSCustomer.Show();
                }
                else
                {
                    fManageGCMSCustomer.Visible = true;
                    fManageGCMSCustomer.Activate();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }

        private void makingDebitIntructionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (fMakingDebitNote == null || fMakingDebitNote.IsDisposed)
                {
                    fMakingDebitNote = new frmMakingDebitNote();
                    fMakingDebitNote.MdiParent = this;
                    fMakingDebitNote.Show();
                }
                else
                {
                    fMakingDebitNote.Visible = true;
                    fMakingDebitNote.Activate();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }

        private void makingReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (fMakingReport == null || fMakingReport.IsDisposed)
                {
                    fMakingReport = new frmMakingReport();
                    fMakingReport.MdiParent = this;
                    fMakingReport.Show();
                }
                else
                {
                    fMakingReport.Visible = true;
                    fMakingReport.Activate();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }

        }

        private void holidaysConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (fConfiguration == null || fConfiguration.IsDisposed)
                {
                    fConfiguration = new frmConfiguration();
                    fConfiguration.MdiParent = this;
                    fConfiguration.Show();
                }
                else
                {
                    fConfiguration.Visible = true;
                    fConfiguration.Activate();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }

        private void forBankToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                frmCreditLineForBank fCreditLineForBank = new frmCreditLineForBank();
                fCreditLineForBank.StartPosition = FormStartPosition.CenterScreen;
                fCreditLineForBank.MdiParent = this;
                fCreditLineForBank.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }

        private void covenantToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmCovenant fCovenant = new frmCovenant();
                fCovenant.StartPosition = FormStartPosition.CenterScreen;
                fCovenant.MdiParent = this;
                fCovenant.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void pendingItemOfBorrowRatingToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void borrowRatingToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void borrowRatingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmBorrowRating fBorrowRating = new frmBorrowRating();
                fBorrowRating.StartPosition = FormStartPosition.CenterScreen;
                fBorrowRating.MdiParent = this;
                fBorrowRating.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void pendingItemForBRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmPendingItemBorrowing fPendingItemBorrowing = new frmPendingItemBorrowing();
                fPendingItemBorrowing.StartPosition = FormStartPosition.CenterScreen;
                fPendingItemBorrowing.MdiParent = this;
                fPendingItemBorrowing.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void pendingItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                frmPendingItemCreditLine fPendingItemCreditLine = new frmPendingItemCreditLine();
                fPendingItemCreditLine.StartPosition = FormStartPosition.CenterScreen;
                fPendingItemCreditLine.MdiParent = this;
                fPendingItemCreditLine.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void creditFacilityForCorporateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfCreditLine frm = new frmMonthlyReportOfCreditLine();
            frm.MdiParent = this;
            frm.Show();
        }

        private void creditFacilityForBankToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfCreditLineForBank frm = new frmMonthlyReportOfCreditLineForBank();
            frm.MdiParent = this;
            frm.Show();
        }

        private void securityReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfSecurity frm = new frmMonthlyReportOfSecurity();
            frm.MdiParent = this;
            frm.Show();
        }

        private void instructionConditionForCorporateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfIntructionCondition frm = new frmMonthlyReportOfIntructionCondition();
            frm.MdiParent = this;
            frm.Show();
        }

        private void instructionConditionForBankToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfIntructionConditionBank frm = new frmMonthlyReportOfIntructionConditionBank();
            frm.MdiParent = this;
            frm.Show();
        }

        private void borrowerRatingToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfBorrowerRating frm = new frmMonthlyReportOfBorrowerRating();
            frm.MdiParent = this;
            frm.Show();
        }

        private void pendingItemREquesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfPendingItemsBorrowerRating frm = new frmMonthlyReportOfPendingItemsBorrowerRating();
            frm.MdiParent = this;
            frm.Show();
        }

        private void facilityReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfFacility frm = new frmMonthlyReportOfFacility();
            frm.MdiParent = this;
            frm.Show();
        }

        private void maturityControlOfActionPlanForCloseWatchOrWorseBorrowersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfActionPlanforCloseWatchOrBorrowers frm = new frmMonthlyReportOfActionPlanforCloseWatchOrBorrowers();
            frm.MdiParent = this;
            frm.Show();
        }

        private void overdueInstructionConditionForCorporateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMonthlyReportOfOverdueIntructionCondition frm = new frmMonthlyReportOfOverdueIntructionCondition();
            frm.MdiParent = this;
            frm.Show();
        }

        private void manageTransactionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTransaction frm = new frmTransaction();
            frm.MdiParent = this;
            frm.Show();
        }

        private void transaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTransactionQuery frm = new frmTransactionQuery();
            frm.MdiParent = this;
            frm.Show();
        }

        private void createStatementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmStatement frm = new frmStatement();
            frm.MdiParent = this;
            frm.Show();
        }

        private void statementQueryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmStatementList frm = new frmStatementList();
            frm.MdiParent = this;
            frm.Show();
        }

        private void uploadTransactionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUploadTransactions frm = new frmUploadTransactions();
            frm.MdiParent = this;
            frm.Show();
        }

        private void makeTransactionReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMakeReport frm = new frmMakeReport();
            frm.MdiParent = this;
            frm.Show();
        }

        private void agentTransactionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.fAgentTransactionReport = new frmAgentTransactionReport();
            this.fAgentTransactionReport.MdiParent = this;
            //fCreditInfo.fMain = this;
            this.fAgentTransactionReport.Show();
        }

        private void importEDPListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmImportEDPList frm = new frmImportEDPList();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void customerErrorListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                List<string> lst = new List<string>();
                frmListCustomerError frm = new frmListCustomerError("", lst);
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void finalizeCPADataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmFinalizeCPAData frm = new frmFinalizeCPAData();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();


            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }


        }

        private void customerCPAListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmCPAListCPA frm = new frmCPAListCPA();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void quaterlyHistoryOfProfitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmScreenReportProfit frm = new frmScreenReportProfit();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();

            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }

        }

        private void monthReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmScreenReportMonth frm = new frmScreenReportMonth();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void customerTransactionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmCustomerTransactionsReport frm = new frmCustomerTransactionsReport();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void customerProfitabilityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmCustomerProfitabilityReport frm = new frmCustomerProfitabilityReport();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void customerProfitabilityAnalysisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmCustomerProfitAnalysisReport frm = new frmCustomerProfitAnalysisReport();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void toolStripMenuCPA_Click(object sender, EventArgs e)
        {
            try
            {
                clsGetDataCombobox.Instance().LoadData();
                clsTemplateManager.Instance().CreateDirectory();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void createNewOLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmOLCreateOL frm = new frmOLCreateOL(null);
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void outstandingOLListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmOLOutstandingList frm = new frmOLOutstandingList();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void pendingListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmOLPendingForApproveList frm = new frmOLPendingForApproveList();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void historyOLListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmOLListOffshoreLoanHistory frm = new frmOLListOffshoreLoanHistory();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void createRepaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmOLCreateRepayment frm = new frmOLCreateRepayment();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void listRepaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmOLRepaymentList frm = new frmOLRepaymentList();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void importAccessFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmOLImportAccessFile frm = new frmOLImportAccessFile();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void reportToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            try
            {
                frmOLReport frm = new frmOLReport();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void tsbCreateApplicant_Click(object sender, EventArgs e)
        {
            frmLGCreateApplicant frm = new frmLGCreateApplicant();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void tsbCreateBeneficiary_Click(object sender, EventArgs e)
        {
            frmLGCreateBeneficiary frm = new frmLGCreateBeneficiary();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void tsbCreateReportForNonResidentApplicantLG_Click(object sender, EventArgs e)
        {
            frmLGCreateReportForNonResidentApplicantLG frm = new frmLGCreateReportForNonResidentApplicantLG();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void tsmAppliantList_Click(object sender, EventArgs e)
        {
            frmLGListApplicant frm = new frmLGListApplicant();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.Show();
        }

        private void beneficiaryListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmLGListBeneficiary frm = new frmLGListBeneficiary();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.Show();
        }

        private void tsmListOfFeeCollection_Click(object sender, EventArgs e)
        {
            frmLGListOfFeeCollection frm = new frmLGListOfFeeCollection();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.Show();
        }

        private void tsmLGListSup_Click(object sender, EventArgs e)
        {
            frmLGListLGSupervisor frm = new frmLGListLGSupervisor();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.Show();
        }

        private void tsmLGStaffList_Click(object sender, EventArgs e)
        {
            frmLGListLGStaff frm = new frmLGListLGStaff();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.Show();
        }

        private void tsmHistoryLGList_Click(object sender, EventArgs e)
        {
            frmLGListLGHistory frm = new frmLGListLGHistory();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.Show();
        }

        private void tsbIssueList_Click(object sender, EventArgs e)
        {
            if (clsLGWorkSpace.Instance().FrmIssue == null || clsLGWorkSpace.Instance().FrmIssue.IsDisposed)
            {
                clsLGWorkSpace.Instance().FrmIssue = new frmLGIssue();
                clsLGWorkSpace.Instance().FrmIssue.StartPosition = FormStartPosition.CenterScreen;
                clsLGWorkSpace.Instance().FrmIssue.MdiParent = this;
                clsLGWorkSpace.Instance().FrmIssue.Show();
            }
            else
            {
                clsLGWorkSpace.Instance().FrmIssue.Visible = true;
                clsLGWorkSpace.Instance().FrmIssue.Show();
                clsLGWorkSpace.Instance().FrmIssue.BringToFront();
            }
        }

        private void tsmLGReport_Click(object sender, EventArgs e)
        {
            frmLGListReportForNonResidentApplicantLG frm = new frmLGListReportForNonResidentApplicantLG();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.Show();
        }

        private void reconsileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmLGReconcileData frm = new frmLGReconcileData();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void reconcileSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmLGReconcileSummary frm = new frmLGReconcileSummary();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        // Quan Add 20130610

        private void listUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMDUserListView frm = new frmMDUserListView();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void listTeamToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMDTeamListView frm = new frmMDTeamListView();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void listDepartmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMDDepartmentListView frm = new frmMDDepartmentListView();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void roleManagementToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmSecurityRoleManagement frm = new frmSecurityRoleManagement();
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void menuManagementToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmSecurityMenuManagement frm = new frmSecurityMenuManagement();
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void functionManagementToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmSecurityFnManagement frm = new frmSecurityFnManagement();
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void assignRoleToUserToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmSecurityAssignRoleToUser frm = new frmSecurityAssignRoleToUser();
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void assignRightToRoleToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmSecurityAssignRightToRole frm = new frmSecurityAssignRightToRole();
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void assignMenuToRoleToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmSecurityAssignMenuToRole frm = new frmSecurityAssignMenuToRole();
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void externalLogToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmCOMManageExternalLog frm = new frmCOMManageExternalLog();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void transactionLogToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmCOMViewTransactionLog frm = new frmCOMViewTransactionLog();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void smileOperationLogToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (m_SmileViewLog == null || m_SmileViewLog.IsDisposed)
            {
                m_SmileViewLog = new frmAllSmileViewLog();
                m_SmileViewLog.MdiParent = this;
                m_SmileViewLog.StartPosition = FormStartPosition.CenterParent;
                m_SmileViewLog.Show();
            }
            else
            {
                m_SmileViewLog.Visible = true;
                m_SmileViewLog.Activate();
            }
        }

        private void importQuotationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmMDImportQuotation frm = new frmMDImportQuotation();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            //2013.05.16 UDP vlhcnhung S After import, call View Maker
            frm.OnAfterImported += new EventHandler(frm.ShowViewMakerOnAfterImported);
            //2013.05.16 UDP vlhcnhung E After import, call View Maker
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void dayOffRegistToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMDCurrencyHoliday frm = new frmMDCurrencyHoliday();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void previewQuotationTemplateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDPreviewQuoationDetail frm = new frmMDPreviewQuoationDetail();
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (!frm.IsDisposed)
                {
                    if (frm.QuotationId > 0)
                    {
                        frm.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void processingDailyQuotationMakerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMDProcessingDailyQuotation frm = new frmMDProcessingDailyQuotation((int)CommonValue.QuotationRole.Maker);
            //2013.05.16 UDP vlhcnhung S After import, call View Maker
            frm.Text = clsMDConstant.PROCESSING_DAILY_QUOTATION_MAKER;
            //2013.05.16 UDP vlhcnhung E After import, call View Maker
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void processingDailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMDProcessingDailyQuotation frm = new frmMDProcessingDailyQuotation((int)CommonValue.QuotationRole.Approver);
            //2013.05.16 UDP vlhcnhung S After import, call View Maker
            frm.Text = clsMDConstant.PROCESSING_DAILY_QUOTATION_APPROVER;
            //2013.05.16 UDP vlhcnhung E After import, call View Maker
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void currencyInToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMDCurrencyInquiryQuotationHistory frm = new frmMDCurrencyInquiryQuotationHistory();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void inquiryQuotationHistoryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmMDInquiryQuotationHistory frm = new frmMDInquiryQuotationHistory();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (!frm.IsDisposed)
            {
                frm.Show();
            }
        }

        private void createCeilingFloorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDAddModifyCeilingFloor frm = new frmMDAddModifyCeilingFloor();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (!frm.IsDisposed)
                {
                    frm.Show();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void listCeilingFloorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMasListCeilingFloor frm = new frmMasListCeilingFloor();
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (!frm.IsDisposed)
                {
                    frm.Show();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void createToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDAddModifyThreshold frm = new frmMDAddModifyThreshold();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (!frm.IsDisposed)
                {
                    frm.Show();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void listThresholdToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDListThreshold frm = new frmMDListThreshold();
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (!frm.IsDisposed)
                {
                    frm.Show();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }
        }

        private void customerInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCustomerInfo frm = new frmCustomerInfo();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void tsbProcessingBoardRateMaker_Click(object sender, EventArgs e)
        {
            //show form Board Rate Maker
            frmMDProcessingBoardRateMaker frm = new frmMDProcessingBoardRateMaker();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void tsbProcessingBoardRateApprover_Click(object sender, EventArgs e)
        {
            //show form Board Rate Approver
            frmMDProcessingBoardRateApprover frm = new frmMDProcessingBoardRateApprover();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void tsbInquiryBoardRateHistory_Click(object sender, EventArgs e)
        {
            //show form Inquiry Board Rate History
            frmMDInquiryBoardRateHistory frm = new frmMDInquiryBoardRateHistory();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void tsbCurrencyInquiryBoardRateHistory_Click(object sender, EventArgs e)
        {
            //show form Currency Inquiry Board Rate History
            frmMDCurrencyInquiryBoardRateHistory frm = new frmMDCurrencyInquiryBoardRateHistory();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void tsbPreviewBRsTemplate_Click(object sender, EventArgs e)
        {
            //show form Preview Board Rate Template
            frmMDPreviewBoardRate frm = new frmMDPreviewBoardRate();
            frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void createSBVMInMaxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDAddModifySBVMinMax frm = new frmMDAddModifySBVMinMax();
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }            
        }

        private void listSBVMinMaxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDListSBVMinMax frm = new frmMDListSBVMinMax();
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }      
        }

        private void createPrefixTDNoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDAddModifyPrefixTDNo frm = new frmMDAddModifyPrefixTDNo();
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }      
        }

        private void listPrefixTDNoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDListPrefixTDNo frm = new frmMDListPrefixTDNo();
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }      
        }

        private void createDefaultRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDAddModifyDefaultRate frm = new frmMDAddModifyDefaultRate();
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }      
        }

        private void listDefaultRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDListDefaultRate frm = new frmMDListDefaultRate();
                frm.MdiParent = this;
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.Show();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message);
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
            }      
        }
        // End
    }
}