﻿namespace BTMU_HCM_SYS
{
    partial class frmDBManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDBManagement));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCurrSetting = new System.Windows.Forms.TextBox();
            this.txtNewSetting = new System.Windows.Forms.TextBox();
            this.cbDB = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btGet = new System.Windows.Forms.Button();
            this.btUpdate = new System.Windows.Forms.Button();
            this.btClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Current settings";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 203);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "New settings";
            // 
            // txtCurrSetting
            // 
            this.txtCurrSetting.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCurrSetting.Location = new System.Drawing.Point(106, 59);
            this.txtCurrSetting.Multiline = true;
            this.txtCurrSetting.Name = "txtCurrSetting";
            this.txtCurrSetting.Size = new System.Drawing.Size(328, 125);
            this.txtCurrSetting.TabIndex = 2;
            // 
            // txtNewSetting
            // 
            this.txtNewSetting.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNewSetting.Location = new System.Drawing.Point(106, 203);
            this.txtNewSetting.Multiline = true;
            this.txtNewSetting.Name = "txtNewSetting";
            this.txtNewSetting.Size = new System.Drawing.Size(328, 125);
            this.txtNewSetting.TabIndex = 3;
            // 
            // cbDB
            // 
            this.cbDB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbDB.FormattingEnabled = true;
            this.cbDB.Items.AddRange(new object[] {
            "BTMU_HCM DataBase"});
            this.cbDB.Location = new System.Drawing.Point(106, 19);
            this.cbDB.Name = "cbDB";
            this.cbDB.Size = new System.Drawing.Size(154, 21);
            this.cbDB.TabIndex = 4;
            this.cbDB.SelectedIndexChanged += new System.EventHandler(this.cbDB_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "DataBase";
            // 
            // btGet
            // 
            this.btGet.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btGet.Location = new System.Drawing.Point(106, 353);
            this.btGet.Name = "btGet";
            this.btGet.Size = new System.Drawing.Size(75, 23);
            this.btGet.TabIndex = 6;
            this.btGet.Text = "Get";
            this.btGet.UseVisualStyleBackColor = true;
            this.btGet.Click += new System.EventHandler(this.btGet_Click);
            // 
            // btUpdate
            // 
            this.btUpdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btUpdate.Location = new System.Drawing.Point(232, 353);
            this.btUpdate.Name = "btUpdate";
            this.btUpdate.Size = new System.Drawing.Size(75, 23);
            this.btUpdate.TabIndex = 7;
            this.btUpdate.Text = "Update";
            this.btUpdate.UseVisualStyleBackColor = true;
            this.btUpdate.Click += new System.EventHandler(this.btUpdate_Click);
            // 
            // btClose
            // 
            this.btClose.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btClose.Location = new System.Drawing.Point(358, 353);
            this.btClose.Name = "btClose";
            this.btClose.Size = new System.Drawing.Size(75, 23);
            this.btClose.TabIndex = 8;
            this.btClose.Text = "Close";
            this.btClose.UseVisualStyleBackColor = true;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // frmDBManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(456, 388);
            this.Controls.Add(this.btClose);
            this.Controls.Add(this.btUpdate);
            this.Controls.Add(this.btGet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbDB);
            this.Controls.Add(this.txtNewSetting);
            this.Controls.Add(this.txtCurrSetting);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmDBManagement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DataBase Management";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCurrSetting;
        private System.Windows.Forms.TextBox txtNewSetting;
        private System.Windows.Forms.ComboBox cbDB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btGet;
        private System.Windows.Forms.Button btUpdate;
        private System.Windows.Forms.Button btClose;
    }
}