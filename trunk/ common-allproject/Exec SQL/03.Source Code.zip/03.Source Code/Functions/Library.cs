﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Functions
{
    public class Library
    {
        public static bool try_to_convert_to_bool(string input)
        {
            try
            {
                bool result = bool.Parse(input);
                return result;


            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public static decimal tryToConvertToDecimal(string temp)
        {
            try
            {
                 decimal result = decimal.Parse(temp);
                 return result;


            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        public static decimal tryToConvertToDecimalIfnotReturnTru1(string temp)
        {
            try
            {
                decimal result = decimal.Parse(temp);
                return result;


            }
            catch (Exception ex)
            {
                return -1;
            }
        }
        public static DateTime tryToConvertToDate(string temp)
        {
            try
            {
                DateTime result = DateTime.Parse(temp);
                return result;


            }
            catch (Exception ex)
            {
                return DateTime.MinValue;

            }
        }
        public static DateTime tryToConvertToDateIfNotReturnMaxValue(string temp)
        {
            try
            {
                DateTime result = DateTime.Parse(temp);
                return result;


            }
            catch (Exception ex)
            {
                return DateTime.MaxValue;

            }
        }
        public static long tryToConvertTolong(string temp)
        {
            try
            {
                long result = long.Parse(temp);
                return result;


            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        public static string GetRepeatedTabStringWithTimes(int time)
        {
            

            string result = "";
            for (int i = 0; i < time; i++)
            {
                result = result + "\t";

            }
            return result;
       }
        public static bool CheckAApplicationOpen(string name)
        {
            try
            {
                Process[] app = System.Diagnostics.Process.GetProcessesByName(name);
                if (app != null)
                {
                    if (app.Length > 1)
                    {
                        return true;
                    }
                    else
                    {
                        return false;

                    }
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

      
        public static bool TryToDeleteAFile(string filePath)
        {
            try
            {

                File.Delete(filePath);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public static string GetSelectFormatComandForDate(DateTime date)
        {



            string temp = "";
            temp = "#" + date.ToShortDateString() + "#";
            return temp;


        }
        public static string GetInsertStrFromStrForUnicodeStrInSQL(decimal strInsert)
        {

            return strInsert.ToString();


        }
        public static string GetInsertStrFromStrForUnicodeStrInSQL(long strInsert)
        {

            return strInsert.ToString();


        }
        public static string GetInsertStrFromStrForUnicodeStrInSQL(string strInsert)
        {
            strInsert = strInsert.Replace("'", "''");
            strInsert = "N'" + strInsert + "'";
            strInsert = strInsert.Trim();
            return strInsert;

        }
        public static string GetInsertStrFromStrForUnicodeStrInSQL(bool bInput)
        {
            string strInsert = bInput.ToString();
            strInsert = strInsert.Replace("'", "''");
            strInsert = "N'" + strInsert + "'";
            strInsert = strInsert.Trim();
            return strInsert;

        }
        public static string GetInsertStrFromStrForUnicodeStrInSQL(DateTime bInput)
        {
            string strInsert = bInput.ToString();
            strInsert = strInsert.Replace("'", "''");
            strInsert = "N'" + strInsert + "'";
            strInsert = strInsert.Trim();
            if (bInput == DateTime.MaxValue)
            {
                return "null";
            }
            return strInsert;

        }
        public static string GetInsertStrFromStr(string strInsert)
        {



            strInsert = strInsert.Replace("'", "''");
            strInsert = "'" + strInsert + "'";
            strInsert = strInsert.Trim();
            return strInsert;

        }
        public static bool CheckFileExists(string fileName)
        {
            try
            {
                return File.Exists(fileName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //start nay gia dinh index bat dau=1
        //   A 
        //de lay A thi phai la Library.GetSubstring(allLines[i], 4, 5) == "A"
        //4 la vi tri bat dau lay 
        //5 la vi tri ket thuc lay
        public static string MoveSubtractSignFromEndOfStrToBeGinOfStr(string strInput)
        {
            string result = strInput;
            if (result.Length > 0)
            {
                if (result[result.Length - 1] == '-')
                {
                    result = strInput.Substring(strInput.Length - 1, 1) + strInput.Substring(0, strInput.Length - 1);
                }

            }
            return result;


        }
        public static string GetSubstring(string pInput, int start, int end)
        {
            //luu y start la vi tri bat dau tinh tu 1
            

            string result = "";
            try
            {

              
                if (pInput.Length < end)
                {
                    result = "";
                }
                if (pInput.Length >= end - 1)
                {
                    result = pInput.Substring(start - 1, end - start);
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;

            }

        }
        public static string GetInputFileName(string prefix, DateTime date,string pExtention)
        {
            string result = "";
            try
            {
                result = prefix + date.ToString("yy-MM-dd");
                result = result + pExtention;
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
        public static string GetOutputFileName(string prefix, DateTime date)
        {
            string result = "";
            try
            {

                result = prefix + date.ToString("yy-MM-dd");
                result = result + " OUT";
                return result;
            }
            catch(Exception ex)
            {
                throw ex;

            }


        }
        public static string ReturnAStringWithWhiteSpaceAtBeginOfString(string pInput, int length)
        {
            string outPut = pInput;
            try
            {
                if (length > pInput.Length)
                {
                    for (int i = pInput.Length; i < length; i++)
                    {
                        outPut = " "+ outPut;

                    }

                }
                return outPut;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public static string ReturnAStringWithHight(string pInput, int length)
        {
            string outPut = pInput;
            try
            {
                if (length > pInput.Length)
                {
                    for (int i = pInput.Length; i < length; i++)
                    {
                        outPut = outPut + " ";

                    }

                }
                return outPut;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
