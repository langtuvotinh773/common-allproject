﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Functions
{
    public class ExtensiveString
    {
       
        public static string GetSubStringFromBiGinWithLength(string _input, int _leng)
        {
            string result = _input;
            if (_input.Length > _leng)
            {
                result = _input.Substring(0, _leng);

            }
            return result;

        }
        public static string BoTatCaCacKyTuTrongMotChuoi(string _cacKyTuCanBo, string _chuoiCha)
        {
            string temp1 = _chuoiCha;
            if (_cacKyTuCanBo.Length > 0)
            {
                for (int i = 0; i < _cacKyTuCanBo.Length; i++)
                {
                    temp1 = temp1.Replace(_cacKyTuCanBo[i].ToString(), "");

                }
            }
            return temp1;

        }
        public static string MakeBeginCharacterToUpper(string pInput)
        {
            string result=pInput.ToLower();
            if (result.Length > 1)
            {
                string phanDau = pInput.Substring(0, 1);
                string panSau = pInput.Substring(1, pInput.Length - 1);
                result = phanDau.ToUpper() + panSau.ToLower();
                


            }
            if (result.Length == 1)
            {
                pInput=pInput.ToUpper();

            }
            return result;

        }
    }
}
