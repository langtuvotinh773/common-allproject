﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Functions
{
    public class NumberLibarary
    {

      

        public static string GetZeroDesFromNumberString(string pInput, ref string pVND, ref string pENG, int donViChaBangBaoNhieuDonViCon)
        {
            pVND = "";
            pENG = "";
            if (pInput.Length == 1)
            {
                if (pInput[0] != '0')
                {
                    pInput = pInput + "0";

                }
               
            }
            return pInput;
            
        }
        

        public static decimal GetPhanLeCuaMotSo(decimal pInput,ref string vnd,ref string eng)
        {
            decimal result = 0;
            string temp = pInput.ToString();
            int viTridauCham = temp.IndexOf('.');
            if (viTridauCham > 0 && viTridauCham < temp.Length)
            {
                string viTriSauDauCham = temp.Substring(viTridauCham + 1, temp.Length - viTridauCham - 1);
                result = TryToConvertToDecimalIfCannotReturn0(viTriSauDauCham);
                if (result > 0 && result < 10 && viTriSauDauCham.Length==1)
                {
                    
                    result = result * 10;
                   

                }
            }
            
            
            return result;
        }
        public static decimal LayPhanDauCuaMotSoThapPhan(decimal pInput)
        {
            decimal result = 0;
            string temp = pInput.ToString();
            int viTridauCham = temp.IndexOf('.');
            if (viTridauCham > 0 && viTridauCham < temp.Length)
            {
                string viTriSauDauCham = temp.Substring(0, viTridauCham);
                result = TryToConvertToDecimalIfCannotReturn0(viTriSauDauCham);
            }
            else
            {
                result = pInput;
            }

            return result;
        }
        public static decimal TryToConvertToNumber(string strNum)
        {
            decimal result = -1;
            try
            {
                result = int.Parse(strNum);
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }

        }
        public static decimal TryToConvertToDecimalIfCannotReturn0(string strNum)
        {
            decimal result = -1;
            try
            {
                result = decimal.Parse(strNum);
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }

        }
        public static decimal TryToConvertToDecimalIfCannotReturn0_TRue_for_CIC_report(string strNum)
        {
            if (strNum == null)
            {
                return -1;
            }
            decimal result = 0;
            try
            {
                result = decimal.Parse(strNum);
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }

        }
       
        public static decimal TryToConvertToDecimalIfCannotReturn0_TRue(string strNum)
        {
            decimal result = 0;
            try
            {
                result = decimal.Parse(strNum);
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }

        }
        public static int TryToConvetToInt(string strNum)
        {
            int result = -1;
            try
            {
                result = int.Parse(strNum);
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }

        }
        public static long TryToConvetToLong(string strNum)
        {
            long result = 0;
            try
            {
                result = long.Parse(strNum);
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }

        }
        public static int TryToConvetToIntIfCannotReturn(string strNum)
        {
            int result = 0;
            try
            {
                result = int.Parse(strNum);
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }

        }
    }
}
