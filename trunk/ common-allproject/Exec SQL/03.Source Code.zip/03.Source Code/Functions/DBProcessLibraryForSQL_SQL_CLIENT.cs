﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Sql;
using System.Data;
using System.Data.SqlClient;
using System.Collections;


 namespace Functions
{
     public class DBProcessLibraryForSQL_SQL_CLIENT
    {

        public SqlConnection connect = new SqlConnection();
      
        public SqlDataAdapter adapter = new SqlDataAdapter();

        public void InsertInLogExecutePro(string procedureName, string source, string username)
        {
            try
            {

                ArrayList arrEmpty = new ArrayList();

                InsertInLogExecutePro(procedureName, arrEmpty,source, username);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void InsertInLogExecutePro(string procedureName, ArrayList list_para, string source,string username)
        {
            try
            {

                string logItem = "Execute procedure:\"" + procedureName + "\" with parameters::::";
                foreach (SqlParameter meter in list_para)
                {
                    logItem = logItem + meter.ParameterName + "=" + meter.Value + ";";

                }
                string command = "insert into [ACTIVITY_LOGS]([Source],[Log_item],Date_update,User_Name) values(";
                command = command + Functions.Library.GetInsertStrFromStrForUnicodeStrInSQL(source) + "," + Functions.Library.GetInsertStrFromStrForUnicodeStrInSQL(logItem) + "," + "Getdate()" + "," + Functions.Library.GetInsertStrFromStrForUnicodeStrInSQL(username) + ")";
                ExecuteOleCommand(command);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void InsertErrorLog(string logItem, string source,string userName)
        {
            try
            {
                string command = "insert into [Error_log]([Source],[Log_item],Date_update,User_Name) values(";

                command = command + Functions.Library.GetInsertStrFromStrForUnicodeStrInSQL(source) + "," + Functions.Library.GetInsertStrFromStrForUnicodeStrInSQL(logItem) + "," + "Getdate()" + "," + Functions.Library.GetInsertStrFromStrForUnicodeStrInSQL(userName) + ")";
                ExecuteOleCommand(command);
            }
            catch (Exception ex)
            {
                throw ex;

            }

        }
        public void InsertIntoLogTableLOGS_ACTIVITY(string logItem, string source, string userName)
        {
            try
            {
                string command = "insert into [ACTIVITY_LOGS]([Source],[Log_item],Date_update,User_Name) values(";
                command = command + Functions.Library.GetInsertStrFromStrForUnicodeStrInSQL(source) + "," + Functions.Library.GetInsertStrFromStrForUnicodeStrInSQL(logItem) + "," + "Getdate()" + "," + Functions.Library.GetInsertStrFromStrForUnicodeStrInSQL(userName) + ")";
                ExecuteOleCommand(command);
            }
            catch (Exception ex)
            {
                InsertErrorLog(ex.ToString(), source,userName);
            }

        }
       
        public string GetValueFromDs(DataTable ds, string columnName, string keyValue, string keyColumn)
        {
            

            string result = "";
            try
            {
                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Rows)
                    {

                        if (row[columnName].ToString().ToUpper() == keyValue.Trim().ToUpper())
                        {
                            result = row[keyColumn].ToString();

                        }
                    }


                }


                return result;

            }
            catch (Exception ex)
            {

                throw ex;

            }

        }
     
        public decimal GetMaxValueFromACollumnOfATable(string table, string column)
        {
            decimal result = 0;
            try
            {
                string command = "select max(" + column + ") as MaxValue from " + table;
                DataSet ds = this.GetDataFromComamnd(command);
                result = Functions.NumberLibarary.TryToConvertToDecimalIfCannotReturn0(Functions.DBProcessLibrary.GetValueFromDs(ds, "MaxValue"));
                return result;
            }
            catch (Exception ex)
            {
                //   MessageLibrary.ShowErrorMessage("GetMaxValueFromACollumnOfATable", "", ex.ToString());
                throw ex;
                return result;
            }
        }
   
        public void ExecuteOleCommand(string strCommand)
        {
            ExecuteOleCommand(strCommand, true);
        }
        public void ExecuteOleCommand(string strCommand,bool withThrowExceptionOrNot)
        {
            try
            {

                SqlCommand command = new SqlCommand();
                command.Connection = connect;
                command.CommandText = strCommand;
                command.CommandTimeout = 0;
                command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                if (withThrowExceptionOrNot == true)
                {
                    throw ex;
                }
            }
        }
        public DataSet GetDataFromComamnd(string command)
        {
            DataSet result = new DataSet();
            try
            {
                SqlDataAdapter Sql = new SqlDataAdapter(command, connect);
                Sql.SelectCommand.CommandTimeout = 0;
                Sql.Fill(result);
                return result;
                

            }
            catch (Exception ex)
            {


                throw ex;

            }
        
        }
        public string GetValueFromDs(DataSet ds,string columnName)
        {

            string result = "";
            try
            {
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                                           


                        result = ds.Tables[0].Rows[0][columnName].ToString();


                    }
                    
                }
                return result;

            }
            catch (Exception ex)
            {

                throw ex;

            }

        }
        public bool CheckARowExistWithACommand(string command)
        {
            try
            {
                DataSet ds = GetDataFromComamnd(command);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        return true;
                    }
                }
                return false;
              
            }
            catch (Exception ex)
            {
                throw ex;


            }

        }
        public void SelectDataFromProcWithNotPara(String ProcedureName, ref DataTable dataOutput)
        {
            try
            {
                SqlCommand command = new SqlCommand();
                command = new SqlCommand();
                command.CommandText = ProcedureName;
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = this.connect;
                this.adapter = new SqlDataAdapter(command);
                this.adapter.Fill(dataOutput);


            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        public void SelectDataFromProc(String ProcedureName, ArrayList arrParameters, ref DataTable dataOutput)
        {
            try
            {
                SqlCommand command = new SqlCommand();
            command = new SqlCommand();
            command.CommandText = ProcedureName;
            command.CommandType = CommandType.StoredProcedure;
            int n = arrParameters.Count;
               SqlDataAdapter adapter2 = new SqlDataAdapter();

            for (int i = 0; i < n; i++)
                command.Parameters.Add((SqlParameter)arrParameters[i]);
            
                command.Connection = this.connect;
                adapter2 = new SqlDataAdapter(command);
                adapter2.Fill(dataOutput);


            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        public void Execute_procedure_with_not_Parameters(String ProcedureName)
        {
            try
            {
                SqlCommand command = new SqlCommand();

                command = new SqlCommand();
                command.CommandText = ProcedureName;
                command.CommandType = CommandType.StoredProcedure;
               command.Connection = this.connect;
                command.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                throw ex;

            }

        }
     
        public void Execute_procedure_with_Parameters(String ProcedureName, ArrayList arrParameters)
        {
            try
            {
                SqlCommand command = new SqlCommand();
               
                command = new SqlCommand();
                command.CommandText = ProcedureName;
                command.CommandType = CommandType.StoredProcedure;
                int n = arrParameters.Count;
                for (int i = 0; i < n; i++)
                    command.Parameters.Add((SqlParameter)arrParameters[i]);
                command.Connection = this.connect; 
                command.ExecuteNonQuery();
             
               
            }
            catch (Exception ex)
            {
                throw ex;

            }
            
        }
      

        public bool Open(string strConnect)
        {
            try
            {
                connect = new SqlConnection();
                connect.ConnectionString = strConnect;
                connect.Open();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;


            }

        }

       

    }
}
