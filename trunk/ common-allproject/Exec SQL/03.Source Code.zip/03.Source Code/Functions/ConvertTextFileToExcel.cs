﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace Functions
{
    public class ConvertTextFileToExcel
    {
        public static void EndAndSaveAs(string[] allLineToOutput, string outPutPath)
        {
            int length = 0;
            for (int i = 0; i < allLineToOutput.Length; i++)
            {
                if (allLineToOutput[i].Trim().Replace("\t", "") == "")
                {
                    length = i + 1;
                    break;

                }
            }
            string[] temp = new string[length];
            for (int i = 0; i < length; i++)
            {
                temp[i] = allLineToOutput[i];

            }
            File.WriteAllLines(outPutPath, temp);

        }
        public static void StandardStringArray(string[] allLinesToOutput, string valueBetween, int columnCount)
        {
            for (int i = 0; i < allLinesToOutput.Length; i++)
            {
                allLinesToOutput[i] = StandardLineString(allLinesToOutput[i], valueBetween, columnCount);

            }
        }
        public static string StandardLineString(string intPutStr, string valueBetweenStr, int columnCount)
        {
            for (int i = 0; i < columnCount - 1; i++)
            {
                intPutStr = intPutStr + valueBetweenStr + '\t';

            }
            intPutStr = intPutStr + valueBetweenStr;
            return intPutStr;

        }

        public static void SetValueToACellInASheet(string[] allLinesToOutput, int sheetNumber, int row, int column, string value)
        {
            string newRowValue = "";
            string[] allColumn = allLinesToOutput[row - 1].Split(new char[] { '\t' });
            if (allColumn.Length > column)
            {
                allColumn[column - 1] = value;
            }
            int i = 0;
            for (i = 0; i < allColumn.Length - 1; i++)
            {
                newRowValue = newRowValue + allColumn[i] + "\t";
            }
            newRowValue = newRowValue + allColumn[i];
            allLinesToOutput[row - 1] = newRowValue;

        }
    }
}
