﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
namespace Functions
{
    public class Currency
    {
        public static decimal GetTrueAmountToPrintOut(decimal pAmount, string list_currency, string pcurrency)
        {
            decimal divideAmountForThis = 100.00M;
            if (list_currency.Contains(pcurrency) == true)
            {
                divideAmountForThis = 1.00M;
            }
            pAmount = pAmount / divideAmountForThis;
            return pAmount;
        }
        public static decimal GetTrueAmountInSmileSystem(decimal pAmount, string list_currency, string pcurrency)
        {
            decimal multipleby = 1.00M;
            if (list_currency.Contains(pcurrency) == false)
            {
                multipleby = 100.00M;
            }
            pAmount = pAmount * multipleby;
            return pAmount;
        }
        public static decimal Get_LIMIT_FOR_STATUS(DataTable CURRENCY_LIST,string pcurrency)
        {
            try
            {
                decimal result = 0;
                foreach (DataRow row in CURRENCY_LIST.Rows)
                {
                    if (row["CCY_CODE_NAME"].ToString() == pcurrency.Trim().ToUpper())
                    {
                        result=Functions.NumberLibarary.TryToConvertToDecimalIfCannotReturn0_TRue(row["LIMIT_FOR_STATUS"].ToString());
                        return result;

                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
                return 0;
            }

        }
    }
}
