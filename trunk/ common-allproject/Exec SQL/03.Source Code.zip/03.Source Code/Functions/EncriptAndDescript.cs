﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;
namespace Functions
{
    public class EncriptAndDescript
    {
        public static byte[] bytes = ASCIIEncoding.ASCII.GetBytes("btmu3640");

        public static string Encrypt(string originalString)
        {
            try
            {
                DESCryptoServiceProvider cryptoProvide = new DESCryptoServiceProvider();
                MemoryStream memoryStream = new MemoryStream();
                CryptoStream crypttoStream = new CryptoStream(memoryStream, cryptoProvide.CreateEncryptor(bytes, bytes), CryptoStreamMode.Write);
                StreamWriter write = new StreamWriter(crypttoStream);
                write.Write(originalString);
                write.Flush();
                crypttoStream.FlushFinalBlock();
                write.Flush();
                return Convert.ToBase64String(memoryStream.GetBuffer(),0, (int)memoryStream.Length);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string Descript(string cryptedString)
        {
            try
            {
                DESCryptoServiceProvider cryptoProvide = new DESCryptoServiceProvider();
                MemoryStream memoryStream = new MemoryStream(Convert.FromBase64String(cryptedString));
                CryptoStream cryptoStream = new CryptoStream(memoryStream, cryptoProvide.CreateDecryptor(bytes, bytes), CryptoStreamMode.Read);
                StreamReader reader = new StreamReader(cryptoStream);
                return reader.ReadToEnd();


          

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
