﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Odbc;
using System.Data;
using System.Data.OleDb;

 namespace Functions
{
    public class DBProcessLibrary
    {
        public static OleDbConnection connect = new OleDbConnection();
        public static void ExecuteOleCommand(string strCommand)
        {
            ExecuteOleCommand(strCommand, true);
        }
        public static decimal GetMaxValueFromACollumnOfATable(string table, string column)
        {
            decimal result = 0;
            try
                
            {
                string command = "select max(" + column + ") as MaxValue from " + table;
                DataSet ds = Functions.DBProcessLibrary.GetDataFromComamnd(command);
                result = Functions.NumberLibarary.TryToConvertToDecimalIfCannotReturn0(Functions.DBProcessLibrary.GetValueFromDs(ds, "MaxValue"));
                return result;
            }
            catch (Exception ex)
            {
             //   MessageLibrary.ShowErrorMessage("GetMaxValueFromACollumnOfATable", "", ex.ToString());
                throw ex;
                return result;
            }
        }
        public static decimal GetMaxValueFromInvoice(string _bokDat)
        {
            OleDbCommand command = new OleDbCommand();
            OleDbTransaction transaction = null;

            // Set the Connection to the new OleDbConnection.
            command.Connection = connect;
            // Open the connection and execute the transaction.
            try
            {
                // Start a local transaction

                transaction = connect.BeginTransaction(IsolationLevel.ReadCommitted);
             
                // Assign transaction object for a pending local transaction.
                command.Connection = connect;
                command.Transaction = transaction;
              
                decimal strInvoiceNum = 0;

                 DataSet result = new DataSet();
            
                command.CommandText="select max(" + "Invoice_no" + ") as MaxValue from " + "INVOICE_NUMBER_TABLE";

                OleDbDataAdapter odbc = new OleDbDataAdapter(command);
                odbc.Fill(result);
                strInvoiceNum = Functions.NumberLibarary.TryToConvertToDecimalIfCannotReturn0_TRue(Functions.DBProcessLibrary.GetValueFromDs(result, "MaxValue"));
             
                string strcommand = "";
             
                if (strInvoiceNum <= 0)
                {
                    strInvoiceNum = 1;
                }
                else
                {
                    strInvoiceNum = strInvoiceNum + 1;
                }
                strcommand = "insert into INVOICE_NUMBER_TABLE(Invoice_no,Invoice_date,Invoice_user_print)";
                strcommand = strcommand + " values(" + strInvoiceNum.ToString() + "," + _bokDat + ",'')";
                command.CommandText = strcommand;
                command.ExecuteNonQuery();

                transaction.Commit();
               
                return strInvoiceNum;

               
            }
            catch (Exception ex)
            {
                throw ex;
                try
                {
                    // Attempt to roll back the transaction.
                    transaction.Rollback();
                }
                catch
                {
                    // Do nothing here; transaction is not active.
                }
                return -1;

            }
            // The connection is automatically closed when the
            // code exits the using block.           
        }

        public static void ExecuteOleCommand(string strCommand,bool withThrowExceptionOrNot)
        {
            try
            {

                OleDbCommand command = new OleDbCommand();
                command.Connection = connect;
                command.CommandText = strCommand;
                command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                if (withThrowExceptionOrNot == true)
                {
                    throw ex;
                }
            }
        }
        public static DataSet GetDataFromComamnd(string command)
        {
            DataSet result = new DataSet();
            try
            {
                
                OleDbDataAdapter odbc = new OleDbDataAdapter(command, connect);
                odbc.Fill(result);
                return result;


            }
            catch (Exception ex)
            {


                throw ex;

            }
        
        }
        public static string GetValueFromDs(DataSet ds,string columnName)
        {

            string result = "";
            try
            {
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        result = ds.Tables[0].Rows[0][columnName].ToString();


                    }
                    
                }
                return result;

            }
            catch (Exception ex)
            {

                throw ex;

            }

        }
        public static string GetValueFromDs(DataTable ds, string columnName,string keyValue,string keyColumn)
        {

            string result = "";
            try
            {
                    if (ds.Rows.Count > 0)
                    {
                        foreach (DataRow row in ds.Rows)
                        {

                            if (row[columnName].ToString().ToUpper() == keyValue.Trim().ToUpper())
                            {
                                result = row[keyColumn].ToString();

                            }
                        }


                    }

               
                return result;

            }
            catch (Exception ex)
            {

                throw ex;

            }

        }
        public static bool CheckARowExistWithACommand(string command)
        {
            try
            {
                DataSet ds = GetDataFromComamnd(command);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        return true;
                    }
                }
                return false;
              
            }
            catch (Exception ex)
            {
                throw ex;


            }

        }
        public static bool Open(string strConnect)
        {
            try
            {
                connect.ConnectionString = strConnect;
                connect.Open();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;


            }

        }

       

    }
}
