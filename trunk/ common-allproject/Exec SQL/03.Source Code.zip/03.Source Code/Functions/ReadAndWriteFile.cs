﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;


namespace Functions
{
    public class ReadAndWriteFile
    {

        public static void WriteFile(ArrayList allOutputLines, string fileName, Encoding encode)
        {
            try
            {
                string[] outPut = new string[allOutputLines.Count];
                int i = 0;
                foreach (string item in allOutputLines)
                {
                    outPut[i++] = item;
                }
                ReadAndWriteFile.WriteFile(outPut, fileName, encode);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void WriteFile(string[] allLines,string filePath,Encoding encode)
        {

            try
            {
                
                File.WriteAllLines(filePath, allLines,encode);
            
            }
            catch (Exception ex)
            {
                throw ex;
               

            }

            
        }

        public static string[] ReadAllLine(string filePath)
        {
            string[] allLines;
            allLines = new string[0];

            try
            {
                allLines=File.ReadAllLines(filePath);
                return allLines;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
    }
}
