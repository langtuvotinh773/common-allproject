﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Functions
{
    public class DateTimeFucntions
    {
        public static string GetStrFromDate(DateTime time)
        {
            string result = "";
            string strdate="";
            strdate=time.ToLongDateString();
            strdate=strdate.Replace("\\","-");
            strdate=strdate.Replace("/","-");
            strdate=strdate.Replace(":","-");
            strdate = strdate.Replace(",", "-");
            string strTime = time.ToLongTimeString();
            strTime = strTime.Replace("\\", "-");
            strTime = strTime.Replace("/", "-");
            strTime = strTime.Replace(":", "-");
            return strdate + " " + strTime;
                       
        

            
        }
       
        public static DateTime TryToConvertToDateTimeWithYearMonthDate(int year,int month,int date_in_month)
        {
            try
            {

                DateTime date = new DateTime(year, month, date_in_month);
                return date;


            }
            catch
            {
                return DateTime.MinValue;
            }
                 
        }
        public static string Get2CharacterAtTheEndOfTheYear(string strInput)
        {
            string temp = "";

            try
            {
                if (strInput.Trim().Length == 8)
                {
                    temp = strInput.Substring(2, 2);
                }
                return temp;


            }
            catch (Exception ex)
            {
               
                return temp;

            }
        }
       


        public static string ConvertFromBokDatFormatToCommonDateTimeYYYYMMDD(string strInput)
        {
            string temp = "";

            try
            {
                if (strInput.Trim().Length == 8)
                {
                    temp = strInput.Substring(0, 4) + "/" + strInput.Substring(4, 2) + "/" + strInput.Substring(6, 2);
                }
                return temp;


            }
            catch (Exception ex)
            {
                throw ex;
                return temp;

            }
        }
        public static string ConvertDateTimeToMMM_dd_yyyy(DateTime dt)
        {
            return dt.ToString("MMM dd, yyyy");
        }
        public static string ConvertFromBokDatFormatToCommonDateTimeDDMMYYYY(string strInput)
        {
            string temp = "";

            try
            {
                if (strInput.Trim().Length == 8)
                {
                    temp = strInput.Substring(6, 2)+ "/" + strInput.Substring(4, 2) + "/"+ strInput.Substring(0, 4) ;
                }
                return temp;


            }
            catch (Exception ex)
            {
                throw ex;
                return temp;

            }
        }
    }
}
