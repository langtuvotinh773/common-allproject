﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Functions
{
    public class ChuyenSoSangChu
    {
        public static string N2C(int pNumber)
        {
            switch (pNumber)
            {
                case 1:
                    return "một";
                case 2:
                    return "hai";
                case 3:
                    return "ba";
                case 4:
                    return "bốn";
                case 5:
                    return "năm";
                case 6:
                    return "sáu";
                case 7:
                    return "bảy";
                case 8:
                    return "tám";
                case 9:
                    return "chín";
            }
            return "";
        }        
        public static string N2CHoa(string ChuoiSoDau)
        {
            if (ChuoiSoDau.Contains("một"))
                return "Một";
            else if (ChuoiSoDau.Contains("hai"))
                return "Hai";
            else if (ChuoiSoDau.Contains("ba"))
                return "Ba";
            else if (ChuoiSoDau.Contains("bốn"))
                return "Bốn";
            else if (ChuoiSoDau.Contains("năm"))
                return "Năm";
            else if (ChuoiSoDau.Contains("sáu"))
                return "Sáu";
            else if (ChuoiSoDau.Contains("bảy"))
                return "Bảy";
            else if (ChuoiSoDau.Contains("tám"))
                return "Tám";
            else if (ChuoiSoDau.Contains("chín"))
                return "Chín";
            else if (ChuoiSoDau.Contains("mười"))
                return "Mười";

            //case 4:
            //    return "Bốn";
            //case 5:
            //    return "Năm";
            //case 6:
            //    return "Sáu";
            //case 7:
            //    return "Bảy";
            //case 8:
            //    return "Tám";
            //case 9:
            //    return "Chín";

            return "";
        }
        public static string parseNumber(int pNumber, long pMoney,int level,ref int hang_chuc)
        {
            string str = "";
            int tram, chuc, donvi;
            tram = (int)(pNumber / 100);
            pNumber = pNumber % 100;
            chuc = (int)(pNumber / 10);
            hang_chuc = chuc;
            donvi = pNumber % 10;

            if (tram != 0)
                str += N2C(tram) + " trăm";
            switch (chuc)
            {
                case 0:
                    if (tram != 0)
                    {
                        if (donvi != 0)
                            str += " lẻ " + N2C(donvi);
                    }
                    else
                        if (donvi != 0)
                           str += " " + N2C(donvi);
                                                      
                    break;
                case 1:
                    str += " mười ";
                    if (donvi == 5)
                        str += " lăm";
                    else
                        str += N2C(donvi);
                    break;
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                    str += " " + N2C(chuc) + " mươi ";
                    if (donvi == 1)
                        str += "mốt";
                    else
                    {
                        if (donvi == 5)
                            str += "lăm";
                        else
                            str += N2C(donvi);
                    }
                    break;
            }
            return str;
        }
        public static string DoiChuoi(long pMoney)
        {
            
            string str = "";
            int hang_chuc = 0;
            string str_le = "";
            long money = (long)pMoney;
            long le = money % 1000;
            money = (long)(money / 1000);//ngan
            long money_level2 = (long)(money / 1000);//trieu
            long money_level3 = (long)(money / 1000000);//ti
         

            if (le != 0)
            {
                str = parseNumber((int)le, pMoney, 0, ref hang_chuc);
            }
            if (money != 0)
            {
                //nho hon mot tram
                if (le < 100 && le != 0)
                {
                    str_le = "";
                    if (money > 0 && hang_chuc == 0)
                    {
                        str_le = " lẻ ";

                    }
                    str = "không trăm" + str_le + str;
                }
                
                le = money % 1000;
                money = (long)(money / 1000);
                if (le != 0)
                    str = parseNumber((int)le, pMoney, 1, ref hang_chuc) + " nghìn " + str;
                if (money != 0)
                {
                    if (le < 100 && le != 0)
                    {
                        str_le = "";
                        if (money_level2 > 0 && hang_chuc == 0)
                        {
                            str_le = " lẻ ";

                        }
                        str = "không trăm" + str_le + str;
                    }
                    le = money % 1000;
                    money = (long)(money / 1000);
                    if (le != 0)
                        str = parseNumber((int)le, pMoney, 2, ref hang_chuc) + " triệu " + str;
                    if (money != 0)
                    {
                        if (le < 100 && le != 0)
                        {
                            str_le = "";
                            if (money_level3 > 0 && hang_chuc == 0)
                            {
                                str_le = " lẻ ";

                            }
                            str = "không trăm" + str_le + str;
                        }
                        le = money % 1000;
                        money = (long)(money / 1000);
                        if (le != 0)
                            str = parseNumber((int)le, pMoney, 3, ref hang_chuc) + " tỉ " + str;
                    }
                }
            }
            if (str.Length == 0)
                str = "không";

            str = str.Trim();

            // Vi edit 25/07/2007
            return (str.Substring(0, 1).ToUpper() + str.Substring(1, str.Length - 1));

        }
        public static string DoiChuoi(decimal pMoney)
        {
            try
            {
                decimal soTienLamTron = decimal.Round(pMoney, 0);
                long soTien = long.Parse(soTienLamTron.ToString());
                string resul= ChuyenSoSangChu.DoiChuoi(long.Parse(soTien.ToString()));
                return resul;
            }
            catch (Exception ex)
            {
                return "";

            }

        }

          

    }
}
