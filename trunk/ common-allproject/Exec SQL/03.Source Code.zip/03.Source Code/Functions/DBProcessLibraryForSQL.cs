﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Odbc;
using System.Data;


 namespace Functions
{
     public class DBProcessLibraryForSQL
    {

        public OdbcConnection connect = new OdbcConnection();
        public string GetValueFromDs(DataTable ds, string columnName, string keyValue, string keyColumn)
        {
            

            string result = "";
            try
            {
                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Rows)
                    {

                        if (row[columnName].ToString().ToUpper() == keyValue.Trim().ToUpper())
                        {
                            result = row[keyColumn].ToString();

                        }
                    }


                }


                return result;

            }
            catch (Exception ex)
            {

                throw ex;

            }

        }
     
        public decimal GetMaxValueFromACollumnOfATable(string table, string column)
        {
            decimal result = 0;
            try
            {
                string command = "select max(" + column + ") as MaxValue from " + table;
                DataSet ds = this.GetDataFromComamnd(command);
                result = Functions.NumberLibarary.TryToConvertToDecimalIfCannotReturn0(Functions.DBProcessLibrary.GetValueFromDs(ds, "MaxValue"));
                return result;
            }
            catch (Exception ex)
            {
                //   MessageLibrary.ShowErrorMessage("GetMaxValueFromACollumnOfATable", "", ex.ToString());
                throw ex;
                return result;
            }
        }
   
        public void ExecuteOleCommand(string strCommand)
        {
            ExecuteOleCommand(strCommand, true);
        }
        public void ExecuteOleCommand(string strCommand,bool withThrowExceptionOrNot)
        {
            try
            {

                OdbcCommand command = new OdbcCommand();
                command.Connection = connect;
                command.CommandText = strCommand;
                command.CommandTimeout = 0;
                command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                if (withThrowExceptionOrNot == true)
                {
                    throw ex;
                }
            }
        }
        public DataSet GetDataFromComamnd(string command)
        {
            DataSet result = new DataSet();
            try
            {
                OdbcDataAdapter odbc = new OdbcDataAdapter(command, connect);
                odbc.SelectCommand.CommandTimeout = 0;
                odbc.Fill(result);
                return result;


            }
            catch (Exception ex)
            {


                throw ex;

            }
        
        }
        public string GetValueFromDs(DataSet ds,string columnName)
        {

            string result = "";
            try
            {
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        result = ds.Tables[0].Rows[0][columnName].ToString();


                    }
                    
                }
                return result;

            }
            catch (Exception ex)
            {

                throw ex;

            }

        }
        public bool CheckARowExistWithACommand(string command)
        {
            try
            {
                DataSet ds = GetDataFromComamnd(command);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        return true;
                    }
                }
                return false;
              
            }
            catch (Exception ex)
            {
                throw ex;


            }

        }
        public bool Open(string strConnect)
        {
            try
            {
                connect = new OdbcConnection();
                connect.ConnectionString = strConnect;
                connect.Open();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;


            }

        }

       

    }
}
