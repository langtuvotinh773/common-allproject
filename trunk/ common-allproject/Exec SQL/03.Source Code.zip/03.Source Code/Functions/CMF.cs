﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Functions
{
    public class CMF
    {
         public static bool KiemTraXem1ChuoiCoChuaMotSoLuongSoLienTiepNaoHayKhong(string pInput, decimal soLuongSoLienTiep)
        {

             pInput = pInput.Trim();
             pInput=pInput.Replace(" ", "");
             if (pInput.Length < soLuongSoLienTiep)
            {
                return false;
            }
            else
            {
                if (pInput.Length > 0)
                {
                     for (int i = 0; i < pInput.Length; i++)
                     {
                        bool result = true;
                        int soLuongSoLienTiepDemDuoc = 0;
                        for (int j = i; j < i+soLuongSoLienTiep; j++)
                        {
                            if(j<pInput.Length)
                            {
                                soLuongSoLienTiepDemDuoc = soLuongSoLienTiepDemDuoc + 1;
                                if(Char.IsDigit(pInput[j])==false)
                                {
                                    result = false;
                                }
                            }
                        }
                        if (result == true && soLuongSoLienTiepDemDuoc >= soLuongSoLienTiep)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
         }
    }
}
