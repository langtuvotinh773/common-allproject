﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Excel;
using System.Collections;




/*
 *  m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(1));
                m_objRange = m_objSheet.get_Range("A1", "B1");
                m_objFont = m_objRange.Font;
                m_objFont.Bold = true;
 * /
 * 
 */
/*
 * 
                 m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(1));
                 m_objRange = m_objSheet.get_Range("k335", "k335");
                 m_objRange.Formula = "=SUM(K321:K328)";

*/


/*
 *       m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(1));
            m_objRange = m_objSheet.get_Range("D1", "D10");
            m_objRange.NumberFormat = "00000000";
         
 * */

 /*
  *    Excel.Worksheet mmm = (Worksheet)m_objSheets.Add(Type.Missing, Type.Missing, 1, XlSheetType.xlWorksheet);
            mmm.Name = "nam1";

            mmm = (Worksheet)m_objSheets.Add(Type.Missing, Type.Missing, 1, XlSheetType.xlWorksheet);
            mmm.Name = "na31231m1";
            mmm = (Worksheet)m_objSheets.Add(Type.Missing, Type.Missing, 1, XlSheetType.xlWorksheet);
            mmm.Name = "na312321m1";
            mmm = (Worksheet)m_objSheets.Add(Type.Missing, Type.Missing, 1, XlSheetType.xlWorksheet);
            mmm.Name = "na3213132m1";

  */






namespace Functions
{
    public class ExcelLibrary
    {

        //can tim hieu them ve format fomular va font cho mot o nao do
        //cac tao them sheet trong workbook

      
        
        
        private Excel.Application m_objExcel = null;
        private Excel.Workbooks m_objBooks = null;
        private Excel._Workbook m_objBook = null;
        private Excel.Sheets m_objSheets = null;
        private Excel._Worksheet m_objSheet = null;
        private Excel.Range m_objRange = null;
        private object m_objOpt = System.Reflection.Missing.Value;
        public  void ClearGargabage()
        {

            try
            {
                

                //Clean-up
                m_objRange = null;
                m_objSheet = null;
                m_objSheets = null;
                m_objBooks = null;
                m_objBook = null;
                m_objExcel = null;
                GC.Collect();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void SetFormatForNumberColumn(int pSheetIndex,string pColumn,string pFormat,int maxRow)
        {
            try
            {

                if (pSheetIndex <= m_objSheets.Count)
                {
                    m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetIndex));
                    m_objRange = m_objSheet.get_Range(pColumn + "1", pColumn + maxRow.ToString());
                    m_objRange.NumberFormat = pFormat;
                
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
 
 
        }
        public void SetFormatForACell(int pSheetIndex, string pColumn, string pFormat, int row)
        {
            try
            {

                if (pSheetIndex <= m_objSheets.Count)
                {
                    m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetIndex));
                    m_objRange = m_objSheet.get_Range(pColumn + row, pColumn + row);
                    m_objRange.NumberFormat = pFormat;

                }


            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        public void Validate(Excel.Range range)
        {
            try
            {
                range.Validation.Add(XlDVType.xlValidateList, XlDVAlertStyle.xlValidAlertStop, Type.Missing, "=softwarelist", Type.Missing);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void BeginWithAFileName(string fileName)
        {

            try
            {
                // Start a new workbook in Excel.
                m_objExcel = new Excel.Application();

                m_objBooks = (Excel.Workbooks)m_objExcel.Workbooks;
                m_objBooks.Open(fileName, Type.Missing, true, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                if (m_objBooks.Count > 0)
                {
                    m_objBook = (Excel._Workbook)(m_objBooks[1]);
                    m_objSheets = (Excel.Sheets)m_objBook.Worksheets;
                }


                
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
        //--Sang add this function
        public void BeginWithAFileNameAndPopupFile(String fileName)
        {
            try
            {
                // Start a new workbook in Excel.
                m_objExcel = new Excel.Application();

                m_objBooks = (Excel.Workbooks)m_objExcel.Workbooks;
                m_objBooks.Open(fileName, Type.Missing, true, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                if (m_objBooks.Count > 0)
                {
                    m_objBook = (Excel._Workbook)(m_objBooks[1]);
                    m_objSheets = (Excel.Sheets)m_objBook.Worksheets;
                }
                m_objExcel.Visible = true;


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void Begin()
        {

            try
            {
                // Start a new workbook in Excel.
                m_objExcel = new Excel.Application();
                m_objBooks = (Excel.Workbooks)m_objExcel.Workbooks;
                m_objBook = (Excel._Workbook)(m_objBooks.Add(m_objOpt));
                m_objSheets = (Excel.Sheets)m_objBook.Worksheets;



            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
        public void SetNameToSheet(int pSheetIndex, string name)
        {
            try
            {
                if (m_objSheets.Count >= pSheetIndex && pSheetIndex >= 1)
                {
                    ((Excel._Worksheet)m_objSheets[pSheetIndex]).Name = name;

                }
            }
            catch(Exception ex)
            {
                throw ex;

            }
        }
        public string GetValueToACellInASheet(int pSheetIndex, int row, string column)
        {
            try
            {
                object value = new object();
                if (pSheetIndex <= m_objSheets.Count)
                {
                    m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetIndex));
                    value = ((Excel.Range)m_objSheet.Cells[row, column]).Value2;
                    if (value != null)
                    {
                        return value.ToString().Trim();
                    }

                }
                return "";
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        public string GetFormatInACell(int pSheetIndex, int row, string column)
        {
            try
            {
                object value = new object();
                if (pSheetIndex <= m_objSheets.Count)
                {
                    m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetIndex));
                    value = ((Excel.Range)m_objSheet.Cells[row, column]).NumberFormat;
                    object value2 = ((Excel.Range)m_objSheet.Cells[row, column]).NumberFormatLocal;
                    string abcd = value2.ToString();
                    if (value != null)
                    {
                        return value.ToString().Trim();
                    }

                }
                return "";
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        public int GetRowCount(string pSheetName)
        {
            int result = 0;

            try
            {
               
                m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetName));
                if (m_objSheet != null)
                {
                    result = m_objSheet.Rows.Count;
                }
                return result;
            }
            catch (Exception ex)
            {
                return result;
                throw ex;


            }
        }
        
        public string GetValueToACellInASheet(string pSheetName, int row, string column)
        {
            try
            {
                object value = new object();
                
                m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetName));
             
                value = ((Excel.Range)m_objSheet.Cells[row, column]).Value2;

                if (value != null)
                {
                    return value.ToString().Trim();
                }

              
                return "";
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        public object GetValueToACellInASheet(int pSheetIndex, int row, int column)
        {
            try
            {
                object value = new object();
                if (pSheetIndex <= m_objSheets.Count)
                {
                    m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetIndex));
                    value=((Excel.Range)m_objSheet.Cells[row, column]).Value2;



                }
                return value;
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        public object HideAColumn(int pSheetIndex,int row, int column)
        {
            try
            {
                object value = new object();
                if (pSheetIndex <= m_objSheets.Count)
                {
                    m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetIndex));
                    ((Excel.Range)m_objSheet.Cells[row, column]).Hidden=true;



                }
                return value;
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
    
        public void SetValueToACellInASheet(int pSheetIndex,int row, int column,object value)
        {
            try
            {
                if (pSheetIndex <= m_objSheets.Count)
                {
                    m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetIndex));
                    m_objSheet.Cells[row, column] = value;

                }

            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        public void SetValueToACellInASheet(string pSheetName, int row, int column, object value)
        {
            try
            {

                m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetName));
                
                m_objSheet.Cells[row, column] = value;



               

            }
            catch (Exception ex)
            {
                throw ex;

            }
        }




        public void EndAndSaveAs()
        {
            try
            {



                m_objBook.Close(false,false,false);
                m_objExcel.Quit();



            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public void EndAndSaveAs(string outPutFileName,string password)
        {
            try
            {

                foreach (Excel._Worksheet sheet in m_objSheets)
                {
                    sheet.Columns.AutoFit();
                }
                m_objBook.SaveAs(outPutFileName, m_objOpt, password,
                 m_objOpt, m_objOpt, m_objOpt, Excel.XlSaveAsAccessMode.xlNoChange,
                   m_objOpt, m_objOpt, m_objOpt, m_objOpt, m_objOpt);
                m_objBook.Close(true, m_objOpt, m_objOpt);
                m_objExcel.Quit();




            }
            catch (Exception ex)
            {
                throw ex;

            }

        }
        public void SetBoarderForARange(int pSheetIndex, string rangeFrom, string rangeTo)
        {
            try
            {
                     try
                 {
                     if (pSheetIndex <= m_objSheets.Count)
                     {
                         m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(pSheetIndex));
                         Range excelRange = m_objSheet.get_Range(rangeFrom, rangeTo);
                excelRange.Borders[XlBordersIndex.xlEdgeLeft].LineStyle = XlLineStyle.xlContinuous;
                         excelRange.Borders[XlBordersIndex.xlEdgeRight].LineStyle = XlLineStyle.xlContinuous;
                         excelRange.Borders[XlBordersIndex.xlEdgeTop].LineStyle = XlLineStyle.xlContinuous;
                         excelRange.Borders[XlBordersIndex.xlEdgeBottom].LineStyle = XlLineStyle.xlContinuous;
                         excelRange.Borders[XlBordersIndex.xlInsideHorizontal].LineStyle = XlLineStyle.xlContinuous;
                         excelRange.Borders[XlBordersIndex.xlInsideVertical].LineStyle = XlLineStyle.xlContinuous;
                       

                     }

                 }
                 catch (Exception ex)
                 {
                     throw ex;

                 }

            }
            catch (Exception ex)
            {
                throw ex;

            }

        }
        public void SetBoarderForARange(string sheetName, String rangeFrom, string rangeTo)
        {
            try
            {
                try
                {
                        m_objSheet = (Excel._Worksheet)(m_objSheets.get_Item(sheetName));
                        Range excelRange = m_objSheet.get_Range(rangeFrom, rangeTo);
                        excelRange.Borders[XlBordersIndex.xlEdgeLeft].LineStyle = XlLineStyle.xlContinuous;
                        excelRange.Borders[XlBordersIndex.xlEdgeRight].LineStyle = XlLineStyle.xlContinuous;
                        excelRange.Borders[XlBordersIndex.xlEdgeTop].LineStyle = XlLineStyle.xlContinuous;
                        excelRange.Borders[XlBordersIndex.xlEdgeBottom].LineStyle = XlLineStyle.xlContinuous;
                        excelRange.Borders[XlBordersIndex.xlInsideHorizontal].LineStyle = XlLineStyle.xlContinuous;
                        excelRange.Borders[XlBordersIndex.xlInsideVertical].LineStyle = XlLineStyle.xlContinuous;
                }
                catch (Exception ex)
                {
                    throw ex;

                }

            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        public void EndAndSaveAsNotAutoFit(string outPutFileName, string password)
        {
            try
            {

                
                m_objBook.SaveAs(outPutFileName, m_objOpt, password,
                 m_objOpt, m_objOpt, m_objOpt, Excel.XlSaveAsAccessMode.xlNoChange,
                   m_objOpt, m_objOpt, m_objOpt, m_objOpt, m_objOpt);
                m_objBook.Close(true, m_objOpt, m_objOpt);
                m_objExcel.Quit();




            }
            catch (Exception ex)
            {
                throw ex;

            }

        }

    public void EndAndSaveAs(string outPutFileName)
   {
       try
       {

           foreach (Excel._Worksheet sheet in m_objSheets)
           {
               sheet.Columns.AutoFit();
           }
           // Save the workbook and quit Excel.
          /* m_objBook.SaveAs(outPutFileName, m_objOpt, m_objOpt,
               m_objOpt, m_objOpt, m_objOpt, Excel.XlSaveAsAccessMode.xlNoChange,
               m_objOpt, m_objOpt, m_objOpt, m_objOpt, m_objOpt);
           
           m_objBook.Close(false, m_objOpt, m_objOpt);
            */


            m_objBook.SaveAs(outPutFileName, m_objOpt, m_objOpt,
             m_objOpt, m_objOpt, m_objOpt, Excel.XlSaveAsAccessMode.xlNoChange,
               m_objOpt, m_objOpt, m_objOpt, m_objOpt, m_objOpt);
  
            m_objBook.Close(true, m_objOpt, m_objOpt);
             
            m_objExcel.Quit();
           
           

           
       }
       catch (Exception ex)
       {
           throw ex;
                               
       }

   }

    public void EndAndSaveAsNotAutoFit(string outPutFileName)
    {
        try
        {

            
           

            m_objBook.SaveAs(outPutFileName, m_objOpt, m_objOpt,
             m_objOpt, m_objOpt, m_objOpt, Excel.XlSaveAsAccessMode.xlNoChange,
               m_objOpt, m_objOpt, m_objOpt, m_objOpt, m_objOpt);

            m_objBook.Close(true, m_objOpt, m_objOpt);

            m_objExcel.Quit();




        }
        catch (Exception ex)
        {
            throw ex;

        }

    }


      
    }
}
