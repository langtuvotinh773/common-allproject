﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using COMMON.Properties;
using Config.Classes;

namespace Phoenix.Common.Popup
{
    public partial class frmPhoenixMessage : Form
    {
        public int Type;
        
        /// <summary>
        /// Confirm = 0,
        /// Error = 1,
        /// Infomaition =2
        /// </summary>
        /// <param name="type"></param>
        /// <param name="format"></param>
        /// <param name="arrayItem"></param>
        public frmPhoenixMessage(int type, string format, string[] arrayItem)
        {
            InitializeComponent();
            this.Type = type;
            btnOK.Visible = false;
            btnNo.Visible = false;
            btnCancel.Visible = false;
            txtMsg.Text = String.Format(format, arrayItem);
            int a = txtMsg.TextLength;
            //  int b = a / 40;

            if (this.Type == (int)CommonValue.MessageType.Confirm)
            {
                pictureBox1.Image = Resources.confirm;
                this.Text = "Phoenix System Confirm";
                btnOK.Text = "&Yes";
                btnOK.Visible = true;
                btnNo.Visible = true;
                btnCancel.Visible = true;


            }
            if (this.Type == (int)CommonValue.MessageType.Error)
            {
                pictureBox1.Image = Resources.Error_systerm;
                this.Text = "Phoenix System Error";
                btnNo.Visible = true;
                btnNo.Text = "&OK";
                // btnOK.Location = new Point(166, 80);
                txtMsg.ForeColor = Color.Red;
            }
            if (this.Type == (int)CommonValue.MessageType.Infomaition)
            {
                pictureBox1.Image = Resources.error_validation;
                this.Text = "Phoenix System Infomation";
                btnNo.Visible = true;
                btnNo.Text = "&OK";
                // btnOK.Location = new Point(166, 80);
            }
            if (this.Type == (int)CommonValue.MessageType.YesNoConfirm)
            {
                pictureBox1.Image = Resources.confirm;
                this.Text = "Phoenix System Confirm";
                btnOK.Text = "&Yes";
                btnOK.Visible = true;
                btnNo.Visible = true;
                btnOK.Location = new Point(btnOK.Location.X + btnCancel.Width / 2, btnCancel.Location.Y);
                btnNo.Location = new Point(btnNo.Location.X + btnCancel.Width / 2, btnCancel.Location.Y);
            }

            if (a > 200)
            {
                this.Width += 200 * 4;

                this.Height += (a / 200+1) * 10;

            }
            else
            {
                this.Width += a * 4;
            }

            if (type == (int)CommonValue.MessageType.Confirm) this.Width = Math.Max(350, this.Width) ;
        }

        /// <summary>
        /// Confirm = 0,
        /// Error = 1,
        /// Infomaition =2
        /// </summary>
        /// <param name="type"></param>
        /// <param name="msg"></param>
        public frmPhoenixMessage(int type, string msg)
        {
            InitializeComponent();
            this.Type = type;
            btnOK.Visible = false;
            btnNo.Visible = false;
            btnCancel.Visible = false;
            txtMsg.Text = msg;
            int a = txtMsg.TextLength;
            int b = a / 40;



            if (this.Type == (int)CommonValue.MessageType.Confirm)
            {
                pictureBox1.Image = Resources.confirm;
                this.Text = "Phoenix System Confirm";
                btnOK.Text = "&Yes";
                btnOK.Visible = true;
                btnNo.Visible = true;
                btnCancel.Visible = true;


            }
            if (this.Type == (int)CommonValue.MessageType.Error)
            {
                pictureBox1.Image = Resources.Error_systerm;
                this.Text = "Phoenix System Error";
                btnNo.Visible = true;
                btnNo.Text = "&OK";
                // btnOK.Location = new Point(166, 80);
                txtMsg.ForeColor = Color.Red;
            }
            if (this.Type == (int)CommonValue.MessageType.Infomaition)
            {
                pictureBox1.Image = Resources.error_validation;
                this.Text = "Phoenix System Infomation";
                btnNo.Visible = true;
                btnNo.Text = "&OK";
                // btnOK.Location = new Point(166, 80);
            }
            if (this.Type == (int)CommonValue.MessageType.YesNoConfirm)
            {
                pictureBox1.Image = Resources.confirm;
                this.Text = "Phoenix System Confirm";
                btnOK.Text = "&Yes";
                btnOK.Visible = true;
                btnNo.Visible = true;
                btnOK.Location = new Point(btnOK.Location.X + btnCancel.Width / 2, btnCancel.Location.Y);
                btnNo.Location = new Point(btnNo.Location.X + btnCancel.Width / 2, btnCancel.Location.Y);
            }

           // this.Height +=  b * 15;


            if (a > 200)
            {
                this.Width += 200 * 4;

                this.Height += (a / 200 + 1) * 10;
            }
            else
            {
                this.Width += a * 5;
            }
            if (type == (int)CommonValue.MessageType.Confirm) this.Width = Math.Max(350, this.Width);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
