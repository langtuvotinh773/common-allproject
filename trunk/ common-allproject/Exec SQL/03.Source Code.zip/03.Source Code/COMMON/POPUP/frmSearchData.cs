﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Phoenix.Common.Popup
{
    public partial class frmSearchData : Form
    {
        public DataGridViewRow selectedRow = null;
        public frmSearchData()
        {
            InitializeComponent();
        }

        public frmSearchData(DataTable table)
        {
            InitializeComponent();
            dtgvResult.DataSource = table;
            dtgvResult.RowsDefaultCellStyle.BackColor = Color.White;
            dtgvResult.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(150, 254, 165);
            if (dtgvResult.ColumnCount > 0)
            {
                for (int i = 0; i < dtgvResult.Columns.Count; i++)
                {
                    dtgvResult.Columns[i].Width = (dtgvResult.Size.Width - 30) / dtgvResult.Columns.Count;
                }
            }
        }

        private void dtgvResult_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dtgvResult.SelectedRows.Count > 0)
            {
                selectedRow = dtgvResult.SelectedRows[0];
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void dtgvResult_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (dtgvResult.SelectedRows.Count > 0)
                {
                    selectedRow = dtgvResult.SelectedRows[0];
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else {
                    this.DialogResult = DialogResult.Cancel;
                    this.Close();
                }
            }
        }
    }
}
