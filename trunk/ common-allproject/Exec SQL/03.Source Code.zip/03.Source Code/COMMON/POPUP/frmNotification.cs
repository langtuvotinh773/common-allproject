﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Phoenix.Common.Popup
{
    public partial class frmNotification : Form
    {
        public string NotifierMessage 
        { 
            get { return lblMessage.Text; }
            set { lblMessage.Text = value; } 
        }

        public frmNotification()
        {
            InitializeComponent();
            pictureBox1.Image = Config.Properties.Resources.ringtone;
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;

            _timer = new Timer();
            _timer.Interval = 100;
            _timer.Tick += new EventHandler(Animate);

            _timerToClose = new Timer();
            _timerToClose.Interval = 7000;
            _timerToClose.Tick += new EventHandler(_timerToClose_Tick);

            _timerBlinker = new Timer();
            _timerBlinker.Interval = 150;
            _timerBlinker.Tick += new EventHandler(_timerBlinker_Tick);
        }

        private void _timerBlinker_Tick(object sender, EventArgs e)
        {
            lblMessage.Visible = !this.lblMessage.Visible;
            _blinkCount++;
            if (_blinkCount == 10)
            {
                _timerBlinker.Stop();
                lblMessage.Visible = true;
            }
        }

        private void frmNotification_Load(object sender, EventArgs e)
        {
            this.Opacity = 0;
            _timer.Start();
            System.Threading.Thread.Sleep(100);
        }

        private void Animate(object sender, EventArgs e)
        {
            if (_Showing)
            {
                if (this.Opacity < 1)
                {
                    this.Opacity += 0.3;
                }
                else
                {
                    _timer.Stop();
                    _timerToClose.Start();
                    _timerBlinker.Start();
                }
            }
            else
            {
                if (this.Opacity > 0)
                {
                    this.Opacity -= 0.3;
                }
                else
                {
                    _timer.Stop();
                    //_ForceClose = true;
                    this.Close();
                    if (_DisposeAtEnd)
                        this.Dispose();
                }
            }
        }

        private void _timerToClose_Tick(object sender, EventArgs e)
        {
            _timerToClose.Stop();
            _timer.Stop();
            _timerBlinker.Stop();

            IsTimerCloseForm = true;
            this.Close();
        }

        private Timer _timer;
        private Timer _timerToClose;
        private Timer _timerBlinker;
        private int _blinkCount = 0;
        private bool _Showing = true;
        //private bool _ForceClose = false;
        //private DialogResult m_origDialogResult;
        private bool _DisposeAtEnd = false;

        private const int _maxNumberOfBlinks = 20;

        public bool IsTimerCloseForm = false;
    }
}
