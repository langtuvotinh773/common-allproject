﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phoenix.Common.Reconcile.Dal;
using Phoenix.Common.Reconcile.Dto;

namespace Phoenix.Common.Reconcile.Bus
{
    class clsReconcileBus
    {
        private clsReconcileDal m_Dal = null;

        public clsReconcileBus()
        {
            m_Dal = new clsReconcileDal();
        }
        
        public DataTable GetTDDealTable()
        {
            return m_Dal.GetTDDealTable();
        }

        public DataTable GetTDReconciliationDetail(int no)
        {
            return m_Dal.GetTDReconciliationDetail(no);
        }

        public int SaveTDReconciliationSummary(clsReconcileDto dto)
        {
            return m_Dal.SaveTDReconciliationSummary(dto);
        }

        public List<clsReconcileDto> GetTDReconciliationSummary(clsReconcileDto dto)
        {
            return m_Dal.GetTDReconciliationSummary(dto);
        }

        public int SaveTDReconciliationDetail(DataTable detail)
        {
            return m_Dal.SaveTDReconciliationDetail(detail);
        }
    }
}
