﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Phoenix.Common.Reconcile.Com
{
    public abstract class clsReconcilerBase
    {
        public abstract bool CheckFileFromSmileIsValid();
        protected abstract DataTable ReadFileFromSmile();
        public abstract void MergeSmileRecord(DataTable table1, DataTable table2);
        protected abstract DataTable ReadDataFromPhoenix();
        public abstract void ReconcileData(DataGridView dgvPhoenix, DataGridView dgvSmile, ref int match, ref int mismatch);
        public abstract void Filter(DataGridView dtgPhoenix, DataGridView dtgSmile, DataTable detail, string filter);
        public abstract int SaveToDB();
    }
}