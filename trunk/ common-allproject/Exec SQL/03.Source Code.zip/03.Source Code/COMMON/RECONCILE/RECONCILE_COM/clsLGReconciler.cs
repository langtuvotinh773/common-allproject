﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Linq;
using System.Drawing;

using Config.Classes;

using Phoenix.Common.Reconcile.Bus;
using Phoenix.Common.Reconcile.Dto;

namespace Phoenix.Common.Reconcile.Com
{
    public class clsLGReconciler : clsReconcilerBase
    {
        private const string SMILE_LG_NO = "SimleLGNo";
        private const string SMILE_LG_CODE = "SimleLGCode";
        private const string SMILE_VALUE_DATE = "SimleValueDate";
        private const string SMILE_EXPIRE_DATE = "SimleExpireDate";
        private const string SMILE_CUST_CODE = "SimleCustomerCode";
        private const string SMILE_BENEFICIARY_NAME = "SimleBeneficiaryName";
        private const string SMILE_GUARANTEE_TYPE = "SimleGuaranteeType";
        private const string SMILE_CALCULATE_TYPE = "SimleCalculateType";
        private const string SMILE_LG_RATE = "SimleLGRate";
        private const string SMILE_MIN_RATE_STD = "SimleMinRateStandard";
        private const string SMILE_TRANS_CURRENCY = "SimleTransCurrency";
        private const string SMILE_TRANS_AMOUNT = "SimleTransAmount";
        private const string SMILE_CHARGE_AC = "SimleChargeAccount";
        private const string SMILE_FEE = "SimleFee";
        private const string SMILE_FEE_CURRENCY = "SimleFeeCurrency";

        private const string OLE_DB_CON_STR = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=Yes;IMEX=1';";

        private int m_MatchRecord = 0;
        private int m_MismatchRecord = 0;

        public string OuFileName { get; set; }
        public string OnFileName { get; set; }
        public DateTime ReconcileTime { get; set; }

        private DataTable m_TablePhoenix = null;
        private DataTable m_TableSmile = null;
        private DataTable m_TableToSave = null;

        private clsReconcileBus m_Bus = null;

        public override bool CheckFileFromSmileIsValid()
        {
            return true;
        }

        protected override DataTable ReadFileFromSmile()
        {
            DataTable tblLGOUTP = new DataTable();
            DataTable tblLGONTP = new DataTable();

            // Read LGOUTP file
            using (OleDbConnection dbCon = new OleDbConnection(String.Format(OLE_DB_CON_STR, OuFileName)))
            {
                string cmd = CreateQueryCmdForFileLGOUTP(OuFileName, "LGOUTP");
                using (OleDbDataAdapter dbDA = new OleDbDataAdapter(cmd, dbCon))
                {
                    try
                    {
                        dbDA.Fill(tblLGOUTP);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }

            // Read LGONTP file
            using (OleDbConnection dbCon = new OleDbConnection(String.Format(OLE_DB_CON_STR, OnFileName)))
            {
                string cmd = CreateQueryCmdForFileLGONTP(OnFileName, "LGONTP");
                using (OleDbDataAdapter dbDA = new OleDbDataAdapter(cmd, dbCon))
                {
                    try
                    {
                        dbDA.Fill(tblLGONTP);
                    }
                    catch (Exception)
                    {
                    }
                }
            }

            IEnumerable<DataRow> match = tblLGOUTP.AsEnumerable().Intersect(tblLGONTP.AsEnumerable());
            IEnumerable<DataRow> mismatch = tblLGOUTP.AsEnumerable().Except(tblLGONTP.AsEnumerable());
            DataTable result = new DataTable();
            
            if (match.Count() > 0 && mismatch.Count() > 0)
            {
                result = match.CopyToDataTable();
                result.Merge(mismatch.CopyToDataTable());

                return result;
            }
            else
            {
                tblLGOUTP.Merge(tblLGONTP);
                return tblLGOUTP;
            }
        }

        public override void MergeSmileRecord(DataTable tblLGOUTP, DataTable tblLGONTP)
        {
        }

        protected override DataTable ReadDataFromPhoenix()
        {
            m_Bus = new clsReconcileBus();

            return null;
        }

        public override void ReconcileData(DataGridView dtgPhoenix, DataGridView dtgSmile, ref int match, ref int mismatch)
        {
            // Cache reconcile time
            ReconcileTime = DateTime.Now;

            // Get tables to reconcile
            DataTable tblPhoenix = ReadDataFromPhoenix();
            DataTable tblSmile = ReadFileFromSmile();

            int j = 0;
            int original = 0;

            m_TablePhoenix = tblPhoenix.Clone();
            m_TableSmile = tblSmile.Clone();

            dtgPhoenix.Rows.Clear();
            dtgSmile.Rows.Clear();

            #region Check first loop
            // Loop through phoenix table
            for (int i = 0; i < tblPhoenix.Rows.Count; i++)
            {
                // Indicate whether or not add a new row to DataGrid
                original = tblSmile.Rows.Count;
                j = 0;
                // For one record, compare with each record in smile table
                #region Check second loop
                while (j < tblSmile.Rows.Count)
                {
                    if ((tblSmile.Rows.Count > 0 && tblPhoenix.Rows.Count > 0) && tblPhoenix.Rows[i].ItemArray.SequenceEqual(tblSmile.Rows[j].ItemArray))
                    {
                        // Records is match, remove them from both datatables
                        tblPhoenix.Rows.RemoveAt(i);
                        tblSmile.Rows.RemoveAt(j);
                        ++match;
                    }
                    else
                    {
                        if (tblSmile.Rows.Count == 0 || tblPhoenix.Rows.Count == 0)
                        {
                            ++j;
                            continue;
                        }
                        if (tblPhoenix.Rows[i]["TDNo"].Equals(tblSmile.Rows[j]["TDNo"]))
                        {
                            // Records is NOT match, add them to gridviews
                            tblPhoenix.Rows.Add(new DataGridViewRow());
                            dtgSmile.Rows.Add(new DataGridViewRow());

                            List<string> prow = new List<string>();
                            List<string> srow = new List<string>();

                            for (int k = 0; k < tblPhoenix.Columns.Count; k++)
                            {
                                if (tblPhoenix.Rows[i][k].ToString().Equals(tblSmile.Rows[j][k].ToString()))
                                {
                                    dtgPhoenix.Rows[tblPhoenix.Rows.Count - 1].Cells[k].Value = tblPhoenix.Rows[i][k];
                                    dtgSmile.Rows[dtgSmile.Rows.Count - 1].Cells[k].Value = tblSmile.Rows[j][k];

                                    prow.Add(tblPhoenix.Rows[i][k].ToString());
                                    srow.Add(String.Empty);
                                }
                                else
                                {
                                    dtgPhoenix.Rows[dtgPhoenix.Rows.Count - 1].Cells[k].Value = tblPhoenix.Rows[i][k];
                                    dtgSmile.Rows[dtgSmile.Rows.Count - 1].Cells[k].Value = tblSmile.Rows[j][k];
                                    dtgPhoenix.Rows[dtgSmile.Rows.Count - 1].Cells[k].Style.BackColor = Color.Red;
                                    dtgSmile.Rows[dtgSmile.Rows.Count - 1].Cells[k].Style.BackColor = Color.Red;

                                    prow.Add(tblPhoenix.Rows[i][k].ToString());
                                    srow.Add(tblSmile.Rows[j][k].ToString());
                                }
                            }
                            // Insert values into save table
                            DataRow row = m_TableToSave.NewRow();
                            prow.AddRange(srow);
                            row.ItemArray = prow.ToArray();
                            m_TableToSave.Rows.Add(row);

                            // After that, remove checked record in Smile table
                            tblSmile.Rows.RemoveAt(j);
                        }
                        else
                            ++j;
                    }
                }
                #endregion

                if (original == tblSmile.Rows.Count)
                {
                    // Add record to phoenix gridview
                    dtgPhoenix.Rows.Add(tblPhoenix.Rows[i].ItemArray);
                    DataGridViewRow emptyRow = new DataGridViewRow();
                    emptyRow.DefaultCellStyle.BackColor = Color.LightGray;
                    dtgSmile.Rows.Add(emptyRow);

                    List<object> list = new List<object>();
                    list.AddRange(tblPhoenix.Rows[i].ItemArray.ToArray());
                    list.AddRange(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "S" });
                    m_TableToSave.Rows.Add(list.ToArray());
                }
            }
            #endregion

            // Add remaining rows in smile table
            for (int i = 0; i < tblSmile.Rows.Count; i++)
            {
                // Add record to smile gridview
                dtgSmile.Rows.Add(tblSmile.Rows[i].ItemArray);
                DataGridViewRow emptyRow = new DataGridViewRow();
                emptyRow.DefaultCellStyle.BackColor = Color.LightGray;
                dtgPhoenix.Rows.Add(emptyRow);

                List<object> list = new List<object>();
                list.AddRange(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "" });
                list.AddRange(tblSmile.Rows[i].ItemArray.ToArray());
                list.Add("P");
                m_TableToSave.Rows.Add(list.ToArray());
            }

            mismatch = m_TableToSave.Rows.Count;
        }

        private bool CheckValueEachColumn(DataTable table, DataRow prow, DataRow srow, string pCol, string sCol, string gvCol, int rowIndex)
        {
            prow[gvCol] = table.Rows[rowIndex][pCol];
            if (table.Rows[rowIndex][sCol].Equals(String.Empty) || table.Rows[rowIndex][sCol] is DBNull)
            {
                srow[gvCol] = prow[gvCol];
                return false;
            }
            else
            {
                srow[gvCol] = table.Rows[rowIndex][sCol];
                return true;
            }
        }

        public override void Filter(DataGridView dtgPhoenix, DataGridView dtgSmile, DataTable tblDetail, string filter)
        {
            DataTable filteredTable = new DataTable();
            DataRow[] rows = tblDetail.Select(filter);
            if (rows.Length > 0) filteredTable = rows.CopyToDataTable();

            dtgPhoenix.Rows.Clear();
            dtgSmile.Rows.Clear();

            for (int i = 0; i < filteredTable.Rows.Count; i++)
            {
                if (filteredTable.Rows[i]["Key"].Equals(String.Empty) || filteredTable.Rows[i]["Key"] is DBNull)
                {
                    DataRow prow = m_TablePhoenix.NewRow();
                    DataRow srow = m_TableSmile.NewRow();

                    bool FillTDNoColor = CheckValueEachColumn(filteredTable, prow, srow, "PTDNo", "STDNo", "TDNo", i);
                    bool FillCIFColor = CheckValueEachColumn(filteredTable, prow, srow, "PCIFCode", "SCIFCode", "CIFCode", i);
                    bool FillGLColor = CheckValueEachColumn(filteredTable, prow, srow, "PGLCode", "SGLCode", "GLCode", i);
                    bool FillCCYColor = CheckValueEachColumn(filteredTable, prow, srow, "PCCY", "SCCY", "CCY", i);
                    bool FillVDColor = CheckValueEachColumn(filteredTable, prow, srow, "PValueDate", "SValueDate", "ValueDate", i);
                    bool FillMDColor = CheckValueEachColumn(filteredTable, prow, srow, "PMaturityDate", "SMaturityDate", "MaturityDate", i);
                    bool FillTAColor = CheckValueEachColumn(filteredTable, prow, srow, "PTotalAmt", "STotalAmt", "TotalAmt", i);
                    bool FillIRColor = CheckValueEachColumn(filteredTable, prow, srow, "PIR", "SIR", "IR", i);
                    bool FillISColor = CheckValueEachColumn(filteredTable, prow, srow, "PIS", "SIS", "IS", i);
                    bool FillDPACColor = CheckValueEachColumn(filteredTable, prow, srow, "PDebitProceedAC", "SDebitProceedAC", "DebitProceedAC", i);
                    bool FillMACColor = CheckValueEachColumn(filteredTable, prow, srow, "PMaturityAC", "SMaturityAC", "MaturityAC", i);
                    bool FillIACColor = CheckValueEachColumn(filteredTable, prow, srow, "PInterestAC", "SInterestAC", "InterestAC", i);
                    bool FillCTDColor = CheckValueEachColumn(filteredTable, prow, srow, "PCollateralTD", "SCollateralTD", "CollateralTD", i);

                    dtgPhoenix.Rows.Add(prow.ItemArray);
                    dtgSmile.Rows.Add(srow.ItemArray);

                    if (FillTDNoColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PTDNoColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["STDNoColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillCIFColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PCIFCodeColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SCIFCodeColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillGLColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PGLCodeColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SGLCodeColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillCCYColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PCCYColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SCCYColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillVDColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PValueDateColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SValueDateColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillMDColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PMaturityDateColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SMaturityDateColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillTAColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PTotalAmtColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["STotalAmtColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillIRColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PIRColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SIRColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillISColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PISColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SISColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillDPACColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PDebitProceedACColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SDebitProceedACColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillMACColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PMaturityACColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SMaturityACColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillIACColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PInterestACColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SInterestACColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillCTDColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PCollateralTDColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SCollateralTDColumn"].Style.BackColor = Color.Red;
                    }
                }
                else if (filteredTable.Rows[i]["Key"].Equals("P"))
                {
                    DataRow prow = m_TablePhoenix.NewRow();
                    DataRow srow = m_TableSmile.NewRow();
                    List<object> list = new List<object>();
                    for (int j = 0; j < filteredTable.Columns.Count - 1; j++)
                    {
                        list.Add(filteredTable.Rows[i][j]);
                    }
                    for (int k = 0; k < 13; k++)
                    {
                        prow[k] = list[k];
                    }
                    for (int l = 0; l < 13; l++)
                    {
                        srow[l] = list[l + 13];
                    }
                    dtgPhoenix.Rows.Add(prow.ItemArray);
                    dtgSmile.Rows.Add(srow.ItemArray);
                    dtgPhoenix.Rows[dtgPhoenix.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightGray;
                }
                else
                {
                    DataRow prow = m_TablePhoenix.NewRow();
                    DataRow srow = m_TableSmile.NewRow();
                    List<object> list = new List<object>();
                    for (int j = 0; j < filteredTable.Columns.Count - 2; j++)
                    {
                        list.Add(filteredTable.Rows[i][j]);
                    }
                    for (int k = 0; k < (list.Count - 1) / 2; k++)
                    {
                        prow[k] = list[k];
                    }
                    for (int k = 0; k < 13; k++)
                    {
                        srow[k] = list[k + 12];
                    }
                    dtgPhoenix.Rows.Add(prow.ItemArray);
                    dtgSmile.Rows.Add(srow.ItemArray);
                    dtgSmile.Rows[dtgSmile.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightGray;
                }
            }
        }

        public override int SaveToDB()
        {
            clsReconcileDto dto = new clsReconcileDto();
            dto.Timing = ReconcileTime;
            dto.MatchNo = m_MatchRecord;
            dto.MismatchNo = m_MismatchRecord;

            int no = m_Bus.SaveTDReconciliationSummary(dto);
            DataTable tblDetails = null;
            tblDetails.Columns.Add("No", typeof(System.Int32)).SetOrdinal(0);
            foreach (DataRow row in tblDetails.Rows)
            {
                row["No"] = no;
            }

            return m_Bus.SaveTDReconciliationDetail(tblDetails);
        }

        private string CreateQueryCmdForFileLGOUTP(string OufileName, string sheetName)
        {
            StringBuilder QueryCmd = new StringBuilder();
            QueryCmd.Append("SELECT ");
            QueryCmd.Append(String.Format("BOTRNO&BOTRSN AS {0},", SMILE_LG_NO));
            QueryCmd.Append(String.Format("CDGL&CDSUGL AS {0},", SMILE_LG_CODE));
            QueryCmd.Append(String.Format("BOVADT AS {0},", SMILE_VALUE_DATE));
            QueryCmd.Append(String.Format("BOMADT AS {0},", SMILE_EXPIRE_DATE));
            QueryCmd.Append(String.Format("CDCST AS {0},", SMILE_CUST_CODE));
            QueryCmd.Append(String.Format("LGNMBE AS {0},", SMILE_BENEFICIARY_NAME));
            QueryCmd.Append(String.Format("LGTYPE AS {0},", SMILE_GUARANTEE_TYPE));
            QueryCmd.Append(String.Format("S36ADJ AS {0},", SMILE_CALCULATE_TYPE));
            QueryCmd.Append(String.Format("BOINTR AS {0},", SMILE_LG_RATE));
            QueryCmd.Append(String.Format("BOMINI AS {0},", SMILE_MIN_RATE_STD));
            QueryCmd.Append(String.Format("CDCCY AS {0},", SMILE_TRANS_CURRENCY));
            QueryCmd.Append(String.Format("BOCBAL AS {0},", SMILE_TRANS_AMOUNT));
            QueryCmd.Append(String.Format("BODRAC AS {0},", SMILE_CHARGE_AC));
            QueryCmd.Append(String.Format("BODRAM AS {0},", SMILE_FEE));
            QueryCmd.Append(String.Format("BOICCY AS {0} ", SMILE_FEE_CURRENCY));
            QueryCmd.Append(String.Format("FROM [{0}$]", sheetName));
            
            return QueryCmd.ToString();
        }

        private string CreateQueryCmdForFileLGONTP(string OnFileName, string sheetName)
        {
            StringBuilder QueryCmd = new StringBuilder();
            QueryCmd.Append("SELECT ");
            QueryCmd.Append(String.Format("BTRTRN&BTRTRS AS {0},", SMILE_LG_NO));
            QueryCmd.Append(String.Format("BTRGL1&BTRGS1 AS {0},", SMILE_LG_CODE));
            QueryCmd.Append(String.Format("BTREFF AS {0},", SMILE_VALUE_DATE));
            QueryCmd.Append(String.Format("BTRMDT AS {0},", SMILE_EXPIRE_DATE));
            QueryCmd.Append(String.Format("BTRCM1 AS {0},", SMILE_CUST_CODE));
            QueryCmd.Append(String.Format("LGONMB AS {0},", SMILE_BENEFICIARY_NAME));
            QueryCmd.Append(String.Format("LGOGUT AS {0},", SMILE_GUARANTEE_TYPE));
            QueryCmd.Append(String.Format("S36ADJ AS {0},", SMILE_CALCULATE_TYPE));
            QueryCmd.Append(String.Format("BTRINR AS {0},", SMILE_LG_RATE));
            QueryCmd.Append(String.Format("DRFEMN AS {0},", SMILE_MIN_RATE_STD));
            QueryCmd.Append(String.Format("BTRCY1 AS {0},", SMILE_TRANS_CURRENCY));
            QueryCmd.Append(String.Format("BTRAM1 AS {0},", SMILE_TRANS_AMOUNT));
            QueryCmd.Append(String.Format("LCHGAC AS {0},", SMILE_CHARGE_AC));
            QueryCmd.Append(String.Format("BTCTIT AS {0},", SMILE_FEE));
            QueryCmd.Append(String.Format("LCHGCY AS {0} ", SMILE_FEE_CURRENCY));
            QueryCmd.Append(String.Format("FROM [{0}$]", sheetName));

            return QueryCmd.ToString();
        }
    }
}