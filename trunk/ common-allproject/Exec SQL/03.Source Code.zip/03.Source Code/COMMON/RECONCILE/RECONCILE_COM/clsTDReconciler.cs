﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Phoenix.Common.Reconcile.Com
{
    public class clsTDReconciler
    {
        private int m_MatchRecord;
        private int m_MismatchRecord;
    }
}