﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Reconcile.Dto
{
    public class clsReconcileDto
    {
        public int No { get; set; }
        public DateTime Timing { get; set; }
        public DateTime From { get; set; }
        public DateTime To { get; set; }
        public int MismatchNo { get; set; }
        public int MatchNo { get; set; }

        public string TimingString { get; set; }
    }
}
