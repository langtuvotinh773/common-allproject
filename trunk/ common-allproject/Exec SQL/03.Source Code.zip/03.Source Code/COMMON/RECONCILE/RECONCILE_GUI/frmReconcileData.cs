﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics;

using Config.Classes;
using Phoenix.Common.Reconcile.Com;

namespace Phoenix.Common.Reconcile.Gui
{
    public enum BusinessType
    {
        TD,
        LO,
        LG
    }

    public partial class frmReconcileData : Form
    {
		//clsReconciliation m_Reconciler = null;
		//DataTable m_Detail = null;
		//DateTime m_ReconcileTime;

		//int matchRecords = 0;
		//int mismatchRecords = 0;
		//bool m_IsReconciled = false;

		//private clsTDReconciler m_TDReconciler = null;
		//private clsLOReconciler m_LOReconciler = null;
		//private clsLGReconciler m_LGReconciler = null;

		//private BusinessType m_Type;  

		public frmReconcileData(BusinessType type)
		{
		//    InitializeComponent();

		//    if (type == BusinessType.TD)
		//    {
		//        m_Type = BusinessType.TD;
		//        m_TDReconciler = new clsTDReconciler();
		//        InitTDUI();
		//    }
		//    else if (type == BusinessType.LO)
		//    {
		//        m_Type = BusinessType.LO;
		//        m_LOReconciler = new clsLOReconciler();
		//        InitLOUI();
		//    }
		//    else if (type == BusinessType.LG)
		//    {
		//        m_Type = BusinessType.LG;
		//        m_LGReconciler = new clsLGReconciler();
		//        InitLGUI();
		//    }
		//    else
		//    {
		//        Dispose();
		//    }

		//    AlignLabelCenter();

		//    SettingPhoenixColumns();
		//    SetupDataPropertyName();

		//    dtgPhoenix.AutoGenerateColumns = false;
		//    dtgSmile.AutoGenerateColumns = false;

		//    checkBox1.Checked = true;
		//    checkBox2.Checked = true;
		//    checkBox3.Checked = true;
        }

        private void InitTDUI()
        {
            Text = "TD Reconciliation";
            lblOUFileName.Text = "Outstanding TD (FDOUTP)";
            lblONFileName.Text = "TD Transaction in day  (FDONTP)";
        }

        private void InitLOUI()
        {
            Text = "LO Reconciliation";
            lblOUFileName.Text = "Outstanding LO (LNOUTP)";
            lblONFileName.Text = "LO Transaction in day  (LNONTP)";
        }

        private void InitLGUI()
        {
            Text = "LG Reconciliation";
            lblOUFileName.Text = "Outstanding LG (LGOUTP)";
            lblONFileName.Text = "LG Transaction in day  (LGONTP)";
        }

        private void AlignLabelCenter()
        {
            int px = (splitContainer1.Panel1.Width - lblPhoenixTime.Width) / 2;
            int sx = (splitContainer1.Panel2.Width - lblSmileTime.Width) / 2;
            lblPhoenixTime.Location = new Point(px, lblPhoenixTime.Location.Y);
            lblSmileTime.Location = new Point(sx, lblSmileTime.Location.Y);
        }

        private void SettingPhoenixColumns()
        {
            PCCYColumn.DataPropertyName = "CCY";
            PGLCodeColumn.DataPropertyName = "GLCode";
            PTDNoColumn.DataPropertyName = "TDNo";
            PTotalAmtColumn.DataPropertyName = "TotalAmt";
            PValueDateColumn.DataPropertyName = "ValueDate";
            PMaturityDateColumn.DataPropertyName = "MaturityDate";
            PIRColumn.DataPropertyName = "IR";
            PISColumn.DataPropertyName = "IS";
            PDebitProceedACColumn.DataPropertyName = "DebitProceedAC";
            PMaturityACColumn.DataPropertyName = "MaturityAC";
            PInterestACColumn.DataPropertyName = "InterestAC";
            PCollateralTDColumn.DataPropertyName = "CollateralTD";
        }

        private void SetupDataPropertyName()
        {
            SCCYColumn.DataPropertyName = "CCY";
            SGLCodeColumn.DataPropertyName = "GLCode";
            STDNoColumn.DataPropertyName = "TDNo";
            STotalAmtColumn.DataPropertyName = "TotalAmt";
            SValueDateColumn.DataPropertyName = "ValueDate";
            SMaturityDateColumn.DataPropertyName = "MaturityDate";
            SIRColumn.DataPropertyName = "IR";
            SISColumn.DataPropertyName = "IS";
            SDebitProceedACColumn.DataPropertyName = "DebitProceedAC";
            SMaturityACColumn.DataPropertyName = "MaturityAC";
            SInterestACColumn.DataPropertyName = "InterestAC";
            SCollateralTDColumn.DataPropertyName = "CollateralTD";
        }

        private void SetCheckbox()
        {
			//if (checkBox1.Checked && checkBox2.Checked && checkBox3.Checked)
			//{
			//    // Get all
			//    m_Reconciler.FilterData(dtgPhoenix, dtgSmile, m_Reconciler.GetTableDetail(), "Key is null OR Key = 'S' OR Key = 'P'");
			//}
			//else if (!checkBox1.Checked && checkBox2.Checked && checkBox3.Checked)
			//{
			//    // Get records found and not found in phoenix and smile
			//    m_Reconciler.FilterData(dtgPhoenix, dtgSmile, m_Reconciler.GetTableDetail(), "Key = 'S' OR Key = 'P'");
			//}
			//else if (checkBox1.Checked && !checkBox2.Checked && checkBox3.Checked)
			//{
			//    // Get records have mismatched and found in smile
			//    m_Reconciler.FilterData(dtgPhoenix, dtgSmile, m_Reconciler.GetTableDetail(), "Key is null OR Key = 'S'");
			//}
			//else if (checkBox1.Checked && checkBox2.Checked && !checkBox3.Checked)
			//{
			//    // Get records have mismatched and found in smile
			//    m_Reconciler.FilterData(dtgPhoenix, dtgSmile, m_Reconciler.GetTableDetail(), "Key is null OR Key = 'P'");
			//}
			//else if (!checkBox1.Checked && !checkBox2.Checked && checkBox3.Checked)
			//{
			//    // Get records found in phoenix
			//    m_Reconciler.FilterData(dtgPhoenix, dtgSmile, m_Reconciler.GetTableDetail(), "Key = 'S'");
			//}
			//else if (!checkBox1.Checked && checkBox2.Checked && !checkBox3.Checked)
			//{
			//    // Get records found in smile
			//    m_Reconciler.FilterData(dtgPhoenix, dtgSmile, m_Reconciler.GetTableDetail(), "Key = 'P'");
			//}
			//else if (checkBox1.Checked && !checkBox2.Checked && !checkBox3.Checked)
			//{
			//    // Get not matched records
			//    m_Reconciler.FilterData(dtgPhoenix, dtgSmile, m_Reconciler.GetTableDetail(), "Key is null");
			//}
			//else
			//{
			//    // There is no any records, clear gridviews
			//    dtgPhoenix.Rows.Clear();
			//    dtgSmile.Rows.Clear();
			//}
        }

        private bool IsFileNameValid()
        {
            if (txtOutstandingTD.Text.Trim().Length == 0 || txtTransInDay.Text.Trim().Length == 0)
            {
                return false;
            }
            return true;
        }

        private void btnBrowse1_Click(object sender, EventArgs e)
        {
			//txtOutstandingTD.Text = clsFunction.OpenFileDialog("Excel files|*.xls|All files|*.*");
			//switch (m_Type)
			//{
			//    case BusinessType.TD:
			//        break;
			//    case BusinessType.LO:
			//        break;
			//    case BusinessType.LG:
			//        m_LGReconciler.OuFileName = txtOutstandingTD.Text;
			//        break;
			//    default:
			//        break;
			//}
        }

        private void btnBrowse2_Click(object sender, EventArgs e)
        {
			//txtTransInDay.Text = clsFunction.OpenFileDialog("Excel files|*.xls|All files|*.*");
			//switch (m_Type)
			//{
			//    case BusinessType.TD:
			//        break;
			//    case BusinessType.LO:
			//        break;
			//    case BusinessType.LG:
			//        m_LGReconciler.OnFileName = txtTransInDay.Text;
			//        break;
			//    default:
			//        break;
			//}
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
			//switch (m_Type)
			//{
			//    case BusinessType.TD:
			//        break;
			//    case BusinessType.LO:
			//        break;
			//    case BusinessType.LG:
			//        if (IsFileNameValid())
			//        {
			//            bool IsFileValid = m_LGReconciler.CheckFileFromSmileIsValid();
			//            if (IsFileValid)
			//            {
			//                lblPhoenixTime.Text = "PHOENIX (" + DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss") + ")";
			//                m_LGReconciler.ReconcileData(dtgPhoenix, dtgSmile, ref matchRecords, ref mismatchRecords);
			//                m_IsReconciled = true;
			//            }    
			//        }
			//        break;
			//    default:
			//        break;
			//}  
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
			//switch (m_Type)
			//{
			//    case BusinessType.TD:
			//        break;
			//    case BusinessType.LO:
			//        break;
			//    case BusinessType.LG:
			//        if (m_LGReconciler.SaveToDB() == 1)
			//            clsFunction.ShowInfoDialog(clsMessage.SAVE_SUCCESSFULL);
			//        else
			//            clsFunction.ShowInfoDialog(clsMessage.SAVE_UNSUCCESSFULL);
			//        break;
			//    default:
			//        break;
			//}   
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dtgPhoenix_Scroll(object sender, ScrollEventArgs e)
        {
            if (e.ScrollOrientation == ScrollOrientation.HorizontalScroll)
            {
                dtgSmile.HorizontalScrollingOffset = e.NewValue;
            }
            else
            {
                if (dtgSmile.Controls[1].Visible)
                {
                    dtgSmile.FirstDisplayedScrollingRowIndex = dtgPhoenix.FirstDisplayedScrollingRowIndex;
                }
            }
        }

        private void dtgSmile_Scroll(object sender, ScrollEventArgs e)
        {
            if (e.ScrollOrientation == ScrollOrientation.HorizontalScroll)
            {
                dtgPhoenix.HorizontalScrollingOffset = e.NewValue;
            }
            else
            {
                if (dtgPhoenix.Controls[1].Visible)
                {
                    dtgPhoenix.FirstDisplayedScrollingRowIndex = dtgSmile.FirstDisplayedScrollingRowIndex;
                }
            }
        }

        private void dtgPhoenix_SelectionChanged(object sender, EventArgs e)
        {
            dtgPhoenix.ClearSelection();
        }

        private void dtgSmile_SelectionChanged(object sender, EventArgs e)
        {
            dtgSmile.ClearSelection();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
			//if (m_IsReconciled == false) return;
			//SetCheckbox();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
			//if (m_IsReconciled == false) return;
			//SetCheckbox();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
			//if (m_IsReconciled == false) return;
			//SetCheckbox();
        }

        private void frmDPDReconcileTDData_Load(object sender, EventArgs e)
        {
        }

        private void frmDPDReconcileTDData_Resize(object sender, EventArgs e)
        {
            AlignLabelCenter();
        }
    }
}