﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

using Config.Classes;
using Phoenix.Common.Reconcile.Dto;

namespace Phoenix.Common.Reconcile.Dal
{
    public class clsReconcileDal
    {
        private string m_ConnStr = @"Data Source=isb-273\SQLEXPRESS;Initial Catalog=PHOENIX_TEST;User ID=sa;Password=123456";

        public clsReconcileDal()
        {
        }

        public DataTable GetTDDealTable()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(m_ConnStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "spDiet_GetTDDeal";
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        public int SaveTDReconciliationSummary(clsReconcileDto dto)
        {
            if (dto == null) return 0;
            using (SqlConnection conn = new SqlConnection(m_ConnStr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "spDiet_InsertTDReconciliationSummary";
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] values = new SqlParameter[] { 
                            new SqlParameter("@Timing", dto.Timing),
                            new SqlParameter("@Match", dto.MatchNo),
                            new SqlParameter("@Mismatch", dto.MismatchNo)
                        };
                    cmd.Parameters.AddRange(values);
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        public int SaveTDReconciliationDetail(DataTable detail)
        {
            int success = 0;
            using (SqlConnection conn = new SqlConnection(m_ConnStr))
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, trans))
                {
                    bulkCopy.DestinationTableName = "tblDiet_TDReconciledDetails";
                    bulkCopy.BatchSize = 100;
                    try
                    {
                        bulkCopy.WriteToServer(detail);
                        trans.Commit();
                        success = 1;
                    }
                    catch (Exception)
                    {
                        trans.Rollback();
                        success = 0;
                    }
                    finally
                    {
                        trans.Dispose();
                        conn.Close();
                    }
                }
            }
            return success;
        }

        public DataTable GetTDReconciliationDetail(int no)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(m_ConnStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "spDiet_GetTDReconciliationDetail";
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter value = new SqlParameter();
                    value = new SqlParameter("@No", no);
                    cmd.Parameters.Add(value);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        public List<clsReconcileDto> GetTDReconciliationSummary(clsReconcileDto dto)
        {
            if (dto == null) return null;
            List<clsReconcileDto> list = new List<clsReconcileDto>();
            using (SqlConnection conn = new SqlConnection(m_ConnStr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "spDiet_GetTDReconciliationSummary";
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] values = new SqlParameter[2];
                    values[0] = new SqlParameter("@From", SqlDbType.DateTime);
                    values[1] = new SqlParameter("@To", SqlDbType.DateTime);
                    values[0].Value = dto.From;
                    values[1].Value = dto.To;
                    cmd.Parameters.AddRange(values);

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        clsReconcileDto entity = new clsReconcileDto();
                        entity.No = reader.GetInt32(0);
                        entity.TimingString = reader.GetDateTime(1).ToString("hh:mm tt");
                        entity.MismatchNo = reader.GetInt32(2);
                        entity.MatchNo = reader.GetInt32(3);
                        
                        list.Add(entity);
                    }
                    reader.Close();
                }
            }
            return list;
        }
    }
}
