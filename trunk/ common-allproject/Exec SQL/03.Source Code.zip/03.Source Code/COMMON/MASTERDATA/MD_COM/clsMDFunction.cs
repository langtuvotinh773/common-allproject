﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-13 (Web, 13 March 2013) $
 * ========================================================
 * This class is used to define conmon functions 
 * For Master Data module.
 */
using System;
using System.Text;
using System.Security.Cryptography;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using MasterCommon = Phoenix.Common.MasterData.Com;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Collections;

namespace Phoenix.Common.MasterData.Com
{
    public static class clsMDFunction
    {
        /// <summary>
        /// take any string and encoding it using MD5 then
        /// return the encrypted data 
        /// </summary>
        /// <param name="data">input text you will enterd to encrypt it</param>
        /// <returns>return the encoding text as hexadecimal string</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public static string GetMD5HashData(string data)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(data));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into 2 hexadecimal digits
                //for each byte
                strBuilder.Append(result[i].ToString("x2"));
            }
            return strBuilder.ToString();
        }

        /// <summary>
        /// encrypt input text using MD5 and compare it with
        /// the stored encrypted text
        /// </summary>
        /// <param name="inputData">input text you will enterd to encrypt it</param>
        /// <param name="storedHashData">the encrypted text
        ///         stored on file or database ... etc</param>
        /// <returns>true or false depending on input validation</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public static bool ValidateMD5HashData(string inputData, string storedHashData)
        {
            //hash input text and save it string variable
            string getHashInputData = GetMD5HashData(inputData);

            if (string.Compare(getHashInputData, storedHashData) == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public static void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;

                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, MasterCommon.clsMDConstant.MODULE_MD);
            }
            finally
            {
                GC.Collect();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="excelBase"></param>
        /// <param name="dt"></param>
        /// <param name="isMergeCell"></param>
        /// <param name="iRowStart"></param>
        /// <param name="iRowCountMerge"></param>
        /// <param name="iColStart"></param>
        /// <param name="iColCountMerge"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private static void MergeCellAndFormatNumber(ExcelBase excelBase, DataTable dt, bool isMergeCell, int iRowStart, int iRowCountMerge, int iColStart, int iColCountMerge)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //get string format
                string format = dt.Rows[i][clsMDConstant.MD_COL_FORMATNUMBER].ToString();
                //format               
                Excel.Range excRange = excelBase.GetRange(iColStart + iColCountMerge, iRowStart + i, iColStart + dt.Columns.Count - 1, iRowStart + i);
                excRange.NumberFormat = format;
                //border
                excRange = excelBase.GetRange(iColStart, iRowStart + i, iColStart + +dt.Columns.Count - 1, iRowStart + i);
                excRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                excRange.Borders.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                excRange = excelBase.GetRange(iColStart + iColCountMerge, iRowStart + i, iColStart + +dt.Columns.Count - 1, iRowStart + i);
                excRange.Font.Bold = false;
                //merge cell
                if (isMergeCell)
                {
                    excelBase.MergeCellTitle(iColStart, iRowStart + i, iColCountMerge, iRowCountMerge);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="isFormatNumber"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private static object[,] ConvertData(DataTable dt, bool isFormatNumber, bool isConvertText)
        {
            int iCol = dt.Columns.Count;
            if (isFormatNumber)
            {
                iCol -= 1;
            }
            object[,] data = new object[dt.Rows.Count, iCol];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < iCol; j++)
                {
                    if (isConvertText)
                    {
                        data[i, j] = "'" + dt.Rows[i][j].ToString();
                    }
                    else
                    {
                        data[i, j] = dt.Rows[i][j].ToString();
                    }
                }
            }
            return data;
        }

        /// <summary>
        /// Export quotation
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public static void ExportQuotation(string strProjectName, int iQuotationIDSelected, string FORMAT_DDMMMYYYY)
        {
            string strFileName = clsMDConstant.EXCEL_TEMPLATE_NAME_DETAIL_DAILY_QUOTATION + clsMDBus.Instance().GetServerDate();
            string strTemplateName = clsMDConstant.EXCEL_TEMPLATE_FILE_DETAIL_DAILY_QUOTATION;
            bool isOPened = false;
            ExcelBase excelBase = new Config.Classes.ExcelBase(strFileName, strTemplateName, strProjectName, ref isOPened, clsMDBus.Instance().GetServerDate());
            if (isOPened)
                return;

            ///GET DATA
            clsMDQuotationDTO quotationObj = clsMDQuoationBus.Instance().GetQuotationDetail(iQuotationIDSelected);
            DataTable tdbQuotationECRate = clsMDQuoationBus.Instance().GetQuotationECRate(iQuotationIDSelected);
            tdbQuotationECRate.Columns.Remove(clsMDConstant.MD_COL_EXCHANGECCYPAIRID);
            DataTable tdbQuotationUSD = clsMDQuoationBus.Instance().GetQuotationDetailUSD(iQuotationIDSelected);
            DataTable tdbQuotationVND = clsMDQuoationBus.Instance().GetQuotationDetailVND(iQuotationIDSelected);

            excelBase.InsertText(9, 1, quotationObj.ImportTime.ToString(FORMAT_DDMMMYYYY));
            excelBase.InsertText(9, 2, quotationObj.EffectiveTime.ToString());
            excelBase.InsertText(9, 3, quotationObj.Seq.ToString());
            excelBase.InsertText(1, 4, clsMDNumberUtil.toOrdinal(quotationObj.Seq));
            excelBase.InsertText(1, 6, quotationObj.NoteHead);
            excelBase.InsertText(9, 11, quotationObj.CentralBankCoreRate);
            excelBase.InsertText(7, 12, quotationObj.CeilingRate.ToString());
            excelBase.InsertText(9, 12, quotationObj.FloorRate.ToString());

            int iColStart = 2;
            int iRowStart = 15;
            Excel.Range er;
            //Quotation USD
            if (tdbQuotationUSD != null && tdbQuotationUSD.Rows.Count > 0)
            {
                excelBase.InsertRows(iRowStart, tdbQuotationUSD.Rows.Count);
                er = excelBase.ExportRange(iColStart, iRowStart, iColStart + tdbQuotationUSD.Columns.Count - 2, iRowStart + tdbQuotationUSD.Rows.Count - 1, ConvertData(tdbQuotationUSD, true, false));
                er.Font.Size = 12;
                er.HorizontalAlignment = Excel.Constants.xlRight;
                MergeCellAndFormatNumber(excelBase, tdbQuotationUSD, true, iRowStart, 1, iColStart - 1, 2);
                excelBase.GetRange(iColStart - 1, iRowStart, iColStart, iRowStart + tdbQuotationUSD.Rows.Count - 1).HorizontalAlignment = Excel.Constants.xlCenter;
                iRowStart += tdbQuotationUSD.Rows.Count - 1;
            }
            else
            {
                excelBase.InsertRows(iRowStart, 1);
                iRowStart += 1;
            }

            //Quotation VND
            iRowStart = iRowStart + 3;
            if (tdbQuotationVND != null && tdbQuotationVND.Rows.Count > 0)
            {
                excelBase.InsertRows(iRowStart, tdbQuotationVND.Rows.Count);
                er = excelBase.ExportRange(iColStart, iRowStart, iColStart + tdbQuotationVND.Columns.Count - 2, iRowStart + tdbQuotationVND.Rows.Count - 1, ConvertData(tdbQuotationVND, true, false));
                er.Font.Size = 12;
                er.HorizontalAlignment = Excel.Constants.xlRight;
                MergeCellAndFormatNumber(excelBase, tdbQuotationVND, true, iRowStart, 1, iColStart - 1, 2);
                //Pls refer below to enter the E/C rate
                er = excelBase.Worksheet.get_Range(excelBase.Worksheet.Cells[iRowStart - 1, tdbQuotationVND.Columns.Count + 1],
                                                excelBase.Worksheet.Cells[iRowStart - 1 + tdbQuotationVND.Rows.Count, tdbQuotationVND.Columns.Count + 2]);
                er.Merge(false);
                er.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                er.Borders.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                excelBase.GetRange(iColStart - 1, iRowStart, iColStart, iRowStart + tdbQuotationUSD.Rows.Count - 1).HorizontalAlignment = Excel.Constants.xlCenter;
                iRowStart += tdbQuotationVND.Rows.Count - 1;
            }
            else
            {
                excelBase.InsertRows(iRowStart, 1);
                iRowStart += 1;
            }
            //TC
            iRowStart = iRowStart + 2;
            excelBase.InsertText(6, iRowStart, quotationObj.TC);

            //Note ThresHold
            iRowStart = iRowStart + 2;
            string strThreshold = quotationObj.NoteThreshold.Trim();
            string strThresholdParam = clsMDBus.Instance().GetParamThreshold();
            string strThreholdValue = clsMDQuoationBus.Instance().GetThresholdValue();
            if (strThreshold.IndexOf(strThresholdParam) > -1)
            {
                strThreshold = strThreshold.Replace(strThresholdParam, strThreholdValue);
            }
            excelBase.InsertText(1, iRowStart, strThreshold);
            excelBase.GetRange(1, iRowStart, 9, iRowStart).RowHeight = 39;
            excelBase.GetRange(1, iRowStart, 9, iRowStart).Font.Bold = false;
            excelBase.GetRange(1, iRowStart, 9, iRowStart).HorizontalAlignment = Excel.Constants.xlLeft;
            excelBase.GetRange(1, iRowStart, 9, iRowStart).VerticalAlignment = Excel.Constants.xlTop;

            //Note Mid
            iRowStart = iRowStart + 1;
            excelBase.InsertText(1, iRowStart, quotationObj.NoteMid.Trim());
            excelBase.GetRange(1, iRowStart, 9, iRowStart).RowHeight = 200;
            excelBase.GetRange(1, iRowStart, 9, iRowStart).Font.Bold = false;
            excelBase.GetRange(1, iRowStart, 9, iRowStart).HorizontalAlignment = Excel.Constants.xlLeft;
            excelBase.GetRange(1, iRowStart, 9, iRowStart).VerticalAlignment = Excel.Constants.xlTop;

            //ECRate            
            iRowStart = iRowStart + 8;
            if (tdbQuotationECRate != null && tdbQuotationECRate.Rows.Count > 0)
            {
                excelBase.InsertRows(iRowStart, tdbQuotationECRate.Rows.Count);
                er = excelBase.ExportRange(iColStart, iRowStart, iColStart + tdbQuotationECRate.Columns.Count - 1, iRowStart + tdbQuotationECRate.Rows.Count - 1, ConvertData(tdbQuotationECRate, false, true));
                er.Font.Bold = false;
                er.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                for (int i = iRowStart; i < (iRowStart + tdbQuotationECRate.Rows.Count); i++)
                {
                    if (i % 2 == 0)
                    {
                        er = excelBase.ExportRange(iColStart, i, iColStart + tdbQuotationECRate.Columns.Count - 1, i, ConvertData(tdbQuotationECRate, false, true));
                        er.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(255, 204, 153));
                    }
                }
                er.HorizontalAlignment = Excel.Constants.xlRight;
                iRowStart += tdbQuotationECRate.Rows.Count - 1;
            }
            else
            {
                excelBase.InsertRows(iRowStart, 1);
                iRowStart += 1;
            }
            //Note End
            iRowStart = iRowStart + 2;
            List<string> lstNoteEnd = AnalyzeNoteEnd(quotationObj.NoteEnd);
            //excelBase.InsertText(1, iRowStart, quotationObj.NoteEnd.Trim());
            excelBase.InsertText(1, iRowStart, lstNoteEnd[0]);
            excelBase.InsertText(6, iRowStart, lstNoteEnd[1]);
            excelBase.GetRange(1, iRowStart, 9, iRowStart).HorizontalAlignment = Excel.Constants.xlLeft;
            excelBase.GetRange(1, iRowStart, 9, iRowStart).VerticalAlignment = Excel.Constants.xlTop;
            excelBase.GetRange(1, iRowStart, 9, iRowStart).RowHeight = 80;
            excelBase.SaveFileNotAutoFitColumns();
            //excelBase.SaveFile();
        }

        /// <summary>
        /// Analyzing NoteEnd to 2 group
        /// </summary>
        /// <param name="strNoteEnd"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public static List<string> AnalyzeNoteEnd(string strNoteEnd)
        {
            List<string> result = new List<string>();
            string strNoteLeft = string.Empty;
            string strNoteRight = string.Empty;

            ////2013.06.06 vlhcnhung S
            if (!string.IsNullOrEmpty(strNoteEnd))
            {
                string[] arrNoteEnd = strNoteEnd.Split(char.Parse("\n"));
                if (arrNoteEnd.Length > 0)
                {
                    int maxLength = 0;
                    for (int i = 0; i < arrNoteEnd.Length; i++)
                    {
                        //remove \r character
                        arrNoteEnd[i] = arrNoteEnd[i].Replace("\r", "");
                        if (!string.IsNullOrEmpty(arrNoteEnd[i]))
                        {
                            //remove start with \t
                            int index = arrNoteEnd[i].IndexOf("\t");
                            while (index == 0)
                            {
                                arrNoteEnd[i] = arrNoteEnd[i].Remove(index, 1);
                                index = arrNoteEnd[i].IndexOf("\t");
                            }
                            //remove end with \t
                            index = arrNoteEnd[i].LastIndexOf("\t");
                            while (index == (arrNoteEnd[i].Length - 1))
                            {
                                arrNoteEnd[i] = arrNoteEnd[i].Remove(index, 1);
                                index = arrNoteEnd[i].LastIndexOf("\t");
                            }
                            arrNoteEnd[i] = arrNoteEnd[i].Replace("     ", "\t");
                        }
                    }
                    List<string> lstNoteLeft = new List<string>();
                    List<string> lstNoteRight = new List<string>();
                    for (int i = 0; i < arrNoteEnd.Length; i++)
                    {
                        List<string> lstChildNote = new List<string>();
                        string[] arrChildNote = arrNoteEnd[i].Split(char.Parse("\t"));
                        if (arrChildNote.Length > 0)
                        {
                            for (int j = 0; j < arrChildNote.Length; j++)
                            {
                                if (!string.IsNullOrEmpty(arrChildNote[j]))
                                {
                                    lstChildNote.Add(arrChildNote[j].TrimStart().TrimEnd());
                                }
                            }
                        }
                        if (lstChildNote.Count == 1)
                        {
                            if (!string.IsNullOrEmpty(lstChildNote[0].Trim()))
                            {
                                lstNoteLeft.Add(lstChildNote[0]);
                            }
                        }
                        else if (lstChildNote.Count == 2)
                        {
                            if (!string.IsNullOrEmpty(lstChildNote[0].Trim()))
                            {
                                lstNoteLeft.Add(lstChildNote[0]);
                            }
                            if (!string.IsNullOrEmpty(lstChildNote[1].Trim()))
                            {
                                lstNoteRight.Add(lstChildNote[1]);
                            }
                        }
                    }

                    for (int i = 0; i < lstNoteLeft.Count; i++)
                    {
                        if (i == 0)
                        {
                            strNoteLeft += lstNoteLeft[i];
                        }
                        else
                        {
                            strNoteLeft += Environment.NewLine + new string(char.Parse(" "), 7) + lstNoteLeft[i];
                        }

                    }
                    for (int i = 0; i < lstNoteRight.Count; i++)
                    {
                        if (i == 0)
                        {
                            strNoteRight += lstNoteRight[i];
                        }
                        else
                        {
                            strNoteRight += Environment.NewLine + new string(char.Parse(" "), 7) + lstNoteRight[i];
                        }
                    }
                }
            }
            result.Add(strNoteLeft);
            result.Add(strNoteRight);
            return result;
            ////2013.06.06 vlhcnhung E
        }


        /// <summary>
        /// Check object is null or empty
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static bool isNullOrEmpty(object obj)
        {
            try
            {
                if (obj == null)
                    return true;
                if (obj.ToString().Trim().Equals("") || obj.ToString().Trim().Equals("null"))
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Convert object to date with format
        /// </summary>
        /// <param name="strDate"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public static DateTime? ConvertObjectToNullDateTime(object objDate)
        {
            //check strDate is NULL
            if (objDate == null)
            {
                return new Nullable<DateTime>();
            }
            DateTime? returnDate = new DateTime();
            try
            {
                returnDate = Convert.ToDateTime(objDate);
            }
            catch
            {
                return new Nullable<DateTime>();
            }
            return returnDate;
        }

        /// <summary>
        /// Convert object to date with format
        /// </summary>
        /// <param name="strDate"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public static DateTime? ConvertObjectToNullDateTime(object objDate, string format)
        {
            //check strDate is NULL
            if (objDate == null)
            {
                return new Nullable<DateTime>();
            }
            DateTime? returnDate = new DateTime();
            try
            {
                returnDate = ConvertObjectToNullDateTime(objDate);
                if (returnDate != null)
                    return returnDate;
                returnDate = DateTime.ParseExact(objDate.ToString(), format, null);
            }
            catch
            {
                return new Nullable<DateTime>();
            }
            return returnDate;
        }

        /// <summary>
        /// Convert object to string
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ConvertObjectToString(object str)
        {
            //check str is Null
            if (str == null)
            {
                return String.Empty;
            }
            try
            {
                string returnStr = str.ToString().Trim();
                return returnStr;
            }
            catch (System.Exception)
            {
                return String.Empty;
            }
        }

        /// <summary>
        /// Convert string to Decimal?
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public static Decimal? ConvertObjectToNullDecimal(object str)
        {
            //check str is Null
            if (str == null)
            {
                return new Nullable<Decimal>();
            }
            Decimal? returnInt = new Nullable<Decimal>();
            try
            {
                returnInt = Decimal.Parse(str.ToString());
            }
            catch (System.Exception)
            {
                return new Nullable<Decimal>();
            }
            return returnInt;
        }

        /// <summary>
        /// Get Board Rate Status Name
        /// </summary>
        /// <param name="weekDay"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public static string GetBoardRateStatusName(int status)
        {
            switch (status)
            {
                case (int)clsMDCommonValue.BoardRateStatus.New:
                    return clsMDConstant.BOARD_RATE_STATUS_New;

                case (int)clsMDCommonValue.BoardRateStatus.WaitingforApprove:
                    return clsMDConstant.BOARD_RATE_STATUS_WaitForApproval;

                case (int)clsMDCommonValue.BoardRateStatus.Approved:
                    return clsMDConstant.BOARD_RATE_STATUS_Approved;

                case (int)clsMDCommonValue.BoardRateStatus.Withdrawed:
                    return clsMDConstant.BOARD_RATE_STATUS_Withdrawed;

                case (int)clsMDCommonValue.BoardRateStatus.Returned:
                    return clsMDConstant.BOARD_RATE_STATUS_Returned;

                case (int)clsMDCommonValue.BoardRateStatus.Suspended:
                    return clsMDConstant.BOARD_RATE_STATUS_Suspended;

                case (int)clsMDCommonValue.BoardRateStatus.Obsolete:
                    return clsMDConstant.BOARD_RATE_STATUS_Obsolete;

                case (int)clsMDCommonValue.BoardRateStatus.Freeze:
                    return clsMDConstant.BOARD_RATE_STATUS_Freeze;

                default:
                    break;
            }
            return "";
        }

        /// <summary>
        /// Get Board Rate Status Name
        /// </summary>
        /// <param name="weekDay"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public static string GetTransTypeName(int transType)
        {
            switch (transType)
            {
                case clsMDConstant.BOARD_RATE_TRANS_TYPE_DEPOSIT:
                    return clsMDConstant.BOARD_RATE_DEPOSIT;

                case clsMDConstant.BOARD_RATE_TRANS_TYPE_LOAN:
                    return clsMDConstant.BOARD_RATE_LOAN;

                default:
                    break;
            }
            return "";
        }
    }

    public class ItemComparer : IComparer
    {
        //column used for comparison
        public int Column { get; set; }
        //Order of sorting
        public SortOrder Order { get; set; }
        public ItemComparer(int colIndex)
        {
            Column = colIndex;
            Order = SortOrder.None;
        }
        public int Compare(object a, object b)
        {
            int result;
            ListViewItem itemA = a as ListViewItem;
            ListViewItem itemB = b as ListViewItem;
            if (itemA == null && itemB == null)
                result = 0;
            else if (itemA == null)
                result = -1;
            else if (itemB == null)
                result = 1;
            if (itemA == itemB)
                result = 0;
            //alphabetic comparison
            result = String.Compare(itemA.SubItems[Column].Text, itemB.SubItems[Column].Text);
            // if sort order is descending.
            if (Order == SortOrder.Descending)
                // Invert the value returned by Compare.
                result *= -1;
            return result;
        }
    }
}
