﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-01-08 20:37:30 +0700 (Mon, 08 Jan 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to provide function to create an excel file
 * for CPA module.

 */
using System;
using System.Runtime.InteropServices;
using System.Diagnostics;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using System.IO;

namespace Phoenix.Common.MasterData.Com
{
    /// <summary>
    /// This class define function processing export data to excel file
    /// </summary>
    public class clsExcelBase
    {
        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        #region Properties
        /// <summary>
        /// Please add this reference to your solution		
        /// Add Microsoft.Office.Interop.Excel reference, its default path is:
        /// Visual Studio Tools for Office\ PIA\Office12\Microsoft.Office.Interop.Excel.dll 
        /// </summary>        
        private Microsoft.Office.Interop.Excel.Application app = null;

        public Microsoft.Office.Interop.Excel.Application App
        {
            get { return app; }
            set { app = value; }
        }

        //Workbooks workbooks;

        private Microsoft.Office.Interop.Excel.Workbook workbook = null;

        public Microsoft.Office.Interop.Excel.Workbook Workbook
        {
            get { return workbook; }
            set { workbook = value; }
        }

        Sheets worksheets;

        public Sheets Worksheets
        {
            get { return worksheets; }
            set { worksheets = value; }
        }

        private Microsoft.Office.Interop.Excel.Worksheet worksheet = null;

        public Microsoft.Office.Interop.Excel.Worksheet Worksheet
        {
            get { return worksheet; }
            set { worksheet = value; }
        }

        private string excelFilePath;

        /// <summary>
        /// File is exported.
        /// </summary>
        public string ExcelFilePath
        {
            get { return excelFilePath; }
            set { excelFilePath = value; }
        }

        private string templateFilePath;

        /// <summary>
        /// File template
        /// </summary>
        public string TemplateFilePath
        {
            get { return templateFilePath; }
            set { templateFilePath = value; }
        }

        private bool isAutoFixColumn = false;

        public bool IsAutoFixColumn
        {
            get { return isAutoFixColumn; }
            set { isAutoFixColumn = value; }
        }

        private bool isAutoFixRow = false;

        public bool IsAutoFixRow
        {
            get { return isAutoFixRow; }
            set { isAutoFixRow = value; }
        }

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="strFilePath"></param>        
        //private clsExcelBase(string strTemplateFileName, string strFilePath)
        //{
        //    templateFilePath = strTemplateFileName;
        //    excelFilePath = strFilePath;

        //    if (File.Exists(strFilePath))
        //    {
        //        File.Delete(strFilePath);
        //    }

        //    File.Copy(strTemplateFileName, strFilePath);

        //    CreateExcel();
        //}

        /// <summary>
        /// Constructor for read file excel
        /// </summary>
        /// <param name="strFilePath"></param>        
        public clsExcelBase(string strFilePath)
        {
            excelFilePath = strFilePath;
            CreateExcel();
        }

        /// <summary>
        /// Constructor for write file excel from file template
        /// </summary>
        /// <param name="strFilePath"></param>
        /// <param name="strTemplateName"></param>
        /// <param name="strProjectName"></param>
        /// <param name="serverDate"></param>
        public clsExcelBase(string strTemplateName, string strProjectName, string serverDate)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + strProjectName + "_GUI\\FORM\\REPORT\\TEMPLATE\\";
            CreateFile(path, strTemplateName, serverDate);
            CreateExcel();
        }

        /// <summary>
        /// Check if this file is opened or not
        /// </summary>
        /// <param name="strFileName"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond		
        private bool IsOpened(string strFileName)
        {
            FileStream stream = null;
            FileInfo file = new FileInfo(strFileName);
            if (!File.Exists(strFileName))
                return false;
            try
            {
                stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException e)
            {
                //the file is unavailable because it is:
                //still being written to
                //or being processed by another thread
                //or does not exist (has already been processed)            
                //clsCommonFunctions.ShowWarningDialog(clsCommonMessages.ALREADY_OPENED);
                //clsLogFile.LogException(e.Message);
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }

            //file is not locked
            return false;
        }

        /// <summary>
        /// Create template before export report
        /// </summary>
        /// <param name="path"></param>
        /// <param name="name"></param>
        private void CreateFile(string path, string name, string serverDate)
        {
            String appData = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Template");
            string FilePath = appData;
            try
            {
                System.IO.Directory.Delete(appData, true);
            }
            catch (Exception ex)
            {
            }
            try
            {
                System.IO.Directory.CreateDirectory(appData);
            }
            catch (Exception ex)
            {
            }

            string strFilePath = path;
            string fileName = name;

            string newFileName = fileName.Remove(fileName.Length - 4, 4) + serverDate + "_" + ".xls";
            try
            {
                excelFilePath = appData + "\\" + newFileName;
                if (File.Exists(appData + "\\" + newFileName))
                {
                    File.Delete(appData + "\\" + newFileName);
                }
                File.Copy(strFilePath + "" + fileName, appData + "\\" + newFileName);                
            }
            catch (Exception ex)
            {
            }
        }

        /// <summary>
        /// Initialize File
        /// </summary>        
        private void CreateExcel()
        {
            app = new Excel.Application();

            workbook = app.Workbooks.Open(ExcelFilePath, Type.Missing, true, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

            worksheets = workbook.Sheets;

            //get first sheet of file excel
            worksheet = (Microsoft.Office.Interop.Excel.Worksheet)worksheets.get_Item(1);


        }

        /// <summary>
        /// Save the generated excel file
        /// </summary>
        /// <param name="strFilePath"></param>        
        public void SaveFile()
        {
            if (isAutoFixColumn)
            {
                worksheet.Columns.AutoFit();
            }
            if (isAutoFixRow)
            {
                worksheet.Rows.AutoFit();
            }
            app.Visible = true;
           
            //ReleaseExcel();
        }

        /// <summary>
        /// Release excel object
        /// </summary>
        private void ReleaseExcel()
        {
            int hWnd = app.Application.Hwnd;
            uint processID;

            ReleaseObject(worksheet);
            ReleaseObject(workbook);
            ReleaseObject(app);
            app.Quit();

            GetWindowThreadProcessId((IntPtr)hWnd, out processID);
            Process[] procs = Process.GetProcessesByName("EXCEL");
            foreach (Process p in procs)
            {
                if (p.Id == processID)
                    p.Kill();
            }
        }

        /// <summary>
        /// Release Excel Object
        /// </summary>
        /// <param name="obj"></param>        
        private void ReleaseObject(object obj)
        {
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            obj = null;
            GC.Collect();
        }

        /// <summary>
        /// Kill process excel
        /// </summary>
        /// <param name="application"></param>        
        public static void KillProcessExcel(Microsoft.Office.Interop.Excel.Application application)
        {
            application.Quit();

            int hWnd = application.Application.Hwnd;
            uint processID;

            System.Runtime.InteropServices.Marshal.ReleaseComObject(application);

            GetWindowThreadProcessId((IntPtr)hWnd, out processID);
            Process[] procs = Process.GetProcessesByName("EXCEL");
            foreach (Process p in procs)
            {
                if (p.Id == processID)
                    p.Kill();
            }
        }

        /// <summary>
        /// Get a group of cell belongs to the index of column(start & end)  and row(start & end)
        /// EX: cellStart = "A1", cellEnd = "E100"
        /// </summary>
        /// <param name="cellStart"></param>
        /// <param name="cellEnd"></param>
        /// <returns></returns>
        public Excel.Range GetRange(string cellStart, string cellEnd)
        {
            Excel.Range excRange = null;
            // get the range to fill.
            excRange = worksheet.get_Range(cellStart, cellEnd);//"A1", "E100");
            return excRange;
        }

        /// <summary>
        /// Export data to a range in excel
        /// EX: cellStart = "A1", cellEnd = "E100"
        /// </summary>
        /// <param name="cellStart"></param>
        /// <param name="cellEnd"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public Excel.Range ExportRange(string cellStart, string cellEnd, object[,] data)
        {
            Excel.Range excRange = GetRange(cellStart, cellEnd);

            excRange.set_Value(Microsoft.Office.Interop.Excel.XlRangeValueDataType.xlRangeValueDefault, (object)data);

            Excel.Borders borders = excRange.Borders;

            excRange.Borders.Color = System.Drawing.Color.Black.ToArgb();
            if (excRange.Rows.Count > 1)
            {
                borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle = Excel.XlLineStyle.xlContinuous;
                borders[Excel.XlBordersIndex.xlInsideHorizontal].Weight = Excel.XlBorderWeight.xlHairline;
            }
            borders = null;
            return excRange;
        }

        /// <summary>
        /// Export data to a range in excel don't draw border
        /// EX: cellStart = "A1", cellEnd = "E100"
        /// </summary>
        /// <param name="cellStart"></param>
        /// <param name="cellEnd"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public Excel.Range ExportRangeNoBoder(string cellStart, string cellEnd, object[,] data)
        {
            Excel.Range excRange = GetRange(cellStart, cellEnd);

            excRange.set_Value(Microsoft.Office.Interop.Excel.XlRangeValueDataType.xlRangeValueDefault, (object)data);
            return excRange;
        }


        /// <summary>
        /// Export data to a range in excel
        /// EX: cellStart = "A1", cellEnd = "E100"
        /// </summary>
        /// <param name="cellStart"></param>
        /// <param name="cellEnd"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public Excel.Range ExportRangeWithInsertion(string columnStart, int rowStart, string columnEnd, int rowEnd, object[,] data)
        {
            Excel.Range excTempRange = GetRange(columnStart + rowStart, columnEnd + rowStart);

            for (int i = rowStart; i < rowEnd; i++)
            {
                excTempRange.EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftToRight, Microsoft.Office.Interop.Excel.XlInsertFormatOrigin.xlFormatFromRightOrBelow);
            }

            Excel.Range excRange = GetRange(columnStart + rowStart, columnEnd + rowEnd);
            excRange.set_Value(Microsoft.Office.Interop.Excel.XlRangeValueDataType.xlRangeValueDefault, (object)data);

            Excel.Borders borders = excRange.Borders;

            excRange.Borders.Color = System.Drawing.Color.Black.ToArgb();
            if (excRange.Rows.Count > 1)
            {
                borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle = Excel.XlLineStyle.xlContinuous;
                borders[Excel.XlBordersIndex.xlInsideHorizontal].Weight = Excel.XlBorderWeight.xlHairline;
            }
            borders = null;
            return excRange;
        }

        /// <summary>
        /// Set object for a cell in excel file
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="strText"></param>
        public void InsertCellObject(int iRowStart, int iColStart, object obj)
        {
            worksheet.Cells[iRowStart, iColStart] = obj;
        }

        /// <summary>
        /// Set Picture For Cell
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="imgObj"></param>        
        [STAThread]
        public void InsertPicture(int iRowStart, int iColStart, string imgPath, double imgWidth, double imgHeight)
        {
            object misValue = System.Reflection.Missing.Value;
            Excel.Range rangeObj = (Excel.Range)worksheet.Cells[iRowStart, iColStart];
            Excel.Pictures imgObjCollection = worksheet.Pictures(misValue) as Excel.Pictures;
            Excel.Picture imgObj = null;
            imgObj = imgObjCollection.Insert(imgPath, misValue);
            imgObj.Left = Convert.ToDouble(rangeObj.Left) + (Convert.ToDouble(rangeObj.Width) - imgWidth) / 2;
            imgObj.Top = Convert.ToDouble(rangeObj.Top);
            imgObj.Width = imgWidth;
            imgObj.Height = imgHeight;
        }

        /// <summary>
        /// Return column name in excel file belongs to the index of this column
        /// </summary>
        /// <param name="columnNumber"></param>
        /// <returns></returns>
        public static string GetExcelColumnName(int columnNumber)
        {
            int dividend = columnNumber;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                dividend = (int)((dividend - modulo) / 26);
            }

            return columnName;
        }

    }
}
