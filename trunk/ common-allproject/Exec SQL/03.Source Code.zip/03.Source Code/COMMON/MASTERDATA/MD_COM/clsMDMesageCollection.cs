﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define message collection form
 * for Master Data module.
 */
using System.Collections.Generic;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Popup;

namespace Phoenix.Common.MasterData.Com
{
	public class clsMDMesageCollection
	{

		/// <summary>
		/// Show message no transaction found
		/// </summary>
		public static void MessageNoTransactions()
		{

			frmPhoenixMessage frm = new frmPhoenixMessage((int) CommonValue.MessageType.Infomaition,
													"No transaction found");
			frm.ShowDialog();

		}

		///// <summary>
		///// 
		///// </summary>
		///// <param name="type"></param>
		///// <param name="format"></param>
		///// <param name="param"></param>
		///// <returns></returns>
		//public static DialogResult ShowMessage(int type, string format, string[] param)
		//{
		//    frmPhoenixMessage frmMsg = new frmPhoenixMessage(type, format, param);
		//    return frmMsg.ShowDialog();
		//}


		/// <summary>
		/// Confirm = 0,
		/// Error = 1,
		/// Infomaition =2
		/// </summary>
		/// <param name="type"></param>
		/// <param name="msg"></param>
		/// <returns></returns>
		internal static DialogResult ShowMessage(int type, string msg)
		{
			frmPhoenixMessage frmMsg = new frmPhoenixMessage(type, msg);
			return frmMsg.ShowDialog();
		}

        /// <summary>
        /// Confirm = 0,
        /// Error = 1,
        /// Infomaition =2
        /// </summary>
        /// <param name="type"></param>
        /// <param name="msg"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        internal static DialogResult ShowMessage(int type, string msg, int height)
        {
            frmPhoenixMessage frmMsg = new frmPhoenixMessage(type, msg);
            frmMsg.Height = height;
            frmMsg.Width = height * 4;
            return frmMsg.ShowDialog();
        }
	}
}