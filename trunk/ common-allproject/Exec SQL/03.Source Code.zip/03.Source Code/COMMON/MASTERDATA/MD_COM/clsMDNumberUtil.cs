﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to handle number
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Com
{
	public class clsMDNumberUtil
	{
		public static String[] ORDINAL_SUFFIXES = { "th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th" };

		public static String ordinalSuffix(int value)
		{
			int n = Math.Abs(value);
			int lastTwoDigits = n % 100;
			int lastDigit = n % 10;
			int index = (lastTwoDigits >= 11 && lastTwoDigits <= 13) ? 0 : lastDigit;
			return ORDINAL_SUFFIXES[index];
		}

		public static String toOrdinal(int n)
		{
			return n.ToString() + ordinalSuffix(n);
		}
	}
}