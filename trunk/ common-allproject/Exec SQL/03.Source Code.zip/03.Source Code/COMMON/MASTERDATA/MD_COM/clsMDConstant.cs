﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-13 (Web, 13 March 2013) $
 * ========================================================
 * This class is used to define common constants
 * For Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Phoenix.Common.MasterData.Com
{
    public static class clsMDConstant
    {
        #region COMMON
        /// <summary>
        /// Form background color
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public static Color BG_FORM = System.Drawing.ColorTranslator.FromHtml("#E0DFE3");
        /// <summary>
        /// Button background color
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public static Color BG_BUTTON = System.Drawing.ColorTranslator.FromHtml("#F6F7FD");
        /// <summary>
        /// Different Quotaion item background color
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public static Color BG_DATAGRID_DIFF_QUOTATION = System.Drawing.ColorTranslator.FromHtml("#50D17D");
        /// <summary>
        /// Datagridview background color
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public static Color BG_DATAGRID_HEADER = System.Drawing.ColorTranslator.FromHtml("#F9FAFD");
        /// <summary>
        /// Datagridview selection back color
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public static Color DGV_SELECTION_BACK_COLOR = System.Drawing.ColorTranslator.FromHtml("#335EA8");// Color.SteelBlue;
        /// <summary>
        /// Readonly datagridview  background color
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public static Color BG_DGV_READONLY_COLUMN = Color.FromArgb(229, 225, 198);
        /// <summary>
        /// Readonly textbox background color
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public static Color BG_TEXTBOX_READONLY = System.Drawing.ColorTranslator.FromHtml("#E0DFE3");
        #endregion

        #region PATTERN
        //public const string DATETIME_FORMAT_YYYYMMDD = "yyyy/MM/dd";
        /// <summary>
        /// Datetime format
        /// </summary>
        public const string DATETIME_FORMAT_DDMMMYYYY = "dd-MMM-yyyy";
        /// <summary>
        /// Datetime format
        /// </summary>
        public const string DATETIME_FORMAT_DMMMYY = "d-MMM-yy";
        /// <summary>
        /// File import filter
        /// </summary>
        public const string DIALOG_IMPORT_FILTER_TXT_EXCEL = "Excel Worksheets 2003(*.xls)|*.xls";
        /// <summary>
        /// Number format
        /// </summary>
        public const string NUMBER_FORMAT = "#,###.#####";

        public const string PATTERN_PASSWORD = @"(?=^.{8,}$)(?=.*\d)(?=.*[a-zA-Z])(?!.*\s)[0-9a-zA-Z!@#$%^&*+=]*$";
        #endregion

        #region EXPORT
        public static string[] HEADER_HOLIDAY_EXPORT = new string[] { "CCY", "YEAR", "HOLIDAYS" };
        public static string[] HEADER_QUOTATION_EXPORT_CURRENCY_INQUIRY_HISTORY = new string[] { "SEQ", "DATE", "TIME", "INACTIVE", "CCY PAIR", "TTM", "TTB", "TTS", "CSB", "CSS" };
        public static string[] HEADER_QUOTATION_EXPORT_TRANSACTION_LOG = new string[] { "USER NAME", "FULL NAME", "UPDATED DATE", "MODULE", "USER ACTION", "APPLICATION NAME", "CONTENT" };
        public static string[] HEADER_QUOTATION_EXPORT_EXTERNAL_LOG = new string[] { "USER NAME", "FULL NAME", "LOG DATE", "MODULE", "FILE NAME", "FILE PATH", "FILE TYPE", "INVALID DATA", "ERROR MESSAGE" };
        public static string[] HEADER_CUSTOMER_EXPORT = new string[] { "SPECIAL", "CUSTOMER CODE", "FULL NAME", "SHORT NAME", "CUSTOMER TYPE" };

        public const string EXCEL_TEMPLATE_NAME_CURRENCY_HOLIDAY = "CURRENCY HOLIDAY LIST";
        public const string EXCEL_TEMPLATE_NAME_CURRENCY_INQUIRY_QUOTATION_HISTORY = "CURRENCY INQUIRY QUOTATION HISTORY LIST";
        /// <summary>
        /// File name to export of transaction log list
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string EXCEL_TEMPLATE_NAME_TRANSACTION_LOG = "TRANSACTION LOG LIST";
        /// <summary>
        /// File name to export of external log list
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string EXCEL_TEMPLATE_NAME_EXTERNAL_LOG = "EXTERNAL LOG LIST";
        /// <summary>
        /// Export file name of quotation detail
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string EXCEL_TEMPLATE_NAME_DETAIL_DAILY_QUOTATION = "DETAIL_DAILY_QUOTATION";

        /// <summary>
        /// Template file name of quotation detail to export 
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string EXCEL_TEMPLATE_FILE_DETAIL_DAILY_QUOTATION = "DETAIL DAILY QUOTATION.xls";

        public const string EXCEL_TEMPLATE_FILE_CURRENCY_HOLIDAY = "CURRENCY HOLIDAY LIST.xls";
        public const string EXCEL_TEMPLATE_FILE_CURRENCY_QUOTATION = "CURRENCY INQUIRY QUOTATION HISTORY.xls";
        /// <summary>
        /// Transaction log template file
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string EXCEL_TEMPLATE_FILE_TRANSACTION_LOG = "TRANSACTION LOG LIST.xls";
        /// <summary>
        /// External transaction log template file
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string EXCEL_TEMPLATE_FILE_EXTERNAL_LOG = "EXTERNAL LOG LIST.xls";
        /// <summary>
        /// File name to export of external log list
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string EXCEL_TEMPLATE_NAME_SPECIALCUSTOMER = "SPECIAL CUSTOMER LIST";
        public const string EXCEL_TEMPLATE_NAME_CICUSTOMER = "CI CUSTOMER LIST";

        /// <summary>
        /// Customer template file
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string EXCEL_TEMPLATE_FILE_SPECIALCUSTOMER = "SPECIAL CUSTOMER LIST.xls";
        public const string EXCEL_TEMPLATE_FILE_CICUSTOMER = "CI CUSTOMER LIST.xls";
        #endregion

        #region PROJECT_NAME
        /// <summary>
        /// Master data Project Name of
        /// </summary>
        public const string PROJECT_NAME_MASTERDATA = "MASTERDATA\\MD";
        #endregion

        #region TITTLE-FORM

        #region DEPARTMNET
        public const string DEPT_TITLE_LIST = "Department List";
        public const string DEPT_TITLE_CREATE = "Create Department";
        public const string DEPT_TITLE_MODIFY = "Modify Department";
        public const string DEPT_TITLE_ASSIGN_USER = "Assign Users to Department";
        #endregion

        #region USER
        public const string USER_TITLE_LIST = "User List";
        public const string USER_TITLE_CREATE = "Create User";
        public const string USER_TITLE_MODIFY = "Modify User";
        public const string USER_TITLE_ASSIGN_DEPT = "Assign Departments to User";
        public const string USER_TITLE_ASSIGN_TEAM = "Assign Teams to User";
        #endregion

        #region TEAM
        public const string TEAM_TITLE_LIST = "Team List";
        public const string TEAM_TITLE_CREATE = "Create Team";
        public const string TEAM_TITLE_MODIFY = "Modify Team";
        public const string TEAM_TITLE_ASSIGN_USER = "Assign Users to Team";
        #endregion

        #region DAY OFF REGIT
        public const string HOLIDAY_TITLE = "Currency Holiday";
        public const string HOLIDAY_EXPORT_EXCEL_CAPTION = "Currency Holiday List";
        #endregion

        #region QUOTATION
        /// <summary>
        /// Title of import quotation dialog
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string QUOTATION_TITLE_IMPORT = "Import Quotation";
        /// <summary>
        /// USD
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string USD = "USD";
        /// <summary>
        /// VND
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string VND = "VND";

        public const string QUOTATION_TITLE = "Currency Inquiry Quotation HisTory";
        public const string QUOTATION_EXPORT_EXCEL_CAPTION = "Currency Inquiry Quotation HisTory List";

        /// <summary>
        /// Screen of Maker's Text
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string PROCESSING_DAILY_QUOTATION_MAKER = "Processing Daily Quotation (Maker)";
        /// <summary>
        /// Screen of Approver's Text
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string PROCESSING_DAILY_QUOTATION_APPROVER = "Processing Daily Quotation (Approver)";
        /// <summary>
        /// Screen's Text
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string PROCESSING_DAILY_QUOTATION = "Processing Daily Quotation";

        /// <summary>
        /// Title of Customer dialog
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string SPECIAL_CUSTOMER = "SPECIAL";
        public const string INDIRECT_INVESTOR = "INDIRECT_INVESTOR";
        public const string FXAT_CODE_CUSTOMER = "FXAT_CODE";
        public const string CI_CUSTOMER = "CI";
        /// <summary>
        /// Title of Special Customer dialog
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string CUSTOMER_SPECIAL_TITLE_LIST = "Special Customer List";
        public const string CUSTOMER_SPECIAL_TITLE_UPDATE = "Update Special Customer";

        /// <summary>
        /// Title of Indirect Investor dialog
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string CUSTOMER_INDIRECT_INVESTOR_TITLE_LIST = "FX Indirect Investor List";
        public const string CUSTOMER_INDIRECT_INVESTOR_TITLE_UPDATE = "Update FX Indirect Investor";
        /// <summary>
        /// Title of FXAT Code Customer dialog
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string CUSTOMER_FXATCODE_TITLE_LIST = "FXAT Code Customer List";
        public const string CUSTOMER_FXATCODE_TITLE_UPDATE = "Update FXAT Code Customer";
        /// <summary>
        /// Title of Transient Account Information
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string TRANSIENT_ACCOUNT_INFO_TITLE_LIST = "Transient Account Information";
        public const string TRANSIENT_ACCOUNT_INFO_TITLE_CREATE = "Create Transient Account Information";
        public const string TRANSIENT_ACCOUNT_INFO_TITLE_UPDATE = "Update Transient Account Information";
        /// <summary>
        /// Title of CI Customer dialog
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string CUSTOMER_CI_TITLE_LIST = "CI Customer List";
        public const string CUSTOMER_CI_TITLE_UPDATE = "Update CI Customer";
        #endregion
        #endregion

        #region COLUMN NAME LIST
        public const string MD_COLNAME = "ColumnName";
        public const string MD_COLNAME_COUNTRECORD = "CountRecord";

        public const string MD_COL_REMARK = "Remark";
        public const string MD_COL_DELFLAG = "DelFlag";
        public const string MD_COL_CREATED_BY = "CreatedBy";
        public const string MD_COL_UPDATE_DATE = "UpdateDate";

        public const string MD_COL_DEPARTMENTID = "DepartmentID";
        public const string MD_COL_DEPARTMENTCODE = "DepartmentCode";
        public const string MD_COL_DEPARTMENTNAME = "DepartmentName";

        public const string MD_COL_TEAMID = "TeamID";
        public const string MD_COL_TEAMCODE = "TeamCode";
        public const string MD_COL_TEAMNAME = "TeamName";

        public const string MD_COL_TEAMTYPEID = "TeamTypeID";
        public const string MD_COL_TEAMTYPECODE = "TeamTypeCode";
        public const string MD_COL_TEAMTYPENAME = "TeamTypeName";

        public const string MD_COL_USER_NO = "UserNo";
        public const string MD_COL_USERNAME = "UserName";
        public const string MD_COL_SHORTNAME = "ShortName";
        public const string MD_COL_FULLNAME = "FullName";
        public const string MD_COL_OFFICER = "Officer";
        public const string MD_COL_STAFF01 = "Staff01";
        public const string MD_COL_STAFF02 = "Staff02";
        public const string MD_COL_LOCKOUT = "Lockout";
        public const string MD_COL_PASSWORD = "Password";

        public const string MD_COL_CCYCODE = "CCYCode";
        public const string MD_COL_CCYNAME = "CurrencyName";
        public const string MD_COL_HOLIDAY_DATE = "HolidayDate";
        public const string MD_COL_HOLIDAY_YEAR = "HolidayYear";
        public const string MD_COL_MONTH = "HolidayMonth";

        public const string MD_COL_EXCHANGECCYPAIRID = "ExchangeCCYPairID";
        public const string MD_COL_EXCHANGECCYPAIR = "ExchangeCCYPair";
        public const string MD_COL_BASECCY = "BaseCCY";
        public const string MD_COL_QUOTECCY = "QuoteCCY";
        public const string MD_COL_CHECKEDCCYPAIR = "CheckedCCYPair";
        public const string MD_COL_STATUS = "Status";
        public const string MD_COL_QUOTATIONID = "QuotationID";
        public const string MD_COL_FORMATNUMBER = "FormatNumber";
        public const string MD_COL_FILEDIRECTORY = "FileDirectory";
        public const string MD_COL_VERSION = "Version";
        public const string MD_COL_IMPORT_TIME = "ImportTime";
        public const string MD_COL_EFFECTIVE_TIME = "EffectiveTime";

        public const string MD_COL_HOLIDAYS = "HOLIDAYS";
        public const string MD_COL_UPDATED_DATE = "UPDATED DATE";
        public const string MD_COL_YEAR = "YEAR";
        public const string MD_COL_CCY = "CCY";
        public const string MD_COL_CONTENT = "CONTENT";
        public const string MD_COL_LOG_DATE = "LOG DATE";
        public const string MD_COL_DATE = "DATE";
        public const string MD_COL_CCY_PAIR = "CCY PAIR";
        public const string MD_COL_SEQ = "SEQ";
        public const string MD_COL_INACTIVE = "INACTIVE";

        public const string MD_COL_CUSTOMERCODE = "CustomerCode";
        public const string MD_COL_CODE = "Code";
        public const string MD_COL_CUS_FULLNAME = "Name";
        public const string MD_COL_CUS_SHORTNAME = "ShortName";
        public const string MD_COL_CUSTOMERTYPE = "CustType";
        public const string MD_COL_SPECIAL = "Special";
        public const string MD_COL_INDIRECT_INVESTOR = "IndirectInvestor";
        public const string MD_COL_FXATCODE = "FXATCode";
        public const string MD_COL_LOCATION = "LocationCode";
        public const string MD_COL_CI = "CI";
        public const string MD_COL_CIT = "CIT";

        public const string MD_COL_ACCOUNT_NO = "AccountNo";
        public const string MD_COL_GLCODE = "GLCode";
        public const string MD_COL_GLSUBCODE = "GLSubCode";
        public const string MD_COL_DEPARTMENT_ID = "DepartmentId";
        public const string MD_COL_ACCOUNT_TYPE = "AccountType";
        public const string MD_COL_OPENDATE = "OpenDate";
        public const string MD_COL_CLOSEDATE = "CloseDate";
        #endregion

        #region QUOTATION STATUS
        /// <summary>
        /// Quotation status - new
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string QUOTATIONSTATUS_01_NEW = "New";
        /// <summary>
        /// Quotation status - Waiting for approve
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string QUOTATIONSTATUS_02_WAIITING_FOR_APPROVE = "Waiting for Approve";
        /// <summary>
        /// Quotation status - approved
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string QUOTATIONSTATUS_03_APPROVED = "Approved";
        /// <summary>
        /// Quotation status - withdrawn
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string QUOTATIONSTATUS_04_WITHDRAWN = "Withdrawn";
        /// <summary>
        /// Quotation status - returned
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string QUOTATIONSTATUS_05_RETURNED = "Returned";
        /// <summary>
        /// Quotation status - suspended
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string QUOTATIONSTATUS_06_SUSPENDED = "Suspended";
        /// <summary>
        /// Quotation status - obsolute
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string QUOTATIONSTATUS_07_OBSOLUTE = "Obsolete";
        #endregion

        #region IMPORT QUOTATION
        public const string QUOTATION_SHEETNAME_EQ_USD = "EQ_USD";
        public const string QUOTATION_SHEETNAME_EQ_VND = "EQ_VND";
        public const string QUOTATION_SHEETNAME_EC_RATE = "EC_Rate";

        public const string QUOTATION_IMPORT_DATE = "Date";
        public const string QUOTATION_IMPORT_TIME = "Time";
        public const string QUOTATION_IMPORT_SEQUENCE = "Seq.";
        public const string QUOTATION_IMPORT_CENTRAL_BANK_CORE_RATE = "CENTRAL BANK'S CORE RATE";
        public const string QUOTATION_IMPORT_CCY = "CCY";
        public const string QUOTATION_IMPORT_TTM = "TTM";
        public const string QUOTATION_IMPORT_TTB = "TTB";
        public const string QUOTATION_IMPORT_TTS = "TTS";
        public const string QUOTATION_IMPORT_CSB = "CSB";
        public const string QUOTATION_IMPORT_CSS = "CSS";
        public const string QUOTATION_IMPORT_I_S_RATE = "I/S RATE";
        public const string QUOTATION_IMPORT_BUY_CCY_SELL_VND = "Buy CCY / Sell VND";
        public const string QUOTATION_IMPORT_SELL_CCY_BUY_VND = "Sell CCY / Buy VND";
        public const string QUOTATION_IMPORT_BUY_CCY_SELL_VND_CASH = "Buy CCY / Sell VND (Cash)";
        public const string QUOTATION_IMPORT_SELL_CCY_BUY_VND_CASH = "Sell CCY / Sell VND (Cash)";
        public const string QUOTATION_IMPORT_TC = "T/C";
        public const string QUOTATION_IMPORT_CROSS_FX = "CROSS FX";
        public const string QUOTATION_IMPORT_EC = "E/C";
        public const string QUOTATION_IMPORT_CUST_RATE = "CUST. RATE";
        public const string QUOTATION_IMPORT_BANK_BUYS_FC_vs_VND = "BANK BUYS FC vs VND";
        public const string QUOTATION_IMPORT_BANK_SELLS_FC_vs_VND = "BANK SELLS FC vs VND";
        public const string QUOTATION_IMPORT_A_GREEN_SREEN = "A GROUP SCREEN";
        public const string QUOTATION_IMPORT_B_GREEN_SREEN = "B GROUP SCREEN";
        #endregion

        #region QUOTATION DETAIL

        /// <summary>
        /// Column in datagridview - Cross FX 
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string CROSS_FX = "CROSS FX";
        /// <summary>
        /// Column in datagridview - Bank buys FC vs VND
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string BANK_BUYS_FC_vs_VND = "BANK BUYS FC vs VND";
        /// <summary>
        /// Column in datagridview - Cust. rate
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string CUST_RATE = "CUST. RATE";
        /// <summary>
        /// string - _
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string _ = "_";
        /// <summary>
        /// Column in datagridview - A group screen
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string A_GROUP_SCREEN = "A GROUP SCREEN";
        /// <summary>
        /// Column in datagridview - E/C
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string EC = "E/C";
        /// <summary>
        /// Column in datagridview - B group screen
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string B_GROUP_SCREEN = "B GROUP SCREEN";
        /// <summary>
        /// Column in datagridview - Bank sells FC vs VND
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string BANK_SELLS_FC_vs_VND = "BANK SELLS FC vs VND";
        /// <summary>
        /// Column in datagridview - Status
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string STATUS = "Status";
        /// <summary>
        /// Column in datagridview - Note Head
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string NOTE_HEAD = "Note Head";
        /// <summary>
        /// Column in datagridview - Note threshold
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string NOTE_THRESHOLD = "Note Threshold";
        /// <summary>
        /// Column in datagridview - Note Mid
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string NOTE_MID = "Note Mid";
        /// <summary>
        /// Column in datagridview - Note End
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string NOTE_END = "Note End";
        /// <summary>
        /// Column in datagridview - Remark
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string REMARK = "Remark";
        /// <summary>
        /// Column in datagridview - User name
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string USER_NAME = "User Name";
        /// <summary>
        /// Column in datagridview - Inactive
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string IN_ACTIVE = "Inactive";

        #endregion

        #region COMBOBOX OBJECT
        /// <summary>
        /// Display of combobox
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string DISPLAY = "Display";
        /// <summary>
        /// Value of combobox
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string VALUE = "Value";
        #endregion

        #region PARAMETER
        /// <summary>
        /// parameters - transaction type
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string PARAMETERS_TRANSACTION_TYPE = "025";
        /// <summary>
        /// parameters - status
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public const string PARAMETERS_STATUS = "014";
        /// <summary>
        /// parameters - password
        /// </summary>
        public const string PARAMETERS_PASSWORD_DEFAULT = "018";
        /// <summary>
        /// parameters - threshold
        /// </summary>
        public const string PARAMETERS_THRESHOLD_DEFAULT = "019";
        /// <summary>
        /// parameters - User Action
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public const string PARAMETERS_USER_ACTION_LOG_HISTORY = "015";
        /// <summary>
        /// parameters - Number of changing Password
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public const string PARAMETERS_NUMBER_CHANGING_PASSWORD = "020";
        /// <summary>
        /// parameters - customer type
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string PARAMETERS_CUSTOMER_TYPE = "021";

        //BOARD RATE
        public const string PARAMETERS_BR_TRANS_TYPE = "101";
        public const string PARAMETERS_BR_STATUS = "102";
        public const string PARAMETERS_BR_ACTION = "106";

        #endregion

        #region MODULE
        public const string MODULE_MD = "MD";
        public const string MODULE_SE = "SE";
        public const string MODULE_LG = "LG";
        #endregion

        #region FORMAT DATETIME
        public const string MD_FORMAT_YEAR_MONTH = "yyyyMM";
        public const string MD_FORMAT_YEAR_MONTH_DAY = "{0:yyyy/MM/dd}";
        public const string MD_FORMAT_MONTH_YEAR = "MMyyyy";
        public const string MD_FORMAT_STANDARD = "MM/yyyy";
        public const string MD_FORMAT_YYYYMMDD = "yyyy/MM/dd";
        public const string MD_FORMAT_YYYY_MM_DD = "yyyyMMdd";
        public const string MD_FORMAT_MMM_yy = "MMM-yy";
        public const string MD_FORMAT_DDMMMYY = "dd-MMM-yy";
        public const string MD_FORMAT_DAY = "dd";
        public const string MD_FORMAT_MONTH = "MM";
        public const string MD_FORMAT_MONTH_NAME = "MMMM";
        public const string MD_FORMAT_YEAR = "yyyy";
        public const string MD_FORMAT_HHMM = "HH:mm";
        #endregion

        #region Import Board Rate Status title
        public const string BOARD_RATE_TITLE_NEW = "Board Rate Processing (New)";
        public const string BOARD_RATE_TITLE_WITHDRAW = "Board Rate Processing (Withdraw)";
        public const string BOARD_RATE_TITLE_WAITFORAPPROVE = "Board Rate Processing (Wait for approve)";
        public const string BOARD_RATE_TITLE_APPROVED = "Board Rate Processing (approved)";
        public const string BOARD_RATE_TITLE_RETURN = "Board Rate Processing (Return)";
        public const string BOARD_RATE_TITLE_SUSPEND = "Board Rate Processing (Suspend)";
        public const string BOARD_RATE_TITLE_FREEZE = "Board Rate Processing (Freeze)";
        #endregion

        #region Board Rate Grid
        public const string BOARD_RATE_TENORS = "Tenors";
        public const string BOARD_RATE_FOR_THE_AMOUNT = "FOR THE AMOUNT UP TO {0} {1} {2}";
        public const string BOARD_RATE_BIO = "BIO";
        public const string BOARD_RATE_MIO = "MIO";
        public const Decimal BOARD_RATE_BIO_VALUE = 1000000000;
        public const Decimal BOARD_RATE_MIO_VALUE = 1000000;
        public const string BOARD_RATE_CCY = "{0} I/S (%)";
        public const string BOARD_RATE_DEPOSIT = "DEPOSIT";
        public const string BOARD_RATE_LOAN = "LOAN";
        public const string BOARD_RATE_SAME_DAY = "SAME DAY";
        public const string BOARD_RATE_TOM = "TOM";
        public const string BOARD_RATE_SPOT = "SPOT";
        public const string BOARD_RATE_MATURITY_DATE = "Maturity Date";
        public const string BOARD_RATE_NA_VALUE = "N/A";
        #endregion

        #region TransType
        public const int BOARD_RATE_TRANS_TYPE_DEPOSIT = 1;
        public const int BOARD_RATE_TRANS_TYPE_LOAN = 2;
        #endregion

        #region Term ID List

        #endregion

        #region FORMAT NUMBER
        public const string FORMAT_NUMBER_ON_DATAGRID = "#,###.#####";
        public const string FORMAT_NUMBER_N5 = "N5";
        public const string FORMAT_NUMBER_N2 = "N2";
        public const string FORMAT_NUMBER_N = "N0";
        public const string FORMAT_DECIMAL = "#,0.00000";        
        #endregion

        #region Board Rate Action Name
        public const string BOARD_RATE_ACTION_Blank = "Blank";
        public const string BOARD_RATE_ACTION_Save = "Save";
        public const string BOARD_RATE_ACTION_SendForApproval = "Send for approval";
        public const string BOARD_RATE_ACTION_Preview = "Preview/Print";
        public const string BOARD_RATE_ACTION_Withdraw = "Withdraw";
        public const string BOARD_RATE_ACTION_Approve = "Approve";
        public const string BOARD_RATE_ACTION_Return = "Return";
        public const string BOARD_RATE_ACTION_Revise = "Revise";
        public const string BOARD_RATE_ACTION_Freeze = "Freeze";
        #endregion

        #region Board Rate Status Name
        public const string BOARD_RATE_STATUS_New = "New";
        public const string BOARD_RATE_STATUS_WaitForApproval = "Wait for Approve";
        public const string BOARD_RATE_STATUS_Approved = "Approved";
        public const string BOARD_RATE_STATUS_Withdrawed = "Withdrawed";
        public const string BOARD_RATE_STATUS_Returned = "Returned";
        public const string BOARD_RATE_STATUS_Suspended = "Suspended";
        public const string BOARD_RATE_STATUS_Obsolete = "Obsolete";
        public const string BOARD_RATE_STATUS_Freeze = "Freeze";
        #endregion

        #region MyRegion
        public const string BOARD_RATE_ACTIVE = "Active";
        public const string BOARD_RATE_IN_ACTIVE = "Inactive";
        #endregion
        //public const string EXCEL_TEMPLATE_NAME_BOARD_RATE = "BOARD RATE";

        public const string EXCEL_TEMPLATE_FILE_BOARD_RATE = "BOARD RATE.xls";
        public const string EXCEL_TEMPLATE_FILE_CURRENCY_INQUIRY_BOARD_RATE_HISTORY = "CURRENCY INQUIRY BOARD RATE HISTORY.xls";
        public const string EXCEL_TEMPLATE_TITLE_CURRENCY_INQUIRY_BOARD_RATE_HISTORY = "CURRENCY INQUIRY BOARD RATE HISTORY";

        #region SBV Min Max
        public const int SBV_MIN_MAX_TRANS_TYPE_DEPOSIT = 1;
        public const int SBV_MIN_MAX_TRANS_TYPE_LOAN = 2;

        public const string SBV_MIN_MAX_DEPOSIT = "DEPOSIT";
        public const string SBV_MIN_MAX_LOAN = "LOAN";
        #endregion
    }
}