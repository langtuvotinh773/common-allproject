﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-07-31 (Web, 31 July 2013) $
 * ========================================================
 * This class is used to define common value for module MD
 * For Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Com
{
    public class clsMDCommonValue
    {
        /// <summary>
        /// Action of BoardRate
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public enum BoardRateAction : int
        {
            Blank = 0,
            Save = 1,
            SendForApproval = 2,
            Preview = 3,
            Withdraw = 4,
            Approve = 5,
            Return = 6,
            Revise = 7,
            Freeze = 8
        }

        /// <summary>
        /// Action of BoardRate
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public enum BoardRateStatus : int
        {
            Blank = 0,
            New = 1,
            WaitingforApprove = 2,
            Approved = 3,
            Withdrawed = 4,
            Returned = 5,
            Suspended = 6,
            Obsolete = 7,
            Freeze = 8
        }

        /// <summary>
        /// Term Type
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public enum TermType : int
        {
            TERM_ON = 1,
            TERM_TN = 2,
            TERM_1WK = 3,
            TERM_2WK = 4,
            TERM_1MO = 5,
            TERM_2MS = 6,
            TERM_3MS = 7,
            TERM_6MS = 8,
            TERM_9MS = 9,
            TERM_1Y = 10
        }

        /// <summary>
        /// Board Rate Form is called form Import Board Rate
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public enum BoardRateForm : int
        {
            Maker = 0,
            Approver = 1
        }
    }
}
