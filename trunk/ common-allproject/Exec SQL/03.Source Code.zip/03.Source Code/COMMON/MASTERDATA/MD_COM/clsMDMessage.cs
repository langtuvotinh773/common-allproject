﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-13 (Web, 13 March 2013) $
 * ========================================================
 * This class is used to define common messages 
 * For Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Com
{
    public static class clsMDMessage
    {
        #region CONFIRM
        /// <summary>
        /// param 1: ACTION, param 2: INFORMATION_NAME
        /// Ex: Are you sure to [save] [department]?
        /// </summary>
        public static readonly string CONF_ACTION = "Are you sure to {0} {1}?";
        public static readonly string CONFIRM_ACTION_DELETE_DATA = "Are you sure to delete this {0}?";
        public static readonly string CONFIRM_ACTION_SAVE_DATA_CHANGED = "Do you want to save changed data?";
        public static readonly string YOUR_CHANGES_HAVE_NOT_SAVED_DO_YOU_WANT_TO_SAVE = "Your changes have not saved. Do you want to save?";
        public static readonly string CONFIRM_ACTION_DO_COUNTINUE = "Do you want to continue?";

        public static readonly string ARE_YOU_SURE_TO_REQUEST_FOR_APPROVAL = "Are you sure to request for approval?";
        public static readonly string REQUEST_WAS_SENT_SUCCESSFULLY = "Request was sent successfully.";
        public static readonly string REQUEST_WAS_SENT_UN_SUCCESSFULLY = "Request was sent unsuccessfully.";

        public static readonly string ARE_YOU_SURE_TO_WITHDRAW_DATA = "Are you sure to withdraw data?";
        public static readonly string DATA_BR_WAS_WITHDRAWED_SUCCESSFULLY = "Board rate was withdrawn successfully.";
        public static readonly string DATA_BR_WAS_WITHDRAWED_UN_SUCCESSFULLY = "Board rate was withdrawn unsuccessfully.";

        public static readonly string ARE_YOU_SURE_TO_APPROVE_BOARD_RATE = "Are you sure to approve board rate?";
        public static readonly string DATA_BR_WAS_APPROVED_SUCCESSFULLY = "Board rate was approved successfully.";
        public static readonly string DATA_WAS_APPROVED_UN_SUCCESSFULLY = "Board rate was approved unsuccessfully.";
        public static readonly string ARE_YOU_SURE_TO_RETURN_BOARD_RATE = "Are you sure to return board rate?";
        public static readonly string DATA_BR_WAS_RETURNED_SUCCESSFULLY = "Board rate was returned successfully.";
        public static readonly string DATA_BR_WAS_RETURNED_UN_SUCCESSFULLY = "Board rate was returned unsuccessfully.";
        public static readonly string ARE_YOU_SURE_TO_REVISE_BOARD_RATE = "Are you sure to revise board rate?";
        public static readonly string DATA_BR_WAS_REVISED_SUCCESSFULLY = "Board rate was revised successfully.";
        public static readonly string DATA_BR_WAS_REVISED_UN_SUCCESSFULLY = "Board rate was revised unsuccessfully.";
        public static readonly string ARE_YOU_SURE_TO_FREEZE_BOARD_RATE = "Are you sure to freeze board rate?";
        public static readonly string DATA_BR_WAS_FREEZED_SUCCESSFULLY = "Board rate was freezed successfully.";
        public static readonly string DATA_BR_WAS_FREEZED_UN_SUCCESSFULLY = "Board rate was freezed unsuccessfully.";

        
        public static readonly string ARE_YOU_SURE_TO_SAVE_DATA = "Are you sure to save data?";
        public static readonly string DATA_WAS_WITHDRAW_SUCCESSFULLY = "Data was withdraw successfully.";
        public static readonly string DATA_WAS_WITHDRAW_UN_SUCCESSFULLY = "Data was withdraw unsuccessfully.";
        public static readonly string DATA_WAS_SAVED_SUCCESSFULLY = "Data was saved successfully.";
        public static readonly string ACTION_INFORMATION_NAME_IS_SUCCESSFUL = "{0} {1} is successful";
        public static readonly string DATA_WAS_SAVED_UN_SUCCESSFULLY = "Data was saved unsuccessfully.";
        public static readonly string NO_TRANSACTION_FOUND = "No transaction found";

        public static readonly string DO_YOU_WANT_TO_RE_IMPORT_DATA_FOR_DAILY_QUOTATION = "Do you want to re-import data for Daily Quotation?";
        public static readonly string DO_YOU_WANT_TO_RE_IMPORT_DATA_FOR_BOARD_RATE = "Do you want to re-import data for Board Rate?";
        public static readonly string THERE_IS_EXISTED_DAILY_QUOTATION_THAT_IS_WAITING_FOR_APPROVAL = "There is existed daily quotation that is waiting for approval";
        public static readonly string ARE_YOU_SURE_TO_APPROVE_DATA = "Are you sure to approve data?";
        public static readonly string DAILY_QUOTATION_WAS_APPROVED_SUCCESSFULLY = "Daily Quotation was approved successfully.";
        public static readonly string DAILY_QUOTATION_WAS_FREEZED_SUCCESSFULLY = "Daily Quotation was freezed successfully.";
        public static readonly string ARE_YOU_SURE_TO_RETURN_DATA = "Are you sure to return data?";
        public static readonly string DATA_WAS_RETURNED_SUCCESSFULLY = "Data was returned successfully.";
        public static readonly string ARE_YOU_SURE_TO_REVISE_DATA = "Are you sure to revise data?";
        public static readonly string DATA_WAS_REVISED_SUCCESSFULLY = "Data was revised successfully.";
        public static readonly string ARE_YOU_SURE_TO_FREEZE_DATA = "Are you sure to freeze data?";
        public static readonly string CONFIRM_ACTION_IMPORT_DATA = "Are you sure to import data for {0}?";
        public static readonly string CONFIRM_ACTION_RE_IMPORT_DATA = "Are you sure to re-import data for {0}?";
        public static readonly string ARE_YOU_SURE_TO_DELETE_CEILING_FLOOR = "Are you sure to delete Ceiling/Floor?";
        public static readonly string ARE_YOU_SURE_TO_THRESHOLD = "Are you sure to delete Threshold?";
        public static readonly string ARE_YOU_SURE_TO_CUTOFF_TIME = "Are you sure to delete Cut-off Time?";
        //public static readonly string CEILING_FLOOR_WAS_DELETED_SUCCESSFULLY = "Ceiling/Floor was deleted successfully";
        //public static readonly string THRESHOLDR_WAS_DELETED_SUCCESSFULLY = "Threshold was deleted successfully";
        //public static readonly string DATA_WAS_UPDATED_SUCCESSFULLY = "Data was updated successfully";
        public static readonly string CONFIRM_OVERRIDE_CEILING_FLOOR = "This Ceiling/Floor existed in the system. Do you want to override it?";
        public static readonly string CONFIRM_OVERRIDE_THREADHOLD = "This threshold existed in the system. Do you want to override it?";
        public static readonly string CONFIRM_OVERRIDE_CUTOFFTIME = "This Cut-off time existed in the system. Do you want to override it?";
        //public static readonly string CONFIRM_SAVE_CHANGE = "Your changes have not saved. Do you want to save?";
        #endregion

        #region INFO ACTION
        public static readonly string INFO_ABOUT_SELECTED_HOLIDAY = "All CCY have holiday on {0} : {1}";
        public static readonly string INFO_SEARCH_NO_RESULT = "No data found!";
        public static readonly string INFO_NO_DATA_IMPORT = "No data to import.";        
        public static readonly string INFO_NO_DATA_EXPORT = "No data to export.";
        /// <summary>
        /// param 1: ACTION, param 2: INFORMATION_NAME
        /// Ex: [Creating] [user] is successful
        /// </summary>
        public static readonly string INFO_ACTION_SUCCESS = "{0} {1} is successful.";
        /// <summary>
        /// param 1: ACTION, param 2: INFORMATION_NAME
        /// Ex: [Creating] [user] is fail
        /// </summary>
        public static readonly string INFO_ACTION_FAIL = "{0} {1} is fail.";
        #endregion

        #region WARNING
        public static readonly string WARNING_ACTION_FILE_TYPE_INVALID = "File type is invalid.";
        public static readonly string WARNING_ACTION_FILE_IMPORT_NOT_FOUND = "File is not found.";
        public static readonly string WARNING_ACTION_YEAR_HAS_NOT_HOLIDAY = "For {0} currency, this year does not have holiday data.";
        public static readonly string WARNING_ACTION_UPDATE_HOLIDAY_IN_PAST = "You are modifying holiday data on the past.";
        public static readonly string WARNING_ACTION_CAN_NOT_IMPORT = "There is existed daily quotation that is waiting for approval.";
        public static readonly string WARNING_ACTION_IMPORT = "Can not import.";
        public static readonly string WARNING_ACTION_CHOOSE_ITEM_QUOTATION_EXPORT = "Please select a quotation to export excel.";
        public static readonly string WARNING_ACTION_CHOOSE_ITEM_QUOTATION_PREVIEW = "Please select a quotation to preview.";
        public static readonly string WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION = "Please select a {0} to {1}.";
        public static readonly string WARNING_ACTION_CHOOSE_ITEM = "Please select {0} to {1}.";
        public static readonly string WARNING_PLEASE_INPUT = "Please input{0}";
        public static readonly string WARNING_PLEASE_INPUT_VALID = "Please input a valid{0}";
        public static readonly string WARNING_ACTION_EXIST_FXATCODE = "This FXAT Code existed in the system. Please try another one!";
        public static readonly string WARNING_ACTION_FXATCODE_NOT_FOUND = "FXAT Code not found.";
        //BoardRate
        public static readonly string WARNING_ACTION_CAN_NOT_IMPORT_BR = "There is existed board rate that is waiting for approval.";
        public static readonly string WARNING_ACTION_CHOOSE_ITEM_BOARD_RATE_EXPORT = "Please select a board rate to export excel.";
        public static readonly string WARNING_NO_DATA_NO_CHANGED_IMPORT = "Please re-import board rate.";
        public static readonly string WARNING_NO_DATA_TO_MODIFY = "No data to modify.";
        #endregion

        #region ERROR
        /// <summary>
        /// param: ITEM_NAME
        /// Ex: Please input [Department Code]
        /// </summary>
        public static readonly string ERR_REQUIRED = "Please input {0}.";
        /// <summary>
        /// param: ITEM_NAME
        /// Ex: [Department Code] existed in the system
        /// </summary>
        public static readonly string ERR_ITEM_EXISTED = "{0} existed in the system.";
        public static readonly string ERROR_ACTION_CANNOT_DELETE = "Can not delete this {0} because it is being used by relating functions such as {1}.";
        //public static readonly string ERROR_VALUE_IS_INVALID = "{0} is invalid data.";      
        public static readonly string ERROR_COMBOBOX_SELECTED_NOT_FOUND = "{0} is not found.";
        public static readonly string ERROR_RETYPE_PASSWORD_IS_EMPTY = "Please enter Retype Password.";
        public static readonly string ERROR_RETYPE_PASSWORD_NOT_SAME = "Retype Password is not same. Please enter again.";
        public static readonly string ERROR_NOT_FOUND_ITEM = "Cannot found selected item.";
        public static readonly string ERROR_CHOOSE_TEAM_SAME_TEAMTYPE = "Cannot choose Team has name '{0}' with the same Team Type.";
        public static readonly string ERROR_CHOOSE_USER_SAME_TEAMTYPE = "Cannot choose User has name '{0}' with the same Team Type.";
        public static readonly string ERROR_MPORT_HOLIDAY_DATA_ERROR = "There is error data in row {0} of sheet name '{1}'. Please try again!";
        public static readonly string ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID = "In sheet {0}, {1} in line {2} is invalid data.";
        public static readonly string ERROR_IMPORT_QUOTATION_VALUE_IS_NOT_EXIST = "In sheet {0}, {1} in line {2} is not existed.";
        public static readonly string ERROR_IMPORT_QUOTATION_AGAINSTCCY_IS_INVALID = "In sheet {0}, {1} in line {2} must contain {3}";
        public static readonly string ERROR_IMPORT_QUOTATION_VALUE_IS_EMPTY = "In sheet {0}, {1} in line {2} is empty.";
        public static readonly string ERR_ITEM_INCORRECT = "{0} is incorrect.";
        public static readonly string ERR_RE_NEW_PASSWORD_NOT_MATCH = "Re-new Password and New Password are not match.";
        public static readonly string ERR_THE_LENGTH_OF_ITEM_NAME_SHOULD_BE_LESS_THAN_OR_EQUAL_MAX_LENGTH = "The length of {0} should be less than or equal {1}.";//item name, max length
        public static readonly string ERR_NOT_EXISTED_CCY = "The sheet with name '{0}' is not existed CCY in system. Please check again.";
        public static readonly string ERROR_FIELD_REQUIRED = "{0} is required.";
        public static readonly string ERROR_IS_NOT_FORMAT = "{0} is not in expected format.";
        public static readonly string ERROR_IS_INVALID_DATA = "{0} is invalid.";
        public static readonly string ERROR_NOT_CURRENT_DATE = "{0} must be current date.";
        public static readonly string ERROR_IS_DELETE = "[{0}] is deleted by another user.";
        public static readonly string ERROR_SMALLER_THAN_OR_EQUAL = "{0} have to smaller than or equal {1}.";
        public static readonly string ERROR_SMALLER_THAN = "{0} have to smaller than {1}.";
        #endregion
    }
}
