﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-15 (Fri, 13 March 2013) $
 * ========================================================
 * This class is used to define functions to access DB of DepartmentUser
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phoenix.Common.MasterData.Dto;
using System.Data.SqlClient;
using System.Data;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dal 
{
    public class clsMDDepartmentUserDAL : clsDataAccessLayer
    {
        #region CONST PARAMETER NAME USED IN STORE PROCUDURE        
        const string PARAMETER_USERNO = "@userNo";
        const string PARAMETER_DEPARTMENTID = "@departmentID";
        const string PARAMETER_CREATEDBY = "@createdBy";
        #endregion

        #region CONST STORE PROCUDURE NAME        
        const string STORE_PROCEDURE_INSERT = "spMD_CreateDepartmentUser";
        const string STORE_PROCEDURE_DELETE = "spMD_DeleteDepartmentUser";
        #endregion

        /// <summary>
        /// Insert a DepartmentUser
        /// </summary>
        /// <param name="obj">clsMDDepartmentUserDTO</param>
        /// <returns>return row number insert successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertDepartmentUser(clsMDDepartmentUserDTO obj)
        {
            try
            {
                if (obj != null)
                {
                    SqlParameter[] parameters = new SqlParameter[] { 
                        new SqlParameter(PARAMETER_USERNO, obj.UserNo),
                        new SqlParameter(PARAMETER_DEPARTMENTID, obj.DepartmentID),
                        new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy)
                    };
                    return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_INSERT, CommandType.StoredProcedure, parameters);
                }
                return 0;
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        ///// <summary>
        ///// Delete all DepartmentUser record have DepartmentId = iDeptID
        ///// </summary>
        ///// <param name="iUserNo">UserNo</param>
        ///// <param name="iDeptID">TeamID</param>
        ///// <returns>return row number insert successfully</returns>
        ///// @cond
        ///// Author: vlhcnhung
        ///// @endcond
        //public int DeleteDepartmentUser(int iUserNo, int iDeptID)
        //{
        //    try
        //    {
        //        SqlParameter[] parameters = new SqlParameter[2];
        //        parameters[0] = new SqlParameter(PARAMETER_USERNO, iUserNo);
        //        parameters[1] = new SqlParameter(PARAMETER_DEPARTMENTID, iDeptID);
        //        return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE, CommandType.StoredProcedure, parameters);
        //    }
        //    catch (Exception ex)
        //    {
        //        RollBack();
        //        ////show error message
        //        //clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
        //        ////save log exception
        //        //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
        //        throw new System.ArgumentException(ex.Message);
        //        return -1;
        //    }
        //}
    }
}
