﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-13 (Web, 13 March 2013) $
 * ========================================================
 * This class is used to define functions to access DB of department
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Functions;
using Config.Classes;

namespace Phoenix.Common.MasterData.Dal
{
    public sealed class clsMDDepartmentDAL : clsDataAccessLayer
    {
        #region CONST PARAMETER NAME USED IN STORE PROCUDURE
        const string PARAMETER_NEWDEPT = "@newDept";//is used in store procedure check duplicate. 0: is add dept, 1: update dept
        const string PARAMETER_DEPTID = "@departmentID";
        const string PARAMETER_DEPARTMENTCODE = "@departmentCode";
        const string PARAMETER_DEPARTMENTNAME = "@departmentName";
        const string PARAMETER_REMARK = "@remark";
        const string PARAMETER_CREATEDBY = "@createdBy";
        #endregion

        #region CONST STORE PROCUDURE NAME         
        const string STORE_PROCEDURE_GET_LIST = "spMD_GetDepartmentList";
        const string STORE_PROCEDURE_GET_ITEM = "spMD_GetDepartment";
        const string STORE_PROCEDURE_INSERT = "spMD_CreateDepartment";
        const string STORE_PROCEDURE_UPDATE = "spMD_UpdateDepartment";
        const string STORE_PROCEDURE_DELETE = "spMD_DeleteDepartment";
        const string STORE_PROCEDURE_CHECK_DUPLICATE = "spMD_CheckDuplicateDepartment";
        const string STORE_PROCEDURE_GET_ALL_LIST_COMBOBOX = "spMD_GetAllDepartmentListForComboBox";
        #endregion

        /// <summary>
        /// Get list of all departments based on input parameter
        /// If all parammeters are blank or null, will get all departments
        /// </summary>
        /// <param name="obj">clsMDDepartmentDTO contains values to filter</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetDepartmentList(clsMDDepartmentDTO obj)
        {
            //set paramameters
            SqlParameter[] parameters = new SqlParameter[2];
            if (string.IsNullOrEmpty(obj.DepartmentCode))
                parameters[0] = new SqlParameter(PARAMETER_DEPARTMENTCODE, DBNull.Value);
            else
                parameters[0] = new SqlParameter(PARAMETER_DEPARTMENTCODE, obj.DepartmentCode);
            if (string.IsNullOrEmpty(obj.DepartmentName))
                parameters[1] = new SqlParameter(PARAMETER_DEPARTMENTNAME, DBNull.Value);
            else
                parameters[1] = new SqlParameter(PARAMETER_DEPARTMENTNAME, obj.DepartmentName);
            //Excute query to get data
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST, CommandType.StoredProcedure, parameters);

            return dt;
        }

        /// <summary>
        /// Get list of all departments for ComboBox
        /// Return DataTable(DepartmentID, DepartmentCode, DepartmentName)
        /// </summary>
        /// <returns>DataTable(DepartmentID, DepartmentCode, DepartmentName)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAllDepartmentList()
        {
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ALL_LIST_COMBOBOX, CommandType.StoredProcedure);
            return dt;
        }

        /// <summary>
        /// Insert a department
        /// </summary>
        /// <param name="obj">clsMDDepartmentDTO</param>
        /// <returns>return row number insert successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertDepartment(clsMDDepartmentDTO obj)
        {
            try
            {
                if (obj != null)
                {
                    int row = 0;
                    object outParamName = PARAMETER_DEPTID;
                    SqlParameter[] parameters = new SqlParameter[5];
                    parameters[0] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
                    parameters[0].Value = obj.DepartmentID;
                    parameters[0].Direction = ParameterDirection.InputOutput;
                    parameters[1] = new SqlParameter(PARAMETER_DEPARTMENTCODE, obj.DepartmentCode);
                    parameters[2] = new SqlParameter(PARAMETER_DEPARTMENTNAME, obj.DepartmentName);
                    parameters[3] = new SqlParameter(PARAMETER_REMARK, obj.Remark);
                    parameters[4] = new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy);
                    this.ExecuteNonQueryWithReturn(STORE_PROCEDURE_INSERT, CommandType.StoredProcedure, parameters, ref outParamName);
                    if (outParamName != null)
                    {
                        row = int.Parse(outParamName.ToString());
                        if (row > 0)
                        {
                            obj.DepartmentID = int.Parse(outParamName.ToString());
                        }
                        return row;
                    }
                }
                return 0;
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Update a department information
        /// </summary>
        /// <param name="obj">clsMDDepartmentDTO</param>
        /// <returns>return row number update successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int UpdateDepartment(clsMDDepartmentDTO obj)
        {
            try
            {
                if (obj != null)
                {
                    SqlParameter[] parameters = new SqlParameter[] { 
                        new SqlParameter(PARAMETER_DEPTID, obj.DepartmentID),
                        new SqlParameter(PARAMETER_DEPARTMENTCODE, obj.DepartmentCode),
                        new SqlParameter(PARAMETER_DEPARTMENTNAME, obj.DepartmentName),
                        new SqlParameter(PARAMETER_REMARK, obj.Remark),
                        new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy)
                    };
                    return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE, CommandType.StoredProcedure, parameters);
                }
                return 0;
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Delete department: update field DelFlag = 1
        /// 0: Un-Delete
        /// 1: Deleted
        /// </summary>
        /// <param name="iDeptID"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// 
        /// @endcond
        public int DeleteDepartment(int iDeptID)
        {
            try
            {
                SqlParameter[] parameter = new SqlParameter[]{
                    new SqlParameter(PARAMETER_DEPTID, iDeptID)
                };
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE, CommandType.StoredProcedure, parameter);
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Get department by DepartmentID
        /// </summary>
        /// <param name="iDeptID"></param>
        /// <returns>if found return clsMDDepartmentDTO else return null</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public clsMDDepartmentDTO GetDepartment(int iDeptID)
        {
            SqlParameter parameter = new SqlParameter(PARAMETER_DEPTID, iDeptID);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ITEM, CommandType.StoredProcedure, parameter);
            if (dt != null && dt.Rows.Count > 0)
            {
                clsMDDepartmentDTO dto = new clsMDDepartmentDTO();
                dto.DepartmentID = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_DEPARTMENTID].ToString());
                dto.DepartmentCode = dt.Rows[0][clsMDConstant.MD_COL_DEPARTMENTCODE].ToString();
                dto.DepartmentName = dt.Rows[0][clsMDConstant.MD_COL_DEPARTMENTNAME].ToString();
                dto.CreatedBy = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_CREATED_BY].ToString());
                dto.UpdateDate = Convert.ToDateTime(dt.Rows[0][clsMDConstant.MD_COL_UPDATE_DATE]);
                dto.Remark = dt.Rows[0][clsMDConstant.MD_COL_REMARK].ToString();
                return dto;
            }
            return null;
        }

        /// <summary> 
        /// Check DepartmentCode, DepartmentName not duplicate
        /// </summary>
        /// <param name="iNewDept">
        /// 0: create => will check duplicate DepartmentCode and DepartmentName
        /// 1: modify => only check dulicate DepartmentName but not same DepartmentCode
        /// </param>
        /// <param name="iDeptID">ID of Department modified
        /// if create ID = -1
        /// if modify ID = ID of Department modified
        /// </param>
        /// <param name="strDeptCode"></param>
        /// <param name="strDeptName"></param>
        /// <returns>
        /// Dictionary<string, int> result
        /// Ex: <DepartmentCode, 0> : not exist in database
        ///     <DepartmentName, 1> : exist a record has same name in database
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public Dictionary<string, int> ValidationDuplicateDepartment(int iNewDept, int iDeptID, string strDeptCode, string strDeptName)
        {
            Dictionary<string, int> result = null;
            SqlParameter[] parameters = new SqlParameter[]{
                    new SqlParameter(PARAMETER_NEWDEPT, iNewDept),
                    new SqlParameter(PARAMETER_DEPTID, iDeptID),
                    new SqlParameter(PARAMETER_DEPARTMENTCODE, strDeptCode),
                    new SqlParameter(PARAMETER_DEPARTMENTNAME, strDeptName)
                };
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_CHECK_DUPLICATE, CommandType.StoredProcedure, parameters);
            if (dt != null)
            {
                result = new Dictionary<string, int>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    result.Add(dt.Rows[i][clsMDConstant.MD_COLNAME].ToString(), (int)dt.Rows[i][clsMDConstant.MD_COLNAME_COUNTRECORD]);
                }
            }
            return result;
        }
    }
}
