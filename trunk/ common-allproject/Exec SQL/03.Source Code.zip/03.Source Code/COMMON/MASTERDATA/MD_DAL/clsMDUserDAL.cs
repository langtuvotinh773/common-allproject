﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-15 (Fri, 15 March 2013) $
 * ========================================================
 * This class is used to define functions to access DB of user
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using Phoenix.Common.Functions;
using Config.Classes;

namespace Phoenix.Common.MasterData.Dal
{
    public class clsMDUserDAL : clsDataAccessLayer
    {
        #region CONST PARAMETER NAME USED IN STORE PROCUDURE
        const string PARAMETER_NEWUSER = "@newUser";//is used in store procedure check duplicate. @newUser = 0: is add, 1: update
        const string PARAMETER_USERNO = "@userNo";
        const string PARAMETER_LIST_USERNO = "@listOfUserNo";
        const string PARAMETER_USERNAME = "@userName";
        const string PARAMETER_SHORTNAME = "@shortName";
        const string PARAMETER_FULLNAME = "@fullName";
        const string PARAMETER_DEPTID = "@departmentID";
        const string PARAMETER_LIST_DEPTID = "@listOfDepartmentID";
        const string PARAMETER_TEAMID = "@teamID";
        const string PARAMETER_LIST_TEAMID = "@listOfTeamID";
        const string PARAMETER_FULL_SHORT_NAME = "@fullShortName";
        const string PARAMETER_OFFICER = "@isOfficer";
        const string PARAMETER_STAFF01 = "@isStaff01";
        const string PARAMETER_STAFF02 = "@isStaff02";
        const string PARAMETER_LOCKOUT = "@isLockout";
        const string PARAMETER_PASSWORD = "@password";
        const string PARAMETER_REMARK = "@remark";
        const string PARAMETER_CREATEDBY = "@createdBy";
        const string PARAMETER_MODULE = "@module";
        const string PARAMETER_TYPE = "@type";
        #endregion

        #region CONST STORE PROCUDURE NAME
        //Store procedure for Team List, Create/Modify Team
        const string STORE_PROCEDURE_GET_LIST = "spMD_GetUserList";
        const string STORE_PROCEDURE_GET_LIST_FOR_COMBOBOX = "spMD_GetAllUserList";
        const string STORE_PROCEDURE_GET_OBJECT = "spMD_GetUser";
        const string STORE_PROCEDURE_INSERT = "spMD_CreateUser";
        const string STORE_PROCEDURE_UPDATE = "spMD_UpdateUser";
        const string STORE_PROCEDURE_DELETE = "spMD_DeleteUser";
        const string STORE_PROCEDURE_CHECK_DUPLICATE = "spMD_CheckDuplicateUser";
        const string STORE_PROCEDURE_DELETE_DEPT_USER = "spMD_DeleteDepartmentUser";
        const string STORE_PROCEDURE_CHANGE_PASSWORD = "spMD_ChangePasswordUser";
        //Store procedure for Assign Users To Department        
        const string STORE_PROCEDURE_GET_UNASSIGN_USER_BY_DEPTID = "spMD_GetUnassignUsersToDepartment";
        const string STORE_PROCEDURE_GET_ASSIGN_USER_BY_DEPTID = "spMD_GetAssignUsersToDepartment";
        const string STORE_PROCEDURE_GET_UNASSIGN_DEPT_BY_USERNO = "spMD_GetUnAssignDepartmentsToUser";
        const string STORE_PROCEDURE_GET_ASSIGN_DEPT_BY_USERNO = "spMD_GetAssignDepartmentsToUser";
        const string STORE_PROCEDURE_UPDATE_ASSIGN_DEPT_TO_USER = "spMD_UpdateDepartmentsToUser";
        const string STORE_PROCEDURE_UPDATE_ASSIGN_USER_TO_DEPT = "spMD_UpdateUsersToDepartment";
        //Store procedure for Assign Users To Team
        const string STORE_PROCEDURE_DELETE_TEAM_USER = "spMD_DeleteTeamUser";
        const string STORE_PROCEDURE_GET_UNASSIGN_USER_BY_TEAMID = "spMD_GetUnassignUsersToTeam";
        const string STORE_PROCEDURE_GET_ASSIGN_USER_BY_TEAMID = "spMD_GetAssignUsersToTeam";
        const string STORE_PROCEDURE_GET_UNASSIGN_TEAM_BY_USERID = "spMD_GetUnAssignTeamsToUser";
        const string STORE_PROCEDURE_GET_ASSIGN_TEAM_BY_USERID = "spMD_GetAssignTeamsToUser";
        const string STORE_PROCEDURE_UPDATE_ASSIGN_TEAM_TO_USER = "spMD_UpdateTeamsToUser";
        const string STORE_PROCEDURE_UPDATE_ASSIGN_USER_TO_TEAM = "spMD_UpdateUsersToTeam";
        //pass hitỏy
        const string STORE_PROCEDURE_INSERT_PASSWORD_HISTORY = "spMD_CreatePasswordHistory";
        const string STORE_PROCEDURE_GET_PASSWORD_HISTORY = "spMD_GetPasswordHistory";
        const string STORE_PROCEDURE_GET_LATEST_CHANGING_PASSWORD = "spMD_GetLastestDateChangingPassword";
        #endregion

        #region Methods for Team List, Create/Mofidy Team        

        /// <summary>
        /// Get list of user based on input parameters       
        /// </summary>
        /// <param name="obj">clsMDUserDTO contains parameters to filter</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUserList(clsMDUserDTO obj)
        {
            SqlParameter[] parameters = new SqlParameter[8];
            if (obj.DepartmentID < 0)
                parameters[0] = new SqlParameter(PARAMETER_DEPTID, DBNull.Value);
            else
                parameters[0] = new SqlParameter(PARAMETER_DEPTID, obj.DepartmentID);
            if (obj.TeamID < 0)
                parameters[1] = new SqlParameter(PARAMETER_TEAMID, DBNull.Value);
            else
                parameters[1] = new SqlParameter(PARAMETER_TEAMID, obj.TeamID);
            if (string.IsNullOrEmpty(obj.UserName))
                parameters[2] = new SqlParameter(PARAMETER_USERNAME, DBNull.Value);
            else
                parameters[2] = new SqlParameter(PARAMETER_USERNAME, obj.UserName);
            if (string.IsNullOrEmpty(obj.FullShortName))
                parameters[3] = new SqlParameter(PARAMETER_FULL_SHORT_NAME, DBNull.Value);
            else
                parameters[3] = new SqlParameter(PARAMETER_FULL_SHORT_NAME, obj.FullShortName);
            if (string.IsNullOrEmpty(obj.Officer))
                parameters[4] = new SqlParameter(PARAMETER_OFFICER, DBNull.Value);
            else
                parameters[4] = new SqlParameter(PARAMETER_OFFICER, obj.Officer);
            if (string.IsNullOrEmpty(obj.Staff01))
                parameters[5] = new SqlParameter(PARAMETER_STAFF01, DBNull.Value);
            else
                parameters[5] = new SqlParameter(PARAMETER_STAFF01, obj.Staff01);
            if (string.IsNullOrEmpty(obj.Staff02))
                parameters[6] = new SqlParameter(PARAMETER_STAFF02, DBNull.Value);
            else
                parameters[6] = new SqlParameter(PARAMETER_STAFF02, obj.Staff02);
            if (string.IsNullOrEmpty(obj.Lockout))
                parameters[7] = new SqlParameter(PARAMETER_LOCKOUT, DBNull.Value);
            else
                parameters[7] = new SqlParameter(PARAMETER_LOCKOUT, obj.Lockout);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST, CommandType.StoredProcedure, parameters);            
            return dt;
        }

        /// <summary>
        /// Get list of all user for combobox
        /// Return DataTable(UserNo, FullName)
        /// </summary>
        /// <returns>DataTable(UserNo, FullName)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAllUserList()
        {
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST_FOR_COMBOBOX, CommandType.StoredProcedure);            
            return dt;
        }

        /// <summary>
        /// Get information of user by UserNo
        /// if not found return null else return clsMDUserDTO
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public clsMDUserDTO GetUser(int iUserNo)
        {
            SqlParameter parameter = new SqlParameter(PARAMETER_USERNO, iUserNo);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_OBJECT, CommandType.StoredProcedure, parameter);
            if (dt != null && dt.Rows.Count > 0)
            {
                clsMDUserDTO dto = new clsMDUserDTO();
                dto.UserNo = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_USER_NO].ToString());
                dto.UserName = dt.Rows[0][clsMDConstant.MD_COL_USERNAME].ToString();
                dto.ShortName = dt.Rows[0][clsMDConstant.MD_COL_SHORTNAME].ToString();
                dto.FullName = dt.Rows[0][clsMDConstant.MD_COL_FULLNAME].ToString();
                dto.Officer = dt.Rows[0][clsMDConstant.MD_COL_OFFICER].ToString();
                dto.Staff01 = dt.Rows[0][clsMDConstant.MD_COL_STAFF01].ToString();
                dto.Staff02 = dt.Rows[0][clsMDConstant.MD_COL_STAFF02].ToString();
                dto.Lockout = dt.Rows[0][clsMDConstant.MD_COL_LOCKOUT].ToString();
                dto.CreatedBy = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_CREATED_BY].ToString());
                dto.UpdateDate = Convert.ToDateTime(dt.Rows[0][clsMDConstant.MD_COL_UPDATE_DATE]);
                dto.Remark = dt.Rows[0][clsMDConstant.MD_COL_REMARK].ToString();
                dto.Password = dt.Rows[0][clsMDConstant.MD_COL_PASSWORD].ToString();
                dto.Department = dt.Rows[0][clsMDConstant.MD_COL_DEPARTMENTNAME].ToString();
                return dto;
            }
            return null;
        }

        /// <summary>
        /// Delete user: update column DelFlag = 1 in tables: MD_tblUser
        /// 0: Un-Delete
        /// 1: Deleted
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int DeleteUser(int iUserNo)
        {
            try
            {
                SqlParameter[] parameter = new SqlParameter[]{
                    new SqlParameter(PARAMETER_USERNO, iUserNo)
                };
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE, CommandType.StoredProcedure, parameter);
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Insert a new user record
        /// </summary>
        /// <param name="obj">clsMDUserDTO</param>
        /// <returns>return row number insert successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertUser(clsMDUserDTO obj, string listSelectedAssignDept)
        {
            try
            {
                if (obj != null)
                {
                    int row = 0;
                    object outParamName = PARAMETER_USERNO;
                    SqlParameter[] parameters = new SqlParameter[11];
                    parameters[0] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
                    parameters[0].Value = obj.UserNo;
                    parameters[0].Direction = ParameterDirection.InputOutput;
                    parameters[1] = new SqlParameter(PARAMETER_USERNAME, obj.UserName);
                    parameters[2] = new SqlParameter(PARAMETER_SHORTNAME, obj.ShortName);
                    parameters[3] = new SqlParameter(PARAMETER_FULLNAME, obj.FullName);
                    parameters[4] = new SqlParameter(PARAMETER_OFFICER, obj.Officer);
                    parameters[5] = new SqlParameter(PARAMETER_STAFF01, obj.Staff01);
                    parameters[6] = new SqlParameter(PARAMETER_STAFF02, obj.Staff02);
                    parameters[7] = new SqlParameter(PARAMETER_LOCKOUT, obj.Lockout);
                    parameters[8] = new SqlParameter(PARAMETER_PASSWORD, obj.Password);
                    parameters[9] = new SqlParameter(PARAMETER_REMARK, obj.Remark);
                    parameters[10] = new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy);
                    this.ExecuteNonQueryWithReturn(STORE_PROCEDURE_INSERT, CommandType.StoredProcedure, parameters, ref outParamName);
                    if (outParamName != null)
                    {
                        row = int.Parse(outParamName.ToString());
                        if (row > 0)
                        {
                            obj.UserNo = int.Parse(outParamName.ToString());
                        }
                    }
                    ////insert password history
                    //this.ClearParameter();
                    //if (row > 0)
                    //{
                    //    int rowPassHis = InsertPasswordHistory(obj.UserNo, obj.Password);
                    //    if (rowPassHis == 0)
                    //    {
                    //        this.RollBack();
                    //    }
                    //}
                    //insert assign department
                    this.ClearParameter();
                    if (row > 0)//insert success
                    {
                        //delete old assign department                  
                        parameters = new SqlParameter[2];
                        parameters[0] = new SqlParameter(PARAMETER_USERNO, obj.UserNo);
                        parameters[1] = new SqlParameter(PARAMETER_DEPTID, -1);
                        this.ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE_DEPT_USER, CommandType.StoredProcedure, parameters);
                        //Insert new 
                        int rowAssign = 0;
                        if (!string.IsNullOrEmpty(listSelectedAssignDept.Trim()))
                        {
                            parameters = new SqlParameter[3];
                            parameters[0] = new SqlParameter(PARAMETER_USERNO, obj.UserNo);
                            parameters[1] = new SqlParameter(PARAMETER_LIST_DEPTID, listSelectedAssignDept.Trim());
                            parameters[2] = new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy);
                            rowAssign = this.ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE_ASSIGN_DEPT_TO_USER, CommandType.StoredProcedure, parameters);
                            this.ClearParameter();
                            if (rowAssign == 0)
                            {
                                //if can not insert
                                //rollback and stop process
                                RollBack();
                            }
                        }
                    }
                    return row;
                }
                return 0;
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Update a user
        /// </summary>
        /// <param name="obj">clsMDUserDTO</param>
        /// <returns>return row number update successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int UpdateUser(clsMDUserDTO obj, string listSelectedAssignDept)
        {
            try
            {
                if (obj != null)
                {
                    int row = 0;
                    SqlParameter[] parameters = new SqlParameter[] { 
                        new SqlParameter(PARAMETER_USERNO, obj.UserNo),
                        new SqlParameter(PARAMETER_USERNAME, obj.UserName),
                        new SqlParameter(PARAMETER_SHORTNAME, obj.ShortName),
                        new SqlParameter(PARAMETER_FULLNAME, obj.FullName),
                        new SqlParameter(PARAMETER_OFFICER, obj.Officer),
                        new SqlParameter(PARAMETER_STAFF01, obj.Staff01),
                        new SqlParameter(PARAMETER_STAFF02, obj.Staff02),
                        new SqlParameter(PARAMETER_LOCKOUT, obj.Lockout),
                        new SqlParameter(PARAMETER_PASSWORD, obj.Password),
                        new SqlParameter(PARAMETER_REMARK, obj.Remark),
                        new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy)
                    };
                    row = this.ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE, CommandType.StoredProcedure, parameters);
                    this.ClearParameter();
                    if (row > 0)//insert success
                    {
                        //delete old assign department                  
                        parameters = new SqlParameter[2];
                        parameters[0] = new SqlParameter(PARAMETER_USERNO, obj.UserNo);
                        parameters[1] = new SqlParameter(PARAMETER_DEPTID, -1);
                        this.ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE_DEPT_USER, CommandType.StoredProcedure, parameters);
                        //Insert new 
                        int rowAssign = 0;
                        if (!string.IsNullOrEmpty(listSelectedAssignDept.Trim()))
                        {
                            parameters = new SqlParameter[3];
                            parameters[0] = new SqlParameter(PARAMETER_USERNO, obj.UserNo);
                            parameters[1] = new SqlParameter(PARAMETER_LIST_DEPTID, listSelectedAssignDept.Trim());
                            parameters[2] = new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy);
                            rowAssign = this.ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE_ASSIGN_DEPT_TO_USER, CommandType.StoredProcedure, parameters);
                            this.ClearParameter();
                            if (rowAssign == 0)
                            {
                                //if can not insert
                                //rollback and stop process
                                RollBack();
                            }
                        }
                    }
                    return row;
                }
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
            return 0;
        }

        /// <summary> 
        /// Check duplicate UserName
        /// </summary>
        /// <param name="iNewUser">
        /// 0: create => will check duplicate UserName
        /// 1: modify => only check dulicate UserName but not same UserNo
        /// </param>
        /// <param name="iUserNo"></param>
        /// <param name="strUserName"></param>
        /// <returns>
        /// Dictionary<string, int> result
        /// Ex: <UserName, 0> : not exist in database
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public Dictionary<string, int> ValidationDuplicateUser(int iNewUser, int iUserNo, string strUserName)
        {
            Dictionary<string, int> result = null;
            SqlParameter[] parameters = new SqlParameter[]{
                new SqlParameter(PARAMETER_NEWUSER, iNewUser),
                new SqlParameter(PARAMETER_USERNO, iUserNo),
                new SqlParameter(PARAMETER_USERNAME, strUserName)
            };
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_CHECK_DUPLICATE, CommandType.StoredProcedure, parameters);
            if (dt != null)
            {
                result = new Dictionary<string, int>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    result.Add(dt.Rows[i][clsMDConstant.MD_COLNAME].ToString(), (int)dt.Rows[i][clsMDConstant.MD_COLNAME_COUNTRECORD]);
                }
            }
            return result;
        }

        /// <summary>
        /// User change password login
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <param name="strNewPassword"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int ChangePassword(int iUserNo, string strNewPassword)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[] { 
                    new SqlParameter(PARAMETER_USERNO, iUserNo),
                    new SqlParameter(PARAMETER_PASSWORD, strNewPassword)                    
                };
                int row = this.ExecuteNonQueryWithTransaction(STORE_PROCEDURE_CHANGE_PASSWORD, CommandType.StoredProcedure, parameters);
                //if (row > 0)
                //{
                //    row = InsertPasswordHistory(iUserNo, strNewPassword);
                //    if (row == 0)
                //    {
                //        this.RollBack();
                //    }
                //}
                return row;
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Insert Password history
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <param name="strPass"></param>
        /// <returns></returns>
        /// /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertPasswordHistory(int iUserNo, string strPass)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter(PARAMETER_USERNO, iUserNo);
                parameters[1] = new SqlParameter(PARAMETER_PASSWORD, strPass);
                return this.ExecuteNonQueryWithTransaction(STORE_PROCEDURE_INSERT_PASSWORD_HISTORY, CommandType.StoredProcedure, parameters);
            }
            catch (Exception ex)
            {
                RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Get Password history
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <param name="strPass"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetPasswordHistory(int iUserNo)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter(PARAMETER_USERNO, iUserNo);
                parameters[1] = new SqlParameter(PARAMETER_MODULE, clsMDConstant.MODULE_MD);
                parameters[2] = new SqlParameter(PARAMETER_TYPE, clsMDConstant.PARAMETERS_NUMBER_CHANGING_PASSWORD);
                return this.ExecuteDataReader(STORE_PROCEDURE_GET_PASSWORD_HISTORY, CommandType.StoredProcedure, parameters);
            }
            catch (Exception ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Get Lastest date changing password
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <param name="strPass"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DateTime GetLastestDateChangingPassword(int iUserNo)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter(PARAMETER_USERNO, iUserNo);
                DataTable dt = this.ExecuteDataReader(STORE_PROCEDURE_GET_LATEST_CHANGING_PASSWORD, CommandType.StoredProcedure, parameters);
                if (dt != null && dt.Rows.Count > 0)
                {
                    return DateTime.Parse(dt.Rows[0][0].ToString());
                }
                else
                {
                    return DateTime.Now;
                }
            }
            catch (Exception ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Count Date Changing Password
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int CountDateChangingPassword(int iUserNo)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter(PARAMETER_USERNO, iUserNo);
                DataTable dt = this.ExecuteDataReader(STORE_PROCEDURE_GET_LATEST_CHANGING_PASSWORD, CommandType.StoredProcedure, parameters);
                if (dt != null && dt.Rows.Count > 0)
                {
                    DateTime latestDate = DateTime.Parse(dt.Rows[0][0].ToString());
                    DateTime currentDate = DateTime.Parse(dt.Rows[0][1].ToString());
                    return (currentDate - latestDate).Days;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        #endregion

        #region Methods for Assign Users To Department

        /// <summary>
        /// Get a list of unasigned user for a department, radio Department selected in Assign Users To Department screen
        /// Return DataTable(UserNo, UserName, FullName)
        /// </summary>
        /// <param name="iDeptID">DepartmentID</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUnassignUserListByDeptID(int iDeptID)
        {
            SqlParameter parameter = new SqlParameter(PARAMETER_DEPTID, iDeptID);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_UNASSIGN_USER_BY_DEPTID, CommandType.StoredProcedure, parameter);
            return dt;
        }

        /// <summary>
        /// Get a list of asigned user for a department, radio Department selected in Assign Users To Department screen
        /// Return DataTable(UserNo, UserName, FullName)
        /// </summary>
        /// <param name="iDeptID">DepartmentID</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAssignUserListByDeptID(int iDeptID)
        {
            SqlParameter parameter = new SqlParameter(PARAMETER_DEPTID, iDeptID);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ASSIGN_USER_BY_DEPTID, CommandType.StoredProcedure, parameter);
            return dt;
        }

        /// <summary>
        /// Get a list of  Unasigned department for a user, radio user selected in Assign Users To Department screen
        /// Return DataTable(DepartmentId, DepartmentCode, DepartmentName)
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUnassignDeptList(int iUserNo)
        {
            SqlParameter parameter = new SqlParameter(PARAMETER_USERNO, iUserNo);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_UNASSIGN_DEPT_BY_USERNO, CommandType.StoredProcedure, parameter);
            return dt;
        }

        /// <summary>
        /// Get a list of  asigned department for a user, radio user selected in Assign Users To Department screen
        /// Return DataTable(DepartmentId, DepartmentCode, DepartmentName)
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAssignDeptList(int iUserNo)
        {
            SqlParameter value = new SqlParameter(PARAMETER_USERNO, iUserNo);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ASSIGN_DEPT_BY_USERNO, CommandType.StoredProcedure, value);
            return dt;
        }

        /// <summary>
        /// Update List Assign Department To User
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <param name="strDeptIDs">list departmentID Ex: 1,2,3</param>       
        /// <param name="iCreatedBy"></param>
        /// <returns></returns>
        public int UpdataAssignDepartmentsToUser(int iUserNo, string strDeptIDs, int iCreatedBy)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[] { 
                    new SqlParameter(PARAMETER_USERNO, iUserNo),
                    new SqlParameter(PARAMETER_LIST_DEPTID, strDeptIDs),
                    new SqlParameter(PARAMETER_CREATEDBY, iCreatedBy)
                };
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE_ASSIGN_DEPT_TO_USER, CommandType.StoredProcedure, parameters);
            }
            catch (Exception ex)
            {
                RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Update List Assign User To Department
        /// </summary>
        /// <param name="strUserNo">list UserNo Ex: 1,2,3</param>
        /// <param name="iDeptID"></param>        
        /// <param name="iCreatedBy"></param>
        /// <returns></returns>
        public int UpdataAssignUsersToDepartment(string strUserNo, int iDeptID, int iCreatedBy)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[] { 
                    new SqlParameter(PARAMETER_LIST_USERNO, strUserNo),
                    new SqlParameter(PARAMETER_DEPTID, iDeptID),
                    new SqlParameter(PARAMETER_CREATEDBY, iCreatedBy)
                };
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE_ASSIGN_USER_TO_DEPT, CommandType.StoredProcedure, parameters);
            }
            catch (Exception ex)
            {
                RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Delete all DepartmentUser record have DepartmentId = iDeptID
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <param name="iDeptID">TeamID</param>
        /// <returns>return row number insert successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int DeleteDepartmentUser(int iUserNo, int iDeptID)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter(PARAMETER_USERNO, iUserNo);
                parameters[1] = new SqlParameter(PARAMETER_DEPTID, iDeptID);
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE_DEPT_USER, CommandType.StoredProcedure, parameters);
            }
            catch (Exception ex)
            {
                RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        #endregion

        #region Methods for Assign Users To Team

        /// <summary>
        /// Get a list of unasigned user for a team, radio Team selected in Assign Users To Team screen
        /// Return DataTable(UserNo, UserName, FullName)
        /// </summary>
        /// <param name="iTeamID">TeamID</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUnassignUserListByTeamID(int iTeamID)
        {
            SqlParameter value = new SqlParameter(PARAMETER_TEAMID, iTeamID);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_UNASSIGN_USER_BY_TEAMID, CommandType.StoredProcedure, value);
            return dt;
        }

        /// <summary>
        /// Get a list of asigned user for a team, radio Team selected in Assign Users To Team screen
        /// Return DataTable(UserNo, UserName, FullName)
        /// </summary>
        /// <param name="iTeamID">TeamID</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAssignUserListByTeamID(int iTeamID)
        {
            SqlParameter value = new SqlParameter(PARAMETER_TEAMID, iTeamID);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ASSIGN_USER_BY_TEAMID, CommandType.StoredProcedure, value);
            return dt;
        }

        /// <summary>
        /// Get a list of  unasigned user for a Team , radio user selected in Assign Users To Team screen
        /// Return DataTable(TeamId, TeamCode, TeamName, DepartmentName, TeamTypeName)
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUnassignTeamList(int iUserNo)
        {
            SqlParameter value = new SqlParameter(PARAMETER_USERNO, iUserNo);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_UNASSIGN_TEAM_BY_USERID, CommandType.StoredProcedure, value);
            return dt;
        }

        /// <summary>
        /// Get a list of asigned user for a Team , radio user selected in Assign Users To Team screen
        /// Return DataTable(TeamId, TeamName, DepartmentName, TeamTypeName)
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAssignTeamList(int iUserNo)
        {
            SqlParameter value = new SqlParameter(PARAMETER_USERNO, iUserNo);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ASSIGN_TEAM_BY_USERID, CommandType.StoredProcedure, value);
            return dt;
        }

        /// <summary>
        /// Update List Assign Team To User
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <param name="strTeamIDs">list TeamID Ex: 1,2,3</param>        
        /// <param name="iCreatedBy"></param>
        /// <returns></returns>
        public int UpdataAssignTeamsToUser(int iUserNo, string strTeamIDs, int iCreatedBy)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[] { 
                    new SqlParameter(PARAMETER_USERNO, iUserNo),
                    new SqlParameter(PARAMETER_LIST_TEAMID, strTeamIDs),
                    new SqlParameter(PARAMETER_CREATEDBY, iCreatedBy)
                };
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE_ASSIGN_TEAM_TO_USER, CommandType.StoredProcedure, parameters);
            }
            catch (Exception ex)
            {
                RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Update List Assign User To Team
        /// </summary>
        /// <param name="strUserNo">list UserNo Ex: 1,2,3</param>
        /// <param name="iTeamID"></param>       
        /// <param name="iCreatedBy"></param>
        /// <returns></returns>
        public int UpdataAssignUsersToTeam(string strUserNo, int iTeamID, int iCreatedBy)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[] { 
                    new SqlParameter(PARAMETER_LIST_USERNO, strUserNo),
                    new SqlParameter(PARAMETER_TEAMID, iTeamID),
                    new SqlParameter(PARAMETER_CREATEDBY, iCreatedBy)
                };
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE_ASSIGN_USER_TO_TEAM, CommandType.StoredProcedure, parameters);
            }
            catch (Exception ex)
            {
                RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Delete all TeamUser record have TeamID = iTeamID
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <param name="iTeamID">TeamID</param>
        /// <returns>return row number insert successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int DeleteTeamUser(int iUserNo, int iTeamID)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter(PARAMETER_USERNO, iUserNo);
                parameters[1] = new SqlParameter(PARAMETER_TEAMID, iTeamID);
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE_TEAM_USER, CommandType.StoredProcedure, parameters);
            }
            catch (Exception ex)
            {
                RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }
        #endregion
    }
}
