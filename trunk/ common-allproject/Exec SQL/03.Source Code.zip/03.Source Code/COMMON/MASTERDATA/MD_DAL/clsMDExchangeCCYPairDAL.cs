﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define access data for exchange currency pair
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Dto;
using System.Data.SqlClient;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dal
{
    public class clsMDExchangeCCYPairDAL : clsDataAccessLayer
    {
        public clsMDExchangeCCYPairDAL() { }

        #region CONST STORE PROCUDURE NAME       
        const string STORE_PROCEDURE_GET_LIST_COMBOBOX = "spMD_GetAllExchangeCCYPairList";
        const string STORE_PROCEDURE_INSERT = "spMD_CreateExchangeCCYPair";
        #endregion

        #region CONST PARAMETER NAME
        const string PARAMETER_EXCHANGECCYPAIRID = "@exchangeCCYPairID";
        const string PARAMETER_EXCHANGECCYPAIR = "@exchangeCCYPair";
        const string PARAMETER_BASECCY = "@baseCCY";
        const string PARAMETER_QUOTECCY = "@quoteCCY";
        const string PARAMETER_CREATEDBY = "@createdBy";
        #endregion

        /// <summary>
        /// Get list of all currency for combobox
        /// Return DataTable(ExchangeCCYPairID, ExchangeCCYPair)
        /// </summary>
        /// <returns>DataTable(ExchangeCCYPairID, ExchangeCCYPair)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public System.Data.DataTable GetAllExchangeCCYPairList()
        {
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST_COMBOBOX, CommandType.StoredProcedure);
            return dt;
        }

        /// <summary>
        /// Insert new ExchangeCCYPair, return ExchangeCCYPairID
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertExchangeCCYPair(clsMDExchangeCCYPairDTO obj)
        {
            try
            {
                if (obj != null)
                {
                    object outParamName = PARAMETER_EXCHANGECCYPAIRID;
                    SqlParameter[] parameters = new SqlParameter[5];
                    parameters[0] = new SqlParameter(PARAMETER_EXCHANGECCYPAIRID, SqlDbType.Int);
                    parameters[0] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
                    parameters[0].Value = obj.ExchangeCCYPairID;
                    parameters[0].Direction = ParameterDirection.InputOutput;
                    parameters[1] = new SqlParameter(PARAMETER_EXCHANGECCYPAIR, obj.ExchangeCCYPair);
                    parameters[2] = new SqlParameter(PARAMETER_BASECCY, obj.BaseCCY);
                    parameters[3] = new SqlParameter(PARAMETER_QUOTECCY, obj.QuoteCCY);
                    parameters[4] = new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy);
                    this.ExecuteNonQueryWithReturn(STORE_PROCEDURE_INSERT, CommandType.StoredProcedure, parameters, ref outParamName);
                    int id = int.Parse(outParamName.ToString());
                    if (id > 0)
                    {
                        this.Commit();
                        return id;
                    }
                }
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
            return 0;
        }
    }
}
