﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-27 (Wed, 27 March 2013) $
 * $UodatedDate: 2013-04-03 (Wed, 03 April 2013) $
 * ========================================================
 * This class is used to define functions to access DB of CurrencyHoliday
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Dal
{
    public class clsMDCurrencyHolidayDAL : clsDataAccessLayer
    {
        #region CONST PARAMETER NAME USED IN STORE PROCUDURE
        const string PARAMETER_NEWCUR = "@newCurrencyHoliday";//is used in store procedure check duplicate. @newCurrencyHoliday = 0: is add, 1: update
        const string PARAMETER_CCYCODE = "@CCYCode";
        const string PARAMETER_HOLIDAYDATE = "@holidayDate";
        const string PARAMETER_YEAR = "@holidayYear";
        const string PARAMETER_CREATEDBY = "@createdBy";
        #endregion

        #region CONST STORE PROCUDURE NAME    
        const string STORE_PROCEDURE_GET_YEAR_LIST = "spMD_GetYearList";
        const string STORE_PROCEDURE_GET_LIST = "spMD_GetCurrencyHolidayList";
        const string STORE_PROCEDURE_GET_LIST_EXPORT = "spMD_GetCurrencyHolidayExportList";
        const string STORE_PROCUDURE_GET_DATE_INFO = "spMD_GetDateInfo";
        const string STORE_PROCEDURE_INSERT = "spMD_CreateCurrencyHoliday";
        const string STORE_PROCEDURE_UPDATE = "spMD_UpdateCurrencyHoliday";
        const string STORE_PROCEDURE_DELETE = "spMD_DeleteCurrencyHoliday"; 
        #endregion              

        /// <summary>
        /// Get list of registed holiday years
        /// Return DataTable(HolidayYear)
        /// </summary>      
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetYearList()
        {
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_YEAR_LIST, CommandType.StoredProcedure);
            return dt;
        }

        /// <summary>
        /// Get list of all currency based on input params
        /// Return DataTable(HolidayMonth, HolidayDate)
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="iMonth"></param>
        /// <param name="iYear"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetCurrencyHolidayList(int iYear, string strCCY)
        {
            SqlParameter[] parameters = new SqlParameter[2];
            if (string.IsNullOrEmpty(strCCY))
                parameters[0] = new SqlParameter(PARAMETER_CCYCODE, DBNull.Value);
            else
                parameters[0] = new SqlParameter(PARAMETER_CCYCODE, strCCY);
            parameters[1] = new SqlParameter(PARAMETER_YEAR, iYear);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST, CommandType.StoredProcedure, parameters);
            return dt;
        }

        /// <summary>
        /// Get list of all currency based on input params to export excel
        /// Return DataTable(CCY, YEAR, DD-MMM-YYYY)
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="iMonth"></param>
        /// <param name="iYear"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetCurrencyHolidayExportList(int iYear, string strCCY)
        {
            SqlParameter[] parameters = new SqlParameter[2];
            if (string.IsNullOrEmpty(strCCY))
                parameters[0] = new SqlParameter(PARAMETER_CCYCODE, DBNull.Value);
            else
                parameters[0] = new SqlParameter(PARAMETER_CCYCODE, strCCY);
            parameters[1] = new SqlParameter(PARAMETER_YEAR, iYear);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST_EXPORT, CommandType.StoredProcedure, parameters);
            return dt;
        }

        /// <summary>
        /// Get list of CCY registed holiday in this date 
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="iMonth"></param>
        /// <param name="iYear"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetSelectedHolidayInfo(DateTime date)
        {
            SqlParameter parameter = new SqlParameter(PARAMETER_HOLIDAYDATE, date);
            return ExecuteDataReader(STORE_PROCUDURE_GET_DATE_INFO, CommandType.StoredProcedure, parameter);
        }        

        /// <summary>
        /// Delete CurrencyHoliday
        /// Return number of row deleted
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="dHoliday"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int DeleteCurrencyHoliday(string strCCY, List<DateTime> listDate)
        {
            try
            {               
                SqlParameter[] parameters;
                int iRow = 0;
                //                
                foreach (DateTime date in listDate)
                {
                    parameters = new SqlParameter[] { 
                        new SqlParameter(PARAMETER_CCYCODE, strCCY),                   
                        new SqlParameter(PARAMETER_HOLIDAYDATE, date)  
                    };                    

                    iRow += ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE, CommandType.StoredProcedure, parameters);
                    ClearParameter();
                    if (iRow == 0)
                    {
                        //if can not insert
                        //rollback and stop process
                        RollBack();
                        return iRow;
                    }
                }
                return iRow;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Insert CurrencyHoliday
        /// Return number of row Inserted
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="dHoliday"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertCurrencyHoliday(string strCCY, int iUserNo, List<DateTime> listDate)
        {
            try
            {               
                SqlParameter[] parameters;
                int iRow = 0;               
                foreach (DateTime date in listDate)
                {
                    parameters = new SqlParameter[] { 
                        new SqlParameter(PARAMETER_CCYCODE, strCCY),                    
                        new SqlParameter(PARAMETER_HOLIDAYDATE, date),                    
                        new SqlParameter(PARAMETER_CREATEDBY, iUserNo)
                    };
                    iRow += ExecuteNonQueryWithTransaction(STORE_PROCEDURE_INSERT, CommandType.StoredProcedure, parameters);
                    ClearParameter();
                    if (iRow == 0)
                    {
                        //if can not insert
                        //rollback and stop process
                        RollBack();
                        return iRow;
                    }
                }                
                return iRow;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Update CurrencyHoliday
        /// Return number of row updated
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="dHoliday"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int UpdateCurrencyHoliday(string strCCY, int iUserNo, List<DateTime> listDate)
        {
            try
            {
                SqlParameter[] parameters;
                int iRow = 0;                
                foreach (DateTime date in listDate)
                {
                    parameters = new SqlParameter[] { 
                        new SqlParameter(PARAMETER_CCYCODE, strCCY),                    
                        new SqlParameter(PARAMETER_HOLIDAYDATE, date),                    
                        new SqlParameter(PARAMETER_CREATEDBY, iUserNo)
                    };                  

                    iRow += ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE, CommandType.StoredProcedure, parameters);
                    ClearParameter();
                    if (iRow == 0)
                    {
                        //if can not insert
                        //rollback and stop process
                        RollBack();
                        return iRow;
                    }
                }                
                return iRow;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }
    }
}
