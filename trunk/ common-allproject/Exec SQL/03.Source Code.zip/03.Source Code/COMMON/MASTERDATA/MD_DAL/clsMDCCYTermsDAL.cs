﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * ========================================================
 * This class is used to define functions to access DB of CCYTerms
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dal
{
    public class clsMDCCYTermsDAL : clsDataAccessLayer
    {
        public clsMDCCYTermsDAL() { }

        #region CONST STORE PROCUDURE NAME       
        const string STORE_PROCEDURE_GET_ALL_CCY_TERMS = "spMD_GetAllCCYTermsList";
        #endregion

        /// <summary>
        /// Get list of all CCYTerms for combobox
        /// </summary>
        /// <returns>DataTable(CCYCode)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAllCCYTermsList()
        {
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ALL_CCY_TERMS, CommandType.StoredProcedure);
            return dt;
        }
    }
}
