﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-19 (Tue, 19 March 2013) $
 * ========================================================
 * This class is used to define functions to access DB of TeamType
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dal 
{
    public class clsMDTeamTypeDAL : clsDataAccessLayer
    {
        const string STORE_PROCEDURE_GET_LIST = "spMD_GetAllTeamTypeListForComboBox";

        /// <summary>
        /// Get list of all TeamType for ComboBox
        /// Return DataTable(TeamTypeID, TeamTypeCode, TeamTypeName)
        /// </summary>
        /// <returns>DataTable(TeamTypeID, TeamTypeCode, TeamTypeName)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAllTeamTypeList()
        {
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST, CommandType.StoredProcedure);
            return dt;
        }
    }
}
