﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phoenix.Common.MasterData.Dto;
using System.Data;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Com;
using System.Data.SqlClient;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDBoardRaterDAL : clsDataAccessLayer
    {
        const string STORE_PROCEDURE_GET_FILE_DERECTORY = "spMD_GetLastestFileDirectoryOfBoardRate";

        /// <summary>
        /// Get last path
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public string GetLastestFileDirectoryOfBoardRate()
        {
            clsMDBoardRateDTO quotationObj = new clsMDBoardRateDTO();
            DataTable dtoInfo = ExecuteDataReader(STORE_PROCEDURE_GET_FILE_DERECTORY, CommandType.StoredProcedure);
            if (dtoInfo.Rows.Count > 0)
            {
                return dtoInfo.Rows[0][clsMDConstant.MD_COL_FILEDIRECTORY].ToString().Trim();
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
