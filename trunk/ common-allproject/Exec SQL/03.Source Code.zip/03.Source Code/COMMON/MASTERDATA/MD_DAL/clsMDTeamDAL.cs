﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-15 (Fri, 13 March 2013) $
 * ========================================================
 * This class is used to define functions to access DB of team
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phoenix.Common.MasterData.Dto;
using System.Data.SqlClient;
using System.Data;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Functions;
using Config.Classes;

namespace Phoenix.Common.MasterData.Dal 
{
    public class clsMDTeamDAL : clsDataAccessLayer
    {
        #region CONST PARAMETER NAME USED IN STORE PROCUDURE
        const string PARAMETER_NEWTEAM = "@newTeam";//is used in store procedure check duplicate. 0: is add TEAM, 1: update TEAM
        const string PARAMETER_TEAMID = "@teamID";
        const string PARAMETER_TEAMCODE = "@teamCode";
        const string PARAMETER_TEAMNAME = "@teamName";
        const string PARAMETER_DEPARTMENTID = "@departmentID";
        const string PARAMETER_TEAMTYPEID = "@teamTypeID";
        const string PARAMETER_REMARK = "@remark";
        const string PARAMETER_CREATEDBY = "@createdBy";
        #endregion

        #region CONST STORE PROCUDURE NAME
        const string STORE_PROCEDURE_GET_ALL_LIST_COMBOBOX = "spMD_GetAllTeamListForComboBox";
        const string STORE_PROCEDURE_GET_LIST = "spMD_GetTeamList";
        const string STORE_PROCEDURE_GET_ITEM = "spMD_GetTeam";
        const string STORE_PROCEDURE_INSERT = "spMD_CreateTeam";
        const string STORE_PROCEDURE_UPDATE = "spMD_UpdateTeam";
        const string STORE_PROCEDURE_DELETE = "spMD_DeleteTeam";
        const string STORE_PROCEDURE_CHECK_DUPLICATE = "spMD_CheckDuplicateTeam";
        #endregion

        /// <summary>
        /// Get list of all teams for ComboBox
        /// Return DataTable(TeamId, TeamCode, TeamName)
        /// </summary>
        /// <returns>DataTable(TeamId, TeamCode, TeamName)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// CreatedDate: 2013/03/15
        /// @endcond
        public DataTable GetAllTeamList()
        {
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ALL_LIST_COMBOBOX, CommandType.StoredProcedure);
            return dt;
        }

        /// <summary>
        /// Get list of all team based on input params
        /// Return DataTble(TeamID, TeamCode, TeamName, DepartmentID(DepartmentName), TeamTypeID(TeamTypeName), Remark, CreatedBy, UpdateDate)
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond       
        public DataTable GetTeamList(clsMDTeamDTO obj)
        {
            SqlParameter[] parameters = new SqlParameter[4];
            if (obj.DepartmentID < 0)
                parameters[0] = new SqlParameter(PARAMETER_DEPARTMENTID, DBNull.Value);
            else
                parameters[0] = new SqlParameter(PARAMETER_DEPARTMENTID, obj.DepartmentID);
            if (obj.TeamTypeID < 0)
                parameters[1] = new SqlParameter(PARAMETER_TEAMTYPEID, DBNull.Value);
            else
                parameters[1] = new SqlParameter(PARAMETER_TEAMTYPEID, obj.TeamTypeID);
            if (string.IsNullOrEmpty(obj.TeamCode))
                parameters[2] = new SqlParameter(PARAMETER_TEAMCODE, DBNull.Value);
            else
                parameters[2] = new SqlParameter(PARAMETER_TEAMCODE, obj.TeamCode);
            if (string.IsNullOrEmpty(obj.TeamName))
                parameters[3] = new SqlParameter(PARAMETER_TEAMNAME, DBNull.Value);
            else
                parameters[3] = new SqlParameter(PARAMETER_TEAMNAME, obj.TeamName);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST, CommandType.StoredProcedure, parameters);

            return dt;
        }
        

        /// <summary>
        /// Get information of team by TeamID
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <returns>if not found return null else return clsMDTeamDTO</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public clsMDTeamDTO GetTeam(int iTeamID)
        {
            SqlParameter parameter = new SqlParameter(PARAMETER_TEAMID, iTeamID);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ITEM, CommandType.StoredProcedure, parameter);
            if (dt != null && dt.Rows.Count > 0)
            {
                clsMDTeamDTO dto = new clsMDTeamDTO();
                dto.TeamID = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_TEAMID].ToString());
                dto.TeamCode = dt.Rows[0][clsMDConstant.MD_COL_TEAMCODE].ToString();
                dto.TeamName = dt.Rows[0][clsMDConstant.MD_COL_TEAMNAME].ToString();
                dto.DepartmentID = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_DEPARTMENTID].ToString());
                dto.DepartmentCode = dt.Rows[0][clsMDConstant.MD_COL_DEPARTMENTCODE].ToString().Trim();
                dto.DepartmentName = dt.Rows[0][clsMDConstant.MD_COL_DEPARTMENTNAME].ToString().Trim();
                dto.TeamTypeID = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_TEAMTYPEID].ToString());
                dto.TeamTypeCode = dt.Rows[0][clsMDConstant.MD_COL_TEAMTYPECODE].ToString().Trim();
                dto.TeamTypeName = dt.Rows[0][clsMDConstant.MD_COL_TEAMTYPENAME].ToString().Trim();
                dto.CreatedBy = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_CREATED_BY].ToString());
                dto.UpdateDate = Convert.ToDateTime(dt.Rows[0][clsMDConstant.MD_COL_UPDATE_DATE]);
                dto.Remark = dt.Rows[0][clsMDConstant.MD_COL_REMARK].ToString();
                return dto;
            }
            return null;
        }

        /// <summary>
        /// Delete user: update field DelFlag = 1 in table MD_tblTeam
        /// 0: Un-Delete
        /// 1: Deleted
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int DeleteTeam(int iTeamID)
        {
            try
            {
                SqlParameter[] parameter = new SqlParameter[]{
                    new SqlParameter(PARAMETER_TEAMID, iTeamID)
                };
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE, CommandType.StoredProcedure, parameter);
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Insert a Team
        /// </summary>
        /// <param name="obj">clsMDTeamDTO</param>
        /// <returns>return row number insert successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertTeam(clsMDTeamDTO obj)
        {
            try
            {
                if (obj != null)
                {
                    int row = 0;
                    object outParamName = PARAMETER_TEAMID;
                    SqlParameter[] parameters = new SqlParameter[7];
                    parameters[0] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
                    parameters[0].Value = obj.TeamID;
                    parameters[0].Direction = ParameterDirection.InputOutput;
                    parameters[1] = new SqlParameter(PARAMETER_TEAMCODE, obj.TeamCode);
                    parameters[2] = new SqlParameter(PARAMETER_TEAMNAME, obj.TeamName);
                    parameters[3] = new SqlParameter(PARAMETER_DEPARTMENTID, obj.DepartmentID);
                    parameters[4] = new SqlParameter(PARAMETER_TEAMTYPEID, obj.TeamTypeID);
                    parameters[5] = new SqlParameter(PARAMETER_REMARK, obj.Remark);
                    parameters[6] = new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy);
                    this.ExecuteNonQueryWithReturn(STORE_PROCEDURE_INSERT, CommandType.StoredProcedure, parameters, ref outParamName);
                    if (outParamName != null)
                    {
                        row = int.Parse(outParamName.ToString());
                        if (row > 0)
                        {
                            obj.TeamID = int.Parse(outParamName.ToString());
                        }
                        return row;
                    }
                }
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
            return 0;
        }

        /// <summary>
        /// Update a Team information
        /// </summary>
        /// <param name="obj">clsMDTeamDTO</param>
        /// <returns>return row number update successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int UpdateTeam(clsMDTeamDTO obj)
        {
            try
            {
                if (obj != null)
                {
                    SqlParameter[] parameters = new SqlParameter[] { 
                        new SqlParameter(PARAMETER_TEAMID, obj.TeamID),
                        new SqlParameter(PARAMETER_TEAMCODE, obj.TeamCode),
                        new SqlParameter(PARAMETER_TEAMNAME, obj.TeamName),
                        new SqlParameter(PARAMETER_DEPARTMENTID, obj.DepartmentID),
                        new SqlParameter(PARAMETER_TEAMTYPEID, obj.TeamTypeID),
                        new SqlParameter(PARAMETER_REMARK, obj.Remark),
                        new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy)
                    };
                    return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE, CommandType.StoredProcedure, parameters);
                }
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
            return 0;
        }

        /// <summary> 
        /// Check TeamCode, TeamName not duplicate
        /// </summary>
        /// <param name="iNewTeam">
        /// 0: create => will check duplicate TeamCode and TeamName
        /// 1: modify => only check dulicate TeamName but not same TeamCode
        /// </param>
        /// <param name="iTeamID">ID of Team modified
        /// if create ID = -1
        /// if modify ID = ID of Team modified
        /// </param>
        /// <param name="strTeamCode"></param>
        /// <param name="strTeamName"></param>
        /// <returns>
        /// Dictionary<string, int> result
        /// Ex: <TeamCode, 0> : not exist in database
        ///     <TeamName, 1> : exist a record has same name in database
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public Dictionary<string, int> ValidationDuplicateTeam(int iNewTeam, int iTeamID, string strTeamCode, string strTeamName)
        {
            Dictionary<string, int> result = null;
            SqlParameter[] parameters = new SqlParameter[]{
                    new SqlParameter(PARAMETER_NEWTEAM, iNewTeam),
                    new SqlParameter(PARAMETER_TEAMID, iTeamID),
                    new SqlParameter(PARAMETER_TEAMCODE, strTeamCode),
                    new SqlParameter(PARAMETER_TEAMNAME, strTeamName)
                };
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_CHECK_DUPLICATE, CommandType.StoredProcedure, parameters);
            if (dt != null)
            {
                result = new Dictionary<string, int>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    result.Add(dt.Rows[i][clsMDConstant.MD_COLNAME].ToString(), (int)dt.Rows[i][clsMDConstant.MD_COLNAME_COUNTRECORD]);
                }
            }
            return result;
        }

    }
}
