﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-16(Thur, 16 Mary 2013) $
 * ========================================================
 * This class is used to define functions to access DB of customer
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Functions;
using Config.Classes;

namespace Phoenix.Common.MasterData.Dal
{
    //public class clsMDCustomerDAL
    //{
    public sealed class clsMDCustomerDAL : clsDataAccessLayer
    {
        #region CONST PARAMETER NAME USED IN STORE PROCUDURE
        const string PARAMETER_CUSTOMERCODE = "@customerCode";
        const string PARAMETER_CUSTOMERNAME = "@customerName";
        const string PARAMETER_CUSTOMERTYPE = "@customerType";
        const string PARAMETER_SPECIAL = "@special";
        const string PARAMETER_INDIRECT_INVESTOR = "@indirectInvestor";
        const string PARAMETER_FXATCODE = "@fxatCode";
        const string PARAMETER_LOCATION = "@locationCode";
        const string PARAMETER_LOCATION_NAME = "@locationName";
        const string PARAMETER_NAME = "@name";
        const string PARAMETER_TYPE = "@parameterType";
        #endregion

        #region CONST STORE PROCUDURE NAME
        const string STORE_PROCEDURE_GET_LIST = "spMD_GetCustomerList";
        const string STORE_PROCEDURE_GET_LIST_BYNAME = "spMD_GetListCustomerByName";
        const string STORE_PROCEDURE_GET_FXATCODE_LIST_BYNAME = "spMD_GetListFXATCodeByName";
        const string STORE_PROCEDURE_GET_LIST_BYCODE = "spMD_GetListCustomerByCode";
        const string STORE_PROCEDURE_GET_ITEM = "spMD_Getcustomer";
        const string STORE_PROCEDURE_GET_NAME_CUSTOMER_LIST = "spMD_GetAllNameCustomerList";
        const string STORE_PROCEDURE_GET_CODE_CUSTOMER_LIST = "spMD_GetAllCodeCustomerList";
        const string STORE_PROCEDURE_GET_FXAT_CODE_LIST = "spMD_GetFXATCodeList";
        const string STORE_PROCEDURE_GET_LOCATION_CODE_LIST = "spMD_GetLocationCodeList";
        const string STORE_PROCEDURE_UPDATE = "spMD_Updatecustomer";
        const string STORE_PROCEDURE_CHECK_EXIST_FXAT_CODE = "spMD_CheckExistFXATCode";
        const string STORE_PROCEDURE_CHECK_EXIST_LOCATION_CODE = "spMD_CheckExistLocationCode";
        const string STORE_PROCEDURE_INSERT_LOCATION = "spMD_InsertLocation";
        #endregion

        /// <summary>
        /// Get list of all customers based on input parameter
        /// If all parammeters are blank or null, will get all customers
        /// </summary>
        /// <param name="obj">clsMDCustomerDTO contains values to filter</param>
        /// <param name="obj">param type</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetCustomerList(clsMDCustomerDTO obj, string strparamType)
        {
            //set paramameters
            SqlParameter[] values = new SqlParameter[] 
                {               
                new SqlParameter(PARAMETER_TYPE, strparamType),  
                new SqlParameter(PARAMETER_CUSTOMERCODE, obj.CustomerCode),                
                new SqlParameter(PARAMETER_CUSTOMERNAME, obj.FullName),
                new SqlParameter(PARAMETER_CUSTOMERTYPE, obj.CustomerType),
                new SqlParameter(PARAMETER_SPECIAL, obj.Special),
                new SqlParameter(PARAMETER_INDIRECT_INVESTOR, obj.IndirectInvestor),
                new SqlParameter(PARAMETER_FXATCODE, obj.FXATCode),
                new SqlParameter(PARAMETER_LOCATION, obj.Location),
                };

            //Excute query to get data
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST, CommandType.StoredProcedure, values);

            return dt;
        }

        /// <summary>
        /// Get list of  customers based on input parameter
        /// If all parammeters are blank or null, will get all customers
        /// </summary>
        /// <param name="obj">clsMDCustomerDTO contains values to filter</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public clsMDCustomerDTO GetCustomer(string strCusCode)
        {
            SqlParameter parameter = new SqlParameter(PARAMETER_CUSTOMERCODE, strCusCode);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ITEM, CommandType.StoredProcedure, parameter);
            if (dt != null && dt.Rows.Count > 0)
            {
                clsMDCustomerDTO dto = new clsMDCustomerDTO();
                dto.CustomerCode = dt.Rows[0][clsMDConstant.MD_COL_CODE].ToString();
                dto.FullName = dt.Rows[0][clsMDConstant.MD_COL_CUS_FULLNAME].ToString();
                dto.ShortName = dt.Rows[0][clsMDConstant.MD_COL_CUS_SHORTNAME].ToString();
                dto.CustomerType = dt.Rows[0][clsMDConstant.MD_COL_CUSTOMERTYPE].ToString();
                dto.FXATCode = dt.Rows[0][clsMDConstant.MD_COL_FXATCODE].ToString();
                dto.Location = dt.Rows[0][clsMDConstant.MD_COL_LOCATION].ToString();
                if (dt.Rows[0][clsMDConstant.MD_COL_SPECIAL].ToString() == "")
                {
                    dto.Special = false;
                }
                else
                {
                    dto.Special = bool.Parse(dt.Rows[0][clsMDConstant.MD_COL_SPECIAL].ToString());
                }
                if (dt.Rows[0][clsMDConstant.MD_COL_INDIRECT_INVESTOR].ToString() == "")
                {
                    dto.IndirectInvestor = false;
                }
                else
                {
                    dto.IndirectInvestor = bool.Parse(dt.Rows[0][clsMDConstant.MD_COL_INDIRECT_INVESTOR].ToString());
                }
                return dto;
            }
            return null;
        }

        /// <summary>
        /// Update a customer information
        /// </summary>
        /// <param name="obj">clsMDCustomerDTO</param>
        /// <returns>return row number update successfully</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public int UpdateCustomer(clsMDCustomerDTO obj, string strparamType)
        {
            try
            {
                if (obj != null)
                {
                    SqlParameter[] parameters = new SqlParameter[] { 
                        new SqlParameter(PARAMETER_TYPE, strparamType),
                        new SqlParameter(PARAMETER_CUSTOMERCODE, obj.CustomerCode),
                        new SqlParameter(PARAMETER_SPECIAL, obj.Special),
                        new SqlParameter(PARAMETER_INDIRECT_INVESTOR, obj.IndirectInvestor),
                        new SqlParameter(PARAMETER_FXATCODE, obj.FXATCode),
                        new SqlParameter(PARAMETER_LOCATION, obj.Location)
                    };
                    return ExecuteNonQuery(STORE_PROCEDURE_UPDATE, CommandType.StoredProcedure, parameters);
                }
                return 0;
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Get all name of customer
        /// </summary>
        /// <returns>List all name of customer</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<CbbObject> GetNameCustomerList()
        {
            List<CbbObject> nameOfCustList = new List<CbbObject>();
            DataTable dtbnameOfCustList = ExecuteDataReader(STORE_PROCEDURE_GET_NAME_CUSTOMER_LIST, CommandType.StoredProcedure);
            nameOfCustList.Insert(0, new CbbObject("", ""));
            for (int i = 0; i < dtbnameOfCustList.Rows.Count; i++)
                nameOfCustList.Insert(i + 1, new CbbObject(dtbnameOfCustList.Rows[i][clsMDConstant.MD_COL_CUS_FULLNAME].ToString(), dtbnameOfCustList.Rows[i][clsMDConstant.MD_COL_CUS_FULLNAME].ToString()));
            return nameOfCustList;
        }

        /// <summary>
        /// Get all code of customer
        /// </summary>
        /// <returns>List all code of customer</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<CbbObject> GetCodeCustomerList()
        {
            List<CbbObject> codeOfCustList = new List<CbbObject>();
            DataTable dtbcodeOfCustList = ExecuteDataReader(STORE_PROCEDURE_GET_CODE_CUSTOMER_LIST, CommandType.StoredProcedure);
            codeOfCustList.Insert(0, new CbbObject("", ""));
            for (int i = 0; i < dtbcodeOfCustList.Rows.Count; i++)
                codeOfCustList.Insert(i + 1, new CbbObject(dtbcodeOfCustList.Rows[i][clsMDConstant.MD_COL_CODE].ToString(), dtbcodeOfCustList.Rows[i][clsMDConstant.MD_COL_CODE].ToString()));
            return codeOfCustList;
        }

        /// <summary>
        /// Get all FXAT Code of customer
        /// </summary>
        /// <returns>List all FXAT Code of customer</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<CbbObject> GetFXATCodeList()
        {
            List<CbbObject> FXATCodeOfCustList = new List<CbbObject>();
            DataTable dtbcodeOfCustList = ExecuteDataReader(STORE_PROCEDURE_GET_FXAT_CODE_LIST, CommandType.StoredProcedure);
            FXATCodeOfCustList.Insert(0, new CbbObject("", ""));
            for (int i = 0; i < dtbcodeOfCustList.Rows.Count; i++)
                FXATCodeOfCustList.Insert(i + 1, new CbbObject(dtbcodeOfCustList.Rows[i][clsMDConstant.MD_COL_FXATCODE].ToString(), dtbcodeOfCustList.Rows[i][clsMDConstant.MD_COL_FXATCODE].ToString()));
            return FXATCodeOfCustList;
        }

        /// <summary>
        /// Get all FXAT Code of customer
        /// </summary>
        /// <param name="">strFXATCode</param>
        /// <returns>List all FXAT Code of customer base on parameters input</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable CheckExistFXATCode(string strFXATCode)
        {
            //set paramameters
            SqlParameter[] values = new SqlParameter[] 
                {               
                new SqlParameter(PARAMETER_FXATCODE, strFXATCode),  
                };
            DataTable dtbcodeOfCustList = ExecuteDataReader(STORE_PROCEDURE_CHECK_EXIST_FXAT_CODE, CommandType.StoredProcedure, values);
            return dtbcodeOfCustList;
        }

        /// <summary>
        /// Get all Location Code of customer
        /// </summary>
        /// <param name="">strLocationCode</param>
        /// <returns>List all Location Code of customer base on parameters input</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable CheckExistLocationCode(string strLocationCode)
        {
            //set paramameters
            SqlParameter[] values = new SqlParameter[] 
                {               
                new SqlParameter(PARAMETER_LOCATION, strLocationCode),  
                };
            DataTable dtbcodeOfCustList = ExecuteDataReader(STORE_PROCEDURE_CHECK_EXIST_LOCATION_CODE, CommandType.StoredProcedure, values);
            return dtbcodeOfCustList;
        }

        /// <summary>
        /// Get all Location Code of customer
        /// </summary>
        /// <returns>List all FXAT Code of customer</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<CbbObject> GetLocationCodeList()
        {
            List<CbbObject> locationCodeList = new List<CbbObject>();
            DataTable dtblocationCodeList = ExecuteDataReader(STORE_PROCEDURE_GET_LOCATION_CODE_LIST, CommandType.StoredProcedure);
            locationCodeList.Insert(0, new CbbObject("", ""));
            for (int i = 0; i < dtblocationCodeList.Rows.Count; i++)
                locationCodeList.Insert(i + 1, new CbbObject(dtblocationCodeList.Rows[i][clsMDConstant.MD_COL_LOCATION].ToString(), dtblocationCodeList.Rows[i][clsMDConstant.MD_COL_LOCATION].ToString()));
            return locationCodeList;
        }

        /// <summary>
        /// Get list of all customers based on name
        /// </summary>
        /// <param name="obj">string name</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetCustomerListByName(string strname)
        {
            //set paramameters
            SqlParameter[] values = new SqlParameter[] 
                {               
                new SqlParameter(PARAMETER_CUSTOMERNAME, strname),  
                };

            //Excute query to get data
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST_BYNAME, CommandType.StoredProcedure, values);

            dt.Columns[0].ColumnName = clsMDConstant.MD_COL_CUSTOMERCODE;
            dt.Columns[1].ColumnName = clsMDConstant.MD_COL_CUS_FULLNAME;
            return dt;
        }

        /// <summary>
        /// Get list of all customers based on code
        /// </summary>
        /// <param name="obj">string code</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetCustomerListByCode(string strcode)
        {
            //set paramameters
            SqlParameter[] values = new SqlParameter[] 
                {               
                new SqlParameter(PARAMETER_CUSTOMERCODE, strcode),  
                };

            //Excute query to get data
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST_BYCODE, CommandType.StoredProcedure, values);

            dt.Columns[0].ColumnName = clsMDConstant.MD_COL_CUSTOMERCODE;
            dt.Columns[1].ColumnName = clsMDConstant.MD_COL_CUS_FULLNAME;
            return dt;
        }

        /// <summary>
        /// Save location
        /// </summary>
        /// <param name="obj">clsMDCustomerDTO</param>
        /// <returns>return row number update successfully</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void SaveLocation(string strLocationCode, string strLocationName)
        {
            SqlParameter[] parameters = new SqlParameter[] { 
                            new SqlParameter(PARAMETER_LOCATION, strLocationCode),
                            new SqlParameter(PARAMETER_LOCATION_NAME, strLocationName)
                        };
            ExecuteNonQuery(STORE_PROCEDURE_INSERT_LOCATION, CommandType.StoredProcedure, parameters);
        }

        /// <summary>
        /// Get all Location Code of customer
        /// </summary>
        /// <returns>List all FXAT Code of customer</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<String> GetFXATCodeListByName(string strname)
        {
            List<String> lstFXATList = new List<String>();
            //set paramameters
            SqlParameter[] values = new SqlParameter[] 
                {               
                    new SqlParameter(PARAMETER_NAME, strname),  
                };
            DataTable dtbFXATCodeList = ExecuteDataReader(STORE_PROCEDURE_GET_FXATCODE_LIST_BYNAME, CommandType.StoredProcedure, values);
            for (int i = 0; i < dtbFXATCodeList.Rows.Count; i++)
                lstFXATList.Add(dtbFXATCodeList.Rows[i][clsMDConstant.MD_COL_FXATCODE].ToString());
            return lstFXATList;
        }
    }
}
