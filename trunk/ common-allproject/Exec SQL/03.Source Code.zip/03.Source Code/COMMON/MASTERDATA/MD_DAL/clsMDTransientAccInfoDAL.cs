﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-27 (Mon, 27 May 2013) $
 * ========================================================
 * This class is used to define functions to access DB of TransientAccInfo
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Functions;
using Config.Classes;

namespace Phoenix.Common.MasterData.Dal
{
    public sealed class clsMDTransientAccInfoDAL : clsDataAccessLayer
    {
        #region CONST PARAMETER NAME USED IN STORE PROCUDURE
        const string PARAMETER_CCY = "@ccy";
        const string PARAMETER_ACCOUNTNO = "@accountNo";
        const string PARAMETER_GL_CODE = "@glCode";
        const string PARAMETER_GL_SUBCODE = "@glSubCode";
        const string PARAMETER_DEPTID = "@departmentId";
        const string PARAMETER_ACCOUNT_TYPE = "@accountType";
        const string PARAMETER_OPENDATE = "@openDate";
        const string PARAMETER_CLOSEDATE = "@closeDate";
        #endregion

        #region CONST STORE PROCUDURE NAME         
        const string STORE_PROCEDURE_GET_LIST = "spMD_GetTransientAccInfoList";
        const string STORE_PROCEDURE_GET_ITEM = "spMD_GetTransientAccInfo";
        const string STORE_PROCEDURE_INSERT = "spMD_CreateTransientAccInfo";
        const string STORE_PROCEDURE_UPDATE = "spMD_UpdateTransientAccInfo";
        const string STORE_PROCEDURE_DELETE = "spMD_DeleteTransientAccInfo";
        const string STORE_PROCEDURE_CHECK_EXIST = "spMD_CheckExistTransientAccInfo";
        const string STORE_PROCEDURE_GET_CCY_LIST = "spMD_GetCcyList";
        #endregion

        /// <summary>
        /// Get list of all TransientAccInfos based on input parameter
        /// If all parammeters are blank or null, will get all TransientAccInfos
        /// </summary>
        /// <param name="obj">clsMDTransientAccInfoDTO contains values to filter</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetTransientAccInfoList(clsMDTransientAccInfoDTO obj)
        {
            //set paramameters
            SqlParameter[] parameters = new SqlParameter[7];
            if (string.IsNullOrEmpty(obj.CCY))
                parameters[0] = new SqlParameter(PARAMETER_CCY, DBNull.Value);
            else
                parameters[0] = new SqlParameter(PARAMETER_CCY, obj.CCY);
            if (obj.AccountNo < 0)
                parameters[1] = new SqlParameter(PARAMETER_ACCOUNTNO, DBNull.Value);
            else
                parameters[1] = new SqlParameter(PARAMETER_ACCOUNTNO, obj.AccountNo);
            if (string.IsNullOrEmpty(obj.GLCode))
                parameters[2] = new SqlParameter(PARAMETER_GL_CODE, DBNull.Value);
            else
                parameters[2] = new SqlParameter(PARAMETER_GL_CODE, obj.GLCode);
            if (string.IsNullOrEmpty(obj.GLSubCode))
                parameters[3] = new SqlParameter(PARAMETER_GL_SUBCODE, DBNull.Value);
            else
                parameters[3] = new SqlParameter(PARAMETER_GL_SUBCODE, obj.GLSubCode);
            if (obj.DepartmentId < 0)
                parameters[4] = new SqlParameter(PARAMETER_DEPTID, DBNull.Value);
            else
                parameters[4] = new SqlParameter(PARAMETER_DEPTID, obj.DepartmentId);
            if (obj.OpenDate == null)
                parameters[5] = new SqlParameter(PARAMETER_OPENDATE, DBNull.Value);
            else
                parameters[5] = new SqlParameter(PARAMETER_OPENDATE, obj.OpenDate);
            if (obj.CloseDate == null)
                parameters[6] = new SqlParameter(PARAMETER_CLOSEDATE, DBNull.Value);
            else
                parameters[6] = new SqlParameter(PARAMETER_CLOSEDATE, obj.CloseDate);
            //Excute query to get data
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_LIST, CommandType.StoredProcedure, parameters);

            return dt;
        }

        /// <summary>
        /// Get list of all CCY for ComboBox
        /// </summary>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetCCYList()
        {
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_CCY_LIST, CommandType.StoredProcedure);
            return dt;
        }

        /// <summary>
        /// Insert a TransientAccInfo
        /// </summary>
        /// <param name="obj">clsMDTransientAccInfoDTO</param>
        /// <returns>return row number insert successfully</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public int InsertTransientAccInfo(clsMDTransientAccInfoDTO obj)
        {
            try
            {
                if (obj != null)
                {
                    int row = 0;
                    //object outParamName = PARAMETER_DEPTID;
                    SqlParameter[] parameters = new SqlParameter[8];
                    parameters[0] = new SqlParameter(PARAMETER_CCY, obj.CCY);
                    parameters[1] = new SqlParameter(PARAMETER_ACCOUNTNO, obj.AccountNo);
                    parameters[2] = new SqlParameter(PARAMETER_GL_CODE, obj.GLCode);
                    parameters[3] = new SqlParameter(PARAMETER_GL_SUBCODE, obj.GLSubCode);
                    parameters[4] = new SqlParameter(PARAMETER_ACCOUNT_TYPE, obj.AccountType);
                    if (obj.DepartmentId < 0)
                        parameters[5] = new SqlParameter(PARAMETER_DEPTID, DBNull.Value);
                    else
                        parameters[5] = new SqlParameter(PARAMETER_DEPTID, obj.DepartmentId);
                    if (obj.OpenDate == null)
                        parameters[6] = new SqlParameter(PARAMETER_OPENDATE, DBNull.Value);
                    else
                        parameters[6] = new SqlParameter(PARAMETER_OPENDATE, obj.OpenDate);
                    if (obj.CloseDate == null)
                        parameters[7] = new SqlParameter(PARAMETER_CLOSEDATE, DBNull.Value);
                    else 
                        parameters[7] = new SqlParameter(PARAMETER_CLOSEDATE, obj.CloseDate);
                    row = ExecuteNonQuery(STORE_PROCEDURE_INSERT, CommandType.StoredProcedure, parameters);
                    return row;
                }
                return 0;
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Update a TransientAccInfo information
        /// </summary>
        /// <param name="obj">clsMDTransientAccInfoDTO</param>
        /// <returns>return row number update successfully</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public int UpdateTransientAccInfo(clsMDTransientAccInfoDTO obj)
        {
            try
            {
                if (obj != null)
                {
                    SqlParameter[] parameters = new SqlParameter[8];
                    parameters[0] = new SqlParameter(PARAMETER_CCY, obj.CCY);
                    parameters[1] = new SqlParameter(PARAMETER_ACCOUNTNO, obj.AccountNo);
                    parameters[2] = new SqlParameter(PARAMETER_GL_CODE, obj.GLCode);
                    parameters[3] = new SqlParameter(PARAMETER_GL_SUBCODE, obj.GLSubCode);
                    parameters[4] = new SqlParameter(PARAMETER_ACCOUNT_TYPE, obj.AccountType);
                    if (obj.DepartmentId < 0)
                        parameters[5] = new SqlParameter(PARAMETER_DEPTID, DBNull.Value);
                    parameters[5] = new SqlParameter(PARAMETER_DEPTID, obj.DepartmentId);
                    if (obj.OpenDate == null)
                        parameters[6] = new SqlParameter(PARAMETER_OPENDATE, DBNull.Value);
                    else
                        parameters[6] = new SqlParameter(PARAMETER_OPENDATE, obj.OpenDate);
                    if (obj.CloseDate == null)
                        parameters[7] = new SqlParameter(PARAMETER_CLOSEDATE, DBNull.Value);
                    else
                        parameters[7] = new SqlParameter(PARAMETER_CLOSEDATE, obj.CloseDate);
                    return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_UPDATE, CommandType.StoredProcedure, parameters);
                }
                return 0;
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Delete TransientAccInfo
        /// 0: Un-Delete
        /// 1: Deleted
        /// </summary>
        /// <param name="iDeptID"></param>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// 
        /// @endcond
        public int DeleteTransientAccInfo(string strCCY, int iAccNo)
        {
            try
            {
                SqlParameter[] parameter = new SqlParameter[]{
                    new SqlParameter(PARAMETER_CCY, strCCY),
                     new SqlParameter(PARAMETER_ACCOUNTNO, iAccNo)
                };
                return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE, CommandType.StoredProcedure, parameter);
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Get TransientAccInfo by CCY, Account No
        /// </summary>
        /// <param name="iDeptID"></param>
        /// <returns>if found return clsMDTransientAccInfoDTO
        /// else return null
        /// </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public clsMDTransientAccInfoDTO GetTransientAccInfo(string strCCY, int iAccNo)
        {
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter(PARAMETER_CCY, strCCY);
            parameters[1] = new SqlParameter(PARAMETER_ACCOUNTNO, iAccNo);
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_GET_ITEM, CommandType.StoredProcedure, parameters);
            if (dt != null && dt.Rows.Count > 0)
            {
                clsMDTransientAccInfoDTO dto = new clsMDTransientAccInfoDTO();
                dto.CCY = dt.Rows[0][clsMDConstant.MD_COL_CCY].ToString();
                dto.AccountNo = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_ACCOUNT_NO].ToString());
                dto.GLCode = dt.Rows[0][clsMDConstant.MD_COL_GLCODE].ToString();
                dto.GLSubCode = dt.Rows[0][clsMDConstant.MD_COL_GLSUBCODE].ToString();
                dto.DepartmentId = int.Parse(dt.Rows[0][clsMDConstant.MD_COL_DEPARTMENT_ID].ToString());
                dto.AccountType = dt.Rows[0][clsMDConstant.MD_COL_ACCOUNT_TYPE].ToString();
                dto.OpenDate = null;
                dto.CloseDate = null;
                if (!string.IsNullOrEmpty(dt.Rows[0][clsMDConstant.MD_COL_OPENDATE].ToString()))
                {
                    dto.OpenDate = Convert.ToDateTime(dt.Rows[0][clsMDConstant.MD_COL_OPENDATE]);
                }
                if (!string.IsNullOrEmpty(dt.Rows[0][clsMDConstant.MD_COL_CLOSEDATE].ToString()))
                {
                    dto.CloseDate = Convert.ToDateTime(dt.Rows[0][clsMDConstant.MD_COL_CLOSEDATE]);
                }
                return dto;
            }
            return null;
        }

        /// <summary>
        /// Check Exist Transient Account Info
        /// </summary>
        /// <returns>
        /// True if exist Transient Account Info
        /// False if not exist Transient Account Info
        /// </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public bool CheckExistTransAccInfo(string strCCY, int iAccNo)
        {
            SqlParameter[] parameters = new SqlParameter[]{
                    new SqlParameter(PARAMETER_CCY, strCCY),
                    new SqlParameter(PARAMETER_ACCOUNTNO, iAccNo)
                };
            DataTable dt = ExecuteDataReader(STORE_PROCEDURE_CHECK_EXIST, CommandType.StoredProcedure, parameters);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            return false;
        }
    }
}
