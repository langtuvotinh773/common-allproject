﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-21 (Thu, 21 March 2013) $
 * ========================================================
 * This class is used to define functions to access DB of TeamUser
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phoenix.Common.MasterData.Dto;
using System.Data.SqlClient;
using System.Data;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dal 
{
    public class clsMDTeamUserDAL : clsDataAccessLayer
    {
        #region CONST PARAMETER NAME USED IN STORE PROCUDURE
        const string PARAMETER_USERNO = "@userNo";
        const string PARAMETER_TEAMID = "@teamID";
        const string PARAMETER_DELFLAG = "@delFlag";
        const string PARAMETER_CREATEDBY = "@createdBy";
        const string PARAMETER_UPDATEDDATE = "@updateDate";
        #endregion

        #region CONST STORE PROCUDURE NAME
        const string STORE_PROCEDURE_INSERT = "spMD_CreateTeamUser";
        const string STORE_PROCEDURE_DELETE = "spMD_DeleteTeamUser";
        #endregion

        /// <summary>
        /// Insert a new TeamUser
        /// </summary>
        /// <param name="obj">clsMDTeamUserDTO</param>
        /// <returns>return row number insert successfully</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertTeamUser(clsMDTeamUserDTO obj)
        {
            try
            {
                if (obj != null)
                {
                    SqlParameter[] parameters = new SqlParameter[] { 
                        new SqlParameter(PARAMETER_USERNO, obj.UserNo),
                        new SqlParameter(PARAMETER_TEAMID, obj.TeamID),
                        new SqlParameter(PARAMETER_CREATEDBY, obj.CreatedBy)
                    };
                    return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_INSERT, CommandType.StoredProcedure, parameters);
                }
            }
            catch (Exception ex)
            {
                RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
            return 0;
        }

        ///// <summary>
        ///// Delete all TeamUser record have TeamID = iTeamID
        ///// </summary>
        ///// <param name="iUserNo">UserNo</param>
        ///// <param name="iTeamID">TeamID</param>
        ///// <returns>return row number insert successfully</returns>
        ///// @cond
        ///// Author: vlhcnhung
        ///// @endcond
        //public int DeleteTeamUser(int iUserNo, int iTeamID)
        //{
        //    try
        //    {
        //        SqlParameter[] parameters = new SqlParameter[2];
        //        parameters[0] = new SqlParameter(PARAMETER_USERNO, iUserNo);
        //        parameters[1] = new SqlParameter(PARAMETER_TEAMID, iTeamID);
        //        return ExecuteNonQueryWithTransaction(STORE_PROCEDURE_DELETE, CommandType.StoredProcedure, parameters);
        //    }
        //    catch (Exception ex)
        //    {
        //        RollBack();
        //        ////show error message
        //        //clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
        //        ////save log exception
        //        //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
        //        throw new System.ArgumentException(ex.Message);
        //        return -1;
        //    }
        //}
    }
}
