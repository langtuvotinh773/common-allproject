﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define threshold object
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Phoenix.Common.MasterData.Dto
{
	public class clsMDThresholdDTO
	{
		/// <summary>
		/// Threshold ID
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int thresholdID;
		public int ThresholdID
		{
			get { return thresholdID; }
			set { thresholdID = value; }
		}
		/// <summary>
		/// CCY
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string ccy;
		public string CCY
		{
			get { return ccy; }
			set { ccy = value; }
        }

        /// <summary>
        /// Transaction Type
        /// </summary>
        public int TransType { get; set; }

		/// <summary>
		/// Transaction Type
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int transactionType;
		public int TransactionType
		{
			get { return transactionType; }
			set { transactionType = value; }
		}
		/// <summary>
		/// Threshold
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string threshold;
		public string Threshold
		{
			get { return threshold; }
			set { threshold = value; }
		}
		/// <summary>
		/// Update Time
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private DateTime updateTime;
		public DateTime UpdateTime
		{
			get { return updateTime; }
			set { updateTime = value; }
		}
		/// <summary>
		/// Update by
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int updateDateBy;
		public int UpdateDateBy
		{
			get { return updateDateBy; }
			set { updateDateBy = value; }
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsMDThresholdDTO()
		{
			ThresholdID = -1;
			CCY = "";
			TransactionType = -1;
			Threshold = "";
			UpdateTime = DateTime.Now;
			UpdateDateBy = -1;
		}

        /// <summary>
        /// Get Board Rate Dto
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDThresholdDTO GetBoardRateDetailDto(DataRow dr)
        {
            
            CCY = dr["CCYCode"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["CCYCode"]).Trim();
            
            Threshold = dr["Threshold"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Threshold"]).Trim();
            
            return this;
        }
	}
}