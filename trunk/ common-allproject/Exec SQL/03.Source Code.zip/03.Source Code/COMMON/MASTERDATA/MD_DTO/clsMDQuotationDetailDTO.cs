﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-04-08 14:29:30 +0700 (Mon, 08 Apr 2013) $
 * ========================================================
 * This class is used to create QuotationDetail object
 * for Master Date module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDQuotationDetailDTO
    {
        public int QuotationID { get; set; }
        public int ExchangeCCYPairID { get; set; }
        public string ExchangeCCYPairCode { get; set; }
        public string TTM { get; set; }
        public string TTB { get; set; }
        public string TTS { get; set; }
        public string CSB { get; set; }
        public string CSS{ get; set; }
        public string TTBRate { get; set; }
        public string TTSRate { get; set; }
        public string FormatNumber { get; set; }
        public string AgainstCCY { get; set; }

        public clsMDQuotationDetailDTO()
        {
            QuotationID = -1;
            ExchangeCCYPairID = -1;
            ExchangeCCYPairCode = string.Empty;
            TTM = string.Empty;
            TTB = string.Empty;
            TTS = string.Empty;
            CSB = string.Empty;
            CSS = string.Empty;
            TTBRate = string.Empty;
            TTSRate = string.Empty;
            AgainstCCY = string.Empty;
            FormatNumber = string.Empty;
        }
    }
}
