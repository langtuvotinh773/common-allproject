﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-15 (Fri, 15 March 2013) $ 
 * ========================================================
 * This class is used to define properties fo team object.
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDTeamDTO
    {
        public int TeamID { get; set; }
        public string TeamCode { get; set; }
        public string TeamName { get; set; }
        public int DepartmentID { get; set; }
        public string DepartmentCode { get; set; }
        public string DepartmentName { get; set; }
        public int TeamTypeID { get; set; }
        public string TeamTypeCode { get; set; }
        public string TeamTypeName { get; set; }
        public string Remark { get; set; }
        public bool DelFlag { get; set; }
        public int CreatedBy { get; set; }
        public DateTime UpdateDate { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDTeamDTO()
        {
            TeamID = -1;
            TeamCode = string.Empty;
            TeamName = string.Empty;
            DepartmentID = -1;
            DepartmentCode = string.Empty;
            DepartmentName = string.Empty;
            TeamTypeID = -1;
            TeamTypeCode = string.Empty;
            TeamTypeName = string.Empty;
            Remark = string.Empty;
            DelFlag = false;
            CreatedBy = -1;
            UpdateDate = DateTime.Now;
        }
    }
}
