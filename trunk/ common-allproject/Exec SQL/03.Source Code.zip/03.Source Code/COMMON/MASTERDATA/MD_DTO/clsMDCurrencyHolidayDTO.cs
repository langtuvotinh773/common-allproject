﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-27 (Wed, 27 March 2013) $ 
 * ========================================================
 * This class is used to define properties of CurrencyHoliday object.
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDCurrencyHolidayDTO
    {
        public int HolidayID { get; set; }
        public string CCYCode { get; set; }
        public DateTime HolidayDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime UpdateDate { get; set; }

        public clsMDCurrencyHolidayDTO()
        {
            HolidayID = -1;
            CCYCode = string.Empty;
            HolidayDate = DateTime.Now;
            CreatedBy = -1;
            UpdateDate = DateTime.Now;
        }

        /// <summary>
        /// Get Currency Holiday Dto
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public clsMDCurrencyHolidayDTO GetCurrencyHolidayDto(DataRow row)
        {
            HolidayID = (int)row["HolidayID"];
            CCYCode = row["CCYCode"].ToString();
            HolidayDate = (DateTime)row["HolidayDate"];
            return this;
        }
    }
}
