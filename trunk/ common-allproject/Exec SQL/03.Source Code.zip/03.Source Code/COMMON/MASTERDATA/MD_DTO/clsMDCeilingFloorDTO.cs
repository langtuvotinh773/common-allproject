﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define ceiling floor object
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
	public class clsMDCeilingFloorDTO
	{
		/// <summary>
		/// Ceiling
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string ceiling;
		public string Ceiling
		{
			get { return ceiling; }
			set { ceiling = value; }
		}
		/// <summary>
		/// Floor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string floor;
		public string Floor
		{
			get { return floor; }
			set { floor = value; }
		}
		/// <summary>
		/// CCY Pair
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string ccyPair;
		public string CCYPair
		{
			get { return ccyPair; }
			set { ccyPair = value; }
		}
		/// <summary>
		/// CCY Pair ID
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int ccyPairID;
		public int CCYPairID
		{
			get { return ccyPairID; }
			set { ccyPairID = value; }
		}

	}
}
