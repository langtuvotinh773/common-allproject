﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define clsMDBoardRateDTO object
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDBoardRateDTO
    {
        public int BoardRateID { get; set; }
        public decimal? Version { get; set; }
        public int Status { get; set; }
        public String FileDirectory { get; set; }
        public DateTime? ImportTime { get; set; }
        public String EffectiveTime { get; set; }
        public String ImportantNote { get; set; }
        public String Remark { get; set; }
        public int? ApprovedBy { get; set; }
        public Boolean IsActive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string Maker { get; set; }
        public string Approver { get; set; }
        public List<clsMDBoardRateDetailDTO> BoardRateDetails { get; set; }
        public List<string> CCYList { get; set; }
        public List<string> ThresholdList { get; set; }
        public bool IsProcess { get; set; }

        public clsMDBoardRateDTO()
        {
            BoardRateID = -1;
            Version = 1;
            Status = 0;
            FileDirectory = String.Empty;
            ImportTime = null;
            EffectiveTime = String.Empty;
            ImportantNote = String.Empty;
            Remark = String.Empty;
            ApprovedBy = -1;
            IsActive = false;
            CreatedBy = -1;
            UpdateDate = null;
            BoardRateDetails = new List<clsMDBoardRateDetailDTO>();
            CCYList = new List<string>();
            ThresholdList = new List<string>();
        }

        public clsMDBoardRateDTO(DataRow drBoardRate)
        {
            if (drBoardRate != null)
            {
                BoardRateID = int.Parse(drBoardRate["BoardRateID"].ToString().Trim());
                Version = Decimal.Parse(drBoardRate["Version"].ToString().Trim());
                Status = int.Parse(drBoardRate["Status"].ToString().Trim());
                FileDirectory = drBoardRate["Status"].ToString().Trim();
                ImportTime = DateTime.Parse(drBoardRate["Status"].ToString().Trim());
                EffectiveTime = drBoardRate["Status"].ToString().Trim();
                ImportantNote = drBoardRate["Status"].ToString().Trim();
                Remark = drBoardRate["Status"].ToString().Trim();
                ApprovedBy = int.Parse(drBoardRate["Status"].ToString().Trim());
                IsActive = Boolean.Parse(drBoardRate["Status"].ToString().Trim());
                CreatedBy = int.Parse(drBoardRate["Status"].ToString().Trim());
                UpdateDate = DateTime.Parse(drBoardRate["Status"].ToString().Trim());
            }
            else
            {
                BoardRateID = -1;
                Version = 1;
                Status = 0;
                FileDirectory = String.Empty;
                ImportTime = null;
                EffectiveTime = String.Empty;
                ImportantNote = String.Empty;
                Remark = String.Empty;
                ApprovedBy = -1;
                IsActive = false;
                CreatedBy = -1;
                UpdateDate = null;
            }
        }

        /// <summary>
        /// Get Board Rate Dto
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDBoardRateDTO GetBoardRateDto(DataRow dr)
        {
            BoardRateID = (int)dr["BoardRateID"];
            Version = dr["Version"].GetType() == typeof(DBNull) ? new Nullable<Decimal>() : (Decimal)dr["Version"];
            Status = dr["Status"].GetType() == typeof(DBNull) ? (int)clsMDCommonValue.BoardRateStatus.Blank : (int)dr["Status"];
            FileDirectory = dr["FileDirectory"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["FileDirectory"]).Trim();
            ImportTime = dr["ImportTime"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["ImportTime"];
            EffectiveTime = dr["EffectiveTime"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["EffectiveTime"]).Trim();
            ImportantNote = dr["ImportantNote"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["ImportantNote"]).Trim();
            Remark = dr["Remark"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Remark"]).Trim();
            ApprovedBy = dr["ApprovedBy"].GetType() == typeof(DBNull) ? new Nullable<int>() : (int)dr["ApprovedBy"];
            IsActive = dr["IsActive"].GetType() == typeof(DBNull) ? false : (bool)dr["IsActive"];
            CreatedBy = (int)dr["CreatedBy"];
            UpdateDate = dr["UpdateDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["UpdateDate"];
            return this;
        }

        /// <summary>
        /// Get Board Rate Maker Dto
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDBoardRateDTO GetBoardRateMakerDto(DataRow dr)
        {
            BoardRateID = (int)dr["BoardRateID"];
            Version = dr["Version"].GetType() == typeof(DBNull) ? new Nullable<Decimal>() : (Decimal)dr["Version"];
            Status = dr["Status"].GetType() == typeof(DBNull) ? (int)clsMDCommonValue.BoardRateStatus.Blank : (int)dr["Status"];
            FileDirectory = dr["FileDirectory"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["FileDirectory"]).Trim();
            ImportTime = dr["ImportTime"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["ImportTime"];
            EffectiveTime = dr["EffectiveTime"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["EffectiveTime"]).Trim();
            ImportantNote = dr["ImportantNote"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["ImportantNote"]).Trim();
            Remark = dr["Remark"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Remark"]).Trim();
            ApprovedBy = dr["ApprovedBy"].GetType() == typeof(DBNull) ? new Nullable<int>() : (int)dr["ApprovedBy"];
            IsActive = dr["IsActive"].GetType() == typeof(DBNull) ? false : (bool)dr["IsActive"];
            CreatedBy = (int)dr["CreatedBy"];
            UpdateDate = dr["UpdateDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["UpdateDate"];
            Maker = dr["Maker"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Maker"]).Trim();
            Approver = dr["Approver"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Approver"]).Trim();
            return this;
        }

        /// <summary>
        /// Get Board Rate Approver Dto
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDBoardRateDTO GetBoardRateApproverDto(DataRow dr)
        {
            BoardRateID = (int)dr["BoardRateID"];
            Version = dr["Version"].GetType() == typeof(DBNull) ? new Nullable<Decimal>() : (Decimal)dr["Version"];
            Status = dr["Status"].GetType() == typeof(DBNull) ? (int)clsMDCommonValue.BoardRateStatus.Blank : (int)dr["Status"];
            FileDirectory = dr["FileDirectory"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["FileDirectory"]).Trim();
            ImportTime = dr["ImportTime"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["ImportTime"];
            EffectiveTime = dr["EffectiveTime"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["EffectiveTime"]).Trim();
            ImportantNote = dr["ImportantNote"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["ImportantNote"]).Trim();
            Remark = dr["Remark"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Remark"]).Trim();
            ApprovedBy = dr["ApprovedBy"].GetType() == typeof(DBNull) ? new Nullable<int>() : (int)dr["ApprovedBy"];
            IsActive = dr["IsActive"].GetType() == typeof(DBNull) ? false : (bool)dr["IsActive"];
            CreatedBy = (int)dr["CreatedBy"];
            UpdateDate = dr["UpdateDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["UpdateDate"];
            Maker = dr["Maker"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Maker"]).Trim();
            Approver = dr["Approver"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Approver"]).Trim();
            return this;
        }

        /// <summary>
        /// Get Inquiry Board Rate History Dto
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDBoardRateDTO GetInquiryBoardRateHistoryDto(DataRow dr)
        {
            BoardRateID = (int)dr["BoardRateID"];
            Version = dr["Version"].GetType() == typeof(DBNull) ? new Nullable<Decimal>() : (Decimal)dr["Version"];
            Status = dr["Status"].GetType() == typeof(DBNull) ? (int)clsMDCommonValue.BoardRateStatus.Blank : (int)dr["Status"];
            FileDirectory = dr["FileDirectory"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["FileDirectory"]).Trim();
            ImportTime = dr["ImportTime"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["ImportTime"];
            EffectiveTime = dr["EffectiveTime"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["EffectiveTime"]).Trim();
            ImportantNote = dr["ImportantNote"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["ImportantNote"]).Trim();
            Remark = dr["Remark"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Remark"]).Trim();
            ApprovedBy = dr["ApprovedBy"].GetType() == typeof(DBNull) ? new Nullable<int>() : (int)dr["ApprovedBy"];
            IsActive = dr["IsActive"].GetType() == typeof(DBNull) ? false : (bool)dr["IsActive"];
            CreatedBy = (int)dr["CreatedBy"];
            UpdateDate = dr["UpdateDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["UpdateDate"];
            Maker = dr["Maker"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Maker"]).Trim();
            Approver = dr["Approver"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Approver"]).Trim();
            return this;
        }
    }
}
