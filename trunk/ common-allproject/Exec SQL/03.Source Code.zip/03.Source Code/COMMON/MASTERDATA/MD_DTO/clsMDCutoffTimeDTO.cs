﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-24 +0700 (Fri, 24 may 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define CutoffTime object
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Phoenix.Common.MasterData.Dto
{
	public class clsMDCutoffTimeDTO
	{
		/// <summary>
		/// CutoffTime ID
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private int cutoffTimeID;
		public int CutoffTimeID
		{
			get { return cutoffTimeID; }
			set { cutoffTimeID = value; }
		}
		/// <summary>
		/// CCY
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private string ccy;
		public string CCY
		{
			get { return ccy; }
			set { ccy = value; }
		}
		/// <summary>
		/// Transaction Type
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private int transactionType;
		public int TransactionType
		{
			get { return transactionType; }
			set { transactionType = value; }
		}
		/// <summary>
		/// CutoffTime
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private string cutoffTime;
		public string CutoffTime
		{
			get { return cutoffTime; }
			set { cutoffTime = value; }
		}
		/// <summary>
		/// Update Time
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private DateTime updateTime;
		public DateTime UpdateTime
		{
			get { return updateTime; }
			set { updateTime = value; }
		}
		/// <summary>
		/// Update by
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private int updateDateBy;
		public int UpdateDateBy
		{
			get { return updateDateBy; }
			set { updateDateBy = value; }
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public clsMDCutoffTimeDTO()
		{
			CutoffTimeID = -1;
			CCY = "";
			TransactionType = -1;
			CutoffTime = "";
			UpdateTime = DateTime.Now;
			UpdateDateBy = -1;
		}

        /// <summary>
        /// Get Ordinary Deposit IS Rate
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDCutoffTimeDTO GetCutoffTimeDto(DataRow dr)
        {
            CCY = dr["CCYCode"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["CCYCode"]).Trim();
            CutoffTime = dr["CutOffTime"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["CutOffTime"]).Trim();            
            return this;
        }
	}
}