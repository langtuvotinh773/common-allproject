﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDCustomerDTO
    {
          //private string m_CustomerCode;
        public string CustomerCode { get; set; }

        //private string m_FullName;
        public string FullName { get; set; }

        //private string m_ShortName;
        public string ShortName { get; set; }

        //private string m_CustomerType;
        public string CustomerType { get; set; }

        //private bool m_Special;
        public bool Special{ get; set; }

        //private bool m_IndirectInvestor;
        public bool IndirectInvestor { get; set; }

        //private bool m_FXATCode;
        public string FXATCode { get; set; }

        //private bool m_Location;
        public string Location { get; set; }

        public clsMDCustomerDTO()
        {
            CustomerCode = string.Empty;
            FullName = string.Empty;
            ShortName = string.Empty;
            CustomerType = string.Empty;
            Special = false;
            IndirectInvestor = false;
            FXATCode = string.Empty;
            Location = string.Empty;
        }
    }
}
