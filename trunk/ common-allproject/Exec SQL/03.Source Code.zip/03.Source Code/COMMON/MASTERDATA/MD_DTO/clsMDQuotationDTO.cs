﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-04-08 14:29:30 +0700 (Mon, 08 Apr 2013) $
 * $Revision: 11501 $ 
 * ========================================================
 * This class is used to create Quotation object
 * for Master Date module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
	public class clsMDQuotationDTO
	{
		/// <summary>
		/// Quotation ID
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int quotationID;
		public int QuotationID
		{
			get { return quotationID; }
			set { quotationID = value; }
		}
		/// <summary>
		/// Version
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private double version;
		public double Version
		{
			get { return version; }
			set { version = value; }
		}
		/// <summary>
		/// Status
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int status;
		public int Status
		{
			get { return status; }
			set { status = value; }
		}
		/// <summary>
		/// Import Time
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private DateTime importTime;
		public DateTime ImportTime
		{
			get { return importTime; }
			set { importTime = value; }
		}
		/// <summary>
		/// Effective time
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string effectiveTime;
		public string EffectiveTime
		{
			get { return effectiveTime; }
			set { effectiveTime = value; }
		}
		/// <summary>
		/// Seq
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int seq;
		public int Seq
		{
			get { return seq; }
			set { seq = value; }
		}
		/// <summary>
		/// Central bank core rate
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string centralBankCoreRate;
		public string CentralBankCoreRate
		{
			get { return centralBankCoreRate; }
			set { centralBankCoreRate = value; }
		}
		/// <summary>
		/// TC
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string tc;
		public string TC
		{
			get { return tc; }
			set { tc = value; }
		}
		/// <summary>
		/// Note Head
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string noteHead;
		public string NoteHead
		{
			get { return noteHead; }
			set { noteHead = value; }
		}
		/// <summary>
		/// Note threshold
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string noteThreshold;
		public string NoteThreshold
		{
			get { return noteThreshold; }
			set { noteThreshold = value; }
		}
		/// <summary>
		/// Note Mid
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string noteMid;
		public string NoteMid
		{
			get { return noteMid; }
			set { noteMid = value; }
		}
		/// <summary>
		/// Note End
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string noteEnd;
		public string NoteEnd
		{
			get { return noteEnd; }
			set { noteEnd = value; }
		}
		/// <summary>
		/// Remark
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string remark;
		public string Remark
		{
			get { return remark; }
			set { remark = value; }
		}
		/// <summary>
		/// Approver
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string approver;
		public string Approver
		{
			get { return approver; }
			set { approver = value; }
		}
		/// <summary>
		/// Isactive
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool isActive;
		public bool IsActive
		{
			get { return isActive; }
			set { isActive = value; }
		}
		/// <summary>
		/// Create by
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int createdBy;
		public int CreatedBy
		{
			get { return createdBy; }
			set { createdBy = value; }
		}
		/// <summary>
		/// Update date
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private DateTime updateDate;
		public DateTime UpdateDate
		{
			get { return updateDate; }
			set { updateDate = value; }
		}

		/// <summary>
		/// File directory
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string fileDirectory;

		public string FileDirectory
		{
			get { return fileDirectory; }
			set { fileDirectory = value; }
		}
		/// <summary>
		/// ceiling rate
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string ceilingRate;

		public string CeilingRate
		{
			get { return ceilingRate; }
			set { ceilingRate = value; }
		}
		/// <summary>
		/// Floor rate
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string floorRate;

		public string FloorRate
		{
			get { return floorRate; }
			set { floorRate = value; }
		}

		/// <summary>
		/// Stt
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string stt;

		public string STT
		{
			get { return stt; }
			set { stt = value; }
		}

		/// <summary>
		/// Instance of clsMDQuotationDTO
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private static clsMDQuotationDTO instance;

		public static clsMDQuotationDTO Instance()
		{
			if (instance == null)
			{
				instance = new clsMDQuotationDTO();
			}
			return instance; 
		}
		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsMDQuotationDTO()
		{
			QuotationID = -1;
			Version = -1.0;
			Status = -1;
			ImportTime = DateTime.Now;
			EffectiveTime = "";
			Seq = -1;
			CentralBankCoreRate = "";
			TC = "";
			NoteHead = "";
			NoteThreshold = "";
			NoteMid = "";
			NoteEnd = "";
			Remark = "";
			Approver = "";
			IsActive = false;
			CreatedBy = -1;
			UpdateDate = DateTime.Now;
			FileDirectory = string.Empty;
			FloorRate = "";
			CeilingRate = "";
		}
	}
}