﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-14 (Thu, 14 March 2013) $ 
 * ========================================================
 * This class is used to define properties of user object.
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDUserDTO
    {
        public int UserNo { get; set; }
        public string UserName { get; set; }
        public string ShortName { get; set; }
        public string FullName { get; set; }
        public string FullShortName { get; set; }
        public int DepartmentID { get; set; }
        public string Department { get; set; }
        public int TeamID { get; set; }
        public string Team { get; set; }
        public string Officer { get; set; }
        public string Staff01 { get; set; }
        public string Staff02 { get; set; }
        public string Lockout { get; set; }
        public string Password { get; set; }
        public string Remark { get; set; }
        public bool DelFlag { get; set; }
        public int CreatedBy { get; set; }
        public DateTime UpdateDate { get; set; }

        public clsMDUserDTO()
        {
            UserNo = -1;
            UserName = string.Empty;
            ShortName = string.Empty;
            FullName = string.Empty;
            FullShortName = string.Empty;
            DepartmentID = -1;
            Department = string.Empty;
            TeamID = -1;
            Team = string.Empty;
            Officer = string.Empty;
            Staff01 = string.Empty;
            Staff02 = string.Empty;
            Lockout = string.Empty;
            Password = string.Empty;
            Remark = string.Empty;
            DelFlag = false;
            CreatedBy = -1;
            UpdateDate = DateTime.Now;
        }
    }
}
