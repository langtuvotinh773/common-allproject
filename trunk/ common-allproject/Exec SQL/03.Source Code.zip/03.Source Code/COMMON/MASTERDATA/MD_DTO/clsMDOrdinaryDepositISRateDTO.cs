﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define clsMDBoardRateDTO object
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDOrdinaryDepositISRateDTO
    {
        public int OrdinaryDepositISRateID { get; set; }
        public string CCY {get;set;}
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public Decimal Rate { get; set; }
        public clsMDOrdinaryDepositISRateDTO()
        {
            
        }

        /// <summary>
        /// Get Ordinary Deposit IS Rate
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDOrdinaryDepositISRateDTO GetOrdinaryDepositISRateDto(DataRow dr)
        {
            CCY = dr["CCY"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["CCY"]).Trim();
            FromDate = (DateTime)dr["FromDate"];
            ToDate = (DateTime)dr["ToDate"];
            Rate = (Decimal)dr["Rate"];           
            return this;
        }

    }
}
