﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define clsMDBoardRateDTO object
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDSBVMinMaxDTO
    {
        public short SBVMinMaxID { get; set; }        
        public string CCY { get; set; }
        public short CCYTermsID { get; set; }
        public string Tenor { get; set; }
        public byte TransType { get; set; }

        public Decimal DepositMin { get; set; }
        public Decimal DepositMax { get; set; }
        public Decimal TDMin { get; set; }
        public Decimal TDMax { get; set; }

        public short CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public short UpdatedBy { get; set; }
        public DateTime? UpdateDate { get; set; }



        public clsMDSBVMinMaxDTO()
        {
            UpdatedBy = -1;
        }



        /// <summary>
        /// Get SBV Min Max Dto
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDSBVMinMaxDTO GetSBVMinMaxDTO(DataRow dr)
        {
            SBVMinMaxID = (short)dr["SBVMinMaxID"];
            CCY = dr["CCY"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["CCY"]).Trim();
            Tenor = dr["Tenor"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Tenor"]).Trim();
            DepositMin = (Decimal)dr["DepositMin"];
            DepositMax = (Decimal)dr["DepositMax"];
            TDMin = (Decimal)dr["TDMin"];
            TDMax = (Decimal)dr["TDMax"];

            return this;
        }


        /// <summary>
        /// Get SBV Min Max Dto to udpate
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDSBVMinMaxDTO GetSBVMinMaxDTOToUpdate(DataRow dr)
        {
            SBVMinMaxID = (short)dr["SBVMinMaxID"];
            CCY = dr["CCY"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["CCY"]).Trim();
            Tenor = dr["Tenor"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Tenor"]).Trim();
            TransType = (byte)dr["TransType"];
            DepositMin = (Decimal)dr["DepositMin"];
            DepositMax = (Decimal)dr["DepositMax"];
            TDMin = (Decimal)dr["TDMin"];
            TDMax = (Decimal)dr["TDMax"];

            return this;
        }
    }
}
