﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-27 (Mon, 27 May 2013) $ 
 * ========================================================
 * This class is used to define properties of transient account information object
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Config.Classes;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDTransientAccInfoDTO
    {
        // private string m_CCY
        public string CCY { get; set; }

        //private int m_AccountNo;
        public int AccountNo { get; set; }

        //private string m_GLCode;
        public string GLCode { get; set; }

        //private string m_GLSubCode;
        public string GLSubCode { get; set; }

        //private int m_DepartmentId;
        public int DepartmentId { get; set; }

        //private string m_AccountType;
        public string AccountType { get; set; }

        //private DateTime m_OpenDate;
        public DateTime? OpenDate { get; set; }

        //private DateTime m_CloseDate;
        public DateTime? CloseDate { get; set; }

        public clsMDTransientAccInfoDTO()
        {
            CCY = string.Empty;
            //AccountNo = clsUserInfo.UserNo;
            AccountNo = -1;
            GLCode = string.Empty;
            GLSubCode = string.Empty;
            DepartmentId = -1;
            AccountType = string.Empty;
            OpenDate = null;
            CloseDate = null;
            //OpenDate = DateTime.Now;
            //OpenDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0, 0);
            //CloseDate = DateTime.Now;
            //CloseDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0, 0);
        }
    }
}
