﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-04-08 14:29:30 +0700 (Mon, 08 Apr 2013) $
 * ========================================================
 * This class is used to create ExchangeCCYPair object
 * for Master Date module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDExchangeCCYPairDTO
    {
        public int ExchangeCCYPairID { get; set; }
        public string ExchangeCCYPair { get; set; }
        public string BaseCCY { get; set; }
        public string QuoteCCY { get; set; }
        public int CreatedBy { get; set; }
        public DateTime UpdateDate { get; set; }

        public clsMDExchangeCCYPairDTO()
        {
            ExchangeCCYPairID = -1;
            ExchangeCCYPair = string.Empty;
            BaseCCY = string.Empty;
            QuoteCCY = string.Empty;
            CreatedBy = -1;
            UpdateDate = DateTime.Now;
        }
    }
}
