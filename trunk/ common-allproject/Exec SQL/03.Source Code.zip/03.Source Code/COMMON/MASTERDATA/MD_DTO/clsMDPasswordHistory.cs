﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-04-22 (mon, 22 April 2013) $ 
 * ========================================================
 * This class is used to define properties of password history object.
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDPasswordHistory
    {
        public int PasswordHistoryID { get; set; }
        public int UserNo { get; set; }
        public string Password { get; set; }
        public DateTime UpdatedDate { get; set; }

        public clsMDPasswordHistory()
        {
            PasswordHistoryID = -1;
            UserNo = -1;
            Password = string.Empty;
            UpdatedDate = DateTime.Now;
        }
    }
}
