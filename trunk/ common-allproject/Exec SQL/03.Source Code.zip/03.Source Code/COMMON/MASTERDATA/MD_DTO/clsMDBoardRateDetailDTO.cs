﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define clsMDBoardRateDetailDTO object
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDBoardRateDetailDTO
    {
        public Int64 BoardRateDetailID { get; set; }
        public int BoardRateID { get; set; }
        public int CCYTermsID { get; set; }
        public String Term { get; set; }
        public String CCY { get; set; }
        public int TransType { get; set; }
        public string TransTypeName { get; set; }
        public String SameDay { get; set; }
        public DateTime? SameDayValueDate { get; set; }
        public DateTime? SameDayMaturityDate { get; set; }
        public String Tom { get; set; }
        public DateTime? TomValueDate { get; set; }
        public DateTime? TomMaturityDate { get; set; }
        public String Spot { get; set; }
        public DateTime? SpotValueDate { get; set; }
        public DateTime? SpotMaturityDate { get; set; }
        public String FormatNumber { get; set; }
        public DateTime? ImportTime { get; set; }
        public Boolean IsActive { get; set; }

        /// <summary>
        /// EX: FOR THE AMOUNT UP TO VND 40 BIO
        /// </summary>
        public string CCYForAmount { get; set; }
        /// <summary>
        /// EX: VND I/S (%)
        /// </summary>
        public string CCYForPercent { get; set; }

        /// <summary>
        /// Get Board Rate Dto
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDBoardRateDetailDTO GetBoardRateDetailDto(DataRow dr)
        {
            BoardRateDetailID = (Int64)dr["BoardRateDetailID"];
            BoardRateID = (int)dr["BoardRateID"];
            CCYTermsID = (int)dr["CCYTermsID"];
            Term = dr["Term"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Term"]).Trim();
            CCY = dr["CCY"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["CCY"]).Trim();
            TransType = (int)dr["TransType"];
            SameDay = dr["SameDay"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["SameDay"]).Trim();
            SameDayValueDate = dr["SameDayValueDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SameDayValueDate"];
            SameDayMaturityDate = dr["SameDayMaturityDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SameDayMaturityDate"];
            Tom = dr["Tom"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Tom"]).Trim();
            TomValueDate = dr["TomValueDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["TomValueDate"];
            TomMaturityDate = dr["TomMaturityDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["TomMaturityDate"];
            Spot = dr["Spot"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Spot"]).Trim();
            SpotValueDate = dr["SpotValueDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SpotValueDate"];
            SpotMaturityDate = dr["SpotMaturityDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SpotMaturityDate"];
            FormatNumber = dr["FormatNumber"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["FormatNumber"]).Trim();
            return this;
        }

        /// <summary>
        /// Get Currency Inquiry Board Rate History Dto
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDBoardRateDetailDTO GetCurrencyInquiryBoardRateDetailHistoryDto(DataRow dr)
        {
            BoardRateDetailID = (Int64)dr["BoardRateDetailID"];
            BoardRateID = (int)dr["BoardRateID"];
            CCYTermsID = (int)dr["CCYTermsID"];
            Term = dr["Term"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Term"]).Trim();
            CCY = dr["CCY"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["CCY"]).Trim();
            TransType = (int)dr["TransType"];
            SameDay = dr["SameDay"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["SameDay"]).Trim();
            SameDayValueDate = dr["SameDayValueDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SameDayValueDate"];
            SameDayMaturityDate = dr["SameDayMaturityDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SameDayMaturityDate"];
            Tom = dr["Tom"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Tom"]).Trim();
            TomValueDate = dr["TomValueDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["TomValueDate"];
            TomMaturityDate = dr["TomMaturityDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["TomMaturityDate"];
            Spot = dr["Spot"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Spot"]).Trim();
            SpotValueDate = dr["SpotValueDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SpotValueDate"];
            SpotMaturityDate = dr["SpotMaturityDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SpotMaturityDate"];
            FormatNumber = dr["FormatNumber"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["FormatNumber"]).Trim();
            ImportTime = dr["ImportTime"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["ImportTime"];
            IsActive = dr["IsActive"].GetType() == typeof(DBNull) ? false : (bool)dr["IsActive"];
            return this;
        }

        /// <summary>
        /// Get Print Preview Board Rate Dto
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDBoardRateDetailDTO GetPrintPreviewBoardRateDetailDto(DataRow dr)
        {            
            Term = dr["Term"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Term"]).Trim();
            CCY = dr["CCY"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["CCY"]).Trim();
            TransType = (int)dr["TransType"];
            SameDay = dr["SameDay"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["SameDay"]).Trim();
            SameDayValueDate = dr["SameDayValueDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SameDayValueDate"];
            
            Tom = dr["Tom"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Tom"]).Trim();
            TomValueDate = dr["TomValueDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["TomValueDate"];
            
            Spot = dr["Spot"].GetType() == typeof(DBNull) ? String.Empty : ((string)dr["Spot"]).Trim();
            SpotValueDate = dr["SpotValueDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["SpotValueDate"]; 
            CCYForPercent = String.Format(clsMDConstant.BOARD_RATE_CCY, CCY);
            TransTypeName = clsMDFunction.GetTransTypeName(TransType);            
            return this;
        }
    }
}
