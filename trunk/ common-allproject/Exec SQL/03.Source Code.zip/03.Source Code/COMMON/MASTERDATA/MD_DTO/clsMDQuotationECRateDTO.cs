﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-04-08 14:29:30 +0700 (Mon, 08 Apr 2013) $
 * ========================================================
 * This class is used to create QuotationECRate object
 * for Master Date module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDQuotationECRateDTO
    {
        public int QuotationID { get; set; }
        public int ExchangeCCYPairID { get; set; }
        public string ExchangeCCYPairCode { get; set; }
        public string CustRateBuy { get; set; }
        public string AGroupECBuy { get; set; }
        public string BGroupECBuy { get; set; }
        public string CustRateSell { get; set; }
        public string AGroupECSell { get; set; }
        public string BGroupECSell { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDQuotationECRateDTO()
        {
            QuotationID = -1;
            ExchangeCCYPairID = -1;
            ExchangeCCYPairCode = string.Empty;
            CustRateBuy = string.Empty;
            AGroupECBuy = string.Empty;
            BGroupECBuy = string.Empty;
            CustRateSell = string.Empty;
            AGroupECSell = string.Empty;
            BGroupECSell = string.Empty;
        }
    }
}
