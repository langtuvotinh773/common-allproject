﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-08-30 20:37:30 +0700 (Friday, 30 August 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to add/modify default rate
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Data;

namespace Phoenix.Common.MasterData.Dto
{
    #region AddModifyDefaultRate
    public class clsAddModifyDefaultRateDTO
    {
        #region Declaration
        //Header
        //+ Input Date From
        DateTime inputDateFrom = new DateTime();        
        //+ Input Date To
        DateTime inputDateTo = new DateTime();
        //+ Created By
        string createdBy = String.Empty;
        //+ isLatestDefaultRate
        bool isLatestDefaultRate;
        //+ isEmptyDefaultRate
        bool isEmptyDefaultRate;
        //List Of Data On Grid
        List<clsAddModifyDefaultRateOnGridDTO> lstAddModifyDefaultRateOnGridDTO = new List<clsAddModifyDefaultRateOnGridDTO>();        
        #endregion Declaration

        #region Properties
        //Header
        //+ Input Date From
        public DateTime InputDateFrom
        {
            get 
            { 
                return inputDateFrom; 
            }
            set 
            { 
                inputDateFrom = value; 
            }
        }
        //+ Input Date To
        public DateTime InputDateTo
        {
            get 
            { 
                return inputDateTo; 
            }
            set 
            { 
                inputDateTo = value; 
            }
        }
        //+ Created By
        public string CreatedBy
        {
            get 
            { 
                return createdBy; 
            }
            set 
            { 
                createdBy = value; 
            }
        }
        //+ isLatestDefaultRate
        public bool IsLatestDefaultRate
        {
            get 
            { 
                return isLatestDefaultRate; 
            }
            set 
            { 
                isLatestDefaultRate = value; 
            }
        }
        //+ isEmptyDefaultRate
        public bool IsEmptyDefaultRate
        {
            get 
            { 
                return isEmptyDefaultRate; 
            }
            set 
            { 
                isEmptyDefaultRate = value;
            }
        }
        //+ List Of Default Rate On Grid
        public List<clsAddModifyDefaultRateOnGridDTO> LstAddModifyDefaultRateOnGridDTO
        {
            get 
            { 
                return lstAddModifyDefaultRateOnGridDTO; 
            }
            set 
            { 
                lstAddModifyDefaultRateOnGridDTO = value; 
            }
        }
        #endregion Properties
    }

    public class clsAddModifyDefaultRateOnGridDTO
    {
        #region Declaration
        //+ CCY
        string ccy = string.Empty;        
        //+ Rate
        decimal rate = 0;
        //+ Is Inserted
        string oldDefaultRate = string.Empty;       
        #endregion Declaration

        #region Properties
        //+ CCY
        public string CCY
        {
            get 
            { 
                return ccy; 
            }
            set 
            { 
                ccy = value; 
            }
        }
        //+ Rate
        public decimal Rate
        {
            get 
            { 
                return rate; 
            }
            set 
            { 
                rate = value; 
            }
        }
        //+ Is Inserted
        public string OldDefaultRate
        {
            get 
            { 
                return oldDefaultRate; 
            }
            set 
            { 
                oldDefaultRate = value; 
            }
        }
        #endregion Properties
    }
    #endregion AddModifyDefaultRate

    #region ListDefaultRate
    public class clsListDefaultRateDTO
    {
        #region Declaration
        //Header
        //+ Input Date From
        DateTime inputDateFrom = new DateTime();        
        //+ Input Date To
        DateTime inputDateTo = new DateTime();       
        //+ CCY
        string ccy = String.Empty;       
        //+ Rate From
        string rateFrom = String.Empty;        
        //+ Rate To
        string rateTo = String.Empty;        
        //List Of Data On Grid
        List<clsListDefaultRateOnGridDTO> lstDefaultRateOnGridDTO = new List<clsListDefaultRateOnGridDTO>();
        #endregion Declaration

        #region Properties
        //Header
        //+ Input Date From
        public DateTime InputDateFrom
        {
            get 
            { 
                return inputDateFrom; 
            }
            set 
            { 
                inputDateFrom = value; 
            }
        }
        //+ Input Date To
        public DateTime InputDateTo
        {
            get 
            { 
                return inputDateTo; 
            }
            set 
            { 
                inputDateTo = value; 
            }
        }
        //+ CCY
        public string CCY
        {
            get 
            { 
                return ccy; 
            }
            set  
            {
                ccy = value; 
            }
        }
        //+ Rate From
        public string RateFrom
        {
            get 
            { 
                return rateFrom; 
            }
            set 
            { 
                rateFrom = value; 
            }
        }
        //+ Rate To
        public string RateTo
        {
            get 
            { 
                return rateTo; 
            }
            set 
            { 
                rateTo = value;
            }
        }
        //+ List Of Default Rate On Grid
        //List Of Data On Grid
        public List<clsListDefaultRateOnGridDTO> LstDefaultRateOnGridDTO
        {
            get 
            { 
                return lstDefaultRateOnGridDTO;
            }
            set
            { 
                lstDefaultRateOnGridDTO = value; 
            }
        }
        #endregion Properties
    }

    public class clsListDefaultRateOnGridDTO
    {
        #region Declaration
        //+ Input Date From
        DateTime inputDateFrom = new DateTime();        
        //+ Input Date To
        DateTime inputDateTo = new DateTime();        
        //+ CCY
        string ccy = string.Empty;        
        //+ Rate
        decimal rate = 0;        
        #endregion Declaration

        #region Properties
        //+ Input Date From
        public DateTime InputDateFrom
        {
            get 
            { 
                return inputDateFrom; 
            }
            set 
            { 
                inputDateFrom = value; 
            }
        }
        //+ Input Date To
        public DateTime InputDateTo
        {
            get 
            { 
                return inputDateTo;
            }
            set 
            { 
                inputDateTo = value; 
            }
        }
        //+ CCY
        public string CCY
        {
            get 
            { 
                return ccy; 
            }
            set 
            { 
                ccy = value; 
            }
        }
        //+ Rate
        public decimal Rate
        {
            get 
            { 
                return rate; 
            }
            set 
            { 
                rate = value;
            }
        }
        #endregion Properties

        /// <summary>
        /// Get From Date, To Date 
        /// </summary>
        /// <param name="dr"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsListDefaultRateOnGridDTO GetDefaultRateOnCombobox(DataRow dr)
        {
            InputDateFrom = (DateTime)dr["FromDate"];
            InputDateTo = (DateTime)dr["ToDate"];
            return this;
        }
    }
    #endregion ListDefaultRate
}
