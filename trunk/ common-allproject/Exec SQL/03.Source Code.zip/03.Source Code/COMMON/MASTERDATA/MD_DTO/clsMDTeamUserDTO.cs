﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-19 (Tue, 19 March 2013) $ 
 * ========================================================
 * This class is used to define properties of TeamUser object.
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDTeamUserDTO
    {
        public int UserNo { get; set; }
        public int TeamID { get; set; }
        public bool DelFlag { get; set; }
        public string CreatedBy { get; set; }
        public DateTime UpdateDate { get; set; }
    }
}
