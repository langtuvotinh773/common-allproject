﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define clsMDBoardRateDTO object
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDPrefixTDNoDTO
    {
        public short PrefixTDNo { get; set; }
        public string CCY { get; set; }
        public string Value { get; set; }
        public string Remark { get; set; }

        public short CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public short UpdatedBy { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string UserName { get; set; }


        public clsMDPrefixTDNoDTO()
        {
            UpdatedBy = -1;
        }

        /// <summary>
        /// Get PrefixTDNoDTO
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDPrefixTDNoDTO GetPrefixTDNoDTO(DataRow dr)
        {
            PrefixTDNo = (short)dr["PrefixTDNo"];
            CCY = dr["CCY"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["CCY"]).Trim();
            Value = dr["Value"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Value"]).Trim();
            UpdateDate = dr["UpdateDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)dr["UpdateDate"];
            UserName = dr["UserName"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["UserName"]).Trim();

            return this;
        }


        /// <summary>
        /// Get PrefixTDNoDTO to update
        /// </summary>
        /// <param name="drBoardRate"></param>
        /// <returns></returns>
        public clsMDPrefixTDNoDTO GetPrefixTDNoDTOToUpdate(DataRow dr)
        {
            PrefixTDNo = (short)dr["PrefixTDNo"];
            CCY = dr["CCY"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["CCY"]).Trim();
            Value = dr["Value"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Value"]).Trim();
            Remark = dr["Remark"].GetType() == typeof(DBNull) ? string.Empty : ((string)dr["Remark"]).Trim();
            
            return this;
        }
    }
}
