﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-13 (Web, 13 March 2013) $ 
 * ========================================================
 * This class is used to define properties of department object
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Config.Classes;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDDepartmentDTO
    {
        //private int m_DeptID;
        public int DepartmentID { get; set; }

        //private string m_DeptCode;
        public string DepartmentCode { get; set; }

        //private string m_DeptName;
        public string DepartmentName { get; set; }

        //private string m_Remark;
        public string Remark { get; set; }

        //private string m_DelFlag;
        public bool DelFlag { get; set; }

        //private string m_CreatedBy;
        public int CreatedBy { get; set; }

        //private DateTime m_UpdateDate;
        public DateTime UpdateDate { get; set; }

        public clsMDDepartmentDTO()
        {
            DepartmentID = -1;
            DepartmentCode = string.Empty;
            DepartmentName = string.Empty;
            Remark = string.Empty;
            DelFlag = false;
            CreatedBy = clsUserInfo.UserNo;
            UpdateDate = DateTime.Now;
        }
    }
}
