﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-27 (Wed, 27 March 2013) $ 
 * ========================================================
 * This class is used to define properties of Currency object.
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDCurrencyMasterDTO
    {
        public string CCYCode { get; set; }
        public string CurrencyName { get; set; }
        public string Description { get; set; }
        public int CreatedBy { get; set; }
        public DateTime UpdateDate { get; set; }

        public clsMDCurrencyMasterDTO()
        {
            CCYCode = string.Empty;
            CurrencyName = string.Empty;
            Description = string.Empty;
            CreatedBy = -1;
            UpdateDate = DateTime.Now;
        }
    }
}
