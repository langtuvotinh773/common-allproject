﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-19 (Tue, 19 March 2013) $ 
 * ========================================================
 * This class is used to define properties of DepartmentUser object.
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.MasterData.Dto
{
    public class clsMDDepartmentUserDTO
    {
        public int UserNo { get; set; }
        public int DepartmentID { get; set; }
        public bool DelFlag { get; set; }
        public int CreatedBy { get; set; }
        public DateTime UpdateDate { get; set; }

        public clsMDDepartmentUserDTO()
        {
            UserNo = -1;
            DepartmentID = -1;
            DelFlag = false;
            CreatedBy = -1;
            UpdateDate = DateTime.Now;
        }
    }
}
