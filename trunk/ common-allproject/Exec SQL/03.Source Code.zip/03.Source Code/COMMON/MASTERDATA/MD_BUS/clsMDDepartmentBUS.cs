﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-13 (Web, 13 March 2013) $
 * ========================================================
 * This class is used to implement business logic for department
 * Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDDepartmentBUS
    {
        clsMDDepartmentDAL m_DAL = null;

        private static clsMDDepartmentBUS instance;
        public static clsMDDepartmentBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDDepartmentBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDDepartmentBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsMDDepartmentDAL();
            }
        }        

        /// <summary>
        /// Get list of all departments based on input parameter
        /// If all parammeters are blank or null, will get all departments
        /// </summary>
        /// <param name="obj">clsMDDepartmentDTO</param>
        /// <returns> DataTable </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetDepartmentList(clsMDDepartmentDTO obj)
        {
            return m_DAL.GetDepartmentList(obj);
        }

        /// <summary>
        /// Get list of all department for ComboBox Department in User List screen
        /// not DelFlag = 1
        /// Return DataTable(DepartmentID, DepartmentCode, DepartmentName)
        /// </summary>
        /// <returns>DataTable(DepartmentID, DepartmentCode, DepartmentName)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAllDepartmentList()
        {
            return m_DAL.GetAllDepartmentList();
        }        

        /// <summary>
        /// Get department by DepartmentID
        /// Return clsMDDepartmentDTO
        /// </summary>
        /// <param name="iDeptID">DepartmentID</param>
        /// <returns>clsMDDepartmentDTO</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public clsMDDepartmentDTO GetDepartment(int iDeptID)
        {
            return m_DAL.GetDepartment(iDeptID);
        }

        /// <summary>
        /// Insert Department
        /// Return number of row insert
        /// </summary>
        /// <param name="obj">clsMDDepartmentDTO</param>
        /// <returns>number of row insert</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertDepartment(clsMDDepartmentDTO obj, clsMDLogBase logBase)
        {
            try
            {
                //insert department
                int iRow = m_DAL.InsertDepartment(obj);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.Key = obj.DepartmentCode + " " + obj.DepartmentID;//Key: [DepartmentCode DepartmentID]
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Update information of Department
        /// Return number of row update
        /// </summary>
        /// <param name="obj">clsMDDepartmentDTO</param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int UpdateDepartment(clsMDDepartmentDTO obj, clsMDLogBase logBase)
        {
            try
            {
                //update department
                int iRow = m_DAL.UpdateDepartment(obj);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.Key = obj.DepartmentCode + " " + obj.DepartmentID;//Key: [DepartmentCode DepartmentID]
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //////show error message
                ////clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //////save log exception
                ////clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Delete Department
        /// </summary>
        /// <param name="iDeptID">DepartmentID</param>
        /// <returns>number of row delete</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int DeleteDepartment(int iDeptID, clsMDLogBase logBase)
        {
            try
            {
                //delete logic department
                int iRow = m_DAL.DeleteDepartment(iDeptID);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Check duplicate DepartmentCode, DepartmentName
        /// Return Dictionary<string, int>
        /// Ex: <DepartmentCode, 0> : not exist in database
        ///     <DepartmentName, 1> : exist a record has same name in database
        /// </summary>
        /// <param name="iNewDept">if create action iNewDept = 0 else iNewDept = 1</param>
        /// <param name="iDeptID">DepartmentID</param>
        /// <param name="strDeptCode">DepartmentCode</param>
        /// <param name="strDeptName">DepartmentName</param>
        /// <returns>Dictionary<string, int></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public Dictionary<string, int> ValidationDuplicateDepartment(int iNewDept, int iDeptID, string strDeptCode, string strDeptName)
        {
            return m_DAL.ValidationDuplicateDepartment(iDeptID, iDeptID, strDeptCode, strDeptName);
        }
    }
}
