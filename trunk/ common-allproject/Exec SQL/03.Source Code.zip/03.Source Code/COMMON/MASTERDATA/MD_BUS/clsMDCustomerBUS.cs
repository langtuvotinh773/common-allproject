﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-16 (Thur, 16 May 2013) $
 * ========================================================
 * This class is used to implement business logic for team
 * Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;
using System.Data;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDCustomerBUS
    {
         clsMDCustomerDAL m_DAL = null;

        private static clsMDCustomerBUS instance;
        public static clsMDCustomerBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDCustomerBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDCustomerBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsMDCustomerDAL();
            }
        }        

        /// <summary>
        /// Get list of all customer based on input parameter
        /// If all parammeters are blank or null, will get all customer
        /// </summary>
        /// <param name="obj">clsMDCustomerDTO</param>
        /// <returns> DataTable </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetCustomerList(clsMDCustomerDTO obj, string strparamType)
        {
            return m_DAL.GetCustomerList(obj, strparamType);
        }

        /// <summary>
        /// Get list of all customer based on input parameter
        /// If all parammeters are blank or null, will get all customer
        /// </summary>
        /// <param name="obj">strCusCode</param>
        /// <returns> DataTable </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public clsMDCustomerDTO GetCustomer(string strCusCode)
        {
            return m_DAL.GetCustomer(strCusCode);
        }
        

        /// <summary>
        /// Get list of all name customer
        /// </summary>
        /// <param name=""></param>
        /// <returns> DataTable </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<CbbObject> GetNameCustomerList()
        {
            return m_DAL.GetNameCustomerList();
        }

        /// <summary>
        /// Get list of all code customer
        /// </summary>
        /// <param name=""></param>
        /// <returns> List all customer's code </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<CbbObject> GetCodeCustomerList()
        {
            return m_DAL.GetCodeCustomerList();
        }

        /// <summary>
        /// Get list of all code customer
        /// </summary>
        /// <param name=""></param>
        /// <returns> List all customer's code </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<CbbObject> GetFXATCodeList()
        {
            return m_DAL.GetFXATCodeList();
        }

        /// <summary>
        /// Get list of all code customer
        /// </summary>
        /// <param name=""></param>
        /// <returns> List all customer's code </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<CbbObject> GetLocationCodeList()
        {
            return m_DAL.GetLocationCodeList();
        }

        /// <summary>
        /// Update information of customer
        /// Return number of row update
        /// </summary>
        /// <param name="obj">clsMDCustomerDTO</param>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public int UpdateCustomer(clsMDCustomerDTO obj, string strparamType, clsMDLogBase logBase)
        {
            try
            {
                //update customer
                int iRow = m_DAL.UpdateCustomer(obj, strparamType);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.Key = obj.CustomerCode; //Key: [Customer code]
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Get list of all customer based on name        
        /// </summary>
        /// <returns> DataTable </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetListCustomerByName( string strname)
        {
            return m_DAL.GetCustomerListByName(strname);
        }

        /// <summary>
        /// Get list of all customer based on name        
        /// </summary>
        /// <returns> DataTable </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetListCustomerByCode(string strcode)
        {
            return m_DAL.GetCustomerListByCode(strcode);
        }

        /// <summary>
        /// Check exist FXAT Code of customer
        /// </summary>
        /// <param name=""></param>
        /// <returns> List FXAT code exist </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable CheckExistFXATCode(string strFXATCode)
        {
            return m_DAL.CheckExistFXATCode(strFXATCode);
        }

        /// <summary>
        /// Check exist Location Code of customer
        /// </summary>
        /// <param name=""></param>
        /// <returns> List Location code exist </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable CheckExistLocationCode(string strLocationCode)
        {
            return m_DAL.CheckExistLocationCode(strLocationCode);
        }

        /// <summary>
        /// Save Location
        /// </summary>
        /// <param name=""></param>
        /// <returns> </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void SaveLocation(string strLocationCode, string strLocationName)
        {
            m_DAL.SaveLocation(strLocationCode, strLocationName);
        }

        /// <summary>
        /// Get list FXAT Code by name
        /// </summary>
        /// <returns> List FXAT Code </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public List<String> GetListFXATCodeByName(string strname)
        {
            return m_DAL.GetFXATCodeListByName(strname);
        }
    }
}
