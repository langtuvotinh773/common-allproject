﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phoenix.Common.MasterData.Dto;
using System.Data;
using Phoenix.Common.MasterData.Dal;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Com;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Common.Log.Dto;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDBoardRaterBUS
    {
        private string spMD_BoardRateInfo = "dbo.spMD_BoardRateInfo";
        private string spMD_GetBoardRateDetail = "dbo.spMD_GetBoardRateDetail";
        private string spMD_GetCurrencyHolidayByCCY = "dbo.spMD_GetCurrencyHolidayByCCY";
        private string spMD_InsertBoardRate = "dbo.spMD_InsertBoardRate";
        private string spMD_UpdateBoardRate = "dbo.spMD_UpdateBoardRate";
        private string spMD_InsertBoardRateDetail = "dbo.spMD_InsertBoardRateDetail";

        private string spMD_GetViewBoardRateMaker = "dbo.spMD_GetViewBoardRateMaker";
        private string spMD_GetViewBoardRateApprover = "dbo.spMD_GetViewBoardRateApprover";

        private string spMD_GetInquiryBoardRateHistory = "dbo.spMD_GetInquiryBoardRateHistory";
        private string spMD_GetCurrencyInquiryBoardRateHistory = "spMD_GetCurrencyInquiryBoardRateHistory";
        private string spMD_PrintPreviewBoardRate = "spMD_PrintPreviewBoardRate";

        private string spMD_GetImportantNoteByParameters = "spMD_GetImportantNoteByParameters";

        private string spMD_GetAllCCYCutOFFTime = "spMD_GetAllCCYCutOFFTime";

        private string spMD_GetAllOrdinaryDepositISRate = "spMD_GetAllOrdinaryDepositISRate";
        /// <summary>
        /// used to process data from database
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private clsMDBoardRaterDAL m_DAL = null;
        public clsMDBoardRaterDAL DAL
        {
            get
            {
                return m_DAL;
            }
        }

        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsMDBoardRaterBUS()
        {
            m_DAL = new clsMDBoardRaterDAL();
        }

        /// <summary>
        /// Get instance of clsMDBoardRaterBUS object
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private static clsMDBoardRaterBUS instance;
        public static clsMDBoardRaterBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDBoardRaterBUS();
            }
            return instance;

        }

        /// <summary>
        /// commit transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// Get last path
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public string GetLastestFileDirectoryOfBoardRate()
        {
            return m_DAL.GetLastestFileDirectoryOfBoardRate();
        }

        /// <summary>
        /// Get Board Rate info and board rate detail
        /// If boardRateID = 0 => get previous Board Rate 
        /// If boardRateID <> 0 => get Board Rate by boardRateID
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsMDBoardRateDTO GetBoardRateAndBoadRateDetail(int boardRateID)
        {
            clsMDBoardRateDTO dto = new clsMDBoardRateDTO();
            DataTable dtBoardRate = new DataTable();
            DataTable dtBoardRateDetail = new DataTable();
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@BoardRateID", boardRateID);
            dtBoardRate = m_DAL.ExecuteDataReader(spMD_BoardRateInfo, CommandType.StoredProcedure, parameters);
            if (dtBoardRate.Rows.Count > 0)
            {
                for (int i = 0; i < dtBoardRate.Rows.Count; i++)
                {
                    dto = (new clsMDBoardRateDTO()).GetBoardRateDto(dtBoardRate.Rows[i]);
                }
                parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@BoardRateID", dto.BoardRateID);
                dtBoardRateDetail = m_DAL.ExecuteDataReader(spMD_GetBoardRateDetail, CommandType.StoredProcedure, parameters);

                if (dtBoardRateDetail.Rows.Count > 0)
                {
                    string CCY = string.Empty;
                    for (int j = 0; j < dtBoardRateDetail.Rows.Count; j++)
                    {
                        dto.BoardRateDetails.Add(new clsMDBoardRateDetailDTO().GetBoardRateDetailDto(dtBoardRateDetail.Rows[j]));
                        if (!CCY.Equals(dto.BoardRateDetails[j].CCY))
                        {
                            CCY = dto.BoardRateDetails[j].CCY;
                            dto.CCYList.Add(CCY);
                            dto.ThresholdList.Add(clsMDBus.Instance().GetThresholdByCCY(CCY));
                        }
                    }
                }
            }
            else
            {
                dto = null;
            }

            return dto;
        }

        /// <summary>
        /// Get Currency Holiday by CCY
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDCurrencyHolidayDTO> GetCurrencyHolidayByCCY(string CCY)
        {
            List<clsMDCurrencyHolidayDTO> lst = new List<clsMDCurrencyHolidayDTO>();
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@CCYCode", CCY);
            DataTable dt = m_DAL.ExecuteDataReader(spMD_GetCurrencyHolidayByCCY, CommandType.StoredProcedure, parameters);

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add(new clsMDCurrencyHolidayDTO().GetCurrencyHolidayDto(dt.Rows[i]));
                }
            }
            return lst;
        }

        /// <summary>
        /// Insert Boadrd Rate
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public int InsertBoardRate(clsMDBoardRateDTO dto, clsCOMExternalTransactionLogDTO externalLog)
        {
            int row = 0;
            object identity;
            SqlParameter[] parameters = new SqlParameter[11];
            List<SqlParameter[]> lstParameter = new List<SqlParameter[]>();
            //set parameters
            parameters[0] = new SqlParameter("@Version", dto.Version);
            parameters[1] = new SqlParameter("@Status", dto.Status);
            parameters[2] = new SqlParameter("@FileDirectory", dto.FileDirectory);
            if (dto.ImportTime == null)
            {
                parameters[3] = new SqlParameter("@ImportTime", DBNull.Value);
            }
            else
            {
                parameters[3] = new SqlParameter("@ImportTime", dto.ImportTime);
            }
            parameters[4] = new SqlParameter("@EffectiveTime", dto.EffectiveTime);
            parameters[5] = new SqlParameter("@ImportantNote", dto.ImportantNote);
            parameters[6] = new SqlParameter("@Remark", dto.Remark);
            parameters[7] = new SqlParameter("@ApprovedBy", dto.ApprovedBy);
            parameters[8] = new SqlParameter("@IsActive", dto.IsActive);
            parameters[9] = new SqlParameter("@CreatedBy", dto.CreatedBy);
            if (dto.UpdateDate == null)
            {
                parameters[10] = new SqlParameter("@UpdateDate", DBNull.Value);
            }
            else
            {
                parameters[10] = new SqlParameter("@UpdateDate", dto.UpdateDate);
            }

            //insert with parameters
            row = m_DAL.ExecuteNonQueryWithTransactionOutValue(spMD_InsertBoardRate, CommandType.StoredProcedure, parameters, out identity);
            if (row > 0)
            {
                for (int i = 0; i < dto.BoardRateDetails.Count; i++)
                {
                    parameters = new SqlParameter[14];
                    parameters[0] = new SqlParameter("@BoardRateID", (int)identity);
                    parameters[1] = new SqlParameter("@CCYTermsID", dto.BoardRateDetails[i].CCYTermsID);
                    parameters[2] = new SqlParameter("@CCY", dto.BoardRateDetails[i].CCY);
                    parameters[3] = new SqlParameter("@TransType", dto.BoardRateDetails[i].TransType);
                    parameters[4] = new SqlParameter("@SameDay", dto.BoardRateDetails[i].SameDay);
                    parameters[5] = new SqlParameter("@SameDayValueDate", dto.BoardRateDetails[i].SameDayValueDate);
                    if (dto.BoardRateDetails[i].SameDayMaturityDate == null)
                    {
                        parameters[6] = new SqlParameter("@SameDayMaturityDate", DBNull.Value);
                    }
                    else
                    {
                        parameters[6] = new SqlParameter("@SameDayMaturityDate", dto.BoardRateDetails[i].SameDayMaturityDate);
                    }
                    parameters[7] = new SqlParameter("@Tom", dto.BoardRateDetails[i].Tom);
                    parameters[8] = new SqlParameter("@TomValueDate", dto.BoardRateDetails[i].TomValueDate);
                    if (dto.BoardRateDetails[i].TomMaturityDate == null)
                    {
                        parameters[9] = new SqlParameter("@TomMaturityDate", DBNull.Value);
                    }
                    else
                    {
                        parameters[9] = new SqlParameter("@TomMaturityDate", dto.BoardRateDetails[i].TomMaturityDate);
                    }
                    parameters[10] = new SqlParameter("@Spot", dto.BoardRateDetails[i].Spot);
                    parameters[11] = new SqlParameter("@SpotValueDate", dto.BoardRateDetails[i].SpotValueDate);
                    if (dto.BoardRateDetails[i].SpotMaturityDate == null)
                    {
                        parameters[12] = new SqlParameter("@SpotMaturityDate", DBNull.Value);
                    }
                    else
                    {
                        parameters[12] = new SqlParameter("@SpotMaturityDate", dto.BoardRateDetails[i].SpotMaturityDate);
                    }
                    //TO-DO???
                    parameters[13] = new SqlParameter("@FormatNumber", dto.BoardRateDetails[i].FormatNumber);
                    lstParameter.Add(parameters);
                }
                row = m_DAL.ExecuteNonQueryWithTransaction(spMD_InsertBoardRateDetail, CommandType.StoredProcedure, lstParameter);

                //save import log
                parameters = new SqlParameter[8];
                parameters[0] = new SqlParameter("@module", externalLog.Module);
                parameters[1] = new SqlParameter("@userImport", externalLog.UserNo);// externalTransactionLogObj.UserName);????
                parameters[2] = new SqlParameter("@importDate", externalLog.LogDate);
                parameters[3] = new SqlParameter("@fileName", externalLog.FileName);
                parameters[4] = new SqlParameter("@filePath", externalLog.FilePath);
                parameters[5] = new SqlParameter("@fileType", externalLog.FileType);
                parameters[6] = new SqlParameter("@invalidData", externalLog.InvalidData);
                parameters[7] = new SqlParameter("@errorMessage", externalLog.ErrorMessage);
                int iSaveLog = m_DAL.ExecuteNonQueryWithTransaction("dbo.spCOM_ImportExternalTransactionLog", CommandType.StoredProcedure, parameters);
                if (iSaveLog == 0)
                {
                    RollBack();
                    return iSaveLog;
                }
            }
            return row;
        }


        /// <summary>
        /// Update board rate
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public int UpdateBoardRate(clsMDBoardRateDTO dto)
        {
            int row = 0;
            SqlParameter[] parameters = new SqlParameter[12];
            //set parameters
            parameters[0] = new SqlParameter("@BoardRateID", dto.BoardRateID);
            parameters[1] = new SqlParameter("@Version", dto.Version);
            parameters[2] = new SqlParameter("@Status", dto.Status);
            parameters[3] = new SqlParameter("@FileDirectory", dto.FileDirectory);
            parameters[4] = new SqlParameter("@ImportTime", dto.ImportTime);
            parameters[5] = new SqlParameter("@EffectiveTime", dto.EffectiveTime);
            parameters[6] = new SqlParameter("@ImportantNote", dto.ImportantNote);
            parameters[7] = new SqlParameter("@Remark", dto.Remark);
            parameters[8] = new SqlParameter("@ApprovedBy", dto.ApprovedBy);
            parameters[9] = new SqlParameter("@IsActive", dto.IsActive);
            parameters[10] = new SqlParameter("@CreatedBy", dto.CreatedBy);
            if (dto.UpdateDate == null)
            {
                parameters[11] = new SqlParameter("@UpdateDate", DBNull.Value);
            }
            else
            {
                parameters[11] = new SqlParameter("@UpdateDate", dto.UpdateDate);
            }
            row = m_DAL.ExecuteNonQueryWithTransaction(spMD_UpdateBoardRate, CommandType.StoredProcedure, parameters);
            return row;
        }

        /// <summary>
        /// Get View Board Rate Maker List
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDBoardRateDTO> GetViewBoardRateMakerList()
        {
            List<clsMDBoardRateDTO> lst = new List<clsMDBoardRateDTO>();
            DataTable dtBoardRate = new DataTable();
            dtBoardRate = m_DAL.ExecuteDataReader(spMD_GetViewBoardRateMaker, CommandType.StoredProcedure);
            if (dtBoardRate.Rows.Count > 0)
            {
                for (int i = 0; i < dtBoardRate.Rows.Count; i++)
                {
                    clsMDBoardRateDTO dto = (new clsMDBoardRateDTO()).GetBoardRateMakerDto(dtBoardRate.Rows[i]);
                    if (lst.Count == 0)
                    {
                        dto.IsProcess = true;
                        lst.Insert(0, dto);
                    }
                    else
                    {

                        if ((dto.Status == (int)clsMDCommonValue.BoardRateStatus.Approved
                            && dto.IsActive == true) || dto.Status == (int)clsMDCommonValue.BoardRateStatus.Suspended)
                        {
                            dto.IsProcess = false;
                            lst.Insert(0, dto);
                        }
                    }
                }
            }

            return lst;
        }

        /// <summary>
        /// Get View Board Rate Maker List
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDBoardRateDTO> GetViewBoardRateApproverList()
        {
            List<clsMDBoardRateDTO> lst = new List<clsMDBoardRateDTO>();
            DataTable dtBoardRate = new DataTable();
            dtBoardRate = m_DAL.ExecuteDataReader(spMD_GetViewBoardRateApprover, CommandType.StoredProcedure);
            if (dtBoardRate.Rows.Count > 0)
            {
                for (int i = 0; i < dtBoardRate.Rows.Count; i++)
                {
                    clsMDBoardRateDTO dto = (new clsMDBoardRateDTO()).GetBoardRateApproverDto(dtBoardRate.Rows[i]);
                    if (lst.Count == 0)
                    {
                        lst.Insert(0, dto);
                    }
                    else
                    {
                        if (dto.Status == (int)clsMDCommonValue.BoardRateStatus.Approved
                            && dto.IsActive == true)
                        {
                            lst.Insert(0, dto);
                        }
                    }
                    //lst.Add((new clsMDBoardRateDTO()).GetBoardRateMakerDto(dtBoardRate.Rows[i]));
                }
            }

            return lst;
        }

        /// <summary>
        /// Get Inquiry Board Rate History List
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDBoardRateDTO> GetInquiryBoardRateHistoryList(DateTime? fromDate, DateTime? toDate, int status, bool? isActive)
        {
            List<clsMDBoardRateDTO> lst = new List<clsMDBoardRateDTO>();
            DataTable dt = new DataTable();
            SqlParameter[] parameters = new SqlParameter[4];
            if (fromDate == null)
            {
                parameters[0] = new SqlParameter("@FromDate", DBNull.Value);
            }
            else
            {
                parameters[0] = new SqlParameter("@FromDate", fromDate.Value);
            }
            if (toDate == null)
            {
                parameters[1] = new SqlParameter("@ToDate", DBNull.Value);
            }
            else
            {
                parameters[1] = new SqlParameter("@ToDate", toDate.Value);
            }
            if (status == 0)
            {
                parameters[2] = new SqlParameter("@Status", DBNull.Value);
            }
            else
            {
                parameters[2] = new SqlParameter("@Status", status);
            }
            if (isActive == null)
            {
                parameters[3] = new SqlParameter("@IsActive", DBNull.Value);
            }
            else
            {
                parameters[3] = new SqlParameter("@IsActive", isActive.Value);
            }

            dt = m_DAL.ExecuteDataReader(spMD_GetInquiryBoardRateHistory, CommandType.StoredProcedure, parameters);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add((new clsMDBoardRateDTO()).GetInquiryBoardRateHistoryDto(dt.Rows[i]));
                }
            }

            return lst;
        }

        /// <summary>
        /// Get Currency Inquiry Board Rate History List
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDBoardRateDetailDTO> GetCurrencyInquiryBoardRateHistoryList(DateTime? fromDate, DateTime? toDate, int? termID, bool? isActive, string ccyList)
        {
            List<clsMDBoardRateDetailDTO> lst = new List<clsMDBoardRateDetailDTO>();
            DataTable dt = new DataTable();
            SqlParameter[] parameters = new SqlParameter[5];
            if (fromDate == null)
            {
                parameters[0] = new SqlParameter("@FromDate", DBNull.Value);
            }
            else
            {
                parameters[0] = new SqlParameter("@FromDate", fromDate.Value);
            }
            if (toDate == null)
            {
                parameters[1] = new SqlParameter("@ToDate", DBNull.Value);
            }
            else
            {
                parameters[1] = new SqlParameter("@ToDate", toDate.Value);
            }
            if (termID == null)
            {
                parameters[2] = new SqlParameter("@TermID", DBNull.Value);
            }
            else
            {
                parameters[2] = new SqlParameter("@TermID", termID);
            }
            if (isActive == null)
            {
                parameters[3] = new SqlParameter("@IsActive", DBNull.Value);
            }
            else
            {
                parameters[3] = new SqlParameter("@IsActive", isActive.Value);
            }
            if (String.IsNullOrEmpty(ccyList))
            {
                parameters[4] = new SqlParameter("@CCYList", DBNull.Value);
            }
            else
            {
                parameters[4] = new SqlParameter("@CCYList", ccyList);
            }

            dt = m_DAL.ExecuteDataReader(spMD_GetCurrencyInquiryBoardRateHistory, CommandType.StoredProcedure, parameters);//, parameters);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add((new clsMDBoardRateDetailDTO()).GetCurrencyInquiryBoardRateDetailHistoryDto(dt.Rows[i]));
                }
            }

            return lst;
        }

        /// <summary>
        /// Get Print Preview Inquiry Board Rate List
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDBoardRateDetailDTO> GetPrintPreviewBoardRate(int? boardRateID, ref DateTime? previewDate, out string importantNote)
        {
            List<clsMDBoardRateDetailDTO> lst = new List<clsMDBoardRateDetailDTO>();
            DataTable dt = new DataTable();
            SqlParameter[] parameters = new SqlParameter[2];
            importantNote = string.Empty;

            if (boardRateID == null)
            {
                parameters[0] = new SqlParameter("@BoardRateID", DBNull.Value);
            }
            else
            {
                parameters[0] = new SqlParameter("@BoardRateID", boardRateID.Value);
            }
            if (previewDate == null)
            {
                parameters[1] = new SqlParameter("@ImportDate", DBNull.Value);
            }
            else
            {
                parameters[1] = new SqlParameter("@ImportDate", previewDate.Value);
            }

            dt = m_DAL.ExecuteDataReader(spMD_PrintPreviewBoardRate, CommandType.StoredProcedure, parameters);//, parameters);
            if (dt.Rows.Count > 0)
            {
                importantNote = dt.Rows[0]["ImportantNote"].GetType() == typeof(DBNull) ? string.Empty
                    : dt.Rows[0]["ImportantNote"].ToString();
                previewDate = dt.Rows[0]["ImportTime"].GetType() == typeof(DBNull) ? new Nullable<DateTime>()
                    : (DateTime)dt.Rows[0]["ImportTime"];
                string CCY = string.Empty;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add((new clsMDBoardRateDetailDTO()).GetPrintPreviewBoardRateDetailDto(dt.Rows[i]));
                    if (!CCY.Equals(lst[i].CCY))
                    {
                        CCY = lst[i].CCY;
                        lst[i].CCYForAmount = clsMDBus.Instance().GetThresholdByCCY(CCY);
                    }
                    else
                    {
                        if (i > 0)
                        {
                            lst[i].CCYForAmount = lst[i - 1].CCYForAmount;
                        }
                    }
                }
            }

            return lst;
        }

        /// <summary>
        /// Export Board Rate
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void ExportBoardRate(clsMDBoardRateDTO dto)
        {
            int iRowStart = 13;
            int iColStart = 2;
            int iRowEnd = 27;
            int iColEnd = 7;

            string cellStart = String.Empty;
            string cellEnd = String.Empty;

            if (dto.CCYList.Count > 0)
            {
                clsExcelBase m_ExcelBase = new clsExcelBase(clsMDConstant.EXCEL_TEMPLATE_FILE_BOARD_RATE, clsMDConstant.PROJECT_NAME_MASTERDATA, clsMDBus.Instance().GetServerDate());
                cellStart = clsExcelBase.GetExcelColumnName(iColStart) + iRowStart;
                cellEnd = clsExcelBase.GetExcelColumnName(iColEnd) + iRowEnd;
                Excel.Range source = m_ExcelBase.GetRange(cellStart, cellEnd);

                for (int i = 1; i < dto.CCYList.Count; i++)
                {
                    iColStart += 6;
                    iColEnd += 6;
                    cellStart = clsExcelBase.GetExcelColumnName(iColStart) + iRowStart;
                    cellEnd = clsExcelBase.GetExcelColumnName(iColEnd) + iRowEnd;
                    Excel.Range destination = m_ExcelBase.GetRange(cellStart, cellEnd);
                    source.Copy(destination);
                }
                object[,] data = GetObjectDataExcel(dto);

                iRowStart = 17;
                iColStart = 2;
                iRowEnd = 27;

                cellStart = clsExcelBase.GetExcelColumnName(iColStart) + iRowStart;
                cellEnd = clsExcelBase.GetExcelColumnName(iColEnd) + iRowEnd;
                m_ExcelBase.ExportRangeNoBoder(cellStart, cellEnd, data);

                string importantNote = dto.ImportantNote;
                //process important note 
                clsMDBus.Instance().ProcessImportantNote(ref importantNote, dto.CCYList[0]);
                //insert important note to file excel
                m_ExcelBase.InsertCellObject(30, 1, importantNote);

                m_ExcelBase.SaveFile();
            }
        }

        /// <summary>
        /// Get Object Data for export
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private object[,] GetObjectDataExcel(clsMDBoardRateDTO dto)
        {
            int iBR = 0;
            int countTerm = 10;
            object[,] data = new object[11, dto.CCYList.Count * 6];
            for (int i = 1; i <= countTerm; i++)
            {
                iBR = i - 1;
                int iCol = 0;
                for (int k = 0; k < dto.CCYList.Count; k++)
                {
                    data[0, iCol] = i == 1 ? dto.BoardRateDetails[iBR].SameDayValueDate : data[0, iCol];
                    data[i, iCol++] = dto.BoardRateDetails[iBR].SameDay;
                    data[0, iCol] = i == 1 ? dto.BoardRateDetails[iBR].TomValueDate : data[0, iCol];
                    data[i, iCol++] = dto.BoardRateDetails[iBR].Tom;
                    data[0, iCol] = i == 1 ? dto.BoardRateDetails[iBR].SpotValueDate : data[0, iCol];
                    data[i, iCol++] = dto.BoardRateDetails[iBR].Spot;
                    iBR = iBR + countTerm;

                    data[0, iCol] = i == 1 ? dto.BoardRateDetails[iBR].SameDayValueDate : data[0, iCol];
                    data[i, iCol++] = dto.BoardRateDetails[iBR].SameDay;
                    data[0, iCol] = i == 1 ? dto.BoardRateDetails[iBR].TomValueDate : data[0, iCol];
                    data[i, iCol++] = dto.BoardRateDetails[iBR].Tom;
                    data[0, iCol] = i == 1 ? dto.BoardRateDetails[iBR].SpotValueDate : data[0, iCol];
                    data[i, iCol++] = dto.BoardRateDetails[iBR].Spot;
                    iBR = iBR + countTerm;
                }
            }

            return data;
        }

        /// <summary>
        /// Get Important Note by Parameter
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public DataTable GetImportantNoteByParameters(string period, string rCCY, string cCCY)
        {
            SqlParameter[] parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("@Period", period);
            parameters[1] = new SqlParameter("@rCCY", rCCY);
            parameters[2] = new SqlParameter("@cCCY", cCCY);

            DataTable dt = m_DAL.ExecuteDataReader(spMD_GetImportantNoteByParameters, CommandType.StoredProcedure, parameters);

            return dt;
        }

        /// <summary>
        /// Get Cut off time List
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDCutoffTimeDTO> GetCutoffTimeList()
        {
            List<clsMDCutoffTimeDTO> lst = new List<clsMDCutoffTimeDTO>();
            DataTable dt = new DataTable();
            dt = m_DAL.ExecuteDataReader(spMD_GetAllCCYCutOFFTime, CommandType.StoredProcedure);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add((new clsMDCutoffTimeDTO()).GetCutoffTimeDto(dt.Rows[i]));
                }
            }

            return lst;
        }

        /// <summary>
        /// Get Ordinary Deposit IS Rate List
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDOrdinaryDepositISRateDTO> GetOrdinaryDepositISRateList()
        {
            List<clsMDOrdinaryDepositISRateDTO> lst = new List<clsMDOrdinaryDepositISRateDTO>();
            DataTable dt = new DataTable();
            dt = m_DAL.ExecuteDataReader(spMD_GetAllOrdinaryDepositISRate, CommandType.StoredProcedure);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add((new clsMDOrdinaryDepositISRateDTO()).GetOrdinaryDepositISRateDto(dt.Rows[i]));
                }
            }

            return lst;
        }
    }
}
