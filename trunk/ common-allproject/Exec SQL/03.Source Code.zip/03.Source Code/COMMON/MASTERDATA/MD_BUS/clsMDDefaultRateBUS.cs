﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-08-31 11:46:30 +0700 (Saturday, 31 August 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define access data for default rate
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using Config.Classes;
using Phoenix.Common.MasterData.Dal;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Bus
{
	public class clsMDDefaultRateBUS
	{

		/// <summary>
		/// used to process data from database
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		private clsDataAccessLayer m_DAL = null;
		public clsDataAccessLayer DAL
		{
			get
			{
				return m_DAL;
			}
		}
	
		/// <summary>
		/// Contructor
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
        public clsMDDefaultRateBUS()
		{
			m_DAL = new clsDataAccessLayer();
		}

		/// <summary>
        /// Instance of clsMDDeafultRateBUS Object
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
        private static clsMDDefaultRateBUS instance;
        public static clsMDDefaultRateBUS Instance()
		{
			if (instance == null)
			{
                instance = new clsMDDefaultRateBUS();
			}
			return instance;
		}
		
		/// <summary>
		/// commit transaction
		/// </summary>
		/// @cond
        /// Author: Phuong Lap Co
		/// @endcond
		public void Commit()
		{
			m_DAL.m_transaction.Commit();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

		/// <summary>
		/// rollback transaction
		/// </summary>
		/// @cond
        /// Author: Phuong Lap Co
		/// @endcond
		public void RollBack()
		{
			m_DAL.m_transaction.Rollback();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

        /// <summary>
        /// Insert Default Rate
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public int InsertDefaultRate(clsAddModifyDefaultRateDTO dto, bool mode)
        {
            int rowCount = 0;
            List<SqlParameter[]> lstParameter = new List<SqlParameter[]>();

            //Clear All Of Default Rate
            ClearAllCCYForAddModifyDefaultRate(mode, dto.InputDateFrom.ToString(clsMDConstant.MD_FORMAT_YYYY_MM_DD), dto.InputDateTo.ToString(clsMDConstant.MD_FORMAT_YYYY_MM_DD));
            //Insert Default Rate
            foreach (clsAddModifyDefaultRateOnGridDTO objDefaultRateInfo in dto.LstAddModifyDefaultRateOnGridDTO)
            {
                SqlParameter[] parameters = new SqlParameter[6];
                //Input Date From
                parameters[0] = new SqlParameter("@inputDateFrom", dto.InputDateFrom);
                //Input Date To
                parameters[1] = new SqlParameter("@inputDateTo", dto.InputDateTo);

                //CCY
                parameters[2] = new SqlParameter("@ccy", objDefaultRateInfo.CCY);
                //Rate
                parameters[3] = new SqlParameter("@rate", objDefaultRateInfo.Rate);
                //Created By: User login 
                parameters[4] = new SqlParameter("@createdBy", dto.CreatedBy);

                //The number of effected rows
                object outParamName = "@rowCount";
                parameters[5] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
                parameters[5].Direction = ParameterDirection.Output;

                lstParameter.Add(parameters);
            }
            rowCount = m_DAL.ExecuteNonQueryWithTransaction("dbo.spMD_InsertDefaultRate", CommandType.StoredProcedure, lstParameter);

            return rowCount;
        }

        /// <summary>
        /// Clear All Of Default Rate
        /// </summary>
        /// <param name="yearMonth"></param>
        /// <returns></returns>   
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public int ClearAllCCYForAddModifyDefaultRate(bool mode, string inputDateFrom, string inpurtDateTo)
        {
            int rowCount = 0;

            SqlParameter[] parameter = new SqlParameter[4];

            //Mode
            parameter[0] = new SqlParameter("@mode", mode);
            //Input Date From
            parameter[1] = new SqlParameter("@inputDateFrom", inputDateFrom);
            //Input Date To
            parameter[2] = new SqlParameter("@inputDateTo", inpurtDateTo);
            //The Number Of Effected Row
            object outParamName = "@rowCount";
            parameter[3] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
            parameter[3].Direction = ParameterDirection.Output;

            rowCount = m_DAL.ExecuteNonQueryWithTransaction("dbo.spMD_ClearDefaultRateByInputDate", CommandType.StoredProcedure, parameter);

            return rowCount;
        }

        /// <summary>
        /// Get List CCY For Add/Modify Default Rate
        /// </summary>
        /// <param name="objNonResidentAppInfo"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond  
        public void spMD_GetDefaultRateForAddModify(ref clsAddModifyDefaultRateDTO dto)
        {
            //Exec
            m_DAL.SetCommand("dbo.spMD_GetDefaultRateForAddModify", CommandType.StoredProcedure);
            //Parameters            
            //+ Input Date From
            if (dto.InputDateFrom.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@inputDateFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@inputDateFrom", dto.InputDateFrom);
            }
            //+ Input Date To
            if (dto.InputDateTo.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@inputDateTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@inputDateTo", dto.InputDateTo);
            } 
            
            SqlDataReader reader = m_DAL.ExecuteDataReader();
            //Set Default Value For InputDate Date As System Date In case Data Empty
            dto.InputDateFrom = clsMDBus.Instance().GetServerDateTime();
            dto.InputDateTo = dto.InputDateFrom.AddDays(1);
            if (reader != null)
            {
                //Load Data
                while (reader.Read())
                {
                    //+ From Date
                    dto.InputDateFrom = DateTime.Parse(reader["ToDate"] == DBNull.Value ? dto.InputDateFrom.ToString() : DateTime.Parse(reader["ToDate"].ToString()).AddDays(1).ToString());
                    //+ To Date
                    dto.InputDateTo = dto.InputDateFrom.AddDays(1);
                    //+ isLatestDefaultRate
                    dto.IsLatestDefaultRate = bool.Parse(reader["isLatestDefaultRate"].ToString());
                    //+ isEmptyDefaultRate
                    dto.IsEmptyDefaultRate = bool.Parse(reader["isEmptyDefaultRate"].ToString());
                    //For Grid Of CCY
                    clsAddModifyDefaultRateOnGridDTO objDefaultRateInfo = new clsAddModifyDefaultRateOnGridDTO();                    
                    //+ CCY
                    objDefaultRateInfo.CCY = reader["CCY"].ToString();
                    //+ Rate
                    objDefaultRateInfo.Rate = decimal.Parse(reader["Rate"] == DBNull.Value ? "0" : reader["Rate"].ToString());                    

                    //- Used to regconize "Update" OR "Create New"
                    //+ String.Empty: Create New
                    //+ Different from [String.Empty] AND different itself: Update
                    objDefaultRateInfo.OldDefaultRate = reader["Rate"] == DBNull.Value ? String.Empty : reader["Rate"].ToString();

                    dto.LstAddModifyDefaultRateOnGridDTO.Add(objDefaultRateInfo);
                }
            }
            reader.Close();           
        }

        /// <summary>
        /// Get List Exchange Rate For Reporting
        /// </summary>
        /// <param name="objNonResidentAppInfo"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond  
        public void GetDefaultRateForList(ref clsListDefaultRateDTO dto)
        {
            //Exec
            m_DAL.SetCommand("dbo.spMD_GetDefaultRateForList", CommandType.StoredProcedure);
            //Parameters
            //+ Input Date From
            if (dto.InputDateFrom.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@inputDateFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@inputDateFrom", dto.InputDateFrom);
            }            
            //+ Input Date To
            if (dto.InputDateTo.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@inputDateTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@inputDateTo", dto.InputDateTo);
            }            
            //+ CCY
            if (dto.CCY.EndsWith(String.Empty))
            {
                m_DAL.AddParameter("@ccy", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@ccy", dto.CCY);
            }            
            //+ Rate From
            if (dto.RateFrom.Equals(String.Empty))
            {
                m_DAL.AddParameter("@rateFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@rateFrom", decimal.Parse(dto.RateFrom));   
            }            
            //+ Rate To
            if (dto.RateTo.Equals(String.Empty))
            {
                m_DAL.AddParameter("@rateTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@rateTo", decimal.Parse(dto.RateTo));
            }
            
            SqlDataReader reader = m_DAL.ExecuteDataReader();
            if (reader != null)
            {
                //Load Data
                while (reader.Read())
                {
                    clsListDefaultRateOnGridDTO objDefaultRateInfo = new clsListDefaultRateOnGridDTO();
                    //+ Input Date From
                    objDefaultRateInfo.InputDateFrom = DateTime.Parse(reader["FromDate"] == DBNull.Value ? DateTime.MinValue.ToString() : reader["FromDate"].ToString());
                    //+ Input Date To
                    objDefaultRateInfo.InputDateTo = DateTime.Parse(reader["ToDate"] == DBNull.Value ? DateTime.MinValue.ToString() : reader["ToDate"].ToString());
                    //+ CCY
                    objDefaultRateInfo.CCY = reader["CCY"].ToString();
                    //+ Rate
                    objDefaultRateInfo.Rate = decimal.Parse(reader["Rate"] == DBNull.Value ? "0" : reader["Rate"].ToString());
                    //Add Item to List
                    dto.LstDefaultRateOnGridDTO.Add(objDefaultRateInfo);
                }
            }
            reader.Close();
        }

        /// <summary>
        /// Get From Date, To Date List
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsListDefaultRateOnGridDTO> GetFromToDateList()
        {
            List<clsListDefaultRateOnGridDTO> lst = new List<clsListDefaultRateOnGridDTO>();
            DataTable dt = new DataTable();
            dt = m_DAL.ExecuteDataReader("spMD_GetFromToDefaultRateList", CommandType.StoredProcedure);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add(new clsListDefaultRateOnGridDTO().GetDefaultRateOnCombobox(dt.Rows[i]));
                }
            }

            return lst;
        }
	}
}