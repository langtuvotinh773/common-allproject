﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define access data for threshold
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using Config.Classes;
using Phoenix.Common.MasterData.Dal;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Dto;

namespace Phoenix.Common.MasterData.Bus
{
	public class clsMDThresholdBUS
	{

		/// <summary>
		/// used to process data from database
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsDataAccessLayer m_DAL = null;
		public clsDataAccessLayer DAL
		{
			get
			{
				return m_DAL;
			}
		}
	
		/// <summary>
		/// Contructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsMDThresholdBUS()
		{
			m_DAL = new clsDataAccessLayer();
		}

		/// <summary>
		/// Instance of clsMDThresholdBus Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private static clsMDThresholdBUS instance;
		public static clsMDThresholdBUS Instance()
		{
			if (instance == null)
			{
				instance = new clsMDThresholdBUS();
			}
			return instance;
		}
		
		/// <summary>
		/// commit transaction
		/// </summary>
		/// @cond
		/// Author: phuong lap co
		/// @endcond
		public void Commit()
		{
			m_DAL.m_transaction.Commit();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

		/// <summary>
		/// rollback transaction
		/// </summary>
		/// @cond
		/// Author: phuong lap co
		/// @endcond
		public void RollBack()
		{
			m_DAL.m_transaction.Rollback();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}
		 
		/// <summary>
		/// Get threshold list
		/// </summary>
		/// <param name="strCCYCode">CCY Code</param>
		/// <param name="iTransactionType">Transaction Type</param>
		/// <param name="dtUpdateDate">Update Date</param>
		/// <param name="strUpdateBy">Update By</param>
		/// <returns>Threshold datatable</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetThresholdList(string strCCYCode, int iTransactionType, DateTime? dtUpdateDate,string strUpdateBy)
		{
			SqlParameter[] parameters = new SqlParameter[4];
			parameters[0] = new SqlParameter("@ccyCode", strCCYCode); 
			parameters[1] = new SqlParameter("@transType", iTransactionType);
			if (dtUpdateDate == null)
			{
				parameters[2] = new SqlParameter("@updateDate", DBNull.Value);
			}
			else
			{
				parameters[2] = new SqlParameter("@updateDate", dtUpdateDate);
			}
			
			parameters[3] = new SqlParameter("@updateBy", strUpdateBy);
			return m_DAL.ExecuteDataReader("dbo.spMD_GetThresholdList", CommandType.StoredProcedure,parameters);
		}

		/// <summary>
		/// Check a threshold is exist or not
		/// </summary>
		/// <param name="strCCYCode">CCY Code</param>
		/// <param name="iTransactionType">Transaction Type</param>
		/// <returns>Threshold ID</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable CheckExistThreshold(string strCCYCode, int iTransactionType)
		{
			SqlParameter[] parameters = new SqlParameter[2];
			parameters[0] = new SqlParameter("@ccyCode", strCCYCode);
			parameters[1] = new SqlParameter("@transType", iTransactionType);
			return	m_DAL.ExecuteDataReader("dbo.spMD_CheckExistThreshold", CommandType.StoredProcedure, parameters);			
		}

		/// <summary>
		/// Override a threshold
		/// </summary>
		/// <param name="iThresholdID">Threshold ID</param>
		/// <param name="strThreshold">Threshold value</param>
		/// <returns>Number of overrided threshold</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int OverideThreshold( int iThresholdID, string strThreshold)
		{
			SqlParameter[] parameters = new SqlParameter[3];
			parameters[0] = new SqlParameter("@thresholdId", iThresholdID);
			parameters[1] = new SqlParameter("@threshold", strThreshold);
			parameters[2] = new SqlParameter("@updateBy", clsUserInfo.UserNo);
			int i = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_OverideThreshold", CommandType.StoredProcedure, parameters);
			return i;
		}
		
		/// <summary>
		/// Update Threshold
		/// </summary>
		/// <param name="iThresholdID">Threshold ID</param>
		/// <param name="strCCYCode">CCY Code</param>
		/// <param name="iTransactionType">Transaction Type</param>
		/// <param name="strThreshold">Threshold</param>
		/// <returns>Number of rows updated</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int UpdateThreshold(int iThresholdID, string strCCYCode, int iTransactionType,string strThreshold)
		{
			SqlParameter[] parameters = new SqlParameter[5];
			parameters[0] = new SqlParameter("@thresholdId", iThresholdID);
			parameters[1] = new SqlParameter("@ccyCode", strCCYCode);
			parameters[2] = new SqlParameter("@transactionType", iTransactionType);
			parameters[3] = new SqlParameter("@threshold", strThreshold);
			parameters[4] = new SqlParameter("@updateBy", clsUserInfo.UserNo);
			int i = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_UpdateThreshold", CommandType.StoredProcedure, parameters);
			return i;
		}
	
		/// <summary>
		/// Create threshold
		/// </summary>
		/// <param name="strCCYCode">CCY Code</param>
		/// <param name="iTransactionType">Transaction Type</param>
		/// <param name="strThreshold">Threshold ID</param>
		/// <returns>Number of threshold created</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int CreateThreshold(string strCCYCode,int iTransactionType, string strThreshold)
		{ 
			SqlParameter[] parameters = new SqlParameter[4];
			parameters[0] = new SqlParameter("@ccyCode", strCCYCode);
			parameters[1] = new SqlParameter("@transType", iTransactionType);
			parameters[2] = new SqlParameter("@threshold", strThreshold);
			parameters[3] = new SqlParameter("@user", clsUserInfo.UserNo);
            int ThresholdID = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_CreateThreshold", CommandType.StoredProcedure, parameters);
            //if (dtbThresholdID.Rows.Count > 0)
            //    return int.Parse(dtbThresholdID.Rows[0][0].ToString());
            return ThresholdID;
		}

		/// <summary>
		/// Delete threshold
		/// </summary>
		/// <param name="iThresholdID">Threshold ID</param>
		/// <returns>Number of deleted threshold</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int DeleteThreshold(int iThresholdID)
		{
			int row = 0;
			List<SqlParameter[]> lstParams = new List<SqlParameter[]>();
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@thresholdID", iThresholdID);
			lstParams.Add(parameters);
			row = m_DAL.ExecuteNonQueryDeleteWithTransaction("dbo.spMD_DeleteThreshold", CommandType.StoredProcedure, lstParams);
			return row;
		}


        /// <summary>
        /// Get Threshold by CCY
        /// </summary>
        /// <param name="strCCYCode"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public List<clsMDThresholdDTO> GetThresholdByCCY(string strCCYCode)
        {
            List<clsMDThresholdDTO> lst = new   List<clsMDThresholdDTO>();
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@CCYCode", strCCYCode);            

            DataTable dt = m_DAL.ExecuteDataReader("dbo.spMD_GetCurrencyThresholdByCCY", CommandType.StoredProcedure, parameters);

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add(new clsMDThresholdDTO().GetBoardRateDetailDto(dt.Rows[i]));
                }
            }

            return lst;
        }
	}
}