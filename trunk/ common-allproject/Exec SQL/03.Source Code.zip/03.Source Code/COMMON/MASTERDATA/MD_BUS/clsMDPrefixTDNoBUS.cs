﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Com;
using Config.Classes;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDPrefixTDNoBUS
    {
        clsDataAccessLayer m_DAL = null;
        #region Properties
        public clsDataAccessLayer DAL
        {
            get
            {
                return m_DAL;
            }
        }
        #endregion
        private static clsMDPrefixTDNoBUS instance;
        public static clsMDPrefixTDNoBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDPrefixTDNoBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsMDPrefixTDNoBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsDataAccessLayer();
            }
        }

        /// <summary>
        /// commit transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// Get PrefixTDNo List
        /// </summary>
        /// <param name="CCY"></param>
        /// <param name="transType"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDPrefixTDNoDTO> GetPrefixTDNoList(string CCY, string value, DateTime? updateDate)
        {
            List<clsMDPrefixTDNoDTO> lst = new List<clsMDPrefixTDNoDTO>();
            DataTable dt = new DataTable();
            SqlParameter[] parameters = new SqlParameter[3];
            if (clsMDFunction.isNullOrEmpty(CCY))
            {
                parameters[0] = new SqlParameter("@CCY", DBNull.Value);
            }
            else
            {
                parameters[0] = new SqlParameter("@CCY", CCY);
            }

            if (clsMDFunction.isNullOrEmpty(value))
            {
                parameters[1] = new SqlParameter("@Value", DBNull.Value);
            }
            else
            {
                parameters[1] = new SqlParameter("@Value", value);
            }

            if (updateDate == null)
            {
                parameters[2] = new SqlParameter("@UpdateDate", DBNull.Value);
            }
            else
            {
                parameters[2] = new SqlParameter("@UpdateDate", updateDate.Value);
            }

            dt = m_DAL.ExecuteDataReader("spMD_GetPrefixTDNoList", CommandType.StoredProcedure, parameters);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add(new clsMDPrefixTDNoDTO().GetPrefixTDNoDTO(dt.Rows[i]));
                }
            }
            return lst;
        }

        /// <summary>
        /// Get PrefixTDNo
        /// </summary>
        /// <param name="CCY"></param>
        /// <param name="transType"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsMDPrefixTDNoDTO GetPrefixTDNo(short id)
        {
            clsMDPrefixTDNoDTO dto = new clsMDPrefixTDNoDTO();
            DataTable dt = new DataTable();
            SqlParameter[] parameters = new SqlParameter[1];

            parameters[0] = new SqlParameter("@PrefixTDNo", id);

            dt = m_DAL.ExecuteDataReader("spMD_GetPrefixTDNo", CommandType.StoredProcedure, parameters);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dto = new clsMDPrefixTDNoDTO().GetPrefixTDNoDTOToUpdate(dt.Rows[i]);
                }
            }
            else
            {
                dto = null;
            }
            return dto;
        }

        /// <summary>
        /// Insert PrefixTDNo
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public int InsertPrefixTDNo(clsMDPrefixTDNoDTO dto)
        {
            int row = 0;
            object identity;
            SqlParameter[] parameters = new SqlParameter[4];
            List<SqlParameter[]> lstParameter = new List<SqlParameter[]>();
            //set parameters
            parameters[0] = new SqlParameter("@CCY", dto.CCY);
            parameters[1] = new SqlParameter("@Value", dto.Value);
            parameters[2] = new SqlParameter("@Remark", dto.Remark);
            parameters[3] = new SqlParameter("@CreatedBy", clsUserInfo.UserNo);            

            row = m_DAL.ExecuteNonQueryWithTransactionOutValue("spMD_InsertPrefixTDNo", CommandType.StoredProcedure, parameters, out identity);
            if (row > 0)
            {
                dto.PrefixTDNo = Convert.ToInt16(identity);
            }
            return row;
        }

        /// <summary>
        /// Update PrefixTDNo
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public int UpdatePrefixTDNo(clsMDPrefixTDNoDTO dto)
        {
            int row = 0;
            object identity;
            SqlParameter[] parameters = new SqlParameter[5];
            List<SqlParameter[]> lstParameter = new List<SqlParameter[]>();
            //set parameters
            parameters[0] = new SqlParameter("@PrefixTDNo", dto.PrefixTDNo);
            parameters[1] = new SqlParameter("@CCY", dto.CCY);
            parameters[2] = new SqlParameter("@Value", dto.Value);
            parameters[3] = new SqlParameter("@Remark", dto.Remark);
            parameters[4] = new SqlParameter("@UpdatedBy", clsUserInfo.UserNo);

            row = m_DAL.ExecuteNonQueryWithTransactionOutValue("spMD_UpdatePrefixTDNo", CommandType.StoredProcedure, parameters, out identity);

            return row;
        }

        /// <summary>
        /// Check exist CCY in prefix TD No
        /// </summary>
        /// <param name="CCY"></param>
        /// <returns></returns>
                /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public bool IsExistCCYPrefixTDNo(string CCY)
        {
            DataTable dt = new DataTable();
            SqlParameter[] parameters = new SqlParameter[1];

            parameters[0] = new SqlParameter("@CCY", CCY);

            dt = m_DAL.ExecuteDataReader("spMD_CheckExistCCYInPrefixTDNo", CommandType.StoredProcedure, parameters);
            if (dt.Rows.Count > 0)
            {
                return true;   
            }
            return false;
        }
    }
}
