﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to access data for ceiling/ floor
 * of Master Data module.
 */
using System.Collections.Generic;
using System.Data;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;
using System.Data.SqlClient;
using Config.Classes;
namespace Phoenix.Common.MasterData.Bus
{
	public class clsMDCeilingFloorBUS
	{
		/// <summary>
		/// used to process data from database
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsDataAccessLayer m_DAL = null;

		#region Properties
		public clsDataAccessLayer DAL
		{
			get
			{
				return m_DAL;
			}
		}
		#endregion
		/// <summary>
		/// Contructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsMDCeilingFloorBUS()
		{
			m_DAL = new clsDataAccessLayer();
		}

		/// <summary>
		/// Get instance of clsMDCeilingFloorBus Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private static clsMDCeilingFloorBUS instance;
		public static clsMDCeilingFloorBUS Instance()
		{
			if (instance == null)
			{
				instance = new clsMDCeilingFloorBUS();
			}
			return instance;
		}
		/// <summary>
		/// commit transaction
		/// </summary>
		/// @cond
		/// Author: phuong lap co
		/// @endcond
		public void Commit()
		{
			m_DAL.m_transaction.Commit();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

		/// <summary>
		/// rollback transaction
		/// </summary>
		/// @cond
		/// Author: phuong lap co
		/// @endcond
		public void RollBack()
		{
			m_DAL.m_transaction.Rollback();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

		/// <summary>
		/// Get ceiling/floor list
		/// </summary>
		/// <returns>Ceiling / Floor datatable</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetCeilingFloorList()
		{
			return m_DAL.ExecuteDataReader("dbo.spMD_GetCeilingFloorList", CommandType.StoredProcedure);
		}

		/// <summary>
		/// Delete ceiling/floor
		/// </summary>
		/// <param name="iCeilingFloorID">Ceiling Floor ID to be deleted</param>
		/// <returns>Number of rows deleted</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int DeleteCeilingFloor(int iCeilingFloorID)
		{
			int row = 0;
			List<SqlParameter[]> lstParams = new List<SqlParameter[]>();
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@ceilingFloorID", iCeilingFloorID);
			lstParams.Add(parameters);
			row = m_DAL.ExecuteNonQueryDeleteWithTransaction("dbo.spMD_DeleteCeilingFloor", CommandType.StoredProcedure, lstParams);
			return row;
		}

		/// <summary>
		/// Get currency pair list
		/// </summary>
		/// <returns>List of currency pair</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public List<CbbObject> GetCurencyPairList()
		{
			List<CbbObject> currencyPairList = new List<CbbObject>();
			DataTable dtbCurrencyList = m_DAL.ExecuteDataReader("dbo.spMD_GetCurencyPairList", CommandType.StoredProcedure);
			currencyPairList.Insert(0, new CbbObject("", ""));
			for (int i = 0; i < dtbCurrencyList.Rows.Count; i++)
				currencyPairList.Insert(i + 1, new CbbObject(dtbCurrencyList.Rows[i]["ExchangeCCYPairID"].ToString(), dtbCurrencyList.Rows[i]["ExchangeCCYPair"].ToString()));
			return currencyPairList;
		}

		/// <summary>
		/// Get currency pair list without empty item
		/// </summary>
		/// <returns>List of currency pair without empty item</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public List<CbbObject> GetCurencyPairListWithoutEmptyItem()
		{
			List<CbbObject> currencyPairList = new List<CbbObject>();
			DataTable dtbCurrencyList = m_DAL.ExecuteDataReader("dbo.spMD_GetCurencyPairList", CommandType.StoredProcedure);
			for (int i = 0; i < dtbCurrencyList.Rows.Count; i++)
				currencyPairList.Insert(i, new CbbObject(dtbCurrencyList.Rows[i]["ExchangeCCYPairID"].ToString(), dtbCurrencyList.Rows[i]["ExchangeCCYPair"].ToString()));
			return currencyPairList;
		}

		/// <summary>
		/// Get currency list without empty item
		/// </summary>
		/// <returns>List of currency without empty item</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public List<CbbObject> GetCurencyListWithoutEmptyItem()
		{
			List<CbbObject> currencyPairList = new List<CbbObject>();
			DataTable dtbCurrencyList = m_DAL.ExecuteDataReader("dbo.spMD_GetCurencyList", CommandType.StoredProcedure);
			for (int i = 0; i < dtbCurrencyList.Rows.Count; i++)
				currencyPairList.Insert(i + 0, new CbbObject(dtbCurrencyList.Rows[i]["CCYCode"].ToString(), dtbCurrencyList.Rows[i]["CurrencyName"].ToString()));
			return currencyPairList;
		}

		/// <summary>
		/// Get currency list
		/// </summary>
		/// <returns>List of currency</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public List<CbbObject> GetCurencyList()
		{
			List<CbbObject> currencyList = new List<CbbObject>();
			DataTable dtbCurrencyList = m_DAL.ExecuteDataReader("dbo.spMD_GetCurencyList", CommandType.StoredProcedure);
			currencyList.Insert(0, new CbbObject("", ""));
			for (int i = 0; i < dtbCurrencyList.Rows.Count; i++)
				currencyList.Insert(i + 1, new CbbObject(dtbCurrencyList.Rows[i]["CCYCode"].ToString(), dtbCurrencyList.Rows[i]["CCYCode"].ToString()));
			return currencyList;
		}

		/// <summary>
		/// Check if ceiling/ floor is exist or not
		/// </summary>
		/// <param name="iExchangeCCYPairID">Exchange CCY Pair ID to check</param>
		/// <returns>Number of Exchane CCY Pair ID</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int CheckExistCeilingFloor(int iExchangeCCYPairID)
		{
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@exchangeCCYPairID", iExchangeCCYPairID);
			return m_DAL.ExecuteDataReader("dbo.spMD_CheckExistCeilingFloor", CommandType.StoredProcedure, parameters).Rows.Count;
		}

		/// <summary>
		/// Update Ceiling/Floor
		/// </summary>
		/// <param name="iCeilingFloorID">Ceiling floor ID to update</param>
		/// <param name="iExchangeCCYPairID">Exchange CCY Pair ID</param>
		/// <param name="strCeiling">Ceiling</param>
		/// <param name="strFloor">Fllor</param>
		/// <returns>Number of ceiling/floor updated</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int UpdateCeilingFloor(int iCeilingFloorID, int iExchangeCCYPairID, string strCeiling, string strFloor)
		{
			SqlParameter[] parameters = new SqlParameter[4];
			parameters[0] = new SqlParameter("@ceilingFloorID", iCeilingFloorID);
			parameters[1] = new SqlParameter("@exchangeCCYPairID", iExchangeCCYPairID);
			parameters[2] = new SqlParameter("@ceiling", strCeiling);
			parameters[3] = new SqlParameter("@floor", strFloor);
			return m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_UpdateCeilingFloor", CommandType.StoredProcedure, parameters);
		}

		/// <summary>
		/// Overrid a ceiling/floor
		/// </summary>
		/// <param name="iExchangeCCYPairID">Exchange CCY Pair ID to overide</param>
		/// <param name="strCeiling">Ceiling</param>
		/// <param name="strFloor">Floor</param>
		/// <returns>Number of row to overide</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int OverideCeilingFloor(int iExchangeCCYPairID, string strCeiling, string strFloor)
		{
			SqlParameter[] parameters = new SqlParameter[3];
			parameters[0] = new SqlParameter("@exchangeCCYPairID", iExchangeCCYPairID);
			parameters[1] = new SqlParameter("@ceiling", strCeiling);
			parameters[2] = new SqlParameter("@floor", strFloor);
			return m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_OverrideCeilingFloor", CommandType.StoredProcedure, parameters);
		}

		/// <summary>
		/// Create ceiling/floor
		/// </summary>
		/// <param name="iExchangeCCYPairID">Exchange Ceiling/Floor ID</param>
		/// <param name="strCeiling">Ceiling</param>
		/// <param name="strFloor">Floor</param>
		/// <returns>Number of ceiling/floor created</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int CreateCeilingFloor(int iExchangeCCYPairID, string strCeiling, string strFloor)
		{
			SqlParameter[] parameters = new SqlParameter[4];
			parameters[0] = new SqlParameter("@exchangeCCYPairID", iExchangeCCYPairID);
			parameters[1] = new SqlParameter("@ceiling", strCeiling);
			parameters[2] = new SqlParameter("@floor", strFloor);
			parameters[3] = new SqlParameter("@user", clsUserInfo.UserNo);
            int CeilingFloorID = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_CreateCeilingFloor", CommandType.StoredProcedure, parameters);
            //if (dtbMaxCeilingFloorID.Rows.Count > 0)
            //    return int.Parse(dtbMaxCeilingFloorID.Rows[0][0].ToString());
            return CeilingFloorID;
		}
	}
}