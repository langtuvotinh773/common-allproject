﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-15 (Fri, 15 March 2013) $
 * ========================================================
 * This class is used to implement business logic for user
 * Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDUserBUS
    {
        clsMDUserDAL m_DAL = null;

        private static clsMDUserBUS instance;
        public static clsMDUserBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDUserBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDUserBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsMDUserDAL();
            }
        }        

        #region Functions for Team List, Create/Modify Team       

        /// <summary>
        /// Get list of all users based on input params
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUserList(clsMDUserDTO obj)
        {
            return m_DAL.GetUserList(obj);
        }

        /// <summary>
        /// Get information of user by UserNo
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <returns></returns>
        public clsMDUserDTO GetUser(int iUserNo)
        {
            return m_DAL.GetUser(iUserNo);
        }

        /// <summary>
        /// Get list of all user for ComboBox User in Assign Users To Dept screen
        /// not DelFlag = 1
        /// Return DataTable(UserNo, FullName)
        /// </summary>
        /// <param name="obj"></param>
        /// <returns>DataTable(UserNo, FullName)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUserList()
        {
            return m_DAL.GetAllUserList();
        }
        
        /// <summary>
        /// Delete User
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int DeleteUser(int iUserNo, clsMDLogBase logBase)
        {
            try
            {
                //delete logic user
                int iRow = m_DAL.DeleteUser(iUserNo);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.WirteLog(m_DAL);                                 
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Insert user
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertUser(clsMDUserDTO obj, string listSelectedAssignDept, clsMDLogBase logBase)
        {
            try
            {
                //create user
                int iRow = m_DAL.InsertUser(obj, listSelectedAssignDept);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.Key = obj.UserName + " " + obj.UserNo;//Key: [UserName UserNo]
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Update user
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int UpdateUser(clsMDUserDTO obj, string listSelectedAssignDept, clsMDLogBase logBase)
        { 
            try
            {
                //create user
                int iRow = m_DAL.UpdateUser(obj, listSelectedAssignDept);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.Key = obj.UserName + " " + obj.UserNo;//Key: [UserName UserNo]
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Check duplicate UserName
        /// </summary>
        /// <param name="newUser"></param>
        /// <param name="userNo"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public Dictionary<string, int> ValidationDuplicateUser(int newUser, int userNo, string userName)
        {
            return m_DAL.ValidationDuplicateUser(newUser, userNo, userName);
        }

        /// <summary>
        /// User change password login
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <param name="strNewPassword"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int ChangePassword(int iUserNo, string strNewPassword, clsMDLogBase logBase)
        {
            try
            {
                //update password
                int iRow = m_DAL.ChangePassword(iUserNo, strNewPassword);
                //update successfull
                if (iRow > 0)
                {
                    //system will save log                     
					logBase.WirteLog(m_DAL);                           
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        ///// <summary>
        ///// Get list password history based on number of changing password param
        ///// </summary>
        ///// <param name="iUserNo"></param>
        ///// <returns></returns>
        ///// @cond
        ///// Author: vlhcnhung
        ///// @endcond
        //public DataTable GetPasswordHistory(int iUserNo)
        //{
        //    return m_DAL.GetPasswordHistory(iUserNo);
        //}

        ///// <summary>
        ///// Get Latest date changing password
        ///// </summary>
        ///// <param name="iUserNo"></param>
        ///// <param name="strPass"></param>
        ///// <returns></returns>
        ///// @cond
        ///// Author: vlhcnhung
        ///// @endcond
        //public DateTime GetLastestDateChangingPassword(int iUserNo)
        //{
        //    return m_DAL.GetLastestDateChangingPassword(iUserNo);
        //}

        ///// <summary>
        ///// Count Date Changing Password
        ///// </summary>
        ///// <param name="iUserNo"></param>
        ///// <returns></returns>
        ///// @cond
        ///// Author: vlhcnhung
        ///// @endcond
        //public int CountDateChangingPassword(int iUserNo)
        //{
        //    return m_DAL.CountDateChangingPassword(iUserNo);
        //}
        #endregion

        #region Functions for Assign Users To Department

        /// <summary>
        /// Get list of Unassign User by DepartmentID
        /// </summary>
        /// <param name="iDeptID">DepartmentID</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUnassignUserListByDeptID(int iDeptID)
        {
            return m_DAL.GetUnassignUserListByDeptID(iDeptID);
        }

        /// <summary>
        /// Get list of Assign User by DepartmentID
        /// </summary>
        /// <param name="iDeptID">DepartmentID</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAssignUserListByDeptID(int iDeptID)
        {
            return m_DAL.GetAssignUserListByDeptID(iDeptID);
        }

        /// <summary>
        /// Get list of Unassign Department by UserNo
        /// Return DataTable(DepartmentId, DepartmentCode, DepartmentName)
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUnassignDeptList(int iUserNo)
        {
            return m_DAL.GetUnassignDeptList(iUserNo);
        }

        /// <summary>
        /// Get list of Assign Department by UserNo
        /// Return DataTable(DepartmentId, DepartmentCode, DepartmentName)
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAssignDeptList(int iUserNo)
        {
            return m_DAL.GetAssignDeptList(iUserNo);
        }       

        /// <summary>
        /// Update List Assign Department To User
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <param name="strDeptIDs">list departmentID Ex: 1,2,3</param>
        /// <param name="iCreatedBy"></param>
        /// <returns></returns>
        public int UpdataAssignDepartmentsToUser(int iUserNo, string strDeptIDs, int iCreatedBy, clsMDLogBase logBase)
        {
            try
            {
                int iRow = 0;
                //Delete all records
                //if radio Department selected, delete all have DepartmentID = iDeptID
                //if radio User selected, delete all have UserNo = iUserNo
                iRow = m_DAL.DeleteDepartmentUser(iUserNo, -1);
                //insert new
                if (!string.IsNullOrEmpty(strDeptIDs))
                {
                    iRow = m_DAL.UpdataAssignDepartmentsToUser(iUserNo, strDeptIDs, iCreatedBy);
                }
                //if successfull
                if (iRow > 0)
                {
                    //system will save log                     
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Update List Assign User To Department
        /// </summary>
        /// <param name="strUserNo">list UserNo Ex: 1,2,3</param>
        /// <param name="iDeptID"></param>       
        /// <param name="iCreatedBy"></param>
        /// <returns></returns>
        public int UpdataAssignUsersToDepartment(string strUserNo, int iDeptID, int iCreatedBy, clsMDLogBase logBase)
        {
            try
            {
                int iRow = 0;                
                //Delete all records
                //if radio Department selected, delete all have DepartmentID = iDeptID
                //if radio User selected, delete all have UserNo = iUserNo
                iRow = m_DAL.DeleteDepartmentUser(-1, iDeptID);
                //insert new
                if (!string.IsNullOrEmpty(strUserNo))
                {
                    iRow = m_DAL.UpdataAssignUsersToDepartment(strUserNo, iDeptID, iCreatedBy);
                }
                //if successfull
                if (iRow > 0)
                {
                    //system will save log                     
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        #endregion

        #region Functions for Assign Users To Team

        /// <summary>
        /// Get list of Unassign User by TeamID
        /// </summary>
        /// <param name="iTeamID">TeamID</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUnassignUserListByTeamID(int iTeamID)
        {
            return m_DAL.GetUnassignUserListByTeamID(iTeamID);
        }

        /// <summary>
        /// Get list of Assign User by TeamID
        /// </summary>
        /// <param name="iTeamID">TeamID</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAssignUserListByTeamID(int iTeamID)
        {
            return m_DAL.GetAssignUserListByTeamID(iTeamID);
        }

        /// <summary>
        /// Get list of Unassign Team by UserNo
        /// Return DataTable(TeamId, TeamCode, TeamName, DepartmentName, TeamTypeName)
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetUnassignTeamList(int iUserNo)
        {
            return m_DAL.GetUnassignTeamList(iUserNo);
        }

        /// <summary>
        /// Get list of Assign Team by UserNo
        /// </summary>
        /// <param name="iUserNo">UserNo</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAssignTeamList(int iUserNo)
        {
            return m_DAL.GetAssignTeamList(iUserNo);
        }       

        /// <summary>
        /// Update List Assign Team To User
        /// </summary>
        /// <param name="iUserNo"></param>
        /// <param name="strTeamIDs">list teamID Ex: 1,2,3</param>       
        /// <param name="iCreatedBy"></param>
        /// <returns></returns>
        public int UpdataAssignTeamsToUser(int iUserNo, string strTeamIDs, int iCreatedBy, clsMDLogBase logBase)
        {
            try
            {
                int iRow = 0;                
                //Delete all records
                //if radio Team selected, delete all have TeamID = iTeamID
                //if radio User selected, delete all have UserNo = iUserNo
                iRow = m_DAL.DeleteTeamUser(iUserNo, -1);
                if (!string.IsNullOrEmpty(strTeamIDs))
                {
                    iRow = m_DAL.UpdataAssignTeamsToUser(iUserNo, strTeamIDs, iCreatedBy);
                }
                //if successfull
                if (iRow > 0)
                {
                    //system will save log                     
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Update List Assign User To Team
        /// </summary>
        /// <param name="strUserNo">list UserNo Ex: 1,2,3</param>
        /// <param name="iTeamID"></param>       
        /// <param name="iCreatedBy"></param>
        /// <returns></returns>
        public int UpdataAssignUsersToTeam(string strUserNo, int iTeamID, int iCreatedBy, clsMDLogBase logBase)
        {
            try
            {
                int iRow = 0;                
                //Delete all records
                //if radio Team selected, delete all have TeamID = iTeamID
                //if radio User selected, delete all have UserNo = iUserNo
                iRow = m_DAL.DeleteTeamUser(-1, iTeamID);
                if (!string.IsNullOrEmpty(strUserNo))
                {
                    iRow = m_DAL.UpdataAssignUsersToTeam(strUserNo, iTeamID, iCreatedBy);
                }
                //if successfull
                if (iRow > 0)
                {
                    //system will save log                     
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }
        #endregion
    }
}
