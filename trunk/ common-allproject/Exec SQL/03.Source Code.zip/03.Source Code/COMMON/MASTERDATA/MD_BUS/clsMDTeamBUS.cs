﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-19 (Tue, 19 March 2013) $
 * ========================================================
 * This class is used to implement business logic for team
 * Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;
using System.Data;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDTeamBUS
    {
        clsMDTeamDAL m_DAL = null;

        private static clsMDTeamBUS instance;
        public static clsMDTeamBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDTeamBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDTeamBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsMDTeamDAL();
            }
        }        


        /// <summary>
        /// Get list of all teams based on input params
        /// Return DataTble(TeamID, TeamCode, TeamName, DepartmentID(DepartmentName), TeamTypeID(TeamTypeName), Remark, CreatedBy, UpdateDate)
        /// </summary>
        /// <param name="obj">clsMDTeamDTO</param>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetTeamList(clsMDTeamDTO obj)
        {
            return m_DAL.GetTeamList(obj);
        }

        /// <summary>
        /// Get list of all team for ComboBox Team in User List screen
        /// not DelFlag = 1
        /// Return DataTable(TeamId, TeamCode, TeamName)
        /// </summary>
        /// <returns>DataTable(TeamId, TeamCode, TeamName)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAllTeamList()
        {
            return m_DAL.GetAllTeamList();
        }
        
        /// <summary>
        /// Get information of team by TeamID
        /// </summary>
        /// <param name="iTeamID">TeamID</param>
        /// <returns>clsMDTeamDTO</returns>
        public clsMDTeamDTO GetTeam(int iTeamID)
        {
            return m_DAL.GetTeam(iTeamID);
        }

        /// <summary>
        /// Get list of all department for ComboBox Department in Team List screen
        /// not get DelFlag = 1
        /// Return DataTable(DepartmentID, DepartmentCode, DepartmentName)
        /// </summary>
        /// <returns>DataTable(DepartmentID, DepartmentCode, DepartmentName)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetDepartmentList()
        {
            clsMDDepartmentDAL dept_DAL = new clsMDDepartmentDAL();
            return dept_DAL.GetAllDepartmentList();
        }

        /// <summary>
        /// Get list of all teamtype for ComboBox TeamType in Team List screen
        /// not get DelFlag = 1
        /// Return DataTable(TeamTypeID, TeamTypeCode, TeamTypeName)
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetTeamTypeList()
        {
            clsMDTeamTypeDAL teamType_DAL = new clsMDTeamTypeDAL();
            return teamType_DAL.GetAllTeamTypeList();
        }

        /// <summary>
        /// Delete Team
        /// </summary>
        /// <param name="iTeamID"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int DeleteTeam(int iTeamID, clsMDLogBase logBase)
        {
            try
            {
                //delete logic team
                int iRow =m_DAL.DeleteTeam(iTeamID);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Insert Team
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertTeam(clsMDTeamDTO obj, clsMDLogBase logBase)
        {
            try
            {
                //inser new team
                int iRow = m_DAL.InsertTeam(obj);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.Key = obj.TeamCode + " " + obj.TeamID;//Key: [TeamCode TeamID]
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Update Team
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int UpdateTeam(clsMDTeamDTO obj, clsMDLogBase logBase)
        {
            try
            {
                //update team
                int iRow = m_DAL.UpdateTeam(obj);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.Key = obj.TeamCode + " " + obj.TeamID;//Key: [TeamCode TeamID]
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Check duplicate TeamCode, TeamName
        /// Return Dictionary<string, int>
        /// Ex: <DepartmentCode, 0> : not exist in database
        ///     <DepartmentName, 1> : exist a record has same name in database
        /// </summary>
        /// <param name="iNewTeam">if create action iNewTeam = 0 else iNewTeam = 1</param>
        /// <param name="iTeamID">TeamID</param>
        /// <param name="strTeamCode">TeamCode</param>
        /// <param name="strTeamName">TeamName</param>
        /// <returns>Dictionary<string, int></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public Dictionary<string, int> ValidationDuplicateTeam(int iNewTeam, int iTeamID, string strTeamCode, string strTeamName)
        {
            return m_DAL.ValidationDuplicateTeam(iNewTeam, iTeamID, strTeamCode, strTeamName);
        }
    }
}
