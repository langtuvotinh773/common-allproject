﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to access data of exchanged currency pair
 * of Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDExchangeCCYPairBUS
    {
        clsMDExchangeCCYPairDAL m_DAL = null;
		#region Properties
		public clsDataAccessLayer DAL
		{
			get
			{
				return m_DAL;
			}
		}
		#endregion
        private static clsMDExchangeCCYPairBUS instance;
        public static clsMDExchangeCCYPairBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDExchangeCCYPairBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDExchangeCCYPairBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsMDExchangeCCYPairDAL();
            }
        }        

        /// <summary>
        /// Get list of all currency for ComboBox
        ///Return DataTable(ExchangeCCYPairID, ExchangeCCYPair)
        /// </summary>
        /// <returns>DataTable(ExchangeCCYPairID, ExchangeCCYPair)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetAllExchangeCCYPairList()
        {
            
            return m_DAL.GetAllExchangeCCYPairList();
        }

        /// <summary>
        /// Insert new ExchangeCCYPair, return ExchangeCCYPairID
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int InsertExchangeCCYPair(clsMDExchangeCCYPairDTO obj)
        {
            return m_DAL.InsertExchangeCCYPair(obj);
        }
    }
}
