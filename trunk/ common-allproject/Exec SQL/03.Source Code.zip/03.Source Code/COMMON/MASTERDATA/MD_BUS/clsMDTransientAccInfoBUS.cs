﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-27 (Mon, 27 May 2013) $
 * ========================================================
 * This class is used to implement business logic for transient account information
 * Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDTransientAccInfoBUS
    {
        clsMDTransientAccInfoDAL m_DAL = null;

        private static clsMDTransientAccInfoBUS instance;
        public static clsMDTransientAccInfoBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDTransientAccInfoBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDTransientAccInfoBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsMDTransientAccInfoDAL();
            }
        }

        /// <summary>
        /// Get list of all transient account information based on input parameter
        /// If all parammeters are blank or null, will get all transient account information
        /// </summary>
        /// <param name="obj">clsMDTransientAccInfoDTO</param>
        /// <returns> DataTable </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetTransientAccInfoList(clsMDTransientAccInfoDTO obj)
        {
            return m_DAL.GetTransientAccInfoList(obj);
        }

        /// <summary>
        /// Get list of all department for ComboBox Department in Team List screen
        /// </summary>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetDepartmentList()
        {
            clsMDDepartmentDAL dept_DAL = new clsMDDepartmentDAL();
            return dept_DAL.GetAllDepartmentList();
        }

        /// <summary>
        /// Get Transient Account Info base on parameters input
        /// </summary>
        /// <returns>clsMDTransientAccInfoDTO</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public clsMDTransientAccInfoDTO GetTransientAccountInfo(string strCCY, int iAccNo)
        {
            return m_DAL.GetTransientAccInfo(strCCY, iAccNo);
        }

        /// <summary>
        /// Get list of all department for ComboBox Department in Team List screen
        /// </summary>
        /// <returns>DataTable</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public DataTable GetCCYList()
        {
            return m_DAL.GetCCYList();
        }
        
        /// <summary>
        /// Insert TransientAccInfo
        /// Return number of row insert
        /// </summary>
        /// <param name="obj">clsMDTransientAccInfoDTO</param>
        /// <returns>number of row insert</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public int InsertTransientAccInfo(clsMDTransientAccInfoDTO obj, clsMDLogBase logBase)
        {
            try
            {
                //insert TransientAccInfo
                int iRow = m_DAL.InsertTransientAccInfo(obj);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.Key = obj.CCY + " " + obj.AccountNo; //Key: [CCY AccountNo]
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                ////show error message
                //clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                ////save log exception
                //clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Update information of TransientAccInfo
        /// Return number of row update
        /// </summary>
        /// <param name="obj">clsMDTransientAccInfoDTO</param>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public int UpdateTransientAccInfo(clsMDTransientAccInfoDTO obj, clsMDLogBase logBase)
        {
            try
            {
                //update TransientAccInfo
                int iRow = m_DAL.UpdateTransientAccInfo(obj);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.Key = obj.CCY + " " + obj.AccountNo; //Key: [CCY AccountNo]
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //////show error message
                ////clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //////save log exception
                ////clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                throw new System.ArgumentException(ex.Message);
                return -1;
            }
        }

        /// <summary>
        /// Delete TransientAccInfo
        /// </summary>
        /// <param name="iDeptID">TransientAccInfoID</param>
        /// <returns>number of row delete</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public int DeleteTransientAccInfo(string strCCY, int iAccNo, clsMDLogBase logBase)
        {
            try
            {
                //delete logic TransientAccInfo
                int iRow = m_DAL.DeleteTransientAccInfo(strCCY, iAccNo);
                //delete successfull
                if (iRow > 0)
                {
                    //system will save log 
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }

        /// <summary>
        /// Check Exist Transient Account Info
        /// </summary>
        /// <returns>
        /// True if exist Transient Account Info
        /// False if not exist Transient Account Info
        /// </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public bool CheckExistTransAccInfo(string strCCY, int iAccNo)
        {
            return m_DAL.CheckExistTransAccInfo(strCCY, iAccNo);
        }
        
    }
}
