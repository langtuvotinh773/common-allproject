﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to access data
 * of Master Data module.
 */
using System;
using System.Collections.Generic;
using Phoenix.Common.MasterData.Dal;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Dto;
using System.Data;
using Config.Classes;
using System.Linq;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDBus
    {
        /// <summary>
        /// used to process data from database
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public clsMDBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Get instance of clMDBus
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private static clsMDBus instance;
        public static clsMDBus Instance()
        {
            if (instance == null)
            {
                instance = new clsMDBus();
            }
            return instance;
        }

        /// <summary>
        /// commit transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// get list parameter belongs to type
        /// </summary>
        /// <returns>type</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public List<CbbObject> GetListMDParameters(string strType)
        {
            List<CbbObject> lst = new List<CbbObject>();
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@module", clsMDConstant.MODULE_MD);
            parameters[1] = new SqlParameter("@type", strType);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetParameters", CommandType.StoredProcedure, parameters);
            lst.Add(new CbbObject("0", ""));
            if (reader.Rows.Count > 0)
            {
                for (int i = 0; i < reader.Rows.Count; i++)
                    lst.Add(new CbbObject(reader.Rows[i]["Value"], reader.Rows[i]["Name"]));
            }
            return lst;
        }

        /// <summary>
        /// get list parameter belongs to type
        /// </summary>
        /// <returns>type</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public List<CbbObject> GetListParameters(string strModule, string strType)
        {
            List<CbbObject> lst = new List<CbbObject>();
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@module", strModule);
            parameters[1] = new SqlParameter("@type", strType);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetParameters", CommandType.StoredProcedure, parameters);
            lst.Add(new CbbObject("0", ""));
            if (reader.Rows.Count > 0)
            {
                for (int i = 0; i < reader.Rows.Count; i++)
                    lst.Add(new CbbObject(reader.Rows[i]["Value"], reader.Rows[i]["Name"]));
            }
            return lst;
        }

        /// <summary>
        /// get list parameter belongs to type without empty item
        /// </summary>
        /// <returns>type</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public List<CbbObject> GetListMDParametersWithoutEmptyItem(string strType)
        {
            List<CbbObject> lst = new List<CbbObject>();
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@module", clsMDConstant.MODULE_MD);
            parameters[1] = new SqlParameter("@type", clsMDConstant.PARAMETERS_TRANSACTION_TYPE);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetParameters", CommandType.StoredProcedure, parameters);

            if (reader.Rows.Count > 0)
            {
                for (int i = 0; i < reader.Rows.Count; i++)
                    lst.Add(new CbbObject(reader.Rows[i]["Value"], reader.Rows[i]["Name"]));
            }
            return lst;
        }

        /// <summary>
        /// Get server datetime
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond 
        public string GetServerDate()
        {
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetServerDate", CommandType.StoredProcedure);
            return "_" + ((DateTime)reader.Rows[0][0]).ToString("yyyyMMdd");
        }

        /// <summary>
        /// Load data for Status combobox in case call action 'Inquiry Quotation History'
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        public List<CbbObject> LoadStatusInquiryQuotationHistory()
        {
            List<CbbObject> status = new List<CbbObject>();
            status = new List<CbbObject>();
            status.Add(new CbbObject(-1, ""));
            status.Add(new CbbObject((int)CommonValue.QuotationStatus.Approved, clsMDConstant.QUOTATIONSTATUS_03_APPROVED));
            status.Add(new CbbObject((int)CommonValue.QuotationStatus.Obsolete, clsMDConstant.QUOTATIONSTATUS_07_OBSOLUTE));
            return status;
        }

        /// <summary>
        /// Get password default from table Parameters
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public string GetPasswordDefault()
        {
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@module", clsMDConstant.MODULE_MD);
            parameters[1] = new SqlParameter("@type", clsMDConstant.PARAMETERS_PASSWORD_DEFAULT);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetParameters", CommandType.StoredProcedure, parameters);
            if (reader.Rows.Count > 0)
            {
                return reader.Rows[0]["Value"].ToString();
            }
            return string.Empty;
        }

        /// <summary>
        /// Get threshold param from table Parameters, system will fill auto value threshold based on this param
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public string GetParamThreshold()
        {
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@module", clsMDConstant.MODULE_MD);
            parameters[1] = new SqlParameter("@type", clsMDConstant.PARAMETERS_THRESHOLD_DEFAULT);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetParameters", CommandType.StoredProcedure, parameters);
            if (reader.Rows.Count > 0)
            {
                return reader.Rows[0]["Value"].ToString();
            }
            return string.Empty;
        }

        /// <summary>
        /// get list parameter belongs to type
        /// </summary>
        /// <returns>type</returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<CbbObject> GetLisBoardRateAction()
        {
            List<CbbObject> lst = new List<CbbObject>();
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Blank, clsMDConstant.BOARD_RATE_ACTION_Blank));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Save, clsMDConstant.BOARD_RATE_ACTION_Save));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.SendForApproval, clsMDConstant.BOARD_RATE_ACTION_SendForApproval));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Preview, clsMDConstant.BOARD_RATE_ACTION_Preview));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Withdraw, clsMDConstant.BOARD_RATE_ACTION_Withdraw));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Approve, clsMDConstant.BOARD_RATE_ACTION_Approve));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Return, clsMDConstant.BOARD_RATE_ACTION_Return));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Revise, clsMDConstant.BOARD_RATE_ACTION_Revise));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Freeze, clsMDConstant.BOARD_RATE_ACTION_Freeze));
            return lst;
        }

        /// <summary>
        /// Get server datetime
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public DateTime GetServerDateTime()
        {
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetServerDate", CommandType.StoredProcedure);
            return (DateTime)reader.Rows[0][0];
        }

        /// <summary>
        /// Get Threshold by CCY
        /// </summary>
        /// <param name="CCY"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public string GetThresholdByCCY(string CCY)
        {
            string threshold = string.Empty;
            List<clsMDThresholdDTO> lst = clsMDThresholdBUS.Instance().GetThresholdByCCY(CCY);

            if (lst.Count > 0)
            {
                Decimal? dThreshold = clsMDFunction.ConvertObjectToNullDecimal(lst[0].Threshold);
                if (dThreshold != null)
                {
                    if (dThreshold > clsMDConstant.BOARD_RATE_BIO_VALUE)
                    {
                        threshold = string.Format(clsMDConstant.BOARD_RATE_FOR_THE_AMOUNT, CCY, Decimal.Round(dThreshold.Value / clsMDConstant.BOARD_RATE_BIO_VALUE, 0), clsMDConstant.BOARD_RATE_BIO).Trim();
                    }
                    else if (dThreshold > clsMDConstant.BOARD_RATE_MIO_VALUE)
                    {
                        threshold = string.Format(clsMDConstant.BOARD_RATE_FOR_THE_AMOUNT, CCY, Decimal.Round(dThreshold.Value / clsMDConstant.BOARD_RATE_MIO_VALUE, 0), clsMDConstant.BOARD_RATE_MIO).Trim();
                    }
                    else
                    {
                        threshold = string.Format(clsMDConstant.BOARD_RATE_FOR_THE_AMOUNT, CCY, Decimal.Round(dThreshold.Value, 0), string.Empty).Trim();
                    }
                }
                else
                {
                    threshold = string.Format(clsMDConstant.BOARD_RATE_FOR_THE_AMOUNT, CCY, 0, string.Empty).Trim();
                }
            }
            else
            {
                threshold = string.Format(clsMDConstant.BOARD_RATE_FOR_THE_AMOUNT, CCY, 0, string.Empty).Trim();
            }

            return threshold;
        }

        /// <summary>
        /// Process Important Note for Export data
        /// </summary>
        /// <param name="importantNote"></param>
        /// <param name="ccy"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public bool ProcessImportantNote(ref string importantNote, string ccy)
        {
            try
            {
                List<clsMDOrdinaryDepositISRateDTO> lstOrd = clsMDBoardRaterBUS.Instance().GetOrdinaryDepositISRateList();
                List<clsMDCutoffTimeDTO> lstCut = clsMDBoardRaterBUS.Instance().GetCutoffTimeList();

                clsMDOrdinaryDepositISRateDTO dtoOrd;

                if (lstOrd.Count > 0)
                {
                    dtoOrd = lstOrd.FirstOrDefault(m => m.CCY.ToUpper().Equals(ccy));

                    if (dtoOrd != null)
                    {
                        importantNote = importantNote.Replace("{#Period#}", dtoOrd.FromDate.ToString("dd MMM") + " - " + dtoOrd.ToDate.ToString("dd MMM yy"));
                        foreach (clsMDOrdinaryDepositISRateDTO item in lstOrd)
                        {
                            importantNote = importantNote.Replace("{#r" + item.CCY + "#}", item.Rate.ToString());
                        }

                        if (lstCut.Count > 0)
                        {
                            foreach (clsMDCutoffTimeDTO item in lstCut)
                            {
                                importantNote = importantNote.Replace("{#c" + item.CCY + "#}", item.CutoffTime);
                            }
                        }
                    }

                }
                else
                {

                }
            }
            catch (System.Exception ex)
            {
                return false;
            }
            return true;
        }
    }
}