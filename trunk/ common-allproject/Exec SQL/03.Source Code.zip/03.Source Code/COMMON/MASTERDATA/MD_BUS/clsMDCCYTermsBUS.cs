﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Dal;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDCCYTermsBUS
    {
        clsMDCCYTermsDAL m_DAL = null;
		#region Properties
		public clsDataAccessLayer DAL
		{
			get
			{
				return m_DAL;
			}
		}
		#endregion
        private static clsMDCCYTermsBUS instance;
        public static clsMDCCYTermsBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDCCYTermsBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDCCYTermsBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsMDCCYTermsDAL();
            }
        }   

        /// <summary>
        /// Get list of all CCYTerms
        /// </summary>
        /// <returns>all columns</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetCCYTermsList()
        {            
            return m_DAL.GetAllCCYTermsList();
        }
    }
}
