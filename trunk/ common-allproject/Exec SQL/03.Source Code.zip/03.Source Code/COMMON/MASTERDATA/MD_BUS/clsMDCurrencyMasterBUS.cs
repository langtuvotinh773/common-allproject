﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to access data of currency master
 * of Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Dal;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDCurrencyMasterBUS
    {
        clsMDCurrencyMasterDAL m_DAL = null;
		#region Properties
		public clsDataAccessLayer DAL
		{
			get
			{
				return m_DAL;
			}
		}
		#endregion
        private static clsMDCurrencyMasterBUS instance;
        public static clsMDCurrencyMasterBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDCurrencyMasterBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDCurrencyMasterBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsMDCurrencyMasterDAL();
            }
        }   

        /// <summary>
        /// Get list of all currency for ComboBox
        /// not DelFlag = 1
        /// Return DataTable(CCYCode)
        /// </summary>
        /// <returns>DataTable(CCY)</returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetCurrencyList()
        {            
            return m_DAL.GetAllCurrencyList();
        }
    }
}
