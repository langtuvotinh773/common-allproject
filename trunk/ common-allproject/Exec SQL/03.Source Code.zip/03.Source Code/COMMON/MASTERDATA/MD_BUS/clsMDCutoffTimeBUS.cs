﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-24 +0700 (Fri, 24 may 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define access data for CutoffTime
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using Config.Classes;
using Phoenix.Common.MasterData.Dal;
using System.Data.SqlClient;

namespace Phoenix.Common.MasterData.Bus
{
	public class clsMDCutoffTimeBUS
	{

		/// <summary>
		/// used to process data from database
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private clsDataAccessLayer m_DAL = null;
		public clsDataAccessLayer DAL
		{
			get
			{
				return m_DAL;
			}
		}
	
		/// <summary>
		/// Contructor
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public clsMDCutoffTimeBUS()
		{
			m_DAL = new clsDataAccessLayer();
		}

		/// <summary>
		/// Instance of clsMDCutoffTimeBus Object
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private static clsMDCutoffTimeBUS instance;
		public static clsMDCutoffTimeBUS Instance()
		{
			if (instance == null)
			{
				instance = new clsMDCutoffTimeBUS();
			}
			return instance;
		}
		
		/// <summary>
		/// commit transaction
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public void Commit()
		{
			m_DAL.m_transaction.Commit();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

		/// <summary>
		/// rollback transaction
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public void RollBack()
		{
			m_DAL.m_transaction.Rollback();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}
		 
		/// <summary>
		/// Get CutoffTime list
		/// </summary>
		/// <param name="strCCYCode">CCY Code</param>
		/// <param name="iTransactionType">Transaction Type</param>
		/// <param name="dtUpdateDate">Update Date</param>
		/// <param name="strUpdateBy">Update By</param>
		/// <returns>CutoffTime datatable</returns>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public DataTable GetCutoffTimeList(string strCCYCode, int iTransactionType, DateTime? dtUpdateDate,string strUpdateBy)
		{
			SqlParameter[] parameters = new SqlParameter[4];
			parameters[0] = new SqlParameter("@ccyCode", strCCYCode); 
			parameters[1] = new SqlParameter("@transType", iTransactionType);
			if (dtUpdateDate == null)
			{
				parameters[2] = new SqlParameter("@updateDate", DBNull.Value);
			}
			else
			{
				parameters[2] = new SqlParameter("@updateDate", dtUpdateDate);
			}
			
			parameters[3] = new SqlParameter("@updateBy", strUpdateBy);
			return m_DAL.ExecuteDataReader("dbo.spMD_GetCutoffTimeList", CommandType.StoredProcedure,parameters);
		}

		/// <summary>
		/// Check a CutoffTime is exist or not
		/// </summary>
		/// <param name="strCCYCode">CCY Code</param>
		/// <param name="iTransactionType">Transaction Type</param>
		/// <returns>CutoffTime ID</returns>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public DataTable CheckExistCutoffTime(string strCCYCode, int iTransactionType)
		{
			SqlParameter[] parameters = new SqlParameter[2];
			parameters[0] = new SqlParameter("@ccyCode", strCCYCode);
			parameters[1] = new SqlParameter("@transType", iTransactionType);
			return	m_DAL.ExecuteDataReader("dbo.spMD_CheckExistCutoffTime", CommandType.StoredProcedure, parameters);			
		}

		/// <summary>
		/// Override a CutoffTime
		/// </summary>
		/// <param name="iCutoffTimeID">CutoffTime ID</param>
		/// <param name="strCutoffTime">CutoffTime value</param>
		/// <returns>Number of overrided CutoffTime</returns>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public int OverideCutoffTime( int iCutoffTimeID, string strCutoffTime)
		{
			SqlParameter[] parameters = new SqlParameter[3];
			parameters[0] = new SqlParameter("@CutoffTimeId", iCutoffTimeID);
			parameters[1] = new SqlParameter("@CutoffTime", strCutoffTime);
			parameters[2] = new SqlParameter("@updateBy", clsUserInfo.UserNo);
			int i = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_OverideCutoffTime", CommandType.StoredProcedure, parameters);
			return i;
		}
		
		/// <summary>
		/// Update CutoffTime
		/// </summary>
		/// <param name="iCutoffTimeID">CutoffTime ID</param>
		/// <param name="strCCYCode">CCY Code</param>
		/// <param name="iTransactionType">Transaction Type</param>
		/// <param name="strCutoffTime">CutoffTime</param>
		/// <returns>Number of rows updated</returns>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public int UpdateCutoffTime(int iCutoffTimeID, string strCCYCode, int iTransactionType,string strCutoffTime)
		{
			SqlParameter[] parameters = new SqlParameter[5];
			parameters[0] = new SqlParameter("@CutoffTimeId", iCutoffTimeID);
			parameters[1] = new SqlParameter("@ccyCode", strCCYCode);
			parameters[2] = new SqlParameter("@transactionType", iTransactionType);
			parameters[3] = new SqlParameter("@CutoffTime", strCutoffTime);
			parameters[4] = new SqlParameter("@updateBy", clsUserInfo.UserNo);
			int i = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_UpdateCutoffTime", CommandType.StoredProcedure, parameters);
			return i;
		}
	
		/// <summary>
		/// Create CutoffTime
		/// </summary>
		/// <param name="strCCYCode">CCY Code</param>
		/// <param name="iTransactionType">Transaction Type</param>
		/// <param name="strCutoffTime">CutoffTime ID</param>
		/// <returns>Number of CutoffTime created</returns>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public int CreateCutoffTime(string strCCYCode,int iTransactionType, string strCutoffTime)
		{ 
			SqlParameter[] parameters = new SqlParameter[4];
			parameters[0] = new SqlParameter("@ccyCode", strCCYCode);
			parameters[1] = new SqlParameter("@transType", iTransactionType);
			parameters[2] = new SqlParameter("@cutoffTime", strCutoffTime);
			parameters[3] = new SqlParameter("@user", clsUserInfo.UserNo);
            int CutoffTimeID = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_CreateCutoffTime", CommandType.StoredProcedure, parameters);
            //if (dtbCutoffTimeID.Rows.Count > 0)
            //    return int.Parse(dtbCutoffTimeID.Rows[0][0].ToString());
            return CutoffTimeID;
		}

		/// <summary>
		/// Delete CutoffTime
		/// </summary>
		/// <param name="iCutoffTimeID">CutoffTime ID</param>
		/// <returns>Number of deleted CutoffTime</returns>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public int DeleteCutoffTime(int iCutoffTimeID)
		{
			int row = 0;
			List<SqlParameter[]> lstParams = new List<SqlParameter[]>();
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@CutoffTimeID", iCutoffTimeID);
			lstParams.Add(parameters);
			row = m_DAL.ExecuteNonQueryDeleteWithTransaction("dbo.spMD_DeleteCutoffTime", CommandType.StoredProcedure, lstParams);
			return row;
		}
	}
}