﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-04-08 14:29:30 +0700 (Mon, 08 Apr 2013) $
 * $Revision: 11501 $ 
 * ========================================================
 * This class is used to manage Quotation
 * for Master Date module.
 */
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Log.Dto;
namespace Phoenix.Common.MasterData.Bus
{
	public class clsMDQuoationBus
	{		
		/// <summary>
		/// used to process data from database
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsDataAccessLayer m_DAL = null;
		public clsDataAccessLayer DAL
		{
			get
			{
				return m_DAL;
			}
		}
	
		/// <summary>
		/// Contructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsMDQuoationBus()
		{
			m_DAL = new clsDataAccessLayer();
		}

		/// <summary>
		/// Get instance of clsMDQuotationBus object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private static clsMDQuoationBus instance;
		public static clsMDQuoationBus Instance()
		{
			if (instance == null)
			{
				instance = new clsMDQuoationBus();
			}
			return instance;

		}

		/// <summary>
		/// Get Quotation
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsMDQuotationDTO GetQuotation()
		{
			clsMDQuotationDTO quotationObj = new clsMDQuotationDTO();
			DataTable tdbQuotationInfo = m_DAL.ExecuteDataReader("dbo.spMD_GetQuotation", CommandType.StoredProcedure);
			Console.WriteLine("Rows.Count: " + tdbQuotationInfo.Rows.Count);
			if (tdbQuotationInfo.Rows.Count > 0)
			{
				quotationObj.ImportTime = DateTime.Parse(tdbQuotationInfo.Rows[0]["ImportTime"].ToString());
				quotationObj.Seq = int.Parse(tdbQuotationInfo.Rows[0]["Seq"].ToString());
				quotationObj.CentralBankCoreRate = tdbQuotationInfo.Rows[0]["CentralBankCoreRate"].ToString().Trim();
				quotationObj.TC = tdbQuotationInfo.Rows[0]["TC"].ToString().Trim();
				quotationObj.NoteEnd = tdbQuotationInfo.Rows[0]["NoteEnd"].ToString().Trim();
				quotationObj.Status = int.Parse(tdbQuotationInfo.Rows[0]["Status"].ToString().Trim());
				quotationObj.Remark = tdbQuotationInfo.Rows[0]["Remark"].ToString().Trim();
				quotationObj.QuotationID = int.Parse(tdbQuotationInfo.Rows[0]["QuotationID"].ToString().Trim());
				quotationObj.NoteHead = quotationObj.Status == (int) CommonValue.QuotationStatus.New ? clsMDQuoationBus.Instance().GetNodeHead() : tdbQuotationInfo.Rows[0]["NoteHead"].ToString().Trim();
				quotationObj.NoteThreshold = quotationObj.Status == (int) CommonValue.QuotationStatus.New ? clsMDQuoationBus.Instance().GetNoteThreshold() : tdbQuotationInfo.Rows[0]["NoteThreshold"].ToString().Trim();
				quotationObj.NoteMid = quotationObj.Status == (int) CommonValue.QuotationStatus.New ? clsMDQuoationBus.Instance().GetNoteMid() : tdbQuotationInfo.Rows[0]["NoteMid"].ToString().Trim();
				quotationObj.Approver = tdbQuotationInfo.Rows[0]["ApprovedBy"].ToString().Trim();

			}
			return quotationObj;
		}
	
		/// <summary>
		/// Get Quotation
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsMDQuotationDTO GetQuotationDetail(int iQuotationID)
		{
			clsMDQuotationDTO quotationObj = new clsMDQuotationDTO();
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@quotationID", iQuotationID);
			/*
				QuotationID,
				NoteHead,
				ImportTime,
				Seq,
				CentralBankCoreRate,
				TC,
				NoteThreshold,
				NoteMid,
				NoteEnd,
				[Status],
				Remark
			 */
			DataTable tdbQuotationInfo = m_DAL.ExecuteDataReader("dbo.spMD_GetQuotationDetail", CommandType.StoredProcedure, parameters);
			Console.WriteLine("Rows.Count: " + tdbQuotationInfo.Rows.Count);
			if (tdbQuotationInfo.Rows.Count > 0)
			{
				quotationObj.QuotationID = int.Parse(tdbQuotationInfo.Rows[0]["QuotationID"].ToString().Trim());
				quotationObj.Status = int.Parse(tdbQuotationInfo.Rows[0]["Status"].ToString().Trim());
				
				quotationObj.ImportTime = DateTime.Parse(tdbQuotationInfo.Rows[0]["ImportTime"].ToString());
				quotationObj.EffectiveTime = tdbQuotationInfo.Rows[0]["EffectiveTime"].ToString().Trim();
				quotationObj.Seq = int.Parse(tdbQuotationInfo.Rows[0]["Seq"].ToString());
                quotationObj.Version = double.Parse(tdbQuotationInfo.Rows[0]["Version"].ToString());
				quotationObj.CentralBankCoreRate = tdbQuotationInfo.Rows[0]["CentralBankCoreRate"].ToString().Trim();
				quotationObj.TC = tdbQuotationInfo.Rows[0]["TC"].ToString().Trim();
				quotationObj.IsActive = bool.Parse(tdbQuotationInfo.Rows[0]["Isactive"].ToString());
                quotationObj.CreatedBy = int.Parse(tdbQuotationInfo.Rows[0]["CreatedBy"].ToString());//20130516 vlhcnhung ADD
                if(string.IsNullOrEmpty(tdbQuotationInfo.Rows[0]["NoteHead"].ToString().Trim()))
                {
                    quotationObj.NoteHead = clsMDQuoationBus.Instance().GetNodeHead();
                }
                else
                {
                    quotationObj.NoteHead = tdbQuotationInfo.Rows[0]["NoteHead"].ToString().Trim();
                }
                if(string.IsNullOrEmpty(tdbQuotationInfo.Rows[0]["NoteThreshold"].ToString().Trim()))
                {
                    quotationObj.NoteThreshold = clsMDQuoationBus.Instance().GetNoteThreshold();
                }
                else
                {
                    quotationObj.NoteThreshold = tdbQuotationInfo.Rows[0]["NoteThreshold"].ToString().Trim();
                }
                if(string.IsNullOrEmpty(tdbQuotationInfo.Rows[0]["NoteMid"].ToString().Trim()))
                {
                    quotationObj.NoteMid = clsMDQuoationBus.Instance().GetNoteMid();
                }else
                {
                    quotationObj.NoteMid =  tdbQuotationInfo.Rows[0]["NoteMid"].ToString().Trim();
                }
                if (string.IsNullOrEmpty(tdbQuotationInfo.Rows[0]["NoteEnd"].ToString().Trim()))
                {
                    quotationObj.NoteEnd = clsMDQuoationBus.Instance().GetNoteEnd();
                }
                else
                {
                    quotationObj.NoteEnd = tdbQuotationInfo.Rows[0]["NoteEnd"].ToString().Trim();
                }
                quotationObj.Remark = tdbQuotationInfo.Rows[0]["Remark"].ToString().Trim();
                //quotationObj.Status == (int)CommonValue.QuotationStatus.New ? clsMDQuoationBus.Instance().GetRemark() : tdbQuotationInfo.Rows[0]["Remark"].ToString().Trim();
                				
				quotationObj.STT = clsMDNumberUtil.toOrdinal(quotationObj.Seq);
			}

			DataTable dtbCeilingFloor = m_DAL.ExecuteDataReader("dbo.spMD_GetCeilingFloor", CommandType.StoredProcedure);
			if (dtbCeilingFloor.Rows.Count > 0)
			{
				quotationObj.CeilingRate = dtbCeilingFloor.Rows[0]["Ceiling"].ToString().Trim();
				quotationObj.FloorRate = dtbCeilingFloor.Rows[0]["Floor"].ToString().Trim();
			}
			return quotationObj;
		}
	
		/// <summary>
		/// Get Quotation List
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        //public DataTable GetQuotationList(DateTime dtmFrom, DateTime dtmTo, int iStatus)
        //{
        //    clsMDQuotationDTO quotationObj = new clsMDQuotationDTO();
        //    SqlParameter[] parameters = new SqlParameter[3];
        //    parameters[0] = new SqlParameter("@dateTimeFrom", dtmFrom);
        //    parameters[1] = new SqlParameter("@dateTimeTo", dtmTo);
        //    parameters[2] = new SqlParameter("@status", iStatus);
        //    DataTable tdbQuotation = m_DAL.ExecuteDataReader("dbo.spMD_GetQuotationList", CommandType.StoredProcedure, parameters);
        //    return tdbQuotation;
        //}
	
		/// <summary>
		/// Get Quotation List
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetQuotationListForApprover()
		{
			return m_DAL.ExecuteDataReader("dbo.spMD_GetQuotationListForApprover", CommandType.StoredProcedure);
		}
	
		/// <summary>
		/// Get Quotation List
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetQuotationListForMaker()
		{
			return m_DAL.ExecuteDataReader("dbo.spMD_GetQuotationListForMaker", CommandType.StoredProcedure);
		}
	
		/// <summary>
		/// Get NoteHead
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string GetNodeHead()
		{
			DataTable dataTable = m_DAL.ExecuteDataReader("dbo.spMD_GetNoteHead", CommandType.StoredProcedure);
			if (dataTable.Rows.Count <= 0)
				return "";
			return dataTable.Rows[dataTable.Rows.Count - 1][0].ToString();
		}
	
		/// <summary>
		/// Get NoteHead
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string GetNoteMid()
		{
			DataTable dataTable = m_DAL.ExecuteDataReader("dbo.spMD_GetNoteMid", CommandType.StoredProcedure);
			if (dataTable.Rows.Count <= 0)
				return "";
			return dataTable.Rows[dataTable.Rows.Count - 1][0].ToString();
		}
	
		/// <summary>
		/// Get NoteHead
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string GetNoteEnd()
		{
			DataTable dataTable = m_DAL.ExecuteDataReader("dbo.spMD_GetNoteEnd", CommandType.StoredProcedure);
			if (dataTable.Rows.Count <= 0)
				return "";
			return dataTable.Rows[dataTable.Rows.Count - 1][0].ToString();
		}
	
		/// <summary>
		/// Get NoteHead
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string GetRemark()
		{
			DataTable dataTable = m_DAL.ExecuteDataReader("dbo.spMD_GetRemark", CommandType.StoredProcedure);
			if (dataTable.Rows.Count <= 0)
				return "";
			return dataTable.Rows[dataTable.Rows.Count - 1][0].ToString();
		}

		/// <summary>
		/// Get NoteHead
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string GetNoteThreshold()
		{
			DataTable dataTable = m_DAL.ExecuteDataReader("dbo.spMD_GetNoteThreshold", CommandType.StoredProcedure);
			if (dataTable.Rows.Count <= 0)
				return string.Empty;
			return dataTable.Rows[dataTable.Rows.Count - 1][0].ToString();
		}

        /// <summary>
        /// Get value of Threshold Param
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public string GetThresholdValue()
        {
            SqlParameter[] parameters = new SqlParameter[]{
                new SqlParameter("@ccy", clsMDConstant.USD),
                new SqlParameter("@tranType", (int)CommonValue.TransactionType.FX)
            };
            DataTable dtbThreshold = m_DAL.ExecuteDataReader("dbo.spMD_GetThresholdParamForQuotation", CommandType.StoredProcedure, parameters);
            string strThresholdValue = string.Empty;
            if (dtbThreshold != null && dtbThreshold.Rows.Count > 0)
            {
                strThresholdValue = decimal.Parse(dtbThreshold.Rows[0]["Threshold"].ToString()).ToString(clsMDConstant.NUMBER_FORMAT).ToString();
            }
            return strThresholdValue;
        }

		/// <summary>
		/// Get Quotation Detail 1
		/// </summary>
		/// <param name="iQuotationID"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetQuotationDetailUSD(int iQuotationID)
		{
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@quotationID", iQuotationID);
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetQuotationDetailUSD", CommandType.StoredProcedure, parameters);
			return reader;
		}

		/// <summary>
		/// Get Quotation Detail 1
		/// </summary>
		/// <param name="iQuotationID"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetPreviousQuotationDetailUSD(int iQuotationID)
		{
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@quotationID", iQuotationID);
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetPreviousQuotationDetailUSD", CommandType.StoredProcedure, parameters);
			return reader;
		}

		/// <summary>
		/// Get Quotation Detail 2
		/// </summary>
		/// <param name="iQuotationID"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetQuotationDetailVND(int iQuotationID)
		{
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@quotationID", iQuotationID);
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetQuotationDetailVND", CommandType.StoredProcedure, parameters);
			return reader;
		}

		/// <summary>
		/// Get Quotation Detail 2
		/// </summary>
		/// <param name="iQuotationID"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetPreviousQuotationDetailVND(int iQuotationID)
		{
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@quotationID", iQuotationID);
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetPreviousQuotationDetailVND", CommandType.StoredProcedure, parameters);
			return reader;
		}
	
		/// <summary>
		/// Get GetQuotation EC Rate
		/// </summary>
		/// <param name="iQuotationID"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetQuotationECRate(int iQuotationID)
		{
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@quotationID", iQuotationID);
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetQuotationECRate", CommandType.StoredProcedure, parameters);
			return reader;
		}
		
		/// <summary>
		/// Get GetQuotation EC Rate
		/// </summary>
		/// <param name="iQuotationID"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetPreviousQuotationECRate(int iQuotationID)
		{
			SqlParameter[] parameters = new SqlParameter[1];
			parameters[0] = new SqlParameter("@quotationID", iQuotationID);
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spMD_GetPreviousQuotationECRate", CommandType.StoredProcedure, parameters);
			return reader;
		}

		/// <summary>
		/// Update Quotation Status
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int UpdateQuotationStatus(clsMDQuotationDTO quotationDTO)
		{
            try
            {
                int row = 0;

                SqlParameter[] parameters = new SqlParameter[8];
                parameters[0] = new SqlParameter("@quotationID", quotationDTO.QuotationID);
                parameters[1] = new SqlParameter("@status", quotationDTO.Status);
                parameters[2] = new SqlParameter("@noteHead", quotationDTO.NoteHead);
                parameters[3] = new SqlParameter("@noteThreshold", quotationDTO.NoteThreshold);
                parameters[4] = new SqlParameter("@noteMid", quotationDTO.NoteMid);
                parameters[5] = new SqlParameter("@noteEnd", quotationDTO.NoteEnd);
                parameters[6] = new SqlParameter("@remark", quotationDTO.Remark);
                parameters[7] = new SqlParameter("@approver", quotationDTO.Approver);
                row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_UpdateQuotationStatus", CommandType.StoredProcedure, parameters);

                return row;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}
	
		/// <summary>
		/// Update Quotation Status
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int UpdateQuotationStatus(int iQuotationID, int iNewStatus)
		{
            try
            {
                int row = 0;

                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@quotationID", iQuotationID);
                parameters[1] = new SqlParameter("@status", iNewStatus);
                row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_UpdateQuotationStatus", CommandType.StoredProcedure, parameters);

                return row;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}
	
		/// <summary>
		/// Update Quotation Status
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int ReturnQuotation(int iQuotationID, string strRemark)
		{
            try
            {
                int row = 0;

                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@quotationID", iQuotationID);
                parameters[1] = new SqlParameter("@remark", strRemark);
                row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_ReturnQuotation", CommandType.StoredProcedure, parameters);

                return row;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}

		/// <summary>
		/// Update Free text
		/// </summary>
		/// <param name="iQuotationID">Quotation Id</param>
		/// <param name="strNoteHead">Note Head</param>
		/// <param name="strNoteThreshold">Note Threshold</param>
		/// <param name="strNoteMid">Note Mid</param>
		/// <param name="strNoteEnd">Note End</param>
		/// <param name="strRemark">Remark</param>
		/// <returns>Number or rows updated</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int UpdateFreeText(int iQuotationID, string strNoteHead, string strNoteThreshold, string strNoteMid, string strNoteEnd, string strRemark)
		{
            try
            {
                int row = 0;

                SqlParameter[] parameters = new SqlParameter[6];
                parameters[0] = new SqlParameter("@quotationID", iQuotationID);
                parameters[1] = new SqlParameter("@noteHead", strNoteHead);
                parameters[2] = new SqlParameter("@noteThreshold", strNoteThreshold);
                parameters[3] = new SqlParameter("@noteMid", strNoteMid);
                parameters[4] = new SqlParameter("@noteEnd", strNoteEnd);
                parameters[5] = new SqlParameter("@remark", strRemark);
                row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_UpdateFreeText", CommandType.StoredProcedure, parameters);

                return row;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}

		/// <summary>
		/// Approve quotation
		/// </summary>
		/// <param name="iQuotationID">Quotation ID</param>
		/// <param name="dVersion">Version</param>
		/// <returns>Number of effected rows</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int ApproveQuotation(int iQuotationID, double dVersion)
		{
            try
            {
                int row = 0;

                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@quotationID", iQuotationID);
                parameters[1] = new SqlParameter("@version", dVersion);
                parameters[2] = new SqlParameter("@approver", clsUserInfo.UserNo);
                row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_ApproveQuotation", CommandType.StoredProcedure, parameters);
                return row;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}
	
		/// <summary>
		/// Revise quotation
		/// </summary>
		/// <param name="iQuotationID">Quotation ID</param>
		/// <param name="strRemark">Remark</param>
		/// <returns>Number of rows effected</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int ReviseQuotation(int iQuotationID, string strRemark)
		{
            try
            {
                int row = 0;

                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@quotationID", iQuotationID);
                parameters[1] = new SqlParameter("@remark", strRemark);
                row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_ReviseQuotation", CommandType.StoredProcedure, parameters);

                return row;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}

		/// <summary>
		/// Freeze quotation
		/// </summary>
		/// <param name="iQuotationID">Quotation ID</param>
		/// <returns>Number of rows effected</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int FreezeQuotation(int iQuotationID)
		{
            try
            {
                int row = 0;

                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@quotationID", iQuotationID);
                row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_FreezeQuotation", CommandType.StoredProcedure, parameters);

                return row;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}
	
		/// <summary>
		/// Get previous Quotation in current date
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
		public clsMDQuotationDTO GetPreviousQuotation()
		{          
			clsMDQuotationDTO quotationObj = new clsMDQuotationDTO();
			DataTable tdbQuotationInfo = m_DAL.ExecuteDataReader("dbo.spMD_GetPreviousQuotation", CommandType.StoredProcedure);
			Console.WriteLine("Rows.Count: " + tdbQuotationInfo.Rows.Count);
			if (tdbQuotationInfo.Rows.Count > 0)
			{
				quotationObj.QuotationID = int.Parse(tdbQuotationInfo.Rows[0]["QuotationID"].ToString().Trim());
				quotationObj.FileDirectory = tdbQuotationInfo.Rows[0]["FileDirectory"].ToString().Trim();
				quotationObj.Version = double.Parse(tdbQuotationInfo.Rows[0]["Version"].ToString().Trim());
				quotationObj.Status = int.Parse(tdbQuotationInfo.Rows[0]["Status"].ToString().Trim());
				quotationObj.ImportTime = DateTime.Parse(tdbQuotationInfo.Rows[0]["ImportTime"].ToString());
				quotationObj.EffectiveTime = tdbQuotationInfo.Rows[0]["EffectiveTime"].ToString();
				quotationObj.Seq = int.Parse(tdbQuotationInfo.Rows[0]["Seq"].ToString());
				quotationObj.CentralBankCoreRate = tdbQuotationInfo.Rows[0]["CentralBankCoreRate"].ToString().Trim();
				quotationObj.TC = tdbQuotationInfo.Rows[0]["TC"].ToString().Trim();
			}
			else
			{
				return null;
			}
			return quotationObj;
		}

        /// <summary>
        /// Get previous Quotation in current date
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public clsMDQuotationDTO GetPreviousQuotationViewDetail(int iCurrentQuotationID)
        {
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@quotationID", iCurrentQuotationID);

            clsMDQuotationDTO quotationObj = new clsMDQuotationDTO();
            DataTable tdbQuotationInfo = m_DAL.ExecuteDataReader("dbo.spMD_GetPreviousQuotationViewDetail", CommandType.StoredProcedure, parameters);
            Console.WriteLine("Rows.Count: " + tdbQuotationInfo.Rows.Count);
            if (tdbQuotationInfo.Rows.Count > 0)
            {
                quotationObj.QuotationID = int.Parse(tdbQuotationInfo.Rows[0]["QuotationID"].ToString().Trim());
                quotationObj.FileDirectory = tdbQuotationInfo.Rows[0]["FileDirectory"].ToString().Trim();
                quotationObj.Version = double.Parse(tdbQuotationInfo.Rows[0]["Version"].ToString().Trim());
                quotationObj.Status = int.Parse(tdbQuotationInfo.Rows[0]["Status"].ToString().Trim());
                quotationObj.ImportTime = DateTime.Parse(tdbQuotationInfo.Rows[0]["ImportTime"].ToString());
                quotationObj.EffectiveTime = tdbQuotationInfo.Rows[0]["EffectiveTime"].ToString();
                quotationObj.Seq = int.Parse(tdbQuotationInfo.Rows[0]["Seq"].ToString());
                quotationObj.CentralBankCoreRate = tdbQuotationInfo.Rows[0]["CentralBankCoreRate"].ToString().Trim();
                quotationObj.TC = tdbQuotationInfo.Rows[0]["TC"].ToString().Trim();
            }
            else
            {
                return null;
            }
            return quotationObj;
        }

		/// <summary>
		/// Update Quotation Info, quotation detail, quotation ec rate
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
        public int UpdateQuotationInCaseOverride(clsMDQuotationDTO quotationDTO, List<clsMDQuotationDetailDTO> listDetail, List<clsMDQuotationECRateDTO> listECRate, clsCOMExternalTransactionLogDTO externalLog)
		{
			try
			{
				SqlParameter[] parameters;
				int row = 0;
				if (quotationDTO != null)
				{
					parameters = new SqlParameter[11];
					parameters[0] = new SqlParameter("@quotationID", quotationDTO.QuotationID);
					parameters[1] = new SqlParameter("@fileDirectory", quotationDTO.FileDirectory);
					parameters[2] = new SqlParameter("@version", quotationDTO.Version);
					parameters[3] = new SqlParameter("@status", quotationDTO.Status);
					parameters[4] = new SqlParameter("@importDate", quotationDTO.ImportTime);
					parameters[5] = new SqlParameter("@effectiveTime", quotationDTO.EffectiveTime);
					parameters[6] = new SqlParameter("@seq", quotationDTO.Seq);
					parameters[7] = new SqlParameter("@centralBankCoreRate", quotationDTO.CentralBankCoreRate);
					parameters[8] = new SqlParameter("@tc", quotationDTO.TC);
					parameters[9] = new SqlParameter("@createdBy", quotationDTO.CreatedBy);
					parameters[10] = new SqlParameter("@isActive", quotationDTO.IsActive);
					row = m_DAL.ExecuteNonQueryWithTransaction("dbo.spMD_UpdateQuotationInfo", CommandType.StoredProcedure, parameters);
					m_DAL.ClearParameter();
					if (row > 0)//updata quotation success
					{
						//update details
						//Delete all old quotation details
						parameters = new SqlParameter[1];
						parameters[0] = new SqlParameter("@quotationID", quotationDTO.QuotationID);
						m_DAL.ExecuteNonQueryWithTransaction("dbo.spMD_DeleteQuotationDetail", CommandType.StoredProcedure, parameters);
						//Insert new quotation detail
						int rowDetail = 0;
						if (listDetail.Count > 0)
						{
							foreach (clsMDQuotationDetailDTO dtoDetail in listDetail)
							{
								parameters = new SqlParameter[11];
								parameters[0] = new SqlParameter("@quotationID", quotationDTO.QuotationID);
								parameters[1] = new SqlParameter("@exchangeCCYPairID", dtoDetail.ExchangeCCYPairID);
								parameters[2] = new SqlParameter("@ttm", dtoDetail.TTM);
								parameters[3] = new SqlParameter("@ttb", dtoDetail.TTB);
								parameters[4] = new SqlParameter("@tts", dtoDetail.TTS);
								parameters[5] = new SqlParameter("@csb", dtoDetail.CSB);
								parameters[6] = new SqlParameter("@css", dtoDetail.CSS);
								parameters[7] = new SqlParameter("@ttbRate", dtoDetail.TTBRate);
								parameters[8] = new SqlParameter("@ttsRate", dtoDetail.TTSRate);
								parameters[9] = new SqlParameter("@againstCCY", dtoDetail.AgainstCCY);
								parameters[10] = new SqlParameter("@formatNumber ", dtoDetail.FormatNumber);
								rowDetail = m_DAL.ExecuteNonQueryWithTransaction("dbo.spMD_CreateQuotationDetail", CommandType.StoredProcedure, parameters);
								m_DAL.ClearParameter();
								if (rowDetail == 0)
								{
									//if can not insert
									//rollback and stop process
									RollBack();
                                    return rowDetail;
								}
								//if insert success, continous
							}
						}
						//Delete all old quotation ec rate
						parameters = new SqlParameter[1];
						parameters[0] = new SqlParameter("@quotationID", quotationDTO.QuotationID);
						m_DAL.ExecuteNonQueryWithTransaction("dbo.spMD_DeleteQuotationECRate", CommandType.StoredProcedure, parameters);
						m_DAL.ClearParameter();
						//insert quotation ec rate
						if (listECRate.Count > 0)
						{
							foreach (clsMDQuotationECRateDTO dtoECRate in listECRate)
							{
								parameters = new SqlParameter[8];
								parameters[0] = new SqlParameter("@quotationID", quotationDTO.QuotationID);
								parameters[1] = new SqlParameter("@exchangeCCYPairID", dtoECRate.ExchangeCCYPairID);
								parameters[2] = new SqlParameter("@custRateBuy", dtoECRate.CustRateBuy);
								parameters[3] = new SqlParameter("@aGroupECBuy", dtoECRate.AGroupECBuy);
								parameters[4] = new SqlParameter("@bGroupECBuy", dtoECRate.BGroupECBuy);
								parameters[5] = new SqlParameter("@custRateSell", dtoECRate.CustRateSell);
								parameters[6] = new SqlParameter("@aGroupECSell", dtoECRate.AGroupECSell);
								parameters[7] = new SqlParameter("@bGroupECSell", dtoECRate.BGroupECSell);
								rowDetail = m_DAL.ExecuteNonQueryWithTransaction("dbo.spMD_CreateQuotationECRate", CommandType.StoredProcedure, parameters);
								m_DAL.ClearParameter();
								if (rowDetail == 0)
								{
									//if can not insert
									//rollback and stop process
									RollBack();
                                    return rowDetail;
								}
								//if insert success, continous
							}
						}
                        m_DAL.ClearParameter();
                        //save impot log
                        parameters = new SqlParameter[8];
                        parameters[0] = new SqlParameter("@module", externalLog.Module);
                        parameters[1] = new SqlParameter("@userImport", externalLog.UserNo);// externalTransactionLogObj.UserName);????
                        parameters[2] = new SqlParameter("@importDate", externalLog.LogDate);
                        parameters[3] = new SqlParameter("@fileName", externalLog.FileName);
                        parameters[4] = new SqlParameter("@filePath", externalLog.FilePath);
                        parameters[5] = new SqlParameter("@fileType", externalLog.FileType);
                        parameters[6] = new SqlParameter("@invalidData", externalLog.InvalidData);
                        parameters[7] = new SqlParameter("@errorMessage", externalLog.ErrorMessage);
                        int iSaveLog = m_DAL.ExecuteNonQueryWithTransaction("dbo.spCOM_ImportExternalTransactionLog", CommandType.StoredProcedure, parameters);
                        if (iSaveLog == 0)
                        {
                            RollBack();
                            return iSaveLog;
                        }
					}
					else//updata quotation unsuccess
					{
						//rollback and stop process
						RollBack();
						return row;
					}
				}//Commit
				this.Commit();
				return row;
			}
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}

		/// <summary>
		/// Insert Quotation Info, quotation detail, quotation ec rate
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
        public int CreateQuotationInfo(ref clsMDQuotationDTO quotationDTO, clsMDQuotationDTO preQuotationDTO, List<clsMDQuotationDetailDTO> listDetail, List<clsMDQuotationECRateDTO> listECRate, clsCOMExternalTransactionLogDTO externalLog)
		{
			try
			{
				SqlParameter[] parameters;
				int row = 0;
				if (quotationDTO != null)
				{
					object outParamName = "@quotationID";
					parameters = new SqlParameter[10];
					parameters[0] = new SqlParameter("@fileDirectory", quotationDTO.FileDirectory);
					parameters[1] = new SqlParameter("@version", quotationDTO.Version);
					parameters[2] = new SqlParameter("@status", quotationDTO.Status);
					parameters[3] = new SqlParameter("@importDate", quotationDTO.ImportTime);
					parameters[4] = new SqlParameter("@effectiveTime", quotationDTO.EffectiveTime);
					parameters[5] = new SqlParameter("@seq", quotationDTO.Seq);
					parameters[6] = new SqlParameter("@centralBankCoreRate", quotationDTO.CentralBankCoreRate);
					parameters[7] = new SqlParameter("@tc", quotationDTO.TC);
					parameters[8] = new SqlParameter("@createdBy", quotationDTO.CreatedBy);
					parameters[9] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
					parameters[9].Value = quotationDTO.QuotationID;
					parameters[9].Direction = ParameterDirection.InputOutput;
					m_DAL.ExecuteNonQueryWithReturn("dbo.spMD_CreateQuotation", CommandType.StoredProcedure, parameters, ref outParamName);
					if (outParamName != null)
					{
						row = int.Parse(outParamName.ToString());
						if (row > 0)
						{
							quotationDTO.QuotationID = int.Parse(outParamName.ToString());
						}
					}
					m_DAL.ClearParameter();
					if (row > 0)//updata quotation success
					{
						//Insert new quotation detail
						int rowDetail = 0;
						if (listDetail.Count > 0)
						{
							foreach (clsMDQuotationDetailDTO dtoDetail in listDetail)
							{
								parameters = new SqlParameter[11];
								parameters[0] = new SqlParameter("@quotationID", quotationDTO.QuotationID);
								parameters[1] = new SqlParameter("@exchangeCCYPairID", dtoDetail.ExchangeCCYPairID);
								parameters[2] = new SqlParameter("@ttm", dtoDetail.TTM);
								parameters[3] = new SqlParameter("@ttb", dtoDetail.TTB);
								parameters[4] = new SqlParameter("@tts", dtoDetail.TTS);
								parameters[5] = new SqlParameter("@csb", dtoDetail.CSB);
								parameters[6] = new SqlParameter("@css", dtoDetail.CSS);
								parameters[7] = new SqlParameter("@ttbRate", dtoDetail.TTBRate);
								parameters[8] = new SqlParameter("@ttsRate", dtoDetail.TTSRate);
								parameters[9] = new SqlParameter("@againstCCY", dtoDetail.AgainstCCY);
								parameters[10] = new SqlParameter("@formatNumber ", dtoDetail.FormatNumber);
								rowDetail = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_CreateQuotationDetail", CommandType.StoredProcedure, parameters);
								m_DAL.ClearParameter();
								if (rowDetail == 0)
								{
									//if can not insert
									//rollback and stop process
									RollBack();
									return row;
								}
								//if insert success, continuous
							}
						}
						//insert quotation ec rate
						if (listECRate.Count > 0)
						{
							foreach (clsMDQuotationECRateDTO dtoECRate in listECRate)
							{
								parameters = new SqlParameter[8];
								parameters[0] = new SqlParameter("@quotationID", quotationDTO.QuotationID);
								parameters[1] = new SqlParameter("@exchangeCCYPairID", dtoECRate.ExchangeCCYPairID);
								parameters[2] = new SqlParameter("@custRateBuy", dtoECRate.CustRateBuy);
								parameters[3] = new SqlParameter("@aGroupECBuy", dtoECRate.AGroupECBuy);
								parameters[4] = new SqlParameter("@bGroupECBuy", dtoECRate.BGroupECBuy);
								parameters[5] = new SqlParameter("@custRateSell", dtoECRate.CustRateSell);
								parameters[6] = new SqlParameter("@aGroupECSell", dtoECRate.AGroupECSell);
								parameters[7] = new SqlParameter("@bGroupECSell", dtoECRate.BGroupECSell);
								rowDetail = m_DAL.ExecuteNonQueryWithTransaction("dbo.spMD_CreateQuotationECRate", CommandType.StoredProcedure, parameters);
								m_DAL.ClearParameter();
								if (rowDetail == 0)
								{
									//if can not insert
									//rollback and stop process
									RollBack();
									return row;
								}
								//if insert success, continuous
							}
						}                        
					}
					else//updata quotation unsuccess
					{
						//rollback and stop process
						RollBack();
						return row;
					}
				}
				if (preQuotationDTO != null)
				{
					parameters = new SqlParameter[2];
					parameters[0] = new SqlParameter("@quotationID", preQuotationDTO.QuotationID);
					parameters[1] = new SqlParameter("@status", preQuotationDTO.Status);
					row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_UpdateQuotationStatus", CommandType.StoredProcedure, parameters);
					if (row == 0)
					{
						//rollback and stop process
						RollBack();
						return row;
					}
				}
                m_DAL.ClearParameter();
                //save impot log
                parameters = new SqlParameter[8];
                parameters[0] = new SqlParameter("@module", externalLog.Module);
                parameters[1] = new SqlParameter("@userImport", externalLog.UserNo);// externalTransactionLogObj.UserName);????
                parameters[2] = new SqlParameter("@importDate", externalLog.LogDate);
                parameters[3] = new SqlParameter("@fileName", externalLog.FileName);
                parameters[4] = new SqlParameter("@filePath", externalLog.FilePath);
                parameters[5] = new SqlParameter("@fileType", externalLog.FileType);
                parameters[6] = new SqlParameter("@invalidData", externalLog.InvalidData);
                parameters[7] = new SqlParameter("@errorMessage", externalLog.ErrorMessage);
                int iSaveLog = m_DAL.ExecuteNonQueryWithTransaction("dbo.spCOM_ImportExternalTransactionLog", CommandType.StoredProcedure, parameters);
                if (iSaveLog == 0)
                {
                    RollBack();
                    return iSaveLog;
                }
				//Commit
				this.Commit();
				return row;
			}
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}

		/// <summary>
		/// Get last path
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
		public string GetLastestFileDirectoryOfQuotation()
		{
			clsMDQuotationDTO quotationObj = new clsMDQuotationDTO();
			DataTable tdbQuotationInfo = m_DAL.ExecuteDataReader("dbo.spMD_GetLastestFileDirectoryOfQuotation", CommandType.StoredProcedure);
			Console.WriteLine("Rows.Count: " + tdbQuotationInfo.Rows.Count);
			if (tdbQuotationInfo.Rows.Count > 0)
			{
				return tdbQuotationInfo.Rows[0]["FileDirectory"].ToString().Trim();
			}
			else
			{
				return string.Empty;
			}
		}

		/// <summary>
		/// commit transaction
		/// </summary>
		/// @cond
		/// Author: phuong lap co
		/// @endcond
		public void Commit()
		{
			m_DAL.m_transaction.Commit();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

		/// <summary>
		/// rollback transaction
		/// </summary>
		/// @cond
		/// Author: phuong lap co
		/// @endcond
		public void RollBack()
		{
            if (m_DAL.m_transaction != null)
            {
                m_DAL.m_transaction.Rollback();
            }
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

		/// <summary>
		/// Get latest quotation status
		/// </summary>
		/// <returns>Status value </returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int GetLatestQuotationStatus()
		{
            try
            {
                return m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spMD_GetLatestQuotationStatus", CommandType.StoredProcedure, new SqlParameter[0]);
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}

		/// <summary>
		/// Get list of Currency Inquiry Quotation History
		/// Return DataTable(Seq, Date, Time, InActive, CCY Pair, TTM, TTB, TTS, CSB, CSS)
		/// </summary>
		/// <param name="strSelectedCCYPair"></param>
		/// <param name="dateFrom"></param>
		/// <param name="dateTo"></param>
		/// <param name="iStatusApprove"></param>
		/// <returns></returns>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
        public DataTable GetCurrencyInquiryQuotationHistoryList(string strSelectedCCYPair, DateTime dateFrom, DateTime dateTo, int iStatusApprove, int iSelectedIsActive)
		{
			SqlParameter[] parameters = new SqlParameter[5];
			parameters[0] = new SqlParameter("@selectedCCYPair", strSelectedCCYPair);
			parameters[1] = new SqlParameter("@dateFrom", dateFrom);
			parameters[2] = new SqlParameter("@dateTo", dateTo);
			parameters[3] = new SqlParameter("@iStatusApprove", iStatusApprove);
            parameters[4] = new SqlParameter("@iSelectedIsActive", iSelectedIsActive);
			return m_DAL.ExecuteDataReader("dbo.spMD_GetCurrencyInquiryQuotationHistoryList", CommandType.StoredProcedure, parameters);
		}

		/// <summary>
		/// Get list of Inquiry Quotation History
		/// Return DataTable(Seq, Status, InActive, Remark, Date, Time, Maker, Approver)
		/// </summary>
		/// <param name="strSelectedCCYPair"></param>
		/// <param name="dateFrom"></param>
		/// <param name="dateTo"></param>
		/// <param name="iStatusApprove"></param>
		/// <returns></returns>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
        public DataTable GetInquiryQuotationHistoryList(DateTime dateFrom, DateTime dateTo, int iSelectedStatus, int iSelectedIsActive)
		{
			SqlParameter[] parameters = new SqlParameter[4];
			parameters[0] = new SqlParameter("@dateFrom", dateFrom);
			parameters[1] = new SqlParameter("@dateTo", dateTo);
			parameters[2] = new SqlParameter("@iSelectedStatus", iSelectedStatus);
            parameters[3] = new SqlParameter("@iSelectedIsActive", iSelectedIsActive);
			return m_DAL.ExecuteDataReader("dbo.spMD_GetInquiryQuotationHistoryList", CommandType.StoredProcedure, parameters);
		}
		
		/// <summary>
		/// Get list of Inquiry Quotation History
		/// Return DataTable(Seq, Status, InActive, Remark, Date, Time, Maker, Approver)
		/// </summary>
		/// <param name="strSelectedCCYPair"></param>
		/// <param name="dateFrom"></param>
		/// <param name="dateTo"></param>
		/// <param name="iStatusApprove"></param>
		/// <returns></returns>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
		public int ChecQuotationFreeze(int iQuotationID)
		{
            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@quotationID", iQuotationID);
                DataTable dtb = m_DAL.ExecuteDataReader("dbo.spMD_CheckQuotationFreeze", CommandType.StoredProcedure, parameters);
                Console.WriteLine(dtb.Rows[0][0].ToString());
                Console.WriteLine("iQuotationID: " + iQuotationID);
                return int.Parse(dtb.Rows[0][0].ToString());
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}
		
		/// <summary>
		/// Get last quotation ID
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int GetQuotationIDLast()
		{
			DataTable dtb = m_DAL.ExecuteDataReader("dbo.spMD_QuotationIDLast", CommandType.StoredProcedure);			
			return dtb.Rows[0][0].ToString() == "" ? -1 : int.Parse(dtb.Rows[0][0].ToString());
		}

        ///// <summary>
        ///// Get apprived Quotation in current date
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        ///// @cond
        ///// Author: vlhcnhung
        ///// @endcond
        //public int GetIDOfApprovedQuotationToday()
        //{            
        //    DataTable tdbQuotationInfo = m_DAL.ExecuteDataReader("dbo.spMD_GetApprovedQuotationToday", CommandType.StoredProcedure);
        //    if (tdbQuotationInfo.Rows.Count > 0)
        //    {
        //        return int.Parse(tdbQuotationInfo.Rows[0]["QuotationID"].ToString().Trim());
        //    }
        //    else
        //    {
        //        return -1;
        //    }
        //}
	}
}