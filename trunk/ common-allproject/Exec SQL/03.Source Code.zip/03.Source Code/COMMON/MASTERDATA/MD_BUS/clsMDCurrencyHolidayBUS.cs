﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-27 (Wed, 27 March 2013) $
 * ========================================================
 * This class is used to implement business logic for CurrencyHoliday
 * Master Data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phoenix.Common.MasterData.Dal;
using System.Data;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDCurrencyHolidayBUS
    {
        clsMDCurrencyHolidayDAL m_DAL = null;

        private static clsMDCurrencyHolidayBUS instance;
        public static clsMDCurrencyHolidayBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDCurrencyHolidayBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public clsMDCurrencyHolidayBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsMDCurrencyHolidayDAL();
            }
        }        

        /// <summary>
        /// Get list of registed holiday years
        /// Return DataTable(HolidayYear)
        /// </summary>      
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetYearList()
        {
            return m_DAL.GetYearList();
        }        

        /// <summary>
        /// Get list of all currency based on input params
        /// Return DataTable(HolidayMonth, HolidayDate)
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="iMonth"></param>
        /// <param name="iYear"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetCurrencyHolidayList(int iYear, string strCCY)
        {
            return m_DAL.GetCurrencyHolidayList(iYear, strCCY);
        }

        /// <summary>
        /// Get list of CCY registed holiday in this date 
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="iMonth"></param>
        /// <param name="iYear"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public string GetSelectedHolidayInfo(DateTime date)
        {
            string strCCY = string.Empty;
            DataTable dt = m_DAL.GetSelectedHolidayInfo(date);
            if (dt != null && dt.Rows.Count > 0)
            {
                strCCY = dt.Rows[0][0].ToString().Trim();
                if (strCCY[strCCY.Length - 1].CompareTo(char.Parse(",")) == 0)
                {
                    strCCY = strCCY.Substring(0, strCCY.Length - 1);
                }
            }
            return strCCY;
        }

        /// <summary>
        /// Get list of all currency based on input params to export excel
        /// Return DataTable(CCY, YEAR, HolidayDate)
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="iMonth"></param>
        /// <param name="iYear"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public DataTable GetCurrencyHolidayExportList(int iYear, string strCCY)
        {
            return m_DAL.GetCurrencyHolidayExportList(iYear, strCCY);
        }

        /// <summary>
        /// Save list of selected holiday of 12 months
        /// </summary>
        /// <param name="strCCY"></param>
        /// <param name="iUserNo"></param>
        /// <param name="listDeletedDate"></param>
        /// <param name="listInsertedDate"></param>
        /// <param name="listUpdatedDate"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public int SaveCurrencyHolidayList(string strCCY, int iUserNo, List<DateTime> listDeletedDate, List<DateTime> listInsertedDate, List<DateTime> listUpdatedDate, clsMDLogBase logBase)
        {
            try
            {
                int iRow = 0;
                //delete old holidays are not in new list selected holiday.
                if (listDeletedDate.Count > 0)
                {
                    int row = m_DAL.DeleteCurrencyHoliday(strCCY, listDeletedDate);
                    if (row == 0)
                    {
                        m_DAL.RollBack();
                        return iRow;
                    }
                    iRow += row;
                }
                //insert new list selected holiday.
                if (listInsertedDate.Count > 0)
                {
                    int row = m_DAL.InsertCurrencyHoliday(strCCY, iUserNo, listInsertedDate);
                    if (row == 0)
                    {
                        m_DAL.RollBack();
                        return iRow;
                    }
                    iRow += row;
                }
                //update old holidays are not in new list selected holiday.
                if (listUpdatedDate.Count > 0)
                {
                    int row = m_DAL.UpdateCurrencyHoliday(strCCY, iUserNo, listUpdatedDate);
                    if (row == 0)
                    {
                        m_DAL.RollBack();
                        return iRow;
                    }
                    iRow += row;
                }                
                //if successfull
                if (iRow > 0)
                {
                    //system will save log                     
                    logBase.WirteLog(m_DAL);
                    //commit all changes
                    m_DAL.Commit();
                }
                return iRow;
            }
            catch(Exception ex)
            {
                //Rollback if having errors
                m_DAL.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
        }
    }
}
