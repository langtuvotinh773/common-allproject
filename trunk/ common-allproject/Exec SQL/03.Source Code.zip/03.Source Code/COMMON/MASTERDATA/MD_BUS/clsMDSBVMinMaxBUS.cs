﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.MasterData.Dal;
using Phoenix.Common.MasterData.Dto;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Com;
using Config.Classes;

namespace Phoenix.Common.MasterData.Bus
{
    public class clsMDSBVMinMaxBUS
    {
        clsDataAccessLayer m_DAL = null;
        #region Properties
        public clsDataAccessLayer DAL
        {
            get
            {
                return m_DAL;
            }
        }
        #endregion
        private static clsMDSBVMinMaxBUS instance;
        public static clsMDSBVMinMaxBUS Instance()
        {
            if (instance == null)
            {
                instance = new clsMDSBVMinMaxBUS();
            }
            return instance;

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsMDSBVMinMaxBUS()
        {
            if (m_DAL == null)
            {
                m_DAL = new clsDataAccessLayer();
            }
        }

        /// <summary>
        /// commit transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// Get SBV Min Max List
        /// </summary>
        /// <param name="CCY"></param>
        /// <param name="transType"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsMDSBVMinMaxDTO> GetSBVMinMaxList(string CCY, int transType)
        {
            List<clsMDSBVMinMaxDTO> lst = new List<clsMDSBVMinMaxDTO>();
            DataTable dt = new DataTable();
            SqlParameter[] parameters = new SqlParameter[2];
            if (clsMDFunction.isNullOrEmpty(CCY))
            {
                parameters[0] = new SqlParameter("@CCY", DBNull.Value);
            }
            else
            {
                parameters[0] = new SqlParameter("@CCY", CCY);
            }

            if (transType == 0)
            {
                parameters[1] = new SqlParameter("@TransType", DBNull.Value);
            }
            else
            {
                parameters[1] = new SqlParameter("@TransType", transType);
            }

            dt = m_DAL.ExecuteDataReader("spMD_GetSBVMinMaxList", CommandType.StoredProcedure, parameters);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    lst.Add(new clsMDSBVMinMaxDTO().GetSBVMinMaxDTO(dt.Rows[i]));
                }
            }
            return lst;
        }

        /// <summary>
        /// Get SBV Min Max
        /// </summary>
        /// <param name="CCY"></param>
        /// <param name="transType"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsMDSBVMinMaxDTO GetSBVMinMax(short id)
        {
            clsMDSBVMinMaxDTO dto = new clsMDSBVMinMaxDTO();
            DataTable dt = new DataTable();
            SqlParameter[] parameters = new SqlParameter[1];

            parameters[0] = new SqlParameter("@SBVMinMaxID", id);

            dt = m_DAL.ExecuteDataReader("spMD_GetSBVMinMax", CommandType.StoredProcedure, parameters);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dto = new clsMDSBVMinMaxDTO().GetSBVMinMaxDTOToUpdate(dt.Rows[i]);
                }
            }
            else
            {
                dto = null;
            }
            return dto;
        }

        /// <summary>
        /// Insert SBV Min Max
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public int InsertSBVMinMax(clsMDSBVMinMaxDTO dto)
        {
            int row = 0;
            object identity;
            SqlParameter[] parameters = new SqlParameter[9];
            List<SqlParameter[]> lstParameter = new List<SqlParameter[]>();
            //set parameters
            parameters[0] = new SqlParameter("@CCY", dto.CCY);
            parameters[1] = new SqlParameter("@Tenor", dto.Tenor);
            parameters[2] = new SqlParameter("@TransType", dto.TransType);
            parameters[3] = new SqlParameter("@DepositMin", dto.DepositMin);
            parameters[4] = new SqlParameter("@DepositMax", dto.DepositMax);
            parameters[5] = new SqlParameter("@TDMin", dto.TDMin);
            parameters[6] = new SqlParameter("@TDMax", dto.TDMax);
            parameters[7] = new SqlParameter("@CreatedBy", clsUserInfo.UserNo);
            parameters[8] = new SqlParameter("@UpdatedBy", dto.UpdatedBy);

            row = m_DAL.ExecuteNonQueryWithTransactionOutValue("spMD_InsertSBVMinMax", CommandType.StoredProcedure, parameters, out identity);
            if (row > 0)
            {
                dto.SBVMinMaxID = Convert.ToInt16(identity);
            }
            return row;
        }

        /// <summary>
        /// Update SBV Min Max
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public int UpdateSBVMinMax(clsMDSBVMinMaxDTO dto)
        {
            int row = 0;
            object identity;
            SqlParameter[] parameters = new SqlParameter[9];
            List<SqlParameter[]> lstParameter = new List<SqlParameter[]>();
            //set parameters
            parameters[0] = new SqlParameter("@SBVMinMaxID", dto.SBVMinMaxID);
            parameters[1] = new SqlParameter("@CCY", dto.CCY);
            parameters[2] = new SqlParameter("@Tenor", dto.Tenor);
            parameters[3] = new SqlParameter("@TransType", dto.TransType);
            parameters[4] = new SqlParameter("@DepositMin", dto.DepositMin);
            parameters[5] = new SqlParameter("@DepositMax", dto.DepositMax);
            parameters[6] = new SqlParameter("@TDMin", dto.TDMin);
            parameters[7] = new SqlParameter("@TDMax", dto.TDMax);
            parameters[8] = new SqlParameter("@UpdatedBy", clsUserInfo.UserNo);

            row = m_DAL.ExecuteNonQueryWithTransactionOutValue("spMD_UpdateSBVMinMax", CommandType.StoredProcedure, parameters, out identity);

            return row;
        }
    }
}
