﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to access data for comboboxes
 * of Master Data module.
 */
using System.Collections.Generic;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Dto;

namespace Phoenix.Common.MasterData.Bus
{

	/// <summary>
	/// this class use to get data in combobox
	/// </summary>
	/// @cond
	/// Author: Yen Phan
	/// @endcond
	public class clsMDGetDataCombobox
	{
		/// <summary>
		/// clsMDGetDataCombobox object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private static clsMDGetDataCombobox m_Style;

		/// <summary>
		/// Status list
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private List<CbbObject> status;
		public List<CbbObject> Status
		{
			get { return status; }
			set { status = value; }
		}

		///// <summary>
		///// Status of inquiry quotation history
		///// </summary>
		//private List<CbbObject> statusInquiryQuotationHistory;
		//public List<CbbObject> StatusInquiryQuotationHistory
		//{
		//    get { return statusInquiryQuotationHistory; }
		//    set { statusInquiryQuotationHistory = value; }
		//}

		/// <summary>
		/// Currency pair list
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private List<CbbObject> currencyPair;
		public List<CbbObject> CurrencyPair
		{
			get { return currencyPair; }
			set { currencyPair = value; }
		}
	
		/// <summary>
		/// Currency pair without empty item list
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private List<CbbObject> currencyPairWithoutEmptyItem;
		public List<CbbObject> CurrencyPairWithoutEmptyItem
		{
			get { return currencyPairWithoutEmptyItem; }
			set { currencyPairWithoutEmptyItem = value; }
		}
		
		/// <summary>
		/// Currency list
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private List<CbbObject> currency;
		public List<CbbObject> Currency
		{
			get { return currency; }
			set { currency = value; }
		}
	
		/// <summary>
		/// Currency without empty item list
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private List<CbbObject> currencyWithoutEmptyItem;
		public List<CbbObject> CurrencyWithoutEmptyItem
		{
			get { return currencyWithoutEmptyItem; }
			set { currencyWithoutEmptyItem = value; }
		}
		
		/// <summary>
		/// Transaction type list
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private List<CbbObject> transactionType;
		public List<CbbObject> TransactionType
		{
			get { return transactionType; }
			set { transactionType = value; }
		}
		 
		/// <summary>
		/// Transaction type without empty item list
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private List<CbbObject> transactionTypeWithoutEmptyItem;
		public List<CbbObject> TransactionTypeWithoutEmptyItem
		{
			get { return transactionTypeWithoutEmptyItem; }
			set { transactionTypeWithoutEmptyItem = value; }
		}

		/// <summary>
		/// Get instance of clsMDDataCombobox
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static clsMDGetDataCombobox Instance()
		{
			if (m_Style == null)
			{
				m_Style = new clsMDGetDataCombobox();
			}

			return m_Style;
		}

        /// <summary>
        /// Customer type list
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private List<CbbObject> customerType;
        public List<CbbObject> CustomerType
        {
            get { return customerType; }
            set { customerType = value; }
        }

        /// <summary>
        /// Customer code list
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private List<CbbObject> customerCode;
        public List<CbbObject> CustomerCode
        {
            get { return customerCode; }
            set { customerCode = value; }
        }

        ///// <summary>
        ///// Customer name list
        ///// </summary>
        ///// @cond
        ///// Author: pqkhai
        ///// @endcond
        //private List<CbbObject> customerName;
        //public List<CbbObject> CustomerName
        //{
        //    get { return customerName; }
        //    set { customerName = value; }
        //}

        /// <summary>
        /// Customer FXAT Code list
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private List<CbbObject> fXATCode;
        public List<CbbObject> FXATCode
        {
            get { return fXATCode; }
            set { fXATCode = value; }
        }

        /// <summary>
        /// Customer Location Code list
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private List<CbbObject> locationCode;
        public List<CbbObject> LocationCode
        {
            get { return locationCode; }
            set { locationCode = value; }
        }

		/// <summary>
		/// Load data for comboboxes: transaction type, status, currency pair, currency pair without empty item,
		/// currency, currency without empty item, status of inquiry quotation history
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void LoadData()
		{
			transactionType = clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_TRANSACTION_TYPE);
			TransactionTypeWithoutEmptyItem = clsMDBus.Instance().GetListMDParametersWithoutEmptyItem(clsMDConstant.PARAMETERS_TRANSACTION_TYPE);
			status = clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_STATUS);
			currencyPair = clsMDCeilingFloorBUS.Instance().GetCurencyPairList();
			CurrencyPairWithoutEmptyItem = clsMDCeilingFloorBUS.Instance().GetCurencyPairListWithoutEmptyItem();
			currency = clsMDCeilingFloorBUS.Instance().GetCurencyList();
			currencyWithoutEmptyItem = clsMDCeilingFloorBUS.Instance().GetCurencyListWithoutEmptyItem();
			//statusInquiryQuotationHistory = clsMDBus.Instance().LoadStatusInquiryQuotationHistory();
            customerType = clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_CUSTOMER_TYPE);
           // customerName = clsMDCustomerBUS.Instance().GetNameCustomerList();

 		}
	}
}