﻿namespace Phoenix.Common.MasterData.Gui
{
	partial class frmMDQuotationDetail
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMDQuotationDetail));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelDetail = new System.Windows.Forms.Panel();
            this.panelButtonControl = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnPrintPreview = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ckbInActive = new System.Windows.Forms.CheckBox();
            this.grpRemark = new System.Windows.Forms.GroupBox();
            this.txtRemark = new UserCtrl.ctrlMDDisableTextBox();
            this.grpFretext4 = new System.Windows.Forms.GroupBox();
            this.txtNoteEnd = new UserCtrl.ctrlMDDisableTextBox();
            this.txtMaker = new UserCtrl.DisableTextBox();
            this.txtStatus = new UserCtrl.DisableTextBox();
            this.dtgQuotationECRateList = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.grpFretext3 = new System.Windows.Forms.GroupBox();
            this.txtNoteMid = new UserCtrl.ctrlMDDisableTextBox();
            this.grpFretext2 = new System.Windows.Forms.GroupBox();
            this.txtNoteThreshold = new UserCtrl.ctrlMDDisableTextBox();
            this.disableTextBox2 = new UserCtrl.DisableTextBox();
            this.txtTC = new UserCtrl.DisableTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dtgQuotationVND = new System.Windows.Forms.DataGridView();
            this.colCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTTM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBuyCCYSellVND = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coSellCCYBuyVND = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBuyCCYSellVNDCash = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTIme = new System.Windows.Forms.Label();
            this.lblSeq = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFloorRate = new UserCtrl.DisableTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCeilingRate = new UserCtrl.DisableTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCentralBankCoreRate = new UserCtrl.DisableTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtgQuotationUSD = new System.Windows.Forms.DataGridView();
            this.CCYColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TTMColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TTBColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TTSColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CSBColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CSSColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTtbIsRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTtsIsRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpFretext1 = new System.Windows.Forms.GroupBox();
            this.txtNoteHead = new UserCtrl.ctrlMDDisableTextBox();
            this.panelDetail.SuspendLayout();
            this.panelButtonControl.SuspendLayout();
            this.grpRemark.SuspendLayout();
            this.grpFretext4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgQuotationECRateList)).BeginInit();
            this.grpFretext3.SuspendLayout();
            this.grpFretext2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgQuotationVND)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgQuotationUSD)).BeginInit();
            this.grpFretext1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelDetail
            // 
            this.panelDetail.AutoScroll = true;
            this.panelDetail.Controls.Add(this.panelButtonControl);
            this.panelDetail.Controls.Add(this.panel2);
            this.panelDetail.Controls.Add(this.ckbInActive);
            this.panelDetail.Controls.Add(this.grpRemark);
            this.panelDetail.Controls.Add(this.grpFretext4);
            this.panelDetail.Controls.Add(this.txtMaker);
            this.panelDetail.Controls.Add(this.txtStatus);
            this.panelDetail.Controls.Add(this.dtgQuotationECRateList);
            this.panelDetail.Controls.Add(this.label7);
            this.panelDetail.Controls.Add(this.label16);
            this.panelDetail.Controls.Add(this.grpFretext3);
            this.panelDetail.Controls.Add(this.grpFretext2);
            this.panelDetail.Controls.Add(this.disableTextBox2);
            this.panelDetail.Controls.Add(this.txtTC);
            this.panelDetail.Controls.Add(this.label13);
            this.panelDetail.Controls.Add(this.label12);
            this.panelDetail.Controls.Add(this.dtgQuotationVND);
            this.panelDetail.Controls.Add(this.lblTIme);
            this.panelDetail.Controls.Add(this.lblSeq);
            this.panelDetail.Controls.Add(this.lblDate);
            this.panelDetail.Controls.Add(this.label4);
            this.panelDetail.Controls.Add(this.label3);
            this.panelDetail.Controls.Add(this.label2);
            this.panelDetail.Controls.Add(this.txtFloorRate);
            this.panelDetail.Controls.Add(this.label6);
            this.panelDetail.Controls.Add(this.txtCeilingRate);
            this.panelDetail.Controls.Add(this.label5);
            this.panelDetail.Controls.Add(this.txtCentralBankCoreRate);
            this.panelDetail.Controls.Add(this.label1);
            this.panelDetail.Controls.Add(this.dtgQuotationUSD);
            this.panelDetail.Controls.Add(this.grpFretext1);
            this.panelDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDetail.Location = new System.Drawing.Point(0, 0);
            this.panelDetail.Name = "panelDetail";
            this.panelDetail.Size = new System.Drawing.Size(1035, 620);
            this.panelDetail.TabIndex = 0;
            this.panelDetail.Click += new System.EventHandler(this.panelDetail_Click);
            this.panelDetail.Scroll += new System.Windows.Forms.ScrollEventHandler(this.panelDetail_Scroll);
            // 
            // panelButtonControl
            // 
            this.panelButtonControl.Controls.Add(this.btnClose);
            this.panelButtonControl.Controls.Add(this.btnSave);
            this.panelButtonControl.Controls.Add(this.btnPrintPreview);
            this.panelButtonControl.Location = new System.Drawing.Point(734, 572);
            this.panelButtonControl.Name = "panelButtonControl";
            this.panelButtonControl.Size = new System.Drawing.Size(271, 40);
            this.panelButtonControl.TabIndex = 29;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(180, 8);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(94, 9);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Con&firm";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnPrintPreview
            // 
            this.btnPrintPreview.Location = new System.Drawing.Point(9, 9);
            this.btnPrintPreview.Name = "btnPrintPreview";
            this.btnPrintPreview.Size = new System.Drawing.Size(75, 23);
            this.btnPrintPreview.TabIndex = 0;
            this.btnPrintPreview.Text = "&Preview";
            this.btnPrintPreview.UseVisualStyleBackColor = true;
            this.btnPrintPreview.Click += new System.EventHandler(this.btnPrintPreview_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(896, 1976);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(97, 22);
            this.panel2.TabIndex = 28;
            // 
            // ckbInActive
            // 
            this.ckbInActive.AutoSize = true;
            this.ckbInActive.Enabled = false;
            this.ckbInActive.Location = new System.Drawing.Point(218, 1889);
            this.ckbInActive.Name = "ckbInActive";
            this.ckbInActive.Size = new System.Drawing.Size(64, 17);
            this.ckbInActive.TabIndex = 24;
            this.ckbInActive.TabStop = false;
            this.ckbInActive.Text = "Inactive";
            this.ckbInActive.UseVisualStyleBackColor = true;
            // 
            // grpRemark
            // 
            this.grpRemark.Controls.Add(this.txtRemark);
            this.grpRemark.Location = new System.Drawing.Point(12, 1911);
            this.grpRemark.Margin = new System.Windows.Forms.Padding(0);
            this.grpRemark.Name = "grpRemark";
            this.grpRemark.Padding = new System.Windows.Forms.Padding(0);
            this.grpRemark.Size = new System.Drawing.Size(990, 59);
            this.grpRemark.TabIndex = 27;
            this.grpRemark.TabStop = false;
            this.grpRemark.Text = "Remark";
            // 
            // txtRemark
            // 
            this.txtRemark.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtRemark.Location = new System.Drawing.Point(7, 18);
            this.txtRemark.MaxLength = 200;
            this.txtRemark.Multiline = true;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemark.Size = new System.Drawing.Size(976, 33);
            this.txtRemark.TabIndex = 0;
            // 
            // grpFretext4
            // 
            this.grpFretext4.Controls.Add(this.txtNoteEnd);
            this.grpFretext4.Location = new System.Drawing.Point(9, 1711);
            this.grpFretext4.Margin = new System.Windows.Forms.Padding(0);
            this.grpFretext4.Name = "grpFretext4";
            this.grpFretext4.Padding = new System.Windows.Forms.Padding(0);
            this.grpFretext4.Size = new System.Drawing.Size(996, 171);
            this.grpFretext4.TabIndex = 21;
            this.grpFretext4.TabStop = false;
            this.grpFretext4.Text = "Free Text 04:";
            // 
            // txtNoteEnd
            // 
            this.txtNoteEnd.Location = new System.Drawing.Point(11, 21);
            this.txtNoteEnd.MaxLength = 1000;
            this.txtNoteEnd.Multiline = true;
            this.txtNoteEnd.Name = "txtNoteEnd";
            this.txtNoteEnd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNoteEnd.Size = new System.Drawing.Size(976, 138);
            this.txtNoteEnd.TabIndex = 0;
            this.txtNoteEnd.Text = "A GROUP SCREEN\r\n         - FOREIGN REMITTANCE OUTWARD\r\n         - IMPORT BR SETTL" +
                "EMENT\r\n         - IMPORT BCR SETTLEMENT\r\n";
            // 
            // txtMaker
            // 
            this.txtMaker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtMaker.ForeColor = System.Drawing.Color.Black;
            this.txtMaker.Location = new System.Drawing.Point(338, 1889);
            this.txtMaker.Name = "txtMaker";
            this.txtMaker.ReadOnly = true;
            this.txtMaker.Size = new System.Drawing.Size(158, 20);
            this.txtMaker.TabIndex = 26;
            this.txtMaker.TabStop = false;
            // 
            // txtStatus
            // 
            this.txtStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtStatus.ForeColor = System.Drawing.Color.Black;
            this.txtStatus.Location = new System.Drawing.Point(54, 1888);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ReadOnly = true;
            this.txtStatus.Size = new System.Drawing.Size(158, 20);
            this.txtStatus.TabIndex = 23;
            this.txtStatus.TabStop = false;
            // 
            // dtgQuotationECRateList
            // 
            this.dtgQuotationECRateList.AllowUserToAddRows = false;
            this.dtgQuotationECRateList.AllowUserToResizeColumns = false;
            this.dtgQuotationECRateList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgQuotationECRateList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgQuotationECRateList.Enabled = false;
            this.dtgQuotationECRateList.Location = new System.Drawing.Point(9, 1399);
            this.dtgQuotationECRateList.Name = "dtgQuotationECRateList";
            this.dtgQuotationECRateList.ReadOnly = true;
            this.dtgQuotationECRateList.RowHeadersVisible = false;
            this.dtgQuotationECRateList.Size = new System.Drawing.Size(996, 309);
            this.dtgQuotationECRateList.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(293, 1892);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 25;
            this.label7.Text = "Maker";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 1891);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 13);
            this.label16.TabIndex = 22;
            this.label16.Text = "Status";
            // 
            // grpFretext3
            // 
            this.grpFretext3.Controls.Add(this.txtNoteMid);
            this.grpFretext3.Location = new System.Drawing.Point(11, 1020);
            this.grpFretext3.Margin = new System.Windows.Forms.Padding(0);
            this.grpFretext3.Name = "grpFretext3";
            this.grpFretext3.Padding = new System.Windows.Forms.Padding(0);
            this.grpFretext3.Size = new System.Drawing.Size(996, 367);
            this.grpFretext3.TabIndex = 19;
            this.grpFretext3.TabStop = false;
            this.grpFretext3.Text = "Free Text 03:";
            // 
            // txtNoteMid
            // 
            this.txtNoteMid.Location = new System.Drawing.Point(10, 20);
            this.txtNoteMid.MaxLength = 2500;
            this.txtNoteMid.Multiline = true;
            this.txtNoteMid.Name = "txtNoteMid";
            this.txtNoteMid.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNoteMid.Size = new System.Drawing.Size(976, 335);
            this.txtNoteMid.TabIndex = 0;
            this.txtNoteMid.Text = resources.GetString("txtNoteMid.Text");
            // 
            // grpFretext2
            // 
            this.grpFretext2.Controls.Add(this.txtNoteThreshold);
            this.grpFretext2.Location = new System.Drawing.Point(11, 932);
            this.grpFretext2.Margin = new System.Windows.Forms.Padding(0);
            this.grpFretext2.Name = "grpFretext2";
            this.grpFretext2.Padding = new System.Windows.Forms.Padding(0);
            this.grpFretext2.Size = new System.Drawing.Size(996, 82);
            this.grpFretext2.TabIndex = 18;
            this.grpFretext2.TabStop = false;
            this.grpFretext2.Text = "Free Text 02:";
            // 
            // txtNoteThreshold
            // 
            this.txtNoteThreshold.Location = new System.Drawing.Point(10, 19);
            this.txtNoteThreshold.MaxLength = 500;
            this.txtNoteThreshold.Multiline = true;
            this.txtNoteThreshold.Name = "txtNoteThreshold";
            this.txtNoteThreshold.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNoteThreshold.Size = new System.Drawing.Size(976, 55);
            this.txtNoteThreshold.TabIndex = 0;
            this.txtNoteThreshold.Text = resources.GetString("txtNoteThreshold.Text");
            // 
            // disableTextBox2
            // 
            this.disableTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.disableTextBox2.ForeColor = System.Drawing.Color.Black;
            this.disableTextBox2.Location = new System.Drawing.Point(804, 912);
            this.disableTextBox2.Name = "disableTextBox2";
            this.disableTextBox2.ReadOnly = true;
            this.disableTextBox2.Size = new System.Drawing.Size(100, 20);
            this.disableTextBox2.TabIndex = 16;
            this.disableTextBox2.TabStop = false;
            this.disableTextBox2.Text = "T/C";
            this.disableTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTC
            // 
            this.txtTC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtTC.ForeColor = System.Drawing.Color.Black;
            this.txtTC.Location = new System.Drawing.Point(907, 912);
            this.txtTC.Name = "txtTC";
            this.txtTC.ReadOnly = true;
            this.txtTC.Size = new System.Drawing.Size(100, 20);
            this.txtTC.TabIndex = 17;
            this.txtTC.TabStop = false;
            this.txtTC.Text = "20620";
            this.txtTC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(725, 831);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 13);
            this.label13.TabIndex = 79;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(747, 915);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "For IOD:";
            // 
            // dtgQuotationVND
            // 
            this.dtgQuotationVND.AllowUserToAddRows = false;
            this.dtgQuotationVND.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgQuotationVND.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgQuotationVND.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCCY,
            this.colTTM,
            this.colBuyCCYSellVND,
            this.coSellCCYBuyVND,
            this.colBuyCCYSellVNDCash,
            this.Column1});
            this.dtgQuotationVND.Enabled = false;
            this.dtgQuotationVND.Location = new System.Drawing.Point(11, 550);
            this.dtgQuotationVND.Name = "dtgQuotationVND";
            this.dtgQuotationVND.ReadOnly = true;
            this.dtgQuotationVND.RowHeadersVisible = false;
            this.dtgQuotationVND.Size = new System.Drawing.Size(996, 353);
            this.dtgQuotationVND.TabIndex = 14;
            // 
            // colCCY
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCCY.DefaultCellStyle = dataGridViewCellStyle1;
            this.colCCY.HeaderText = "CCY";
            this.colCCY.MinimumWidth = 30;
            this.colCCY.Name = "colCCY";
            this.colCCY.ReadOnly = true;
            // 
            // colTTM
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colTTM.DefaultCellStyle = dataGridViewCellStyle2;
            this.colTTM.HeaderText = "TTM";
            this.colTTM.Name = "colTTM";
            this.colTTM.ReadOnly = true;
            // 
            // colBuyCCYSellVND
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colBuyCCYSellVND.DefaultCellStyle = dataGridViewCellStyle3;
            this.colBuyCCYSellVND.HeaderText = "Buy CCY / Sell VND";
            this.colBuyCCYSellVND.MinimumWidth = 150;
            this.colBuyCCYSellVND.Name = "colBuyCCYSellVND";
            this.colBuyCCYSellVND.ReadOnly = true;
            // 
            // coSellCCYBuyVND
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.coSellCCYBuyVND.DefaultCellStyle = dataGridViewCellStyle4;
            this.coSellCCYBuyVND.HeaderText = "Sell CCY / Buy VND";
            this.coSellCCYBuyVND.MinimumWidth = 150;
            this.coSellCCYBuyVND.Name = "coSellCCYBuyVND";
            this.coSellCCYBuyVND.ReadOnly = true;
            // 
            // colBuyCCYSellVNDCash
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colBuyCCYSellVNDCash.DefaultCellStyle = dataGridViewCellStyle5;
            this.colBuyCCYSellVNDCash.HeaderText = "Buy CCY / Sell VND (Cash)";
            this.colBuyCCYSellVNDCash.MinimumWidth = 180;
            this.colBuyCCYSellVNDCash.Name = "colBuyCCYSellVNDCash";
            this.colBuyCCYSellVNDCash.ReadOnly = true;
            // 
            // Column1
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column1.HeaderText = "Sell CCY / Buy VND (Cash)";
            this.Column1.MinimumWidth = 180;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // lblTIme
            // 
            this.lblTIme.Location = new System.Drawing.Point(934, 37);
            this.lblTIme.Name = "lblTIme";
            this.lblTIme.Size = new System.Drawing.Size(64, 13);
            this.lblTIme.TabIndex = 4;
            this.lblTIme.Text = "1";
            this.lblTIme.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSeq
            // 
            this.lblSeq.Location = new System.Drawing.Point(934, 58);
            this.lblSeq.Name = "lblSeq";
            this.lblSeq.Size = new System.Drawing.Size(64, 13);
            this.lblSeq.TabIndex = 6;
            this.lblSeq.Text = "1";
            this.lblSeq.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(931, 14);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(67, 13);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "29-Mar-2013";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(877, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Seq:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(877, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Time:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(877, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Date:";
            // 
            // txtFloorRate
            // 
            this.txtFloorRate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtFloorRate.ForeColor = System.Drawing.Color.Black;
            this.txtFloorRate.Location = new System.Drawing.Point(907, 522);
            this.txtFloorRate.Name = "txtFloorRate";
            this.txtFloorRate.ReadOnly = true;
            this.txtFloorRate.Size = new System.Drawing.Size(100, 20);
            this.txtFloorRate.TabIndex = 13;
            this.txtFloorRate.TabStop = false;
            this.txtFloorRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(823, 525);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "FLOOR RATE:";
            // 
            // txtCeilingRate
            // 
            this.txtCeilingRate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtCeilingRate.ForeColor = System.Drawing.Color.Black;
            this.txtCeilingRate.Location = new System.Drawing.Point(717, 522);
            this.txtCeilingRate.Name = "txtCeilingRate";
            this.txtCeilingRate.ReadOnly = true;
            this.txtCeilingRate.Size = new System.Drawing.Size(100, 20);
            this.txtCeilingRate.TabIndex = 11;
            this.txtCeilingRate.TabStop = false;
            this.txtCeilingRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(627, 525);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "CEILING RATE:";
            // 
            // txtCentralBankCoreRate
            // 
            this.txtCentralBankCoreRate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtCentralBankCoreRate.ForeColor = System.Drawing.Color.Black;
            this.txtCentralBankCoreRate.Location = new System.Drawing.Point(907, 500);
            this.txtCentralBankCoreRate.Name = "txtCentralBankCoreRate";
            this.txtCentralBankCoreRate.ReadOnly = true;
            this.txtCentralBankCoreRate.Size = new System.Drawing.Size(100, 20);
            this.txtCentralBankCoreRate.TabIndex = 9;
            this.txtCentralBankCoreRate.TabStop = false;
            this.txtCentralBankCoreRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(738, 503);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "CENTRAL BANK\'S CORE RATE";
            // 
            // dtgQuotationUSD
            // 
            this.dtgQuotationUSD.AllowUserToAddRows = false;
            this.dtgQuotationUSD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgQuotationUSD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgQuotationUSD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CCYColumn,
            this.TTMColumn,
            this.TTBColumn,
            this.TTSColumn,
            this.CSBColumn,
            this.CSSColumn,
            this.colTtbIsRate,
            this.colTtsIsRate});
            this.dtgQuotationUSD.Enabled = false;
            this.dtgQuotationUSD.Location = new System.Drawing.Point(11, 133);
            this.dtgQuotationUSD.Name = "dtgQuotationUSD";
            this.dtgQuotationUSD.ReadOnly = true;
            this.dtgQuotationUSD.RowHeadersVisible = false;
            this.dtgQuotationUSD.Size = new System.Drawing.Size(997, 360);
            this.dtgQuotationUSD.TabIndex = 7;
            // 
            // CCYColumn
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.CCYColumn.DefaultCellStyle = dataGridViewCellStyle7;
            this.CCYColumn.HeaderText = "CCY";
            this.CCYColumn.Name = "CCYColumn";
            this.CCYColumn.ReadOnly = true;
            // 
            // TTMColumn
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.TTMColumn.DefaultCellStyle = dataGridViewCellStyle8;
            this.TTMColumn.HeaderText = "TTM";
            this.TTMColumn.Name = "TTMColumn";
            this.TTMColumn.ReadOnly = true;
            // 
            // TTBColumn
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.TTBColumn.DefaultCellStyle = dataGridViewCellStyle9;
            this.TTBColumn.HeaderText = "TTB";
            this.TTBColumn.Name = "TTBColumn";
            this.TTBColumn.ReadOnly = true;
            // 
            // TTSColumn
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.TTSColumn.DefaultCellStyle = dataGridViewCellStyle10;
            this.TTSColumn.HeaderText = "TTS";
            this.TTSColumn.Name = "TTSColumn";
            this.TTSColumn.ReadOnly = true;
            // 
            // CSBColumn
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.CSBColumn.DefaultCellStyle = dataGridViewCellStyle11;
            this.CSBColumn.HeaderText = "CSB";
            this.CSBColumn.Name = "CSBColumn";
            this.CSBColumn.ReadOnly = true;
            // 
            // CSSColumn
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.CSSColumn.DefaultCellStyle = dataGridViewCellStyle12;
            this.CSSColumn.HeaderText = "CSS";
            this.CSSColumn.Name = "CSSColumn";
            this.CSSColumn.ReadOnly = true;
            // 
            // colTtbIsRate
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colTtbIsRate.DefaultCellStyle = dataGridViewCellStyle13;
            this.colTtbIsRate.HeaderText = "TTB IS/Rate";
            this.colTtbIsRate.Name = "colTtbIsRate";
            this.colTtbIsRate.ReadOnly = true;
            // 
            // colTtsIsRate
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colTtsIsRate.DefaultCellStyle = dataGridViewCellStyle14;
            this.colTtsIsRate.HeaderText = "TTS IS/Rate";
            this.colTtsIsRate.Name = "colTtsIsRate";
            this.colTtsIsRate.ReadOnly = true;
            // 
            // grpFretext1
            // 
            this.grpFretext1.Controls.Add(this.txtNoteHead);
            this.grpFretext1.Location = new System.Drawing.Point(11, 14);
            this.grpFretext1.Name = "grpFretext1";
            this.grpFretext1.Size = new System.Drawing.Size(553, 113);
            this.grpFretext1.TabIndex = 0;
            this.grpFretext1.TabStop = false;
            this.grpFretext1.Text = "Free Text 01:";
            // 
            // txtNoteHead
            // 
            this.txtNoteHead.Location = new System.Drawing.Point(9, 20);
            this.txtNoteHead.MaxLength = 1000;
            this.txtNoteHead.Multiline = true;
            this.txtNoteHead.Name = "txtNoteHead";
            this.txtNoteHead.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNoteHead.Size = new System.Drawing.Size(535, 85);
            this.txtNoteHead.TabIndex = 0;
            this.txtNoteHead.Text = "TTB and CSB mean Bank buys the currency against USD and sells USD\r\nTTS and CSS me" +
                "an Bank buys the currency against USD and sells USD";
            // 
            // frmMDQuotationDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1035, 620);
            this.Controls.Add(this.panelDetail);
            this.MaximumSize = new System.Drawing.Size(1041, 652);
            this.MinimumSize = new System.Drawing.Size(1041, 652);
            this.Name = "frmMDQuotationDetail";
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.frmMDQuotationDetail_Scroll);
            this.Shown += new System.EventHandler(this.frmMDQuotationDetail_Shown);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMDQuotationDetail_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDQuotationDetail_FormClosing);
            this.panelDetail.ResumeLayout(false);
            this.panelDetail.PerformLayout();
            this.panelButtonControl.ResumeLayout(false);
            this.grpRemark.ResumeLayout(false);
            this.grpRemark.PerformLayout();
            this.grpFretext4.ResumeLayout(false);
            this.grpFretext4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgQuotationECRateList)).EndInit();
            this.grpFretext3.ResumeLayout(false);
            this.grpFretext3.PerformLayout();
            this.grpFretext2.ResumeLayout(false);
            this.grpFretext2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgQuotationVND)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgQuotationUSD)).EndInit();
            this.grpFretext1.ResumeLayout(false);
            this.grpFretext1.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion      

        private System.Windows.Forms.Panel panelDetail;
        private System.Windows.Forms.Label lblTIme;
        private System.Windows.Forms.Label lblSeq;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private UserCtrl.DisableTextBox txtFloorRate;
        private System.Windows.Forms.Label label6;
        private UserCtrl.DisableTextBox txtCeilingRate;
        private System.Windows.Forms.Label label5;
        private UserCtrl.DisableTextBox txtCentralBankCoreRate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dtgQuotationUSD;
        private System.Windows.Forms.DataGridViewTextBoxColumn CCYColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TTMColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TTBColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TTSColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CSBColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CSSColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTtbIsRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTtsIsRate;
        private System.Windows.Forms.GroupBox grpFretext1;
        private UserCtrl.ctrlMDDisableTextBox txtNoteHead;
        private System.Windows.Forms.GroupBox grpFretext3;
        private UserCtrl.ctrlMDDisableTextBox txtNoteMid;
        private System.Windows.Forms.GroupBox grpFretext2;
        private UserCtrl.ctrlMDDisableTextBox txtNoteThreshold;
        private UserCtrl.DisableTextBox disableTextBox2;
        private UserCtrl.DisableTextBox txtTC;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dtgQuotationVND;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTTM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBuyCCYSellVND;
        private System.Windows.Forms.DataGridViewTextBoxColumn coSellCCYBuyVND;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBuyCCYSellVNDCash;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox ckbInActive;
        private System.Windows.Forms.GroupBox grpRemark;
        private UserCtrl.ctrlMDDisableTextBox txtRemark;
        private System.Windows.Forms.GroupBox grpFretext4;
        private UserCtrl.ctrlMDDisableTextBox txtNoteEnd;
        private UserCtrl.DisableTextBox txtMaker;
        private UserCtrl.DisableTextBox txtStatus;
        private System.Windows.Forms.DataGridView dtgQuotationECRateList;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panelButtonControl;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnPrintPreview;

    }
}