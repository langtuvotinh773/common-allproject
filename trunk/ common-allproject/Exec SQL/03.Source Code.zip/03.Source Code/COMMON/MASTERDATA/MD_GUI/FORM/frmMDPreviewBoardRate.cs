﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDPreviewBoardRate : frmMDMaster
    {

        // For Security Checking
        clsSEAuthorizer m_Security = null;

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        public frmMDPreviewBoardRate()
        {
            try
            {
                InitializeComponent();

                //Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                dtpPreview.Value = clsMDBus.Instance().GetServerDateTime();
            
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }            
        }
        #endregion

        #region Event
        /// <summary>
        /// Button Preview Click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPreview_Click(object sender, EventArgs e)
        {
            //show form Inquiry Board Rate History
            frmMDPrintPreviewBoardRate frm = new frmMDPrintPreviewBoardRate(null, dtpPreview.Value);
            frm.StartPosition = FormStartPosition.CenterScreen;
            if (frm.ShowDialog() == DialogResult.No)
            {
                frm.Close();
            }
        }
        #endregion
    }
}
