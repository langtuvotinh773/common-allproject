﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-27 (Mon, 27 May 2013) $
 * ========================================================
 * This class is used to view Special Customer List
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;
using MasterCommon = Phoenix.Common.MasterData.Com;
using MasterBus = Phoenix.Common.MasterData.Bus;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDTransientAccountInfo : frmMDMaster
    {
        #region Global Variable
        DataTable m_DataTable = null;
        DataView m_DataView = null;

        private int MAXLENGTH_GLCODE = 3;
        private int MAXLENGTH_GLSUBCODE = 4;
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        // For listview
        //CCY
        private string m_colCCY = "colCCY";
        private string m_colAccountNo = "colAccountNo";
        #endregion

        #region Constructor
        public frmMDTransientAccountInfo()
        {
            InitializeComponent();
            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);
            this.Text = clsMDConstant.TRANSIENT_ACCOUNT_INFO_TITLE_LIST;
            m_DataView = new DataView();
            try
            {
                //Load data to all control              
                LoadDataForCombobox();
                //Get list Transient Acc Info
                GetTransientAccInfoList();
                // Enable control
                EnableControl(true);
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Event on click "Close"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            // close form
            this.Close();
        }

        /// <summary>
        /// Event on click "Delete"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //disable all button while system excute delete function.
            EnableControl(false);
            try
            {
                if (dtgUserList.SelectedRows.Count > 0)
                {
                    //display confirm message 'Are you sure to delete this transient account information?'
                    DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, string.Format(clsMDMessage.CONFIRM_ACTION_DELETE_DATA, "transient account information"));
                    if (res == DialogResult.Yes)
                    {
                        //get transient account information to delete
                        DataGridViewRow dataRow = dtgUserList.CurrentRow;
                        string strCCY = dataRow.Cells[m_colCCY].Value.ToString();
                        int iAccNo = int.Parse(dataRow.Cells[m_colAccountNo].Value.ToString());

                        //create data for save log
                        clsMDLogBase logBase = new clsMDLogBase();
                        logBase.ApplicationName = this.Text;
                        logBase.UserID = clsUserInfo.UserNo.ToString();
                        logBase.Module = clsMDConstant.MODULE_MD;
                        logBase.Action = (int)CommonValue.ActionType.Delete;
                        logBase.Key = dataRow.Cells[m_colCCY].Value.ToString() + " " +
                                        dataRow.Cells[m_colAccountNo].Value.ToString();

                        //Delete logic transient account information and Write Delete information to Log History
                        int iRow = clsMDTransientAccInfoBUS.Instance().DeleteTransientAccInfo(strCCY, iAccNo, logBase);
                        if (iRow > 0)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Deleting", "transient account information"));

                            //Refresh data on grid after delete
                            GetTransientAccInfoList();
                        }
                        else
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Deleting", "transient account information"));

                            //Refresh data on grid after delete
                            GetTransientAccInfoList();
                        }
                    }
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a transient account information", "delete"));
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //enable all button while system finish delete function.
            EnableControl(true);
        }

        /// <summary>
        /// Event on click "Search"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //disable all button control while system excute search function
            EnableControl(false);
            //get search condition
            clsMDTransientAccInfoDTO dto = new clsMDTransientAccInfoDTO();
            dto.CCY = cbbCCY.SelectedValue.ToString();
            dto.AccountNo = string.IsNullOrEmpty(txtAccountNo.Text) ? -1 : int.Parse(txtAccountNo.Text.Trim());
            dto.GLCode = txtGLCode.Text.Trim();
            dto.GLSubCode = txtGLSubCode.Text.Trim();
            dto.DepartmentId = string.IsNullOrEmpty(cbbDepartment.Text)? -1 : int.Parse(cbbDepartment.SelectedValue.ToString());
            dto.OpenDate = null;
            dto.CloseDate = null;
            if (dtpOpenDate.Text != "")
            {
                dto.OpenDate = new DateTime(dtpOpenDate.Value.Year, dtpOpenDate.Value.Month, dtpOpenDate.Value.Day, 0, 0, 0, 0);
            }
            if (dtpCloseDate.Text != "")
            {
                dto.CloseDate = new DateTime(dtpCloseDate.Value.Year, dtpCloseDate.Value.Month, dtpCloseDate.Value.Day, 0, 0, 0, 0);
            }
            try
            {
                //search list dept based on input params
                m_DataTable = clsMDTransientAccInfoBUS.Instance().GetTransientAccInfoList(dto);
                //update data on grid
                UpdateGridView(m_DataTable);
                if (m_DataTable == null || (m_DataTable != null && m_DataTable.Rows.Count == 0))
                {
                    //display message 'No transaction found!'
                    clsMDMesageCollection.MessageNoTransactions();
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //enable all button control while system excute search function
            EnableControl(true);
        }


        /// <summary>
        /// Event on click "Create"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnCreate_Click(object sender, EventArgs e)
        {
            ////tranfer to Create Transient  Screen
            frmMDAddModifyTransientAccInfo frmNew = new frmMDAddModifyTransientAccInfo(clsMDConstant.TRANSIENT_ACCOUNT_INFO_TITLE_CREATE);
            frmNew.OnSaved += new EventHandler(frmNewModify_OnSaved);
            frmNew.m_CurrentAction = CommonValue.ActionType.New;
            frmNew.StartPosition = FormStartPosition.CenterScreen;
            frmNew.ShowDialog();
        }

        /// <summary>
        /// Event on click "Modify"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgUserList.SelectedRows.Count > 0)
                {
                    if (dtgUserList.SelectedRows.Count > 1)
                    {
                        //if user choose more than one item on grid
                        //display message to require user choose one item on grid before click modify button
                        //'Please select a transient account information to modify.'                           
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a transient acccount information", "modify"));
                    }
                    else
                    {
                        //get selected row
                        DataGridViewRow rowSelected = dtgUserList.CurrentRow;
                        //tranfer to Modify Transient Account Information Screen
                        frmMDAddModifyTransientAccInfo frmModify = new frmMDAddModifyTransientAccInfo(clsMDConstant.TRANSIENT_ACCOUNT_INFO_TITLE_UPDATE);
                        //define action after called save action on frmMDUserAddModify screen
                        frmModify.OnSaved += new EventHandler(frmNewModify_OnSaved);
                        //set updated object
                        frmModify.m_CurrentAction = CommonValue.ActionType.Update;
                        frmModify.m_UpdatingAccInfo.CCY = rowSelected.Cells[m_colCCY].Value.ToString();
                        frmModify.m_UpdatingAccInfo.AccountNo = int.Parse(rowSelected.Cells[m_colAccountNo].Value.ToString());
                        frmModify.m_UpdatingAccInfo = clsMDTransientAccInfoBUS.Instance().GetTransientAccountInfo(frmModify.m_UpdatingAccInfo.CCY, frmModify.m_UpdatingAccInfo.AccountNo);
                        if (frmModify.m_UpdatingAccInfo != null)
                        {
                            frmModify.SetData(frmModify.m_UpdatingAccInfo);
                            frmModify.StartPosition = FormStartPosition.CenterScreen;
                            frmModify.ShowDialog();
                        }
                        else
                        {
                            //if system can not get information of selected object
                            //display error message
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.ERROR_NOT_FOUND_ITEM);
                        }
                    }
                }
                else
                {
                    //if user choose more than one item on grid
                    //display message to require user choose one item on grid before click modify button
                    //'Please select a transient account information to modify.'                           
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a transient account information", "modify"));
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event form load
        /// Load data default: List Transient Account Information
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void frmMD_TransientAccountInfo_Load(object sender, EventArgs e)
        {
            //Set common style for form
            SetFormStyleCommon();
            //dtgUserList.ClearSelection();
            if (dtgUserList.SelectedRows.Count > 0)
            {
                EnableControl(true);
            } 
            else
            {
                EnableControl(false);
                btnSearch.Enabled = true;
            }

            // Set default value for control
            dtpOpenDate.Value = DateTime.Now;
            dtpCloseDate.Value = DateTime.Now;
            txtGLCode.MaxLength = MAXLENGTH_GLCODE;
            txtGLSubCode.MaxLength = MAXLENGTH_GLSUBCODE;
        }

        /// <summary>
        /// Event Key Press
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void txtGLCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        /// <summary>
        /// Event Key Press
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void txtGLSubCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }
        #endregion

        #region Member Method
        /// <summary>
        /// Enable or disable button action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void EnableControl(bool value)
        {
            btnModify.Enabled = value;
            btnDelete.Enabled = value;
            //check logic
            if (m_DataTable != null && m_DataTable.Rows.Count == 0)
            {
                btnDelete.Enabled = false;
                btnModify.Enabled = false;
            }
        }

        /// <summary>
        /// Load data to all control
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void LoadDataForCombobox()
        {
            GetDataForComboBoxDepartment();
            GetDataForComboBoxCCY();
        }

        /// <summary>
        /// Get Transient Account Info list
        /// </summary>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void GetTransientAccInfoList()
        {
            m_DataTable = clsMDTransientAccInfoBUS.Instance().GetTransientAccInfoList(new clsMDTransientAccInfoDTO());
            UpdateGridView(m_DataTable);
        }

        /// <summary>
        /// Update DataSource of Transient Account Information DataGridView
        /// </summary>
        /// <param name="list">list data customer dto</param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void UpdateGridView(DataTable user)
        {
            user.TableName = "Transient Account Info";
            m_DataView.Table = user;
            dtgUserList.AutoGenerateColumns = false;
            dtgUserList.DataSource = m_DataView;
        }

        /// <summary>
        /// Get list of departments for cbbDepartment
        /// </summary>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void GetDataForComboBoxDepartment()
        {
            DataTable depts = clsMDTransientAccInfoBUS.Instance().GetDepartmentList();
            if (depts == null) return;

            depts.Rows.InsertAt(depts.NewRow(), 0);
            depts.AcceptChanges();

            cbbDepartment.DataSource = depts;
            cbbDepartment.ValueMember = clsMDConstant.MD_COL_DEPARTMENTID;
            cbbDepartment.DisplayMember = clsMDConstant.MD_COL_DEPARTMENTNAME;
            cbbDepartment.SelectedIndex = 0;
        }

        /// <summary>
        /// Get list of ccys for cbbCCY
        /// </summary>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void GetDataForComboBoxCCY()
        {
            DataTable ccys = clsMDTransientAccInfoBUS.Instance().GetCCYList();
            if (ccys == null) return;

            ccys.Rows.InsertAt(ccys.NewRow(), 0);
            ccys.AcceptChanges();

            cbbCCY.DataSource = ccys;
            cbbCCY.ValueMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.DisplayMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.SelectedIndex = 0;
        }

        /// <summary>
        /// Define EventHandle after excute action save in frmMDAddModifyTransientAccInfo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void frmNewModify_OnSaved(object sender, EventArgs e)
        {
            //Refresh data on grid
            GetTransientAccInfoList();
            //enable button control if they are disable
            EnableControl(true);
        }   
        #endregion
    }
}
