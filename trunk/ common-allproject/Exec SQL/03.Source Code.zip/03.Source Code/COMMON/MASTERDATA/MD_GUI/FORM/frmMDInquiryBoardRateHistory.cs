﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDInquiryBoardRateHistory : frmMDMaster
    {

        #region Private Variables

        // For Security Checking
        clsSEAuthorizer m_Security = null;

        private clsMDBoardRaterBUS m_BoardRateBus;
        private List<clsMDBoardRateDTO> m_BoardRateList;
        private clsMDBoardRateDTO m_BoardRateDto;
        private DateTime? m_FromDate = null;
        private DateTime? m_ToDate = null;
        private int m_Status = 0;
        private bool? m_IsActive = null;
        private string m_colBoardRateID = "colBoardRateID";
        private string m_colStatus = "colStatus";
        private string m_colInactive = "colInactive";
        private string m_colDate = "colDate";
        private string m_colTime = "colTime";
        private string m_colMaker = "colMaker";
        private string m_colApprover = "colApprover";
        private string m_colStatusID = "colStatusID";
        #endregion

        #region Constructor
        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        public frmMDInquiryBoardRateHistory()
        {
            try
            {
                InitializeComponent();
                SetFormStyleCommon();

                //Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                FillDataComboboxStatus();
                FillDataComboboxIsActive();
                DateTime serverDate = clsMDBus.Instance().GetServerDateTime();
                dtpFrom.Value = serverDate;
                dtpTo.Value = serverDate;
                dtgBoardRateHistory.Columns[m_colDate].DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Event Methods

        /// <summary>
        /// Search Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (String.IsNullOrEmpty(dtpFrom.Text))
                {
                    m_FromDate = new Nullable<DateTime>();
                }
                else
                {
                    m_FromDate = dtpFrom.Value;
                }
                if (String.IsNullOrEmpty(dtpTo.Text))
                {
                    m_ToDate = new Nullable<DateTime>();
                }
                else
                {
                    m_ToDate = dtpTo.Value;
                }
                m_Status = (int)cbbStatus.SelectedValue;
                m_IsActive = (bool?)cbbIsActive.SelectedValue;
                m_BoardRateBus = new clsMDBoardRaterBUS();
                dtgBoardRateHistory.Rows.Clear();
                //get Inquiry Board rate history list
                m_BoardRateList = m_BoardRateBus.GetInquiryBoardRateHistoryList(m_FromDate, m_ToDate, m_Status, m_IsActive);
                if (m_BoardRateList.Count > 0)
                {
                    List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
                    DataGridViewRow row;
                    foreach (clsMDBoardRateDTO dto in m_BoardRateList)
                    {
                        row = new DataGridViewRow();
                        row.CreateCells(dtgBoardRateHistory);
                        row.Cells[dtgBoardRateHistory.Columns[m_colBoardRateID].Index].Value = dto.BoardRateID;
                        row.Cells[dtgBoardRateHistory.Columns[m_colStatus].Index].Value = clsMDFunction.GetBoardRateStatusName(dto.Status);
                        row.Cells[dtgBoardRateHistory.Columns[m_colInactive].Index].Value = !dto.IsActive;
                        row.Cells[dtgBoardRateHistory.Columns[m_colDate].Index].Value = dto.ImportTime;
                        row.Cells[dtgBoardRateHistory.Columns[m_colTime].Index].Value = dto.ImportTime;
                        row.Cells[dtgBoardRateHistory.Columns[m_colMaker].Index].Value = dto.Maker;
                        row.Cells[dtgBoardRateHistory.Columns[m_colApprover].Index].Value = dto.Approver;
                        row.Cells[dtgBoardRateHistory.Columns[m_colStatusID].Index].Value = dto.Status;
                        lstRows.Add(row);
                    }
                    dtgBoardRateHistory.Rows.AddRange(lstRows.ToArray());
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Print Preview Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrintPreView_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show("Print Preview");
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Export Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_BoardRateDto != null)
                {
                    clsMDBoardRateDTO dtoExport = clsMDBoardRaterBUS.Instance().GetBoardRateAndBoadRateDetail(m_BoardRateDto.BoardRateID);
                    if (dtoExport != null)
                    {

                        m_BoardRateBus = new clsMDBoardRaterBUS();
                        m_BoardRateBus.ExportBoardRate(dtoExport);
                    }
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_BOARD_RATE_EXPORT);
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Close Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Data Grid Selection Changed Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgBoardRateHistory_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                //int StatusID = (int)clsMDCommonValue.BoardRateStatus.Blank;
                if (dtgBoardRateHistory.Rows.Count > 0 && dtgBoardRateHistory.SelectedRows.Count > 0)
                {
                    int index = dtgBoardRateHistory.Rows.IndexOf(dtgBoardRateHistory.SelectedRows[0]);
                    //StatusID = (int)dtgBoardRateHistory.Rows[index].Cells[m_colStatusID].Value;
                    int boardRateID = (int)dtgBoardRateHistory.Rows[index].Cells[m_colBoardRateID].Value;
                    m_BoardRateDto = m_BoardRateList.Find(t => t.BoardRateID == boardRateID);
                }
                else
                {
                    m_BoardRateDto = null;
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        #endregion

        #region Member Methods

        /// <summary>
        /// Load data for Combobox Status
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillDataComboboxStatus()
        {
            List<CbbObject> lst = new List<CbbObject>();
            lst.Add(new CbbObject(0, string.Empty));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateStatus.Approved, clsMDConstant.BOARD_RATE_STATUS_Approved));
            lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateStatus.Obsolete, clsMDConstant.BOARD_RATE_STATUS_Obsolete));

            cbbStatus.DataSource = lst;
            cbbStatus.DisplayMember = clsMDConstant.DISPLAY;
            cbbStatus.ValueMember = clsMDConstant.VALUE;
            cbbStatus.SelectedIndex = 0;
        }

        /// <summary>
        /// Load data for Combobox IsActive
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillDataComboboxIsActive()
        {
            List<CbbObject> lst = new List<CbbObject>();
            lst.Add(new CbbObject(new Nullable<bool>(), string.Empty));
            lst.Add(new CbbObject(true, clsMDConstant.BOARD_RATE_ACTIVE));
            lst.Add(new CbbObject(false, clsMDConstant.BOARD_RATE_IN_ACTIVE));

            cbbIsActive.DataSource = lst;
            cbbIsActive.DisplayMember = clsMDConstant.DISPLAY;
            cbbIsActive.ValueMember = clsMDConstant.VALUE;
            cbbIsActive.SelectedIndex = 0;
        }

        #endregion


    }
}