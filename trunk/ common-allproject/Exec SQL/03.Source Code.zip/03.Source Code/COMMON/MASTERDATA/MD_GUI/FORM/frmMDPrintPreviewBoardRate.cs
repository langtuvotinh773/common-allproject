﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-08-22 11:15:00 +0700 (Thu, 22 Agu 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to report boardrate
 * for MD module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using COMMON.MASTERDATA.MD_GUI.FORM.REPORT;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDPrintPreviewBoardRate : Form
    {
        #region Global Variable

        // For Security Checking
        clsSEAuthorizer m_Security = null;

        //+ Bus
        //private clsMDBoardRaterBUS m_BoardRateBus;
        private int? m_BoardRateID = null;
        private DateTime? m_PreviewDate = null;
        //For Reporting Controlling Book
        //+ Project Name
        private string m_ProjectName = "MASTERDATA\\" + clsMDConstant.MODULE_MD;
        //+ Data Source
        private string m_DataSource = "dtsBoardRate_tblBoardRate";
        //+ Template Name
        private string m_TemplateName = "_GUI\\FORM\\REPORT\\rptMDBoardRate.rdlc";

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="boardRateID"></param>
        /// <param name="previewDate"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDPrintPreviewBoardRate(int? boardRateID, DateTime? previewDate)
        {
            InitializeComponent();
            m_BoardRateID = boardRateID;
            m_PreviewDate = previewDate;

            //Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);
        }

        /// <summary>
        /// Form Load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void frmMDPrintPreviewBoardRate_Load(object sender, EventArgs e)
        {
            try
            {
                //Declaration
                dtsBoardRate dtsReportPrintPreviewBoardRateObj = new dtsBoardRate();
                List<clsMDBoardRateDetailDTO> lst = new List<clsMDBoardRateDetailDTO>();
                string importantNote = string.Empty;
                lst = clsMDBoardRaterBUS.Instance().GetPrintPreviewBoardRate(m_BoardRateID, ref m_PreviewDate, out importantNote);

                if (lst.Count > 0)
                {

                    //Group
                    var groups = lst.GroupBy(x => x.CCY).ToList();

                    foreach (var group in groups)
                    {
                        foreach (var item in group)
                        {
                            dtsReportPrintPreviewBoardRateObj.tblBoardRate.Rows.Add(
                                item.CCYForAmount, item.CCYForPercent, item.TransTypeName, clsMDConstant.BOARD_RATE_SAME_DAY,
                                item.SameDayValueDate == null ? String.Empty : item.SameDayValueDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY),
                                item.Term, item.SameDay, item.TransType);
                            dtsReportPrintPreviewBoardRateObj.tblBoardRate.Rows.Add(
                                item.CCYForAmount, item.CCYForPercent, item.TransTypeName, clsMDConstant.BOARD_RATE_TOM,
                                item.TomValueDate == null ? string.Empty : item.TomValueDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY),
                                item.Term, item.Tom, item.TransType);
                            dtsReportPrintPreviewBoardRateObj.tblBoardRate.Rows.Add(
                                item.CCYForAmount, item.CCYForPercent, item.TransTypeName, clsMDConstant.BOARD_RATE_SPOT,
                                item.SpotValueDate == null ? string.Empty : item.SpotValueDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY),
                                item.Term, item.Spot, item.TransType);
                        }
                    }
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.INFO_NO_DATA_EXPORT);
                    this.DialogResult = DialogResult.No;
                    return;
                }

                //+ Load report
                this.reportViewerPrintPreviewBoardRate.ProcessingMode = Microsoft.Reporting.WinForms.ProcessingMode.Local;
                this.reportViewerPrintPreviewBoardRate.LocalReport.ReportPath = AppDomain.CurrentDomain.BaseDirectory + m_ProjectName + m_TemplateName;
                this.reportViewerPrintPreviewBoardRate.LocalReport.DataSources.Clear();
                this.reportViewerPrintPreviewBoardRate.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource(m_DataSource, dtsReportPrintPreviewBoardRateObj.Tables[0]));
                this.reportViewerPrintPreviewBoardRate.DocumentMapCollapsed = true;

                //+ Add parameters
                List<Microsoft.Reporting.WinForms.ReportParameter> report_parameters = new List<Microsoft.Reporting.WinForms.ReportParameter>();
                report_parameters.Add(new Microsoft.Reporting.WinForms.ReportParameter("AlternatingBackColor", "#CCFFCC".ToString(), false));
                report_parameters.Add(new Microsoft.Reporting.WinForms.ReportParameter("PreviewDate", m_PreviewDate == null ? string.Empty : m_PreviewDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY), true));
                report_parameters.Add(new Microsoft.Reporting.WinForms.ReportParameter("PreviewTime", m_PreviewDate == null ? string.Empty : m_PreviewDate.Value.ToString(clsMDConstant.MD_FORMAT_HHMM), true));

                clsMDBus.Instance().ProcessImportantNote(ref importantNote, lst[0].CCY);

                report_parameters.Add(new Microsoft.Reporting.WinForms.ReportParameter("ImportantNote", importantNote, true));

                this.reportViewerPrintPreviewBoardRate.LocalReport.SetParameters(report_parameters);

                //Refresh reporting
                this.reportViewerPrintPreviewBoardRate.RefreshReport();

                string strImport = string.Empty;

                
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                this.Close();
            }
        }

        
    }
}
