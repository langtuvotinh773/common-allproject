﻿namespace COMMON.MASTERDATA.MD_GUI.FORM.REPORT
{       
    public partial class dtsBoardRate 
    {
    }
}
