﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDAddModifyCeilingFloor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtCeiling = new UserCtrl.ctrlMDNumberOnlyTextBox();
            this.cbbCCYPair = new System.Windows.Forms.ComboBox();
            this.txtFloor = new UserCtrl.ctrlMDNumberOnlyTextBox();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(108, 107);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CCY Pair";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ceiling";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Floor";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(189, 107);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtCeiling
            // 
            this.txtCeiling.CustomDecimal = 0;
            this.txtCeiling.CustomLenght = 20;
            this.txtCeiling.Location = new System.Drawing.Point(114, 47);
            this.txtCeiling.Name = "txtCeiling";
            this.txtCeiling.NeedDecimal = true;
            this.txtCeiling.Size = new System.Drawing.Size(150, 20);
            this.txtCeiling.StringFormat = "";
            this.txtCeiling.TabIndex = 4;
            this.txtCeiling.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCeiling.TextChanged += new System.EventHandler(this.txtCeiling_TextChanged);
            this.txtCeiling.Leave += new System.EventHandler(this.txtCeiling_Leave);
            // 
            // cbbCCYPair
            // 
            this.cbbCCYPair.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbCCYPair.FormattingEnabled = true;
            this.cbbCCYPair.Location = new System.Drawing.Point(114, 25);
            this.cbbCCYPair.Name = "cbbCCYPair";
            this.cbbCCYPair.Size = new System.Drawing.Size(150, 21);
            this.cbbCCYPair.TabIndex = 3;
            this.cbbCCYPair.SelectedIndexChanged += new System.EventHandler(this.cbbCCYPair_SelectedIndexChanged);
            this.cbbCCYPair.TextUpdate += new System.EventHandler(this.cbbCCYPair_TextUpdate);
            // 
            // txtFloor
            // 
            this.txtFloor.CustomDecimal = 0;
            this.txtFloor.CustomLenght = 20;
            this.txtFloor.Location = new System.Drawing.Point(114, 68);
            this.txtFloor.Name = "txtFloor";
            this.txtFloor.NeedDecimal = true;
            this.txtFloor.Size = new System.Drawing.Size(150, 20);
            this.txtFloor.StringFormat = "#,0.####";
            this.txtFloor.TabIndex = 5;
            this.txtFloor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFloor.TextChanged += new System.EventHandler(this.txtFloor_TextChanged);
            this.txtFloor.Leave += new System.EventHandler(this.txtFloor_Leave);
            // 
            // frmMDAddModifyCeilingFloor
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(324, 155);
            this.Controls.Add(this.cbbCCYPair);
            this.Controls.Add(this.txtFloor);
            this.Controls.Add(this.txtCeiling);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSave);
            this.Name = "frmMDAddModifyCeilingFloor";
            this.Text = "Create Ceiling & Floor";
            this.Shown += new System.EventHandler(this.frmMDAddModifyCeilingFloor_Shown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMasAddCeilingFloor_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnCancel;
        private UserCtrl.ctrlMDNumberOnlyTextBox txtCeiling;
        private System.Windows.Forms.ComboBox cbbCCYPair;
        private UserCtrl.ctrlMDNumberOnlyTextBox txtFloor;
    }
}