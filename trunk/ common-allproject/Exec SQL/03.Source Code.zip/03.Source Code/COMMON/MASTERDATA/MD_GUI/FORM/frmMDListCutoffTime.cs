﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-24 +0700 (Fri, 24 may 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage CutoffTime
 * of Master data module.
 */
using System;
using System.Data;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Dto;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using System.Collections.Generic;
namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDListCutoffTime : frmMDMaster
	{
		/// <summary>
		/// clsMDCutoffTimeBus object
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private clsMDCutoffTimeBUS m_MDCutoffTimeBUS = new clsMDCutoffTimeBUS();
		/// <summary>
		/// For Security Checking
		/// </summary>
		clsSEAuthorizer m_Security = null;

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
        public frmMDListCutoffTime()
		{
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                LoadCurrency(cbbCCY);
                if (cbbCCY.Items.Count == 0)
                    cbbCCY.DataSource = clsMDCeilingFloorBUS.Instance().GetCurencyList();
                LoadTransactionType(cbbTransType);
                if (cbbTransType.Items.Count == 0)
                    cbbTransType.DataSource = clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_TRANSACTION_TYPE);

                SetFormStyleCommon();

                dtpUpdateTime.Text = "";
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// Search and fill CutoffTime to datagridview
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void SearchAndFillData()
		{
			try
			{
				dtgCutoffTimeList.Rows.Clear();
				string strCCYCode = cbbCCY.Items.Count > 0 ? ((CbbObject) cbbCCY.SelectedItem).Value.ToString() : "";
				int iTransactionType = cbbTransType.Items.Count > 0 ? int.Parse(((CbbObject) cbbTransType.SelectedItem).Value.ToString()) : 0;
				string strUpdateBy = txtUpdateBY.Text.Trim();
				DateTime? dtUpdateDate = dtpUpdateTime.Value;
				if (dtpUpdateTime.Text == "")
					dtUpdateDate = null;

				DataTable dtbCutoffTime = m_MDCutoffTimeBUS.GetCutoffTimeList(strCCYCode, iTransactionType, dtUpdateDate, strUpdateBy);

                List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
                DataGridViewRow row = new DataGridViewRow();
                //Suppend Layout
                dtgCutoffTimeList.SuspendLayout();

                for (int i = 0; i < dtbCutoffTime.Rows.Count; i++)
                {
                    row = new DataGridViewRow();
                    row.CreateCells(dtgCutoffTimeList);
                    row.Cells[dtgCutoffTimeList.Columns["colCCY"].Index].Value = dtbCutoffTime.Rows[i]["CCYCode"];
                    row.Cells[dtgCutoffTimeList.Columns["colTransactionType"].Index].Value = dtbCutoffTime.Rows[i]["TransactionType"];
                    row.Cells[dtgCutoffTimeList.Columns["colCutoffTime"].Index].Value = dtbCutoffTime.Rows[i]["CutoffTime"].ToString();
                    row.Cells[dtgCutoffTimeList.Columns["colUpdateTime"].Index].Value = DateTime.Parse(dtbCutoffTime.Rows[i]["UpdateDate"].ToString()).ToString(FORMAT_DDMMMYYYY);
                    row.Cells[dtgCutoffTimeList.Columns["colUpdateBy"].Index].Value = dtbCutoffTime.Rows[i]["UserName"];
                    row.Cells[dtgCutoffTimeList.Columns["colCutoffTimeID"].Index].Value = dtbCutoffTime.Rows[i]["CutoffTimeId"];

                    //row.Cells[dtgCutoffTimeList.Columns["colCutoffTime"].Index].Style.Format = GetFormatDecimal(decimal.Parse(dtbCutoffTime.Rows[i]["CutoffTime"].ToString()));

                    lstRows.Add(row);
                }
                //Resume Layout
                dtgCutoffTimeList.Rows.AddRange(lstRows.ToArray());
                dtgCutoffTimeList.ResumeLayout();

				if (dtgCutoffTimeList.Rows.Count > 0)
				{
					dtgCutoffTimeList.Rows[0].Selected = true;
					SetAction();
				}
				else
				{
					clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, clsMDMessage.NO_TRANSACTION_FOUND);
					SetAction();
				}
			}
			catch (Exception ex)
			{
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
		}

		/// <summary>
		/// Set action 
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void SetAction()
		{
			if (dtgCutoffTimeList.Rows.Count <= 0)
			{
				btnModify.Enabled = false;
				btnDelete.Enabled = false;
			}
			else
			{
				btnModify.Enabled = true;
				btnDelete.Enabled = true;
			}
		}
		
		/// <summary>
		/// Writelog
		/// </summary>
		/// <param name="iUserAction">User action</param>
		/// <param name="strKeyDelete">Key to delete</param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void WriteLog(int iUserAction, string strKeyDelete)
		{	//History Header
			clsMDLogBase logBase = new clsMDLogBase();
			logBase.ApplicationName = this.Text;
			logBase.UserID = clsUserInfo.UserNo.ToString();
			logBase.Module = clsMDConstant.MODULE_MD;

			switch (iUserAction)
			{
				case (int) CommonValue.ActionType.Delete:
					logBase.Action = (int) CommonValue.ActionType.Delete;
					logBase.Key = strKeyDelete;
					logBase.WirteLog(m_MDCutoffTimeBUS.DAL);


					break;
			}
			m_MDCutoffTimeBUS.Commit();

		}

		/// <summary>
		/// Delete CutoffTime even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void btnDelete_Click(object sender, EventArgs e)
		{
			try
			{
				if (dtgCutoffTimeList.SelectedRows.Count <= 0)
					clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, CUTOFFTIME, DELETE));
				else
				{

					int iCutoffTimeID = -1;
					string strMessageToWriteLog = "";
					string strCCYCode = "";
					string strTransactionTypeID = "";
					if (dtgCutoffTimeList.SelectedRows.Count > 0)
					{
						iCutoffTimeID = int.Parse(dtgCutoffTimeList.SelectedRows[0].Cells["colCutoffTimeID"].Value.ToString());
						strCCYCode = dtgCutoffTimeList.SelectedRows[0].Cells["colCCY"].Value.ToString();
						strTransactionTypeID = dtgCutoffTimeList.SelectedRows[0].Cells["colTransactionType"].Value.ToString();
					}
                    if (clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_CUTOFF_TIME) == DialogResult.Yes)
						if (m_MDCutoffTimeBUS.DeleteCutoffTime(iCutoffTimeID) > 0)
						{
                            WriteLog((int)CommonValue.ActionType.Delete, strMessageToWriteLog);
							clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, DELETING, CUTOFFTIME));
							SearchAndFillData();
							strMessageToWriteLog = iCutoffTimeID.ToString() + " " + strCCYCode + " " + strTransactionTypeID;							
						}
						else
						{
							clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, DELETING, CUTOFFTIME));
							if (m_MDCutoffTimeBUS.DAL != null)
								m_MDCutoffTimeBUS.RollBack();
						}
				}
			}
			catch (Exception ex)
			{
                m_MDCutoffTimeBUS.RollBack();
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
		}
				
		/// <summary>
		/// Search even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void btnSearch_Click(object sender, EventArgs e)
		{
			SearchAndFillData();
		}
		
		/// <summary>
		/// Close form even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		/// <summary>
		/// Modify even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void btnModify_Click(object sender, EventArgs e)
		{
            try
            {
                if (dtgCutoffTimeList.SelectedRows.Count <= 0)
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "CutoffTime", "modify"));
                else
                {
                    string strCCY = dtgCutoffTimeList.SelectedRows[0].Cells["colCCY"].Value.ToString();
                    string strTransactionType = dtgCutoffTimeList.SelectedRows[0].Cells["colTransactionType"].Value.ToString();
                    string strCutoffTime = dtgCutoffTimeList.SelectedRows[0].Cells["colCutoffTime"].Value.ToString();
                    int iCutoffTimeID = int.Parse(dtgCutoffTimeList.SelectedRows[0].Cells["colCutoffTimeID"].Value.ToString());
                    frmMDAddModifyCutoffTime frm = new frmMDAddModifyCutoffTime(strCCY, strTransactionType, strCutoffTime, iCutoffTimeID);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.ShowDialog();
                    SearchAndFillData();
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// Add CutoffTime even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void btnAdd_Click(object sender, EventArgs e)
		{
            try
            {
                frmMDAddModifyCutoffTime frm = new frmMDAddModifyCutoffTime();
                frm.StartPosition = FormStartPosition.CenterScreen;
                DialogResult result = frm.ShowDialog();
                if (result == DialogResult.OK)
                    SearchAndFillData();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// Row removed even on datagrid
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void dtgTimeList_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
            try
            {
                SetAction();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// Form shown even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void frmMDListCutoffTime_Shown(object sender, EventArgs e)
		{
            try
            {
                SearchAndFillData();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}
	}
}