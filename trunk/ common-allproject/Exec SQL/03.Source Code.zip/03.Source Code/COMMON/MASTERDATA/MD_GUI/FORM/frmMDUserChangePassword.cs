﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-04-22 (Mon, 22 April 2013) $
 * ========================================================
 * This class is used to change password of login user
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Bus;
using Config.Classes;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Functions;
using System.Text.RegularExpressions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDUserChangePassword : frmMDMaster
    {
        #region Global Variable
        clsMDUserDTO m_User;        
        bool m_ForceClose = false;            
        #endregion

        /// <summary>
        /// Initializes a new instance of the frmMDUserChangePassword class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDUserChangePassword()
        {
            InitializeComponent();
            m_User = new clsMDUserDTO();
        }

        /// <summary>
        /// Form Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDUserChangePassword_Load(object sender, EventArgs e)
        {
            try
            {
                //m_User = clsMDUserBUS.Instance().GetUser(clsUserInfo.UserNo);
                //if (m_User != null)
                //{
                //    //load username to textbox
                //    txtUserName.Text = m_User.UserName;
                //}
                txtUserName.Text = clsUserInfo.UserName;
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click Camcel button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        /// <summary>
        /// Event form close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDUserChangePassword_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (!m_ForceClose)
                {
                    //if data was changed on screen, display confirm message to save changed data.
                    if (IsDataChanged())
                    {
                        //display message 'Do you want to save changes of data?'
                        DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                        //if user select Yes button on confirm screen, close form and save data
                        if (res == DialogResult.Yes )
                        {
                            if (IsValidData())
                            {
                                //create data for save log
                                clsMDLogBase logBase = new clsMDLogBase();
                                logBase.ApplicationName = this.Text;
                                logBase.UserID = clsUserInfo.UserNo.ToString();
                                logBase.Module = clsMDConstant.MODULE_SE;
                                logBase.Action = (int)CommonValue.ActionType.Update;
                                logBase.Key = txtUserName.Text + " " + clsUserInfo.UserNo;
                                //detail log
                                clsMDLogInformation logInfo = new clsMDLogInformation();
                                logInfo.FieldName = clsMDConstant.MD_COL_PASSWORD;
                                logInfo.OldValue = m_User.Password;
                                logInfo.NewValue = clsMDFunction.GetMD5HashData(txtNewPassword.Text);
                                logBase.LstLogInformation.Add(logInfo);

                                int iRow = clsMDUserBUS.Instance().ChangePassword(m_User.UserNo, clsMDFunction.GetMD5HashData(txtNewPassword.Text), logBase);
                                // If Insert OK
                                if (iRow > 0)
                                {
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Changing password", "of user"));
                                }
                                else
                                {
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Changing password", "of user"));
                                    e.Cancel = true;
                                }
                            }
                            else
                            {
                                e.Cancel = true;
                            }
                        }
                        else if (res == DialogResult.Cancel)
                        {
                            //if user select Cancel button on confirm screen, do nothing
                            e.Cancel = true;
                        }
                        //if user select No button on confirm screen, close form and not save
                    }
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click save button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            //disable all button while system excute delete function.
            EnableButtonControl(false);
            try
            {
                //check valid data
                if (IsValidData())
                {
                    DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "changing password"));
                    if (res == DialogResult.Yes)
                    {
                        //create data for save log
                        clsMDLogBase logBase = new clsMDLogBase();
                        logBase.ApplicationName = this.Text;
                        logBase.UserID = clsUserInfo.UserNo.ToString();
                        logBase.Module = clsMDConstant.MODULE_SE;
                        logBase.Action = (int)CommonValue.ActionType.Update;
                        logBase.Key = clsUserInfo.UserName + " " + clsUserInfo.UserNo;
                        //detail log
                        clsMDLogInformation logInfo = new clsMDLogInformation();
                        logInfo.FieldName = clsMDConstant.MD_COL_PASSWORD;
                        logInfo.OldValue = m_User.Password;
                        logInfo.NewValue = clsMDFunction.GetMD5HashData(txtNewPassword.Text);
                        logBase.LstLogInformation.Add(logInfo);

                        int iRow = clsMDUserBUS.Instance().ChangePassword(m_User.UserNo, clsMDFunction.GetMD5HashData(txtNewPassword.Text), logBase);
                        // If Insert OK
                        if (iRow > 0)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Changing password", "of user"));
                            this.m_ForceClose = true;
                            this.Close();
                        }
                        else if (iRow == 0)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Changing password", "of user"));
                        }
                        else
                        {
                            this.m_ForceClose = true;
                            this.Close();
                        }
                    }else if (res == DialogResult.No)
                    {
                        this.m_ForceClose = true;
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button while system finish search function.
            EnableButtonControl(true);            
        }

        /// <summary>
        /// Enable or disable button control
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnCancel.Enabled = value;
            btnSave.Enabled = value;
        }

        /// <summary>
        /// Check validation data
        /// </summary>
        /// <returns>
        /// if any required field is invalid, system will display a warning message and return false
        /// else return true
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool IsValidData()
        {
            //check user name can not be blank
            if (string.IsNullOrEmpty(txtUserName.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "User Name"));
                txtUserName.Focus();
                return false;
            } 
            //check Old Password can not be blank
            if (string.IsNullOrEmpty(txtOldPassword.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Old Password"));
                txtOldPassword.Focus();
                return false;
            }else
            {
                m_User = clsMDUserBUS.Instance().GetUser(clsUserInfo.UserNo);
                //check inputting old password is correct
                if (!clsMDFunction.ValidateMD5HashData(txtOldPassword.Text, m_User.Password))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_ITEM_INCORRECT, "Old Password"));
                    txtOldPassword.Focus();
                    return false;
                }
            }
            //check New Password can not be blank
            if (string.IsNullOrEmpty(txtNewPassword.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "New Password"));
                txtNewPassword.Focus();
                return false;
            }
            else
            {
                //check min length password
                if (txtNewPassword.Text.Length < 8)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, "New password must be at least 8 characters.");
                    txtNewPassword.Focus();
                    return false;
                }
                ////check password must be the combination of alphabet, numeric character and special character(!@#$%^&*+=)
                //if (!IsPatternPassword(txtNewPassword.Text))
                //{
                //    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, "New password must be the combination of "
                //                                                                            + Environment.NewLine + "alphabet, numeric character and special character(!@#$%^&*+=)");
                //    txtNewPassword.Focus();
                //    return false;
                //}
                ////check Password is not the same with "n" old password. n will be defined in Parameter
                //DataTable dtPassHistory = clsMDUserBUS.Instance().GetPasswordHistory(clsUserInfo.UserNo);
                //DataRow[] rows = dtPassHistory.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_PASSWORD, clsMDFunction.GetMD5HashData(txtNewPassword.Text)));
                //if (rows.Length > 0)
                //{
                //    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, "You cannot use this password. Please try another password.");
                //    txtNewPassword.Focus();
                //    return false;
                //}
                //check new password can not be same old password
                if(clsMDFunction.ValidateMD5HashData(txtNewPassword.Text, m_User.Password))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, "New password can not be same old password.");
                    txtNewPassword.Focus();
                    return false;
                }
                //check re-new pass can not be blank
                if (string.IsNullOrEmpty(txtReNewPassword.Text.Trim()))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Re-new Password"));
                    txtReNewPassword.Focus();
                    return false;
                }
                else
                {
                    //check re-new password must be same new password
                    if (txtNewPassword.Text.CompareTo(txtReNewPassword.Text) != 0)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.ERR_RE_NEW_PASSWORD_NOT_MATCH);
                        txtReNewPassword.Focus();
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool IsDataChanged()
        {
            if (string.IsNullOrEmpty(txtOldPassword.Text.Trim())
                && string.IsNullOrEmpty(txtNewPassword.Text.Trim()) 
                && string.IsNullOrEmpty(txtReNewPassword.Text.Trim()))
            {
                return false;
            }
            else
            {
                return true;
            } 
        }

        /// <summary>
        /// Check Password must be the combination of alphabet, numeric character and special character
        /// </summary>
        /// <param name="pwd"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool IsPatternPassword(string pwd)
        {            
            Match match = Regex.Match(pwd, clsMDConstant.PATTERN_PASSWORD, RegexOptions.None);

            // Here we check the Match instance.
            if (match.Success)
            {
                return true;
            }
            return false;
        }
    }
}
