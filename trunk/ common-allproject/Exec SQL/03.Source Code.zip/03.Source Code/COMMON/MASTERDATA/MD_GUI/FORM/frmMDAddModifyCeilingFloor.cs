﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage ceiling floor
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDAddModifyCeilingFloor : frmMDMaster
	{
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        /// <summary>
        /// close form not check changed data
        /// </summary>
        bool m_ForceClose = false;

		/// <summary>
		/// CCY Pair
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string m_CCYPair = "";
		/// <summary>
		/// Ceiling
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string m_Ceiling = "";
		/// <summary>
		/// Floor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string m_Floor = "";
		/// <summary>
		/// Value to show if the data is changed or not
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		bool m_IsChange = false;
		/// <summary>
		/// Action type: create or modify
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		int m_ActionType = -1;
		/// <summary>
		/// Ceiling / Floor ID of this screen
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		int m_CeilingFloorID = -1;

		/// <summary>
		/// clsMDCeilingFloorBus object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsMDCeilingFloorBUS m_MDCeilingFloorBUS = new clsMDCeilingFloorBUS();

		bool CommonError = false;
		
		/// <summary>
		/// Constructor for creating ceiling/floor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmMDAddModifyCeilingFloor()
		{
			InitializeComponent();
            try
            {
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_ActionType = (int)CommonValue.CeilingFloorAction.Create;
                Init();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				CommonError = true;
            }
		}
		
		/// <summary>
		/// Constructor for modifying ceiling/floor
		/// </summary>
		/// <param name="iCeilingFloorID">Ceiling/Floor ID</param>
		/// <param name="strCCYPair">CCY Pair</param>
		/// <param name="strCeiling">Ceiling value</param>
		/// <param name="strFloor">Floor value</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmMDAddModifyCeilingFloor(int iCeilingFloorID, string strCCYPair, string strCeiling, string strFloor)
		{
			InitializeComponent();
            try
            {
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_CCYPair = strCCYPair;
                m_Ceiling = strCeiling.Trim();
                m_Floor = strFloor.Trim();
                m_CeilingFloorID = iCeilingFloorID;
                m_ActionType = (int)CommonValue.CeilingFloorAction.Modify;
                m_CeilingFloorID = iCeilingFloorID;
                Init();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				CommonError = true;
            }
		}

		/// <summary>
		/// Inititialize value for controls
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void Init()
		{
			LoadCurrencyPair(cbbCCYPair);
			if (cbbCCYPair.Items.Count == 0)
			{
				List<CbbObject> lstCCYPair = clsMDCeilingFloorBUS.Instance().GetCurencyPairList();
				cbbCCYPair.DataSource = lstCCYPair;
				cbbCCYPair.DisplayMember = clsMDConstant.DISPLAY;
				cbbCCYPair.ValueMember = clsMDConstant.VALUE;
			}
			switch (m_ActionType)
			{
				case (int) CommonValue.CeilingFloorAction.Modify:

					this.Text = "Modify Ceiling & Floor";
					cbbCCYPair.Enabled = false;
					cbbCCYPair.SelectedIndex = cbbCCYPair.FindString(m_CCYPair);
					txtCeiling.Text = m_Ceiling;
					txtFloor.Text = m_Floor;
					break;
				case (int) CommonValue.CeilingFloorAction.Create:
					this.Text = "Create Ceiling & Floor";
					cbbCCYPair.Enabled = true;
					break;
			}
			m_IsChange = false;
		}
	
		/// <summary>
		/// Check valid conditions of controls's value
		/// </summary>
		/// <returns>True if valid, false otherwise</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool CheckValidCondition()
		{
			bool isValid = false;
			if (cbbCCYPair.SelectedIndex == 0)
			{
				clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " [" + CCY_PAIR + "]"));
				cbbCCYPair.Focus();
			}
			else if (txtCeiling.Text.Trim() == "")
			{
				clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " [" + CEILING + "]"));
				txtCeiling.Focus();
			}
			else if (txtFloor.Text.Trim() == "")
			{
				clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " [" + FLOOR + "]"));
				txtFloor.Focus();
			}
			else
				isValid = true;
			if (!isValid)
				DialogResult = DialogResult.None;
			if (isValid == false)
				m_IsChange = true;
			return isValid;
		}
		
		/// <summary>
		/// Save ceiling/floor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool SaveCeiling()
		{
            try
            {
                if (CheckValidCondition())
                {
                    bool isAllowToWrite = true;
                    ///- User clicks on “Save” button.
                    ///- System display a confirm message box “Are you sure to save data?”
                    ///- User clicks on “Yes” button. 
                    string strCeiling = txtCeiling.Text.Trim().Replace(",", "");
                    string strFloor = txtFloor.Text.Trim().Replace(",", "");
                    int iCCYCode = int.Parse(((CbbObject)cbbCCYPair.SelectedItem).Value.ToString());
                    bool isOverride = false;
                    try
                    {
                        ///- System validates data and saves it to database.				
                        switch (m_ActionType)
                        {
                            ///- In case of creating new 
                            case (int)CommonValue.CeilingFloorAction.Create:
                                ///Ceiling.Floor that already existed in DB, 
                                int iCeilingFloorID = int.Parse(((CbbObject)cbbCCYPair.SelectedItem).Value.ToString());
                                if (m_MDCeilingFloorBUS.CheckExistCeilingFloor(iCeilingFloorID) > 0)
                                {
                                    DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_OVERRIDE_CEILING_FLOOR);
                                    ///system will alert a warning message. 
                                    if (result == DialogResult.Yes)
                                    ///If user agrees to override data, system will update 
                                    {
                                        isOverride = true;
                                        m_CeilingFloorID = iCeilingFloorID;
                                        if (m_MDCeilingFloorBUS.OverideCeilingFloor(iCCYCode, strCeiling, strFloor) > 0)
                                        {
                                            WriteLog(isOverride, isAllowToWrite);
                                            ///- System will popup a message to announce “Data was saved successfully”
                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, OVERRIDING, CEILING_FLOOR));
                                            this.m_ForceClose = true;
                                        }
                                        else
                                        {
                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, OVERRIDING, CEILING_FLOOR));
                                        }
                                    }
                                    else isAllowToWrite = false;
                                }
                                else
                                {
                                    int iNewCeilingFloorID = m_MDCeilingFloorBUS.CreateCeilingFloor(iCCYCode, strCeiling, strFloor);
                                    if (iNewCeilingFloorID != m_CeilingFloorID)
                                    {
                                        WriteLog(isOverride, isAllowToWrite);
                                        ///- System will popup a message to announce “Data was saved successfully”
                                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, CREATING, CEILING_FLOOR));
                                        m_CeilingFloorID = iNewCeilingFloorID;
                                    }
                                    else
                                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, CREATING, CEILING_FLOOR));
                                }
                                break;

                            case (int)CommonValue.CeilingFloorAction.Modify:
                                if (m_MDCeilingFloorBUS.UpdateCeilingFloor(m_CeilingFloorID, iCCYCode, strCeiling, strFloor) > 0)
                                {
                                    WriteLog(isOverride, isAllowToWrite);
                                    ///- System will popup a message to announce “Data was saved successfully”
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, MODIFYING, CEILING_FLOOR));
                                    this.m_ForceClose = true;
                                }
                                else
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, MODIFYING, CEILING_FLOOR));
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        this.m_ForceClose = true;
                        if (m_MDCeilingFloorBUS.DAL.m_transaction != null)
                            m_MDCeilingFloorBUS.RollBack();
                        clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                        Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                    }
                    ///- In case of actor clicks [No] on confirm message box, system will not save data in database and close confirm message.
                    ///- Operation log wil be saved.
                    ///
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                if (m_MDCeilingFloorBUS.DAL.m_transaction != null)
                    m_MDCeilingFloorBUS.RollBack();
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            return true;
		}
		
		/// <summary>
		/// Writelog
		/// </summary>
		/// <param name="isOverride">Write for isoverride case</param>
		/// <param name="isAllowToWrite">This function is allowed to excute not not</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void WriteLog(bool isOverride, bool isAllowToWrite)
		{
			if (isAllowToWrite == false)
				return;
			//History Header
			clsMDLogBase logBase = new clsMDLogBase();
			logBase.ApplicationName = this.Text;
			logBase.UserID = clsUserInfo.UserNo.ToString();
			logBase.Module = clsMDConstant.MODULE_MD;
			logBase.Key = m_CeilingFloorID.ToString();
			clsMDLogInformation logInfo = new clsMDLogInformation();
			if (isOverride)
			{
				logBase.Action = (int) CommonValue.ActionType.Update;

				if (m_Ceiling != txtCeiling.Text)
				{
					logInfo = new clsMDLogInformation();
					logInfo.FieldName = CEILING;
					logInfo.OldValue = m_Ceiling.ToString();
					logInfo.NewValue = txtCeiling.Text;
					logBase.LstLogInformation.Add(logInfo);
				}
				if (m_Floor != txtFloor.Text)
				{
					logInfo = new clsMDLogInformation();
					logInfo.FieldName = FLOOR;
					logInfo.OldValue = m_Floor.ToString();
					logInfo.NewValue = txtFloor.Text;
					logBase.LstLogInformation.Add(logInfo);
				}
			}
			else
				switch (m_ActionType)
				{
					case (int) CommonValue.ActionType.Update:
						logBase.Action = (int) CommonValue.ActionType.Update;

						if (m_Ceiling != txtCeiling.Text)
						{
							logInfo = new clsMDLogInformation();
							logInfo.FieldName = CEILING;
							logInfo.OldValue = m_Ceiling.ToString();
							logInfo.NewValue = txtCeiling.Text;
							logBase.LstLogInformation.Add(logInfo);
						}
						if (m_Floor != txtFloor.Text)
						{
							logInfo = new clsMDLogInformation();
							logInfo.FieldName = FLOOR;
							logInfo.OldValue = m_Floor.ToString();
							logInfo.NewValue = txtFloor.Text;
							logBase.LstLogInformation.Add(logInfo);
						}

						break;
					case (int) CommonValue.ActionType.New:

						logBase.Action = (int) CommonValue.ActionType.New;

						logInfo = new clsMDLogInformation();
						logInfo.FieldName = CEILING;
						logInfo.OldValue = string.Empty;
						logInfo.NewValue = txtCeiling.Text;
						logBase.LstLogInformation.Add(logInfo);

						logInfo = new clsMDLogInformation();
						logInfo.FieldName = FLOOR;
						logInfo.OldValue = string.Empty;
						logInfo.NewValue = txtFloor.Text;
						logBase.LstLogInformation.Add(logInfo);

						break;
				}
			logBase.WirteLog(m_MDCeilingFloorBUS.DAL);
			if (m_MDCeilingFloorBUS.DAL.m_transaction != null)
				m_MDCeilingFloorBUS.Commit();
			DialogResult = DialogResult.OK;
			m_IsChange = false;
		}
		
		/// <summary>
		/// Save ceiling/floor even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnSave_Click(object sender, EventArgs e)
		{
            DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_SAVE_DATA);
            if (result == DialogResult.Yes)
            {
                SaveCeiling();
            }
            else if (result == DialogResult.No)
            {
                m_IsChange = false;
                DialogResult = DialogResult.No;
            }
		}
	
		/// <summary>
		/// Cancel even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close(); 
		}
		
		/// <summary>
		/// Form closing even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void frmMasAddCeilingFloor_FormClosing(object sender, FormClosingEventArgs e)
		{
            if (!this.m_ForceClose)
            {
                if (m_IsChange)
                {
                    DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                    if (result == DialogResult.Yes)
                    {
                        if (!SaveCeiling())
                        {
                            e.Cancel = true;
                        }
                    }
                    else if (result == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                    }
                }
            }
		}
		
		/// <summary>
		/// Selected index changed on combobox even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void cbbCCY_SelectedIndexChanged(object sender, EventArgs e)
		{
			m_IsChange = true;
		}

		/// <summary>
		/// Ceiling text changed even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void txtCeiling_TextChanged(object sender, EventArgs e)
		{
			m_IsChange = true; 
			
		}

		/// <summary>
		/// Floor text changed even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void txtFloor_TextChanged(object sender, EventArgs e)
		{
			m_IsChange = true;
		}

		/// <summary>
		/// Ceiling textbox left even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void txtCeiling_Leave(object sender, EventArgs e)
		{
			//if (txtCeiling.Text.Trim() == "")
			//    txtCeiling.Text = "0";
		}

		/// <summary>
		/// Floor textbox left even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void txtFloor_Leave(object sender, EventArgs e)
		{
			//if (txtFloor.Text.Trim() == "")
			//    txtFloor.Text = "0";
		}

		/// <summary>
		/// Text update even of CCY Pair combobox even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void cbbCCYPair_TextUpdate(object sender, EventArgs e)
		{
			m_IsChange = true;
		}

		/// <summary>
		/// Selected index changed even of CCY Pair comvbobox
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void cbbCCYPair_SelectedIndexChanged(object sender, EventArgs e)
		{
			m_IsChange = true;
		}

		/// <summary>
		/// Form shown even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void frmMDAddModifyCeilingFloor_Shown(object sender, EventArgs e)
		{
			if(CommonError)
			{
				this.m_ForceClose = true;
				this.Close();
			}
			m_IsChange = false;
		}
	}
}