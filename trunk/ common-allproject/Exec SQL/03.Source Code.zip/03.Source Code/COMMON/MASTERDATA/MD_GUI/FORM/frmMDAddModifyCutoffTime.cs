﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-24 +0700 (Fri, 24 may 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage CutoffTime
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Config.Classes;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;
using System.Text.RegularExpressions;

namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDAddModifyCutoffTime : frmMDMaster
	{
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        /// <summary>
        /// Is close form not check changed data
        /// </summary>
        bool m_ForceClose = false;
		/// <summary>
		/// CCY
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		string m_CCY;
		/// <summary>
		/// Transaction Type
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		string m_TransactionType;
		/// <summary>
		/// CutoffTime
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		string m_CutoffTime = "";
		/// <summary>
		/// CutoffTime ID
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		int m_CutoffTimeId;
		/// <summary>
		/// Action type: create or modify
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		int m_ActionType = -1;
		/// <summary>
		/// Value to show id the data is changed or not
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private bool m_IsChange = false;
		/// <summary>
		/// Form text: update CutoffTime case
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private const string UPDATE_CUTOFFTIME = "Modify Cut-off Time";
		/// <summary>
		/// Form text: create CutoffTime case
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private const string CREATE_CUTOFFTIME = "Create Cut-off Time"; 
		/// <summary>
		/// CCY
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		const string CCY = "CCY";
		/// <summary>
		/// Transaction type string
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		const string TRANSACTION_TYPE= "Transaction Type";		
		/// <summary>
		/// clsMDCutoffTimeBus Object
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private clsMDCutoffTimeBUS m_MDCutoffTimeBUS = new clsMDCutoffTimeBUS();

		/// <summary>
		/// Constructor: for create CutoffTime case
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		public frmMDAddModifyCutoffTime()
		{
			InitializeComponent();
            
            try
            {
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_ActionType = (int)CommonValue.ThresholdAction.Create;
                Init();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// Constructor: for update CutoffTime case
		/// </summary>
		/// <param name="strCCY">CCY</param>
		/// <param name="strTransactionType">Transaction Type</param>
		/// <param name="iCutoffTime">CutoffTime</param>
		/// <param name="iCutoffTimeId">CutoffTime ID</param>
        public frmMDAddModifyCutoffTime(string strCCY, string strTransactionType, string strCutoffTime, int iCutoffTimeId)
		{
			InitializeComponent();
            try
            {
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_CCY = strCCY;
                m_TransactionType = strTransactionType;
                m_CutoffTime = strCutoffTime;
                m_ActionType = (int)CommonValue.CutoffTimeAction.Modify;
                m_CutoffTimeId = iCutoffTimeId;
                Init();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}
	
		/// <summary>
		/// Initialize controls's value
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void Init()
		{
            SetFormStyleCommon();
            //LoadTransactionTypeWithoutEmptyItem(cbbTransactionType);
            LoadCurrency(cbbCCY);
            if (cbbCCY.Items.Count == 0)
            {
                List<CbbObject> lstCbbObj = new List<CbbObject>();
                lstCbbObj = clsMDCeilingFloorBUS.Instance().GetCurencyList();
                cbbCCY.DataSource = lstCbbObj;
            }

            List<CbbObject> lstTransactionType = new List<CbbObject>();
            lstTransactionType = clsMDGetDataCombobox.Instance().TransactionTypeWithoutEmptyItem;
            if (lstTransactionType == null)
            {
                lstTransactionType = clsMDBus.Instance().GetListMDParametersWithoutEmptyItem(clsMDConstant.PARAMETERS_TRANSACTION_TYPE);
            }
            switch (m_ActionType)
            {
                case (int)CommonValue.CutoffTimeAction.Modify:
                    this.Text = UPDATE_CUTOFFTIME;
                    //cbbTransactionType.Enabled = false;
                    cbbCCY.Enabled = false;
                    dtgTransactionType.ReadOnly = true;
                    dtgTransactionType.DefaultCellStyle.BackColor = clsMDConstant.BG_DGV_READONLY_COLUMN;
                    //cbbTransactionType.SelectedIndex = cbbTransactionType.FindString(m_TransactionType);
                    cbbCCY.SelectedIndex = cbbCCY.FindString(m_CCY);
                    mtxtCutoffTime.Text = m_CutoffTime + "";
                    if (lstTransactionType != null)
                    {
                        for (int i = 0; i < lstTransactionType.Count; i++)
                        {
                            if (((CbbObject)lstTransactionType[i]).Display.ToString() == m_TransactionType)
                            {
                                dtgTransactionType.Rows.Add(true, ((CbbObject)lstTransactionType[i]).Display, ((CbbObject)lstTransactionType[i]).Value);
                            }
                            else
                            {
                                dtgTransactionType.Rows.Add(false, ((CbbObject)lstTransactionType[i]).Display, ((CbbObject)lstTransactionType[i]).Value);
                            }
                            
                        }
                    }
                    break;
                case (int)CommonValue.CutoffTimeAction.Create:
                    this.Text = CREATE_CUTOFFTIME;
                    //cbbTransactionType.Enabled = true;
                    cbbCCY.Enabled = true;
                    dtgTransactionType.ReadOnly = false;
                    dtgTransactionType.DefaultCellStyle.BackColor = Color.White;
                    if (lstTransactionType != null)
                    {
                        for (int i = 0; i < lstTransactionType.Count; i++)
                        {
                            dtgTransactionType.Rows.Add(false, ((CbbObject)lstTransactionType[i]).Display, ((CbbObject)lstTransactionType[i]).Value);
                        }
                    }
                    break;
            }

			m_IsChange = false;
		}
		
		/// <summary>
		/// Check if user choose any transaction type or not
		/// </summary>
		/// <returns>True if user selected at least 1 item, false otherwise</returns>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private bool DontHaveSelectTransactionType()
		{
            for (int i = 0; i < dtgTransactionType.Rows.Count; i++)
            {
                if (dtgTransactionType.Rows[i].Cells[0].Value.ToString() == true.ToString())
                {
                    return false;
                }
            }
			return true;
		}

        /// <summary>
        /// Check if user choose any transaction type or not
        /// </summary>
        /// <returns>True if user selected at least 1 item, false otherwise</returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private bool CheckValidCutoffTime()
        {
            string strCutoffTime = mtxtCutoffTime.Text;
            if (strCutoffTime.Trim().Length == 5)
            {
                string[] arrLetters = Regex.Split(strCutoffTime, ":");
                int so1 = int.Parse(arrLetters[0].ToString());
                int so2 = int.Parse(arrLetters[1].ToString());
                if (so1 > 23 || so2 > 59)
                    return false;
                return true;    
            }
            return false;
        }
		
		/// <summary>
		/// Check if the condition input on form are valid or not
		/// </summary>
		/// <returns>True if data valid, false otherwise</returns>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private bool CheckValidCondition()
		{
			bool isValid = false;
			if (cbbCCY.SelectedIndex == 0)
			{
				clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " [" + CCY + "]"));
				cbbCCY.Focus();
			}
			else if (DontHaveSelectTransactionType())
			{
				clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " [" + TRANSACTION_TYPE + "]"));
				dtgTransactionType.Focus();
			}
            else if (!CheckValidCutoffTime())
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT_VALID, " [" + CUTOFFTIME + "]"));
                mtxtCutoffTime.Focus();
            }
            else
            {
                isValid = true;
            }
			if (!isValid)
				DialogResult = DialogResult.None;
			if (isValid == false)
				m_IsChange = true;
			return isValid;
		}
		
		/// <summary>
		/// Check if CutoffTime is exist not not
		/// </summary>
		/// <param name="resultExist">Dialog result of confirming override or not</param>
		/// <returns>True if the CutoffTime id exist, false otherwise</returns>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private bool CheckExistCutoffTime(ref DialogResult resultExist)
		{
            if (m_ActionType == (int)CommonValue.ActionType.Update)
            {
                return false;
            }
			int iItemExist = 0;
			for (int i = 0; i < dtgTransactionType.Rows.Count; i++)
			{
				if (dtgTransactionType.Rows[i].Cells["colCheck"].Value.ToString() == true.ToString())
				{
					string strCCYCode = ((CbbObject) cbbCCY.SelectedItem).Value.ToString();
					int iTransactionType = int.Parse(dtgTransactionType.Rows[i].Cells["colTransactionValue"].Value.ToString());
					DataTable dtbCurrencyCutoffTimeExist = m_MDCutoffTimeBUS.CheckExistCutoffTime(strCCYCode, iTransactionType);
					iItemExist += dtbCurrencyCutoffTimeExist.Rows.Count;
				}
			}
			if (iItemExist > 0)
			{
                DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_OVERRIDE_CUTOFFTIME);
				if (result == DialogResult.Yes)
					return true;
				else if (result == DialogResult.Cancel)
				{
					resultExist = DialogResult.Cancel;
					return false;
				}
				else
				{
					resultExist = DialogResult.No;
					return false;
				}
			}
			return true;
		}
		
		/// <summary>
		/// Save CutoffTime
		/// </summary>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void SaveCutoffTime()
		{
            try
            {                
                bool isOverride = false;
               
                if (CheckValidCondition())
                {
                    DialogResult resultCheckExist = new DialogResult();
                    bool isAllowToOverride = CheckExistCutoffTime(ref resultCheckExist);
                    if (resultCheckExist == DialogResult.Cancel || resultCheckExist == DialogResult.No)
                    {
                        return;
                    }
                    string strCCYCode = ((CbbObject)cbbCCY.SelectedItem).Value.ToString();
                    string strCutoffTime = mtxtCutoffTime.Text.Trim();
                    string strCutoffTimeExist = "";
                    int iCutoffTimeIdExist = -1;
                    int iTransactionType = -1;// int.Parse(((CbbObject) cbbTransactionType.SelectedItem).Value.ToString());
                    int iSuccessCount = 0;
                    for (int i = 0; i < dtgTransactionType.Rows.Count; i++)
                    {
                        if (dtgTransactionType.Rows[i].Cells["colCheck"].Value.ToString() == true.ToString())
                        {
                            isOverride = false;
                            iTransactionType = int.Parse(dtgTransactionType.Rows[i].Cells["colTransactionValue"].Value.ToString());

                            ///- System validates data and saves it to database.				
                            switch (m_ActionType)
                            {
                                ///- In case of creating new 
                                case (int)CommonValue.CeilingFloorAction.Create:
                                    ///Ceiling.Floor that already existed in DB, 
                                    DataTable dtbCurrencyCutoffTimeExist = m_MDCutoffTimeBUS.CheckExistCutoffTime(strCCYCode, iTransactionType);
                                    if (dtbCurrencyCutoffTimeExist.Rows.Count > 0)
                                    {
                                        iCutoffTimeIdExist = int.Parse(dtbCurrencyCutoffTimeExist.Rows[0]["CutoffTimeId"].ToString());
                                        strCutoffTimeExist = dtbCurrencyCutoffTimeExist.Rows[0]["CutoffTime"].ToString();

                                        ///system will alert a warning message. 
                                        //if (DialogResult.Yes == clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_OVVERIDE_THREADHOLD))
                                        if (isAllowToOverride)
                                        {	///If user agrees to override data, system will update 
                                            isOverride = true;
                                            m_CutoffTimeId = iCutoffTimeIdExist;
                                            if (m_MDCutoffTimeBUS.OverideCutoffTime(iCutoffTimeIdExist, strCutoffTime) > 0)
                                            {
                                                iSuccessCount++;
                                            }
                                            ///- System will popup a message to announce “Data was saved successfully”									
                                            //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, OVERRIDING, CutoffTime));
                                            //else
                                            //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, OVERRIDING, CutoffTime));
                                        }
                                    }
                                    else
                                    {
                                        int iNewCutoffTimeID = m_MDCutoffTimeBUS.CreateCutoffTime(strCCYCode, iTransactionType, strCutoffTime);
                                        if (iNewCutoffTimeID != m_CutoffTimeId)
                                        {
                                            ///- System will popup a message to announce “Data was saved successfully”
                                            //clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS,CREATING, CutoffTime));
                                            m_CutoffTimeId = iNewCutoffTimeID;
                                            iSuccessCount++;
                                        }
                                        //else
                                        //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, CREATING, CutoffTime));
                                    }
                                    break;
                                case (int)CommonValue.CeilingFloorAction.Modify:
                                    if (m_MDCutoffTimeBUS.UpdateCutoffTime(m_CutoffTimeId, strCCYCode, iTransactionType, strCutoffTime) > 0)
                                    {
                                        iSuccessCount++;
                                    }
                                    ///- System will popup a message to announce “Data was saved successfully”
                                    //{
                                    //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, MODIFYING, CutoffTime));
                                    //}
                                    //else
                                    //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, MODIFYING, CutoffTime));
                                    break;

                            }

                            ///- In case of actor clicks [No] on confirm message box, system will not save data in database and close confirm message.
                            ///- Operation log wil be saved.
                        }
                    }
                    if (m_ActionType == (int)CommonValue.ActionType.New)
                    {
                        if (iSuccessCount > 0)
                        {
                            WriteLog(isOverride, m_ActionType, iTransactionType, m_CutoffTimeId, strCutoffTimeExist);
                            //- System will popup a message to announce “Data was saved successfully”									
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, CREATING, CUTOFFTIME));
                            this.m_ForceClose = true;
                        }
                        else
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, CREATING, CUTOFFTIME));
                    }
                    else
                    {
                        if (iSuccessCount > 0)
                        {
                            WriteLog(isOverride, m_ActionType, iTransactionType, m_CutoffTimeId, strCutoffTimeExist);
                            //- System will popup a message to announce “Data was saved successfully”									
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, MODIFYING, CUTOFFTIME));
                            this.m_ForceClose = true;
                        }
                        else
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, MODIFYING, CUTOFFTIME));
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                if (m_MDCutoffTimeBUS.DAL.m_transaction != null)
                    m_MDCutoffTimeBUS.RollBack();
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }		
			//m_IsChange = false;
		}
		
		/// <summary>
		/// Write log
		/// </summary>
		/// <param name="isOverride">Is override case or not</param>
		/// <param name="iActionType">action type</param>
		/// <param name="iTransactionType">transaction type</param>
		/// <param name="iCutoffTimeId">CutoffTime ID</param>
		/// <param name="strCutoffTimeExist">CutoffTime exist string, in case of override</param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void WriteLog(bool isOverride, int iActionType, int iTransactionType, int iCutoffTimeId, string strCutoffTimeExist)
		{	//History Header
			clsMDLogBase logBase = new clsMDLogBase();
			logBase.ApplicationName = this.Text;
			logBase.UserID = clsUserInfo.UserNo.ToString();
			logBase.Module = clsMDConstant.MODULE_MD;
			logBase.Key = iCutoffTimeId.ToString();
			clsMDLogInformation logInfo = new clsMDLogInformation();
			if (isOverride)
			{
				logBase.ApplicationName = UPDATE_CUTOFFTIME;
				logBase.Action = (int) CommonValue.ActionType.Update; 
				if (!m_CutoffTime.Equals(mtxtCutoffTime.Text.Trim()))
				{
					logInfo = new clsMDLogInformation();
                    logInfo.FieldName = CUTOFFTIME;
					logInfo.OldValue = strCutoffTimeExist;
					logInfo.NewValue = mtxtCutoffTime.Text;
					logBase.LstLogInformation.Add(logInfo);
				} 
			}
			else
				switch (iActionType)
				{
					case (int) CommonValue.ActionType.Update:
						logBase.Action = (int) CommonValue.ActionType.Update;

						if (!m_CutoffTime.Equals(mtxtCutoffTime.Text.Trim()))
						{
							logInfo = new clsMDLogInformation();
                            logInfo.FieldName = CUTOFFTIME;
							logInfo.OldValue = m_CutoffTime.ToString();
                            logInfo.NewValue = mtxtCutoffTime.Text;
							logBase.LstLogInformation.Add(logInfo);
						} 
						break;
					case (int) CommonValue.ActionType.New:

						logBase.Action = (int) CommonValue.ActionType.New;

						logInfo = new clsMDLogInformation();
						logInfo.FieldName = CCY;
						logInfo.OldValue = string.Empty;
						logInfo.NewValue = ((CbbObject) cbbCCY.SelectedItem).Display.ToString();
						logBase.LstLogInformation.Add(logInfo);

						logInfo = new clsMDLogInformation();
						logInfo.FieldName = TRANSACTION_TYPE;
						logInfo.OldValue = string.Empty;
						logInfo.NewValue = iTransactionType.ToString();
						logBase.LstLogInformation.Add(logInfo); 

						logInfo = new clsMDLogInformation();
                        logInfo.FieldName = CUTOFFTIME;
						logInfo.OldValue = string.Empty;
						logInfo.NewValue = mtxtCutoffTime.Text;
						logBase.LstLogInformation.Add(logInfo);
						break;
				}
			logBase.WirteLog(m_MDCutoffTimeBUS.DAL);
			m_MDCutoffTimeBUS.Commit();
			DialogResult = DialogResult.OK;
			m_IsChange = false;
		}
		
		/// <summary>
		/// Save even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void btnSave_Click(object sender, EventArgs e)
		{
            DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_SAVE_DATA);
            ///- User clicks on “Save” button.
            ///- System display a confirm message box “Are you sure to save data?”
            ///- User clicks on “Yes” button.

            if (result == DialogResult.Yes)
                SaveCutoffTime();
            else if (result == DialogResult.No)
            {
                m_IsChange = false;
                DialogResult = DialogResult.No;
            }
		}

		/// <summary>
		/// Cancel even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
			//m_IsChange = false;
			this.Close();
		}

		/// <summary>
		/// Form closing even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void frmMasAddCeilingFloor_FormClosing(object sender, FormClosingEventArgs e)
		{
            if (!this.m_ForceClose)
            {
                Console.WriteLine(m_IsChange.ToString());
                if (m_IsChange)
                {
                    DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                    if (result == DialogResult.Yes)
                        SaveCutoffTime();
                    else if (result == DialogResult.Cancel)
                        e.Cancel = true;
                }
            }
		}
		
		/// <summary>
		/// Seleted indexchanged even of combobox
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void cbbCCY_SelectedIndexChanged(object sender, EventArgs e)
		{
			m_IsChange = true;
		}

		/// <summary>
		/// CutoffTime textbox leave even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void mtxtCutoffTime_Leave(object sender, EventArgs e)
		{
			//if (mtxtCutoffTime.Text.Trim() == "")
			//    mtxtCutoffTime.Text = "0";
		}

		/// <summary>
		/// CutoffTime textbox changed even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void mtxtCutoffTime_TextChanged(object sender, EventArgs e)
		{
			m_IsChange = true;
		}

		/// <summary>
		/// Datagrid cell enter even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void dtgTransactionType_CellEnter(object sender, DataGridViewCellEventArgs e)
		{
            if (e.ColumnIndex == 0)
            {
                m_IsChange = true;
            }
			Console.WriteLine(m_IsChange.ToString());
		}

		/// <summary>
		/// Form shown even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: pqkhai
		/// @endcond
		private void frmMDAddModifyCutoffTime_Shown(object sender, EventArgs e)
		{
			m_IsChange = false;
		}
	}
}