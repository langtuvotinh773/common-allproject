﻿using System.Windows.Forms;

namespace Phoenix.Common.MasterData.UserControl
{
	public interface IStackedHeaderGenerator
	{
		Header GenerateStackedHeader(DataGridView objGridView);
	}
}