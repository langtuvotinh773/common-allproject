﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage threshold
 * of Master data module.
 */
using System;
using System.Data;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Dto;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using System.Collections.Generic;
namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDListThreshold : frmMDMaster
	{
		/// <summary>
		/// clsMDThresholdBus object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsMDThresholdBUS m_MDThresholdBUS = new clsMDThresholdBUS();
		/// <summary>
		/// For Security Checking
		/// </summary>
		clsSEAuthorizer m_Security = null;
		
		bool CommonError = false;
		
		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmMDListThreshold()
		{
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                LoadCurrency(cbbCCY);
                if (cbbCCY.Items.Count == 0)
                    cbbCCY.DataSource = clsMDCeilingFloorBUS.Instance().GetCurencyList();
                LoadTransactionType(cbbTransType);
                if (cbbTransType.Items.Count == 0)
                    cbbTransType.DataSource = clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_TRANSACTION_TYPE);

                SetFormStyleCommon();

                dtpUpdateTime.Text = "";
                //load list threshold default
                SearchAndFillData();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				CommonError = true;
            }
		}

		/// <summary>
		/// Search and fill threshold to datagridview
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void SearchAndFillData()
		{
			try
			{
				dtgThresholdList.Rows.Clear();
				string strCCYCode = cbbCCY.Items.Count > 0 ? ((CbbObject) cbbCCY.SelectedItem).Value.ToString() : "";
				int iTransactionType = cbbTransType.Items.Count > 0 ? int.Parse(((CbbObject) cbbTransType.SelectedItem).Value.ToString()) : 0;
				string strUpdateBy = txtUpdateBY.Text.Trim();
				DateTime? dtUpdateDate = dtpUpdateTime.Value;
				if (dtpUpdateTime.Text == "")
					dtUpdateDate = null;

				DataTable dtbThreshold = m_MDThresholdBUS.GetThresholdList(strCCYCode, iTransactionType, dtUpdateDate, strUpdateBy);

                List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
                DataGridViewRow row = new DataGridViewRow();
                //Suppend Layout
                dtgThresholdList.SuspendLayout();

                for (int i = 0; i < dtbThreshold.Rows.Count; i++)
                {
                    row = new DataGridViewRow();
                    row.CreateCells(dtgThresholdList);
                    row.Cells[dtgThresholdList.Columns["colCCY"].Index].Value = dtbThreshold.Rows[i]["CCYCode"];
                    row.Cells[dtgThresholdList.Columns["colTransactionType"].Index].Value = dtbThreshold.Rows[i]["TransactionType"];
                    row.Cells[dtgThresholdList.Columns["colThreshold"].Index].Value = decimal.Parse(dtbThreshold.Rows[i]["Threshold"].ToString());
                    row.Cells[dtgThresholdList.Columns["colUpdateTime"].Index].Value = DateTime.Parse(dtbThreshold.Rows[i]["UpdateDate"].ToString()).ToString(FORMAT_DDMMMYYYY);
                    row.Cells[dtgThresholdList.Columns["colUpdateBy"].Index].Value = dtbThreshold.Rows[i]["UserName"];
                    row.Cells[dtgThresholdList.Columns["colThresholdID"].Index].Value = dtbThreshold.Rows[i]["ThresholdId"];

                    row.Cells[dtgThresholdList.Columns["colThreshold"].Index].Style.Format = GetFormatDecimal(decimal.Parse(dtbThreshold.Rows[i]["Threshold"].ToString()));

                    lstRows.Add(row);
                }
                //Resume Layout
                dtgThresholdList.Rows.AddRange(lstRows.ToArray());
                dtgThresholdList.ResumeLayout();

				if (dtgThresholdList.Rows.Count > 0)
				{
					dtgThresholdList.Rows[0].Selected = true;
					SetAction();
				}
				else
				{
					clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, clsMDMessage.NO_TRANSACTION_FOUND);
					SetAction();
				}
			}
			catch (Exception ex)
			{
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
		}

		/// <summary>
		/// Set action 
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void SetAction()
		{
			if (dtgThresholdList.Rows.Count <= 0)
			{
				btnModify.Enabled = false;
				btnDelete.Enabled = false;
			}
			else
			{
				btnModify.Enabled = true;
				btnDelete.Enabled = true;
			}
		}
		
		/// <summary>
		/// Writelog
		/// </summary>
		/// <param name="iUserAction">User action</param>
		/// <param name="strKeyDelete">Key to delete</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void WriteLog(int iUserAction, string strKeyDelete)
		{	//History Header
			clsMDLogBase logBase = new clsMDLogBase();
			logBase.ApplicationName = this.Text;
			logBase.UserID = clsUserInfo.UserNo.ToString();
			logBase.Module = clsMDConstant.MODULE_MD;

			switch (iUserAction)
			{
				case (int) CommonValue.ActionType.Delete:
					logBase.Action = (int) CommonValue.ActionType.Delete;
					logBase.Key = strKeyDelete;
					logBase.WirteLog(m_MDThresholdBUS.DAL);


					break;
			}
			m_MDThresholdBUS.Commit();

		}

		/// <summary>
		/// Delete threshold even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnDelete_Click(object sender, EventArgs e)
		{
			try
			{
				if (dtgThresholdList.SelectedRows.Count <= 0)
					clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, THRESHOLD, DELETE));
				else
				{

					int iThresholdID = -1;
					string strMessageToWriteLog = "";
					string strCCYCode = "";
					string strTransactionTypeID = "";
					if (dtgThresholdList.SelectedRows.Count > 0)
					{
						iThresholdID = int.Parse(dtgThresholdList.SelectedRows[0].Cells["colThresholdID"].Value.ToString());
						strCCYCode = dtgThresholdList.SelectedRows[0].Cells["colCCY"].Value.ToString();
						strTransactionTypeID = dtgThresholdList.SelectedRows[0].Cells["colTransactionType"].Value.ToString();
					}
					if (clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_THRESHOLD) == DialogResult.Yes)
						if (m_MDThresholdBUS.DeleteThreshold(iThresholdID) > 0)
						{
                            WriteLog((int)CommonValue.ActionType.Delete, strMessageToWriteLog);
							clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, DELETING, THRESHOLD));
							SearchAndFillData();
							strMessageToWriteLog = iThresholdID.ToString() + " " + strCCYCode + " " + strTransactionTypeID;							
						}
						else
						{
							clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, DELETING, THRESHOLD));
							if (m_MDThresholdBUS.DAL != null)
								m_MDThresholdBUS.RollBack();
						}
				}
			}
			catch (Exception ex)
			{
                m_MDThresholdBUS.RollBack();
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
		}
				
		/// <summary>
		/// Search even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnSearch_Click(object sender, EventArgs e)
		{
			SearchAndFillData();
		}
		
		/// <summary>
		/// Close form even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		/// <summary>
		/// Modify even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnModify_Click(object sender, EventArgs e)
		{
            try
            {
                if (dtgThresholdList.SelectedRows.Count <= 0)
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "threshold", "modify"));
                else
                {
                    string strCCY = dtgThresholdList.SelectedRows[0].Cells["colCCY"].Value.ToString();
                    string strTransactionType = dtgThresholdList.SelectedRows[0].Cells["colTransactionType"].Value.ToString();
                    double iThreshold = double.Parse(dtgThresholdList.SelectedRows[0].Cells["colThreshold"].Value.ToString().Replace(",", ""));
                    int iThresholdID = int.Parse(dtgThresholdList.SelectedRows[0].Cells["colThresholdID"].Value.ToString());
                    frmMDAddModifyThreshold frm = new frmMDAddModifyThreshold(strCCY, strTransactionType, iThreshold, iThresholdID);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.ShowDialog();
                    SearchAndFillData();
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// Add threshold even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnAdd_Click(object sender, EventArgs e)
		{
            try
            {
                frmMDAddModifyThreshold frm = new frmMDAddModifyThreshold();
                frm.StartPosition = FormStartPosition.CenterScreen;
                DialogResult result = frm.ShowDialog();
                if (result == DialogResult.OK)
                    SearchAndFillData();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// Row removed even on datagrid
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void dtgTimeList_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
            try
            {
                SetAction();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// Form shown even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void frmMDListThreshold_Shown(object sender, EventArgs e)
		{
			if(CommonError)
			{
				this.Close();
            }
            //try
            //{
                
            //}
            //catch (Exception ex)
            //{
            //    //show error message
            //    clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            //    //save log exception
            //    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            //}
		}
	}
}