﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.Security.Com;
using Config.Classes;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDSearchData : frmMDMaster
    {
        //Current row focus
        public DataGridViewRow selectedRow = null;

        public clsSEAuthorizer _security = null;

         /// <summary>
        /// Constructor
        /// </summary>
        public frmMDSearchData()
        {       
            InitializeComponent();
			_security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            _security.CheckAuthorizationOnScreen(this);
        }

         /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="table"></param>
        public frmMDSearchData(DataTable table)
        {
            //Set common style for form
            SetFormStyleCommon();
            InitializeComponent();  
            dtgResult.ReadOnly = true;
            dtgResult.DataSource = table;
            dtgResult.RowHeadersVisible = false;
            //dtgResult.RowsDefaultCellStyle.BackColor = Color.White;
            //dtgResult.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(150, 254, 165);
            {
                    if (dtgResult.ColumnCount > 0)
                    {
                        dtgResult.Columns[0].Width = 150;
                        dtgResult.Columns[0].Frozen = true;
                        dtgResult.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
            }
        }

        /// <summary>
        /// Cell Double Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgResult_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dtgResult.SelectedRows.Count > 0)
            {
                selectedRow = dtgResult.SelectedRows[0];
                if (e.RowIndex >= 0)
                {
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
        }

        /// <summary>
        /// Button Close Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        /// <summary>
        /// DataGridView Key Down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgResult_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (dtgResult.SelectedRows.Count > 0)
                {
                    selectedRow = dtgResult.SelectedRows[0];
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    this.DialogResult = DialogResult.Cancel;
                    this.Close();
                }
            }
        }
    }
}
