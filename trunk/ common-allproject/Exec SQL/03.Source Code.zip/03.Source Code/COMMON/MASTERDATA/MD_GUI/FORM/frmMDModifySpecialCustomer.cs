﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-16 (Thu, 16 May 2013) $
 * ========================================================
 * This class is used to create or modify a customer
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDModifySpecialCustomer : frmMDMaster
    {
        #region Global Variable
        public clsMDCustomerDTO m_UpdatingCus;
        public event EventHandler OnSaved;
        public CommonValue.ActionType m_CurrentAction;
        bool m_ForceClose = false;
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        //Pivate member
        private string m_CustomerCode = "";
        private string m_FullName = "";
        private string m_ShortName = "";

        private int m_CustomerType = 0;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDModifySpecialCustomer class.
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public frmMDModifySpecialCustomer(string title)
        {
            InitializeComponent();

            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);

            this.Text = title;
            m_UpdatingCus = new clsMDCustomerDTO();
            m_CurrentAction = CommonValue.ActionType.New; //default

            // Disable all textbox
            txtCustCode.ReadOnly = true;
            txtFullName.ReadOnly = true;
            txtShortName.ReadOnly = true;
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Event click button "Save"
        /// System will update information customer into DB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            //disable all button
            EnableControl(false);
            try
            {
                //update information of customer to db
                if (SaveModifyAction() > 0)
                {
                    this.m_ForceClose = true;
                    if (OnSaved != null)
                    {
                        OnSaved(sender, e);
                    }
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //Enable control
            EnableControl(true);
        }

        /// <summary>
        /// Event click button "Cancel"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        /// <summary>
        /// Form Close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void frmMDModifySpecialCustomer_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                try
                {
                    if (!m_ForceClose)
                    {
                        //if data was changed on screen, display confirm message to save changed data
                        if (IsDataChanged())
                        {
                            //display message 'Do you want to save changes of data?'
                            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                            if (res == DialogResult.Yes)
                            {
                                //update information of dept
                                if (SaveAModifiedCus() > 0)
                                {
                                    this.m_ForceClose = true;
                                    if (OnSaved != null)
                                    {
                                        OnSaved(sender, e);
                                    }
                                    this.Close();
                                }
                                else//if save unsuccessfull, display error message and not close form
                                {
                                    e.Cancel = true;
                                }
                            }
                            else if (res == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.m_ForceClose = true;
                    //show error message
                    clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                    //save log exception
                    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                }
            }
        }
        #endregion    

        #region Member method
        /// <summary>
        /// load data to form
        /// </summary>
        /// <param name="obj">Customer object</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void SetData(clsMDCustomerDTO obj)
        {
            // Set data for Customer Code
            m_CustomerCode = obj.CustomerCode;
            txtCustCode.Text = m_CustomerCode;

            // Set data for Customer Code
            m_FullName = obj.FullName;
            txtFullName.Text = m_FullName;

            // Set data for Customer Code
            m_ShortName = obj.ShortName;
            txtShortName.Text = m_ShortName;

            //Set data for Special checkbox
            if (obj.Special == true)
                ckbSpecial.Checked = true;
            else
                ckbSpecial.Checked = false;
        }


        /// <summary>
        /// Save for action Modify Customer
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private int SaveModifyAction()
        {
            //display confirm message 'Are you sure to save customer?'
            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "customer"));
            if (res == DialogResult.Yes)
            {
                return SaveAModifiedCus();
            }
            else if (res == DialogResult.No)
            {
                this.m_ForceClose = true;
                this.Close();
            }
            return 0;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        private bool IsDataChanged()
        {
            if (this.m_UpdatingCus.Special == false && ckbSpecial.Checked || this.m_UpdatingCus.Special == true && !ckbSpecial.Checked)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Save a modify customer
        /// </summary>
        /// <returns></returns>
        private int SaveAModifiedCus()
        {
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //Update dept and Write data to log
            m_UpdatingCus = GetCustomerInfoFromControls();
            int iRow = clsMDCustomerBUS.Instance().UpdateCustomer(m_UpdatingCus, clsMDConstant.SPECIAL_CUSTOMER, logBase);
            // If Update OK
            if (iRow > 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Modifying", "customer"));
            }
            else if (iRow == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Modifying", "customer"));
            }
            else
            {
                this.Close();
            }
            return iRow;
        }

        /// <summary>
        /// Get customer information to modify
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private clsMDCustomerDTO GetCustomerInfoFromControls()
        {
            clsMDCustomerDTO dto = new clsMDCustomerDTO();
            dto.CustomerCode = m_UpdatingCus.CustomerCode;
            dto.FullName = m_UpdatingCus.FullName;
            dto.ShortName = m_UpdatingCus.ShortName;
            if (ckbSpecial.Checked)
                dto.Special = true;
            else
                dto.Special = false;
            return dto;
        }

        /// <summary>
        /// Enable or disable button action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void EnableControl(bool value)
        {
            btnSave.Enabled = value;
            btnCancel.Enabled = value;
        }

        /// <summary>
        /// Create data special customer to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private clsMDLogBase CreateDataSaveLog()
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = txtCustCode.Text.Trim(); //main key is customer code
            logBase.Action = (int)CommonValue.ActionType.Update;

            clsMDLogInformation logInfo = new clsMDLogInformation();

            //Special
            logInfo.FieldName = clsMDConstant.MD_COL_SPECIAL;            
            logInfo.OldValue = this.m_UpdatingCus.Special.ToString();
            logInfo.NewValue = ckbSpecial.Checked.ToString();
            logBase.LstLogInformation.Add(logInfo);           
            return logBase;
        }
        #endregion
    }
}
