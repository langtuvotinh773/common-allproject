﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDAddModifySBVMinMax
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSave = new System.Windows.Forms.Button();
            this.lblCCY = new System.Windows.Forms.Label();
            this.lblTenors = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbbCCY = new System.Windows.Forms.ComboBox();
            this.txtTenors = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDepositMax = new UserCtrl.ctrlMDNumberOnlyTextBox();
            this.lblDepositMax = new System.Windows.Forms.Label();
            this.txtDepositMin = new UserCtrl.ctrlMDNumberOnlyTextBox();
            this.lblDepositMin = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtLoanMax = new UserCtrl.ctrlMDNumberOnlyTextBox();
            this.lblLoanMax = new System.Windows.Forms.Label();
            this.txtLoanMin = new UserCtrl.ctrlMDNumberOnlyTextBox();
            this.lblLoanMin = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(132, 289);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblCCY
            // 
            this.lblCCY.AutoSize = true;
            this.lblCCY.Location = new System.Drawing.Point(59, 29);
            this.lblCCY.Name = "lblCCY";
            this.lblCCY.Size = new System.Drawing.Size(28, 13);
            this.lblCCY.TabIndex = 0;
            this.lblCCY.Text = "CCY";
            // 
            // lblTenors
            // 
            this.lblTenors.AutoSize = true;
            this.lblTenors.Location = new System.Drawing.Point(59, 50);
            this.lblTenors.Name = "lblTenors";
            this.lblTenors.Size = new System.Drawing.Size(40, 13);
            this.lblTenors.TabIndex = 1;
            this.lblTenors.Text = "Tenors";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(213, 289);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cbbCCY
            // 
            this.cbbCCY.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbCCY.FormattingEnabled = true;
            this.cbbCCY.Location = new System.Drawing.Point(114, 25);
            this.cbbCCY.Name = "cbbCCY";
            this.cbbCCY.Size = new System.Drawing.Size(176, 21);
            this.cbbCCY.TabIndex = 0;
            // 
            // txtTenors
            // 
            this.txtTenors.Location = new System.Drawing.Point(114, 50);
            this.txtTenors.MaxLength = 7;
            this.txtTenors.Name = "txtTenors";
            this.txtTenors.Size = new System.Drawing.Size(176, 20);
            this.txtTenors.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDepositMax);
            this.groupBox1.Controls.Add(this.lblDepositMax);
            this.groupBox1.Controls.Add(this.txtDepositMin);
            this.groupBox1.Controls.Add(this.lblDepositMin);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(64, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(226, 83);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Deposit";
            // 
            // txtDepositMax
            // 
            this.txtDepositMax.CustomDecimal = 0;
            this.txtDepositMax.CustomLenght = 20;
            this.txtDepositMax.Location = new System.Drawing.Point(94, 45);
            this.txtDepositMax.Name = "txtDepositMax";
            this.txtDepositMax.NeedDecimal = true;
            this.txtDepositMax.Size = new System.Drawing.Size(110, 20);
            this.txtDepositMax.StringFormat = "";
            this.txtDepositMax.TabIndex = 3;
            this.txtDepositMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblDepositMax
            // 
            this.lblDepositMax.AutoSize = true;
            this.lblDepositMax.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblDepositMax.Location = new System.Drawing.Point(39, 48);
            this.lblDepositMax.Name = "lblDepositMax";
            this.lblDepositMax.Size = new System.Drawing.Size(27, 13);
            this.lblDepositMax.TabIndex = 5;
            this.lblDepositMax.Text = "Max";
            // 
            // txtDepositMin
            // 
            this.txtDepositMin.CustomDecimal = 0;
            this.txtDepositMin.CustomLenght = 20;
            this.txtDepositMin.Location = new System.Drawing.Point(94, 19);
            this.txtDepositMin.Name = "txtDepositMin";
            this.txtDepositMin.NeedDecimal = true;
            this.txtDepositMin.Size = new System.Drawing.Size(110, 20);
            this.txtDepositMin.StringFormat = "";
            this.txtDepositMin.TabIndex = 2;
            this.txtDepositMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblDepositMin
            // 
            this.lblDepositMin.AutoSize = true;
            this.lblDepositMin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblDepositMin.Location = new System.Drawing.Point(39, 22);
            this.lblDepositMin.Name = "lblDepositMin";
            this.lblDepositMin.Size = new System.Drawing.Size(24, 13);
            this.lblDepositMin.TabIndex = 5;
            this.lblDepositMin.Text = "Min";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtLoanMax);
            this.groupBox2.Controls.Add(this.lblLoanMax);
            this.groupBox2.Controls.Add(this.txtLoanMin);
            this.groupBox2.Controls.Add(this.lblLoanMin);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(62, 187);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(226, 83);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Loan";
            // 
            // txtLoanMax
            // 
            this.txtLoanMax.CustomDecimal = 0;
            this.txtLoanMax.CustomLenght = 20;
            this.txtLoanMax.Location = new System.Drawing.Point(94, 45);
            this.txtLoanMax.Name = "txtLoanMax";
            this.txtLoanMax.NeedDecimal = true;
            this.txtLoanMax.Size = new System.Drawing.Size(110, 20);
            this.txtLoanMax.StringFormat = "";
            this.txtLoanMax.TabIndex = 5;
            this.txtLoanMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblLoanMax
            // 
            this.lblLoanMax.AutoSize = true;
            this.lblLoanMax.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblLoanMax.Location = new System.Drawing.Point(39, 48);
            this.lblLoanMax.Name = "lblLoanMax";
            this.lblLoanMax.Size = new System.Drawing.Size(27, 13);
            this.lblLoanMax.TabIndex = 5;
            this.lblLoanMax.Text = "Max";
            // 
            // txtLoanMin
            // 
            this.txtLoanMin.CustomDecimal = 0;
            this.txtLoanMin.CustomLenght = 20;
            this.txtLoanMin.Location = new System.Drawing.Point(94, 19);
            this.txtLoanMin.Name = "txtLoanMin";
            this.txtLoanMin.NeedDecimal = true;
            this.txtLoanMin.Size = new System.Drawing.Size(110, 20);
            this.txtLoanMin.StringFormat = "";
            this.txtLoanMin.TabIndex = 4;
            this.txtLoanMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblLoanMin
            // 
            this.lblLoanMin.AutoSize = true;
            this.lblLoanMin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblLoanMin.Location = new System.Drawing.Point(39, 22);
            this.lblLoanMin.Name = "lblLoanMin";
            this.lblLoanMin.Size = new System.Drawing.Size(24, 13);
            this.lblLoanMin.TabIndex = 5;
            this.lblLoanMin.Text = "Min";
            // 
            // frmMDAddModifySBVMinMax
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(349, 322);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtTenors);
            this.Controls.Add(this.cbbCCY);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblTenors);
            this.Controls.Add(this.lblCCY);
            this.Controls.Add(this.btnSave);
            this.Name = "frmMDAddModifySBVMinMax";
            this.Text = "Create SBV Min/Max";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDAddModifySBVMinMax_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Label lblCCY;
        private System.Windows.Forms.Label lblTenors;
        private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.ComboBox cbbCCY;
        private System.Windows.Forms.TextBox txtTenors;
        private System.Windows.Forms.GroupBox groupBox1;
        private UserCtrl.ctrlMDNumberOnlyTextBox txtDepositMin;
        private System.Windows.Forms.Label lblDepositMin;
        private UserCtrl.ctrlMDNumberOnlyTextBox txtDepositMax;
        private System.Windows.Forms.Label lblDepositMax;
        private System.Windows.Forms.GroupBox groupBox2;
        private UserCtrl.ctrlMDNumberOnlyTextBox txtLoanMax;
        private System.Windows.Forms.Label lblLoanMax;
        private UserCtrl.ctrlMDNumberOnlyTextBox txtLoanMin;
        private System.Windows.Forms.Label lblLoanMin;
    }
}