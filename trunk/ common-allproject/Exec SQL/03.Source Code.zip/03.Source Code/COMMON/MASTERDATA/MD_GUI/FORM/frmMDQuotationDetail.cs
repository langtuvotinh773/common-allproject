﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-04-08 14:29:30 +0700 (Mon, 08 Apr 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to show Quotation - View of Maker
 * for Master Date module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using UserCtrl.DatagridStackHolder.Master;
using Phoenix.Common.MasterData.Bus;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Security.Com;
namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDQuotationDetail : frmMDMaster
    {
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        /// <summary>
        /// Quotation Object
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private clsMDQuotationDTO m_QuotationObj = new clsMDQuotationDTO();
        /// <summary>
        /// Quotation bus - being used to access data
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private clsMDQuoationBus m_MDQuoationBus = new clsMDQuoationBus();
        /// <summary>
        /// User action: modify, approve, suspend...
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int m_UserAction = 0;
        /// <summary>
        /// Quotation ID
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int m_QuotationID;
        /// <summary>
        /// Quotation's status
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int m_Status = 0;
        /// <summary>
        /// Quotation's remark
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private string m_Remark = "";
        /// <summary>
        /// Quotation's notehead
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private string m_NoteHead = "";
        /// <summary>
        /// Quotation's note threshold
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private string m_NoteThreshold = "";
        /// <summary>
        /// Quotation' note mid
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private string m_NoteMid = "";
        /// <summary>
        /// Quotation's note end
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private string m_NoteEnd = "";
        /// <summary>
        /// Form's text of quotation detail for modification
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string DAILY_QUOTATION_DETAILS_FOR_MODIFICATION = "Daily Quotation details (for modification)";
        /// <summary>
        /// Form's text of quotation detail for return
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string DAILY_QUOTATION_DETAILS_FOR_RETURN = "Daily Quotation details (for return)";
        /// <summary>
        /// Form's text of quotation detail for revise
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string DAILY_QUOTATION_DETAILS_FOR_REVISE = "Daily Quotation details (for revise)";
        /// <summary>
        /// Form's text of quotation detail for approve
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string DAILY_QUOTATION_DETAILS_FOR_APPROVE = "Daily Quotation details (for approve)";
        /// <summary>
        /// Close form button's location
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        Point m_LocationGroupBoxAction = new Point(734, 569);
        /// <summary>
        /// E.ExchangeCCYPair,
        /// TTM,
        /// TTB,
        /// TTS,
        /// CSB,
        /// CSS,
        /// TTBRate,
        /// TTSRate
        /// </summary>
        /// <param name="iQuotationID"></param>
        DataTable m_TDBQuotationDetailUSD = new DataTable();
        /// <summary>
        /// Fill data for gridview having against is VND
        /// </summary>
        /// <param name="iQuotationID"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        DataTable m_TDBQuotationDetailVND = new DataTable();
        /// <summary>
        /// Fill data for quotation EC Rate gridview
        /// BaseCCY,
        /// QuoteCCY,
        /// CustRateBuy,
        /// AGroupECBuy,
        /// BGroupECBuy,
        /// CustRateSell,
        /// AGroupECSell,
        /// BGroupECSell		
        /// </summary>
        /// <param name="iQuotationID"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        DataTable m_TDBQuotationECRate = new DataTable();
        /// <summary>
        /// Finish updating
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int m_UpdateFinish = 0;
        /// <summary>
        /// Is already confirmed to save or not
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private bool m_ConfirmSave = false;
        private bool m_ForceClose = false;
        private bool m_CallPreview = false;

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        //public frmMDQuotationDetail()
        //{
        //    InitializeComponent();

        //    // Check authorization
        //    //m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
        //    //m_Security.CheckAuthorizationOnScreen(this);

        //    SetFormStyleCommon();
        //    DrawGridQuotationECRate();
        //    GetQuotationInfo();
        //    if (m_QuotationObj.QuotationID >= 0)
        //    {
        //        FillDataGridQuatationUSD();
        //        FillDataGridQuatationVND();
        //        FillDataForGridQuotationECRate();
        //    }
        //    dtgQuotationUSD.SelectionMode = DataGridViewSelectionMode.CellSelect;
        //    dtgQuotationVND.SelectionMode = DataGridViewSelectionMode.CellSelect;
        //    groupBox1.Location = m_LocationGroupBoxAction; 
        //}

        /// <summary>
        /// Form scroll even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void frmMDQuotationDetail_Scroll(object sender, ScrollEventArgs e)
        {
            panelButtonControl.Location = m_LocationGroupBoxAction;
        }
        //2013.05.31 UDP vlhcnhung S Add Scroll bar 
        /// <summary>
        /// Panel scroll even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void panelDetail_Scroll(object sender, ScrollEventArgs e)
        {
            panelButtonControl.Location = m_LocationGroupBoxAction;
        }
        //2013.05.31 UDP vlhcnhung E Add Scroll bar 
        /// <summary>
        /// Mouse wheel even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void Form1_MouseWheel(object sender, MouseEventArgs e)
        {
            panelButtonControl.BringToFront();
            panelButtonControl.Location = m_LocationGroupBoxAction;
        }
       
        /// <summary>
        /// On focus even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void OnFocus(object sender, EventArgs e)
        {
            panelButtonControl.Location = m_LocationGroupBoxAction;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="iUserAction">User action</param>
        /// <param name="iQuotationID">Quotation ID</param>
        /// <param name="iStatus">Quotation status</param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public frmMDQuotationDetail(int iUserAction, int iQuotationID, int iStatus)
        {
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                SetFormStyleCommon();
                DrawGridQuotationECRate();
                m_QuotationID = iQuotationID;
                m_UserAction = iUserAction;
                m_Status = iStatus;                
                ChangeTypeOfControl();                
                switch (iUserAction)
                {
                    case (int)CommonValue.QuotationAction.Update_free_text:
                        this.Text = DAILY_QUOTATION_DETAILS_FOR_MODIFICATION;
                        break;
                    case (int)CommonValue.QuotationAction.Return_Daily_Quotation:
                        this.Text = DAILY_QUOTATION_DETAILS_FOR_RETURN;
                        break;
                    case (int)CommonValue.QuotationAction.Revise_Daily_Quotation:
                        this.Text = DAILY_QUOTATION_DETAILS_FOR_REVISE;
                        break;
                    case (int)CommonValue.QuotationAction.Approve_Daily_Quotation:
                        this.Text = DAILY_QUOTATION_DETAILS_FOR_APPROVE;
                        break;
                }

                panelButtonControl.Location = m_LocationGroupBoxAction;// new Point(m_LocationGroupBoxAction.X, m_LocationGroupBoxAction.Y);
                panelButtonControl.BringToFront();
                //2013.05.31 UDP vlhcnhung S Add Scroll bar 
                this.panelButtonControl.MouseWheel += new MouseEventHandler(Form1_MouseWheel);
                //2013.05.31 UDP vlhcnhung E Add Scroll bar 
                txtNoteHead.GotFocus += OnFocus;
                txtNoteMid.GotFocus += OnFocus;
                txtNoteThreshold.GotFocus += OnFocus;
                txtNoteEnd.GotFocus += OnFocus;
                txtRemark.GotFocus += OnFocus;
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Form shown even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void frmMDQuotationDetail_Shown(object sender, EventArgs e)
        {
            try
            {
                GetQuotationInfo();
                if (m_QuotationObj.QuotationID >= 0)
                {
                    FillDataGridQuatationUSD();
                    FillDataGridQuatationVND();
                    FillDataForGridQuotationECRate();
                }
                dtgQuotationECRateList.ClearSelection();
                dtgQuotationUSD.ClearSelection();
                dtgQuotationVND.ClearSelection();
                dtgQuotationECRateList.Enabled = false;
                dtgQuotationUSD.Enabled = false;
                dtgQuotationVND.Enabled = false;
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Form close even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void frmMDQuotationDetail_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (m_UpdateFinish > 0)
                DialogResult = DialogResult.OK;
            else
                DialogResult = DialogResult.Cancel;
        }

        /// <summary>
        /// Form closing even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void frmMDQuotationDetail_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (!m_ForceClose)
                {
                    ///-	If user clicks on [Close] button, system will process:
                    ///	If no data was changed on screen, system will close this screen.
                    ///	If data was changed on screen, system will display a confirm message box: “Do you want to save changes of data?”
                    if (IsChangedData())
                    {
                        DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                        ///	If user clicks on [Yes] button, system will process saving current data and close this screen.
                        if (result == DialogResult.Yes)
                        {
                            m_ConfirmSave = true;
                            Save();
                        }
                        else
                            m_ConfirmSave = false;
                        if (result == DialogResult.Cancel)
                        {
                            e.Cancel = true;
                            if (IsModified())
                                m_ConfirmSave = false;
                        }
                    }
                    ///	If user clicks on [No] button, system will discard updated data and close this screen.
                    ///
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            if (m_CallPreview)
            {
                e.Cancel = true;
                m_CallPreview = false;
            }
        }

        /// <summary>
        /// Close this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Save quotation even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Save();
                if (DialogResult == DialogResult.OK)
                    this.Close();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }        

        /// <summary>
        /// Preview quotaion even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnPrintPreview_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_UserAction == (int)CommonValue.QuotationAction.Return_Daily_Quotation || m_UserAction == (int)CommonValue.QuotationAction.Approve_Daily_Quotation)
                {
                    if (txtRemark.Text.Trim() != m_QuotationObj.Remark)
                    {
                        DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                        if (result == DialogResult.Yes)
                        {
                            m_ConfirmSave = true;
                            Save();
                        }
                        else if (result == DialogResult.No)
                        {
                            m_ConfirmSave = false;
                        }
                    }
                    DialogResult = DialogResult.None;
                }
                //vlhcnhung
                else if (m_UserAction == (int)CommonValue.QuotationAction.Update_free_text)
                {
                    if (IsChangedData())
                    {
                        DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, clsMDMessage.YOUR_CHANGES_HAVE_NOT_SAVED_DO_YOU_WANT_TO_SAVE);
                        if (result == DialogResult.Yes)
                        {
                            m_ConfirmSave = true;
                            Save();
                        }
                        else { m_ConfirmSave = false; }
                    }
                }
                
                if (!IsChangedData() || (IsChangedData() && DialogResult != DialogResult.None) || (IsChangedData() && m_ConfirmSave == false))
                {
                    frmMDPreviewQuoationDetail frm = new frmMDPreviewQuoationDetail(
                        m_TDBQuotationDetailUSD,
                        m_TDBQuotationDetailVND,
                        m_TDBQuotationECRate, m_QuotationObj);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.ShowDialog();
                    m_CallPreview = true;
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        private void panelDetail_Click(object sender, EventArgs e)
        {
            this.panelButtonControl.Focus();
        }

        #region Member Methods
        /// <summary>
        /// Get quotation info:
        /// QuotationID
        /// NoteHead,
        /// ImportTime,
        /// Seq,
        /// CentralBankCoreRate,
        /// TC,
        /// NoteThreshold,
        /// NoteMid,
        /// NoteEnd,
        /// [Status],
        /// Remark			  
        /// </summary>		 
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void GetQuotationInfo()
        {
            m_QuotationObj = m_MDQuoationBus.GetQuotationDetail(m_QuotationID);

            if (m_QuotationObj == null)
            {
                Console.WriteLine("null");
                return;
            }
            m_NoteHead = txtNoteHead.Text = m_QuotationObj.NoteHead;
            lblDate.Text = m_QuotationObj.ImportTime.ToString(FORMAT_DDMMMYYYY);
            lblTIme.Text = m_QuotationObj.EffectiveTime;
            lblSeq.Text = m_QuotationObj.Seq.ToString();
            txtCentralBankCoreRate.Text = m_QuotationObj.CentralBankCoreRate;
            txtTC.Text = m_QuotationObj.TC;
            m_NoteThreshold = txtNoteThreshold.Text = m_QuotationObj.NoteThreshold;
            m_NoteMid = txtNoteMid.Text = m_QuotationObj.NoteMid;
            m_NoteEnd = txtNoteEnd.Text = m_QuotationObj.NoteEnd;
            txtStatus.Text = GetStatusText(m_QuotationObj.Status);
            m_Remark = txtRemark.Text = m_QuotationObj.Remark;
            txtCeilingRate.Text = FormatNumber(m_QuotationObj.CeilingRate.ToString(), DECIMAL_FORMAT);
            txtFloorRate.Text = FormatNumber(m_QuotationObj.FloorRate.ToString(), DECIMAL_FORMAT);
            ckbInActive.Checked = !m_QuotationObj.IsActive;
            //2013.05.16 UDP vlhcnhung S Show Marker (UserName) next to InActive Checkbox
            clsMDUserDTO maker = clsMDUserBUS.Instance().GetUser(m_QuotationObj.CreatedBy);
            if(maker!=null)
            {
                txtMaker.Text = maker.UserName;
            }
            //2013.05.16 UDP vlhcnhung E Show Marker (UserName) next to InActive Checkbox
        }

        /// <summary>
        /// Set status for textbox - readonly or not
        /// </summary> 
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void ChangeTypeOfControl()
        {
            switch (m_UserAction)
            {
                case (int)CommonValue.QuotationAction.Update_free_text:
                    txtRemark.ReadOnly = true;
                    break;
                case (int)CommonValue.QuotationAction.Return_Daily_Quotation:
                case (int)CommonValue.QuotationAction.Revise_Daily_Quotation:
                    txtNoteHead.ReadOnly = true;
                    txtNoteThreshold.ReadOnly = true;
                    txtNoteMid.ReadOnly = true;
                    txtNoteEnd.ReadOnly = true;
                    break;
                case (int)CommonValue.QuotationAction.Approve_Daily_Quotation:
                    txtNoteHead.ReadOnly = true;
                    txtNoteThreshold.ReadOnly = true;
                    txtNoteMid.ReadOnly = true;
                    txtNoteEnd.ReadOnly = true;
                    txtRemark.ReadOnly = true;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Get and fill data for USD quotation table
        /// </summary> 
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void FillDataGridQuatationUSD()
        {
            DataTable tdbQuotationDetail = m_MDQuoationBus.GetQuotationDetailUSD(m_QuotationObj.QuotationID);
            m_TDBQuotationDetailUSD = tdbQuotationDetail;
            DataTable tdbPreviousQuotationDetail = m_MDQuoationBus.GetPreviousQuotationDetailUSD(m_QuotationObj.QuotationID);
            int iRowPre = tdbPreviousQuotationDetail.Rows.Count;
            int iColCount = tdbQuotationDetail.Columns.Count;
            dtgQuotationUSD.Rows.Clear();
            clsMDQuotationDTO preQuotation = clsMDQuoationBus.Instance().GetPreviousQuotationViewDetail(m_QuotationObj.QuotationID);
            for (int i = 0; i < tdbQuotationDetail.Rows.Count; i++)
            {
                DataRow rowQuotation = tdbQuotationDetail.Rows[i];
                string strFormatNumber = rowQuotation["FormatNumber"].ToString();
                dtgQuotationUSD.Rows.Add(
                        rowQuotation["ExchangeCCYPair"],
                        FormatNumber(rowQuotation["TTM"], strFormatNumber),
                        FormatNumber(rowQuotation["TTB"], strFormatNumber),
                        FormatNumber(rowQuotation["TTS"], strFormatNumber),
                        FormatNumber(rowQuotation["CSB"], strFormatNumber),
                        FormatNumber(rowQuotation["CSS"], strFormatNumber),
                        FormatNumber(rowQuotation["TTBRate"], strFormatNumber),
                        FormatNumber(rowQuotation["TTSRate"], strFormatNumber));
                if (m_QuotationObj.Status == (int)CommonValue.QuotationStatus.New ||
                    m_QuotationObj.Status == (int)CommonValue.QuotationStatus.WaitForApprove)
                {
                    if (preQuotation != null)
                    {
                        if (preQuotation.Status == (int)CommonValue.QuotationStatus.Returned ||
                            preQuotation.Status == (int)CommonValue.QuotationStatus.Obsolete)
                        {
                            bool isExit = false;
                            for (int j = 0; j < iRowPre; j++)
                            {
                                if (tdbQuotationDetail.Rows[i]["ExchangeCCYPair"].ToString() == tdbPreviousQuotationDetail.Rows[j]["ExchangeCCYPair"].ToString())
                                {
                                    isExit = true;
                                }
                                else
                                {
                                    isExit = false;
                                }
                                //if CCYPair is existed in previous quotation
                                //highlight difference
                                if (isExit)
                                {
                                    for (int k = 1; k < iColCount - 1; k++)
                                    {
                                        if (tdbQuotationDetail.Rows[i][k].ToString() != tdbPreviousQuotationDetail.Rows[j][k].ToString())
                                        {
                                            dtgQuotationUSD.Rows[i].Cells[k].Style.BackColor = clsMDConstant.BG_DATAGRID_DIFF_QUOTATION;
                                        }
                                    }
                                    break;
                                }
                            }
                            //if CCYPair is not existed in previous quotation
                            //highlight full row
                            if (!isExit)
                            {
                                for (int k = 1; k < iColCount - 1; k++)
                                {
                                    dtgQuotationUSD.Rows[i].Cells[k].Style.BackColor = clsMDConstant.BG_DATAGRID_DIFF_QUOTATION;
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get and fill data for VND quotation table
        /// </summary> 
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void FillDataGridQuatationVND()
        {
            DataTable tdbQuotationDetail = m_MDQuoationBus.GetQuotationDetailVND(m_QuotationObj.QuotationID);
            DataTable tdbPreviousQuotationDetail = m_MDQuoationBus.GetPreviousQuotationDetailVND(m_QuotationObj.QuotationID);
            m_TDBQuotationDetailVND = tdbQuotationDetail;
            int iRowPre = tdbPreviousQuotationDetail.Rows.Count;
            int iColCount = tdbQuotationDetail.Columns.Count;
            dtgQuotationVND.Rows.Clear();
            clsMDQuotationDTO preQuotation = clsMDQuoationBus.Instance().GetPreviousQuotationViewDetail(m_QuotationObj.QuotationID);
            for (int i = 0; i < tdbQuotationDetail.Rows.Count; i++)
            {
                DataRow rowQuotation = tdbQuotationDetail.Rows[i];
                string strFormatNumber = rowQuotation["FormatNumber"].ToString();
                dtgQuotationVND.Rows.Add(
                rowQuotation["ExchangeCCYPair"],
                FormatNumber(rowQuotation["TTM"], strFormatNumber),
                FormatNumber(rowQuotation["TTB"], strFormatNumber),
                FormatNumber(rowQuotation["TTS"], strFormatNumber),
                FormatNumber(rowQuotation["CSB"], strFormatNumber),
                FormatNumber(rowQuotation["CSS"], strFormatNumber));

                if (m_QuotationObj.Status == (int)CommonValue.QuotationStatus.New ||
                    m_QuotationObj.Status == (int)CommonValue.QuotationStatus.WaitForApprove)
                {
                    if (preQuotation != null)
                    {
                        if (preQuotation.Status == (int)CommonValue.QuotationStatus.Returned ||
                            preQuotation.Status == (int)CommonValue.QuotationStatus.Obsolete)
                        {
                            bool isExit = false;
                            for (int j = 0; j < iRowPre; j++)
                            {
                                if (tdbQuotationDetail.Rows[i]["ExchangeCCYPair"].ToString() == tdbPreviousQuotationDetail.Rows[j]["ExchangeCCYPair"].ToString())
                                {
                                    isExit = true;
                                }
                                else
                                {
                                    isExit = false;
                                }
                                //if CCYPair is existed in previous quotation
                                //highlight difference
                                if (isExit)
                                {
                                    for (int k = 1; k < iColCount - 1; k++)
                                    {
                                        if (tdbQuotationDetail.Rows[i][k].ToString() != tdbPreviousQuotationDetail.Rows[j][k].ToString())
                                        {
                                            dtgQuotationVND.Rows[i].Cells[k].Style.BackColor = clsMDConstant.BG_DATAGRID_DIFF_QUOTATION;
                                        }
                                    }
                                    break;
                                }
                            }
                            //if CCYPair is existed in previous quotation
                            //highlight full row
                            if (!isExit)
                            {
                                for (int k = 1; k < iColCount - 1; k++)
                                {
                                    dtgQuotationVND.Rows[i].Cells[k].Style.BackColor = clsMDConstant.BG_DATAGRID_DIFF_QUOTATION;
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get and fill data for EC/Rate quotation table
        /// </summary> 
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void FillDataForGridQuotationECRate()
        {
            DataTable tdbQuotationECRate = m_MDQuoationBus.GetQuotationECRate(m_QuotationObj.QuotationID);
            DataTable tdbPreviousQuotationECRate = m_MDQuoationBus.GetPreviousQuotationECRate(m_QuotationObj.QuotationID);
            m_TDBQuotationECRate = tdbQuotationECRate;
            dtgQuotationECRateList.Rows.Clear();
            int iRow = tdbQuotationECRate.Rows.Count;
            int iRowPre = tdbPreviousQuotationECRate.Rows.Count;
            int iColCount = tdbQuotationECRate.Columns.Count;
            clsMDQuotationDTO preQuotation = clsMDQuoationBus.Instance().GetPreviousQuotationViewDetail(m_QuotationObj.QuotationID);
            for (int i = 0; i < iRow; i++)
            {
                DataRow rowQuotation = tdbQuotationECRate.Rows[i];
                dtgQuotationECRateList.Rows.Add(
                    rowQuotation["ExchangeCCYPair"],
                    rowQuotation["CustRateBuy"],
                    rowQuotation["AGroupECBuy"],
                    rowQuotation["BGroupECBuy"],
                    rowQuotation["CustRateSell"],
                    rowQuotation["AGroupECSell"],
                    rowQuotation["BGroupECSell"]);
                if (m_QuotationObj.Status == (int)CommonValue.QuotationStatus.New ||
                    m_QuotationObj.Status == (int)CommonValue.QuotationStatus.WaitForApprove)
                {
                    if (preQuotation != null)
                    {
                        if (preQuotation.Status == (int)CommonValue.QuotationStatus.Returned ||
                            preQuotation.Status == (int)CommonValue.QuotationStatus.Obsolete)
                        {
                            bool isExit = false;
                            for (int j = 0; j < iRowPre; j++)
                            {
                                if (tdbQuotationECRate.Rows[i]["ExchangeCCYPair"].ToString() == tdbPreviousQuotationECRate.Rows[j]["ExchangeCCYPair"].ToString())
                                {
                                    isExit = true;
                                }
                                else
                                {
                                    isExit = false;
                                }
                                //if CCYPair is existed in previous quotation
                                //highlight difference
                                if (isExit)
                                {
                                    for (int k = 2; k < iColCount; k++)
                                    {
                                        if (tdbQuotationECRate.Rows[i][k].ToString() != tdbPreviousQuotationECRate.Rows[j][k - 1].ToString())
                                        {
                                            dtgQuotationECRateList.Rows[i].Cells[k - 1].Style.BackColor = clsMDConstant.BG_DATAGRID_DIFF_QUOTATION;
                                        }
                                    }
                                    break;
                                }
                            }
                            //if CCYPair is existed in previous quotation
                            //highlight full row
                            if (!isExit)
                            {
                                for (int k = 2; k < iColCount; k++)
                                {
                                    dtgQuotationECRateList.Rows[i].Cells[k - 1].Style.BackColor = clsMDConstant.BG_DATAGRID_DIFF_QUOTATION;
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Draw quotation EC Rate datagrid
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void DrawGridQuotationECRate()
        {
            DataGridViewTextBoxColumn colCrossFX = new DataGridViewTextBoxColumn();
            colCrossFX.HeaderText = clsMDConstant.CROSS_FX;
            dtgQuotationECRateList.Columns.Add(colCrossFX);
            dtgQuotationECRateList.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            DataGridViewTextBoxColumn colBankBuyCusRate = new DataGridViewTextBoxColumn();
            colBankBuyCusRate.HeaderText = clsMDConstant.BANK_BUYS_FC_vs_VND +
                clsMDConstant._ + clsMDConstant.CUST_RATE;
            dtgQuotationECRateList.Columns.Add(colBankBuyCusRate);

            DataGridViewTextBoxColumn colBankBuyAgroup = new DataGridViewTextBoxColumn();
            colBankBuyAgroup.HeaderText = clsMDConstant.BANK_BUYS_FC_vs_VND
                + clsMDConstant._
                + clsMDConstant.A_GROUP_SCREEN
                + clsMDConstant._
                + clsMDConstant.EC;
            dtgQuotationECRateList.Columns.Add(colBankBuyAgroup);

            DataGridViewTextBoxColumn colBankBuyBgroup = new DataGridViewTextBoxColumn();
            colBankBuyBgroup.HeaderText = clsMDConstant.BANK_BUYS_FC_vs_VND
                + clsMDConstant._
                + clsMDConstant.B_GROUP_SCREEN
                + clsMDConstant._
                + clsMDConstant.EC;
            dtgQuotationECRateList.Columns.Add(colBankBuyBgroup);

            DataGridViewTextBoxColumn colBankSellCusRate = new DataGridViewTextBoxColumn();
            colBankSellCusRate.HeaderText = clsMDConstant.BANK_SELLS_FC_vs_VND
                + clsMDConstant._
                + clsMDConstant.CUST_RATE;
            dtgQuotationECRateList.Columns.Add(colBankSellCusRate);

            DataGridViewTextBoxColumn colBankSellAgroup = new DataGridViewTextBoxColumn();
            colBankSellAgroup.HeaderText = clsMDConstant.BANK_SELLS_FC_vs_VND
                + clsMDConstant._
                + clsMDConstant.A_GROUP_SCREEN
                + clsMDConstant._
                + clsMDConstant.EC;
            dtgQuotationECRateList.Columns.Add(colBankSellAgroup);

            DataGridViewTextBoxColumn colBankSellBgroup = new DataGridViewTextBoxColumn();
            colBankSellBgroup.HeaderText = clsMDConstant.BANK_SELLS_FC_vs_VND
                + clsMDConstant._
                + clsMDConstant.B_GROUP_SCREEN
                + clsMDConstant._
                + clsMDConstant.EC;
            dtgQuotationECRateList.Columns.Add(colBankSellBgroup);
            for (int i = 1; i < dtgQuotationECRateList.Columns.Count; i++)
                dtgQuotationECRateList.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            StackedHeaderDecorator objREnderer = new StackedHeaderDecorator(dtgQuotationECRateList);
        }

        /// <summary>
        /// Write log for creating quotation
        /// </summary>
        /// <param name="newQuotation">New Quotation information for writing log</param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void WriteLog(clsMDQuotationDTO newQuotation)
        {
            //History Header
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = newQuotation.QuotationID.ToString();
            clsMDLogInformation logInfo = new clsMDLogInformation();

            logBase.Action = (int)CommonValue.ActionType.New;

            if (m_QuotationObj.Version != newQuotation.Version)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "Version";
                logInfo.OldValue = m_QuotationObj.Version.ToString();
                logInfo.NewValue = newQuotation.Version.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.Status != newQuotation.Status)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "Status";
                logInfo.OldValue = m_QuotationObj.Status.ToString();
                logInfo.NewValue = newQuotation.Status.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.ImportTime != newQuotation.ImportTime)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "ImportTime";
                logInfo.OldValue = m_QuotationObj.ImportTime.ToString();
                logInfo.NewValue = newQuotation.ImportTime.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.EffectiveTime != newQuotation.EffectiveTime)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "EffectiveTime";
                logInfo.OldValue = m_QuotationObj.EffectiveTime;
                logInfo.NewValue = newQuotation.EffectiveTime;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.Seq != newQuotation.Seq)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "Seq";
                logInfo.OldValue = m_QuotationObj.Seq.ToString();
                logInfo.NewValue = newQuotation.Seq.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.CentralBankCoreRate != newQuotation.CentralBankCoreRate)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "CentralBankCoreRate";
                logInfo.OldValue = m_QuotationObj.CentralBankCoreRate;
                logInfo.NewValue = newQuotation.CentralBankCoreRate;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.TC != newQuotation.TC)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "TC";
                logInfo.OldValue = m_QuotationObj.TC;
                logInfo.NewValue = newQuotation.TC;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.NoteHead != newQuotation.NoteHead)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "NoteHead";
                logInfo.OldValue = m_QuotationObj.NoteHead;
                logInfo.NewValue = newQuotation.NoteHead;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.NoteThreshold != newQuotation.NoteThreshold)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "NoteThreshold";
                logInfo.OldValue = m_QuotationObj.NoteThreshold;
                logInfo.NewValue = newQuotation.NoteThreshold;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.NoteMid != newQuotation.NoteMid)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "NoteMid";
                logInfo.OldValue = m_QuotationObj.NoteMid;
                logInfo.NewValue = newQuotation.NoteMid;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.NoteEnd != newQuotation.NoteEnd)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "NoteEnd";
                logInfo.OldValue = m_QuotationObj.NoteEnd;
                logInfo.NewValue = newQuotation.NoteEnd;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.Remark != newQuotation.Remark)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "Remark";
                logInfo.OldValue = m_QuotationObj.Remark;
                logInfo.NewValue = newQuotation.Remark;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.Approver != newQuotation.Approver)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "Approver";
                logInfo.OldValue = m_QuotationObj.Approver;
                logInfo.NewValue = newQuotation.Approver;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.IsActive != newQuotation.IsActive)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "IsActive";
                logInfo.OldValue = m_QuotationObj.IsActive.ToString();
                logInfo.NewValue = newQuotation.IsActive.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.CreatedBy != newQuotation.CreatedBy)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "CreatedBy";
                logInfo.OldValue = m_QuotationObj.CreatedBy.ToString();
                logInfo.NewValue = newQuotation.CreatedBy.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.UpdateDate != newQuotation.UpdateDate)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "UpdateDate";
                logInfo.OldValue = m_QuotationObj.UpdateDate.ToString();
                logInfo.NewValue = newQuotation.UpdateDate.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.FileDirectory != newQuotation.FileDirectory)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "FileDirectory";
                logInfo.OldValue = m_QuotationObj.FileDirectory;
                logInfo.NewValue = newQuotation.FileDirectory;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.FloorRate != newQuotation.FloorRate)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "FloorRate";
                logInfo.OldValue = m_QuotationObj.FloorRate;
                logInfo.NewValue = newQuotation.FloorRate;
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_QuotationObj.CeilingRate != newQuotation.CeilingRate)
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "CeilingRate";
                logInfo.OldValue = m_QuotationObj.CeilingRate;
                logInfo.NewValue = newQuotation.CeilingRate;
                logBase.LstLogInformation.Add(logInfo);
            }

            logBase.WirteLog(m_MDQuoationBus.DAL);
            if (m_MDQuoationBus.DAL.m_transaction != null)
                m_MDQuoationBus.Commit();
        }

        /// <summary>
        /// Return quotation
        /// </summary>
        /// <returns>Number of rows effected when returning quotation</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int ReturnQuotation()
        {
            int iRowsUpdate = 0;
            try
            {
                iRowsUpdate = m_MDQuoationBus.ReturnQuotation(m_QuotationObj.QuotationID, txtRemark.Text.Trim());
                if (iRowsUpdate > 0)
                    WriteLogUpdateFreeText((int)CommonValue.QuotationStatus.Returned);
            }
            catch (Exception ex)
            {
                m_MDQuoationBus.RollBack();

                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                return -1;
            }

            GetQuotationInfo();
            return iRowsUpdate;
        }

        /// <summary>
        /// Write log when update free text
        /// </summary>
        /// <param name="iNewSatus">Status to write</param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void WriteLogUpdateFreeText(int iNewSatus)
        {
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = m_QuotationID.ToString();
            logBase.Action = (int)CommonValue.ActionType.Update;

            clsMDLogInformation logInfo = new clsMDLogInformation();
            if (iNewSatus != -1)
            {
                logInfo.FieldName = "Status";
                logInfo.OldValue = m_Status.ToString();
                logInfo.NewValue = iNewSatus.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_NoteHead != txtNoteHead.Text.Trim())
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "NoteHead";
                logInfo.OldValue = m_NoteHead.ToString();
                logInfo.NewValue = txtNoteHead.Text.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }
            if (m_NoteThreshold != txtNoteThreshold.Text.Trim())
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "NoteThreshold";
                logInfo.OldValue = m_NoteThreshold.ToString();
                logInfo.NewValue = txtNoteThreshold.Text.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_NoteMid != txtNoteMid.Text.Trim())
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "NoteMid";
                logInfo.OldValue = m_NoteMid.ToString();
                logInfo.NewValue = txtNoteMid.Text.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_NoteEnd != txtNoteEnd.Text.Trim())
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "NoteEnd";
                logInfo.OldValue = m_NoteEnd.ToString();
                logInfo.NewValue = txtNoteEnd.Text.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            if (m_Remark != txtRemark.Text.Trim())
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = "Remark";
                logInfo.OldValue = m_Remark.ToString();
                logInfo.NewValue = txtRemark.Text.ToString();
                logBase.LstLogInformation.Add(logInfo);
            }

            logBase.WirteLog(m_MDQuoationBus.DAL);
            m_MDQuoationBus.Commit();
        }

        /// <summary>
        /// Revise quotation
        /// </summary>
        /// <returns>Number of rows effected when revising quotation</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int ReviseQuotation()
        {
            int iRowsUpdate = 0;
            try
            {
                iRowsUpdate = m_MDQuoationBus.ReviseQuotation(m_QuotationObj.QuotationID, txtRemark.Text.Trim());
                if (iRowsUpdate > 0)
                    WriteLogUpdateFreeText((int)CommonValue.QuotationStatus.Suspended);
            }
            catch (Exception ex)
            {
                m_MDQuoationBus.RollBack();

                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }

            GetQuotationInfo();
            return iRowsUpdate;
        }

        /// <summary>
        /// Approve quotation
        /// </summary>
        /// <returns>Rows effected when approving</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int ApproveQuotation()
        {
            int iRowsUpdate = 0;
            try
            {
                iRowsUpdate = m_MDQuoationBus.ApproveQuotation(m_QuotationObj.QuotationID, m_QuotationObj.Version);
                if (iRowsUpdate > 0)
                    WriteLogUpdateStatus((int)CommonValue.QuotationStatus.Approved);
            }
            catch (Exception ex)
            {
                if (m_MDQuoationBus.DAL.m_transaction != null)
                    m_MDQuoationBus.RollBack();

                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
            return iRowsUpdate;
        }

        /// <summary>
        /// Write log for update quotation action
        /// </summary>
        /// <param name="iNewSatus">Quotaion's status to be updated</param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void WriteLogUpdateStatus(int iNewSatus)
        {
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = m_QuotationObj.QuotationID.ToString();
            logBase.Action = (int)CommonValue.ActionType.Update;

            clsMDLogInformation logInfo = new clsMDLogInformation();
            logInfo.FieldName = "IsActive";
            logInfo.OldValue = m_Status.ToString();
            logInfo.NewValue = iNewSatus.ToString();
            logBase.LstLogInformation.Add(logInfo);
            logBase.WirteLog(m_MDQuoationBus.DAL);

            m_MDQuoationBus.Commit();
        }

        /// <summary>
        /// Update quotation's free text
        /// </summary>
        /// <param name="iStatusToUpdate">Status code to update</param>
        /// <returns>Number of effected rows when updating quotation's free text</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int UpdateFreeText()
        {
            int iRowsUpdate = 0;
            try
            {
                iRowsUpdate = m_MDQuoationBus.UpdateFreeText(
                    m_QuotationObj.QuotationID,
                    txtNoteHead.Text.Trim(),
                    txtNoteThreshold.Text.Trim(),
                    txtNoteMid.Text.Trim(),
                    txtNoteEnd.Text.Trim(),
                    txtRemark.Text.Trim());
                if (iRowsUpdate > 0)
                    WriteLogUpdateFreeText(-1);
                GetQuotationInfo();
            }
            catch (Exception ex)
            {
                if (m_MDQuoationBus.DAL.m_transaction != null)
                    m_MDQuoationBus.RollBack();

                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }            
            return iRowsUpdate;
        }

        /// <summary>
        /// Check max length of free text and remark field in textboxes
        /// </summary>
        /// <returns>True if length smaller thang max length of database, otherwise false</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private bool CheckMaxLength()
        {
            if (txtNoteHead.Text.Length > NOTE_HEAD_MAX_LENGTH)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_THE_LENGTH_OF_ITEM_NAME_SHOULD_BE_LESS_THAN_OR_EQUAL_MAX_LENGTH, NOTE_HEAD, NOTE_HEAD_MAX_LENGTH.ToString()));
                txtNoteHead.Focus();
                return false;
            }

            if (txtNoteThreshold.Text.Length > NOTE_THRESHOLD_MAX_LENGTH)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_THE_LENGTH_OF_ITEM_NAME_SHOULD_BE_LESS_THAN_OR_EQUAL_MAX_LENGTH, NOTE_THRESHOLD, NOTE_THRESHOLD_MAX_LENGTH.ToString()));
                txtNoteThreshold.Focus();
                return false;
            }
            if (txtNoteMid.Text.Length > NOTE_MID_MAX_LENGTH)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_THE_LENGTH_OF_ITEM_NAME_SHOULD_BE_LESS_THAN_OR_EQUAL_MAX_LENGTH, NOTE_MID, NOTE_MID_MAX_LENGTH.ToString()));
                txtNoteMid.Focus();
                return false;
            }
            if (txtNoteEnd.Text.Length > NOTE_END_MAX_LENGTH)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_THE_LENGTH_OF_ITEM_NAME_SHOULD_BE_LESS_THAN_OR_EQUAL_MAX_LENGTH, NOTE_END, NOTE_END_MAX_LENGTH.ToString()));
                txtNoteEnd.Focus();
                return false;
            }
            return true;

        }

        /// <summary>
        /// Save quotation detail
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void Save()
        {
            DialogResult result = new DialogResult();
            switch (m_UserAction)
            {
                #region Return_Daily_Quotation
                case (int)CommonValue.QuotationAction.Return_Daily_Quotation:
                    if (txtRemark.Text.Trim() == "")
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " reason to return on remark field."));
                        DialogResult = DialogResult.None;
                        //return;
                        txtRemark.Focus();
                    }
                    else
                    {
                        ///Click Return: When user picking Waiting for approve DQ and click [Return]
                        ///- System opens [DQ details] screen for user to input remark field.
                        ///- User inputs data into Remark field.
                        ///- User clicks on “Save” button on [DQ details] screen

                        ///- System display a confirm message box “Are you sure to return data?”
                        ///- In case user clicks on “Yes” button.
                        //if (m_QuotationObj.Remark.Trim() != txtRemark.Text.Trim())//vlhcnhung
                        {
                            result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_RETURN_DATA);
                            if (result == DialogResult.Cancel)
                                return;
                            if (result == DialogResult.No)
                            {
                                this.m_ForceClose = true;
                                this.Close();
                                return;
                            }
                            if (result == DialogResult.Yes)
                            ///- System changes the status of the Quotation to “Returned”.
                            ///- System will popup a message to announce “Data was returned successfully”
                            {
                                m_UpdateFinish = ReturnQuotation();
                                if (m_UpdateFinish < 0)
                                {
                                    m_ForceClose = true;
                                    this.Close();
                                }
                                if (m_UpdateFinish > 0)
                                {
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.DATA_WAS_RETURNED_SUCCESSFULLY);
                                    GetQuotationInfo();
                                    DialogResult = DialogResult.OK;
                                }
                                ///- Returned Quotation will displays in “View Quotation of Maker” screen.
                            }
                            ///- Returned Quotation will be hightlighted 
                            ///- In case of user clicks [No] on confirm message box, system will not save data in database and close confirm message and screen [DQ details] as well					
                        }
                    }
                    break;
                #endregion

                #region Revise_Daily_Quotation
                case (int)CommonValue.QuotationAction.Revise_Daily_Quotation:
                    ///Click Revise: When user picking Approved DQ and click [Revise]			
                    ///- System opens [DQ details] screen for user to input remark field.		
                    ///- User inputs data into Remark field.		
                    ///- User clicks on “Save” button on [DQ details] screen		
                    ///- System display a confirm message box “Are you sure to revise data?”	
                    ////vlhcnhung
                    //if (string.IsNullOrEmpty(txtRemark.Text.Trim()))
                    //{
                    //    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " reason to revise on remark field."));
                    //    DialogResult = DialogResult.None;
                    //    return;
                    //}

                    result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_REVISE_DATA);
                    if (result == DialogResult.Cancel)
                        return;
                    if (result == DialogResult.No)
                    {
                        this.m_ForceClose = true;
                        this.Close();
                        return;
                    }
                    ///- In case user clicks on “Yes” button.
                    if (result == DialogResult.Yes)
                    {
                        ///- System changes the status of the Quotation to “Suspended”.		
                        m_UpdateFinish = ReviseQuotation();
                        if (m_UpdateFinish < 0)
                        {
                            m_ForceClose = true;
                            this.Close();
                        }
                        if (m_UpdateFinish > 0)
                        {///- System will popup a message to announce “Data was revised successfully”
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.DATA_WAS_REVISED_SUCCESSFULLY);
                            DialogResult = DialogResult.OK;
                        }
                    }

                    ///- Revised Quotation will be hightlighted	 																									
                    ///- In case of user clicks [No] on confirm message box, system will not save data in database and close confirm message and screen [DQ details] as well																													

                    break;
                #endregion

                #region Update_free_text
                case (int)CommonValue.QuotationAction.Update_free_text:
                    /// * This button is enable only if user select [New] DQ
                    ///  - System open screen [DQ modification] for user to modify data 
                    ///  -	User clicks on “Save” button.
                    ///  -	System display a confirm message box “Are you sure to save data?”
                    if (!IsModified())
                        return;
                    if (!CheckMaxLength())
                        return;
                    if (m_ConfirmSave == false)
                    {
                        result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_SAVE_DATA);
                        if (result == DialogResult.Cancel)
                        {
                            return;
                        }
                        if (result == DialogResult.No)
                        {
                            this.m_ForceClose = true;
                            DialogResult = DialogResult.Cancel;
                            this.Close();
                            return;
                        }
                    }
                    else result = DialogResult.Yes;
                    ///- In case user clicks on “Yes” button.
                    if (result == DialogResult.Yes)
                    {
                        m_UpdateFinish = UpdateFreeText();
                        if (m_UpdateFinish < 0)
                        {
                            m_ForceClose = true;
                            this.Close();
                        }
                        if (m_UpdateFinish > 0)
                        ///  -	System will popup a message to announce “Data was saved successfully”
                        {
                            if (m_ConfirmSave == false)
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.ACTION_INFORMATION_NAME_IS_SUCCESSFUL, MODIFYING, QUOTATION));
                            ///gan m_QuotationObj cho object vua duoc update
                            DialogResult = DialogResult.OK;
                        }
                    }
                    ///-	In case of actor clicks [No] on confirm message box, system will not save data in database and close confirm message.
                    break;
                #endregion

                #region Approve
                case (int)CommonValue.QuotationAction.Approve_Daily_Quotation:
                    ///- System display a confirm message box “Are you sure to approve data?”	
                    ///- User clicks on “Yes” button.		
                    result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_APPROVE_DATA);
                    if (result == DialogResult.Yes)
                    {
                        ///- System changes the status “Wait for approve” to “Approved” and the old approved quotation will be unactive
                        m_UpdateFinish = ApproveQuotation();
                        if (m_UpdateFinish < 0)
                        {
                            m_ForceClose = true;
                            this.Close();
                        }
                        if (m_UpdateFinish > 0)
                        {
                            ///- System will popup a message to announce “Daily Quotation was approved successfully"
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.DAILY_QUOTATION_WAS_APPROVED_SUCCESSFULLY);                        
                            DialogResult = DialogResult.OK;
                        }
                    }
                    else if (result == DialogResult.Cancel)
                    {
                        return;
                    }
                    else if (result == DialogResult.No)
                    {
                        this.m_ForceClose = true;
                        this.Close();
                    }
                    break;
                #endregion
                default:
                    break;
            }
            ///- Operation log will be saved.

        }

        /// <summary>
        /// Check if quotation's information is modified or not
        /// </summary>
        /// <returns>True if quotation's information is modified, otherwise false</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private bool IsModified()
        {
            //vlhchung
            //if (string.IsNullOrEmpty(txtNoteHead.Text.Trim()))
            //{
            //    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Free Text 01"));
            //    txtNoteHead.Focus();
            //    return false;
            //}
            //if (string.IsNullOrEmpty(txtNoteThreshold.Text.Trim()))
            //{
            //    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Free Text 02"));
            //    txtNoteThreshold.Focus();
            //    return false;
            //}
            //if (string.IsNullOrEmpty(txtNoteMid.Text.Trim()))
            //{
            //    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Free Text 03"));
            //    txtNoteMid.Focus();
            //    return false;
            //}
            //if (string.IsNullOrEmpty(txtNoteEnd.Text.Trim()))
            //{
            //    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Free Text 04"));
            //    txtNoteEnd.Focus();
            //    return false;
            //}
            return true;
            //return
            //   m_QuotationObj.NoteHead != txtNoteHead.Text ||
            //   m_QuotationObj.NoteThreshold != txtNoteThreshold.Text ||
            //   m_QuotationObj.NoteMid != txtNoteMid.Text ||
            //   m_QuotationObj.NoteEnd != txtNoteEnd.Text ||	
            //   m_QuotationObj.Remark != txtRemark.Text;

        }

        /// <summary>
        /// Check if quotation's information is changed or not
        /// </summary>
        /// <returns>True if quotation's information is changed, otherwise false</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private bool IsChangedData()
        {
            return
               m_QuotationObj.NoteHead != txtNoteHead.Text ||
               m_QuotationObj.NoteThreshold != txtNoteThreshold.Text ||
               m_QuotationObj.NoteMid != txtNoteMid.Text ||
               m_QuotationObj.NoteEnd != txtNoteEnd.Text ||
               m_QuotationObj.Remark != txtRemark.Text;
        }

        /// <summary>
        /// Update quotation's status
        /// </summary>
        /// <param name="iStatusToUpdate">Status code to update</param>
        /// <returns>Number of effected rows when updating quotation's status</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int UpdateQuotationStatus(int iStatusToUpdate)
        {
            int iRowsUpdate = 0;
            try
            {
                clsMDQuotationDTO newQuotation = new clsMDQuotationDTO();
                newQuotation.QuotationID = m_QuotationObj.QuotationID;
                newQuotation.NoteHead = txtNoteHead.Text;
                newQuotation.NoteThreshold = txtNoteThreshold.Text;
                newQuotation.NoteMid = txtNoteMid.Text;
                newQuotation.NoteEnd = txtNoteEnd.Text;
                newQuotation.Remark = txtRemark.Text;
                newQuotation.Status = iStatusToUpdate;
                //newQuotation.Approver = cbbApprover.SelectedItem.ToString();
                iRowsUpdate = m_MDQuoationBus.UpdateQuotationStatus(newQuotation);
                m_MDQuoationBus.Commit();
                if (iRowsUpdate > 0)
                    WriteLog(newQuotation);
            }
            catch (Exception ex)
            {
                try
                {
                    m_MDQuoationBus.RollBack();
                }
                catch (System.Exception)
                {
                    clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                }

                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }

            GetQuotationInfo();
            return iRowsUpdate;
        }
        #endregion        
    }
}