﻿namespace Phoenix.Common.MasterData.Gui
{
	partial class frmMDCurrencyInquiryQuotationHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.cbbIsActive = new System.Windows.Forms.ComboBox();
            this.lblIsActive = new System.Windows.Forms.Label();
            this.dtpTo = new UserCtrl.BlankCalendar();
            this.dtpFrom = new UserCtrl.BlankCalendar();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtgCCYPair = new System.Windows.Forms.DataGridView();
            this.colCheck = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colCCYPairID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCCYPair = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.VersionColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CCYColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StatusColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreatedDateColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnClose = new System.Windows.Forms.Button();
            this.dtgQuotationHistory = new System.Windows.Forms.DataGridView();
            this.colSeq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coLDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colInActive = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colCCYPairResult = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTTM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTTB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTTS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCSB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCSS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaker = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colApprover = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExport = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCCYPair)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgQuotationHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.chkAll);
            this.groupBox1.Controls.Add(this.cbbIsActive);
            this.groupBox1.Controls.Add(this.lblIsActive);
            this.groupBox1.Controls.Add(this.dtpTo);
            this.groupBox1.Controls.Add(this.dtpFrom);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.dtgCCYPair);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(5, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(861, 138);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Location = new System.Drawing.Point(77, 116);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(70, 17);
            this.chkAll.TabIndex = 9;
            this.chkAll.Text = "Select All";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            // 
            // cbbIsActive
            // 
            this.cbbIsActive.FormattingEnabled = true;
            this.cbbIsActive.Location = new System.Drawing.Point(420, 54);
            this.cbbIsActive.Name = "cbbIsActive";
            this.cbbIsActive.Size = new System.Drawing.Size(142, 21);
            this.cbbIsActive.TabIndex = 7;
            // 
            // lblIsActive
            // 
            this.lblIsActive.AutoSize = true;
            this.lblIsActive.Location = new System.Drawing.Point(347, 58);
            this.lblIsActive.Name = "lblIsActive";
            this.lblIsActive.Size = new System.Drawing.Size(45, 13);
            this.lblIsActive.TabIndex = 6;
            this.lblIsActive.Text = "IsActive";
            // 
            // dtpTo
            // 
            this.dtpTo.CustomFormat = "dd-MMM-yyyy";
            this.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTo.Location = new System.Drawing.Point(420, 33);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(142, 20);
            this.dtpTo.TabIndex = 5;
            this.dtpTo.Value = new System.DateTime(2013, 4, 25, 17, 12, 37, 985);
            // 
            // dtpFrom
            // 
            this.dtpFrom.CustomFormat = "dd-MMM-yyyy";
            this.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFrom.Location = new System.Drawing.Point(420, 12);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(142, 20);
            this.dtpFrom.TabIndex = 3;
            this.dtpFrom.Value = new System.DateTime(2013, 4, 25, 17, 12, 37, 985);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(487, 81);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 8;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtgCCYPair
            // 
            this.dtgCCYPair.AllowUserToAddRows = false;
            this.dtgCCYPair.AllowUserToDeleteRows = false;
            this.dtgCCYPair.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgCCYPair.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dtgCCYPair.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgCCYPair.ColumnHeadersVisible = false;
            this.dtgCCYPair.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCheck,
            this.colCCYPairID,
            this.colCCYPair});
            this.dtgCCYPair.Location = new System.Drawing.Point(76, 12);
            this.dtgCCYPair.Name = "dtgCCYPair";
            this.dtgCCYPair.RowHeadersVisible = false;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(180)))), ((int)(((byte)(191)))));
            this.dtgCCYPair.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgCCYPair.Size = new System.Drawing.Size(168, 100);
            this.dtgCCYPair.TabIndex = 1;
            this.dtgCCYPair.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCCYPair_CellContentClick);
            // 
            // colCheck
            // 
            this.colCheck.DataPropertyName = "CheckedCCYPair";
            this.colCheck.FillWeight = 30.45685F;
            this.colCheck.HeaderText = "Column1";
            this.colCheck.MinimumWidth = 25;
            this.colCheck.Name = "colCheck";
            // 
            // colCCYPairID
            // 
            this.colCCYPairID.DataPropertyName = "ExchangeCCYPairID";
            this.colCCYPairID.HeaderText = "Column1";
            this.colCCYPairID.MinimumWidth = 120;
            this.colCCYPairID.Name = "colCCYPairID";
            this.colCCYPairID.ReadOnly = true;
            this.colCCYPairID.Visible = false;
            // 
            // colCCYPair
            // 
            this.colCCYPair.DataPropertyName = "ExchangeCCYPair";
            this.colCCYPair.FillWeight = 169.5432F;
            this.colCCYPair.HeaderText = "Column1";
            this.colCCYPair.Name = "colCCYPair";
            this.colCCYPair.ReadOnly = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CCY Pair";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(346, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "To Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(346, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "From Date";
            // 
            // VersionColumn
            // 
            this.VersionColumn.Name = "VersionColumn";
            // 
            // CCYColumn
            // 
            this.CCYColumn.Name = "CCYColumn";
            // 
            // StatusColumn
            // 
            this.StatusColumn.Name = "StatusColumn";
            // 
            // CreatedDateColumn
            // 
            this.CreatedDateColumn.Name = "CreatedDateColumn";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Tenors";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 40;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 60;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "FOR THE AMOUNT UP TO VND 20 BIO.VND I/S (%).DEPOSIT";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 60;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 60;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "FOR THE AMOUNT UP TO VND 20 BIO.VND I/S (%)LOAN";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 60;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 60;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "FOR THE AMOUNT UP TO VND 20 BIO.VND I/S (%).DEPOSIT.Spot";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 60;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 60;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "FOR THE AMOUNT UP TO VND 20 BIO.VND I/S (%).LOAN.Sameday";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 60;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 60;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "FOR THE AMOUNT UP TO VND 20 BIO.VND I/S (%).LOAN.Tom";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "FOR THE AMOUNT UP TO VND 20 BIO.VND I/S (%).LOAN.Spot";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(791, 527);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dtgQuotationHistory
            // 
            this.dtgQuotationHistory.AllowUserToAddRows = false;
            this.dtgQuotationHistory.AllowUserToDeleteRows = false;
            this.dtgQuotationHistory.AllowUserToResizeColumns = false;
            this.dtgQuotationHistory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgQuotationHistory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgQuotationHistory.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgQuotationHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgQuotationHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSeq,
            this.coLDate,
            this.colTime,
            this.colInActive,
            this.colCCYPairResult,
            this.colTTM,
            this.colTTB,
            this.colTTS,
            this.colCSB,
            this.colCSS,
            this.colMaker,
            this.colApprover});
            this.dtgQuotationHistory.Location = new System.Drawing.Point(5, 144);
            this.dtgQuotationHistory.Name = "dtgQuotationHistory";
            this.dtgQuotationHistory.ReadOnly = true;
            this.dtgQuotationHistory.RowHeadersVisible = false;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgQuotationHistory.RowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dtgQuotationHistory.Size = new System.Drawing.Size(861, 377);
            this.dtgQuotationHistory.TabIndex = 1;
            // 
            // colSeq
            // 
            this.colSeq.DataPropertyName = "Seq";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colSeq.DefaultCellStyle = dataGridViewCellStyle2;
            this.colSeq.FillWeight = 50F;
            this.colSeq.HeaderText = "Seq";
            this.colSeq.MinimumWidth = 50;
            this.colSeq.Name = "colSeq";
            this.colSeq.ReadOnly = true;
            // 
            // coLDate
            // 
            this.coLDate.DataPropertyName = "ImportTime";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "dd-mmm-yyyy";
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.coLDate.DefaultCellStyle = dataGridViewCellStyle3;
            this.coLDate.FillWeight = 70F;
            this.coLDate.HeaderText = "Date";
            this.coLDate.MinimumWidth = 50;
            this.coLDate.Name = "coLDate";
            this.coLDate.ReadOnly = true;
            // 
            // colTime
            // 
            this.colTime.DataPropertyName = "EffectiveTime";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colTime.DefaultCellStyle = dataGridViewCellStyle4;
            this.colTime.FillWeight = 50F;
            this.colTime.HeaderText = "Time";
            this.colTime.MinimumWidth = 50;
            this.colTime.Name = "colTime";
            this.colTime.ReadOnly = true;
            // 
            // colInActive
            // 
            this.colInActive.DataPropertyName = "InActive";
            this.colInActive.FillWeight = 30F;
            this.colInActive.HeaderText = "InActive";
            this.colInActive.MinimumWidth = 50;
            this.colInActive.Name = "colInActive";
            this.colInActive.ReadOnly = true;
            this.colInActive.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colInActive.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colCCYPairResult
            // 
            this.colCCYPairResult.DataPropertyName = "ExchangeCCYPair";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colCCYPairResult.DefaultCellStyle = dataGridViewCellStyle5;
            this.colCCYPairResult.FillWeight = 70F;
            this.colCCYPairResult.HeaderText = "CCY Pair";
            this.colCCYPairResult.MinimumWidth = 50;
            this.colCCYPairResult.Name = "colCCYPairResult";
            this.colCCYPairResult.ReadOnly = true;
            // 
            // colTTM
            // 
            this.colTTM.DataPropertyName = "TTM";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colTTM.DefaultCellStyle = dataGridViewCellStyle6;
            this.colTTM.FillWeight = 60F;
            this.colTTM.HeaderText = "TTM";
            this.colTTM.MinimumWidth = 50;
            this.colTTM.Name = "colTTM";
            this.colTTM.ReadOnly = true;
            this.colTTM.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colTTB
            // 
            this.colTTB.DataPropertyName = "TTB";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colTTB.DefaultCellStyle = dataGridViewCellStyle7;
            this.colTTB.FillWeight = 60F;
            this.colTTB.HeaderText = "TTB";
            this.colTTB.MinimumWidth = 50;
            this.colTTB.Name = "colTTB";
            this.colTTB.ReadOnly = true;
            this.colTTB.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colTTS
            // 
            this.colTTS.DataPropertyName = "TTS";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colTTS.DefaultCellStyle = dataGridViewCellStyle8;
            this.colTTS.FillWeight = 60F;
            this.colTTS.HeaderText = "TTS";
            this.colTTS.MinimumWidth = 50;
            this.colTTS.Name = "colTTS";
            this.colTTS.ReadOnly = true;
            this.colTTS.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colCSB
            // 
            this.colCSB.DataPropertyName = "CSB";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colCSB.DefaultCellStyle = dataGridViewCellStyle9;
            this.colCSB.FillWeight = 60F;
            this.colCSB.HeaderText = "CSB";
            this.colCSB.MinimumWidth = 50;
            this.colCSB.Name = "colCSB";
            this.colCSB.ReadOnly = true;
            this.colCSB.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCSB.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colCSS
            // 
            this.colCSS.DataPropertyName = "CSS";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colCSS.DefaultCellStyle = dataGridViewCellStyle10;
            this.colCSS.FillWeight = 60F;
            this.colCSS.HeaderText = "CSS";
            this.colCSS.MinimumWidth = 50;
            this.colCSS.Name = "colCSS";
            this.colCSS.ReadOnly = true;
            this.colCSS.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCSS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colMaker
            // 
            this.colMaker.DataPropertyName = "Maker";
            this.colMaker.FillWeight = 70F;
            this.colMaker.HeaderText = "Maker";
            this.colMaker.Name = "colMaker";
            this.colMaker.ReadOnly = true;
            // 
            // colApprover
            // 
            this.colApprover.DataPropertyName = "Approver";
            this.colApprover.FillWeight = 70F;
            this.colApprover.HeaderText = "Approver";
            this.colApprover.Name = "colApprover";
            this.colApprover.ReadOnly = true;
            // 
            // btnExport
            // 
            this.btnExport.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnExport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnExport.Location = new System.Drawing.Point(710, 527);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 23);
            this.btnExport.TabIndex = 2;
            this.btnExport.Text = "&Export";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // frmMDCurrencyInquiryQuotationHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(870, 562);
            this.Controls.Add(this.dtgQuotationHistory);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmMDCurrencyInquiryQuotationHistory";
            this.Text = "Currency Inquiry Quotation History";
            this.Shown += new System.EventHandler(this.frmMDCurrencyInquiryQuotationHistory_Shown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCCYPair)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgQuotationHistory)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn VersionColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CCYColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StatusColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreatedDateColumn;
        private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.DataGridView dtgQuotationHistory;
		private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.DataGridView dtgCCYPair;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colCheck;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCCYPairID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCCYPair;
        private UserCtrl.BlankCalendar dtpTo;
        private UserCtrl.BlankCalendar dtpFrom;
        private System.Windows.Forms.ComboBox cbbIsActive;
        private System.Windows.Forms.Label lblIsActive;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSeq;
        private System.Windows.Forms.DataGridViewTextBoxColumn coLDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTime;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colInActive;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCCYPairResult;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTTM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTTB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTTS;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCSB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCSS;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaker;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApprover;
        private System.Windows.Forms.CheckBox chkAll;
    }
}