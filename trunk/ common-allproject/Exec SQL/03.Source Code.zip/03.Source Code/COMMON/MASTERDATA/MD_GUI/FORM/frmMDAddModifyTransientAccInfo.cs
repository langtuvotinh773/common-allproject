﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-28 (Tue, 28 May 2013) $
 * ========================================================
 * This class is used to create or modify a transient account information
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDAddModifyTransientAccInfo : frmMDMaster
    {
        #region Global Variable
        public clsMDTransientAccInfoDTO m_UpdatingAccInfo;
        public event EventHandler OnSaved;
        public CommonValue.ActionType m_CurrentAction;
        bool m_ForceClose = false;
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        private int MAXLENGTH_GLCODE = 3;
        private int MAXLENGTH_GLSUBCODE = 4;
        #endregion

        #region Contructor
        /// <summary>
        /// Initializes a new instance of the frmMDDepartmentAddModify class.
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public frmMDAddModifyTransientAccInfo(string title)
        {
            InitializeComponent();
            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);

            this.Text = title;
            // Set default value for control
            dtpOpenDate.Value = DateTime.Now;
            dtpCloseDate.Value = DateTime.Now;
            dtpCloseDate.Text = null;
            txtGLCode.MaxLength = MAXLENGTH_GLCODE;
            txtGLSubCode.MaxLength = MAXLENGTH_GLSUBCODE;
            m_UpdatingAccInfo = new clsMDTransientAccInfoDTO();
            m_CurrentAction = CommonValue.ActionType.New; //default

            try
            {
                //Load data to all control
                LoadDataForCombobox();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Form Load
        /// Set default settings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void frmMDAddModifyTransientAccInfo_Load(object sender, EventArgs e)
        {
            //Set common style for form
            SetFormStyleCommon();        
        }

        /// <summary>
        /// Event click button "Save"
        /// if current action is create, system will save a new transient account info into DB
        /// if current action is modify, system will update information transient account info into DB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            //disable all button
            EnableControl(false);
            try
            {
                if (this.m_CurrentAction == CommonValue.ActionType.New)
                {
                    //Save new acc info to db
                    if (SaveCreateAction() > 0)
                    {
                        this.m_ForceClose = true;
                        if (OnSaved != null)
                        {
                            OnSaved(sender, e);
                        }
                        this.Close();
                    }
                }
                else
                {
                    //update information of transient account info to db
                    if (SaveModifyAction() > 0)
                    {
                        this.m_ForceClose = true;
                        if (OnSaved != null)
                        {
                            OnSaved(sender, e);
                        }
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //enable all button
            EnableControl(true);
        }

        /// <summary>
        /// Event when form closing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void frmMDAddModifyTransientAccInfo_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                try
                {
                    if (!m_ForceClose)
                    {
                        //if data was changed on screen, display confirm message to save changed data
                        if (IsDataChanged())
                        {
                            //disable all button
                            EnableControl(false);
                            //display message 'Do you want to save changes of data?'
                            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                            if (res == DialogResult.Yes)
                            {
                                //check valid data
                                if (IsValidData())
                                {
                                    //save data and close form
                                    if (this.m_CurrentAction == CommonValue.ActionType.New)
                                    {
                                        //save new dept
                                        if (SaveANewTransAccInfo() > 0)
                                        {
                                            this.m_ForceClose = true;
                                            if (OnSaved != null)
                                            {
                                                OnSaved(sender, e);
                                            }
                                            this.Close();
                                        }
                                        else//if save unsuccessfull, display error message and not close form
                                        {
                                            e.Cancel = true;
                                        }
                                    }
                                    else
                                    {
                                        //update information of dept
                                        if (SaveAModifiedTransAccInfo() > 0)
                                        {
                                            this.m_ForceClose = true;
                                            if (OnSaved != null)
                                            {
                                                OnSaved(sender, e);
                                            }
                                            this.Close();
                                        }
                                        else//if save unsuccessfull, display error message and not close form
                                        {
                                            e.Cancel = true;
                                        }
                                    }
                                }
                                else
                                {
                                    e.Cancel = true;
                                }
                            }
                            else if (res == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                            //enable all button
                            EnableControl(true);
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.m_ForceClose = true;
                    //show error message
                    clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                    //save log exception
                    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                }
            }
        }

        /// <summary>
        /// Event on click "Cancel"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            // close form
            this.Close();
        }

        /// <summary>
        /// Event KeyPress
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void txtAcountcNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        /// <summary>
        /// Event KeyPress
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void txtGLCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        /// <summary>
        /// Event KeyPress
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void txtGLSubCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

     
        #endregion

        #region Member method
        /// <summary>
        /// Load data to all control
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void LoadDataForCombobox()
        {
            GetDataForComboBoxDepartment();
            GetDataForComboBoxCCY();
        }

        /// <summary>
        /// Get list of departments for cbbDepartment
        /// </summary>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void GetDataForComboBoxDepartment()
        {
            DataTable depts = clsMDTransientAccInfoBUS.Instance().GetDepartmentList();
            if (depts == null) return;

            depts.Rows.InsertAt(depts.NewRow(), 0);
            depts.AcceptChanges();

            cbbDepartment.DataSource = depts;
            cbbDepartment.ValueMember = clsMDConstant.MD_COL_DEPARTMENTID;
            cbbDepartment.DisplayMember = clsMDConstant.MD_COL_DEPARTMENTNAME;
            cbbDepartment.SelectedIndex = 0;
        }

        /// <summary>
        /// Get list of departments for cbbDepartment
        /// </summary>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void GetDataForComboBoxCCY()
        {
            DataTable ccys = clsMDTransientAccInfoBUS.Instance().GetCCYList();
            if (ccys == null) return;

            ccys.Rows.InsertAt(ccys.NewRow(), 0);
            ccys.AcceptChanges();

            cbbCCY.DataSource = ccys;
            cbbCCY.ValueMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.DisplayMember = clsMDConstant.MD_COL_CCYCODE; // hoi lai
            cbbCCY.SelectedIndex = 0;
        }

        /// <summary>
        /// Enable or disable button control
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void EnableControl(bool value)
        {
            btnCancel.Enabled = value;
            btnSave.Enabled = value;
            //check security
            if (value)
            {
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
        }

        /// <summary>
        /// Save for action Create Transient Account Info
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private int SaveCreateAction()
        {
            //check valid data
            if (IsValidData())
            {
                //display confirm message 'Are you sure to save department?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "department"));
                if (res == DialogResult.Yes)
                {
                    return SaveANewTransAccInfo();
                }
                else if (res == DialogResult.No)
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
            }
            return 0;
        }

        /// <summary>
        /// Check validation data
        /// </summary>
        /// <returns>
        /// if any required field is invalid, system will display a warning message and return false
        /// else return true
        /// </returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private bool IsValidData()
        {
            if (string.IsNullOrEmpty(cbbCCY.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "CCY"));
                cbbCCY.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtAcountcNo.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Account No"));
                txtAcountcNo.Focus();
                return false;
            }
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                string strCCY = cbbCCY.Text.Trim();
                int iAccNo = int.Parse(txtAcountcNo.Text.Trim());
                bool result = clsMDTransientAccInfoBUS.Instance().CheckExistTransAccInfo(strCCY, iAccNo);
                if (result)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_ITEM_EXISTED, "Transient Account Information"));
                    cbbCCY.Focus();
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Save a new transient account info
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private int SaveANewTransAccInfo()
        {
            m_UpdatingAccInfo = GetTransAccInfoFromControls();
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //Save new dept and Write data to log
            int iRow = clsMDTransientAccInfoBUS.Instance().InsertTransientAccInfo(m_UpdatingAccInfo, logBase);
            // If Insert OK
            if (iRow > 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Creating", "transient account information"));
            }
            else if (iRow == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Creating", "transient account information"));
            }
            else
            {
                this.m_ForceClose = true;
                this.Close();
            }
            return iRow;
        }

        /// <summary>
        /// Get transient account information to create or modify
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private clsMDTransientAccInfoDTO GetTransAccInfoFromControls()
        {
            clsMDTransientAccInfoDTO dto = new clsMDTransientAccInfoDTO();
            //if (this.m_CurrentAction == CommonValue.ActionType.Update)
            //{
            //    dto.DepartmentID = m_UpdatingAccInfo.DepartmentID;
            //}
            //else
            //{
            //   dto.DelFlag = false;
            //}
            dto.CCY = cbbCCY.Text.Trim();
            dto.AccountNo = int.Parse(txtAcountcNo.Text.Trim());
            dto.GLCode = txtGLCode.Text.Trim();
            dto.GLSubCode = txtGLSubCode.Text.Trim();
            dto.DepartmentId = string.IsNullOrEmpty(cbbDepartment.Text) ? -1 : int.Parse(cbbDepartment.SelectedValue.ToString());
            dto.AccountType = txtAccType.Text.Trim();
            dto.CloseDate = null;
            dto.OpenDate = null;
            if (dtpOpenDate.Text != "")
            {
                dto.OpenDate = new DateTime(dtpOpenDate.Value.Year, dtpOpenDate.Value.Month, dtpOpenDate.Value.Day, 0, 0, 0, 0);
            }
            if (dtpCloseDate.Text != "")
            {
                dto.CloseDate = new DateTime(dtpCloseDate.Value.Year, dtpCloseDate.Value.Month, dtpCloseDate.Value.Day, 0, 0, 0, 0);
            }
            return dto;
        }

        /// <summary>
        /// Create data trasient account info to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private clsMDLogBase CreateDataSaveLog()
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = cbbCCY.Text.Trim() + " " + txtAcountcNo.Text.Trim();//main key is ccy and accountNo
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logBase.Action = (int)CommonValue.ActionType.New;
            }
            else
            {
                logBase.Action = (int)CommonValue.ActionType.Update;
            }

            clsMDLogInformation logInfo = new clsMDLogInformation();

            //CCY
            logInfo.FieldName = clsMDConstant.MD_COL_CCY;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingAccInfo.CCY;
            }
            logInfo.NewValue = cbbCCY.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //Account No
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_ACCOUNT_NO;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingAccInfo.AccountNo.ToString();
            }
            logInfo.NewValue = txtAcountcNo.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //GL Code
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_GLCODE;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingAccInfo.GLCode;
            }
            logInfo.NewValue = txtGLCode.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //GL Sub Code
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_GLCODE;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingAccInfo.GLSubCode;
            }
            logInfo.NewValue = txtGLSubCode.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //Department ID
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_DEPARTMENT_ID;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingAccInfo.DepartmentId.ToString();
            }
            logInfo.NewValue = cbbDepartment.SelectedValue.ToString().Trim();
            logBase.LstLogInformation.Add(logInfo);
            //Account Type
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_ACCOUNT_TYPE;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingAccInfo.AccountType;
            }
            logInfo.NewValue = txtAccType.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //Open Date
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_OPENDATE;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingAccInfo.OpenDate.ToString();
            }
            logInfo.NewValue = dtpOpenDate.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //Open Date
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_OPENDATE;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingAccInfo.OpenDate.ToString();
            }
            logInfo.NewValue = dtpOpenDate.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            return logBase;
        }

        /// <summary>
        /// load data to form
        /// </summary>
        /// <param name="obj">Transient Accounr Info object</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void SetData(clsMDTransientAccInfoDTO obj)
        {
            cbbCCY.Text = obj.CCY;
            txtAcountcNo.Text = obj.AccountNo.ToString();
            cbbDepartment.SelectedValue = obj.DepartmentId;
            txtGLCode.Text = obj.GLCode;
            txtGLSubCode.Text = obj.GLSubCode;
            dtpOpenDate.Text = obj.OpenDate.ToString();
            dtpCloseDate.Text = obj.CloseDate.ToString();
            txtAccType.Text = obj.AccountType;

            //Disable control
            cbbCCY.Enabled = false;
            txtAcountcNo.Enabled = false;
        }

        /// <summary>
        /// Save for action Modify Transient Account Info
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private int SaveModifyAction()
        {
            //check valida data
            if (IsValidData())
            {
                //display confirm message 'Are you sure to save transient account info?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "transient account info"));
                if (res == DialogResult.Yes)
                {
                    return SaveAModifiedTransAccInfo();
                }
                else if (res == DialogResult.No)
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
            }
            return 0;
        }

        /// <summary>
        /// Save a modify transient account info
        /// </summary>
        /// <returns></returns>
        private int SaveAModifiedTransAccInfo()
        {
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //Update dept and Write data to log
            m_UpdatingAccInfo = GetTransAccInfoFromControls();
            int iRow = clsMDTransientAccInfoBUS.Instance().UpdateTransientAccInfo(m_UpdatingAccInfo, logBase);
            // If Update OK
            if (iRow > 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Modifying", "department"));
            }
            else if (iRow == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Modifying", "department"));
            }
            else
            {
                this.Close();
            }
            return iRow;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        private bool IsDataChanged()
        {
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                if (string.IsNullOrEmpty(cbbCCY.Text.Trim())
                    && string.IsNullOrEmpty(txtAcountcNo.Text.Trim())
                    && string.IsNullOrEmpty(txtGLCode.Text.Trim())
                    && string.IsNullOrEmpty(txtGLSubCode.Text.Trim())
                    && string.IsNullOrEmpty(cbbDepartment.Text.Trim())
                    && string.IsNullOrEmpty(txtAccType.Text.Trim())
                    && string.IsNullOrEmpty(dtpOpenDate.Text.Trim())
                    && string.IsNullOrEmpty(dtpCloseDate.Text.Trim()))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                if (this.m_UpdatingAccInfo.GLCode.CompareTo(txtGLCode.Text.Trim()) != 0)
                {
                    return true;
                }
                if (this.m_UpdatingAccInfo.GLSubCode.CompareTo(txtGLSubCode.Text.Trim()) != 0)
                {
                    return true;
                }
                if (this.m_UpdatingAccInfo.DepartmentId != int.Parse(cbbDepartment.SelectedValue.ToString()))
                {
                    return true;
                }
                if (this.m_UpdatingAccInfo.AccountType.CompareTo(txtAccType.Text.Trim()) != 0)
                {
                    return true;
                }

                if (this.m_UpdatingAccInfo.OpenDate == null && !string.IsNullOrEmpty(dtpOpenDate.Text) ||
                    this.m_UpdatingAccInfo.OpenDate != null && string.IsNullOrEmpty(dtpOpenDate.Text))
                {
                        return true;
                }
                else if (this.m_UpdatingAccInfo.OpenDate != null && !string.IsNullOrEmpty(dtpOpenDate.Text) && 
                        DateTime.Compare(DateTime.Parse(this.m_UpdatingAccInfo.OpenDate.ToString()), DateTime.Parse(dtpOpenDate.Text)) != 0)
                {
                    return true;
                }

                if (this.m_UpdatingAccInfo.CloseDate == null && !string.IsNullOrEmpty(dtpCloseDate.Text) ||
                    this.m_UpdatingAccInfo.CloseDate != null && string.IsNullOrEmpty(dtpCloseDate.Text))
                {
                    return true;
                }
                else if (this.m_UpdatingAccInfo.CloseDate != null && !string.IsNullOrEmpty(dtpCloseDate.Text) && 
                        DateTime.Compare(DateTime.Parse(this.m_UpdatingAccInfo.CloseDate.ToString()), DateTime.Parse(dtpCloseDate.Text)) != 0)
                {
                    return true;
                }
            }
            return false;
        }
        #endregion
    }
}
