﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDListFXIndirectInvestor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbbCustomerName = new System.Windows.Forms.ComboBox();
            this.cbbCustomerCode = new System.Windows.Forms.ComboBox();
            this.cbbCustomerType = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ckbInvestor = new System.Windows.Forms.CheckBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtgCustomer = new System.Windows.Forms.DataGridView();
            this.colInvestor = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colCustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colShortName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCustomerType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnModify = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCustomer)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(656, 473);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 14;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.cbbCustomerName);
            this.groupBox1.Controls.Add(this.cbbCustomerCode);
            this.groupBox1.Controls.Add(this.cbbCustomerType);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.ckbInvestor);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(9, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(719, 80);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            // 
            // cbbCustomerName
            // 
            this.cbbCustomerName.FormattingEnabled = true;
            this.cbbCustomerName.Location = new System.Drawing.Point(330, 18);
            this.cbbCustomerName.Name = "cbbCustomerName";
            this.cbbCustomerName.Size = new System.Drawing.Size(250, 21);
            this.cbbCustomerName.TabIndex = 6;
            this.cbbCustomerName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbbCustomerName_KeyPress);
            this.cbbCustomerName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbbCustomerName_KeyDown);
            // 
            // cbbCustomerCode
            // 
            this.cbbCustomerCode.AllowDrop = true;
            this.cbbCustomerCode.FormattingEnabled = true;
            this.cbbCustomerCode.Location = new System.Drawing.Point(111, 19);
            this.cbbCustomerCode.Name = "cbbCustomerCode";
            this.cbbCustomerCode.Size = new System.Drawing.Size(110, 21);
            this.cbbCustomerCode.TabIndex = 6;
            this.cbbCustomerCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbbCustomerCode_KeyPress);
            this.cbbCustomerCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbbCustomerCode_KeyDown);
            // 
            // cbbCustomerType
            // 
            this.cbbCustomerType.FormattingEnabled = true;
            this.cbbCustomerType.Location = new System.Drawing.Point(111, 45);
            this.cbbCustomerType.Name = "cbbCustomerType";
            this.cbbCustomerType.Size = new System.Drawing.Size(110, 21);
            this.cbbCustomerType.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Customer Type";
            // 
            // ckbInvestor
            // 
            this.ckbInvestor.AutoSize = true;
            this.ckbInvestor.Location = new System.Drawing.Point(330, 47);
            this.ckbInvestor.Name = "ckbInvestor";
            this.ckbInvestor.Size = new System.Drawing.Size(64, 17);
            this.ckbInvestor.TabIndex = 4;
            this.ckbInvestor.Text = "Investor";
            this.ckbInvestor.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(581, 45);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(242, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Customer Name";
            // 
            // dtgCustomer
            // 
            this.dtgCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colInvestor,
            this.colCustomerCode,
            this.colFullName,
            this.colShortName,
            this.colCustomerType});
            this.dtgCustomer.Location = new System.Drawing.Point(9, 89);
            this.dtgCustomer.Name = "dtgCustomer";
            this.dtgCustomer.ReadOnly = true;
            this.dtgCustomer.RowHeadersVisible = false;
            this.dtgCustomer.Size = new System.Drawing.Size(722, 368);
            this.dtgCustomer.TabIndex = 10;
            // 
            // colInvestor
            // 
            this.colInvestor.DataPropertyName = "IndirectInvestor";
            this.colInvestor.HeaderText = "Indirect Investor";
            this.colInvestor.Name = "colInvestor";
            this.colInvestor.ReadOnly = true;
            // 
            // colCustomerCode
            // 
            this.colCustomerCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCustomerCode.DataPropertyName = "Code";
            this.colCustomerCode.HeaderText = "Customer Code";
            this.colCustomerCode.Name = "colCustomerCode";
            this.colCustomerCode.ReadOnly = true;
            // 
            // colFullName
            // 
            this.colFullName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colFullName.DataPropertyName = "Name";
            this.colFullName.HeaderText = "Customer Name";
            this.colFullName.Name = "colFullName";
            this.colFullName.ReadOnly = true;
            // 
            // colShortName
            // 
            this.colShortName.HeaderText = "Short Name";
            this.colShortName.Name = "colShortName";
            this.colShortName.ReadOnly = true;
            // 
            // colCustomerType
            // 
            this.colCustomerType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCustomerType.DataPropertyName = "CustType";
            this.colCustomerType.HeaderText = "Customer Type";
            this.colCustomerType.Name = "colCustomerType";
            this.colCustomerType.ReadOnly = true;
            // 
            // btnModify
            // 
            this.btnModify.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModify.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnModify.Location = new System.Drawing.Point(566, 473);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(75, 23);
            this.btnModify.TabIndex = 11;
            this.btnModify.Text = "Modify";
            this.btnModify.UseVisualStyleBackColor = false;
            this.btnModify.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // frmMDListFXIndirectInvestor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(740, 508);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dtgCustomer);
            this.Controls.Add(this.btnModify);
            this.Name = "frmMDListFXIndirectInvestor";
            this.Text = "FX Indirect Investor";
            this.Load += new System.EventHandler(this.frmMDListFXIndirectInvestor_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCustomer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbbCustomerName;
        private System.Windows.Forms.ComboBox cbbCustomerCode;
        private System.Windows.Forms.ComboBox cbbCustomerType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox ckbInvestor;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dtgCustomer;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colInvestor;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFullName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colShortName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerType;
    }
}