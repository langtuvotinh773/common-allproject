﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDAddModifyTransientAccInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbbDepartment = new System.Windows.Forms.ComboBox();
            this.lblDepartmentCode = new System.Windows.Forms.Label();
            this.cbbCCY = new System.Windows.Forms.ComboBox();
            this.lblTeam = new System.Windows.Forms.Label();
            this.txtGLSubCode = new System.Windows.Forms.TextBox();
            this.txtGLCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblFullShortName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtAcountcNo = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtAccType = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpOpenDate = new UserCtrl.BlankCalendar();
            this.dtpCloseDate = new UserCtrl.BlankCalendar();
            this.SuspendLayout();
            // 
            // cbbDepartment
            // 
            this.cbbDepartment.FormattingEnabled = true;
            this.cbbDepartment.Location = new System.Drawing.Point(113, 35);
            this.cbbDepartment.Name = "cbbDepartment";
            this.cbbDepartment.Size = new System.Drawing.Size(104, 21);
            this.cbbDepartment.TabIndex = 35;
            // 
            // lblDepartmentCode
            // 
            this.lblDepartmentCode.AutoSize = true;
            this.lblDepartmentCode.Location = new System.Drawing.Point(38, 38);
            this.lblDepartmentCode.Name = "lblDepartmentCode";
            this.lblDepartmentCode.Size = new System.Drawing.Size(62, 13);
            this.lblDepartmentCode.TabIndex = 34;
            this.lblDepartmentCode.Text = "Department";
            // 
            // cbbCCY
            // 
            this.cbbCCY.FormattingEnabled = true;
            this.cbbCCY.Location = new System.Drawing.Point(349, 35);
            this.cbbCCY.Name = "cbbCCY";
            this.cbbCCY.Size = new System.Drawing.Size(105, 21);
            this.cbbCCY.TabIndex = 37;
            // 
            // lblTeam
            // 
            this.lblTeam.AutoSize = true;
            this.lblTeam.Location = new System.Drawing.Point(266, 42);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.Size = new System.Drawing.Size(28, 13);
            this.lblTeam.TabIndex = 36;
            this.lblTeam.Text = "CCY";
            // 
            // txtGLSubCode
            // 
            this.txtGLSubCode.Location = new System.Drawing.Point(162, 62);
            this.txtGLSubCode.Name = "txtGLSubCode";
            this.txtGLSubCode.Size = new System.Drawing.Size(55, 20);
            this.txtGLSubCode.TabIndex = 40;
            this.txtGLSubCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGLSubCode_KeyPress);
            // 
            // txtGLCode
            // 
            this.txtGLCode.Location = new System.Drawing.Point(113, 62);
            this.txtGLCode.Name = "txtGLCode";
            this.txtGLCode.Size = new System.Drawing.Size(31, 20);
            this.txtGLCode.TabIndex = 41;
            this.txtGLCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGLCode_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(147, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 13);
            this.label1.TabIndex = 38;
            this.label1.Text = "-";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Location = new System.Drawing.Point(38, 65);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(54, 13);
            this.lblUserName.TabIndex = 39;
            this.lblUserName.Text = "G/L Code";
            // 
            // lblFullShortName
            // 
            this.lblFullShortName.AutoSize = true;
            this.lblFullShortName.Location = new System.Drawing.Point(266, 69);
            this.lblFullShortName.Name = "lblFullShortName";
            this.lblFullShortName.Size = new System.Drawing.Size(64, 13);
            this.lblFullShortName.TabIndex = 42;
            this.lblFullShortName.Text = "Account No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(39, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 48;
            this.label2.Text = "Open Date";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.Location = new System.Drawing.Point(267, 95);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 13);
            this.label19.TabIndex = 49;
            this.label19.Text = "Close Date";
            // 
            // txtAcountcNo
            // 
            this.txtAcountcNo.Location = new System.Drawing.Point(348, 62);
            this.txtAcountcNo.Name = "txtAcountcNo";
            this.txtAcountcNo.Size = new System.Drawing.Size(105, 20);
            this.txtAcountcNo.TabIndex = 40;
            this.txtAcountcNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAcountcNo_KeyPress);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(288, 168);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 32;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.Location = new System.Drawing.Point(378, 168);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 33;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtAccType
            // 
            this.txtAccType.Location = new System.Drawing.Point(115, 117);
            this.txtAccType.Name = "txtAccType";
            this.txtAccType.Size = new System.Drawing.Size(339, 20);
            this.txtAccType.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 42;
            this.label4.Text = "Account Type";
            // 
            // dtpOpenDate
            // 
            this.dtpOpenDate.CustomFormat = "dd-MMM-yyyy";
            this.dtpOpenDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpOpenDate.Location = new System.Drawing.Point(113, 89);
            this.dtpOpenDate.Name = "dtpOpenDate";
            this.dtpOpenDate.Size = new System.Drawing.Size(104, 20);
            this.dtpOpenDate.TabIndex = 50;
            this.dtpOpenDate.Value = new System.DateTime(2013, 4, 25, 17, 12, 37, 985);
            // 
            // dtpCloseDate
            // 
            this.dtpCloseDate.CustomFormat = "dd-MMM-yyyy";
            this.dtpCloseDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCloseDate.Location = new System.Drawing.Point(348, 89);
            this.dtpCloseDate.Name = "dtpCloseDate";
            this.dtpCloseDate.Size = new System.Drawing.Size(105, 20);
            this.dtpCloseDate.TabIndex = 50;
            this.dtpCloseDate.Value = new System.DateTime(2013, 5, 28, 0, 0, 0, 0);
            // 
            // frmMDAddModifyTransientAccInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(500, 216);
            this.Controls.Add(this.dtpCloseDate);
            this.Controls.Add(this.dtpOpenDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblFullShortName);
            this.Controls.Add(this.txtAccType);
            this.Controls.Add(this.txtAcountcNo);
            this.Controls.Add(this.txtGLSubCode);
            this.Controls.Add(this.txtGLCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.cbbCCY);
            this.Controls.Add(this.lblTeam);
            this.Controls.Add(this.cbbDepartment);
            this.Controls.Add(this.lblDepartmentCode);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Name = "frmMDAddModifyTransientAccInfo";
            this.Text = "Create Transient Account Information";
            this.Load += new System.EventHandler(this.frmMDAddModifyTransientAccInfo_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDAddModifyTransientAccInfo_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbbDepartment;
        private System.Windows.Forms.Label lblDepartmentCode;
        private System.Windows.Forms.ComboBox cbbCCY;
        private System.Windows.Forms.Label lblTeam;
        private System.Windows.Forms.TextBox txtGLSubCode;
        private System.Windows.Forms.TextBox txtGLCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblFullShortName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtAcountcNo;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtAccType;
        private System.Windows.Forms.Label label4;
        private UserCtrl.BlankCalendar dtpOpenDate;
        private UserCtrl.BlankCalendar dtpCloseDate;
    }
}