﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-04-11 (Thi, 11 April 2013) $
 * ========================================================
 * This class is used to import daily quotation from excel
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Com;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.Functions;
using Phoenix.Common.Log.Bus;
using System.Globalization;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Log.Dto;

namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDImportQuotation : frmMDMaster
    {
        #region Global Variable
        /// <summary>
        /// Event handle after import data if has
        /// </summary>
        public event EventHandler OnAfterImported;
        clsMDQuotationDTO dtoCurQuotation;//current quotation
        clsMDQuotationDTO dtoPreQuotation;//previous quotation, used to compare status to set action import
        List<clsMDQuotationDetailDTO> listQuotationDetail;//list quotation detail to import
        List<clsMDQuotationECRateDTO> listQUotationECRate;//list quotation EC Rate to import
        List<string> listCCYPairNotImportEQUSD;
        List<string> listCCYPairNotImportEQVND;
        List<string> listCCYPairNotImportECRate;
        /// <summary>
        /// List current CCY Pair
        /// </summary>
        DataTable dtExchangeCCYPair;
        /// <summary>
        /// List current CCY
        /// </summary>
        DataTable dtCurrencyMaster;
        /// <summary>
        /// Stop import 
        /// </summary>
        bool isStopProccess = false;
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        /// <summary>
        /// Import Log Object
        /// </summary>
        clsCOMExternalTransactionLogDTO externaLog;
        //
        string strNotReadNumberValue = "#VALUE!";
        bool CommonError = false;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDImportQuotation class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDImportQuotation()
        {
			try
			{
				InitializeComponent();
				 //Check authorization
				m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
				m_Security.CheckAuthorizationOnScreen(this);

				externaLog = new clsCOMExternalTransactionLogDTO();
				externaLog.Module = clsMDConstant.MODULE_MD;
				externaLog.UserNo = clsUserInfo.UserNo;
				externaLog.LogDate = DateTime.Now;
			}
			catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                CommonError = true;
            }
        }
        #endregion

        #region Events Functions

        /// <summary>
        /// Event form load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDImportQuotation_Load(object sender, EventArgs e)
        {            
            //Set comon style
            SetFormStyleCommon();
        }

        /// <summary>
        /// Event click button "Browse" to tranfer OpenFileDialogs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                //Title OpenFileDialog
                openFileDialogImport.Title = clsMDConstant.QUOTATION_TITLE_IMPORT;
                openFileDialogImport.FileName = clsMDConstant.QUOTATION_TITLE_IMPORT;
                //Filter files .txt
                openFileDialogImport.Filter = clsMDConstant.DIALOG_IMPORT_FILTER_TXT_EXCEL;
                //Show OpenFileDialog 
                string strDirectory = clsMDQuoationBus.Instance().GetLastestFileDirectoryOfQuotation();
                if (!string.IsNullOrEmpty(strDirectory))
                {
                    openFileDialogImport.InitialDirectory = strDirectory;
                }
                if (openFileDialogImport.ShowDialog() == DialogResult.OK)
                {
                    txtDirectory.Text = openFileDialogImport.FileName;
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event click button "Import" to tranfer OpenFileDialogs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnImport_Click(object sender, EventArgs e)
        {
            if (!IsValidFileImport())
            {
                return;
            }
            //disable all button while system excute import function.
            EnableButtonControl(false);
            try
            {
                //get previous quotation
                dtoPreQuotation = clsMDQuoationBus.Instance().GetPreviousQuotation();
                //content of message confirm
                string strMessage = string.Empty;
                //there is not any quotaion in db
                if (dtoPreQuotation != null && dtoPreQuotation.QuotationID <= 0)
                {
                    dtoPreQuotation = null;
                }
                if (dtoPreQuotation != null)
                {                    
                    int iStatus = dtoPreQuotation.Status;
                    //if there is existed quotation with status Wait for Approve, can not import
                    if (iStatus == (int)CommonValue.QuotationStatus.WaitForApprove)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.WARNING_ACTION_IMPORT + Environment.NewLine + clsMDMessage.WARNING_ACTION_CAN_NOT_IMPORT);
                        //enable all button while system finish import function.
                        EnableButtonControl(true);
                        return;
                    }
                    //
                    if (iStatus == (int)CommonValue.QuotationStatus.Withdrawn || iStatus == (int)CommonValue.QuotationStatus.Returned || iStatus == (int)CommonValue.QuotationStatus.Suspended)
                    {
                        strMessage = string.Format(clsMDMessage.CONFIRM_ACTION_RE_IMPORT_DATA, "Daily Quotation");
                    }
                    else
                    {
                        strMessage = string.Format(clsMDMessage.CONFIRM_ACTION_IMPORT_DATA, "Daily Quotation");
                    }
                }
                else
                {
                    strMessage = string.Format(clsMDMessage.CONFIRM_ACTION_IMPORT_DATA, "Daily Quotation");
                }
                //2013.05.30 UDP vlhcnhung E Should be only one confirmation message
                ////display message to confirm import data
                //DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, strMessage);
                //if (res == DialogResult.Yes)
                {
                    if (IsValidFileImport())
                    {
                        listQuotationDetail = new List<clsMDQuotationDetailDTO>();
                        listQUotationECRate = new List<clsMDQuotationECRateDTO>();
                        dtExchangeCCYPair = new DataTable();
                        dtCurrencyMaster = new DataTable();
                        dtoCurQuotation = new clsMDQuotationDTO();
                        //
                        ImportDailyQuotationFromExcel(sender, e);
                    }
                }
                //2013.05.30 UDP vlhcnhung E Should be only one confirmation message
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //enable all button while system finish import function.
            EnableButtonControl(true);
        }

        /// <summary>
        /// Event click button "Cancel" to close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmMDImportQuotation_Shown(object sender, EventArgs e)
        {
            if (CommonError)
            {
                this.Close();
            }
        }
        #endregion

        #region Member Methods
        /// <summary>
        /// Enable or disable all button 
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnBrowse.Enabled = value;
            btnClose.Enabled = value;
            btnImport.Enabled = value;
            if (value)
            {
                btnImport.Enabled = true;
                if (btnImport.Tag != null && !string.IsNullOrEmpty(btnImport.Tag.ToString()))
                {
                    btnImport.Enabled = bool.Parse(btnImport.Tag.ToString());
                }
            }
        }

        /// <summary>
        /// Check FilePath is valid
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool IsValidFileImport()
        {
            string strFilePath = txtDirectory.Text.ToString().Trim();
            if (string.IsNullOrEmpty(strFilePath))
            {                
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a file", "import"));
                btnBrowse.Focus();
                return false;
            }
            FileInfo fileInfo = new FileInfo(strFilePath);
            //Check type file is .txt
            if (fileInfo.Extension != ".xls")
            {                
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.WARNING_ACTION_FILE_TYPE_INVALID);
                btnBrowse.Focus();
                return false;
            }
            //Check file exist
            if (!fileInfo.Exists)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.WARNING_ACTION_FILE_IMPORT_NOT_FOUND);
                btnBrowse.Focus();
                return false;
            }
            externaLog.FileName = fileInfo.Name;
            externaLog.FilePath = fileInfo.DirectoryName;
            externaLog.FileType = CommonValue.FileType.Excel.ToString();
            return true;
        }

        /// <summary>
        /// Import data
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void ImportDailyQuotationFromExcel(object sender, EventArgs e)
        {
            listQuotationDetail = new List<clsMDQuotationDetailDTO>();
            listQUotationECRate = new List<clsMDQuotationECRateDTO>();
            listCCYPairNotImportECRate = new List<string>();
            listCCYPairNotImportEQUSD = new List<string>();
            listCCYPairNotImportEQVND = new List<string>();

            //get list ExchangeCCYPair to check validate data read from excel
            dtExchangeCCYPair = clsMDExchangeCCYPairBUS.Instance().GetAllExchangeCCYPairList();
            dtCurrencyMaster = clsMDCurrencyMasterBUS.Instance().GetCurrencyList();
            //Read data from excel
            ReadDailyQuotationExcel();            
            //2013.05.16 UDP vlhcnhung E Pop up warning in case Seq is different with current system
            if (!isStopProccess)
            {
                //2013.05.16 UDP vlhcnhung S Pop up warning in case Seq is different with current system
                if (dtoCurQuotation == null)
                {
                    return;
                }
                else
                {
                    string strMessage = "Are you sure import daily quotation with Seq No. " + dtoCurQuotation.Seq + "?";
                    //display message to confirm import data
                    DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, strMessage);
                    if (res == DialogResult.No || res == DialogResult.Cancel)
                    {
                        return;
                    }
                }
                //2013.05.27 UDP vlhcnhung S Format template Import Daily Quotation
                //check CCY Pair can not import, can not read number value cause wrong formular
                if (listCCYPairNotImportECRate.Count > 0 || listCCYPairNotImportEQUSD.Count > 0 || listCCYPairNotImportEQVND.Count > 0)
                {
                    int countCCY = listCCYPairNotImportECRate.Count + listCCYPairNotImportEQUSD.Count + listCCYPairNotImportEQVND.Count;
                    string strMessage = string.Format("There are some error value of CCY Pair", countCCY.ToString());
                    if (listCCYPairNotImportEQUSD.Count > 0)
                    {
                        strMessage += Environment.NewLine + "In sheet " + clsMDConstant.QUOTATION_SHEETNAME_EQ_USD + ":";
                        foreach (string s in listCCYPairNotImportEQUSD)
                        {
                            strMessage += " " + s + ",";
                        }
                    }
                    if (strMessage[strMessage.Length - 1].CompareTo(char.Parse(",")) == 0)
                    {
                        strMessage = strMessage.Remove(strMessage.Length - 1);                        
                    }
                    if (listCCYPairNotImportEQVND.Count > 0)
                    {
                        strMessage += Environment.NewLine + "In sheet " + clsMDConstant.QUOTATION_SHEETNAME_EQ_VND + ":";
                        foreach (string s in listCCYPairNotImportEQVND)
                        {
                            strMessage += " " + s + ",";
                        }
                    }
                    if (strMessage[strMessage.Length - 1].CompareTo(char.Parse(",")) == 0)
                    {
                        strMessage = strMessage.Remove(strMessage.Length - 1);
                    }
                    if (listCCYPairNotImportECRate.Count > 0)
                    {
                        strMessage += Environment.NewLine + "In sheet " + clsMDConstant.QUOTATION_SHEETNAME_EC_RATE + ":";
                        foreach (string s in listCCYPairNotImportECRate)
                        {
                            strMessage += " " + s + ",";
                        }
                    }
                    if (strMessage[strMessage.Length - 1].CompareTo(char.Parse(",")) == 0)
                    {
                        strMessage = strMessage.Remove(strMessage.Length - 1);
                    }
                    strMessage += Environment.NewLine + clsMDMessage.CONFIRM_ACTION_DO_COUNTINUE;

                    //display message to confirm import data
                    DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, strMessage, 150);
                    if (res == DialogResult.No || res == DialogResult.Cancel)
                    {
                        return;
                    }
                }
                //2013.05.27 UDP vlhcnhung E Format template Import Daily Quotation
                //Save to db
                int iRow = -1;
                int iStatus;
                if (dtoPreQuotation != null)
                {
                    iStatus = dtoPreQuotation.Status;
                    //get info of quotation
                    dtoCurQuotation.FileDirectory = new FileInfo(txtDirectory.Text.Trim()).DirectoryName;
                    dtoCurQuotation.Status = (int)CommonValue.QuotationStatus.New;
                    dtoCurQuotation.CreatedBy = clsUserInfo.UserNo;
                    dtoCurQuotation.Version = 1.0;// set version = 1.0 

                    //Previous quotation has status 'Withdrawn' or 'New', system will overrive previous quotation
                    if (iStatus == (int)CommonValue.QuotationStatus.Withdrawn || iStatus == (int)CommonValue.QuotationStatus.New)
                    {
                        dtoCurQuotation.QuotationID = dtoPreQuotation.QuotationID;
                        dtoCurQuotation.IsActive = false;
                        iRow = clsMDQuoationBus.Instance().UpdateQuotationInCaseOverride(dtoCurQuotation, listQuotationDetail, listQUotationECRate, externaLog);
                    }
                    //Previous quotation has status 'Returned', system will create new quotation
                    else if (iStatus == (int)CommonValue.QuotationStatus.Returned)
                    {
                        //when user view quotation, system will highlight changed values
                        iRow = clsMDQuoationBus.Instance().CreateQuotationInfo(ref dtoCurQuotation, null, listQuotationDetail, listQUotationECRate, externaLog);
                    }
                    //Previous quotation has status 'Approved', system will create new quotation and set version = Previous quotation's version + 1.0 
                    else if (iStatus == (int)CommonValue.QuotationStatus.Approved)
                    {
                        dtoCurQuotation.Status = (int)CommonValue.QuotationStatus.New;
                        dtoCurQuotation.Version = dtoPreQuotation.Version + 1.0;
                        iRow = clsMDQuoationBus.Instance().CreateQuotationInfo(ref dtoCurQuotation, null, listQuotationDetail, listQUotationECRate, externaLog);
                    }
                    //Previous quotation has status 'Suspended', system will create new quotation and set version = Previous quotation's version + 0.1 
                    else if (iStatus == (int)CommonValue.QuotationStatus.Suspended)
                    {
                        //insert new daily quotation and set new version = old version + 0.1 
                        int iVersion = (int)dtoPreQuotation.Version;
                        double dVersion = dtoPreQuotation.Version - iVersion;
                        if (dVersion + 0.1 < 1)
                        {
                            dtoCurQuotation.Version = dtoPreQuotation.Version + 0.1;
                        }
                        else
                        {
                            dtoCurQuotation.Version = iVersion + 1;
                        }
                        //update status for previous quotation
                        dtoPreQuotation.Status = (int)CommonValue.QuotationStatus.Obsolete;
                        iRow = clsMDQuoationBus.Instance().CreateQuotationInfo(ref dtoCurQuotation, dtoPreQuotation, listQuotationDetail, listQUotationECRate, externaLog);
                    }
                }
                else//there is not any quotation in current date, system will create a new quotation
                {
                    dtoCurQuotation.FileDirectory = new FileInfo(txtDirectory.Text.Trim()).DirectoryName;
                    dtoCurQuotation.Status = (int)CommonValue.QuotationStatus.New;
                    dtoCurQuotation.Version = 1.0;
                    dtoCurQuotation.CreatedBy = clsUserInfo.UserNo;
                    iRow = clsMDQuoationBus.Instance().CreateQuotationInfo(ref dtoCurQuotation, null, listQuotationDetail, listQUotationECRate, externaLog);
                }
                if (iRow == 0)
                {
                    //import unsuccess
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Importing", "quotation"));
                }
                else if (iRow > 0)
                {
                    //import success
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Importing", "quotation"));
                    //2013.05.16 UDP vlhcnhung S After import, call View Maker
                    this.Close();
                    if (OnAfterImported != null)
                    {
                        OnAfterImported(sender, e);
                    }
                    //2013.05.16 UDP vlhcnhung E After import, call View Maker
                }
                else
                {
                    this.Close();
                }
            }
        }

        /// <summary>
        /// Read Excel
        /// </summary>
        /// <param name="strFilePath"></param>
        /// <param name="strPass"></param>
        /// <param name="rowCount"></param>
        /// <param name="colCount"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void ReadDailyQuotationExcel()
        {
            string strFilePath = this.txtDirectory.Text.Trim();
            List<Excel.Worksheet> listSheet = new List<Excel.Worksheet>();
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.ApplicationClass();
            xlWorkBook = xlApp.Workbooks.Open(strFilePath, 0, true, 5, string.Empty, string.Empty, true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
            //Read all sheet in excel file            
            int numSheets = xlWorkBook.Sheets.Count;
            bool readEQ_USD = false;
            bool readEQ_VND = false;
            bool readEC_RATE = false;
            // Iterate through the sheets. They are indexed starting at 1.
            for (int sheetNum = 1; sheetNum < numSheets + 1; sheetNum++)
            {
                //2013.05.27 UDP vlhcnhung S Format template Import Daily Quotation
                Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Sheets[sheetNum];
                if (xlWorkSheet.Name == clsMDConstant.QUOTATION_SHEETNAME_EQ_USD)
                {
                    listSheet.Add(xlWorkSheet);
                    readEQ_USD = true;
                }
                if (xlWorkSheet.Name == clsMDConstant.QUOTATION_SHEETNAME_EQ_VND)
                {
                    listSheet.Add(xlWorkSheet);
                    readEQ_VND = true;
                }
                if (xlWorkSheet.Name == clsMDConstant.QUOTATION_SHEETNAME_EC_RATE)
                {
                    listSheet.Add(xlWorkSheet);
                    readEC_RATE = true;
                }
                if (readEC_RATE == true && readEQ_USD == true && readEQ_VND == true)
                {
                    break;
                }
                //2013.05.27 UDP vlhcnhung E Format template Import Daily Quotation
            }
            //
            isStopProccess = false;
            foreach (Excel.Worksheet sheet in listSheet)
            {
                if (!isStopProccess)
                {
                    switch (sheet.Name)
                    {
                        case clsMDConstant.QUOTATION_SHEETNAME_EQ_USD:
                            ReadQuotationDetail1(sheet);
                            break;
                        case clsMDConstant.QUOTATION_SHEETNAME_EQ_VND:
                            ReadQuotationDetail2(sheet);
                            break;
                        case clsMDConstant.QUOTATION_SHEETNAME_EC_RATE:
                            ReadQuotationECRate(sheet);
                            break;
                    }
                }
                else
                {
                    break;
                }
            }
            //
            xlWorkBook.Close(false, misValue, misValue);
            xlApp.Quit();
            clsMDFunction.ReleaseObject(xlWorkBook);
            clsMDFunction.ReleaseObject(xlApp);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strValue"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private string ToUpperString(string strValue)
        {
            return strValue.Trim().ToUpper().Replace(":", "").Replace("\n", " ").Replace(" ", "");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cell"></param>
        /// <param name="dtoCurQuotation"></param>
        /// <param name="strSheetName"></param>
        /// <param name="iCurRow"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool ReadDateImport(Excel.Range cell, clsMDQuotationDTO dtoCurQuotation, string strSheetName, int iCurRow)
        {
            if (dtoCurQuotation != null)
            {
                string valueCell = string.Empty;
                //if value is null, display error message 
                if (cell.Value2 == null)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_EMPTY, strSheetName, clsMDConstant.QUOTATION_IMPORT_DATE, iCurRow));
                    return false;
                }
                valueCell = cell.Text.ToString().Trim();
                DateTime parsedDate;
                if (DateTime.TryParse(valueCell, out parsedDate))
                {
                    dtoCurQuotation.ImportTime = DateTime.Parse(valueCell);
                    //2013.05.30 UDP vlhcnhung S Check the date of quotation
                    if (!(dtoCurQuotation.ImportTime.Year == DateTime.Now.Year
                        && dtoCurQuotation.ImportTime.Month == DateTime.Now.Month
                        && dtoCurQuotation.ImportTime.Day == DateTime.Now.Day))
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, "Import date is not today.");
                        return false;
                    }
                    //2013.05.30 UDP vlhcnhung E Check the date of quotation
                }
                else
                {
                    //if value is not datetime, display error message
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID, strSheetName, clsMDConstant.QUOTATION_IMPORT_DATE, iCurRow)
                        + " Format Date: dd-mmm-yy.");
                    return false;
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cell"></param>
        /// <param name="dtoCurQuotation"></param>
        /// <param name="strSheetName"></param>
        /// <param name="iCurRow"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool ReadEffectiveTime(Excel.Range cell, clsMDQuotationDTO dtoCurQuotation, string strSheetName, int iCurRow)
        {
            if (dtoCurQuotation != null)
            {
                string valueCell = string.Empty;
                //if value is null, display error message
                if (cell.Value2 == null)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_EMPTY, strSheetName, clsMDConstant.QUOTATION_IMPORT_TIME, iCurRow));
                    return false;
                }
                valueCell = cell.Text.ToString().Trim();
                //if value is empty, display error message
                if (string.IsNullOrEmpty(valueCell))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID, strSheetName, clsMDConstant.QUOTATION_IMPORT_TIME, iCurRow));
                    return false;
                }
                else
                {
                    dtoCurQuotation.EffectiveTime = valueCell;
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cell"></param>
        /// <param name="dtoCurQuotation"></param>
        /// <param name="strSheetName"></param>
        /// <param name="iCurRow"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool ReadSequence(Excel.Range cell, clsMDQuotationDTO dtoCurQuotation, string strSheetName, int iCurRow)
        {
            if (dtoCurQuotation != null)
            {
                string valueCell = string.Empty;
                int seq;
                //if value is null, display error message
                if (cell.Value2 == null)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_EMPTY, strSheetName, clsMDConstant.QUOTATION_IMPORT_SEQUENCE, iCurRow));
                    return false;
                }
                valueCell = cell.Text.ToString().Trim();
                if (int.TryParse(valueCell, out seq))
                {
                    dtoCurQuotation.Seq = int.Parse(valueCell);
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID, strSheetName, clsMDConstant.QUOTATION_IMPORT_SEQUENCE, iCurRow));
                    return false;
                }
                //2013.05.30 UDP vlhcnhung S Show error message when user imports the 2nd quotation with the "Seq" No. 1
                if (dtoPreQuotation == null)
                {
                    if (dtoCurQuotation.Seq != 1)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, "Seq No. is invalid data. Seq must be No. 1.");
                        return false;
                    }
                }
                else
                {
                    int iStatus = dtoPreQuotation.Status;                    
                    if (iStatus == (int)CommonValue.QuotationStatus.Approved)
                    {
                        if (dtoCurQuotation.Seq <= dtoPreQuotation.Seq)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, "Seq No. is invalid data. Seq must be greater than " + dtoPreQuotation.Seq.ToString() + ".");
                            return false;
                        }
                    }
                }
                //2013.05.30 UDP vlhcnhung E Show error message when user imports the 2nd quotation with the "Seq" No. 1
                return true;
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cell"></param>
        /// <param name="dtoCurQuotation"></param>
        /// <param name="strSheetName"></param>
        /// <param name="iCurRow"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool ReadCentralBankCoreRate(Excel.Range cell, clsMDQuotationDTO dtoCurQuotation, string strSheetName, int iCurRow)
        {
            if (dtoCurQuotation != null)
            {
                string valueCell = string.Empty;
                double d;
                //if value is null, display error message
                if (cell.Value2 == null)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_EMPTY, strSheetName, clsMDConstant.QUOTATION_IMPORT_CENTRAL_BANK_CORE_RATE, iCurRow));
                    return false;
                }
                valueCell = cell.Text.ToString().Trim();
                if (double.TryParse(valueCell, out d))
                {
                    dtoCurQuotation.CentralBankCoreRate = valueCell;
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, 
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID, strSheetName , clsMDConstant.QUOTATION_IMPORT_CENTRAL_BANK_CORE_RATE, iCurRow));
                    return false;
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cell"></param>
        /// <param name="dtoCurQuotation"></param>
        /// <param name="strSheetName"></param>
        /// <param name="iCurRow"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool ReadTC(Excel.Range cell, clsMDQuotationDTO dtoCurQuotation, string strSheetName, int iCurRow)
        {
            if (dtoCurQuotation != null)
            {
                string valueCell = string.Empty;
                double d;
                //if value is null, display error message
                if (cell.Value2 == null)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_EMPTY, strSheetName, clsMDConstant.QUOTATION_IMPORT_TC, iCurRow));
                    return false;
                }
                valueCell = cell.Text.ToString().Trim();
                if (double.TryParse(valueCell, out d))
                {
                    dtoCurQuotation.TC = valueCell;
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID, strSheetName, clsMDConstant.QUOTATION_IMPORT_TC, iCurRow));
                    return false;
                }
            }
            else
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cellCCY"></param>
        /// <param name="dtoDetail"></param>
        /// <param name="strSheetName"></param>
        /// <param name="iCurRow"></param>
        /// <param name="containCCY"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool ReadQuotationDetailCCY(Excel.Range cellCCY, clsMDQuotationDetailDTO dtoDetail, string strSheetName, int iCurRow, string containCCY)
        {
            if (dtoDetail != null)
            {
                if (cellCCY.Value2 != null)
                {                    
                    string valueCell = cellCCY.Text.ToString().Trim();
                    DataRow[] result = dtExchangeCCYPair.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_EXCHANGECCYPAIR, valueCell));
                    if (result.Length == 0)//if CCyPair is not existed
                    {
                        string strBaseCCY = string.Empty;
                        string strQuoteCCY = string.Empty;
                        string[] CCY = valueCell.Split(char.Parse("/"));
                        //if CCYPair is inccorrect format [BaseCCY]/[QuoteCCY]. display error message
                        if (CCY.Length != 2)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_NOT_EXIST, strSheetName, clsMDConstant.QUOTATION_IMPORT_CCY, iCurRow));
                            return false;
                        }
                        else//if CCYPair is correct format
                        {
                            //check [BaseCCY] and [QuoteCCY] is existed in CurrencyMaster, insert to ExchangeCCYPair
                            strBaseCCY = CCY[0].Trim();
                            strQuoteCCY = CCY[1].Trim();
                            DataRow[] baseCCY = dtCurrencyMaster.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_CCYCODE, strBaseCCY));
                            DataRow[] quoteCCY = dtCurrencyMaster.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_CCYCODE, strQuoteCCY));
                            if (baseCCY.Length > 0 && quoteCCY.Length > 0)
                            {
                                //insert new ExchangeCCYRate
                                clsMDExchangeCCYPairDTO dtoCCYPair = new clsMDExchangeCCYPairDTO();
                                dtoCCYPair.ExchangeCCYPair = valueCell;
                                dtoCCYPair.BaseCCY = strBaseCCY;
                                dtoCCYPair.QuoteCCY = strQuoteCCY;
                                dtoCCYPair.CreatedBy = clsUserInfo.UserNo;
                                dtoCCYPair.ExchangeCCYPairID = clsMDExchangeCCYPairBUS.Instance().InsertExchangeCCYPair(dtoCCYPair);
                                if (dtoCCYPair.ExchangeCCYPairID <= 0)
                                {
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                            string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_NOT_EXIST, strSheetName, clsMDConstant.QUOTATION_IMPORT_CCY, iCurRow));
                                    return false;
                                }
                                else
                                {                                    
                                    dtoDetail.ExchangeCCYPairID = dtoCCYPair.ExchangeCCYPairID;
                                    dtoDetail.ExchangeCCYPairCode = valueCell.Trim();
                                    //check CCYPair contains USD
                                    if (!valueCell.Contains(containCCY))
                                    {
                                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                            string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_AGAINSTCCY_IS_INVALID, strSheetName, clsMDConstant.QUOTATION_IMPORT_CCY, iCurRow, containCCY));
                                        return false;
                                    }
                                    dtoDetail.AgainstCCY = containCCY;
                                    dtExchangeCCYPair = clsMDExchangeCCYPairBUS.Instance().GetAllExchangeCCYPairList();
                                }
                            }
                            else//if not existed in CurrentcyMaster, display error message
                            {
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_NOT_EXIST, strSheetName, clsMDConstant.QUOTATION_IMPORT_CCY, iCurRow));
                                return false;
                            }
                        }
                    }
                    else//if CCYPair is exist, check CCYPair contains USD
                    {
                        dtoDetail.ExchangeCCYPairID = int.Parse(result[0][clsMDConstant.MD_COL_EXCHANGECCYPAIRID].ToString());
                        dtoDetail.ExchangeCCYPairCode = valueCell.Trim();
                        if (!valueCell.Contains(containCCY))
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_AGAINSTCCY_IS_INVALID, strSheetName, clsMDConstant.QUOTATION_IMPORT_CCY, iCurRow, containCCY));
                            return false;
                        }
                        dtoDetail.AgainstCCY = containCCY;
                    }
                }
                else//if value is null, display error message
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_EMPTY, strSheetName, clsMDConstant.QUOTATION_IMPORT_CCY, iCurRow));
                    return false;
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cellCrossFX"></param>
        /// <param name="dto"></param>
        /// <param name="strSheetName"></param>
        /// <param name="iCurRow"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool ReadQuotationECRateCCY(Excel.Range cellCrossFX, clsMDQuotationECRateDTO dto, string strSheetName, int iCurRow)
        {
            if (dto != null)
            {
                if (cellCrossFX.Value2 != null)
                {
                    string valueCell = cellCrossFX.Text.ToString().Trim();
                    DataRow[] result = dtExchangeCCYPair.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_EXCHANGECCYPAIR, valueCell));
                    if (result.Length == 0)
                    {
                        string strBaseCCY = string.Empty;
                        string strQuoteCCY = string.Empty;
                        string[] CCY = valueCell.Split(char.Parse("/"));
                        //if CCYPair is inccorrect format [BaseCCY]/[QuoteCCY]. display error message
                        if (CCY.Length != 2)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_NOT_EXIST, strSheetName, clsMDConstant.QUOTATION_IMPORT_CROSS_FX, iCurRow));
                            return false;
                        }
                        else//if CCYPair is correct format
                        {
                            //check [BaseCCY] and [QuoteCCY] is existed in CurrencyMaster, insert to ExchangeCCYPair
                            strBaseCCY = CCY[0].Trim();
                            strQuoteCCY = CCY[1].Trim();
                            DataRow[] baseCCY = dtCurrencyMaster.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_CCYCODE, strBaseCCY));
                            DataRow[] quoteCCY = dtCurrencyMaster.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_CCYCODE, strQuoteCCY));
                            if (baseCCY.Length > 0 && quoteCCY.Length > 0)
                            {
                                //insert new ExchangeCCYRate
                                clsMDExchangeCCYPairDTO dtoCCYPair = new clsMDExchangeCCYPairDTO();
                                dtoCCYPair.ExchangeCCYPair = valueCell;
                                dtoCCYPair.BaseCCY = strBaseCCY;
                                dtoCCYPair.QuoteCCY = strQuoteCCY;
                                dtoCCYPair.CreatedBy = clsUserInfo.UserNo;
                                dtoCCYPair.ExchangeCCYPairID = clsMDExchangeCCYPairBUS.Instance().InsertExchangeCCYPair(dtoCCYPair);
                                if (dtoCCYPair.ExchangeCCYPairID <= 0)
                                {
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                            string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID, strSheetName, clsMDConstant.QUOTATION_IMPORT_CROSS_FX, iCurRow));
                                    return false;
                                }
                                else
                                {                                    
                                    dto.ExchangeCCYPairID = dtoCCYPair.ExchangeCCYPairID;
                                    dto.ExchangeCCYPairCode = valueCell.Trim();
                                    dtExchangeCCYPair = clsMDExchangeCCYPairBUS.Instance().GetAllExchangeCCYPairList();
                                }
                            }
                            else//if not existed in CurrentcyMaster, display error message
                            {
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_NOT_EXIST, strSheetName, clsMDConstant.QUOTATION_IMPORT_CCY, iCurRow));
                                return false;
                            }
                        }
                    }
                    else
                    {
                        dto.ExchangeCCYPairID = int.Parse(result[0][clsMDConstant.MD_COL_EXCHANGECCYPAIRID].ToString());
                        dto.ExchangeCCYPairCode = valueCell.Trim();
                    }
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_EMPTY,
                                                                                                                      strSheetName, clsMDConstant.QUOTATION_IMPORT_CROSS_FX, iCurRow));
                    return false;
                }
                return true;
            }
            return false;
        }

        //2013.05.27 UDP vlhcnhung S Format template Import Daily Quotation
        /// <summary>
        /// Read data of Quotation and QuotationDetail USD from excel
        /// </summary>
        /// <param name="xlWorkSheet"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void ReadQuotationDetail1(Excel.Worksheet xlWorkSheet)
        {
            string strSheetName = xlWorkSheet.Name;
            int rowCount = xlWorkSheet.UsedRange.Rows.Count;
            int colCount = xlWorkSheet.UsedRange.Columns.Count;
            string valueCell = string.Empty;            
            if (xlWorkSheet.UsedRange.Value2 != null)
            {
                double d;                
                for (int i = 1; i <= rowCount; i++)
                {
                    for (int j = 1; j <= colCount; j++)
                    {
                        Excel.Range cell = (Excel.Range)xlWorkSheet.Cells[i, j];
                        if (cell.Value2 != null)
                        {
                            valueCell = this.ToUpperString(cell.Text.ToString());                            
                            if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_DATE)) == 0)
                            {
                                cell = (Excel.Range)xlWorkSheet.Cells[i, j + 1];
                                if (!ReadDateImport(cell, dtoCurQuotation, strSheetName, i))
                                {
                                    isStopProccess = true;
                                    return;
                                }
                                break;
                            }                           
                            if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_TIME)) == 0)
                            {
                                cell = (Excel.Range)xlWorkSheet.Cells[i, j + 1];
                                if (!ReadEffectiveTime(cell, dtoCurQuotation, strSheetName, i))
                                {
                                    isStopProccess = true;
                                    return;
                                }
                                break;
                            }
                            if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_SEQUENCE)) == 0)
                            {
                                cell = (Excel.Range)xlWorkSheet.Cells[i, j + 1];
                                if (!ReadSequence(cell, dtoCurQuotation, strSheetName, i))
                                {
                                    isStopProccess = true;
                                    return;
                                }
                                break;
                            }
                            if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CENTRAL_BANK_CORE_RATE)) == 0)
                            {
                                cell = (Excel.Range)xlWorkSheet.Cells[i, j + 1];
                                if (!ReadCentralBankCoreRate(cell, dtoCurQuotation, strSheetName, i))
                                {
                                    isStopProccess = true;
                                    return;
                                }
                                break;
                            }
                            #region read data
                            if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CCY)) == 0)
                            {
                                for (; i < rowCount; i++)
                                {
                                    cell = (Excel.Range)xlWorkSheet.Cells[i, j];
                                    if (cell.Value2 != null)
                                    {
                                        int colCCY = 0, colTTM = 0, colTTB = 0, colTTS = 0, colCSB = 0, colCSS = 0, colTTB_ISRATE = 0, colTTS_ISRATE = 0;
                                        int rowReadData = 0;
                                        //header CCY    TTM     TTB     TTS     CSB     CSS     TTB(I/S RATE)       TTS(I/S RATE)                                       
                                        #region read header table quotation detail
                                        for (; j <= colCount; j++)
                                        {
                                            cell = (Excel.Range)xlWorkSheet.Cells[i, j];
                                            if (cell.Value2 != null)
                                            {
                                                valueCell = this.ToUpperString(cell.Text.ToString());
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CCY)) == 0)
                                                {
                                                    colCCY = j;
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_TTM)) == 0)
                                                {
                                                    colTTM = j;
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_TTB)) == 0)
                                                {
                                                    cell = (Excel.Range)xlWorkSheet.Cells[i + 1, j];
                                                    if (cell.Value2 == null)
                                                    {
                                                        colTTB = j;
                                                    }
                                                    else
                                                    {
                                                        valueCell = this.ToUpperString(cell.Text.ToString());
                                                        if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_I_S_RATE)) == 0)
                                                        {
                                                            colTTB_ISRATE = j;
                                                            rowReadData = i + 2;
                                                        }
                                                    }
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_TTS)) == 0)
                                                {
                                                    cell = (Excel.Range)xlWorkSheet.Cells[i + 1, j];
                                                    if (cell.Value2 == null)
                                                    {
                                                        colTTS = j;
                                                    }
                                                    else
                                                    {
                                                        valueCell = this.ToUpperString(cell.Text.ToString());
                                                        if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_I_S_RATE)) == 0)
                                                        {
                                                            colTTS_ISRATE = j;
                                                            rowReadData = i + 2;
                                                        }
                                                    }
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CSB)) == 0)
                                                {
                                                    colCSB = j;
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CSS)) == 0)
                                                {
                                                    colCSS = j;
                                                }                                                
                                            }
                                        }
                                        #endregion
                                        //                    
                                        if (colCCY != 0 && colTTM != 0 && colTTB != 0 && colTTS != 0 && colCSB != 0 && colCSS != 0 && colTTB_ISRATE != 0 && colTTS_ISRATE != 0)
                                        {
                                            for (; rowReadData < rowCount; rowReadData++)
                                            {
                                                bool isCanNotImport = false;
                                                Excel.Range cellCCY = (Excel.Range)xlWorkSheet.Cells[rowReadData, colCCY];
                                                Excel.Range cellTTM = (Excel.Range)xlWorkSheet.Cells[rowReadData, colTTM];
                                                Excel.Range cellTTB = (Excel.Range)xlWorkSheet.Cells[rowReadData, colTTB];
                                                Excel.Range cellTTS = (Excel.Range)xlWorkSheet.Cells[rowReadData, colTTS];
                                                Excel.Range cellCSB = (Excel.Range)xlWorkSheet.Cells[rowReadData, colCSB];
                                                Excel.Range cellCSS = (Excel.Range)xlWorkSheet.Cells[rowReadData, colCSS];
                                                Excel.Range cellTTB_ISRATE = (Excel.Range)xlWorkSheet.Cells[rowReadData, colTTB_ISRATE];
                                                Excel.Range cellTTS_ISRATE = (Excel.Range)xlWorkSheet.Cells[rowReadData, colTTS_ISRATE];

                                                if (cellCCY.Value2 == null && cellTTM.Value2 == null && cellTTB.Value2 == null && cellTTS.Value2 == null &&
                                                    cellCSB.Value2 == null && cellCSS.Value2 == null && cellTTB_ISRATE.Value2==null && cellTTS_ISRATE.Value2==null)
                                                {
                                                    i = rowReadData;
                                                    break;
                                                }
                                                clsMDQuotationDetailDTO dtoDetail = new clsMDQuotationDetailDTO();                                                                                                  
                                                if (!ReadQuotationDetailCCY(cellCCY, dtoDetail, strSheetName, rowReadData, clsMDConstant.USD))
                                                {
                                                    isStopProccess = true;
                                                    return;
                                                }

                                                #region get TTM 
                                                if (cellTTM.Value2 != null)
                                                {
                                                    valueCell = cellTTM.Text.ToString().Trim();
                                                    dtoDetail.FormatNumber = cellTTM.NumberFormat.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.TTM = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.TTM = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            listCCYPairNotImportEQUSD.Add(cellCCY.Text.ToString());
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                       strSheetName, clsMDConstant.QUOTATION_IMPORT_TTM, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }                                                       
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.TTM = string.Empty;
                                                }
                                                #endregion

                                                #region get TTB
                                                if (cellTTB.Value2 != null)
                                                {
                                                    valueCell = cellTTB.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.TTB = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.TTB = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQUSD.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                      strSheetName, clsMDConstant.QUOTATION_IMPORT_TTB, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.TTB = string.Empty;
                                                }
                                                #endregion

                                                #region get TTS
                                                if (cellTTS.Value2 != null)
                                                {
                                                    valueCell = cellTTS.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.TTS = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.TTS = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQUSD.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                       strSheetName, clsMDConstant.QUOTATION_IMPORT_TTS, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.TTS = string.Empty;
                                                }
                                                #endregion

                                                #region get CSB 
                                                if (cellCSB.Value2 != null)
                                                {
                                                    valueCell = cellCSB.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.CSB = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.CSB = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQUSD.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                       strSheetName, clsMDConstant.QUOTATION_IMPORT_CSB, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.CSB = string.Empty;
                                                }
                                                #endregion

                                                #region get CSS
                                                if (cellCSS.Value2 != null)
                                                {
                                                    valueCell = cellCSS.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.CSS = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.CSS = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQUSD.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                       strSheetName, clsMDConstant.QUOTATION_IMPORT_CSS, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.CSS = string.Empty;
                                                }
                                                #endregion

                                                #region get TTB I/S RATE
                                                if (cellTTB_ISRATE.Value2 != null)
                                                {
                                                    valueCell = cellTTB_ISRATE.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.TTBRate = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.TTBRate = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQUSD.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                         strSheetName, clsMDConstant.QUOTATION_IMPORT_I_S_RATE, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.TTBRate = string.Empty;
                                                }
                                                #endregion

                                                #region get TTS I/S RATE
                                                if (cellTTS_ISRATE.Value2 != null)
                                                {
                                                    valueCell = cellTTS_ISRATE.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.TTSRate = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.TTSRate = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQUSD.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                strSheetName, clsMDConstant.QUOTATION_IMPORT_I_S_RATE, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.TTSRate = string.Empty;
                                                }
                                                #endregion
                                                if (!isCanNotImport)
                                                {
                                                    listQuotationDetail.Add(dtoDetail);
                                                }                              
                                            }
                                        }
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Read data of QuotationDetail VND from excel
        /// </summary>
        /// <param name="xlWorkSheet"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void ReadQuotationDetail2(Excel.Worksheet xlWorkSheet)
        {
            string strSheetName = xlWorkSheet.Name;
            int rowCount = xlWorkSheet.UsedRange.Rows.Count;
            int colCount = xlWorkSheet.UsedRange.Columns.Count;
            string valueCell = string.Empty;
            if (xlWorkSheet.UsedRange.Value2 != null)
            {
                double d;                
                for (int i = 1; i <= rowCount; i++)
                {
                    for (int j = 1; j <= colCount; j++)
                    {
                        Excel.Range cell = (Excel.Range)xlWorkSheet.Cells[i, j];
                        if (cell.Value2 != null)
                        {
                            valueCell = this.ToUpperString(cell.Text.ToString());
                            //TC
                            if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_TC)) == 0)
                            {
                                cell = (Excel.Range)xlWorkSheet.Cells[i, j + 1];
                                if (!ReadTC(cell, dtoCurQuotation, strSheetName, i))
                                {
                                    isStopProccess = true;
                                    return;
                                }
                                break;
                            }
                            #region read data
                            if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CCY)) == 0)
                            {
                                for (; i <= rowCount; i++)
                                {
                                    cell = (Excel.Range)xlWorkSheet.Cells[i, j];
                                    if (cell.Value2 != null)
                                    {
                                        int colCCY = 0, colTTM = 0, colBuyCCYSellVND = 0, colSellCCYBuyVND = 0, colBuyCCYSellVNDCash = 0, colSellCCYSellVNDCash = 0;
                                        int rowReadData = 0;
                                        //header CCY    TTM     TTB     TTS     CSB     CSS     TTB(I/S RATE)       TTS(I/S RATE)                                       
                                        #region read header table quotation detail
                                        for (; j <= colCount; j++)
                                        {
                                            cell = (Excel.Range)xlWorkSheet.Cells[i, j];
                                            if (cell.Value2 != null)
                                            {
                                                valueCell = this.ToUpperString(cell.Text.ToString());
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CCY)) == 0)
                                                {
                                                    colCCY = j;
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_TTM)) == 0)
                                                {
                                                    colTTM = j;
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_BUY_CCY_SELL_VND)) == 0)
                                                {
                                                    colBuyCCYSellVND = j;                                                    
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_SELL_CCY_BUY_VND)) == 0)
                                                {
                                                    colSellCCYBuyVND = j;                                                    
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_BUY_CCY_SELL_VND_CASH)) == 0)
                                                {
                                                    colBuyCCYSellVNDCash = j;                                                    
                                                }
                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_SELL_CCY_BUY_VND_CASH)) == 0)
                                                {
                                                    colSellCCYSellVNDCash = j;                                                    
                                                }                                                
                                            }
                                        }
                                        #endregion
                                        //                    
                                        if (colCCY != 0 && colTTM != 0 && colBuyCCYSellVND != 0 && colSellCCYBuyVND != 0 && colBuyCCYSellVNDCash != 0 && colSellCCYSellVNDCash != 0)
                                        {
                                            rowReadData = i + 1;
                                            for (; rowReadData <= rowCount; rowReadData++)
                                            {
                                                bool isCanNotImport = false;
                                                Excel.Range cellCCY = (Excel.Range)xlWorkSheet.Cells[rowReadData, colCCY];
                                                Excel.Range cellTTM = (Excel.Range)xlWorkSheet.Cells[rowReadData, colTTM];
                                                Excel.Range cellBuyCCYSellVND = (Excel.Range)xlWorkSheet.Cells[rowReadData, colBuyCCYSellVND];
                                                Excel.Range cellSellCCYBuyVND = (Excel.Range)xlWorkSheet.Cells[rowReadData, colSellCCYBuyVND];
                                                Excel.Range cellBuyCCYSellVNDCash = (Excel.Range)xlWorkSheet.Cells[rowReadData, colBuyCCYSellVNDCash];
                                                Excel.Range cellSellCCYSellVNDCash = (Excel.Range)xlWorkSheet.Cells[rowReadData, colSellCCYSellVNDCash];

                                                if (cellCCY.Value2 == null && cellTTM.Value2 == null && cellBuyCCYSellVND.Value2 == null && cellSellCCYBuyVND.Value2 == null &&
                                                                                                            cellBuyCCYSellVNDCash.Value2 == null && cellSellCCYSellVNDCash.Value2 == null)
                                                {
                                                    i = rowReadData;
                                                    break;
                                                }
                                                clsMDQuotationDetailDTO dtoDetail = new clsMDQuotationDetailDTO();
                                                if (!ReadQuotationDetailCCY(cellCCY, dtoDetail, strSheetName, rowReadData, clsMDConstant.VND))
                                                {
                                                    isStopProccess = true;
                                                    return;
                                                }

                                                #region get TTM
                                                if (cellTTM.Value2 != null)
                                                {
                                                    valueCell = cellTTM.Text.ToString().Trim();
                                                    dtoDetail.FormatNumber = cellTTM.NumberFormat.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.TTM = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.TTM = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            listCCYPairNotImportEQVND.Add(cellCCY.Text.ToString());
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                       strSheetName, clsMDConstant.QUOTATION_IMPORT_TTM, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.TTM = string.Empty;
                                                }
                                                #endregion

                                                #region get BuyCCYSellVND
                                                if (cellBuyCCYSellVND.Value2 != null)
                                                {
                                                    valueCell = cellBuyCCYSellVND.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.TTB = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.TTB = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQVND.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                      strSheetName, clsMDConstant.QUOTATION_IMPORT_BUY_CCY_SELL_VND, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.TTB = string.Empty;
                                                }
                                                #endregion

                                                #region get SellCCYBuyVND
                                                if (cellSellCCYBuyVND.Value2 != null)
                                                {
                                                    valueCell = cellSellCCYBuyVND.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.TTS = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.TTS = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQVND.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                       strSheetName, clsMDConstant.QUOTATION_IMPORT_SELL_CCY_BUY_VND, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.TTS = string.Empty;
                                                }
                                                #endregion

                                                #region get BuyCCYSellVNDCash
                                                if (cellBuyCCYSellVNDCash.Value2 != null)
                                                {
                                                    valueCell = cellBuyCCYSellVNDCash.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.CSB = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.CSB = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQVND.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                       strSheetName, clsMDConstant.QUOTATION_IMPORT_BUY_CCY_SELL_VND_CASH, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.CSB = string.Empty;
                                                }
                                                #endregion

                                                #region get SellCCYSellVNDCash
                                                if (cellSellCCYSellVNDCash.Value2 != null)
                                                {
                                                    valueCell = cellSellCCYSellVNDCash.Text.ToString().Trim();
                                                    if (string.IsNullOrEmpty(valueCell))
                                                    {
                                                        dtoDetail.CSS = string.Empty;
                                                    }
                                                    else if (double.TryParse(valueCell, out d))
                                                    {
                                                        dtoDetail.CSS = double.Parse(valueCell).ToString();
                                                    }
                                                    else
                                                    {
                                                        if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                        {
                                                            if (!isCanNotImport)
                                                            {
                                                                listCCYPairNotImportEQVND.Add(cellCCY.Text.ToString());
                                                            }
                                                            isCanNotImport = true;
                                                        }
                                                        else
                                                        {
                                                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                                       strSheetName, clsMDConstant.QUOTATION_IMPORT_SELL_CCY_BUY_VND_CASH, rowReadData));
                                                            isStopProccess = true;
                                                            return;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    dtoDetail.CSS = string.Empty;
                                                }
                                                #endregion

                                                #region get TTB I/S RATE
                                                dtoDetail.TTBRate = string.Empty;
                                                #endregion

                                                #region get TTS I/S RATE
                                                dtoDetail.TTSRate = string.Empty;
                                                #endregion
                                                if (!isCanNotImport)
                                                {
                                                    listQuotationDetail.Add(dtoDetail);
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Read Quotation EC Rate
        /// </summary>
        /// <param name="valueArray"></param>
        /// <param name="rowCount"></param>
        /// <param name="colCount"></param>
        /// <param name="currentRow"></param>
        /// <param name="currentCol"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void ReadQuotationECRate(Excel.Worksheet xlWorkSheet)
        {
            string strSheetName = xlWorkSheet.Name;
            int rowCount = xlWorkSheet.UsedRange.Rows.Count;
            int colCount = xlWorkSheet.UsedRange.Columns.Count;            
            string valueCell = string.Empty;
            double d;
            if (xlWorkSheet.UsedRange.Value2 != null)
            {
                for (int i = 1; i <= rowCount; i++)
                {
                    for (int j = 1; j <= colCount; j++)
                    {
                        Excel.Range cell = (Excel.Range)xlWorkSheet.Cells[i, j];
                        if (cell.Value2 != null)
                        {
                            valueCell = this.ToUpperString(cell.Text.ToString());
                            if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CROSS_FX)) == 0)
                            {
                                int colCrossFX = 0, colCustRateBuy = 0, colCustRateSell = 0, colAGroupECBuy = 0, colBGroupECBuy = 0, colAGroupECSell = 0, colBGroupECSell = 0;
                                int rowReadData = 0;
                                #region read header table
                                for (; j <= colCount; j++)
                                {
                                    cell = (Excel.Range)xlWorkSheet.Cells[i, j];
                                    if (cell.Value2 != null)
                                    {
                                        valueCell = this.ToUpperString(cell.Text.ToString());
                                        if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CROSS_FX)) == 0)
                                        {
                                            colCrossFX = j;
                                        }
                                        if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_BANK_BUYS_FC_vs_VND)) == 0)
                                        {
                                            int rowNext = i + 1;
                                            for (; j <= colCount; j++)
                                            {
                                                cell = (Excel.Range)xlWorkSheet.Cells[rowNext, j];
                                                if (cell.Value2 != null)
                                                {
                                                    valueCell = this.ToUpperString(cell.Text.ToString());
                                                    if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CUST_RATE)) == 0)
                                                    {
                                                        colCustRateBuy = j;
                                                    }
                                                    if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_A_GREEN_SREEN)) == 0)
                                                    {
                                                        colAGroupECBuy = j;
                                                    }
                                                    if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_B_GREEN_SREEN)) == 0)
                                                    {
                                                        colBGroupECBuy = j;
                                                    }
                                                    if (colAGroupECBuy > 0 && colBGroupECBuy > 0)
                                                    {
                                                        for (; rowNext < rowCount; rowNext++)
                                                        {
                                                            cell = (Excel.Range)xlWorkSheet.Cells[rowNext, j];
                                                            if (cell.Value2 != null)
                                                            {
                                                                valueCell = this.ToUpperString(cell.Text.ToString());
                                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_EC)) == 0)
                                                                {
                                                                    rowReadData = rowNext + 1;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_BANK_SELLS_FC_vs_VND)) == 0)
                                        {
                                            int rowNext = i + 1;
                                            for (; j <= colCount; j++)
                                            {
                                                cell = (Excel.Range)xlWorkSheet.Cells[rowNext, j];
                                                if (cell.Value2 != null)
                                                {
                                                    valueCell = this.ToUpperString(cell.Text.ToString());
                                                    if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_CUST_RATE)) == 0)
                                                    {
                                                        colCustRateSell = j;
                                                    }
                                                    if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_A_GREEN_SREEN)) == 0)
                                                    {
                                                        colAGroupECSell = j;
                                                    }
                                                    if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_B_GREEN_SREEN)) == 0)
                                                    {
                                                        colBGroupECSell = j;
                                                    }
                                                    if (colAGroupECSell > 0 && colBGroupECSell > 0)
                                                    {
                                                        for (; rowNext < rowCount; rowNext++)
                                                        {
                                                            cell = (Excel.Range)xlWorkSheet.Cells[rowNext, j];
                                                            if (cell.Value2 != null)
                                                            {
                                                                valueCell = this.ToUpperString(cell.Text.ToString());
                                                                if (valueCell.CompareTo(this.ToUpperString(clsMDConstant.QUOTATION_IMPORT_EC)) == 0)
                                                                {
                                                                    rowReadData = rowNext + 1;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                #endregion
                                if (colCrossFX != 0 && colCustRateBuy != 0 && colCustRateSell != 0 && colAGroupECBuy != 0 && colBGroupECBuy != 0 && colAGroupECSell != 0 && colBGroupECSell != 0)
                                {
                                    for (; rowReadData <= rowCount; rowReadData++)
                                    {
                                        bool isCanNotImport = false;

                                        #region get Quotation ECRate
                                        Excel.Range cellCrossFX = (Excel.Range)xlWorkSheet.Cells[rowReadData, colCrossFX];
                                        Excel.Range cellCustRateBuy = (Excel.Range)xlWorkSheet.Cells[rowReadData, colCustRateBuy];
                                        Excel.Range cellCustRateSell = (Excel.Range)xlWorkSheet.Cells[rowReadData, colCustRateSell];
                                        Excel.Range cellAGroupECBuy = (Excel.Range)xlWorkSheet.Cells[rowReadData, colAGroupECBuy];
                                        Excel.Range cellBGroupECBuy = (Excel.Range)xlWorkSheet.Cells[rowReadData, colBGroupECBuy];
                                        Excel.Range cellAGroupECSell = (Excel.Range)xlWorkSheet.Cells[rowReadData, colAGroupECSell];
                                        Excel.Range cellBGroupECSell = (Excel.Range)xlWorkSheet.Cells[rowReadData, colBGroupECSell];

                                        if (cellCrossFX.Value2 == null && cellCustRateBuy.Value2 == null && cellCustRateSell.Value2 == null && 
                                            cellAGroupECBuy.Value2 == null && cellBGroupECBuy.Value2 == null && cellAGroupECSell.Value2 == null 
                                            && cellBGroupECSell.Value2 == null)
                                        {
                                            i = rowReadData;
                                            break;
                                        }
                                        clsMDQuotationECRateDTO dto = new clsMDQuotationECRateDTO();
                                        
                                        #region get CrossFX
                                        if(!ReadQuotationECRateCCY(cellCrossFX, dto, strSheetName, rowReadData))
                                        {
                                            isStopProccess = true;
                                            return;
                                        }
                                        #endregion

                                        #region get CustRateBuy
                                        if (cellCustRateBuy.Value2 != null)
                                        {
                                            valueCell = cellCustRateBuy.Text.ToString().Trim();
                                            if (string.IsNullOrEmpty(valueCell))
                                            {
                                                dto.CustRateBuy = string.Empty;
                                            }
                                            else if (double.TryParse(valueCell, out d))
                                            {
                                                dto.CustRateBuy = valueCell;
                                            }
                                            else
                                            {
                                                if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                {
                                                    listCCYPairNotImportECRate.Add(cellCrossFX.Text.ToString());
                                                    isCanNotImport = true;
                                                }
                                                else
                                                {
                                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                               strSheetName, clsMDConstant.QUOTATION_IMPORT_CUST_RATE, rowReadData));
                                                    isStopProccess = true;
                                                    return;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            dto.CustRateBuy = string.Empty;
                                        }
                                        #endregion

                                        #region get CustRateSell
                                        if (cellCustRateSell.Value2 != null)
                                        {
                                            valueCell = cellCustRateSell.Text.ToString().Trim();
                                            if (string.IsNullOrEmpty(valueCell))
                                            {
                                                dto.CustRateSell = string.Empty;
                                            }
                                            else if (double.TryParse(valueCell, out d))
                                            {
                                                dto.CustRateSell = valueCell;
                                            }
                                            else
                                            {
                                                if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                {
                                                    if (!isCanNotImport)
                                                    {
                                                        listCCYPairNotImportECRate.Add(cellCrossFX.Text.ToString());
                                                    }
                                                    isCanNotImport = true;
                                                }
                                                else
                                                {
                                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                              strSheetName, clsMDConstant.QUOTATION_IMPORT_CUST_RATE, rowReadData));
                                                    isStopProccess = true;
                                                    return;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            dto.CustRateSell = string.Empty;
                                        }
                                        #endregion

                                        #region get AGroupECBuy
                                        if (cellAGroupECBuy.Value2 != null)
                                        {
                                            valueCell = cellAGroupECBuy.Text.ToString().Trim();
                                            if (string.IsNullOrEmpty(valueCell))
                                            {
                                                dto.AGroupECBuy = string.Empty;
                                            }
                                            else if (double.TryParse(valueCell, out d))
                                            {
                                                dto.AGroupECBuy = valueCell;
                                            }
                                            else
                                            {
                                                if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                {
                                                    if (!isCanNotImport)
                                                    {
                                                        listCCYPairNotImportECRate.Add(cellCrossFX.Text.ToString());
                                                    }
                                                    isCanNotImport = true;
                                                }
                                                else
                                                {
                                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                               strSheetName, clsMDConstant.QUOTATION_IMPORT_EC, rowReadData));
                                                    isStopProccess = true;
                                                    return;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            dto.AGroupECBuy = string.Empty;
                                        }
                                        #endregion

                                        #region get BGroupECBuy
                                        if (cellBGroupECBuy.Value2 != null)
                                        {
                                            valueCell = cellBGroupECBuy.Text.ToString().Trim();
                                            if (string.IsNullOrEmpty(valueCell))
                                            {
                                                dto.BGroupECBuy = string.Empty;
                                            }
                                            else if (double.TryParse(valueCell, out d))
                                            {
                                                dto.BGroupECBuy = valueCell;
                                            }
                                            else
                                            {
                                                if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                {
                                                    if (!isCanNotImport)
                                                    {
                                                        listCCYPairNotImportECRate.Add(cellCrossFX.Text.ToString());
                                                    }
                                                    isCanNotImport = true;
                                                }
                                                else
                                                {
                                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                               strSheetName, clsMDConstant.QUOTATION_IMPORT_EC, rowReadData));
                                                    isStopProccess = true;
                                                    return;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            dto.BGroupECBuy = string.Empty;
                                        }
                                        #endregion

                                        #region get AGroupECSell
                                        if (cellAGroupECSell.Value2 != null)
                                        {
                                            valueCell = cellAGroupECSell.Text.ToString().Trim();
                                            if (string.IsNullOrEmpty(valueCell))
                                            {
                                                dto.AGroupECSell = string.Empty;
                                            }
                                            else if (double.TryParse(valueCell, out d))
                                            {
                                                dto.AGroupECSell = valueCell;
                                            }
                                            else
                                            {
                                                if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                {
                                                    if (!isCanNotImport)
                                                    {
                                                        listCCYPairNotImportECRate.Add(cellCrossFX.Text.ToString());
                                                    }
                                                    isCanNotImport = true;
                                                }
                                                else
                                                {
                                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                              strSheetName, clsMDConstant.QUOTATION_IMPORT_EC, rowReadData));
                                                    isStopProccess = true;
                                                    return;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            dto.AGroupECSell = string.Empty;
                                        }
                                        #endregion

                                        #region get BGroupECSell
                                        if (cellBGroupECSell.Value2 != null)
                                        {
                                            valueCell = cellBGroupECSell.Text.ToString().Trim();
                                            if (string.IsNullOrEmpty(valueCell))
                                            {
                                                dto.BGroupECSell = string.Empty;
                                            }
                                            else if (double.TryParse(valueCell, out d))
                                            {
                                                dto.BGroupECSell = valueCell;
                                            }
                                            else
                                            {
                                                if (valueCell.ToUpper().CompareTo(strNotReadNumberValue) == 0)
                                                {
                                                    if (!isCanNotImport)
                                                    {
                                                        listCCYPairNotImportECRate.Add(cellCrossFX.Text.ToString());
                                                    }
                                                    isCanNotImport = true;
                                                }
                                                else
                                                {
                                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_IMPORT_QUOTATION_VALUE_IS_INVALID,
                                                                                                                               strSheetName, clsMDConstant.QUOTATION_IMPORT_EC, rowReadData));
                                                    isStopProccess = true;
                                                    return;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            dto.BGroupECSell = string.Empty;
                                        }
                                        #endregion
                                        if (!isCanNotImport)
                                        {
                                            listQUotationECRate.Add(dto);
                                        }
                                        #endregion
                                    }
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        //2013.05.27 UDP vlhcnhung E Format template Import Daily Quotation

        /// <summary>
        /// Define EventHandle after excute action import
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        public void ShowViewMakerOnAfterImported(object sender, EventArgs e)
        {
            frmMDProcessingDailyQuotation frm = new frmMDProcessingDailyQuotation((int)CommonValue.QuotationRole.Maker);
            frm.MdiParent = this.MdiParent;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }
        #endregion        
    }
}
