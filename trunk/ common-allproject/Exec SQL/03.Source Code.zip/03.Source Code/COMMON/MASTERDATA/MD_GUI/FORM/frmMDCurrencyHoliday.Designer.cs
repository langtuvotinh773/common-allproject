﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDCurrencyHoliday
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMDCurrencyHoliday));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblYear = new System.Windows.Forms.Label();
            this.cbbYear = new System.Windows.Forms.ComboBox();
            this.cbbCCY = new System.Windows.Forms.ComboBox();
            this.lblCCY = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.clrDec = new UserCtrl.ctrlHolidayCalendar();
            this.clrNov = new UserCtrl.ctrlHolidayCalendar();
            this.clrOct = new UserCtrl.ctrlHolidayCalendar();
            this.clrSep = new UserCtrl.ctrlHolidayCalendar();
            this.clrAug = new UserCtrl.ctrlHolidayCalendar();
            this.clrJul = new UserCtrl.ctrlHolidayCalendar();
            this.clrJun = new UserCtrl.ctrlHolidayCalendar();
            this.clrMay = new UserCtrl.ctrlHolidayCalendar();
            this.clrApr = new UserCtrl.ctrlHolidayCalendar();
            this.clrMar = new UserCtrl.ctrlHolidayCalendar();
            this.clrFeb = new UserCtrl.ctrlHolidayCalendar();
            this.clrJan = new UserCtrl.ctrlHolidayCalendar();
            this.lblRemarkDescription = new System.Windows.Forms.Label();
            this.lblRemark = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnExport);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.lblYear);
            this.groupBox1.Controls.Add(this.cbbYear);
            this.groupBox1.Controls.Add(this.cbbCCY);
            this.groupBox1.Controls.Add(this.lblCCY);
            this.groupBox1.Location = new System.Drawing.Point(4, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(862, 51);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnExport.Location = new System.Drawing.Point(408, 18);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 23);
            this.btnExport.TabIndex = 5;
            this.btnExport.Text = "&Export";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(324, 18);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(14, 24);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(29, 13);
            this.lblYear.TabIndex = 0;
            this.lblYear.Text = "Year";
            // 
            // cbbYear
            // 
            this.cbbYear.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbbYear.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbbYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbYear.FormattingEnabled = true;
            this.cbbYear.Location = new System.Drawing.Point(53, 19);
            this.cbbYear.MaxLength = 10;
            this.cbbYear.Name = "cbbYear";
            this.cbbYear.Size = new System.Drawing.Size(90, 21);
            this.cbbYear.TabIndex = 1;
            this.cbbYear.SelectedIndexChanged += new System.EventHandler(this.cbbYear_SelectedIndexChanged);
            this.cbbYear.SelectedValueChanged += new System.EventHandler(this.cbbYear_SelectedValueChanged);
            // 
            // cbbCCY
            // 
            this.cbbCCY.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbbCCY.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbbCCY.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbCCY.FormattingEnabled = true;
            this.cbbCCY.Location = new System.Drawing.Point(201, 19);
            this.cbbCCY.MaxLength = 3;
            this.cbbCCY.Name = "cbbCCY";
            this.cbbCCY.Size = new System.Drawing.Size(90, 21);
            this.cbbCCY.TabIndex = 3;
            this.cbbCCY.SelectedIndexChanged += new System.EventHandler(this.cbbCCY_SelectedIndexChanged);
            // 
            // lblCCY
            // 
            this.lblCCY.AutoSize = true;
            this.lblCCY.Location = new System.Drawing.Point(165, 23);
            this.lblCCY.Name = "lblCCY";
            this.lblCCY.Size = new System.Drawing.Size(28, 13);
            this.lblCCY.TabIndex = 2;
            this.lblCCY.Text = "CCY";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.btnClose);
            this.groupBox2.Controls.Add(this.clrDec);
            this.groupBox2.Controls.Add(this.clrNov);
            this.groupBox2.Controls.Add(this.clrOct);
            this.groupBox2.Controls.Add(this.clrSep);
            this.groupBox2.Controls.Add(this.clrAug);
            this.groupBox2.Controls.Add(this.clrJul);
            this.groupBox2.Controls.Add(this.clrJun);
            this.groupBox2.Controls.Add(this.clrMay);
            this.groupBox2.Controls.Add(this.clrApr);
            this.groupBox2.Controls.Add(this.clrMar);
            this.groupBox2.Controls.Add(this.clrFeb);
            this.groupBox2.Controls.Add(this.clrJan);
            this.groupBox2.Controls.Add(this.lblRemarkDescription);
            this.groupBox2.Controls.Add(this.lblRemark);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(4, 51);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(862, 603);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(777, 573);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.btnClose_PreviewKeyDown);
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // clrDec
            // 
            this.clrDec.AbbreviateWeekDayHeader = true;
            this.clrDec.BackColor = System.Drawing.SystemColors.Control;
            this.clrDec.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrDec.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrDec.Date = new System.DateTime(2013, 12, 1, 0, 0, 0, 0);
            this.clrDec.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrDec.DayFontColor = System.Drawing.Color.Black;
            this.clrDec.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrDec.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrDec.Location = new System.Drawing.Point(661, 406);
            this.clrDec.Month = 12;
            this.clrDec.Name = "clrDec";
            this.clrDec.SelectedDate = new System.DateTime(2013, 12, 1, 0, 0, 0, 0);
            this.clrDec.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrDec.SelectedDates")));
            this.clrDec.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrDec.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrDec.ShowGrid = true;
            this.clrDec.Size = new System.Drawing.Size(191, 160);
            this.clrDec.TabIndex = 24;
            this.clrDec.TabStop = false;
            this.clrDec.Year = 2013;
            this.clrDec.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrDec_LoadCurrencyHoliday);
            this.clrDec.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrDec_SelectedDateChanged);
            // 
            // clrNov
            // 
            this.clrNov.AbbreviateWeekDayHeader = true;
            this.clrNov.BackColor = System.Drawing.SystemColors.Control;
            this.clrNov.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrNov.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrNov.Date = new System.DateTime(2013, 11, 1, 0, 0, 0, 0);
            this.clrNov.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrNov.DayFontColor = System.Drawing.Color.Black;
            this.clrNov.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrNov.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrNov.Location = new System.Drawing.Point(443, 406);
            this.clrNov.Month = 11;
            this.clrNov.Name = "clrNov";
            this.clrNov.SelectedDate = new System.DateTime(2013, 11, 1, 0, 0, 0, 0);
            this.clrNov.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrNov.SelectedDates")));
            this.clrNov.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrNov.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrNov.ShowGrid = true;
            this.clrNov.Size = new System.Drawing.Size(191, 160);
            this.clrNov.TabIndex = 22;
            this.clrNov.TabStop = false;
            this.clrNov.Year = 2013;
            this.clrNov.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrNov_LoadCurrencyHoliday);
            this.clrNov.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrNov_SelectedDateChanged);
            // 
            // clrOct
            // 
            this.clrOct.AbbreviateWeekDayHeader = true;
            this.clrOct.BackColor = System.Drawing.SystemColors.Control;
            this.clrOct.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrOct.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrOct.Date = new System.DateTime(2013, 10, 1, 0, 0, 0, 0);
            this.clrOct.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrOct.DayFontColor = System.Drawing.Color.Black;
            this.clrOct.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrOct.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrOct.Location = new System.Drawing.Point(226, 406);
            this.clrOct.Month = 10;
            this.clrOct.Name = "clrOct";
            this.clrOct.SelectedDate = new System.DateTime(2013, 10, 1, 0, 0, 0, 0);
            this.clrOct.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrOct.SelectedDates")));
            this.clrOct.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrOct.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrOct.ShowGrid = true;
            this.clrOct.Size = new System.Drawing.Size(191, 160);
            this.clrOct.TabIndex = 20;
            this.clrOct.TabStop = false;
            this.clrOct.Year = 2013;
            this.clrOct.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrOct_LoadCurrencyHoliday);
            this.clrOct.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrOct_SelectedDateChanged);
            // 
            // clrSep
            // 
            this.clrSep.AbbreviateWeekDayHeader = true;
            this.clrSep.BackColor = System.Drawing.SystemColors.Control;
            this.clrSep.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrSep.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrSep.Date = new System.DateTime(2013, 9, 1, 0, 0, 0, 0);
            this.clrSep.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrSep.DayFontColor = System.Drawing.Color.Black;
            this.clrSep.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrSep.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrSep.Location = new System.Drawing.Point(10, 406);
            this.clrSep.Month = 9;
            this.clrSep.Name = "clrSep";
            this.clrSep.SelectedDate = new System.DateTime(2013, 9, 1, 0, 0, 0, 0);
            this.clrSep.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrSep.SelectedDates")));
            this.clrSep.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrSep.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrSep.ShowGrid = true;
            this.clrSep.Size = new System.Drawing.Size(191, 160);
            this.clrSep.TabIndex = 18;
            this.clrSep.TabStop = false;
            this.clrSep.Year = 2013;
            this.clrSep.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrSep_LoadCurrencyHoliday);
            this.clrSep.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrSep_SelectedDateChanged);
            // 
            // clrAug
            // 
            this.clrAug.AbbreviateWeekDayHeader = true;
            this.clrAug.BackColor = System.Drawing.SystemColors.Control;
            this.clrAug.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrAug.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrAug.Date = new System.DateTime(2013, 8, 1, 0, 0, 0, 0);
            this.clrAug.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrAug.DayFontColor = System.Drawing.Color.Black;
            this.clrAug.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrAug.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrAug.Location = new System.Drawing.Point(661, 218);
            this.clrAug.Month = 8;
            this.clrAug.Name = "clrAug";
            this.clrAug.SelectedDate = new System.DateTime(2013, 8, 1, 0, 0, 0, 0);
            this.clrAug.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrAug.SelectedDates")));
            this.clrAug.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrAug.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrAug.ShowGrid = true;
            this.clrAug.Size = new System.Drawing.Size(191, 160);
            this.clrAug.TabIndex = 16;
            this.clrAug.TabStop = false;
            this.clrAug.Year = 2013;
            this.clrAug.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrAug_LoadCurrencyHoliday);
            this.clrAug.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrAug_SelectedDateChanged);
            // 
            // clrJul
            // 
            this.clrJul.AbbreviateWeekDayHeader = true;
            this.clrJul.BackColor = System.Drawing.SystemColors.Control;
            this.clrJul.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrJul.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrJul.Date = new System.DateTime(2013, 7, 1, 0, 0, 0, 0);
            this.clrJul.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrJul.DayFontColor = System.Drawing.Color.Black;
            this.clrJul.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrJul.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrJul.Location = new System.Drawing.Point(443, 218);
            this.clrJul.Month = 7;
            this.clrJul.Name = "clrJul";
            this.clrJul.SelectedDate = new System.DateTime(2013, 7, 1, 0, 0, 0, 0);
            this.clrJul.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrJul.SelectedDates")));
            this.clrJul.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrJul.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrJul.ShowGrid = true;
            this.clrJul.Size = new System.Drawing.Size(191, 160);
            this.clrJul.TabIndex = 14;
            this.clrJul.TabStop = false;
            this.clrJul.Year = 2013;
            this.clrJul.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrJul_LoadCurrencyHoliday);
            this.clrJul.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrJul_SelectedDateChanged);
            // 
            // clrJun
            // 
            this.clrJun.AbbreviateWeekDayHeader = true;
            this.clrJun.BackColor = System.Drawing.SystemColors.Control;
            this.clrJun.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrJun.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrJun.Date = new System.DateTime(2013, 6, 1, 0, 0, 0, 0);
            this.clrJun.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrJun.DayFontColor = System.Drawing.Color.Black;
            this.clrJun.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrJun.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrJun.Location = new System.Drawing.Point(226, 218);
            this.clrJun.Month = 6;
            this.clrJun.Name = "clrJun";
            this.clrJun.SelectedDate = new System.DateTime(2013, 6, 1, 0, 0, 0, 0);
            this.clrJun.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrJun.SelectedDates")));
            this.clrJun.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrJun.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrJun.ShowGrid = true;
            this.clrJun.Size = new System.Drawing.Size(191, 160);
            this.clrJun.TabIndex = 12;
            this.clrJun.TabStop = false;
            this.clrJun.Year = 2013;
            this.clrJun.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrJun_LoadCurrencyHoliday);
            this.clrJun.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrJun_SelectedDateChanged);
            // 
            // clrMay
            // 
            this.clrMay.AbbreviateWeekDayHeader = true;
            this.clrMay.BackColor = System.Drawing.SystemColors.Control;
            this.clrMay.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrMay.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrMay.Date = new System.DateTime(2013, 5, 1, 0, 0, 0, 0);
            this.clrMay.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrMay.DayFontColor = System.Drawing.Color.Black;
            this.clrMay.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrMay.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrMay.Location = new System.Drawing.Point(10, 218);
            this.clrMay.Month = 5;
            this.clrMay.Name = "clrMay";
            this.clrMay.SelectedDate = new System.DateTime(2013, 5, 1, 0, 0, 0, 0);
            this.clrMay.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrMay.SelectedDates")));
            this.clrMay.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrMay.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrMay.ShowGrid = true;
            this.clrMay.Size = new System.Drawing.Size(191, 160);
            this.clrMay.TabIndex = 10;
            this.clrMay.TabStop = false;
            this.clrMay.Year = 2013;
            this.clrMay.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrMay_LoadCurrencyHoliday);
            this.clrMay.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrMay_SelectedDateChanged);
            // 
            // clrApr
            // 
            this.clrApr.AbbreviateWeekDayHeader = true;
            this.clrApr.BackColor = System.Drawing.SystemColors.Control;
            this.clrApr.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrApr.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrApr.Date = new System.DateTime(2013, 4, 1, 0, 0, 0, 0);
            this.clrApr.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrApr.DayFontColor = System.Drawing.Color.Black;
            this.clrApr.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrApr.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrApr.Location = new System.Drawing.Point(661, 32);
            this.clrApr.Month = 4;
            this.clrApr.Name = "clrApr";
            this.clrApr.SelectedDate = new System.DateTime(2013, 4, 1, 0, 0, 0, 0);
            this.clrApr.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrApr.SelectedDates")));
            this.clrApr.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrApr.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrApr.ShowGrid = true;
            this.clrApr.Size = new System.Drawing.Size(191, 160);
            this.clrApr.TabIndex = 8;
            this.clrApr.TabStop = false;
            this.clrApr.Year = 2013;
            this.clrApr.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrApr_LoadCurrencyHoliday);
            this.clrApr.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrApr_SelectedDateChanged);
            // 
            // clrMar
            // 
            this.clrMar.AbbreviateWeekDayHeader = true;
            this.clrMar.BackColor = System.Drawing.SystemColors.Control;
            this.clrMar.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrMar.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrMar.Date = new System.DateTime(2013, 3, 1, 0, 0, 0, 0);
            this.clrMar.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrMar.DayFontColor = System.Drawing.Color.Black;
            this.clrMar.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrMar.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrMar.Location = new System.Drawing.Point(443, 32);
            this.clrMar.Month = 3;
            this.clrMar.Name = "clrMar";
            this.clrMar.SelectedDate = new System.DateTime(2013, 3, 1, 0, 0, 0, 0);
            this.clrMar.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrMar.SelectedDates")));
            this.clrMar.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrMar.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrMar.ShowGrid = true;
            this.clrMar.Size = new System.Drawing.Size(191, 160);
            this.clrMar.TabIndex = 6;
            this.clrMar.TabStop = false;
            this.clrMar.Year = 2013;
            this.clrMar.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrMar_LoadCurrencyHoliday);
            this.clrMar.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrMar_SelectedDateChanged);
            // 
            // clrFeb
            // 
            this.clrFeb.AbbreviateWeekDayHeader = true;
            this.clrFeb.BackColor = System.Drawing.SystemColors.Control;
            this.clrFeb.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrFeb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrFeb.Date = new System.DateTime(2013, 2, 1, 0, 0, 0, 0);
            this.clrFeb.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrFeb.DayFontColor = System.Drawing.Color.Black;
            this.clrFeb.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrFeb.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrFeb.Location = new System.Drawing.Point(226, 32);
            this.clrFeb.Month = 2;
            this.clrFeb.Name = "clrFeb";
            this.clrFeb.SelectedDate = new System.DateTime(2013, 2, 1, 0, 0, 0, 0);
            this.clrFeb.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrFeb.SelectedDates")));
            this.clrFeb.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrFeb.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrFeb.ShowGrid = true;
            this.clrFeb.Size = new System.Drawing.Size(191, 160);
            this.clrFeb.TabIndex = 4;
            this.clrFeb.TabStop = false;
            this.clrFeb.Year = 2013;
            this.clrFeb.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrFeb_LoadCurrencyHoliday);
            this.clrFeb.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrFeb_SelectedDateChanged);
            // 
            // clrJan
            // 
            this.clrJan.AbbreviateWeekDayHeader = true;
            this.clrJan.BackColor = System.Drawing.SystemColors.Control;
            this.clrJan.BackgroundHolidayCalendar = System.Drawing.Color.White;
            this.clrJan.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(141)))), ((int)(((byte)(70)))));
            this.clrJan.Date = new System.DateTime(2013, 1, 1, 0, 0, 0, 0);
            this.clrJan.DayFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrJan.DayFontColor = System.Drawing.Color.Black;
            this.clrJan.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(213)))));
            this.clrJan.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.clrJan.Location = new System.Drawing.Point(10, 33);
            this.clrJan.Month = 1;
            this.clrJan.Name = "clrJan";
            this.clrJan.SelectedDate = new System.DateTime(2013, 1, 1, 0, 0, 0, 0);
            this.clrJan.SelectedDates = ((System.Collections.Generic.List<System.DateTime>)(resources.GetObject("clrJan.SelectedDates")));
            this.clrJan.SelectedDayBackground = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(140)))), ((int)(((byte)(250)))));
            this.clrJan.SelectedWeekendBackground = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(91)))), ((int)(((byte)(88)))));
            this.clrJan.ShowGrid = true;
            this.clrJan.Size = new System.Drawing.Size(191, 160);
            this.clrJan.TabIndex = 2;
            this.clrJan.TabStop = false;
            this.clrJan.Year = 2013;
            this.clrJan.LoadCurrencyHoliday += new UserCtrl.LoadCurrencyHolidayEventHandler(this.clrJan_LoadCurrencyHoliday);
            this.clrJan.SelectedDateChanged += new UserCtrl.SelectedDateChangedEventHandler(this.clrJan_SelectedDateChanged);
            // 
            // lblRemarkDescription
            // 
            this.lblRemarkDescription.AutoSize = true;
            this.lblRemarkDescription.Location = new System.Drawing.Point(64, 578);
            this.lblRemarkDescription.Name = "lblRemarkDescription";
            this.lblRemarkDescription.Size = new System.Drawing.Size(30, 13);
            this.lblRemarkDescription.TabIndex = 26;
            this.lblRemarkDescription.Text = "Note";
            // 
            // lblRemark
            // 
            this.lblRemark.AutoSize = true;
            this.lblRemark.Location = new System.Drawing.Point(10, 578);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(50, 13);
            this.lblRemark.TabIndex = 25;
            this.lblRemark.Text = "Remark :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(658, 390);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "December :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(660, 202);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "August :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(440, 390);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 21;
            this.label15.Text = "November :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(660, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "April :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(442, 202);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "July :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(225, 390);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 13);
            this.label14.TabIndex = 19;
            this.label14.Text = "October :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(440, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "March :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(225, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "June :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 390);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 13);
            this.label13.TabIndex = 17;
            this.label13.Text = "September :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(224, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "February :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 202);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "May :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "January :";
            // 
            // frmMDCurrencyHoliday
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(870, 662);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmMDCurrencyHoliday";
            this.Text = "Currency Holiday";
            this.Load += new System.EventHandler(this.frmMDCurrencyHoliday_Load);
            this.Shown += new System.EventHandler(this.frmMDCurrencyHoliday_Shown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDCurrencyHoliday_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.ComboBox cbbYear;
        private System.Windows.Forms.ComboBox cbbCCY;
        private System.Windows.Forms.Label lblCCY;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblRemarkDescription;
        private System.Windows.Forms.Label lblRemark;
        private UserCtrl.ctrlHolidayCalendar clrJan;
        private UserCtrl.ctrlHolidayCalendar clrDec;
        private UserCtrl.ctrlHolidayCalendar clrNov;
        private UserCtrl.ctrlHolidayCalendar clrOct;
        private UserCtrl.ctrlHolidayCalendar clrSep;
        private UserCtrl.ctrlHolidayCalendar clrAug;
        private UserCtrl.ctrlHolidayCalendar clrJul;
        private UserCtrl.ctrlHolidayCalendar clrJun;
        private UserCtrl.ctrlHolidayCalendar clrMay;
        private UserCtrl.ctrlHolidayCalendar clrApr;
        private UserCtrl.ctrlHolidayCalendar clrMar;
        private UserCtrl.ctrlHolidayCalendar clrFeb;
        private System.Windows.Forms.Button btnClose;
    }
}