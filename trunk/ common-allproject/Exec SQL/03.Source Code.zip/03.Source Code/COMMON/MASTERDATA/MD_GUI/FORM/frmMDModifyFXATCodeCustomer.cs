﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-16 (Thu, 16 May 2013) $
 * ========================================================
 * This class is used to create or modify a customer
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;
using System.Text.RegularExpressions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDModifyFXATCodeCustomer : frmMDMaster
    {
        #region Global Variable
        public clsMDCustomerDTO m_UpdatingCus;
        public event EventHandler OnSaved;
        public CommonValue.ActionType m_CurrentAction;
        bool m_ForceClose = false;
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        //Pivate member
        private string m_CustomerCode = "";
        private string m_FullName = "";
        private string m_ShortName = "";
        private string m_FXATCode = "";
        private string m_LocationCode = "";

        private int m_CustomerType = 0;

        private int MAX_LENGTH_FXATCODE = 4;
        private int MAX_LENGTH_LOCATION = 3;
        #endregion

        #region Constructor

        public frmMDModifyFXATCodeCustomer()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initializes a new instance of the frmMDModifySpecialCustomer class.
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public frmMDModifyFXATCodeCustomer(string title)
        {
            InitializeComponent();

            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);

            this.Text = title;
            m_UpdatingCus = new clsMDCustomerDTO();
            m_CurrentAction = CommonValue.ActionType.New; //default

            // Disable all textbox
            txtCustCode.ReadOnly = true;
            txtFullName.ReadOnly = true;
            txtShortName.ReadOnly = true;
            cbbLocation.DropDownStyle = ComboBoxStyle.DropDown;

            //Set limit text for control
            txtFXATCode.MaxLength = MAX_LENGTH_FXATCODE;
            cbbLocation.MaxLength = MAX_LENGTH_LOCATION;
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Event click button "Save"
        /// System will update information customer into DB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            //disable all button
            EnableControl(false);
            try
            {
                string strFXATCode = txtFXATCode.Text.Trim();        
                if (CheckExistFXATCode(strFXATCode))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_EXIST_FXATCODE));
                    EnableControl(true);
                }
                else
                {
                    //update information of customer to db
                    if (SaveModifyAction() > 0)
                    {
                        this.m_ForceClose = true;
                        if (OnSaved != null)
                        {
                            OnSaved(sender, e);
                        }
                        this.Close();
                    }
                }                
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //Enable control
            EnableControl(true);
        }

        /// <summary>
        /// Event click button "Cancel"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        /// <summary>
        /// Event KeyPress
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void cbbLocation_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                clsCommonClass.AutoComplete(cbbLocation, e);
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Form Close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void frmMDModifySpecialCustomer_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                try
                {
                    if (!m_ForceClose)
                    {
                        //if data was changed on screen, display confirm message to save changed data
                        if (IsDataChanged())
                        {
                            //display message 'Do you want to save changes of data?'
                            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                            if (res == DialogResult.Yes)
                            {
                                //update information of dept
                                if (SaveAModifiedCus() > 0)
                                {
                                    this.m_ForceClose = true;
                                    if (OnSaved != null)
                                    {
                                        OnSaved(sender, e);
                                    }
                                    this.Close();
                                }
                                else//if save unsuccessfull, display error message and not close form
                                {
                                    e.Cancel = true;
                                }
                            }
                            else if (res == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.m_ForceClose = true;
                    //show error message
                    clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                    //save log exception
                    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                }
            }
        }

        /// <summary>
        /// Event click on "Generate"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            String strFXATGenerate = "";
            strFXATGenerate = FindFXATCode(txtFullName.Text.Trim());
            if (strFXATGenerate.CompareTo("No result!") == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_FXATCODE_NOT_FOUND));
            }
            else
            {
                txtFXATCode.Text = strFXATGenerate;
            }
        }
        #endregion

        #region Member method
        /// <summary>
        /// load data to form
        /// </summary>
        /// <param name="obj">Customer object</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void SetData(clsMDCustomerDTO obj)
        {       
            // Set data for Customer Code
            m_CustomerCode = obj.CustomerCode;
            txtCustCode.Text = m_CustomerCode;

            // Set data for Customer Code
            m_FullName = obj.FullName;
            txtFullName.Text = m_FullName;

            // Set data for Customer Code
            m_ShortName = obj.ShortName;
            txtShortName.Text = m_ShortName;

            // Set data for FXAT Code
            m_FXATCode = obj.FXATCode;
            txtFXATCode.Text = m_FXATCode;


            m_LocationCode= obj.Location;
            LoadLocationCode(cbbLocation);
            if (cbbLocation.Items.Count == 0)
            {
                List<CbbObject> lstLocaCode = clsMDCustomerBUS.Instance().GetLocationCodeList();
                cbbLocation.DataSource = lstLocaCode;
                cbbLocation.DisplayMember = clsMDConstant.DISPLAY;
                cbbLocation.ValueMember = clsMDConstant.VALUE;
            }
            cbbLocation.SelectedIndex = cbbLocation.FindString(m_LocationCode);       
        }

        /// <summary>
        /// Save for action Modify Customer
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private int SaveModifyAction()
        {
            //display confirm message 'Are you sure to save customer?'
            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "customer"));
            if (res == DialogResult.Yes)
            {
                    return SaveAModifiedCus(); 
            }
            else if (res == DialogResult.No)
            {
                this.m_ForceClose = true;
                this.Close();
            }
            return 0;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        private bool IsDataChanged()
        {
            if (this.m_UpdatingCus.FXATCode != txtFXATCode.Text.Trim() || this.m_UpdatingCus.Location != cbbLocation.Text.Trim())
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Save a modify customer
        /// </summary>
        /// <returns></returns>
        private int SaveAModifiedCus()
        {
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //Update customer and Write data to log

            m_UpdatingCus = GetCustomerInfoFromControls();
            string strLocationCode = cbbLocation.Text.Trim();
            string strLocationName = "";
            if (!CheckExistLocationCode(strLocationCode))
            {
                SaveLocation(strLocationCode, strLocationName);
            }
            int iRow = clsMDCustomerBUS.Instance().UpdateCustomer(m_UpdatingCus, clsMDConstant.FXAT_CODE_CUSTOMER, logBase);
            // If Update OK
            if (iRow > 0 )
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Modifying", "customer"));
            }
            else if (iRow == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Modifying", "customer"));
            }
            else
            {
                this.Close();
            }
            return iRow;
        }

        /// <summary>
        /// Get customer information to modify
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private clsMDCustomerDTO GetCustomerInfoFromControls()
        {
            clsMDCustomerDTO dto = new clsMDCustomerDTO();
            dto.CustomerCode = m_UpdatingCus.CustomerCode;
            dto.FullName = m_UpdatingCus.FullName;
            dto.ShortName = m_UpdatingCus.ShortName;
            dto.FXATCode = txtFXATCode.Text.Trim();
            dto.Location = cbbLocation.Text.Trim();
           
            return dto;
        }

        /// <summary>
        /// Enable or disable button action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void EnableControl(bool value)
        {
            btnSave.Enabled = value;
            btnCancel.Enabled = value;
        }

        /// <summary>
        /// Check exist FXAT Code
        /// </summary>
        /// <returns>
        /// if exist return true
        /// else return false
        /// </returns>
        private bool CheckExistFXATCode(string strFXATCode)
        {
            DataTable dtbFXATCode = clsMDCustomerBUS.Instance().CheckExistFXATCode(strFXATCode);
            if (dtbFXATCode.Rows.Count == 0)
            {
                return false;
            }
            else
            {
                if (m_FXATCode.CompareTo(dtbFXATCode.Rows[0][clsMDConstant.MD_COL_FXATCODE].ToString())==0)
                {
                    return false;
                }
                return true;
            }
        }

        /// <summary>
        /// Check exist Location Code
        /// </summary>
        /// <returns>
        /// if exist return true
        /// else return false
        /// </returns>
        private bool CheckExistLocationCode(string strLocationCode)
        {
            DataTable dtbLocationCode = clsMDCustomerBUS.Instance().CheckExistLocationCode(strLocationCode);
            if (dtbLocationCode.Rows.Count == 0)
                return false;
            return true;
        }

        /// <summary>
        /// Check exist Location Code
        /// </summary>
        /// <returns>
        /// if exist return true
        /// else return false
        /// </returns>
        private void SaveLocation(string strLocationCode, string strLocationName)
        {
            clsMDCustomerBUS.Instance().SaveLocation(strLocationCode, strLocationName);
        }

        /// <summary>
        /// Get FXAT Code List by name
        /// </summary>
        /// <param name="strname"</param>
        /// <returns>   
        /// </returns>
        private List<String> GetFXATCodeByName(string strname)
        {
            return clsMDCustomerBUS.Instance().GetListFXATCodeByName(strname);            
        }

        /// <summary>
        /// Get FXAT Code List by name
        /// </summary>
        /// <param name="strname"</param>
        /// <returns>   
        /// </returns>
        private String FindFXATCode(string strname)
        {
            strname = strname.ToUpper();

            string[] arrLetters = Regex.Split(strname, " ");

            string letters = String.Empty;
            if (arrLetters.Count() >= 4)
            {
                for (int i = 0; i < arrLetters[0].Length; i++)
                {
                    letters += arrLetters[0].Substring(i, 1);
                    for (int j = 0; j < arrLetters[1].Length; j++)
                    {
                        letters += arrLetters[1].Substring(j, 1);
                        for (int m = 0; m < arrLetters[2].Length; m++)
                        {
                            letters += arrLetters[2].Substring(m, 1);
                            List<String> lstName = clsMDCustomerBUS.Instance().GetListFXATCodeByName(letters);
                            for (int n = 0; n < arrLetters[3].Length; n++)
                            {
                                letters += arrLetters[3].Substring(n, 1);
                                if (letters.Length == 4)
                                {
                                    if (!lstName.Contains(letters))
                                    {
                                        return letters;
                                    }
                                }
                                letters = letters.Substring(0, 3);
                            }
                            letters = letters.Substring(0, 2);
                        }
                        letters = letters.Substring(0, 1);
                    }
                    letters = String.Empty;
                }
                //In case run out of FXAT Code
                for (int i = 0; i < 1000; i++)
                {
                    letters = arrLetters[0].Substring(0, 1);
                    String tmp = i.ToString();
                    while (tmp.Length < 3)
                    {
                        tmp = "0" + tmp;
                    }
                    letters += tmp;
                    List<String> lstName = clsMDCustomerBUS.Instance().GetListFXATCodeByName(letters);
                    if (!lstName.Contains(letters))
                    {
                        return letters;
                    }
                }  
            }
            else if (arrLetters.Count() >= 3)
            {
                for (int i = 0; i < arrLetters[0].Length; i++)
                {
                    letters += arrLetters[0].Substring(i, 1);
                    for (int j = 0; j < arrLetters[1].Length; j++)
                    {
                        letters += arrLetters[1].Substring(j, 1);
                        letters += arrLetters[2].Substring(0, 1);
                        List<String> lstName = clsMDCustomerBUS.Instance().GetListFXATCodeByName(letters);
                        for (int n = 1; n < arrLetters[2].Length; n++)
                        {
                            letters += arrLetters[2].Substring(n, 1);
                            if (letters.Length == 4)
                            {
                                if (!lstName.Contains(letters))
                                {
                                    return letters;
                                }
                            }
                            letters = letters.Substring(0, 3);
                        }
                        letters = letters.Substring(0, 1);
                    }
                    letters = String.Empty;
                }
                //In case run out of FXAT Code
                for (int i = 0; i < 1000; i++)
                {
                    letters = arrLetters[0].Substring(0, 1);
                    String tmp = i.ToString();
                    while (tmp.Length < 3)
                    {
                        tmp = "0" + tmp;
                    }
                    letters += tmp;
                    List<String> lstName = clsMDCustomerBUS.Instance().GetListFXATCodeByName(letters);
                    if (!lstName.Contains(letters))
                    {
                        return letters;
                    }
                }  
            }
            else if (arrLetters.Count() >= 2)
            {
                for (int i = 0; i < arrLetters[0].Length; i++)
                {
                    letters += arrLetters[0].Substring(i, 1);
                    letters += arrLetters[1].Substring(0, 1);
                    for (int n = 2; n < arrLetters[1].Length; n++)
                    {
                        letters += arrLetters[1].Substring(1, 1);
                        List<String> lstName = clsMDCustomerBUS.Instance().GetListFXATCodeByName(letters);
                        letters += arrLetters[1].Substring(n, 1);

                        if (letters.Length == 4)
                        {
                            if (!lstName.Contains(letters))
                            {
                                return letters;
                            }
                        }
                        letters = letters.Substring(0, 2);
                    }
                    letters = String.Empty;
                }
                //In case run out of FXAT Code
                for (int i = 0; i < 1000; i++)
                {
                    letters = arrLetters[0].Substring(0, 1);
                    String tmp = i.ToString();
                    while (tmp.Length < 3)
                    {
                        tmp = "0" + tmp;
                    }
                    letters += tmp;
                    List<String> lstName = clsMDCustomerBUS.Instance().GetListFXATCodeByName(letters);
                    if (!lstName.Contains(letters))
                    {
                        return letters;
                    }
                }  
            }
            else if (arrLetters.Count() >= 1)
            {
                for (int i = 0; i < arrLetters[0].Length; i++)
                {
                    letters += arrLetters[0].Substring(i, 1);
                    letters += arrLetters[0].Substring(i+1, 1);
                    letters += arrLetters[0].Substring(i+2, 1);
                    for (int n = i+3 ; n < arrLetters[0].Length; n++) 
                    {                        
                        List<String> lstName = clsMDCustomerBUS.Instance().GetListFXATCodeByName(letters);
                        letters += arrLetters[0].Substring(n, 1);
                        if (letters.Length == 4)
                        {
                            if (!lstName.Contains(letters))
                            {
                                return letters;
                            }
                        }
                        letters = letters.Substring(0, 3);
                    }
                    letters = String.Empty;
                }
                //In case run out of FXAT Code
                for (int i = 0; i < 1000; i++)
                {
                    letters = arrLetters[0].Substring(0, 1);
                    String tmp = i.ToString();
                    while (tmp.Length < 3)
                    {
                        tmp = "0" + tmp;
                    }
                    letters += tmp;
                    List<String> lstName = clsMDCustomerBUS.Instance().GetListFXATCodeByName(letters);
                    if (!lstName.Contains(letters))
                    {
                        return letters;
                    }
                }  
            }
            return "No result!";
        }

        /// <summary>
        /// Create data FXAT customer to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private clsMDLogBase CreateDataSaveLog()
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = txtCustCode.Text.Trim(); //main key is customer code
            logBase.Action = (int)CommonValue.ActionType.Update;

            clsMDLogInformation logInfo = new clsMDLogInformation();

            //FXAT Code
            logInfo.FieldName = clsMDConstant.MD_COL_FXATCODE;
            logInfo.OldValue = this.m_UpdatingCus.FXATCode;
            logInfo.NewValue = txtFXATCode.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);

            //Location Code
            logInfo.FieldName = clsMDConstant.MD_COL_LOCATION;
            logInfo.OldValue = this.m_UpdatingCus.Location;
            logInfo.NewValue = cbbLocation.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            return logBase;
        }
        #endregion      


    }
}
