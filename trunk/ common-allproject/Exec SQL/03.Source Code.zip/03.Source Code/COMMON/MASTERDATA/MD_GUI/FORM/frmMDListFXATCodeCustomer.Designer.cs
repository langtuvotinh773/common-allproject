﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDListFXATCodeCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnModify = new System.Windows.Forms.Button();
            this.colLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFXATCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCustomerType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colShortName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtgCustomer = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cbbCustomerType = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbbLocation = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbbFXATCode = new System.Windows.Forms.ComboBox();
            this.cbbCustomerCode = new System.Windows.Forms.ComboBox();
            this.cbbCustomerName = new System.Windows.Forms.ComboBox();
            this.grbFXATCode = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCustomer)).BeginInit();
            this.grbFXATCode.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnModify
            // 
            this.btnModify.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModify.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnModify.Location = new System.Drawing.Point(563, 468);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(75, 23);
            this.btnModify.TabIndex = 16;
            this.btnModify.Text = "Modify";
            this.btnModify.UseVisualStyleBackColor = false;
            this.btnModify.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // colLocation
            // 
            this.colLocation.HeaderText = "Location";
            this.colLocation.Name = "colLocation";
            this.colLocation.ReadOnly = true;
            // 
            // colFXATCode
            // 
            this.colFXATCode.HeaderText = "FXAT Code";
            this.colFXATCode.Name = "colFXATCode";
            this.colFXATCode.ReadOnly = true;
            // 
            // colCustomerType
            // 
            this.colCustomerType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCustomerType.DataPropertyName = "CustType";
            this.colCustomerType.HeaderText = "Customer Type";
            this.colCustomerType.Name = "colCustomerType";
            this.colCustomerType.ReadOnly = true;
            // 
            // colShortName
            // 
            this.colShortName.HeaderText = "Customer Short Name";
            this.colShortName.Name = "colShortName";
            this.colShortName.ReadOnly = true;
            this.colShortName.Width = 140;
            // 
            // colFullName
            // 
            this.colFullName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colFullName.DataPropertyName = "Name";
            this.colFullName.HeaderText = "Customer Full Name";
            this.colFullName.Name = "colFullName";
            this.colFullName.ReadOnly = true;
            // 
            // colCustomerCode
            // 
            this.colCustomerCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCustomerCode.DataPropertyName = "Code";
            this.colCustomerCode.HeaderText = "Customer Code";
            this.colCustomerCode.Name = "colCustomerCode";
            this.colCustomerCode.ReadOnly = true;
            // 
            // dtgCustomer
            // 
            this.dtgCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCustomerCode,
            this.colFullName,
            this.colShortName,
            this.colCustomerType,
            this.colFXATCode,
            this.colLocation});
            this.dtgCustomer.Location = new System.Drawing.Point(8, 104);
            this.dtgCustomer.Name = "dtgCustomer";
            this.dtgCustomer.ReadOnly = true;
            this.dtgCustomer.RowHeadersVisible = false;
            this.dtgCustomer.Size = new System.Drawing.Size(719, 349);
            this.dtgCustomer.TabIndex = 15;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(653, 468);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 18;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Customer Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Code";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(480, 66);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Customer Type";
            // 
            // cbbCustomerType
            // 
            this.cbbCustomerType.FormattingEnabled = true;
            this.cbbCustomerType.Location = new System.Drawing.Point(111, 67);
            this.cbbCustomerType.Name = "cbbCustomerType";
            this.cbbCustomerType.Size = new System.Drawing.Size(110, 21);
            this.cbbCustomerType.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(262, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Location";
            // 
            // cbbLocation
            // 
            this.cbbLocation.FormattingEnabled = true;
            this.cbbLocation.Location = new System.Drawing.Point(342, 67);
            this.cbbLocation.Name = "cbbLocation";
            this.cbbLocation.Size = new System.Drawing.Size(110, 21);
            this.cbbLocation.TabIndex = 6;
            this.cbbLocation.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbbLocation_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(262, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "FXAT Code";
            // 
            // cbbFXATCode
            // 
            this.cbbFXATCode.FormattingEnabled = true;
            this.cbbFXATCode.Location = new System.Drawing.Point(342, 41);
            this.cbbFXATCode.Name = "cbbFXATCode";
            this.cbbFXATCode.Size = new System.Drawing.Size(110, 21);
            this.cbbFXATCode.TabIndex = 6;
            this.cbbFXATCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbbFXATCode_KeyPress);
            // 
            // cbbCustomerCode
            // 
            this.cbbCustomerCode.AllowDrop = true;
            this.cbbCustomerCode.FormattingEnabled = true;
            this.cbbCustomerCode.Location = new System.Drawing.Point(111, 40);
            this.cbbCustomerCode.Name = "cbbCustomerCode";
            this.cbbCustomerCode.Size = new System.Drawing.Size(110, 21);
            this.cbbCustomerCode.TabIndex = 6;
            this.cbbCustomerCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbbCustomerCode_KeyPress);
            this.cbbCustomerCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbbCustomerCode_KeyDown);
            // 
            // cbbCustomerName
            // 
            this.cbbCustomerName.FormattingEnabled = true;
            this.cbbCustomerName.Location = new System.Drawing.Point(111, 13);
            this.cbbCustomerName.Name = "cbbCustomerName";
            this.cbbCustomerName.Size = new System.Drawing.Size(341, 21);
            this.cbbCustomerName.TabIndex = 6;
            this.cbbCustomerName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbbCustomerName_KeyPress);
            this.cbbCustomerName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbbCustomerName_KeyDown);
            // 
            // grbFXATCode
            // 
            this.grbFXATCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbFXATCode.Controls.Add(this.cbbCustomerName);
            this.grbFXATCode.Controls.Add(this.cbbCustomerCode);
            this.grbFXATCode.Controls.Add(this.cbbFXATCode);
            this.grbFXATCode.Controls.Add(this.label4);
            this.grbFXATCode.Controls.Add(this.cbbLocation);
            this.grbFXATCode.Controls.Add(this.label5);
            this.grbFXATCode.Controls.Add(this.cbbCustomerType);
            this.grbFXATCode.Controls.Add(this.label3);
            this.grbFXATCode.Controls.Add(this.btnSearch);
            this.grbFXATCode.Controls.Add(this.label1);
            this.grbFXATCode.Controls.Add(this.label2);
            this.grbFXATCode.Location = new System.Drawing.Point(8, 2);
            this.grbFXATCode.Name = "grbFXATCode";
            this.grbFXATCode.Size = new System.Drawing.Size(719, 98);
            this.grbFXATCode.TabIndex = 17;
            this.grbFXATCode.TabStop = false;
            // 
            // frmMDListFXATCodeCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 504);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grbFXATCode);
            this.Controls.Add(this.dtgCustomer);
            this.Controls.Add(this.btnModify);
            this.Name = "frmMDListFXATCodeCustomer";
            this.Text = "FXAT Code Customer List";
            this.Load += new System.EventHandler(this.frmMDFListFXATCodeCustomer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgCustomer)).EndInit();
            this.grbFXATCode.ResumeLayout(false);
            this.grbFXATCode.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFXATCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colShortName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFullName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerCode;
        private System.Windows.Forms.DataGridView dtgCustomer;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbbCustomerType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbbLocation;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbbFXATCode;
        private System.Windows.Forms.ComboBox cbbCustomerCode;
        private System.Windows.Forms.ComboBox cbbCustomerName;
        private System.Windows.Forms.GroupBox grbFXATCode;

    }
}