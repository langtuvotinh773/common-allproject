﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDUserAddModify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listViewRight = new System.Windows.Forms.ListView();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.listViewLeft = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.btnDoubleLeft = new System.Windows.Forms.Button();
            this.btnSingleLeft = new System.Windows.Forms.Button();
            this.btnSingleRight = new System.Windows.Forms.Button();
            this.btnDoubleRight = new System.Windows.Forms.Button();
            this.ckbLockout = new System.Windows.Forms.CheckBox();
            this.ckbStaff02 = new System.Windows.Forms.CheckBox();
            this.ckbStaff01 = new System.Windows.Forms.CheckBox();
            this.ckbOfficer = new System.Windows.Forms.CheckBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnResetPass = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblRemark = new System.Windows.Forms.Label();
            this.txtShortName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblShortName = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.txtRemark = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // listViewRight
            // 
            this.listViewRight.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2});
            this.listViewRight.FullRowSelect = true;
            this.listViewRight.Location = new System.Drawing.Point(318, 194);
            this.listViewRight.Name = "listViewRight";
            this.listViewRight.Size = new System.Drawing.Size(225, 141);
            this.listViewRight.TabIndex = 20;
            this.listViewRight.UseCompatibleStateImageBehavior = false;
            this.listViewRight.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Assign Departments";
            this.columnHeader2.Width = 221;
            // 
            // listViewLeft
            // 
            this.listViewLeft.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.listViewLeft.FullRowSelect = true;
            this.listViewLeft.Location = new System.Drawing.Point(42, 194);
            this.listViewLeft.Name = "listViewLeft";
            this.listViewLeft.Size = new System.Drawing.Size(225, 141);
            this.listViewLeft.TabIndex = 15;
            this.listViewLeft.UseCompatibleStateImageBehavior = false;
            this.listViewLeft.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Unassign Departments";
            this.columnHeader1.Width = 220;
            // 
            // btnDoubleLeft
            // 
            this.btnDoubleLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDoubleLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoubleLeft.ForeColor = System.Drawing.Color.Blue;
            this.btnDoubleLeft.Location = new System.Drawing.Point(278, 301);
            this.btnDoubleLeft.Name = "btnDoubleLeft";
            this.btnDoubleLeft.Size = new System.Drawing.Size(30, 23);
            this.btnDoubleLeft.TabIndex = 19;
            this.btnDoubleLeft.Text = "<<";
            this.btnDoubleLeft.UseVisualStyleBackColor = false;
            this.btnDoubleLeft.Click += new System.EventHandler(this.btnDoubleLeft_Click);
            // 
            // btnSingleLeft
            // 
            this.btnSingleLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSingleLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingleLeft.ForeColor = System.Drawing.Color.Red;
            this.btnSingleLeft.Location = new System.Drawing.Point(278, 268);
            this.btnSingleLeft.Name = "btnSingleLeft";
            this.btnSingleLeft.Size = new System.Drawing.Size(30, 23);
            this.btnSingleLeft.TabIndex = 18;
            this.btnSingleLeft.Text = "<";
            this.btnSingleLeft.UseVisualStyleBackColor = false;
            this.btnSingleLeft.Click += new System.EventHandler(this.btnSingleLeft_Click);
            // 
            // btnSingleRight
            // 
            this.btnSingleRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSingleRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingleRight.ForeColor = System.Drawing.Color.Red;
            this.btnSingleRight.Location = new System.Drawing.Point(278, 236);
            this.btnSingleRight.Name = "btnSingleRight";
            this.btnSingleRight.Size = new System.Drawing.Size(30, 23);
            this.btnSingleRight.TabIndex = 17;
            this.btnSingleRight.Text = ">";
            this.btnSingleRight.UseVisualStyleBackColor = false;
            this.btnSingleRight.Click += new System.EventHandler(this.btnSingleRight_Click);
            // 
            // btnDoubleRight
            // 
            this.btnDoubleRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDoubleRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoubleRight.ForeColor = System.Drawing.Color.Blue;
            this.btnDoubleRight.Location = new System.Drawing.Point(278, 203);
            this.btnDoubleRight.Name = "btnDoubleRight";
            this.btnDoubleRight.Size = new System.Drawing.Size(30, 23);
            this.btnDoubleRight.TabIndex = 16;
            this.btnDoubleRight.Text = ">>";
            this.btnDoubleRight.UseVisualStyleBackColor = false;
            this.btnDoubleRight.Click += new System.EventHandler(this.btnDoubleRight_Click);
            // 
            // ckbLockout
            // 
            this.ckbLockout.AutoSize = true;
            this.ckbLockout.Location = new System.Drawing.Point(484, 51);
            this.ckbLockout.Name = "ckbLockout";
            this.ckbLockout.Size = new System.Drawing.Size(65, 17);
            this.ckbLockout.TabIndex = 11;
            this.ckbLockout.Text = "Lockout";
            this.ckbLockout.UseVisualStyleBackColor = true;
            // 
            // ckbStaff02
            // 
            this.ckbStaff02.AutoSize = true;
            this.ckbStaff02.Location = new System.Drawing.Point(415, 51);
            this.ckbStaff02.Name = "ckbStaff02";
            this.ckbStaff02.Size = new System.Drawing.Size(63, 17);
            this.ckbStaff02.TabIndex = 10;
            this.ckbStaff02.Text = "Staff 02";
            this.ckbStaff02.UseVisualStyleBackColor = true;
            // 
            // ckbStaff01
            // 
            this.ckbStaff01.AutoSize = true;
            this.ckbStaff01.Location = new System.Drawing.Point(348, 51);
            this.ckbStaff01.Name = "ckbStaff01";
            this.ckbStaff01.Size = new System.Drawing.Size(63, 17);
            this.ckbStaff01.TabIndex = 9;
            this.ckbStaff01.Text = "Staff 01";
            this.ckbStaff01.UseVisualStyleBackColor = true;
            // 
            // ckbOfficer
            // 
            this.ckbOfficer.AutoSize = true;
            this.ckbOfficer.Location = new System.Drawing.Point(287, 51);
            this.ckbOfficer.Name = "ckbOfficer";
            this.ckbOfficer.Size = new System.Drawing.Size(57, 17);
            this.ckbOfficer.TabIndex = 8;
            this.ckbOfficer.Text = "Officer";
            this.ckbOfficer.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.Location = new System.Drawing.Point(468, 352);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 23;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnResetPass
            // 
            this.btnResetPass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnResetPass.Location = new System.Drawing.Point(358, 352);
            this.btnResetPass.Name = "btnResetPass";
            this.btnResetPass.Size = new System.Drawing.Size(100, 23);
            this.btnResetPass.TabIndex = 22;
            this.btnResetPass.Text = "&Reset Password";
            this.btnResetPass.UseVisualStyleBackColor = false;
            this.btnResetPass.Click += new System.EventHandler(this.btnResetPass_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(273, 352);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 21;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 174);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Assign Departments To User";
            // 
            // lblRemark
            // 
            this.lblRemark.AutoSize = true;
            this.lblRemark.Location = new System.Drawing.Point(41, 90);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(44, 13);
            this.lblRemark.TabIndex = 12;
            this.lblRemark.Text = "Remark";
            // 
            // txtShortName
            // 
            this.txtShortName.Location = new System.Drawing.Point(115, 45);
            this.txtShortName.MaxLength = 30;
            this.txtShortName.Name = "txtShortName";
            this.txtShortName.Size = new System.Drawing.Size(150, 20);
            this.txtShortName.TabIndex = 3;
            // 
            // txtPassword
            // 
            this.txtPassword.Enabled = false;
            this.txtPassword.Location = new System.Drawing.Point(348, 24);
            this.txtPassword.MaxLength = 20;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(195, 20);
            this.txtPassword.TabIndex = 7;
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(115, 24);
            this.txtUserName.MaxLength = 20;
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(150, 20);
            this.txtUserName.TabIndex = 1;
            // 
            // txtFullName
            // 
            this.txtFullName.Location = new System.Drawing.Point(115, 66);
            this.txtFullName.MaxLength = 50;
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(150, 20);
            this.txtFullName.TabIndex = 5;
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(284, 31);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(53, 13);
            this.lblPassword.TabIndex = 6;
            this.lblPassword.Text = "Password";
            // 
            // lblFullName
            // 
            this.lblFullName.AutoSize = true;
            this.lblFullName.Location = new System.Drawing.Point(40, 70);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(54, 13);
            this.lblFullName.TabIndex = 4;
            this.lblFullName.Text = "Full Name";
            // 
            // lblShortName
            // 
            this.lblShortName.AutoSize = true;
            this.lblShortName.Location = new System.Drawing.Point(41, 49);
            this.lblShortName.Name = "lblShortName";
            this.lblShortName.Size = new System.Drawing.Size(63, 13);
            this.lblShortName.TabIndex = 2;
            this.lblShortName.Text = "Short Name";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Location = new System.Drawing.Point(40, 28);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(60, 13);
            this.lblUserName.TabIndex = 0;
            this.lblUserName.Text = "User Name";
            // 
            // txtRemark
            // 
            this.txtRemark.Location = new System.Drawing.Point(115, 87);
            this.txtRemark.MaxLength = 100;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(428, 72);
            this.txtRemark.TabIndex = 13;
            this.txtRemark.Text = "";
            // 
            // frmMDUserAddModify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(589, 398);
            this.Controls.Add(this.txtRemark);
            this.Controls.Add(this.listViewRight);
            this.Controls.Add(this.listViewLeft);
            this.Controls.Add(this.btnDoubleLeft);
            this.Controls.Add(this.btnSingleLeft);
            this.Controls.Add(this.btnSingleRight);
            this.Controls.Add(this.btnDoubleRight);
            this.Controls.Add(this.ckbLockout);
            this.Controls.Add(this.ckbStaff02);
            this.Controls.Add(this.ckbStaff01);
            this.Controls.Add(this.ckbOfficer);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnResetPass);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblRemark);
            this.Controls.Add(this.txtShortName);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUserName);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblFullName);
            this.Controls.Add(this.lblShortName);
            this.Controls.Add(this.lblUserName);
            this.Name = "frmMDUserAddModify";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Create User";
            this.Load += new System.EventHandler(this.frmMDUserAddModify_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDUserAddModify_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listViewRight;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ListView listViewLeft;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Button btnDoubleLeft;
        private System.Windows.Forms.Button btnSingleLeft;
        private System.Windows.Forms.Button btnSingleRight;
        private System.Windows.Forms.Button btnDoubleRight;
        private System.Windows.Forms.CheckBox ckbLockout;
        private System.Windows.Forms.CheckBox ckbStaff02;
        private System.Windows.Forms.CheckBox ckbStaff01;
        private System.Windows.Forms.CheckBox ckbOfficer;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnResetPass;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblRemark;
        private System.Windows.Forms.TextBox txtShortName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label lblShortName;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.RichTextBox txtRemark;

    }
}