﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-13 (Web, 13 March 2013) $
 * ========================================================
 * This class is used to view Department List
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDDepartmentListView : frmMDMaster
    {
        #region Global Variable
        DataTable m_DataTable = null;
        DataView m_DataView = null;
        // For Security Checking
        clsSEAuthorizer m_Security = null;
		bool CommonError = false;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDDepartmentListView class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDDepartmentListView()
        {
			try
			{
				InitializeComponent();
				
				// Check authorization
				m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
				m_Security.CheckAuthorizationOnScreen(this);

				this.Text = clsMDConstant.DEPT_TITLE_LIST;
				m_DataView = new DataView();

                //Get all list department
                GetDepartmentList();
			}
			catch (Exception ex)
            {                
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
				CommonError = true;
            }
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Event form load
        /// Load data default: list department
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmMDDepartmentListView_Load(object sender, EventArgs e)
        {			
            try
            {
                //Set common style for form
                SetFormStyleCommon();                
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }
        
        /// <summary>
        /// Event click button "Search"
        /// Get list of departments based on input params
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //disable all button control while system excute search function
            EnableButtonControl(false);
            //get search condition
            clsMDDepartmentDTO dto = new clsMDDepartmentDTO();
            dto.DepartmentCode = txtDeptCode.Text.Trim();
            dto.DepartmentName = txtDeptName.Text.Trim();
            try
            {
                //search list dept based on input params
                m_DataTable = clsMDDepartmentBUS.Instance().GetDepartmentList(dto);
                //update data on grid
                UpdateGridView(m_DataTable);              
                if (m_DataTable == null || (m_DataTable != null && m_DataTable.Rows.Count == 0))
                {
                    //display message 'No transaction found!'
                    clsMDMesageCollection.MessageNoTransactions();                   
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button control while system excute search function
            EnableButtonControl(true );
        }

        /// <summary>
        /// Event click button "Create", tranfer to Create Department screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnNew_Click(object sender, EventArgs e)
        {
            //tranfer to Create Department Screen
            frmMDDepartmentAddModify frmNew = new frmMDDepartmentAddModify(clsMDConstant.DEPT_TITLE_CREATE);
            frmNew.OnSaved += new EventHandler(frmNewModify_OnSaved);
            frmNew.m_CurrentAction = CommonValue.ActionType.New;
            frmNew.StartPosition = FormStartPosition.CenterScreen;
            frmNew.ShowDialog();
        }

        /// <summary>
        /// Event click button "Modify", tranfer to Modify Department screen
        /// User must select a department to modify
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgDeptList.SelectedRows.Count > 0)
                {
                    if (dtgDeptList.SelectedRows.Count > 1)
                    {
                        //if user choose more than one item on grid
                        //display message to require user choose one item on grid before click modify button
                        //'Please select a department to modify.'                           
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a department", "modify"));
                    }
                    else
                    {
                        //get selected row
                        DataGridViewRow rowSelected = dtgDeptList.CurrentRow;
                        //tranfer to Modify Department Screen
                        frmMDDepartmentAddModify frmModify = new frmMDDepartmentAddModify(clsMDConstant.DEPT_TITLE_MODIFY);
                        //define action after called save action on frmMDUserAddModify screen
                        frmModify.OnSaved += new EventHandler(frmNewModify_OnSaved);
                        //set updated object
                        frmModify.m_CurrentAction = CommonValue.ActionType.Update;
                        frmModify.m_UpdatingDept.DepartmentID = int.Parse(rowSelected.Cells[clsMDConstant.MD_COL_DEPARTMENTID].Value.ToString());
                        frmModify.m_UpdatingDept = clsMDDepartmentBUS.Instance().GetDepartment(frmModify.m_UpdatingDept.DepartmentID);
                        if (frmModify.m_UpdatingDept != null)
                        {
                            frmModify.SetData(frmModify.m_UpdatingDept);
                            frmModify.StartPosition = FormStartPosition.CenterScreen;
                            frmModify.ShowDialog();
                        }
                        else
                        {
                            //if system can not get information of selected object
                            //display error message
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.ERROR_NOT_FOUND_ITEM);
                        }
                    }
                }
                else
                {
                    //if user choose more than one item on grid
                    //display message to require user choose one item on grid before click modify button
                    //'Please select a department to modify.'                           
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a department", "modify"));
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click button "Delete" to excute action delete department(update DelFlag = 1)
        /// User must select one department to delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //disable all button while system excute delete function.
            EnableButtonControl(false);
            try
            {                
                if (dtgDeptList.SelectedRows.Count > 0)
                {
                    //display confirm message 'Are you sure to delete this department?'
                    DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, string.Format(clsMDMessage.CONFIRM_ACTION_DELETE_DATA, "department"));
                    if (res == DialogResult.Yes)
                    {
                        //get DepartmentId to delete
                        DataGridViewRow dataRow = dtgDeptList.CurrentRow;
                        int iDeptID = int.Parse(dataRow.Cells[clsMDConstant.MD_COL_DEPARTMENTID].Value.ToString());
                        //can not delete if there are users assgined
                        clsMDUserDTO dtoUser = new clsMDUserDTO();
                        dtoUser.DepartmentID = iDeptID;
                        DataTable dtUser = clsMDUserBUS.Instance().GetUserList(dtoUser);
                        if (dtUser != null && dtUser.Rows.Count > 0)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.ERROR_ACTION_CANNOT_DELETE, "department", "user"));
                            //enable all button while system finish delete function.
                            EnableButtonControl(true);
                            return;
                        }
                        clsMDTeamDTO team = new clsMDTeamDTO();
                        team.DepartmentID = iDeptID;
                        DataTable dtTeam = clsMDTeamBUS.Instance().GetTeamList(team);
                        if (dtTeam != null && dtTeam.Rows.Count > 0)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.ERROR_ACTION_CANNOT_DELETE, "department", "team"));
                        }
                        else
                        {
                            //create data for save log
                            clsMDLogBase logBase = new clsMDLogBase();
                            logBase.ApplicationName = this.Text;
                            logBase.UserID = clsUserInfo.UserNo.ToString();
                            logBase.Module = clsMDConstant.MODULE_SE;
                            logBase.Action = (int)CommonValue.ActionType.Delete;
                            logBase.Key = dataRow.Cells[clsMDConstant.MD_COL_DEPARTMENTCODE].Value.ToString() + " " +
                                            dataRow.Cells[clsMDConstant.MD_COL_DEPARTMENTID].Value.ToString();

                            //Delete logic department and Write Delete information to Log History
                            int iRow = clsMDDepartmentBUS.Instance().DeleteDepartment(iDeptID, logBase);
                            if (iRow > 0)
                            {
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Deleting", "department"));

                                //Refresh data on grid after delete
                                //GetDepartmentList();
                                btnSearch_Click(sender, e);
                            }
                            else if (iRow == 0)
                            {
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Deleting", "department"));

                                //Refresh data on grid after delete
                                //GetDepartmentList();
                                btnSearch_Click(sender, e);
                            }
                            //else
                            //{
                            //    this.Close();
                            //}
                        }
                    }
                }
                else
                {                    
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a department", "delete"));
                }                
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button while system finish delete function.
            EnableButtonControl(true);
        }

        /// <summary>
        /// Define EventHandle after excute action save in frmMDDepartmentAddMofidify
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmNewModify_OnSaved(object sender, EventArgs e)
        {
            //2013.06.11 UDP vlhcnhung S Reload data on grid after create/modify team
            //Refresh data on grid
            //GetDepartmentList();
            clsMDDepartmentDTO dto = new clsMDDepartmentDTO();
            dto.DepartmentCode = txtDeptCode.Text.Trim();
            dto.DepartmentName = txtDeptName.Text.Trim();
            //search list dept based on input params
            m_DataTable = clsMDDepartmentBUS.Instance().GetDepartmentList(dto);
            //update data on grid
            UpdateGridView(m_DataTable);
            //2013.06.11 UDP vlhcnhung E Reload data on grid after create/modify team
            //enable button control if they are disable
            EnableButtonControl(true);
        }   

        /// <summary>
        /// Event click button "Assign Users", tranfer to Assign Users To Departmetn screeen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnAssignUser_Click(object sender, EventArgs e)
        {
            if (dtgDeptList.SelectedRows.Count > 0)
            {
                frmMDAssignUserToDepartment frm = new frmMDAssignUserToDepartment(clsMDConstant.DEPT_TITLE_ASSIGN_USER);
                frm.OnSaved += new EventHandler(frmNewModify_OnSaved);

                DataGridViewRow rowSelected = dtgDeptList.CurrentRow;
                frm.iSelectedDept = int.Parse(rowSelected.Cells[clsMDConstant.MD_COL_DEPARTMENTID].Value.ToString());

                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
            }
            else
            {              
                //display message to require user choose one item on grid before click modify button
                //'Please select a department to assign.'        
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a department", "assign"));
            }
        }

        /// <summary>
        /// event click button Close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        private void frmMDDepartmentListView_Shown(object sender, EventArgs e)
        {
            if (CommonError)
            {
                this.Close();
            }
        }
        #endregion

        #region Member Methods
        /// <summary>
        /// Enable or disable all button control
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnSearch.Enabled = value;
            btnCreate.Enabled = value;
            btnModify.Enabled = value;            
            btnDelete.Enabled = value;
            btnAssignUser.Enabled = value;
            btnClose.Enabled = value;
            if (value == true)
            {
                //check security
                if (btnSearch.Tag != null && !string.IsNullOrEmpty(btnSearch.Tag.ToString()))
                {
                    btnSearch.Enabled = bool.Parse(btnSearch.Tag.ToString());
                }
                if (btnCreate.Tag != null && !string.IsNullOrEmpty(btnCreate.Tag.ToString()))
                {
                    btnCreate.Enabled = bool.Parse(btnCreate.Tag.ToString());
                }
                if (btnModify.Tag != null && !string.IsNullOrEmpty(btnModify.Tag.ToString()))
                {
                    btnModify.Enabled = bool.Parse(btnModify.Tag.ToString());
                }
                if (btnDelete.Tag != null && !string.IsNullOrEmpty(btnDelete.Tag.ToString()))
                {
                    btnDelete.Enabled = bool.Parse(btnDelete.Tag.ToString());
                }
                if (btnAssignUser.Tag != null && !string.IsNullOrEmpty(btnAssignUser.Tag.ToString()))
                {
                    btnAssignUser.Enabled = bool.Parse(btnAssignUser.Tag.ToString());
                }
                //check logic
                if (m_DataTable != null && m_DataTable.Rows.Count == 0)
                {
                    btnDelete.Enabled = false;
                    btnModify.Enabled = false;
                    btnAssignUser.Enabled = false;
                }
            }
        }
             
        /// <summary>
        /// Get list of all deprtments based on input parameters search
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetDepartmentList()
        {
            m_DataTable = clsMDDepartmentBUS.Instance().GetDepartmentList(new clsMDDepartmentDTO());
            UpdateGridView(m_DataTable);
        }

        /// <summary>
        /// Update DataSource of Department DataGridView
        /// </summary>
        /// <param name="list">list data department dto</param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void UpdateGridView(DataTable dept)
        {
            dept.TableName = "Department";
            m_DataView.Table = dept;
            dtgDeptList.AutoGenerateColumns = false;
            dtgDeptList.DataSource = m_DataView;
        }
        #endregion        
    }
}