﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDSearchData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbData = new System.Windows.Forms.GroupBox();
            this.dtgResult = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.grbData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgResult)).BeginInit();
            this.SuspendLayout();
            // 
            // grbData
            // 
            this.grbData.Controls.Add(this.dtgResult);
            this.grbData.Location = new System.Drawing.Point(3, 2);
            this.grbData.Name = "grbData";
            this.grbData.Size = new System.Drawing.Size(576, 285);
            this.grbData.TabIndex = 0;
            this.grbData.TabStop = false;
            this.grbData.Text = "Result list";
            // 
            // dtgResult
            // 
            this.dtgResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgResult.Location = new System.Drawing.Point(8, 16);
            this.dtgResult.Name = "dtgResult";
            this.dtgResult.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgResult.Size = new System.Drawing.Size(563, 260);
            this.dtgResult.TabIndex = 0;
            this.dtgResult.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgResult_CellDoubleClick);
            this.dtgResult.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtgResult_KeyDown);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(504, 300);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmMDSearchData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(584, 338);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grbData);
            this.Name = "frmMDSearchData";
            this.Text = "Data Result";
            this.grbData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgResult)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbData;
        private System.Windows.Forms.DataGridView dtgResult;
        private System.Windows.Forms.Button btnClose;
    }
}