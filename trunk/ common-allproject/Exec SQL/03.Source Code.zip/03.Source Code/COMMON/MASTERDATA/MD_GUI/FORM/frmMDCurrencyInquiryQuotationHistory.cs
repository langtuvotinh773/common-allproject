﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-04-12 (Fri, 12 April 2013) $
 * ========================================================
 * This class is used to view Currency Inquiry Quotation History
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Functions;
using Config.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDCurrencyInquiryQuotationHistory : frmMDMaster
	{
        /// <summary>
        /// Excel Base
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        ExcelBase m_ExcelBase;
        /// worker object, working for background thread
        private CWorker m_worker;
        /// Project name
        private string m_ProjectName = clsMDConstant.PROJECT_NAME_MASTERDATA;        
        DataTable dtQuotation;
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        /// <summary>
        /// Is called check all
        /// </summary>
        bool checkAllAction = true;
		bool CommonError = false;
        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
		public frmMDCurrencyInquiryQuotationHistory()
		{
            try
            {
                InitializeComponent();
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);
                SetFormStyleCommon();
                FillExchangeCCYPair();
                LoadIsActiveComboBox(this.cbbIsActive);
                //
                this.dtpFrom.Value = DateTime.Now;
                this.dtpTo.Value = DateTime.Now;
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				CommonError = true;
            }
        }

        #region Event Functions
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmMDCurrencyInquiryQuotationHistory_Shown(object sender, EventArgs e)
        {
			if(CommonError)
			{
				this.Close();
			}
            try
            {
                dtgCCYPair.ClearSelection();
                dtgQuotationHistory.ClearSelection();
                EnableButtonControl(true);
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event click close button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Event click search button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            EnableButtonControl(false);
            try
            {
                dtgCCYPair.CommitEdit(DataGridViewDataErrorContexts.Commit);
                //get checked CCYPair
                DataTable dtCCYPair = ((DataTable)dtgCCYPair.DataSource).Copy();
                DataRow[] checkedRows = dtCCYPair.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_CHECKEDCCYPAIR, "1"));
                string strSelectedCCYPairID = string.Empty;
                DateTime dFrom = string.IsNullOrEmpty(dtpFrom.Text) ? new DateTime(1753, 1, 1) : new DateTime(dtpFrom.Value.Year, dtpFrom.Value.Month, dtpFrom.Value.Day);
                DateTime dTo = string.IsNullOrEmpty(dtpTo.Text) ? new DateTime(9999, 12, 31, 23, 59, 0) : new DateTime(dtpTo.Value.Year, dtpTo.Value.Month, dtpTo.Value.Day, 23, 59, 0);
                int iStatusApprove = (int)CommonValue.QuotationStatus.Approved;
                int iSelectedIsActive = int.Parse(cbbIsActive.SelectedValue.ToString());
                if (checkedRows.Length > 0)
                {
                    foreach (DataRow dr in checkedRows)
                    {
                        if (string.IsNullOrEmpty(strSelectedCCYPairID))
                        {
                            strSelectedCCYPairID = dr[clsMDConstant.MD_COL_EXCHANGECCYPAIRID].ToString() ;
                        }
                        else
                        {
                            strSelectedCCYPairID += ", " + dr[clsMDConstant.MD_COL_EXCHANGECCYPAIRID].ToString();
                        }                        
                    }
                }
                if (string.IsNullOrEmpty(strSelectedCCYPairID))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "CCY Pair", "search"));
                    EnableButtonControl(true);
                    return;
                }
                dtQuotation = clsMDQuoationBus.Instance().GetCurrencyInquiryQuotationHistoryList(strSelectedCCYPairID, dFrom, dTo, iStatusApprove, iSelectedIsActive);
                FillQuotationData(dtQuotation);                
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            EnableButtonControl(true);
        }

        /// <summary>
        /// Event click Export button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnExport_Click(object sender, EventArgs e)
        {            
            try
            {
                ExportToExcel();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }         
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung  
        /// Created Date: 2013.05.30 
        /// @endcond
        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            if (checkAllAction)
            {
                DataTable dt = ((DataTable)dtgCCYPair.DataSource).Copy();
                if (chkAll.Checked)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        dr[this.colCheck.DataPropertyName.ToString()] = true;
                    }
                }
                else
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        dr[this.colCheck.DataPropertyName.ToString()] = false;
                    }
                }
                dtgCCYPair.DataSource = dt;
                dtgCCYPair.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        /// <summary>
        /// Check or uncheck CCY pair to check or uncheck Select All
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void dtgCCYPair_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dtgCCYPair.SuspendLayout();
            dtgCCYPair.CommitEdit(DataGridViewDataErrorContexts.Commit);
            if (e.ColumnIndex == 0)
            {
                checkAllAction = false;
                foreach (DataGridViewRow dr in dtgCCYPair.Rows)
                {
                    if (string.IsNullOrEmpty(dr.Cells[this.colCheck.Name].Value.ToString()) || int.Parse(dr.Cells[this.colCheck.Name].Value.ToString()) == 0)
                    {
                        chkAll.Checked = false;
                        break;
                    }
                    chkAll.Checked = true;
                }
                checkAllAction = true;
            }
            dtgCCYPair.ResumeLayout();
        }       
        #endregion

        #region Member Methods

        /// <summary>
        /// Enable or disable button when call any action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnClose.Enabled = value;
            btnSearch.Enabled = value;
            btnExport.Enabled = value;
            if (value)
            {
                if (dtgQuotationHistory.Rows.Count > 0)
                {
                    btnExport.Enabled = true;
                    if (btnExport.Tag != null && !string.IsNullOrEmpty(btnExport.Tag.ToString()))
                    {
                        btnExport.Enabled = bool.Parse(btnExport.Tag.ToString());
                    }
                }
                else
                {
                    btnExport.Enabled = false;
                }
                if (btnSearch.Tag != null && !string.IsNullOrEmpty(btnSearch.Tag.ToString()))
                {
                    btnSearch.Enabled = bool.Parse(btnSearch.Tag.ToString());
                }
            }
        }

        /// <summary>
        /// Fill data of ExchangeCCYPair
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void FillExchangeCCYPair()
        {
            DataTable dtCCYPair = clsMDExchangeCCYPairBUS.Instance().GetAllExchangeCCYPairList();
            dtgCCYPair.DataSource = dtCCYPair;
            dtgCCYPair.ClearSelection();
        }

        /// <summary>
        /// Fill Quotation data of search action to datagridview
        /// </summary>
        /// <param name="dtQuotation"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
		private void FillQuotationData(DataTable dtQuotation)
		{
            dtgQuotationHistory.Rows.Clear();
            dtgQuotationHistory.ClearSelection();
            if (dtQuotation != null && dtQuotation.Rows.Count == 0)
            {
                clsMDMesageCollection.MessageNoTransactions();
                return;
            }

            //Suppend Layout
            dtgQuotationHistory.SuspendLayout();
            List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
            DataGridViewRow row = new DataGridViewRow();

            for (int i = 0; i < dtQuotation.Rows.Count; i++)
            {
                row = new DataGridViewRow();
                row.CreateCells(dtgQuotationHistory);

                DataRow rowQuotation = dtQuotation.Rows[i];
                string strFormatNumber = rowQuotation["FormatNumber"].ToString();
                GetFormat(ref strFormatNumber);

                row.Cells[dtgQuotationHistory.Columns["colSeq"].Index].Value = rowQuotation["Seq"];
                row.Cells[dtgQuotationHistory.Columns["coLDate"].Index].Value = DateTime.Parse(rowQuotation["ImportTime"].ToString()).ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                row.Cells[dtgQuotationHistory.Columns["colTime"].Index].Value = rowQuotation["EffectiveTime"];
                row.Cells[dtgQuotationHistory.Columns["colInActive"].Index].Value = rowQuotation["Inactive"];
                row.Cells[dtgQuotationHistory.Columns["colCCYPairResult"].Index].Value = rowQuotation["ExchangeCCYPair"];
                row.Cells[dtgQuotationHistory.Columns["colTTM"].Index].Value = string.IsNullOrEmpty(rowQuotation["TTM"].ToString()) ? 0 : double.Parse(rowQuotation["TTM"].ToString());
                row.Cells[dtgQuotationHistory.Columns["colTTB"].Index].Value = string.IsNullOrEmpty(rowQuotation["TTB"].ToString()) ? 0 : double.Parse(rowQuotation["TTB"].ToString());
                row.Cells[dtgQuotationHistory.Columns["colTTS"].Index].Value = string.IsNullOrEmpty(rowQuotation["TTS"].ToString()) ? 0 : double.Parse(rowQuotation["TTS"].ToString());
                row.Cells[dtgQuotationHistory.Columns["colCSB"].Index].Value = FormatNumber(rowQuotation["CSB"].ToString(), strFormatNumber);
                row.Cells[dtgQuotationHistory.Columns["colCSS"].Index].Value = FormatNumber(rowQuotation["CSS"].ToString(), strFormatNumber);
                
                //2013.05.30 UDP vlhcnhung S Display two columns Marker and Approval (UserName) the same with History Screen
                row.Cells[dtgQuotationHistory.Columns[this.colMaker.Name].Index].Value = rowQuotation["Maker"].ToString();
                row.Cells[dtgQuotationHistory.Columns[this.colApprover.Name].Index].Value = rowQuotation["Approver"].ToString();
                //2013.05.30 UDP vlhcnhung E Display two columns Marker and Approval (UserName) the same with History Screen

                row.Cells[dtgQuotationHistory.Columns["colTTM"].Index].Style.Format = strFormatNumber;
                row.Cells[dtgQuotationHistory.Columns["colTTB"].Index].Style.Format = strFormatNumber;
                row.Cells[dtgQuotationHistory.Columns["colTTS"].Index].Style.Format = strFormatNumber;

                lstRows.Add(row);
            }

            //Resume Layout
            dtgQuotationHistory.Rows.AddRange(lstRows.ToArray());
            dtgQuotationHistory.ResumeLayout();
        }

        /// <summary>
        /// Export to excel
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void ExportToExcel()
        {
            EnableButtonControl(false);
            m_worker = new Config.Classes.CWorker(WriteCurrencyInquiryQuotationHistoryToExcel, Complete);
            m_worker.Start();
        }

        /// <summary>
        /// Write data to excel 
        /// </summary>	
        /// @cond
        /// Author: vlhcnhung
        /// @endcond 
        private void WriteCurrencyInquiryQuotationHistoryToExcel()
        {
            //clsMDFunction.ExportDataTableToExcel(m_ProjectName, dtQuotation, clsMDConstant.EXCEL_TEMPLATE_FILE_CURRENCY_QUOTATION, clsMDConstant.EXCEL_TEMPLATE_NAME_CURRENCY_INQUIRY_QUOTATION_HISTORY,
            //    clsMDConstant.HEADER_QUOTATION_EXPORT_CURRENCY_INQUIRY_HISTORY, true);

            string strFileName = clsMDConstant.EXCEL_TEMPLATE_NAME_CURRENCY_INQUIRY_QUOTATION_HISTORY;
            string strTemplateName = clsMDConstant.EXCEL_TEMPLATE_FILE_CURRENCY_QUOTATION;
            bool isOpened = false;
            m_ExcelBase = new ExcelBase(strFileName, strTemplateName, m_ProjectName, ref isOpened, clsMDBus.Instance().GetServerDate());
            if (isOpened)
            {
                return;
            }
            int iColStart = 1, iRowStart = 5, iRowEnd = iRowStart + dtgQuotationHistory.Rows.Count - 1;
            int iColEnd = clsMDConstant.HEADER_QUOTATION_EXPORT_CURRENCY_INQUIRY_HISTORY.Length;
            object[,] m_arrData = FillDataForReport(dtgQuotationHistory, dtgQuotationHistory.Rows.Count, iColEnd);
            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);
        }

        /// <summary>
        /// Get data for report
        /// </summary>
        /// <param name="iRowCount"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private object[,] FillDataForReport(DataGridView dgv, int iRowCount, int iColCount)
        {
            object[,] arrResult = new object[iRowCount, iColCount];
            int pos = 0;
            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                for (int j = 0; j < dgv.Columns.Count; j++)
                {
                    if (dgv.Rows[i].Cells[j].Visible == true)
                    {
                        arrResult[i, pos] = dgv.Rows[i].Cells[j].FormattedValue;
                        if (pos < iColCount)
                        {
                            pos++;
                        }
                    }
                }
                pos = 0;
            }
            return arrResult;
        }

        /// <summary>
        /// Handling when completed a thread
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void Complete()
        {
            EnableButtonControl(true);
            m_ExcelBase.SaveFile(true);
            if (m_worker != null)
                m_worker.Stop();
        }        
        #endregion

         
    }
}