﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-04-15 (Mon, 15 April 2013) $
 * ========================================================
 * This class is used to view Inquiry Quotation History
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDInquiryQuotationHistory : frmMDMaster
    {
        #region Global Variable
        /// worker object, working for background thread
        private CWorker m_worker;
        /// Project name
        private string m_ProjectName = clsMDConstant.PROJECT_NAME_MASTERDATA;
        
        /// <summary>
        /// Selected QUotationID 
        /// </summary>
        private int m_QuotationIDSelected = -1;
		bool CommonError = false;
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        public frmMDInquiryQuotationHistory()
		{
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                SetFormStyleCommon();

                LoadStatusInquiryQuotationHistory(this.cbbStatus);
                LoadIsActiveComboBox(this.cbbIsActive);

                EnableButtonControl(true);
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				CommonError = true;
            }
        }
        #endregion      
		
		#region Event Functions
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
		private void frmMDInquiryQuotationHistory_Load(object sender, EventArgs e)
		{				
			dtgQuotationHistory.ClearSelection();
			if (dtgQuotationHistory.SelectedRows.Count > 0)
			{
				EnableButtonControl(true);
			}
			else
			{
				EnableButtonControl(false);
				btnSearch.Enabled=true;
			}
            //
            this.dtpFrom.Value = DateTime.Now;
            this.dtpTo.Value = DateTime.Now;
		}

        /// <summary>
        /// Event click Search button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Search();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

		private void Search()
		{
			EnableButtonControl(false);
			try
			{
				//get checked CCYPair                
                DateTime dFrom = string.IsNullOrEmpty(dtpFrom.Text) ? new DateTime(1753,1,1) : new DateTime(dtpFrom.Value.Year, dtpFrom.Value.Month, dtpFrom.Value.Day);
                DateTime dTo = string.IsNullOrEmpty(dtpTo.Text) ? new DateTime(9999, 12, 31, 23, 59, 0) : new DateTime(dtpTo.Value.Year, dtpTo.Value.Month, dtpTo.Value.Day, 23, 59, 0);
                
				int iSelectedStatus = int.Parse(cbbStatus.SelectedValue.ToString());
                int iSelectedIsActive = int.Parse(cbbIsActive.SelectedValue.ToString());
                DataTable dtQuotation = clsMDQuoationBus.Instance().GetInquiryQuotationHistoryList(dFrom, dTo, iSelectedStatus, iSelectedIsActive);
				FillQuotationData(dtQuotation);
			}
			catch (Exception ex)
			{
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
			if (dtgQuotationHistory.SelectedRows.Count > 0)
			{
				EnableButtonControl(true);
			}
			else
			{
				EnableButtonControl(false);
				btnSearch.Enabled = true;
			}
		}

        /// <summary>
        /// Event click Print and Preview button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnPrintPreView_Click(object sender, EventArgs e)
        {
			try
			{
                if (dtgQuotationHistory.SelectedRows.Count == 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_QUOTATION_PREVIEW);
                    return;
                }
                m_QuotationIDSelected = int.Parse(dtgQuotationHistory.SelectedRows[0].Cells[clsMDConstant.MD_COL_QUOTATIONID].Value.ToString());
				clsMDQuotationDTO quotationObj = clsMDQuoationBus.Instance().GetQuotationDetail(m_QuotationIDSelected);
				DataTable tdbQuotationECRate = clsMDQuoationBus.Instance().GetQuotationECRate(m_QuotationIDSelected);
				DataTable tdbQuotationUSD = clsMDQuoationBus.Instance().GetQuotationDetailUSD(m_QuotationIDSelected);
				DataTable tdbQuotationVND = clsMDQuoationBus.Instance().GetQuotationDetailVND(m_QuotationIDSelected);
				frmMDPreviewQuoationDetail previewQuoationDetail = new frmMDPreviewQuoationDetail(tdbQuotationUSD, tdbQuotationVND, tdbQuotationECRate, quotationObj);
				previewQuoationDetail.ShowDialog();
			}
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event click Export button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnExport_Click(object sender, EventArgs e)
        {          
			try
			{
                if (dtgQuotationHistory.SelectedRows.Count <= 0)
				{
					clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_QUOTATION_EXPORT);
					return;
				}
				EnableButtonControl(false);
                m_QuotationIDSelected = int.Parse(dtgQuotationHistory.SelectedRows[0].Cells[dtgQuotationHistory.Columns.Count - 1].Value.ToString());
				ExportToExcel();
			}
			catch (Exception ex)
			{
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                EnableButtonControl(true);
			}            
		}
		
        /// <summary>
        /// Event click close button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
		private void dtgQuotationHistory_SelectionChanged(object sender, EventArgs e)
		{
			if (dtgQuotationHistory.SelectedRows.Count > 0)
			{
				EnableButtonControl(true);
			}
			else
			{
				EnableButtonControl(false);
				btnSearch.Enabled = true;
			}
		}

        private void frmMDInquiryQuotationHistory_Shown(object sender, EventArgs e)
        {
            if (CommonError)
            {
                this.Close();
            }
        }
        #endregion

        #region Member Functions
        /// <summary>
        /// Enable or disable button when call any action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnClose.Enabled = value;
            btnSearch.Enabled = value;
            btnExport.Enabled = value;
            btnPrintPreView.Enabled = value;
            if (value)
            {
                if (((DataTable)dtgQuotationHistory.DataSource) != null && ((DataTable)dtgQuotationHistory.DataSource).Rows.Count > 0)
                {
                    btnExport.Enabled = true;
                    btnPrintPreView.Enabled = true;
                    if (btnExport.Tag != null && !string.IsNullOrEmpty(btnExport.Tag.ToString()))
                    {
                        btnExport.Enabled = bool.Parse(btnExport.Tag.ToString());
                    }
                    if (btnPrintPreView.Tag != null && !string.IsNullOrEmpty(btnPrintPreView.Tag.ToString()))
                    {
                        btnPrintPreView.Enabled = bool.Parse(btnPrintPreView.Tag.ToString());
                    }
                }
                else
                {
                    btnExport.Enabled = false;
                    btnPrintPreView.Enabled = false;
                }
                if (btnSearch.Tag != null && !string.IsNullOrEmpty(btnSearch.Tag.ToString()))
                {
                    btnSearch.Enabled = bool.Parse(btnSearch.Tag.ToString());
                }
            }
        }

        /// <summary>
        /// Fill Quotation data of search action to datagridview
        /// </summary>
        /// <param name="dtQuotation"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void FillQuotationData(DataTable dtQuotation)
        {			
            dtgQuotationHistory.DataSource = dtQuotation;
            if (dtQuotation != null && dtQuotation.Rows.Count > 0)
            {
                foreach (DataRow dr in dtQuotation.Rows)
                {
                    int status = int.Parse(dr[clsMDConstant.MD_COL_STATUS].ToString());
                    if (status == (int)CommonValue.QuotationStatus.Approved)
                    {
                        dr[clsMDConstant.MD_COL_STATUS] = clsMDConstant.QUOTATIONSTATUS_03_APPROVED;
                    }
                    else if (status == (int)CommonValue.QuotationStatus.Obsolete)
                    {
                        dr[clsMDConstant.MD_COL_STATUS] = clsMDConstant.QUOTATIONSTATUS_07_OBSOLUTE;
                    }
                    else
                    {
                        dr[clsMDConstant.MD_COL_STATUS] = string.Empty;
                    }
                }                
            }
            else
            {
                clsMDMesageCollection.MessageNoTransactions();
            }
        }

        /// <summary>
        /// Handling when completed a thread
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void Complete()
        { 
            EnableButtonControl(true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void ExportToExcel()
        {
            if (dtgQuotationHistory.SelectedRows.Count>0)
            {
                m_worker = new Config.Classes.CWorker(ExportQuotation, Complete);
                m_worker.Start();
            }
        }

        private void ExportQuotation()
        {
            clsMDFunction.ExportQuotation(m_ProjectName, m_QuotationIDSelected, FORMAT_DDMMMYYYY);
        }        
        #endregion                
    }
}