﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phuong Lap Co $
 * $Date: 2013-06-04 12:37:30 +0700 (Tue, 04 June 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to proccess frmMDProcessingBoardRateMaker
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Dto;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDProcessingBoardRateMaker : frmMDMaster
    {

        #region Private Variables
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        private clsMDBoardRaterBUS m_BoardRateBus;
        private List<clsMDBoardRateDTO> m_BoardRateList;
        private clsMDBoardRateDTO m_BoardRateDto;
        private string m_colBoardRateID = "colBoardRateID";
        private string m_colStatusID = "colStatusID";
        //private clsMDCommonValue.BoardRateAction m_BoardRateAction = 0;
        private clsMDCommonValue.BoardRateStatus m_Status = clsMDCommonValue.BoardRateStatus.Blank;
        #endregion

        #region Contructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="iRole">Approver of Maker</param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDProcessingBoardRateMaker()
        {
            try
            {
                InitializeComponent();
                SetFormStyleCommon();
                //Do not allow sort on grid
                for (int i = 0; i < dtgBoardRateList.Columns.Count; i++)
                {
                    dtgBoardRateList.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                }
                //Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                //load latest Board Rate "Approved"
                GetBoardRateListForMaker();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }

        }
        #endregion

        #region Event Method

        /// <summary>
        /// Approve even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbRequestToApprove_Click(object sender, EventArgs e)
        {
            try
            {
                /*
                   '- User is authorized for action “Request to approve”. 
                    - User selects board rate with status 'New'.
                    - User clicks on “Request to approve” button.
                    - System display a confirm message box “Are you sure to request for approval?”
                    - User clicks on “Yes” button.
                    - System will popup a message to announce “Request was sent successfully”
                    *Note: 
                    - System restricted that approver must be different from maker of board rate.
                    - The board rate status is “Wait for approve”.
                    - Operation log will be saved.
                 */
                DialogResult dialog;
                dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                            clsMDMessage.ARE_YOU_SURE_TO_REQUEST_FOR_APPROVAL);
                if (dialog == DialogResult.Yes)
                {
                    m_BoardRateBus = new clsMDBoardRaterBUS();
                    m_BoardRateDto.Status = (int)clsMDCommonValue.BoardRateStatus.WaitingforApprove;

                    int row = m_BoardRateBus.UpdateBoardRate(m_BoardRateDto);
                    if (row > 0)
                    {
                        WriteLogUpdateStatus(m_BoardRateDto.BoardRateID, (int)m_Status, m_BoardRateDto.Status);
                        m_BoardRateBus.Commit();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                          clsMDMessage.REQUEST_WAS_SENT_SUCCESSFULLY);
                    }
                    else
                    {
                        m_BoardRateBus.RollBack();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                           clsMDMessage.REQUEST_WAS_SENT_UN_SUCCESSFULLY);
                    }
                    GetBoardRateListForMaker();
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_BoardRateBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Withdraw even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbWithdraw_Click(object sender, EventArgs e)
        {
            try
            {
                /*
                    - User is authorized for action “Withdraw Quotation”.
                    - User selects board rate having status “Wait for approve”
                    - User clicks on “Withdraw” button.
                    - System display a confirm message box “Are you sure to withdraw data?”
                    - User clicks on “Yes” button.
                    - System will popup a message to announce “Data was withdraw successfully”
                    - System will display confirm message box to ask user: "Do you want to re-import data for board rate?"
                    - In case user clicks on “Yes” button.
                       System will open screen Import for user to re-import data
                    - In case user clicks on “No” button.
                        System will close confirm message box
                    - In case of actor clicks [No] on confirm message box, system will not save data in database and close confirm message.
                 */
                DialogResult dialog;
                dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                            clsMDMessage.ARE_YOU_SURE_TO_WITHDRAW_DATA);
                if (dialog == DialogResult.Yes)
                {
                    m_BoardRateBus = new clsMDBoardRaterBUS();
                    m_BoardRateDto.Status = (int)clsMDCommonValue.BoardRateStatus.Withdrawed;

                    int row = m_BoardRateBus.UpdateBoardRate(m_BoardRateDto);
                    if (row > 0)
                    {
                        WriteLogUpdateStatus(m_BoardRateDto.BoardRateID, (int)m_Status, m_BoardRateDto.Status);
                        m_BoardRateBus.Commit();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                          clsMDMessage.DATA_WAS_WITHDRAW_SUCCESSFULLY);
                        dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                            clsMDMessage.DO_YOU_WANT_TO_RE_IMPORT_DATA_FOR_BOARD_RATE);
                        if (dialog == DialogResult.Yes)
                        {
                            //show form Import Board Rate
                            frmMDImportBoardRate frm = new frmMDImportBoardRate(clsMDCommonValue.BoardRateStatus.Withdrawed, m_BoardRateDto.BoardRateID, false);
                            frm.StartPosition = FormStartPosition.CenterScreen;
                            frm.ShowDialog();
                        }
                    }
                    else
                    {
                        m_BoardRateBus.RollBack();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                           clsMDMessage.DATA_WAS_WITHDRAW_UN_SUCCESSFULLY);
                    }
                    GetBoardRateListForMaker();
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_BoardRateBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbPrintPreview_Click(object sender, EventArgs e)
        {
            try
            {
                //show form print preview Board Rate
                frmMDPrintPreviewBoardRate frm = new frmMDPrintPreviewBoardRate(m_BoardRateDto.BoardRateID, m_BoardRateDto.ImportTime);
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Refresh even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                GetBoardRateListForMaker();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Import Board Rate
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbImport_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_Status == clsMDCommonValue.BoardRateStatus.Blank)
                {
                    //show form Import Board Rate
                    frmMDImportBoardRate frm = new frmMDImportBoardRate(clsMDCommonValue.BoardRateStatus.Blank, 0, true);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.ShowDialog();
                }
                else
                {
                    //show form Import Board Rate
                    frmMDImportBoardRate frm = new frmMDImportBoardRate(m_Status, m_BoardRateDto.BoardRateID, true);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.ShowDialog();
                }
                GetBoardRateListForMaker();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Export Board Rate template
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_BoardRateDto != null)
                {
                    clsMDBoardRateDTO dtoExport = clsMDBoardRaterBUS.Instance().GetBoardRateAndBoadRateDetail(m_BoardRateDto.BoardRateID);
                    if (dtoExport != null)
                    {
                        m_BoardRateBus = new clsMDBoardRaterBUS();
                        //export board rate is selected on grid to export file excel
                        m_BoardRateBus.ExportBoardRate(dtoExport);
                    }
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_BOARD_RATE_EXPORT);
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Close form even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Datagridview's Selection changed even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgBoardRateMakerList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                m_Status = clsMDCommonValue.BoardRateStatus.Blank;
                if (dtgBoardRateList.Rows.Count > 0 && dtgBoardRateList.SelectedRows.Count > 0)
                {
                    int index = dtgBoardRateList.Rows.IndexOf(dtgBoardRateList.SelectedRows[0]);
                    //get current status of row is selected on grid
                    m_Status = (clsMDCommonValue.BoardRateStatus)dtgBoardRateList.Rows[index].Cells[m_colStatusID].Value;
                    int boardRateID = (int)dtgBoardRateList.Rows[index].Cells[m_colBoardRateID].Value;
                    m_BoardRateDto = m_BoardRateList.Find(t => t.BoardRateID == boardRateID);
                }
                else
                {
                    m_BoardRateDto = null;
                }
                //show and hidden tool strip menu
                ShowHidenToolStrip(m_Status);
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }


        /// <summary>
        /// Board Rate double click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgBoardRateMakerList_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                if (m_Status != clsMDCommonValue.BoardRateStatus.Blank)
                {
                    if (m_BoardRateDto.IsProcess == false)
                    {
                        return;
                    }                    
                    //show form Import Board Rate
                    frmMDImportBoardRate frm = new frmMDImportBoardRate(m_Status, m_BoardRateDto.BoardRateID, true);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.ShowDialog();
                    GetBoardRateListForMaker();
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Member Methods

        /// <summary>
        /// Get board rate list maker
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetBoardRateListForMaker()
        {
            dtgBoardRateList.Rows.Clear();
            m_BoardRateBus = new clsMDBoardRaterBUS();
            m_BoardRateList = m_BoardRateBus.GetViewBoardRateMakerList();
            if (m_BoardRateList.Count > 0)
            {
                foreach (clsMDBoardRateDTO dto in m_BoardRateList)
                {
                    dtgBoardRateList.Rows.Add(dto.BoardRateID, clsMDFunction.GetBoardRateStatusName(dto.Status), !dto.IsActive,
                        dto.ImportTime, dto.ImportTime, dto.Maker, dto.Approver, dto.Status);
                }
            }
            else
            {
                m_Status = clsMDCommonValue.BoardRateStatus.Blank;
            }
            //Init tool strip menu
            ShowHidenToolStrip(m_Status);
        }

        /// <summary>
        /// Show hidden tool strip menu by status
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ShowHidenToolStrip(clsMDCommonValue.BoardRateStatus status)
        {
            /*
             * When user select a board rate, system will enable or disable button depend on status of selected board rate.
                - In case selected board rate is new, enable  Request to Approve
                - In case selected board rate is Wait for approve, enable  withdraw
                - In case selected board rate is Approved, enable export
                - Selected a board rate, enable Print/Preview.
             */
            switch (status)
            {
                case clsMDCommonValue.BoardRateStatus.Blank:
                    tsbRequestToApprove.Visible = false;
                    tsbWithdraw.Visible = false;
                    tsbPrintPreview.Visible = false;
                    tsbImport.Visible = true;
                    tsbExport.Visible = false;
                    break;

                case clsMDCommonValue.BoardRateStatus.New:
                    tsbRequestToApprove.Visible = true;
                    tsbWithdraw.Visible = false;
                    tsbPrintPreview.Visible = true;
                    tsbImport.Visible = false;
                    tsbExport.Visible = true;
                    break;

                case clsMDCommonValue.BoardRateStatus.WaitingforApprove:
                    tsbRequestToApprove.Visible = false;
                    tsbWithdraw.Visible = true;
                    tsbPrintPreview.Visible = true;
                    tsbImport.Visible = false;
                    tsbExport.Visible = true;
                    break;

                case clsMDCommonValue.BoardRateStatus.Approved:
                    tsbRequestToApprove.Visible = false;
                    tsbWithdraw.Visible = false;
                    tsbPrintPreview.Visible = true;
                    tsbImport.Visible = true;
                    tsbExport.Visible = true;
                    //in case : grid board rate have 2 rows
                    if (m_BoardRateDto.IsProcess == false)
                    {
                        tsbImport.Visible = false;
                    }
                    break;

                case clsMDCommonValue.BoardRateStatus.Withdrawed:
                    tsbRequestToApprove.Visible = false;
                    tsbWithdraw.Visible = false;
                    tsbPrintPreview.Visible = true;
                    tsbImport.Visible = true;
                    tsbExport.Visible = true;
                    break;

                case clsMDCommonValue.BoardRateStatus.Returned:
                    tsbRequestToApprove.Visible = false;
                    tsbWithdraw.Visible = false;
                    tsbPrintPreview.Visible = true;
                    tsbImport.Visible = true;
                    tsbExport.Visible = true;
                    break;

                case clsMDCommonValue.BoardRateStatus.Suspended:
                    tsbRequestToApprove.Visible = false;
                    tsbWithdraw.Visible = false;
                    tsbPrintPreview.Visible = true;
                    tsbImport.Visible = true;
                    tsbExport.Visible = true;                    
                    //in case : grid board rate have 2 rows
                    if (m_BoardRateDto.IsProcess == false)
                    {
                        tsbImport.Visible = false;
                    }
                    break;

                case clsMDCommonValue.BoardRateStatus.Obsolete:
                    break;

                case clsMDCommonValue.BoardRateStatus.Freeze:
                    break;
            }
        }

        /// <summary>
        /// Write log update status
        /// </summary>
        /// <param name="key"></param>
        /// <param name="iOldStatus"></param>
        /// <param name="iNewSatus"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLogUpdateStatus(int key, int iOldStatus, int iNewSatus)
        {
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = key.ToString();
            logBase.Action = (int)CommonValue.ActionType.Update;

            clsMDLogInformation logInfo = new clsMDLogInformation();
            logInfo.FieldName = "Status";
            logInfo.OldValue = iOldStatus.ToString();
            logInfo.NewValue = iNewSatus.ToString();
            logBase.LstLogInformation.Add(logInfo);
            logBase.WirteLog(m_BoardRateBus.DAL);
        }
        #endregion


    }
}