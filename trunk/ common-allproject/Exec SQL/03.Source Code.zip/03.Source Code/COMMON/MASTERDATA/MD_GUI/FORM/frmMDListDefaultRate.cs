﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-08-30 10:00:30 +0700 (Tue, 30 August 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage default rate
 * of Master data module.
 */
using System;
using System.Data;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using System.Collections.Generic;
using Phoenix.Common.MasterData.Dto;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDListDefaultRate : frmMDMaster
    {
        #region Global Variable
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        //DTO & BUS
        clsMDDefaultRateBUS mdDefaultRateBUS = new clsMDDefaultRateBUS();
        clsListDefaultRateDTO mdListDefaultRateDTO = new clsListDefaultRateDTO();

        //For Datagridview
        //+ From Date
        private string m_colFromDate = "colFromDate";
        //+ To Date
        private string m_colToDate = "colToDate";
        //+ CCY
        const string m_colCCY = "colCCY";
        //+ Rate
        const string m_colRate = "colRate";

        private string m_DefaultRate = "default rate";
        private string m_Modify = "modify";

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public frmMDListDefaultRate()
        {
            InitializeComponent();

            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);

            try
            {
                Init();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Event Methods
        /// <summary>
        /// Close form even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Button Create event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btCreate_Click(object sender, EventArgs e)
        {
            try
            {
                frmMDAddModifyDefaultRate frm = new frmMDAddModifyDefaultRate();
                frm.StartPosition = FormStartPosition.CenterScreen;
                DialogResult result = frm.ShowDialog();
                if (result == DialogResult.OK)
                {
                    Init();
                    Search();
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Call modify default rate screen event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgDefaultRateList.SelectedRows.Count <= 0)
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, m_DefaultRate, m_Modify));
                else
                {
                    //+ From Date
                    DateTime fromDate = DateTime.Parse(dtgDefaultRateList.SelectedRows[0].Cells[m_colFromDate].Value.ToString());
                    //+ To Date
                    DateTime toDate = DateTime.Parse(dtgDefaultRateList.SelectedRows[0].Cells[m_colToDate].Value.ToString());
                    //+ CCY
                    string ccy = dtgDefaultRateList.SelectedRows[0].Cells[m_colCCY].Value.ToString();
                    //+ Rate
                    string rate = dtgDefaultRateList.SelectedRows[0].Cells[m_colRate].Value.ToString();
                    //Call Form For Modifying
                    frmMDAddModifyDefaultRate frm = new frmMDAddModifyDefaultRate(fromDate, toDate, ccy, rate);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    DialogResult result = frm.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        Init();
                        Search();
                    }
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Search Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Search();
                //No records
                if (dtgDefaultRateList.Rows.Count == 0)
                {
                    clsMDMesageCollection.MessageNoTransactions();
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Datagridview selection changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgDefaultRateList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dtgDefaultRateList.SelectedRows.Count < 1)
                {
                    btnModify.Enabled = false;
                }
                else
                {
                    btnModify.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        #endregion

        #region Methods
        
        /// <summary>
        /// Init value of controls on this form
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void Init()
        {
            //init data for From Date, To Date combobox
            FillDataFromToCombobox();

            SetFormStyleCommon();
            LoadCurrency(cbbCCY);
            if (cbbCCY.Items.Count == 0)
            {
                List<CbbObject> lstCbbObj = new List<CbbObject>();
                lstCbbObj = clsMDCeilingFloorBUS.Instance().GetCurencyList();
                cbbCCY.DataSource = lstCbbObj;
            }
            btnModify.Enabled = false;
            Search();
        }

        /// <summary>
        /// Search function
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void Search()
        {
            //Declaration
            mdListDefaultRateDTO = new clsListDefaultRateDTO();
            List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
            DataGridViewRow row = new DataGridViewRow();
            dtgDefaultRateList.Rows.Clear();

            //Assign value from inputting      
            //+ Input Date From
            mdListDefaultRateDTO.InputDateFrom = cbbFromDate.SelectedValue == null ? DateTime.MinValue : (DateTime)cbbFromDate.SelectedValue;
            //mdListDefaultRateDTO.InputDateFrom = dtpFromDate.Text.Equals(String.Empty) ? DateTime.MinValue : dtpFromDate.Value;
            //+ Input Date To
            mdListDefaultRateDTO.InputDateTo = cbbToDate.SelectedValue == null ? DateTime.MinValue : (DateTime)cbbToDate.SelectedValue;
            //mdListDefaultRateDTO.InputDateTo = dtpToDate.Text.Equals(String.Empty) ? DateTime.MinValue : dtpToDate.Value;
            //+ CCY
            mdListDefaultRateDTO.CCY = cbbCCY.Text.Trim();
            //+ Rate From
            mdListDefaultRateDTO.RateFrom = txtRateFrom.Text.Trim();
            //+ Rate To
            mdListDefaultRateDTO.RateTo = txtRateTo.Text.Trim();

            //Get data collection from database
            mdDefaultRateBUS.GetDefaultRateForList(ref mdListDefaultRateDTO);
            //Suppend Layout
            dtgDefaultRateList.SuspendLayout();
            //Set data collection to grid
            foreach (clsListDefaultRateOnGridDTO objDefaultRateInfo in mdListDefaultRateDTO.LstDefaultRateOnGridDTO)
            {
                row = new DataGridViewRow();
                row.CreateCells(dtgDefaultRateList);
                //+ Input Date From
                row.Cells[dtgDefaultRateList.Columns[m_colFromDate].Index].Value = objDefaultRateInfo.InputDateFrom;
                //+ Input Date To
                row.Cells[dtgDefaultRateList.Columns[m_colToDate].Index].Value = objDefaultRateInfo.InputDateTo;
                //+ CCY
                row.Cells[dtgDefaultRateList.Columns[m_colCCY].Index].Value = objDefaultRateInfo.CCY;
                //+ Rate
                row.Cells[dtgDefaultRateList.Columns[m_colRate].Index].Value = objDefaultRateInfo.Rate;
                //Add Item to List
                lstRows.Add(row);
            }
            //Resume Layout
            dtgDefaultRateList.Rows.AddRange(lstRows.ToArray());
            dtgDefaultRateList.ResumeLayout();
        }

        /// <summary>
        /// Fill data for combobox From Date, To Date
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillDataFromToCombobox()
        {
            List<clsListDefaultRateOnGridDTO> lstFromTo = clsMDDefaultRateBUS.Instance().GetFromToDateList();

            List<CbbObject> lstFrom = new List<CbbObject>();
            List<CbbObject> lstTo = new List<CbbObject>();

            //add new blank data
            lstFrom.Add(new CbbObject(null, string.Empty));
            lstTo.Add(new CbbObject(null, string.Empty));

            if (lstFromTo.Count > 0)
            {
                foreach (clsListDefaultRateOnGridDTO item in lstFromTo)
                {
                    //get data to list to fill combobox from date, to date
                    lstFrom.Add(new CbbObject(item.InputDateFrom, item.InputDateFrom.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY)));
                    lstTo.Add(new CbbObject(item.InputDateTo, item.InputDateTo.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY)));
                }
                //fill data to From Date combobox
                cbbFromDate.DataSource = lstFrom;
                cbbFromDate.DisplayMember = clsMDConstant.DISPLAY;
                cbbFromDate.ValueMember = clsMDConstant.VALUE;
                //fill data to To Date combobox
                cbbToDate.DataSource = lstTo;
                cbbToDate.DisplayMember = clsMDConstant.DISPLAY;
                cbbToDate.ValueMember = clsMDConstant.VALUE;
            }
        }

        #endregion

    }
}