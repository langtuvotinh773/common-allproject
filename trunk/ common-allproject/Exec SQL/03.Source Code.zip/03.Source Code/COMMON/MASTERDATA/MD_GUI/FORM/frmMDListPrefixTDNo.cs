﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage ceiling/floor
 * of Master data module.
 */
using System;
using System.Data;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using System.Collections.Generic;
using Phoenix.Common.MasterData.Dto;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDListPrefixTDNo : frmMDMaster
    {
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        private string m_colPrefixTDNo = "colPrefixTDNo";
        private string m_colCCY = "colCCY";
        private string m_colValue = "colValue";
        private string m_colUpdateBy = "colUpdateBy";
        private string m_colUpdateTime = "colUpdateTime";

        private DataTable m_dtCurrencyMaster;

        private string m_CCY = string.Empty;
        private string m_Value = string.Empty;

        private DateTime? m_UpdateTime;

        private clsMDPrefixTDNoBUS m_PrefixTDNoBus;

        private List<clsMDPrefixTDNoDTO> m_PrefixTDNoList;


        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDListPrefixTDNo()
        {
            try
            {
                InitializeComponent();
                SetFormStyleCommon();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                //fill data combobox CCY
                FillDataComboboxCCY();

                dtpUpdateTime.Value = clsMDBus.Instance().GetServerDateTime();
                dtpUpdateTime.Text = string.Empty;
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        
        #endregion


        #region Event

        /// <summary>
        /// Close form even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Create Ceiling/Floor even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btCreate_Click(object sender, EventArgs e)
        {
            try
            {
                //show form Inquiry Board Rate History
                frmMDAddModifyPrefixTDNo frm = new frmMDAddModifyPrefixTDNo();
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    btnSearch_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Call modify ceiling/floor screen even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgPrefixTDNoList.Rows.Count > 0)
                {
                    short ID = (short)dtgPrefixTDNoList.SelectedRows[0].Cells[m_colPrefixTDNo].Value;
                    //show form Inquiry Board Rate History
                    frmMDAddModifyPrefixTDNo frm = new frmMDAddModifyPrefixTDNo(ID);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        btnSearch_Click(null, null);
                    }
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        clsMDMessage.WARNING_NO_DATA_TO_MODIFY);
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event Searh
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                m_CCY = (string)cbbCCY.SelectedValue;
                m_Value = txtValue.Text.Trim();

                if (clsMDFunction.isNullOrEmpty(dtpUpdateTime.Text))
                {
                    m_UpdateTime = null;
                }
                else
                {
                    m_UpdateTime = dtpUpdateTime.Value;
                }

                m_PrefixTDNoBus = new clsMDPrefixTDNoBUS();
                dtgPrefixTDNoList.Rows.Clear();
                //get list
                m_PrefixTDNoList = m_PrefixTDNoBus.GetPrefixTDNoList(m_CCY, m_Value,m_UpdateTime);

                if (m_PrefixTDNoList.Count > 0)
                {
                    List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
                    DataGridViewRow row;
                    foreach (clsMDPrefixTDNoDTO dto in m_PrefixTDNoList)
                    {
                        row = new DataGridViewRow();
                        row.CreateCells(dtgPrefixTDNoList);
                        row.Cells[dtgPrefixTDNoList.Columns[m_colPrefixTDNo].Index].Value = dto.PrefixTDNo;
                        row.Cells[dtgPrefixTDNoList.Columns[m_colCCY].Index].Value = dto.CCY;
                        row.Cells[dtgPrefixTDNoList.Columns[m_colValue].Index].Value = dto.Value;
                        row.Cells[dtgPrefixTDNoList.Columns[m_colUpdateBy].Index].Value = dto.UserName;
                        row.Cells[dtgPrefixTDNoList.Columns[m_colUpdateTime].Index].Value = dto.UpdateDate == null ? string.Empty
                            : dto.UpdateDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);

                        lstRows.Add(row);
                    }
                    dtgPrefixTDNoList.Rows.AddRange(lstRows.ToArray());
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                       clsMDMessage.NO_TRANSACTION_FOUND);
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        #endregion

       

        #region Function
        /// <summary>
        /// Load data for Combobox Currency
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co        
        /// @endcond
        private void FillDataComboboxCCY()
        {
            //get Currency List
            m_dtCurrencyMaster = clsMDCurrencyMasterBUS.Instance().GetCurrencyList();

            if (m_dtCurrencyMaster == null) return;
            DataRow row = m_dtCurrencyMaster.NewRow();
            row[0] = String.Empty;

            m_dtCurrencyMaster.Rows.InsertAt(row, 0);
            cbbCCY.DataSource = m_dtCurrencyMaster;
            cbbCCY.ValueMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.DisplayMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.SelectedIndex = 0;
        }


        #endregion
    }
}