﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDPreviewBoardRate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dtpPreview = new System.Windows.Forms.DateTimePicker();
            this.btnPreview = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date";
            // 
            // dtpPreview
            // 
            this.dtpPreview.CustomFormat = "dd-MMM-yyyy";
            this.dtpPreview.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPreview.Location = new System.Drawing.Point(66, 19);
            this.dtpPreview.Name = "dtpPreview";
            this.dtpPreview.Size = new System.Drawing.Size(122, 20);
            this.dtpPreview.TabIndex = 1;
            this.dtpPreview.Value = new System.DateTime(2013, 6, 5, 0, 0, 0, 0);
            // 
            // btnPreview
            // 
            this.btnPreview.Location = new System.Drawing.Point(214, 18);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(75, 23);
            this.btnPreview.TabIndex = 2;
            this.btnPreview.Text = "Preview";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // frmMDPreviewBoardRate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 57);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.dtpPreview);
            this.Controls.Add(this.label1);
            this.Name = "frmMDPreviewBoardRate";
            this.Text = "Preview BR\'s template";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpPreview;
        private System.Windows.Forms.Button btnPreview;
    }
}