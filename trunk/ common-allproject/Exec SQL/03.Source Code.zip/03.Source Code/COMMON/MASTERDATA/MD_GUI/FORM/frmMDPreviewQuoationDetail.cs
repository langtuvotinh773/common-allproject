﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to preview quotation detail
 * of Master data module.
 */
using System;
using System.Data;
using Phoenix.Common.MasterData.Dto;
using Config.Classes; 
using Microsoft.Reporting.WinForms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Gui.Report;
using System.Collections.Generic;
using System.Text;
namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDPreviewQuoationDetail : frmMDMaster
	{
        // For Security Checking
        clsSEAuthorizer m_Security = null;
		/// <summary>
		/// USD quotation detail table
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private DataTable m_DTBQuotationDetailUSD;
		/// <summary>
		/// VND quotation detail table
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private DataTable m_DTBQuotationDetailVND;
		/// <summary>
		/// EC/Rate quotation detail table
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private DataTable m_DTBQuotationECRate;
		/// <summary>
		/// Quotation Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsMDQuotationDTO m_QuotationObj;
		/// <summary>
		/// Project name
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string m_ProjectName = "MASTERDATA\\MD";
		/// <summary>
		/// Quotation Bus - Being used to access database
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsMDQuoationBus m_MDQuoationBus = new clsMDQuoationBus();
        public int QuotationId { get; set; }

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmMDPreviewQuoationDetail()
		{
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                QuotationId = m_MDQuoationBus.GetQuotationIDLast();
                if (QuotationId > 0 )
                {
                    m_QuotationObj = m_MDQuoationBus.GetQuotationDetail(QuotationId); 
                    m_DTBQuotationECRate = m_MDQuoationBus.GetQuotationECRate(QuotationId);
                    m_DTBQuotationDetailUSD = m_MDQuoationBus.GetQuotationDetailUSD(QuotationId);
                    m_DTBQuotationDetailVND = m_MDQuoationBus.GetQuotationDetailVND(QuotationId);                    
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, "There is no approved daily quotation in today.");                    
                }

            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}
		 
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="dtbQuotationDetailUSD">USD quotation detail table</param>
		/// <param name="dtbQuotationDetailVND">VND quotation detail table</param>
		/// <param name="dtbQuotationECRate">EC/Rate quotation detail table</param>
		/// <param name="quotationDetailObj">Quotation Object</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmMDPreviewQuoationDetail(DataTable dtbQuotationDetailUSD,	DataTable dtbQuotationDetailVND, DataTable dtbQuotationECRate, clsMDQuotationDTO quotationDetailObj)
		{
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_DTBQuotationDetailUSD = dtbQuotationDetailUSD;
                m_DTBQuotationDetailVND = dtbQuotationDetailVND;
                m_DTBQuotationECRate = dtbQuotationECRate;
                m_QuotationObj = quotationDetailObj;
                QuotationId = m_QuotationObj.QuotationID;
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}              
	
		/// <summary>
		/// Form load even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void frmMDPreviewQuoationDetail_Load(object sender, EventArgs e)
		{
			try
			{
                //Declaration
                dtsQuotation dtMDsQuoationDetailObj = new dtsQuotation();

                //Set data for tables
                foreach (DataRow row in m_DTBQuotationDetailUSD.Rows)
                {
                    string strFormatNumberUSD = row["FormatNumber"].ToString();
                    dtMDsQuoationDetailObj.QuotationDetailUSD.Rows.Add(
                        row["ExchangeCCYPair"],
                        FormatNumber(row["TTM"], strFormatNumberUSD),
                        FormatNumber(row["TTB"], strFormatNumberUSD),
                        FormatNumber(row["TTS"], strFormatNumberUSD),
                        FormatNumber(row["CSB"], strFormatNumberUSD),
                        FormatNumber(row["CSS"], strFormatNumberUSD),
                        FormatNumber(row["TTBRate"], strFormatNumberUSD),
                        FormatNumber(row["TTSRate"], strFormatNumberUSD));
                }
                foreach (DataRow row in m_DTBQuotationDetailVND.Rows)
                {
                    string strFormatNumberVND = row["FormatNumber"].ToString();
                    dtMDsQuoationDetailObj.QuotationDetailVND.Rows.Add(
                        row["ExchangeCCYPair"],
                        FormatNumber(row["TTM"], strFormatNumberVND),
                        FormatNumber(row["TTB"], strFormatNumberVND),
                        FormatNumber(row["TTS"], strFormatNumberVND),
                        FormatNumber(row["CSB"], strFormatNumberVND),
                        FormatNumber(row["CSS"], strFormatNumberVND));
                }
                foreach (DataRow row in m_DTBQuotationECRate.Rows)
                {
                    dtMDsQuoationDetailObj.QuotationECRate.Rows.Add(
                        row["ExchangeCCYPairID"],
                        row["CustRateBuy"],
                        row["AGroupECBuy"],
                        row["BGroupECBuy"],
                        row["CustRateSell"],
                        row["AGroupECSell"],
                        row["BGroupECSell"],
                        row["ExchangeCCYPair"]);
                }
                List<string> lstNoteEnd = clsMDFunction.AnalyzeNoteEnd(m_QuotationObj.NoteEnd);
                ////Intialize reporting
                ////+ Title
                ReportParameter[] reportParameters = new ReportParameter[13];
                reportParameters[0] = new ReportParameter("NoteHead", m_QuotationObj.NoteHead);
                reportParameters[1] = new ReportParameter("ImportTime", m_QuotationObj.ImportTime.ToString("dd-MMM-yyyy"));
                reportParameters[2] = new ReportParameter("EffectiveTime", m_QuotationObj.EffectiveTime);
                reportParameters[3] = new ReportParameter("Seq", m_QuotationObj.Seq.ToString());
                reportParameters[4] = new ReportParameter("CentralBankCoreRate", m_QuotationObj.CentralBankCoreRate);
                reportParameters[5] = new ReportParameter("TC", m_QuotationObj.TC);
                //vlhcnhung start
                string strThreshold = m_QuotationObj.NoteThreshold.Trim();
                string strThresholdParam = clsMDBus.Instance().GetParamThreshold();
                string strThreholdValue = clsMDQuoationBus.Instance().GetThresholdValue();
                if (strThreshold.IndexOf(strThresholdParam) > -1)
                {
                    strThreshold = strThreshold.Replace(strThresholdParam, strThreholdValue);
                }
                reportParameters[6] = new ReportParameter("NoteThreshold", strThreshold);
                //vlhcnhung end 
                reportParameters[7] = new ReportParameter("NoteMid", m_QuotationObj.NoteMid);
                reportParameters[8] = new ReportParameter("NoteEnd", lstNoteEnd[0]);
                reportParameters[9] = new ReportParameter("CeilingRate", FormatNumber(m_QuotationObj.CeilingRate.ToString(), DECIMAL_FORMAT));
                reportParameters[10] = new ReportParameter("FloorRate", FormatNumber(m_QuotationObj.FloorRate.ToString(), DECIMAL_FORMAT));
                reportParameters[11] = new ReportParameter("Stt", clsMDNumberUtil.toOrdinal(m_QuotationObj.Seq));
                reportParameters[12] = new ReportParameter("NoteEnd2", lstNoteEnd[1]);

                ////+ Load report
                this.rptQuotationDetail.ProcessingMode = Microsoft.Reporting.WinForms.ProcessingMode.Local;
                this.rptQuotationDetail.LocalReport.ReportPath = AppDomain.CurrentDomain.BaseDirectory + m_ProjectName + "_GUI\\REPORT\\rptMDQuotationrdlc.rdlc";
                this.rptQuotationDetail.LocalReport.DataSources.Clear();

                //+ Add parameters
                this.rptQuotationDetail.LocalReport.SetParameters(reportParameters);
                ////+ Add parameters

                this.rptQuotationDetail.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource(
                    "Quotation_QuotationDetailUSD", dtMDsQuoationDetailObj.QuotationDetailUSD));

                this.rptQuotationDetail.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource(
                    "Quotation_QuotationDetailVND", dtMDsQuoationDetailObj.QuotationDetailVND));

                this.rptQuotationDetail.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource(
                    "Quotation_QuotationECRate", dtMDsQuoationDetailObj.QuotationECRate));

                this.rptQuotationDetail.DocumentMapCollapsed = true;
                //Refresh reporting
                this.rptQuotationDetail.RefreshReport();
			}
			catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);          
            }
		}
	}
}