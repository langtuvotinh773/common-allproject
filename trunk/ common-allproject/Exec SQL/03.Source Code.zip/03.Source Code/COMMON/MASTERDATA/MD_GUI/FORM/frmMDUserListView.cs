﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-15 (Fri, 15 March 2013) $
 * ========================================================
 * This class is used to view User List
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using System.Collections;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Gui;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDUserListView : frmMDMaster
    {
        #region Global Variable
        DataTable m_DataTable = null;
        DataView m_DataView = null;
        // For Security Checking
        clsSEAuthorizer m_Security = null;
		bool CommonError = false;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMasUserListView class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDUserListView()
        {
            InitializeComponent();            
            try
            {
				// Check authorization
				m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
				m_Security.CheckAuthorizationOnScreen(this);
                this.Text = clsMDConstant.USER_TITLE_LIST;
                m_DataView = new DataView();
                //Get all list user
                GetUserList();
                //Load data for combo box
                LoadComboBoxDepartment();
                LoadComboBoxTeam();
                LoadOfficerStaffLockoutComboBox(cbbOfficer);
                LoadOfficerStaffLockoutComboBox(cbbStaff01);
                LoadOfficerStaffLockoutComboBox(cbbStaff02);
                LoadOfficerStaffLockoutComboBox(cbbLockout);
            }
            catch (Exception ex)
            {                
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
				CommonError = true;
            }
        }
        #endregion 

        #region Event Functions
        /// <summary>
        /// Event form load, system will load data default:
        /// Data for ComboBox Department
        /// Data for ComboBox Team
        /// Data for DataGridView User
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmMDUserListView_Load(object sender, EventArgs e)
        {			
            try
            {
                //Set common style for form
                SetFormStyleCommon();                
            }
            catch (Exception ex)
            {                
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        } 

        /// <summary>
        /// Event click button "Search"
        /// Get list of users based on input params(Department, Team, User Name, Full/Short Name, Office, Staff01, Staff02, Lockout)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {            
            try
            {
                SearchUsers(GetInputParams());
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click button "Create" to tranfer Create User screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnCreate_Click(object sender, EventArgs e)
        {
            //tranfer to Create Screen
            frmMDUserAddModify frm = new frmMDUserAddModify(clsMDConstant.USER_TITLE_CREATE);
            frm.OnSaved += new EventHandler(frmNewModify_OnSaved);
            frm.m_CurrentAction = CommonValue.ActionType.New;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        /// <summary>
        /// Event click button "Modify" to tranfer Modify User screen
        /// User must select a user to modify
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnModify_Click(object sender, EventArgs e)
        {            
            try
            {
                if (dtgUserList.SelectedRows.Count > 0)
                {
                    if (dtgUserList.SelectedRows.Count > 1)
                    {
                        //if user choose more than one item on grid
                        //display message to require user choose one item on grid before click modify button
                        //'Please select a user to modify.'
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "modify"));
                    }
                    else
                    {
                        frmMDUserAddModify frmModify = new frmMDUserAddModify(clsMDConstant.USER_TITLE_MODIFY);
                        //define action after called save action on frmMDUserAddModify screen
                        frmModify.OnSaved += new EventHandler(frmNewModify_OnSaved);
                        //set updated object
                        frmModify.m_CurrentAction = CommonValue.ActionType.Update;
                        //get selected user
                        DataGridViewRow rowSelected = dtgUserList.CurrentRow;
                        frmModify.m_UpdatingUser.UserNo = int.Parse(rowSelected.Cells[clsMDConstant.MD_COL_USER_NO].Value.ToString());
                        frmModify.m_UpdatingUser = clsMDUserBUS.Instance().GetUser(frmModify.m_UpdatingUser.UserNo);
                        
                        if (frmModify.m_UpdatingUser != null)
                        {
                            //load information of user to Create Screen
                            frmModify.SetData(frmModify.m_UpdatingUser);
                            frmModify.StartPosition = FormStartPosition.CenterScreen;
                            frmModify.ShowDialog();
                        }
                        else
                        {
                            //if system can not get information of selected object
                            //display error message
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.ERROR_NOT_FOUND_ITEM);
                        }
                    }
                }
                else
                {
                    //display message to require user choose one item on grid before click modify button
                    //'Please select a user to modify.'
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "modify"));
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click button "Delete" to delete User
        /// User must select a user to delete
        /// System set DelFlag = 1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //disable all button while system excute delete function, user can not excute any other action.
            EnableButtonControl(false);
            try
            {                
                DeleteUser();                
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button while system finish search function.
            EnableButtonControl(true);      
        }

        /// <summary>
        /// Event click button "Assign Role" to tranfer Assign Users To Role screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnAssignRole_Click(object sender, EventArgs e)
        {
            if (dtgUserList.SelectedRows.Count > 0)
            {
                DataGridViewRow rowSelected = dtgUserList.CurrentRow;
                frmSecurityAssignRoleToUser frm = new frmSecurityAssignRoleToUser(int.Parse(rowSelected.Cells[clsMDConstant.MD_COL_USER_NO].Value.ToString()));
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
            }
            else
            {
                //display message to require user choose one item on grid before click assign button
                //'Please select a user to assign.'
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "assign"));
            }
        }

        /// <summary>
        /// Event click button "Assign Department" to tranfer Assign Users To Department screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnAssignDept_Click(object sender, EventArgs e)
        {
            if (dtgUserList.SelectedRows.Count > 0)
            {
                frmMDAssignUserToDepartment frm = new frmMDAssignUserToDepartment();
                frm.OnSaved += new EventHandler(frmNewModify_OnSaved);

                DataGridViewRow rowSelected = dtgUserList.CurrentRow;
                frm.iSelectedUser = int.Parse(rowSelected.Cells[clsMDConstant.MD_COL_USER_NO].Value.ToString());

                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
            }
            else
            {
                //display message to require user choose one item on grid before click assign button
                //'Please select a user to assign.'
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "assign"));
            }
        }

        /// <summary>
        /// Event click button "Assign Team" to tranfer Assign User To Team screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnAssignTeam_Click(object sender, EventArgs e)
        {
            if (dtgUserList.SelectedRows.Count > 0)
            {
                frmMDAssignUsersToTeam frm = new frmMDAssignUsersToTeam();
                frm.OnSaved += new EventHandler(frmNewModify_OnSaved);

                DataGridViewRow rowSelected = dtgUserList.CurrentRow;
                frm.iSelectedUser= int.Parse(rowSelected.Cells[clsMDConstant.MD_COL_USER_NO].Value.ToString());

                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
            }
            else
            {
                //display message to require user choose one item on grid before click assign button
                //'Please select a user to assign.'
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "assign"));
            }
        }

        /// <summary>
        /// Event click button "Close"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        private void frmMDUserListView_Shown(object sender, EventArgs e)
        {
            if (CommonError)
            {
                this.Close();
            }
        }
        #endregion

        #region Member Methods  
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnSearch.Enabled = value;
            btnCreate.Enabled = value;
            btnModify.Enabled = value;
            btnDelete.Enabled = value;
            btnAssignDept.Enabled = value;
            btnAssignRole.Enabled = value;
            btnAssignTeam.Enabled = value;
            btnClose.Enabled = value;
            if (value == true)
            {
                //check security
                if (btnSearch.Tag != null && !string.IsNullOrEmpty(btnSearch.Tag.ToString()))
                {
                    btnSearch.Enabled = bool.Parse(btnSearch.Tag.ToString());
                }
                if (btnCreate.Tag != null && !string.IsNullOrEmpty(btnCreate.Tag.ToString()))
                {
                    btnCreate.Enabled = bool.Parse(btnCreate.Tag.ToString());
                }
                if (btnModify.Tag != null && !string.IsNullOrEmpty(btnModify.Tag.ToString()))
                {
                    btnModify.Enabled = bool.Parse(btnModify.Tag.ToString());
                }
                if (btnDelete.Tag != null && !string.IsNullOrEmpty(btnDelete.Tag.ToString()))
                {
                    btnDelete.Enabled = bool.Parse(btnDelete.Tag.ToString());
                }
                if (btnAssignDept.Tag != null && !string.IsNullOrEmpty(btnAssignDept.Tag.ToString()))
                {
                    btnAssignDept.Enabled = bool.Parse(btnAssignDept.Tag.ToString());
                }
                if (btnAssignRole.Tag != null && !string.IsNullOrEmpty(btnAssignRole.Tag.ToString()))
                {
                    btnAssignRole.Enabled = bool.Parse(btnAssignRole.Tag.ToString());
                }
                if (btnAssignTeam.Tag != null && !string.IsNullOrEmpty(btnAssignTeam.Tag.ToString()))
                {
                    btnAssignTeam.Enabled = bool.Parse(btnAssignTeam.Tag.ToString());
                }
                //check logic
                if (m_DataTable != null && m_DataTable.Rows.Count == 0)
                {
                    btnDelete.Enabled = false;
                    btnModify.Enabled = false;
                    btnAssignTeam.Enabled = false;
                    btnAssignDept.Enabled = false;
                }
            }
        }

        /// <summary>
        /// Get list of all users when form load
        /// Not get input params
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetUserList()
        {
            m_DataTable = clsMDUserBUS.Instance().GetUserList(new clsMDUserDTO());
            UpdateGridView(m_DataTable);  
            this.cbbDepartment.Focus();
        }

        /// <summary>
        /// update DataSource of User DataGridView
        /// </summary>
        /// <param name="user">DataTable</param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void UpdateGridView(DataTable user)
        {
            user.TableName = "User";
            m_DataView.Table = user;
            dtgUserList.AutoGenerateColumns = false;
            dtgUserList.DataSource = m_DataView;           
        }

        /// <summary>
        /// Get list of departments for cbbDepartment
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void LoadComboBoxDepartment()
        {
            DataTable depts = clsMDDepartmentBUS.Instance().GetAllDepartmentList();
            if (depts == null) return;

            depts.Rows.InsertAt(depts.NewRow(), 0);
            depts.AcceptChanges();

            cbbDepartment.DataSource = depts;
            cbbDepartment.ValueMember = clsMDConstant.MD_COL_DEPARTMENTID;
            cbbDepartment.DisplayMember = clsMDConstant.MD_COL_DEPARTMENTNAME;
            cbbDepartment.SelectedIndex = 0;
        }

        /// <summary>
        /// Get list of teams for cbbTeam
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void LoadComboBoxTeam()
        {
            DataTable teams = clsMDTeamBUS.Instance().GetAllTeamList();
            if (teams == null) return;

            teams.Rows.InsertAt(teams.NewRow(), 0);
            teams.AcceptChanges();

            cbbTeam.DataSource = teams;
            cbbTeam.ValueMember = clsMDConstant.MD_COL_TEAMID;
            cbbTeam.DisplayMember = clsMDConstant.MD_COL_TEAMNAME;
            cbbTeam.SelectedIndex = 0;
        }

        /// <summary>
        /// Get list of users based on input params search
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void SearchUsers(clsMDUserDTO dto)
        {
            //disable all button while system excute search function.
            EnableButtonControl(false);
            m_DataTable = clsMDUserBUS.Instance().GetUserList(dto);
            UpdateGridView(m_DataTable);            
            if (m_DataTable == null || (m_DataTable != null && m_DataTable.Rows.Count == 0))
            {
                //display message 'No transaction found!'
                clsMDMesageCollection.MessageNoTransactions();                
            }
            //enable all button while system finish search function.
            EnableButtonControl(true);
        }

        /// <summary>
        /// Get values of params to search
        /// </summary>
        /// <returns>clsMDUserDTO</returns>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private clsMDUserDTO GetInputParams()
        {
            clsMDUserDTO dto = new clsMDUserDTO();
            if (String.IsNullOrEmpty(cbbDepartment.Text.Trim()))
            {
                dto.DepartmentID = -1;
            }
            else
            {
                if (cbbDepartment.FindStringExact(cbbDepartment.Text.Trim()) < 0)
                {
                    dto.DepartmentID = -1;
                }
                else
                {
                    dto.DepartmentID = int.Parse(cbbDepartment.SelectedValue.ToString());
                }
            }
            if (String.IsNullOrEmpty(cbbTeam.Text.Trim()))
            {
                dto.TeamID = -1;
            }
            else
            {
                if (cbbTeam.FindStringExact(cbbTeam.Text.Trim()) < 0)
                {
                    dto.TeamID = -1;
                }
                else
                {
                    dto.TeamID = int.Parse(cbbTeam.SelectedValue.ToString());
                }
            }
            dto.UserName = txtUserName.Text.Trim();
            dto.FullShortName = txtFullShortName.Text.Trim();
            if(string.IsNullOrEmpty(cbbOfficer.Text.Trim()))
            {
                dto.Officer = string.Empty;
            }else
            {
                dto.Officer = cbbOfficer.SelectedValue.ToString();
            }
            if (string.IsNullOrEmpty(cbbStaff01.Text.Trim()))
            {
                dto.Staff01 = string.Empty;
            }
            else
            {
                dto.Staff01 = cbbStaff01.SelectedValue.ToString();
            }
            if (string.IsNullOrEmpty(cbbStaff02.Text.Trim()))
            {
                dto.Staff02 = string.Empty;
            }
            else
            {
                dto.Staff02 = cbbStaff02.SelectedValue.ToString();
            }
            if (string.IsNullOrEmpty(cbbLockout.Text.Trim()))
            {
                dto.Lockout = string.Empty;
            }
            else
            {
                dto.Lockout = cbbLockout.SelectedValue.ToString();
            }
            return dto;
        }

        /// <summary>
        /// Delete selected user
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void DeleteUser()
        {            
            if (dtgUserList.SelectedRows.Count > 0)
            {
                //display confirm message 'Are you sure to delete this user?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, string.Format(clsMDMessage.CONFIRM_ACTION_DELETE_DATA, "user"));
                if (res == DialogResult.Yes)
                {                   
                    DataGridViewRow dataRow = dtgUserList.CurrentRow;
                    int iUserNo = int.Parse(dataRow.Cells[clsMDConstant.MD_COL_USER_NO].Value.ToString());

                    //create data for save log
                    clsMDLogBase logBase = new clsMDLogBase();
                    logBase.ApplicationName = this.Text;
                    logBase.UserID = clsUserInfo.UserNo.ToString();
                    logBase.Module = clsMDConstant.MODULE_SE;
                    logBase.Action = (int)CommonValue.ActionType.Delete;
                    logBase.Key = dataRow.Cells[clsMDConstant.MD_COL_USERNAME].Value.ToString()
                                    + " " + dataRow.Cells[clsMDConstant.MD_COL_USER_NO].Value.ToString();

                    //Delete logic User and Write Delete information to Log History
                    int iRow = clsMDUserBUS.Instance().DeleteUser(iUserNo, logBase);
                    if (iRow > 0)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Deleting", "user"));

                        //Refresh data on grid after delete
                        SearchUsers(GetInputParams());  
                    }
                    else if (iRow == 0)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Deleting", "user"));

                        //Refresh data on grid after delete
                        SearchUsers(GetInputParams());
                    }
                    //else
                    //{
                    //    this.Close();
                    //}
                } 
            }
            else
            {
                //display message to require user choose one item on grid before click delete button
                //'Please select a user to delete.'
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "delete"));
            }            
        }

        /// <summary>
        /// Define EventHandle after excute action save in frmMasUserAddMofidify
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmNewModify_OnSaved(object sender, EventArgs e)
        {
            //2013.06.11 UDP vlhcnhung S Reload data on grid after create/modify user
            //GetUserList();       
            SearchUsers(GetInputParams());
            //2013.06.11 UDP vlhcnhung E Reload data on grid after create/modify user
            EnableButtonControl(true);
        }
        #endregion

        
    }
}
