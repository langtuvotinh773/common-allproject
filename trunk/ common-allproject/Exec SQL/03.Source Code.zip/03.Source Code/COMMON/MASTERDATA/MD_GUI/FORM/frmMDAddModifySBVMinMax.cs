﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage ceiling floor
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;
using System.Data;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDAddModifySBVMinMax : frmMDMaster
    {
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        //If ModeAdd = true: form used to add data
        //If ModeAdd = false: form used to modify data
        private bool m_ModeAdd = true;
        private clsMDSBVMinMaxDTO m_SBVMinMaxDto;
        private clsMDSBVMinMaxBUS m_SBVMinMaxBus;
        private string m_TitleCreate = "Create SBV Min/Max";
        private string m_TitleModify = "Modify SBV Min/Max";
        #region Constructor

        /// <summary>
        /// Constructor fro Add data
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDAddModifySBVMinMax()
        {
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_ModeAdd = true;
                this.Text = m_TitleCreate;
                m_SBVMinMaxDto = new clsMDSBVMinMaxDTO();

                //fill data to combobox CCY
                FillDataComboboxCCY();
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Constructor for modify data
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDAddModifySBVMinMax(short ID)
        {
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_ModeAdd = false;
                this.Text = m_TitleModify;
                m_SBVMinMaxDto = new clsMDSBVMinMaxDTO();
                
                //fill data to combobox CCY
                FillDataComboboxCCY();

                m_SBVMinMaxDto = clsMDSBVMinMaxBUS.Instance().GetSBVMinMax(ID);

                if (m_SBVMinMaxDto != null)
                {
                    FillDataToUpdate();
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                           String.Format(clsMDMessage.ERROR_IS_DELETE, "Data"));
                    this.Close();
                }

            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Event
        /// <summary>
        /// Cancel even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Save Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //check data on form
                if (!IsCheckDataInputOnForm())
                {
                    return;
                }
                DialogResult dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                    clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);

                if (dialog == DialogResult.Yes)
                {
                    if (m_ModeAdd)
                    {
                        //insert data
                        SaveData();
                    }
                    else
                    {
                        //Update data
                        UpdateData();
                    }
                }
            }
            catch (Exception ex)
            {
                try
                {
                    //rollback data
                    m_SBVMinMaxBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }


        /// <summary>
        /// Form Closing Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void frmMDAddModifySBVMinMax_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    if (IsChangeValueOnForm())
                    {
                        DialogResult dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                            clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                        if (dialog == DialogResult.Yes)
                        {
                            if (m_ModeAdd)
                            {
                                //insert data
                                SaveData();
                            }
                            else
                            {
                                //Update data
                                UpdateData();
                            }
                        }
                        else if (dialog == DialogResult.No)
                        {
                            e.Cancel = false;
                        }
                        else if (dialog == DialogResult.Cancel)
                        {
                            e.Cancel = true;
                        }
                    }
                }
                else
                {
                    //close form
                    this.FormClosing -= new FormClosingEventHandler(frmMDAddModifySBVMinMax_FormClosing);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                try
                {
                    //rollback data
                    m_SBVMinMaxBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }


        #endregion

        #region Private Function

        /// <summary>
        /// Load data for Combobox Currency
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co        
        /// @endcond
        private void FillDataComboboxCCY()
        {
            //get Currency List
            DataTable m_dtCurrencyMaster = clsMDCurrencyMasterBUS.Instance().GetCurrencyList();

            if (m_dtCurrencyMaster == null) return;
            DataRow row = m_dtCurrencyMaster.NewRow();
            row[0] = String.Empty;
            m_dtCurrencyMaster.Rows.InsertAt(row, 0);

            cbbCCY.DataSource = m_dtCurrencyMaster;
            cbbCCY.ValueMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.DisplayMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.SelectedIndex = 0;

        }

        /// <summary>
        /// Fill Data to update
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillDataToUpdate()
        {
            cbbCCY.SelectedValue = m_SBVMinMaxDto.CCY;
            txtTenors.Text = m_SBVMinMaxDto.Tenor;
            txtDepositMin.Text = m_SBVMinMaxDto.DepositMin.ToString();
            txtDepositMax.Text = m_SBVMinMaxDto.DepositMax.ToString();
            txtLoanMin.Text = m_SBVMinMaxDto.TDMin.ToString();
            txtLoanMax.Text = m_SBVMinMaxDto.TDMax.ToString();
        }

        /// <summary>
        /// Save data
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool SaveData()
        {
            m_SBVMinMaxBus = new clsMDSBVMinMaxBUS();
            //get data for insert Applicant
            GetDataValueInsert();
            //used to check data input database
            int returnValue = m_SBVMinMaxBus.InsertSBVMinMax(m_SBVMinMaxDto);
            if (returnValue > 0)
            {
                //write log history
                WriteLogInsert(m_SBVMinMaxDto);
                //commit data
                m_SBVMinMaxBus.Commit();
                //show message after save data is success
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                    clsMDMessage.DATA_WAS_SAVED_SUCCESSFULLY);
                frmMDAddModifySBVMinMax_FormClosing(null, null);
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                //rollback data
                m_SBVMinMaxBus.RollBack();
                //show message after save data failed
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    clsMDMessage.DATA_WAS_SAVED_UN_SUCCESSFULLY);
                return false;
            }

            return true;
        }


        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool UpdateData()
        {
            m_SBVMinMaxBus = new clsMDSBVMinMaxBUS();
            clsMDSBVMinMaxDTO dto = new clsMDSBVMinMaxDTO();
            //get data for insert Applicant

            GetDataValueUpdate(dto);
            //used to check data input database
            int returnValue = m_SBVMinMaxBus.UpdateSBVMinMax(dto);
            if (returnValue > 0)
            {
                //write log history
                WriteLogUpdate(dto);
                //commit data
                m_SBVMinMaxBus.Commit();
                //show message after save data is success
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                    clsMDMessage.DATA_WAS_SAVED_SUCCESSFULLY);
                frmMDAddModifySBVMinMax_FormClosing(null, null);
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                //rollback data
                m_SBVMinMaxBus.RollBack();
                //show message after save data failed
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    clsMDMessage.DATA_WAS_SAVED_UN_SUCCESSFULLY);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Get Data to save
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataValueInsert()
        {
            //get data on form 
            m_SBVMinMaxDto.CCY = (string)cbbCCY.SelectedValue;
            m_SBVMinMaxDto.Tenor = txtTenors.Text.Trim();
            m_SBVMinMaxDto.TransType = clsMDConstant.SBV_MIN_MAX_TRANS_TYPE_DEPOSIT;

            m_SBVMinMaxDto.DepositMin = clsMDFunction.isNullOrEmpty(txtDepositMin.Text.Trim()) == true ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtDepositMin.Text.Trim()).Value;
            m_SBVMinMaxDto.DepositMax = clsMDFunction.isNullOrEmpty(txtDepositMax.Text.Trim()) == true ? 0
                            : clsMDFunction.ConvertObjectToNullDecimal(txtDepositMax.Text.Trim()).Value;

            m_SBVMinMaxDto.TDMin = clsMDFunction.isNullOrEmpty(txtLoanMin.Text.Trim()) == true ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtLoanMin.Text.Trim()).Value;
            m_SBVMinMaxDto.TDMax = clsMDFunction.isNullOrEmpty(txtLoanMax.Text.Trim()) == true ? 0
                            : clsMDFunction.ConvertObjectToNullDecimal(txtLoanMax.Text.Trim()).Value;

        }

        /// <summary>
        /// Get Data to save
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataValueUpdate(clsMDSBVMinMaxDTO dto)
        {
            dto.SBVMinMaxID = m_SBVMinMaxDto.SBVMinMaxID;
            //get data on form 
            dto.CCY = (string)cbbCCY.SelectedValue;
            dto.Tenor = txtTenors.Text.Trim();
            dto.TransType = clsMDConstant.SBV_MIN_MAX_TRANS_TYPE_DEPOSIT;

            dto.DepositMin = clsMDFunction.isNullOrEmpty(txtDepositMin.Text.Trim()) == true ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtDepositMin.Text.Trim()).Value;
            dto.DepositMax = clsMDFunction.isNullOrEmpty(txtDepositMax.Text.Trim()) == true ? 0
                            : clsMDFunction.ConvertObjectToNullDecimal(txtDepositMax.Text.Trim()).Value;

            dto.TDMin = clsMDFunction.isNullOrEmpty(txtLoanMin.Text.Trim()) == true ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtLoanMin.Text.Trim()).Value;
            dto.TDMax = clsMDFunction.isNullOrEmpty(txtLoanMax.Text.Trim()) == true ? 0
                            : clsMDFunction.ConvertObjectToNullDecimal(txtLoanMax.Text.Trim()).Value;

        }

        /// <summary>
        /// Check Data Input On Form
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsCheckDataInputOnForm()
        {

            if (String.IsNullOrEmpty(clsMDFunction.ConvertObjectToString(cbbCCY.SelectedValue)))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblCCY.Text));
                cbbCCY.Focus();
                return false;
            }
            if (String.IsNullOrEmpty(txtTenors.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblTenors.Text));
                txtTenors.Focus();
                return false;
            }

            if (String.IsNullOrEmpty(txtDepositMin.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblDepositMin.Text));
                txtDepositMin.Focus();
                return false;
            }

            if (String.IsNullOrEmpty(txtDepositMax.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblDepositMax.Text));
                txtDepositMax.Focus();
                return false;
            }

            if (String.IsNullOrEmpty(txtLoanMin.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblLoanMin.Text));
                txtLoanMin.Focus();
                return false;
            }

            if (String.IsNullOrEmpty(txtLoanMax.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblLoanMax.Text));
                txtLoanMax.Focus();
                return false;
            }

            Decimal depositMin = clsMDFunction.ConvertObjectToNullDecimal(txtDepositMin.Text.Trim()) == null ? 0
               : clsMDFunction.ConvertObjectToNullDecimal(txtDepositMin.Text.Trim()).Value;
            Decimal depositMax = clsMDFunction.ConvertObjectToNullDecimal(txtDepositMax.Text.Trim()) == null ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtDepositMax.Text.Trim()).Value;
            Decimal loanMin = clsMDFunction.ConvertObjectToNullDecimal(txtLoanMin.Text.Trim()) == null ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtLoanMin.Text.Trim()).Value;
            Decimal loanMax = clsMDFunction.ConvertObjectToNullDecimal(txtLoanMax.Text.Trim()) == null ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtLoanMax.Text.Trim()).Value;

            if (depositMin > depositMax)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_SMALLER_THAN_OR_EQUAL, lblDepositMin.Text, lblDepositMax.Text));
                return false;
            }

            if (loanMin > loanMax)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_SMALLER_THAN_OR_EQUAL, lblLoanMin.Text, lblLoanMax.Text));
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check data is changed on form
        /// Return true data is changed
        /// Return false data is not changed
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsChangeValueOnForm()
        {
            //check data is changed on form
            if (!clsMDFunction.ConvertObjectToString(m_SBVMinMaxDto.CCY).Equals(clsMDFunction.ConvertObjectToString(cbbCCY.SelectedValue)))
            {
                return true;
            }

            if (!clsMDFunction.ConvertObjectToString(m_SBVMinMaxDto.Tenor).Equals(txtTenors.Text.Trim()))
            {
                return true;
            }

            Decimal depositMin = clsMDFunction.ConvertObjectToNullDecimal(txtDepositMin.Text.Trim()) == null ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtDepositMin.Text.Trim()).Value;

            if (m_SBVMinMaxDto.DepositMin != depositMin)
            {
                return true;
            }

            Decimal depositMax = clsMDFunction.ConvertObjectToNullDecimal(txtDepositMax.Text.Trim()) == null ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtDepositMax.Text.Trim()).Value;

            if (m_SBVMinMaxDto.DepositMax != depositMax)
            {
                return true;
            }

            Decimal loanMin = clsMDFunction.ConvertObjectToNullDecimal(txtLoanMin.Text.Trim()) == null ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtLoanMin.Text.Trim()).Value;

            if (m_SBVMinMaxDto.TDMin != loanMin)
            {
                return true;
            }

            Decimal loanMax = clsMDFunction.ConvertObjectToNullDecimal(txtLoanMax.Text.Trim()) == null ? 0
                : clsMDFunction.ConvertObjectToNullDecimal(txtLoanMax.Text.Trim()).Value;
            if (m_SBVMinMaxDto.TDMax != loanMax)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Write log update status
        /// </summary>
        /// <param name="key"></param>
        /// <param name="iOldStatus"></param>
        /// <param name="iNewSatus"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLogInsert(clsMDSBVMinMaxDTO dto)
        {
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = dto.SBVMinMaxID.ToString();
            logBase.Action = (int)CommonValue.ActionType.New;

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblCCY.Text,
                    OldValue = String.Empty,
                    NewValue = dto.CCY
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblTenors.Text,
                    OldValue = String.Empty,
                    NewValue = dto.Tenor
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblDepositMin.Text,
                    OldValue = String.Empty,
                    NewValue = dto.DepositMin.ToString()
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblDepositMax.Text,
                    OldValue = String.Empty,
                    NewValue = dto.DepositMax.ToString()
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblLoanMin.Text,
                    OldValue = String.Empty,
                    NewValue = dto.TDMin.ToString()
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblLoanMax.Text,
                    OldValue = String.Empty,
                    NewValue = dto.TDMax.ToString()
                });

            logBase.WirteLog(m_SBVMinMaxBus.DAL);
        }

        /// <summary>
        /// Write log update status
        /// </summary>
        /// <param name="key"></param>
        /// <param name="iOldStatus"></param>
        /// <param name="iNewSatus"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLogUpdate(clsMDSBVMinMaxDTO dto)
        {
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = dto.SBVMinMaxID.ToString();
            logBase.Action = (int)CommonValue.ActionType.Update;

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblCCY.Text,
                    OldValue = m_SBVMinMaxDto.CCY,
                    NewValue = dto.CCY
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblTenors.Text,
                    OldValue = m_SBVMinMaxDto.Tenor,
                    NewValue = dto.Tenor
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblDepositMin.Text,
                    OldValue = m_SBVMinMaxDto.DepositMin.ToString(),
                    NewValue = dto.DepositMin.ToString()
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblDepositMax.Text,
                    OldValue = m_SBVMinMaxDto.DepositMax.ToString(),
                    NewValue = dto.DepositMax.ToString()
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblLoanMin.Text,
                    OldValue = m_SBVMinMaxDto.TDMin.ToString(),
                    NewValue = dto.TDMin.ToString()
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblLoanMax.Text,
                    OldValue = m_SBVMinMaxDto.TDMax.ToString(),
                    NewValue = dto.TDMax.ToString()
                });

            logBase.WirteLog(m_SBVMinMaxBus.DAL);
        }

        #endregion
    }
}