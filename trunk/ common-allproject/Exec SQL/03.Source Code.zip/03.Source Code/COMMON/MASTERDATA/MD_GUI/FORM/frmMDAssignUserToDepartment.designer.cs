﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDAssignUserToDepartment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbbDepartment = new System.Windows.Forms.ComboBox();
            this.cbbUser = new System.Windows.Forms.ComboBox();
            this.radDepartment = new System.Windows.Forms.RadioButton();
            this.radUser = new System.Windows.Forms.RadioButton();
            this.btnSearch = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblControlValue = new System.Windows.Forms.Label();
            this.lblControlName = new System.Windows.Forms.Label();
            this.listViewRight = new System.Windows.Forms.ListView();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.listViewLeft = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.lblRight = new System.Windows.Forms.Label();
            this.lblLeft = new System.Windows.Forms.Label();
            this.btnDoubleLeft = new System.Windows.Forms.Button();
            this.btnSingleLeft = new System.Windows.Forms.Button();
            this.btnSingleRight = new System.Windows.Forms.Button();
            this.btnDoubleRight = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbbDepartment
            // 
            this.cbbDepartment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbbDepartment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbbDepartment.FormattingEnabled = true;
            this.cbbDepartment.Items.AddRange(new object[] {
            "CBP",
            "DBP"});
            this.cbbDepartment.Location = new System.Drawing.Point(104, 14);
            this.cbbDepartment.Name = "cbbDepartment";
            this.cbbDepartment.Size = new System.Drawing.Size(194, 21);
            this.cbbDepartment.TabIndex = 1;
            this.cbbDepartment.SelectedIndexChanged += new System.EventHandler(this.cbbDepartment_SelectedIndexChanged);
            // 
            // cbbUser
            // 
            this.cbbUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbbUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbbUser.Enabled = false;
            this.cbbUser.FormattingEnabled = true;
            this.cbbUser.Location = new System.Drawing.Point(425, 11);
            this.cbbUser.Margin = new System.Windows.Forms.Padding(5);
            this.cbbUser.Name = "cbbUser";
            this.cbbUser.Size = new System.Drawing.Size(194, 21);
            this.cbbUser.TabIndex = 3;
            this.cbbUser.SelectedIndexChanged += new System.EventHandler(this.cbbUser_SelectedIndexChanged);
            // 
            // radDepartment
            // 
            this.radDepartment.AutoSize = true;
            this.radDepartment.Location = new System.Drawing.Point(13, 17);
            this.radDepartment.Name = "radDepartment";
            this.radDepartment.Size = new System.Drawing.Size(80, 17);
            this.radDepartment.TabIndex = 0;
            this.radDepartment.TabStop = true;
            this.radDepartment.Text = "Department";
            this.radDepartment.UseVisualStyleBackColor = true;
            this.radDepartment.CheckedChanged += new System.EventHandler(this.radDepartment_CheckedChanged);
            // 
            // radUser
            // 
            this.radUser.AutoSize = true;
            this.radUser.Location = new System.Drawing.Point(363, 14);
            this.radUser.Name = "radUser";
            this.radUser.Size = new System.Drawing.Size(47, 17);
            this.radUser.TabIndex = 2;
            this.radUser.TabStop = true;
            this.radUser.Text = "User";
            this.radUser.UseVisualStyleBackColor = true;
            this.radUser.CheckedChanged += new System.EventHandler(this.radUser_CheckedChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(425, 34);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(80, 23);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Sea&rch";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.radDepartment);
            this.groupBox1.Controls.Add(this.cbbDepartment);
            this.groupBox1.Controls.Add(this.cbbUser);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.radUser);
            this.groupBox1.Location = new System.Drawing.Point(5, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(686, 69);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Role Code";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Role Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Remark";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblControlValue);
            this.groupBox2.Controls.Add(this.lblControlName);
            this.groupBox2.Controls.Add(this.listViewRight);
            this.groupBox2.Controls.Add(this.listViewLeft);
            this.groupBox2.Controls.Add(this.lblRight);
            this.groupBox2.Controls.Add(this.lblLeft);
            this.groupBox2.Controls.Add(this.btnDoubleLeft);
            this.groupBox2.Controls.Add(this.btnSingleLeft);
            this.groupBox2.Controls.Add(this.btnSingleRight);
            this.groupBox2.Controls.Add(this.btnDoubleRight);
            this.groupBox2.Controls.Add(this.btnCancel);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Location = new System.Drawing.Point(5, 79);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(684, 335);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            // 
            // lblControlValue
            // 
            this.lblControlValue.AutoSize = true;
            this.lblControlValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControlValue.Location = new System.Drawing.Point(75, 23);
            this.lblControlValue.Name = "lblControlValue";
            this.lblControlValue.Size = new System.Drawing.Size(39, 13);
            this.lblControlValue.TabIndex = 22;
            this.lblControlValue.Text = "Value";
            // 
            // lblControlName
            // 
            this.lblControlName.AutoSize = true;
            this.lblControlName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControlName.ForeColor = System.Drawing.Color.Blue;
            this.lblControlName.Location = new System.Drawing.Point(10, 23);
            this.lblControlName.Name = "lblControlName";
            this.lblControlName.Size = new System.Drawing.Size(37, 13);
            this.lblControlName.TabIndex = 21;
            this.lblControlName.Text = "User:";
            // 
            // listViewRight
            // 
            this.listViewRight.AllowColumnReorder = true;
            this.listViewRight.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.listViewRight.FullRowSelect = true;
            this.listViewRight.Location = new System.Drawing.Point(366, 68);
            this.listViewRight.Name = "listViewRight";
            this.listViewRight.Size = new System.Drawing.Size(310, 215);
            this.listViewRight.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listViewRight.TabIndex = 18;
            this.listViewRight.UseCompatibleStateImageBehavior = false;
            this.listViewRight.View = System.Windows.Forms.View.Details;
            this.listViewRight.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listViewRight_ColumnClick);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Assigned Users";
            this.columnHeader3.Width = 140;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Department";
            this.columnHeader4.Width = 165;
            // 
            // listViewLeft
            // 
            this.listViewLeft.AllowColumnReorder = true;
            this.listViewLeft.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listViewLeft.FullRowSelect = true;
            this.listViewLeft.Location = new System.Drawing.Point(9, 68);
            this.listViewLeft.Name = "listViewLeft";
            this.listViewLeft.Size = new System.Drawing.Size(310, 215);
            this.listViewLeft.TabIndex = 12;
            this.listViewLeft.UseCompatibleStateImageBehavior = false;
            this.listViewLeft.View = System.Windows.Forms.View.Details;
            this.listViewLeft.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listViewLeft_ColumnClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Unassign Users";
            this.columnHeader1.Width = 140;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Department";
            this.columnHeader2.Width = 167;
            // 
            // lblRight
            // 
            this.lblRight.AutoSize = true;
            this.lblRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRight.Location = new System.Drawing.Point(366, 50);
            this.lblRight.Name = "lblRight";
            this.lblRight.Size = new System.Drawing.Size(44, 13);
            this.lblRight.TabIndex = 17;
            this.lblRight.Text = "Assign";
            // 
            // lblLeft
            // 
            this.lblLeft.AutoSize = true;
            this.lblLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLeft.Location = new System.Drawing.Point(8, 50);
            this.lblLeft.Name = "lblLeft";
            this.lblLeft.Size = new System.Drawing.Size(59, 13);
            this.lblLeft.TabIndex = 11;
            this.lblLeft.Text = "Unassign";
            // 
            // btnDoubleLeft
            // 
            this.btnDoubleLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDoubleLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoubleLeft.ForeColor = System.Drawing.Color.Blue;
            this.btnDoubleLeft.Location = new System.Drawing.Point(328, 222);
            this.btnDoubleLeft.Name = "btnDoubleLeft";
            this.btnDoubleLeft.Size = new System.Drawing.Size(30, 23);
            this.btnDoubleLeft.TabIndex = 16;
            this.btnDoubleLeft.Text = "<<";
            this.btnDoubleLeft.UseVisualStyleBackColor = false;
            this.btnDoubleLeft.Click += new System.EventHandler(this.btnDoubleLeft_Click);
            // 
            // btnSingleLeft
            // 
            this.btnSingleLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSingleLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingleLeft.ForeColor = System.Drawing.Color.Red;
            this.btnSingleLeft.Location = new System.Drawing.Point(328, 183);
            this.btnSingleLeft.Name = "btnSingleLeft";
            this.btnSingleLeft.Size = new System.Drawing.Size(30, 23);
            this.btnSingleLeft.TabIndex = 15;
            this.btnSingleLeft.Text = "<";
            this.btnSingleLeft.UseVisualStyleBackColor = false;
            this.btnSingleLeft.Click += new System.EventHandler(this.btnSingleLeft_Click);
            // 
            // btnSingleRight
            // 
            this.btnSingleRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSingleRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingleRight.ForeColor = System.Drawing.Color.Red;
            this.btnSingleRight.Location = new System.Drawing.Point(328, 142);
            this.btnSingleRight.Name = "btnSingleRight";
            this.btnSingleRight.Size = new System.Drawing.Size(30, 23);
            this.btnSingleRight.TabIndex = 14;
            this.btnSingleRight.Text = ">";
            this.btnSingleRight.UseVisualStyleBackColor = false;
            this.btnSingleRight.Click += new System.EventHandler(this.btnSingleRight_Click);
            // 
            // btnDoubleRight
            // 
            this.btnDoubleRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDoubleRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoubleRight.ForeColor = System.Drawing.Color.Blue;
            this.btnDoubleRight.Location = new System.Drawing.Point(328, 103);
            this.btnDoubleRight.Name = "btnDoubleRight";
            this.btnDoubleRight.Size = new System.Drawing.Size(30, 23);
            this.btnDoubleRight.TabIndex = 13;
            this.btnDoubleRight.Text = ">>";
            this.btnDoubleRight.UseVisualStyleBackColor = false;
            this.btnDoubleRight.Click += new System.EventHandler(this.btnDoubleRight_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.Location = new System.Drawing.Point(600, 298);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 20;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(514, 298);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 19;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmMDAssignUserToDepartment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(697, 421);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmMDAssignUserToDepartment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Assign Users to Department";
            this.Load += new System.EventHandler(this.frmMDAssignUserToDepartment_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDAssignUserToDepartment_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbbDepartment;
        private System.Windows.Forms.ComboBox cbbUser;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.RadioButton radDepartment;
        private System.Windows.Forms.RadioButton radUser;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListView listViewRight;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ListView listViewLeft;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Label lblRight;
        private System.Windows.Forms.Label lblLeft;
        private System.Windows.Forms.Button btnDoubleLeft;
        private System.Windows.Forms.Button btnSingleLeft;
        private System.Windows.Forms.Button btnSingleRight;
        private System.Windows.Forms.Button btnDoubleRight;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblControlValue;
        private System.Windows.Forms.Label lblControlName;
    }
}