﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-06-05 11:37:30 +0700 (Wed, 05 June 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to proccess frmMDProcessingBoardRateApprover
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Dto;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDProcessingBoardRateApprover : frmMDMaster
    {
        #region Private Variables
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        private clsMDBoardRaterBUS m_BoardRateBus;
        private List<clsMDBoardRateDTO> m_BoardRateList;
        private clsMDBoardRateDTO m_BoardRateDto;
        private string m_colBoardRateID = "colBoardRateID";
        private string m_colStatusID = "colStatusID";
        private string m_colInactive = "colInactive";
        private clsMDCommonValue.BoardRateStatus m_BoardRateStatus = clsMDCommonValue.BoardRateStatus.Blank;
        private bool m_BoardRateActive = false;
        #endregion

        #region Contructor
        /// <summary>
        /// Constructor
        /// </summary>        
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDProcessingBoardRateApprover()
        {
            try
            {
                InitializeComponent();
                SetFormStyleCommon();
                //Do not allow sort on grid
                for (int i = 0; i < dtgBoardRateList.Columns.Count; i++)
                {
                    dtgBoardRateList.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                }
                //Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                //get Board Rate list for approver
                GetBoardRateListForApprover();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Event Method
        /// <summary>
        /// Form shown even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void frmMDProcessingDailyQuotation_Shown(object sender, EventArgs e)
        {
            try
            {

            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Datagridview's Selection changed even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgDailyQuotationList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                m_BoardRateStatus = clsMDCommonValue.BoardRateStatus.Blank;
                if (dtgBoardRateList.Rows.Count > 0 && dtgBoardRateList.SelectedRows.Count > 0)
                {
                    int index = dtgBoardRateList.Rows.IndexOf(dtgBoardRateList.SelectedRows[0]);
                    m_BoardRateStatus = (clsMDCommonValue.BoardRateStatus)dtgBoardRateList.Rows[index].Cells[m_colStatusID].Value;
                    m_BoardRateActive = !(bool)dtgBoardRateList.Rows[index].Cells[m_colInactive].Value;
                    int boardRateID = (int)dtgBoardRateList.Rows[index].Cells[m_colBoardRateID].Value;
                    m_BoardRateDto = m_BoardRateList.Find(t => t.BoardRateID == boardRateID);
                }
                else
                {
                    m_BoardRateDto = null;
                }
                //show and hidden tool strip menu
                ShowHidenToolStrip(m_BoardRateStatus);
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Board Rate double click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgBoardRateList_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                if (m_BoardRateStatus != (int)clsMDCommonValue.BoardRateAction.Blank)
                {
                    //show form Import Board Rate
                    frmMDImportBoardRate frm = new frmMDImportBoardRate(m_BoardRateStatus, m_BoardRateDto.BoardRateID, false);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.ShowDialog();
                    GetBoardRateListForApprover();
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }


        /// <summary>
        /// Approve event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbApprove_Click(object sender, EventArgs e)
        {
            try
            {
                /*
                   '- User is authorized for action "approve”. 
                    - User clicks on “approve”
                    - System display a confirm message box “Are you sure to approve board rate?”
                    - User clicks on “Yes” button.
                    - System will popup a message to announce “Board rate was approved successfully”
                    - In case of actor clicks [No] on confirm message box, system will not save data in database and close confirm message.
                    - System changes the status “Wait for approve” to “Approved” and the old approved board rate will be unactive
                     - Operation log will be saved.
                    *Note:  - System restricted that approver must be different from maker of board rate.
                 */
                DialogResult dialog;
                dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                            clsMDMessage.ARE_YOU_SURE_TO_APPROVE_BOARD_RATE);
                if (dialog == DialogResult.Yes)
                {
                    m_BoardRateBus = new clsMDBoardRaterBUS();
                    m_BoardRateDto.Status = (int)clsMDCommonValue.BoardRateStatus.Approved;
                    m_BoardRateDto.IsActive = true;

                    int row = m_BoardRateBus.UpdateBoardRate(m_BoardRateDto);
                    if (row > 0)
                    {
                        WriteLogUpdateStatus(m_BoardRateDto.BoardRateID, (int)m_BoardRateStatus, m_BoardRateDto.Status, m_BoardRateActive, m_BoardRateDto.IsActive);
                        m_BoardRateBus.Commit();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                          clsMDMessage.DATA_BR_WAS_APPROVED_SUCCESSFULLY);
                    }
                    else
                    {
                        m_BoardRateBus.RollBack();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                           clsMDMessage.DATA_WAS_APPROVED_UN_SUCCESSFULLY);
                    }
                    GetBoardRateListForApprover();
                }

            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_BoardRateBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Return event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbReturn_Click(object sender, EventArgs e)
        {
            try
            {
                /*
                   '- User is authorized for action “Return”. 
                    - User picking Waiting for approve BR and click [Return]
                    - System display a confirm message box “Are you sure to return board rate?”
                     - In case user clicks on “Yes” button.
                         +  System will popup a message to announce “Data was returned successfully”
                         +  System changes the status of the board rate to “Returned”.
                         +  Returned BR will displays in “View Board Rate of Maker” screen.
                         +  If Re-import will hightlight data which diffirence with Returned board rate 
                         + Operation log will be saved.
                    - In case of user clicks [No] on confirm message box, system will not save data in database and close confirm message
                 */
                DialogResult dialog;
                dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                            clsMDMessage.ARE_YOU_SURE_TO_RETURN_BOARD_RATE);
                if (dialog == DialogResult.Yes)
                {
                    m_BoardRateBus = new clsMDBoardRaterBUS();
                    m_BoardRateDto.Status = (int)clsMDCommonValue.BoardRateStatus.Returned;

                    int row = m_BoardRateBus.UpdateBoardRate(m_BoardRateDto);
                    if (row > 0)
                    {
                        WriteLogUpdateStatus(m_BoardRateDto.BoardRateID, (int)m_BoardRateStatus, m_BoardRateDto.Status, m_BoardRateActive, m_BoardRateActive);
                        m_BoardRateBus.Commit();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                          clsMDMessage.DATA_BR_WAS_RETURNED_SUCCESSFULLY);
                    }
                    else
                    {
                        m_BoardRateBus.RollBack();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                           clsMDMessage.DATA_BR_WAS_RETURNED_UN_SUCCESSFULLY);
                    }
                    GetBoardRateListForApprover();
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_BoardRateBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Revise event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbRevise_Click(object sender, EventArgs e)
        {
            try
            {
                /*
                   '- User picking Approved BR and click [Revise]
                    - System display a confirm message box “Are you sure to revise board rate?”
                    - In case user clicks on “Yes” button.
                        +   System will popup a message to announce “Data was revised successfully”
                        +   System changes the status of the Board rate to “Suspended”.
                        +  If Re-import will hightlight data which diffirence with Returned board rate 
                        +    Operation log will be saved.
                    - In case of user clicks [No] on confirm message box, system will not save data in database and close confirm message
                 */
                DialogResult dialog;
                dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                            clsMDMessage.ARE_YOU_SURE_TO_REVISE_BOARD_RATE);
                if (dialog == DialogResult.Yes)
                {
                    m_BoardRateBus = new clsMDBoardRaterBUS();
                    m_BoardRateDto.Status = (int)clsMDCommonValue.BoardRateStatus.Suspended;
                    m_BoardRateDto.IsActive = false;

                    int row = m_BoardRateBus.UpdateBoardRate(m_BoardRateDto);
                    if (row > 0)
                    {
                        WriteLogUpdateStatus(m_BoardRateDto.BoardRateID, (int)m_BoardRateStatus, m_BoardRateDto.Status, m_BoardRateActive, m_BoardRateActive);
                        m_BoardRateBus.Commit();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                          clsMDMessage.DATA_BR_WAS_REVISED_SUCCESSFULLY);
                    }
                    else
                    {
                        m_BoardRateBus.RollBack();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                           clsMDMessage.DATA_BR_WAS_REVISED_UN_SUCCESSFULLY);
                    }
                    GetBoardRateListForApprover();
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_BoardRateBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Freeze event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbFreeze_Click(object sender, EventArgs e)
        {
            try
            {
                /*
                   '- User is authorized for action "freeze” and slected Board Rate is "Approved" 
                    - User clicks on “freeze”
                    - System display a confirm message box “Are you sure to freeze data?”
                    - User clicks on “Yes” button.
                    - System will popup a message to announce “Board Rate was freezed successfully”
                    - In case of actor clicks [No] on confirm message box, system will not save data in database and close confirm message.
                    - System changes the old approved Board Rate will be unactive
                     - Operation log will be saved.
                 */
                DialogResult dialog;
                dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                            clsMDMessage.ARE_YOU_SURE_TO_FREEZE_BOARD_RATE);
                if (dialog == DialogResult.Yes)
                {
                    m_BoardRateBus = new clsMDBoardRaterBUS();
                    
                    m_BoardRateDto.IsActive = false;
                    
                    int row = m_BoardRateBus.UpdateBoardRate(m_BoardRateDto);
                    if (row > 0)
                    {
                        WriteLogUpdateStatus(m_BoardRateDto.BoardRateID, (int)m_BoardRateStatus, (int)m_BoardRateStatus, m_BoardRateActive, m_BoardRateDto.IsActive);
                        m_BoardRateBus.Commit();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                          clsMDMessage.DATA_BR_WAS_FREEZED_SUCCESSFULLY);
                    }
                    else
                    {
                        m_BoardRateBus.RollBack();
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                           clsMDMessage.DATA_BR_WAS_FREEZED_UN_SUCCESSFULLY);
                    }
                    GetBoardRateListForApprover();
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_BoardRateBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Print Preview event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbPrintPreview_Click(object sender, EventArgs e)
        {
            try
            {
                //show form print preview Board Rate
                frmMDPrintPreviewBoardRate frm = new frmMDPrintPreviewBoardRate(m_BoardRateDto.BoardRateID, m_BoardRateDto.ImportTime);
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }


        /// <summary>
        /// Export event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_BoardRateDto != null)
                {
                    clsMDBoardRateDTO dtoExport = clsMDBoardRaterBUS.Instance().GetBoardRateAndBoadRateDetail(m_BoardRateDto.BoardRateID);
                    if (dtoExport != null)
                    {
                        m_BoardRateBus = new clsMDBoardRaterBUS();
                        m_BoardRateBus.ExportBoardRate(dtoExport);
                    }
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_BOARD_RATE_EXPORT);
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Refresh even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                GetBoardRateListForApprover();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Close form even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion


        #region Member Methods

        /// <summary>
        /// Get quotation list for approver
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetBoardRateListForApprover()
        {
            dtgBoardRateList.Rows.Clear();
            m_BoardRateBus = new clsMDBoardRaterBUS();
            m_BoardRateList = m_BoardRateBus.GetViewBoardRateApproverList();
            if (m_BoardRateList.Count > 0)
            {
                foreach (clsMDBoardRateDTO dto in m_BoardRateList)
                {
                    dtgBoardRateList.Rows.Add(dto.BoardRateID, clsMDFunction.GetBoardRateStatusName(dto.Status), !dto.IsActive,
                        dto.ImportTime, dto.ImportTime, dto.Maker, dto.Approver, dto.Status);
                }
            }
            //Init tool strip menu
            ShowHidenToolStrip(m_BoardRateStatus);
        }

        /// <summary>
        /// Show hidden tool strip menu by status
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ShowHidenToolStrip(clsMDCommonValue.BoardRateStatus boardRateStatus)
        {
            /*
             When user select a board rate, system will enable or disable button depend on status of selected board rate.
             - In case selected board rate is Wait for approve, enable Approve, Return.
             - in case selected board rate is approved - actived, enable Revise, Print/Preview and Export
             - Selected a board rate, enable Print/Preview, export
             */
            switch (boardRateStatus)
            {
                case clsMDCommonValue.BoardRateStatus.Blank:
                    tsbApprove.Visible = false;
                    tsbReturn.Visible = false;
                    tsbRevise.Visible = false;
                    tsbFreeze.Visible = false;
                    tsbPrintPreview.Visible = false;
                    tsbExport.Visible = false;
                    break;

                case clsMDCommonValue.BoardRateStatus.New:

                    break;

                case clsMDCommonValue.BoardRateStatus.WaitingforApprove:
                    tsbApprove.Visible = true;
                    tsbReturn.Visible = true;
                    tsbRevise.Visible = false;
                    tsbFreeze.Visible = false;
                    tsbPrintPreview.Visible = true;
                    tsbExport.Visible = true;
                    break;

                case clsMDCommonValue.BoardRateStatus.Approved:
                    tsbApprove.Visible = false;
                    tsbReturn.Visible = false;
                    tsbRevise.Visible = false;
                    tsbFreeze.Visible = true;
                    tsbPrintPreview.Visible = true;
                    tsbExport.Visible = true;

                    if (m_BoardRateDto != null)
                    {
                        if (m_BoardRateDto.IsActive == true)
                        {
                            tsbRevise.Visible = true;
                            //tsbPrintPreview.Visible = true;
                            //tsbExport.Visible = true;
                        }
                        else
                        {
                            tsbFreeze.Visible = false;
                        }
                    }
                    break;

                case clsMDCommonValue.BoardRateStatus.Withdrawed:
                    break;

                case clsMDCommonValue.BoardRateStatus.Returned:
                    break;

                case clsMDCommonValue.BoardRateStatus.Suspended:
                    break;

                case clsMDCommonValue.BoardRateStatus.Obsolete:
                    break;

                case clsMDCommonValue.BoardRateStatus.Freeze:
                    break;
            }
        }

        /// <summary>
        /// Write log update status
        /// </summary>
        /// <param name="key"></param>
        /// <param name="iOldStatus"></param>
        /// <param name="iNewSatus"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLogUpdateStatus(int key, int iOldStatus, int iNewSatus, bool oldActive, bool newActive)
        {
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = key.ToString();
            logBase.Action = (int)CommonValue.ActionType.Update;

            clsMDLogInformation logInfo = new clsMDLogInformation();
            if (iOldStatus != iNewSatus)
            {
                logInfo.FieldName = "Status";
                logInfo.OldValue = iOldStatus.ToString();
                logInfo.NewValue = iNewSatus.ToString();
            }
            if (oldActive != newActive)
            {
                logInfo.FieldName = "IsActive";
                logInfo.OldValue = oldActive == true ? "1" : "0";
                logInfo.NewValue = newActive == true ? "1" : "0";
            }
            logBase.LstLogInformation.Add(logInfo);
            logBase.WirteLog(m_BoardRateBus.DAL);
        }
        #endregion

    }
}