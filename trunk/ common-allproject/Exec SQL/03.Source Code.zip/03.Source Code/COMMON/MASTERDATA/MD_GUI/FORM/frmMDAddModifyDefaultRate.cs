﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-08-30 10:00:30 +0700 (Tue, 30 August 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to add/modify default rate
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDAddModifyDefaultRate : frmMDMaster
    {
        #region Global Variable
        //For Security Checking
        clsSEAuthorizer m_Security = null;

        //DTO & BUS
        private clsMDDefaultRateBUS mdDefaultRateBus = new clsMDDefaultRateBUS();
        private clsAddModifyDefaultRateDTO mdAddModifyDefaultRateDTO = new clsAddModifyDefaultRateDTO();

        //Used for checking changes
        private bool isChanged = false;

        //For DatagridView
        private string m_colCCY = "colCCY";
        private string m_colRate = "colRate";
        private string m_colOldRate = "colOldRate";
        private string m_GridName = "Default Ordinary Deposit I/S Rate";
        private string m_TitleCreate = "Create Default Ordinary Deposit I/S Rate";
        private string m_TitleModify = "Modify Default Ordinary Deposit I/S Rate";
        private string m_ButtonAdd = "&Add";
        private string m_ButtonUpdate = "&Update";

        //Action Type
        int m_ActionType = -1;

        //List Added CCY
        List<string> lstAddedCCY = new List<string>();

        //Row Index Selected
        int rowIndexSelected = 0;

        DateTime m_FromDate;
        DateTime m_ToDate;

        #endregion Global Variable

        #region Constructor
        /// <summary>
        /// Constructor for modifying default rate
        /// </summary>
        /// <param name="OrdinaryDepositISRateID"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDAddModifyDefaultRate()
        {
            InitializeComponent();
            try
            {
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                //+ From Date
                DateTime fromDate = DateTime.MinValue;
                DateTime toDate = DateTime.MinValue;
                string ccy = String.Empty;
                string rate = String.Empty;
                m_ActionType = !ccy.Equals(String.Empty) ? (int)CommonValue.CeilingFloorAction.Modify : (int)CommonValue.CeilingFloorAction.Create;
                Init(fromDate, toDate, ccy, rate);
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Constructor for modifying default rate
        /// </summary>
        /// <param name="OrdinaryDepositISRateID"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDAddModifyDefaultRate(DateTime fromDate, DateTime toDate, string ccy, string rate)
        {
            InitializeComponent();
            try
            {
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_ActionType = !ccy.Equals(String.Empty) ? (int)CommonValue.CeilingFloorAction.Modify : (int)CommonValue.CeilingFloorAction.Create;
                Init(fromDate, toDate, ccy, rate);
                m_FromDate = fromDate;
                m_ToDate = toDate;
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion Constructor


        /// <summary>
        /// Initialize value for controls
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void Init(DateTime fromDate, DateTime toDate, string ccy, string rate)
        {
            //Set Form Style
            SetFormStyleCommon();
            LoadCurrency(cbbCCY);
            if (cbbCCY.Items.Count == 0)
            {
                List<CbbObject> lstCbbObj = new List<CbbObject>();
                lstCbbObj = clsMDCeilingFloorBUS.Instance().GetCurencyList();
                cbbCCY.DataSource = lstCbbObj;
            }
            switch (m_ActionType)
            {
                case (int)CommonValue.CeilingFloorAction.Modify:
                    this.Text = m_TitleModify;
                    cbbCCY.Enabled = false;
                    dtpInputDateFrom.Enabled = false;
                    dtpInputDateTo.Enabled = false;
                    cbbCCY.SelectedIndex = cbbCCY.FindString(ccy);
                    txtRate.Text = rate;
                    btnAdd.Text = m_ButtonUpdate;
                    break;
                case (int)CommonValue.CeilingFloorAction.Create:
                    this.Text = m_TitleCreate;
                    cbbCCY.Enabled = true;
                    dtpInputDateFrom.Enabled = false;
                    dtpInputDateTo.Enabled = true;
                    cbbCCY.SelectedIndex = cbbCCY.FindString(String.Empty);
                    txtRate.Text = rate;
                    btnAdd.Text = m_ButtonAdd;
                    break;
            }
            //Load Default Rate For Add/Modify
            LoadDefaultRateForAddModify(fromDate, toDate);
        }

        /// <summary>
        /// Check valid conditions of controls's value
        /// </summary>
        /// <returns>True if valid, false otherwise</returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool CheckValidCondition()
        {
            bool isValid = true;

            //check date from have to smaller than date to
            if (dtpInputDateTo.Value.Date.CompareTo(dtpInputDateFrom.Value.Date) <= 0)
            {
                isValid = false;
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_SMALLER_THAN, lblInputDateFrom.Text, lblInputDateTo.Text));
                return isValid;
            }

            //Check mandatory for DataGridView
            if (dtgDefaulRateList.Rows.Count == 0)
            {
                isValid = false;
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_FIELD_REQUIRED, "[" + m_GridName + "]"));
                dtgDefaulRateList.Focus();
                return isValid;
            }
            return isValid;
        }

        /// <summary>
        /// Save Default Rate
        /// </summary>
        /// <param name="mode"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool SaveDefaultRate(bool mode)
        {
            //Declaration   
            bool isSucessful = false;
            mdAddModifyDefaultRateDTO = new clsAddModifyDefaultRateDTO();
            int insertedRow = 0;
            //History List
            List<clsMDLogBase> lstLogBase = new List<clsMDLogBase>();

            //Check validation
            isSucessful = CheckValidCondition();

            //Not error
            if (isSucessful)
            {
                //Assign Value
                //+ Input Date From
                mdAddModifyDefaultRateDTO.InputDateFrom = dtpInputDateFrom.Value;
                //+ Input Date To
                mdAddModifyDefaultRateDTO.InputDateTo = dtpInputDateTo.Value;
                mdAddModifyDefaultRateDTO.CreatedBy = clsUserInfo.UserNo.ToString();

                #region Process of Saving
                foreach (DataGridViewRow item in dtgDefaulRateList.Rows)
                {
                    clsAddModifyDefaultRateOnGridDTO objDefaultRateInfo = new clsAddModifyDefaultRateOnGridDTO();
                    //History Header
                    clsMDLogBase logBase = new clsMDLogBase();
                    logBase.ApplicationName = this.Text;
                    logBase.Module = clsMDConstant.MODULE_MD;
                    logBase.UserID = clsUserInfo.UserNo.ToString();
                    logBase.Key = mdAddModifyDefaultRateDTO.InputDateFrom.ToString(clsMDConstant.MD_FORMAT_YYYY_MM_DD)
                                    + " " + mdAddModifyDefaultRateDTO.InputDateTo.ToString(clsMDConstant.MD_FORMAT_YYYY_MM_DD)
                                    + " " + item.Cells[m_colCCY].Value.ToString();

                    //Assign value
                    objDefaultRateInfo.CCY = item.Cells[m_colCCY].Value.ToString();
                    objDefaultRateInfo.Rate = Decimal.Parse(item.Cells[m_colRate].Value.ToString());
                    //Add list exchange rate
                    mdAddModifyDefaultRateDTO.LstAddModifyDefaultRateOnGridDTO.Add(objDefaultRateInfo);

                    //History Details
                    //+ Inserting Log
                    logBase.Action = item.Cells[m_colOldRate].Value.ToString().Equals(String.Empty) ? (int)CommonValue.ActionType.New : (int)CommonValue.ActionType.Update;
                    //+ [CCY] Column                        
                    clsMDLogInformation logInfo = new clsMDLogInformation();
                    if (item.Cells[m_colOldRate].Value.ToString().Equals(String.Empty))
                    {
                        logInfo.FieldName = item.Cells[m_colCCY].OwningColumn.HeaderText;
                        logInfo.OldValue = String.Empty;
                        logInfo.NewValue = item.Cells[m_colCCY].FormattedValue.ToString();
                        logBase.LstLogInformation.Add(logInfo);
                    }

                    //+ [Rate] Column                        
                    logInfo = new clsMDLogInformation();
                    logInfo.FieldName = item.Cells[m_colRate].OwningColumn.HeaderText;
                    logInfo.OldValue = item.Cells[m_colOldRate].Value.ToString().Equals(String.Empty) ? String.Empty : item.Cells[m_colOldRate].Value.ToString();
                    logInfo.NewValue = item.Cells[m_colRate].FormattedValue.ToString();
                    logBase.LstLogInformation.Add(logInfo);

                    //Add to List of History
                    if (!item.Cells[m_colRate].Value.ToString().Equals(item.Cells[m_colOldRate].Value.ToString()))
                    {
                        lstLogBase.Add(logBase);
                    }
                }
                insertedRow = mdDefaultRateBus.InsertDefaultRate(mdAddModifyDefaultRateDTO, mode);
                if (insertedRow != 0)
                {
                    //Write Log
                    foreach (clsMDLogBase logBase in lstLogBase)
                    {
                        logBase.WirteLog(mdDefaultRateBus.DAL);
                    }
                }
                #endregion
            }
            return isSucessful;
        }

        /// <summary>
        /// Save default rate even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, clsMDMessage.ARE_YOU_SURE_TO_SAVE_DATA);
                if (result == DialogResult.Yes)
                {
                    bool isSuccess = false;
                    isSuccess = SaveDefaultRate(m_ActionType == (int)CommonValue.CeilingFloorAction.Create ? true : false);
                    if (isSuccess)
                    {
                        //Commit data if successful
                        mdDefaultRateBus.Commit();
                        clsMDMesageCollection.ShowMessage(2, String.Format(clsMDMessage.INFO_ACTION_SUCCESS, m_ActionType == (int)CommonValue.CeilingFloorAction.Create ? CREATING : MODIFYING, m_GridName));
                        isChanged = false;
                        //Set Dialog Result
                        this.DialogResult = DialogResult.OK;
                        //close form after save data
                        frmMDAddModifyDefaultRate_FormClosing(null, null);
                    }
                }
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                try
                {
                    mdDefaultRateBus.RollBack();
                }
                catch (System.Exception) { }

                if (ex.Message.Equals("InvalidData"))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, String.Format(clsMDMessage.ERROR_IS_INVALID_DATA, "Period"));
                    dtpInputDateFrom.Focus();
                }
                else
                {
                    clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                }
            }

        }

        /// <summary>
        /// Cancel even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Form closing even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void frmMDAddModifyDefaultRate_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    if (IsChangeValueOnForm())
                    {
                        DialogResult dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                            clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                        if (dialog == DialogResult.Yes)
                        {
                            //save data
                            btnSave_Click(null, null);
                        }
                        else if (dialog == DialogResult.No)
                        {
                            e.Cancel = false;
                        }
                        else if (dialog == DialogResult.Cancel)
                        {
                            e.Cancel = true;
                        }
                    }
                }
                else
                {
                    //close form
                    this.FormClosing -= new FormClosingEventHandler(frmMDAddModifyDefaultRate_FormClosing);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                Close();
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }



        /// <summary>
        /// dtgCeilingFloorList_CellMouseDoubleClick
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgDefaultRateList_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                string selectedRowCCY = dtgDefaulRateList.Rows[e.RowIndex].Cells[m_colCCY].Value.ToString();
                string selectedRowRate = dtgDefaulRateList.Rows[e.RowIndex].Cells[m_colRate].Value.ToString();
                rowIndexSelected = e.RowIndex;
                //CCY
                cbbCCY.Text = selectedRowCCY;
                cbbCCY.Enabled = false;
                //Rate
                txtRate.Text = selectedRowRate;
                btnAdd.Text = "&Update";
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Load Default Rate For Add/Modify
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void LoadDefaultRateForAddModify(DateTime fromDate, DateTime toDate)
        {
            //Clear Grid
            dtgDefaulRateList.Rows.Clear();
            lstAddedCCY.Clear();
            //Declaration
            mdAddModifyDefaultRateDTO = new clsAddModifyDefaultRateDTO();
            //Assign value from inputting
            mdAddModifyDefaultRateDTO.InputDateFrom = fromDate;
            mdAddModifyDefaultRateDTO.InputDateTo = toDate;
            //Get data collection from database
            mdDefaultRateBus.spMD_GetDefaultRateForAddModify(ref mdAddModifyDefaultRateDTO);
            //In case [Creating], then Set value again for InputDate
            //Else, Set data for Grid of CCY
            if (m_ActionType == (int)CommonValue.CeilingFloorAction.Create)
            {
                dtpInputDateFrom.Value = mdAddModifyDefaultRateDTO.InputDateFrom;
                dtpInputDateTo.Value = mdAddModifyDefaultRateDTO.InputDateTo;
            }
            else
            {
                dtpInputDateFrom.Value = fromDate;
                dtpInputDateTo.Value = toDate;
                foreach (clsAddModifyDefaultRateOnGridDTO objDefaultRateInfo in mdAddModifyDefaultRateDTO.LstAddModifyDefaultRateOnGridDTO)
                {
                    dtgDefaulRateList.Rows.Add(objDefaultRateInfo.CCY, objDefaultRateInfo.Rate, objDefaultRateInfo.OldDefaultRate);
                    lstAddedCCY.Add(objDefaultRateInfo.CCY);
                }
            }
            //Set Enable/Disable for Input Date if the default rate is the latest default rate
            if (mdAddModifyDefaultRateDTO.IsLatestDefaultRate)
            {
                dtpInputDateTo.Enabled = true;
            }
            //Set Enable/Disable for Input Date if the data is empty or not
            if (mdAddModifyDefaultRateDTO.IsEmptyDefaultRate)
            {
                dtpInputDateFrom.Enabled = true;
            }
        }

        /// <summary>
        /// btnAdd_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //Check mandatory for [CCY]
                if (cbbCCY.Text.Equals(String.Empty))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblCCY.Text));
                    cbbCCY.Focus();
                    return;
                }
                //Check mandatory for [Rate]
                if (txtRate.Text.Equals(String.Empty))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblRate.Text));
                    txtRate.Focus();
                    return;
                }
                //Check exisiting [CCY]
                if (lstAddedCCY.Contains(cbbCCY.Text) && btnAdd.Text.Contains("Add"))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, String.Format(clsMDMessage.ERR_ITEM_EXISTED, lblCCY.Text));
                    cbbCCY.Focus();
                    return;
                }
                //In case checking data is valid, allow to add/update data to grid
                if (btnAdd.Text.Contains("Add"))
                {
                    dtgDefaulRateList.Rows.Add(cbbCCY.Text, txtRate.Text, String.Empty);
                    lstAddedCCY.Add(cbbCCY.Text);
                }
                else
                {
                    dtgDefaulRateList.Rows[rowIndexSelected].Cells[m_colRate].Value = txtRate.Text;
                    //CYY
                    cbbCCY.Text = String.Empty;
                    cbbCCY.Enabled = true;
                    //Rate
                    txtRate.Text = String.Empty;
                    btnAdd.Text = m_ButtonAdd;
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Check data is changed on form
        /// Return true data is changed
        /// Return false data is not changed
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsChangeValueOnForm()
        {
            //check data is changed on form

            switch (m_ActionType)
            {
                case (int)CommonValue.CeilingFloorAction.Modify:
                    //check from date is changed
                    if (m_FromDate.Date.CompareTo(dtpInputDateFrom.Value.Date) != 0)
                    {
                        return true;
                    }

                    //check to date is changed
                    if (m_ToDate.Date.CompareTo(dtpInputDateTo.Value.Date) != 0)
                    {
                        return true;
                    }

                    if (dtgDefaulRateList.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtgDefaulRateList.Rows.Count; i++)
                        {
                            //check data on grid is changed
                            if (clsMDFunction.isNullOrEmpty(dtgDefaulRateList.Rows[i].Cells[m_colOldRate].Value))
                            {
                                return true;
                            }
                            if (Convert.ToDecimal(dtgDefaulRateList.Rows[i].Cells[m_colRate].Value) != Convert.ToDecimal(dtgDefaulRateList.Rows[i].Cells[m_colOldRate].Value))
                            {
                                return true;
                            }
                        }
                    }

                    break;
                case (int)CommonValue.CeilingFloorAction.Create:
                    if (dtgDefaulRateList.Rows.Count > 0)
                    {
                        return true;
                    }

                    break;
            }

            return false;
        }
    }
}