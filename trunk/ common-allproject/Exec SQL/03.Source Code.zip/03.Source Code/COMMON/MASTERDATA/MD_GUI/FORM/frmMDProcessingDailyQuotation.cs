﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to proccess daily quotationn
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Dto;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDProcessingDailyQuotation : frmMDMaster
    {
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        /// <summary>
        /// User role: Approver or Maker
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        int m_Role = -1;
        /// <summary>
        /// Seleted quotation ID of datarow in datagridview
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int m_QuotationIDSelected = -1;
        /// <summary>
        /// Seleted status code of datarow in datagridview
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int m_StatusCodeSelected = -1;
        /// <summary>
        /// Seleted version of datarow in datagridview
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private double m_Version = -0.1;
        /// <summary>
        /// Seleted Isactive of datarow in datagridview
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private bool m_Isactive = false;
        private int m_CurrentStatus;
        int m_UserAction = 0;
        ///// <summary>
        ///// Screen of Maker's Text
        ///// </summary>
        ///// @cond
        ///// Author: Yen Phan
        ///// @endcond
        //public const string PROCESSING_DAILY_QUOTATION_MAKER = "Processing Daily Quotation (Maker)";
        ///// <summary>
        ///// Screen of Approver's Text
        ///// </summary>
        ///// @cond
        ///// Author: Yen Phan
        ///// @endcond
        //public const string PROCESSING_DAILY_QUOTATION_APPROVER = "Processing Daily Quotation (Approver)";
        ///// <summary>
        ///// Screen's Text
        ///// </summary>
        ///// @cond
        ///// Author: Yen Phan
        ///// @endcond
        //public const string PROCESSING_DAILY_QUOTATION = "Processing Daily Quotation";
        /// <summary>
        /// ID of previous quotation
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private int m_QuotationIDReturnPre = -1;
        /// <summary>
        /// Quotation ID column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_QUOTATION_ID = "colQuotationID";
        /// <summary>
        /// Status column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_STATUS = "colStatus";
        /// <summary>
        /// Version column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_VERSION = "colVersion";
        /// <summary>
        /// Inactive column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_INACTIVE = "colInactive";
        //const string APPROVER = "APPROVER";
        //const string MAKER = "MAKER";
        /// <summary>
        /// Quotation bus - Being used to access data for quotation
        /// </summary>/// <summary>
        /// column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private clsMDQuoationBus m_MDQuoationBus = new clsMDQuoationBus();
        /// <summary>
        /// Excel base object - Being used for handling excel file
        /// </summary>
        ExcelBase m_ExcelBase = null;
        /// <summary>
        /// worker object, working for background thread
        /// </summary>
        private CWorker m_worker;
        /// <summary>
        /// File name to export
        /// </summary>
        private string m_FileName = "";
        /// <summary>
        /// template of file to export
        /// </summary>
        private string m_TemplateName;
        /// <summary>
        /// Project name
        /// </summary>
        private string m_ProjectName = clsMDConstant.PROJECT_NAME_MASTERDATA;
		bool CommonError = false;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="iRole">Approver of Maker</param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		public frmMDProcessingDailyQuotation(int iRole)
		{
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                StartPosition = FormStartPosition.CenterScreen;
                SetFormStyleCommon();

                tsbApprove.Enabled = false;
                tsbModify.Enabled = false;
                tsbPrintPreview.Enabled = true;
                tsbRequestToApprove.Enabled = false;
                tsbReturn.Enabled = false;
                tsbRevise.Enabled = false;
                tsbWithdraw.Enabled = false;
                tsbPrintPreview.Enabled = false;
                tsbImport.Enabled = false;
                tsbFreeze.Enabled = false;
                tsbExport.Enabled = false;

                m_Role = iRole;
                ///set form title
                switch (m_Role)
                {
                    case (int)CommonValue.QuotationRole.Maker:
                        this.Text = clsMDConstant.PROCESSING_DAILY_QUOTATION_MAKER;
                        tsbImport.Enabled = true;
                        //check security for tsbImport
                        //tsbImport.Enabled = bool.Parse(tsbImport.Tag.ToString());
                        break;
                    case (int)CommonValue.QuotationRole.Approver:
                        this.Text = clsMDConstant.PROCESSING_DAILY_QUOTATION_APPROVER;
                        break;
                    default:
                        this.Text = clsMDConstant.PROCESSING_DAILY_QUOTATION;
                        break;
                }

            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				//CommonError = true;
                Close();
            }
		}

        /// <summary>
        /// Form shown even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private void frmMDProcessingDailyQuotation_Shown(object sender, EventArgs e)
		{
            //if(CommonError)
            //{
            //    this.Close();
            //}
            try
            {
                switch (m_Role)
                {
                    case (int)CommonValue.QuotationRole.Maker:
                        GetQuotationListForMaker();
                        break;
                    case (int)CommonValue.QuotationRole.Approver:
                        GetQuotationListForApprover();
                        break;
                    default:
                        break;
                }
                if (dtgDailyQuotationList.Rows.Count <= 0)
                    SetRight("", -1);
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

        /// <summary>
        /// Approve even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private void tsbRequestToApprove_Click(object sender, EventArgs e)
		{
			try
			{
				//vlhcnhung 
				if (dtgDailyQuotationList.SelectedRows.Count <= 0)
				{
					clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "quotation", "request for approval"));
					return;
				}
				m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
				m_StatusCodeSelected = GetStatusValue(dtgDailyQuotationList.SelectedRows[0].Cells[COL_STATUS].Value.ToString().Trim());
				/// - System display a confirm message box “Are you sure to request for approval?”
				/// - User clicks on “Yes” button.
                if (clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_REQUEST_FOR_APPROVAL) == DialogResult.Yes)
                {///- System restricted that approver must be different from maker of quotation..--> pending
                    if (UpdateQuotationStatus((int)CommonValue.QuotationStatus.WaitForApprove) > 0)
                    {
                        ///- System will popup a message to announce “Request was sent successfully”
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.REQUEST_WAS_SENT_SUCCESSFULLY);
                        if (m_Role == (int)CommonValue.QuotationRole.Approver)
                            GetQuotationListForApprover();
                        else
                            GetQuotationListForMaker();
                        //UpdateGridStatus(clsMDConstant.QUOTATIONSTATUS_02_WAIITING_FOR_APPROVE);
                    }
                }
			}
			catch (Exception ex)
			{
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
		}

        /// <summary>
        /// Datagridview's Selection changed even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void dtgDailyQuotationList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dtgDailyQuotationList.SelectedRows.Count > 0)
                {
                    SetRight(dtgDailyQuotationList.SelectedRows[0].Cells[COL_STATUS].Value.ToString(),
                    int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString()));
                    Console.WriteLine(dtgDailyQuotationList.SelectedRows[0].Cells[COL_STATUS].Value.ToString());
                    m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
                    m_CurrentStatus = GetStatusValue(dtgDailyQuotationList.SelectedRows[0].Cells[COL_STATUS].Value.ToString());
                    m_Version = double.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_VERSION].Value.ToString());
                    m_Isactive = !bool.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_INACTIVE].Value.ToString());
                    tsbExport.Enabled = true;
                }
                else
                    tsbExport.Enabled = false;
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Refresh even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                switch (m_Role)
                {
                    case (int)CommonValue.QuotationRole.Approver:
                        GetQuotationListForApprover();
                        break;
                    case (int)CommonValue.QuotationRole.Maker:
                        GetQuotationListForMaker();
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Modify even - call quotation detail screen to modify quotation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void tsbModify_Click(object sender, EventArgs e)
        {
            try
            {
                //vlhcnhung 
                if (dtgDailyQuotationList.SelectedRows.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "quotation", "modify"));
                    return;
                }
                m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
                m_StatusCodeSelected = GetStatusValue(dtgDailyQuotationList.SelectedRows[0].Cells[COL_STATUS].Value.ToString().Trim());
                //
                ///- System open screen [DQ modification] for user to modify data
                /// * This button is enable only if user select [New] DQ
                ViewQuotationDetail((int)CommonValue.QuotationAction.Update_free_text);
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Approve quotation even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void tsbApprove_Click(object sender, EventArgs e)
        {
            try
            {
                //vlhcnhung 
                if (dtgDailyQuotationList.SelectedRows.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "quotation", "approve"));
                    return;
                }
                m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
                m_StatusCodeSelected = GetStatusValue(dtgDailyQuotationList.SelectedRows[0].Cells[COL_STATUS].Value.ToString().Trim());
                m_UserAction = (int)CommonValue.QuotationAction.Approve_Daily_Quotation;

                ///// - System restricted that approver must be different from maker of quotation.--> pending

                /////Click Approve: When user picking Waiting for approve DQ and click [Approve]
                /////- System display a confirm message box “Are you sure to approve data?”	
                /////- User clicks on “Yes” button.																					
                //if (clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_APPROVE_DATA) == DialogResult.Yes)
                //{///- System changes the status “Wait for approve” to “Approved” and the old approved quotation will be unactive
                //    if (ApproveQuotation() > 0)
                //    {
                //        ///- System will popup a message to announce “Daily Quotation was approved successfully"
                //        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.DAILY_QUOTATION_WAS_APPROVED_SUCCESSFULLY);
                //        GetQuotationListForApprover();
                //    }
                //}
                /////- In case of actor clicks [No] on confirm message box, system will not save data in database and close confirm message.																					 - System changes the status “Wait for approve” to “Approved” and the old approved quotation will be unactive
                ///// - Approve Quotation will be displayed in the “View Quotation” screen of other departments.
                ///// - Operation log will be saved.


                //
                ///Click Approve: - System open screen [DQ modification] for user to review data
                /// * This button is enable only if user select [Waiting for Approve] DQ
                ViewQuotationDetail((int)CommonValue.QuotationAction.Approve_Daily_Quotation);
                GetQuotationListForApprover();
            }
            catch (Exception ex)
            {
                m_MDQuoationBus.RollBack();
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Import quotation even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void tsbImport_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_MDQuoationBus.GetLatestQuotationStatus() == (int)CommonValue.QuotationStatus.WaitForApprove)
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.THERE_IS_EXISTED_DAILY_QUOTATION_THAT_IS_WAITING_FOR_APPROVAL);
                else
                {
                    CallImportScreen();
                    switch (m_Role)
                    {
                        case (int)CommonValue.QuotationRole.Approver:
                            GetQuotationListForApprover();
                            break;
                        case (int)CommonValue.QuotationRole.Maker:
                            GetQuotationListForMaker();
                            break;
                    }
                }
                //switch (m_QuotationIDSelected)
                //{
                //    ///- In case user selects [New] or [Approved] DQ or there is no DQ existed in grid
                //    case (int) CommonValue.QuotationStatus.New:
                //    case (int) CommonValue.QuotationStatus.Approved:
                //        ///- System will open screen Import for user to import data	
                //        CallImportScreen();
                //        break;
                //    ///- In case user selects [Withdrawed] or [Returned] or [Suspended] DQ		
                //    case (int) CommonValue.QuotationStatus.Withdrawn:
                //    case (int) CommonValue.QuotationStatus.Returned:
                //    case (int) CommonValue.QuotationStatus.Suspended:
                //        ///- System will open screen Import for user to re-import data	
                //        CallImportScreen();
                //        break;
                //    ///- In case user selects [Waiting for approval] DQ		
                //    case (int) CommonValue.QuotationStatus.WaitForApprove:
                //        ///- System will show error message: "There is existed daily quotation that is waiting for approval"
                //        clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, clsMDMessage.THERE_IS_EXISTED_DAILY_QUOTATION_THAT_IS_WAITING_FOR_APPROVAL);
                //        break;
                //    default:
                //        break;
                //}
            }
            catch (Exception ex)
            {
                m_MDQuoationBus.RollBack();
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Close form even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Return quotation even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void tsbReturn_Click(object sender, EventArgs e)
        {
            try
            {
                //vlhcnhung 
                if (dtgDailyQuotationList.SelectedRows.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "quotation", "return"));
                    return;
                }
                m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
                //
                ///hold on the old id which will be returned
                m_QuotationIDReturnPre = m_QuotationIDSelected;
                ///Click Return: When user picking Waiting for approve DQ and click [Return]																						
                ///- System opens [DQ details] screen for user to input remark field.		
                DialogResult result = ViewQuotationDetail((int)CommonValue.QuotationAction.Return_Daily_Quotation);

                ///- User inputs data into Remark field.		
                ///- User clicks on “Save” button on [DQ details] screen		
                ///- System display a confirm message box “Are you sure to return data?”		
                ///- In case user clicks on “Yes” button.	
                ///- System will popup a message to announce “Data was returned successfully”
                ///- System changes the status of the Quotation to “Returned”.			
                ///- Returned Quotation will displays in “View Quotation of Maker” screen.
                GetQuotationListForApprover();

                ///- Returned Quotation will be hightlighted
                ///- Operation log will be saved.
                ///- In case of user clicks [No] on confirm message box, system will not save data in database and close confirm message and screen [DQ details] as well	
            }
            catch (Exception ex)
            {
                m_MDQuoationBus.RollBack();
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Revise quotation even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void tsbRevise_Click(object sender, EventArgs e)
        {
            try
            {
                //vlhcnhung 
                if (dtgDailyQuotationList.SelectedRows.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "quotation", "revise"));
                    return;
                }
                m_StatusCodeSelected = GetStatusValue(dtgDailyQuotationList.SelectedRows[0].Cells[COL_STATUS].Value.ToString().Trim());
                m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
                //
                m_QuotationIDReturnPre = m_QuotationIDSelected;
                ///Click Revise: When user picking Approved DQ and click [Revise]			
                ///- System opens [DQ details] screen for user to input remark field.		
                DialogResult result = ViewQuotationDetail((int)CommonValue.QuotationAction.Revise_Daily_Quotation);

                ///- User inputs data into Remark field.		
                ///- User clicks on “Save” button on [DQ details] screen		
                ///- System display a confirm message box “Are you sure to revise data?”																														
                ///- In case user clicks on “Yes” button.																													
                ///- System will popup a message to announce “Data was revised successfully”																												
                ///- System changes the status of the Quotation to “Suspended”.																												
                ///- Revised Quotation will be hightlighted				

                GetQuotationListForApprover();

                ///- Operation log will be saved.																												
                ///- In case of user clicks [No] on confirm message box, system will not save data in database and close confirm message and screen [DQ details] as well																													
            }
            catch (Exception ex)
            {
                m_MDQuoationBus.RollBack();
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void tsbPrintPreview_Click(object sender, EventArgs e)
        {
            try
            {
                //vlhcnhung 
                if (dtgDailyQuotationList.SelectedRows.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "quotation", "preview"));
                    return;
                }
                m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
                //
                clsMDQuotationDTO quotationObj = m_MDQuoationBus.GetQuotationDetail(m_QuotationIDSelected);
                DataTable tdbQuotationECRate = m_MDQuoationBus.GetQuotationECRate(m_QuotationIDSelected);
                DataTable tdbQuotationUSD = m_MDQuoationBus.GetQuotationDetailUSD(m_QuotationIDSelected);
                DataTable tdbQuotationVND = m_MDQuoationBus.GetQuotationDetailVND(m_QuotationIDSelected);
                frmMDPreviewQuoationDetail previewQuoationDetail = new frmMDPreviewQuoationDetail(tdbQuotationUSD, tdbQuotationVND, tdbQuotationECRate, quotationObj);
                previewQuoationDetail.StartPosition = FormStartPosition.CenterScreen;
                previewQuoationDetail.ShowDialog();
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        
        /// <summary>
        /// Print preview even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond	
        private void dtgDailyQuotationList_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (dtgDailyQuotationList.Rows.Count <= 0)
            {
                tsbModify.Enabled = false;
                tsbRequestToApprove.Enabled = false;
                tsbWithdraw.Enabled = false;
                tsbApprove.Enabled = false;
                tsbReturn.Enabled = false;
                tsbRevise.Enabled = false;
                tsbPrintPreview.Enabled = false;
                tsbFreeze.Enabled = false;
            }
        }

        /// <summary>
        /// Freeze quotation even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbFreeze_Click(object sender, EventArgs e)
        {
            try
            {
                //vlhcnhung 
                if (dtgDailyQuotationList.SelectedRows.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "quotation", "freeze"));
                    return;
                }
                m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
                //
                //m_UserAction = (int) CommonValue.QuotationAction.Freeze_Daily_Quotation;
                ///'- User is authorized for action "freeze” and slected quotation is "Approved" 
                ///- User clicks on “freeze”
                ///- System display a confirm message box “Are you sure to freeze data?”
                ///- User clicks on “Yes” button.
                ///- System will popup a message to announce “Daily Quotation was freezed successfully”
                ///- In case of actor clicks [No] on confirm message box, system will not save data in database and close confirm message.
                ///- System changes the old approved quotation will be unactive
                ///- Operation log will be saved.
                if (clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_FREEZE_DATA) == DialogResult.Yes)
                {
                    ///- System changes the status “Wait for approve” to “Approved” and the old approved quotation will be unactive
                    if (FreezeQuotation() > 0)
                    {
                        ///- System will popup a message to announce “Daily Quotation was approved successfully"
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.DAILY_QUOTATION_WAS_FREEZED_SUCCESSFULLY);
                        GetQuotationListForApprover();
                    }
                }
            }
            catch (Exception ex)
            {
                m_MDQuoationBus.RollBack();
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Withdraw even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void tsbWithdraw_Click(object sender, EventArgs e)
        {
            try
            {
                //vlhcnhung 
                if (dtgDailyQuotationList.SelectedRows.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "quotation", "withdraw"));
                    return;
                }
                m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
                //
                ///* This button is enable only if user select [Wait For Approve] DQ
                /// - System display a confirm message box “Are you sure to withdraw data?”
                /// - In case user clicks on “Yes” button.
                if (clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_WITHDRAW_DATA) == DialogResult.Yes)
                {
                    if (UpdateQuotationStatus((int)CommonValue.QuotationStatus.Withdrawn) > 0)
                    {
                        /// - System will popup a message to announce “Data was withdraw successfully”
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.DATA_WAS_WITHDRAW_SUCCESSFULLY);

                        /// - System will display confirm message box to ask user: "Do you want to re-import data for Daily Quotation?"
                        ///  - In case user clicks on “Yes” button.
                        if (clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.DO_YOU_WANT_TO_RE_IMPORT_DATA_FOR_DAILY_QUOTATION) == DialogResult.Yes)
                            ///- System will open screen Import for user to re-import data
                            CallImportScreen();
                        GetQuotationListForMaker();
                    }
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        ///// <summary>
        ///// Override ProceeCmdKey
        ///// </summary>
        ///// <param name="msg"></param>
        ///// <param name="keyData"></param>  
        ///// <returns></returns>
        ///// @cond
        ///// Author: vlhcnhung
        ///// @endcond
        //protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        //{
        //    switch (keyData)
        //    {
        //        //+ [Request To Approve] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.R):
        //            {
        //                if (tsbRequestToApprove.Visible == true)
        //                {
        //                    tsbRequestToApprove_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Modify] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.M):
        //            {
        //                if (tsbModify.Visible == true)
        //                {
        //                    tsbModify_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Withdraw] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.W):
        //            {
        //                if (tsbWithdraw.Visible == true)
        //                {
        //                    tsbWithdraw_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Approve] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.A):
        //            {
        //                if (tsbApprove.Visible == true)
        //                {
        //                    tsbApprove_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Return] Toolstrip ShortCut Key                
        //        case (Keys.Alt | Keys.T):
        //            {
        //                if (tsbReturn.Visible == true)
        //                {
        //                    tsbReturn_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Revise] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.V):
        //            {
        //                if (tsbRevise.Visible == true)
        //                {
        //                    tsbRevise_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Freeze] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.F):
        //            {
        //                if (tsbFreeze.Visible == true)
        //                {
        //                    tsbFreeze_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Preview] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.P):
        //            {
        //                if (tsbPrintPreview.Visible == true)
        //                {
        //                    tsbPrintPreview_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Import] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.I):
        //            {
        //                if (tsbImport.Visible == true)
        //                {
        //                    tsbImport_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Export] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.E):
        //            {
        //                if (tsbExport.Visible == true)
        //                {
        //                    tsbExport_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //    }

        //    return base.ProcessCmdKey(ref msg, keyData);
        //}

        ///// <summary>
        ///// Processes a dialog box key.
        ///// </summary>
        ///// <param name="keyData"></param>
        ///// <returns></returns>
        ///// @cond
        ///// Author: vlhcnhung
        ///// @endcond
        //protected override bool ProcessDialogKey(Keys keyData)
        //{
        //    switch (keyData)
        //    {
        //        //+ [Request To Approve] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.R):
        //            {
        //                if (tsbRequestToApprove.Visible == true)
        //                {
        //                    tsbRequestToApprove_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Modify] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.M):
        //            {
        //                if (tsbModify.Visible == true)
        //                {
        //                    tsbModify_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Withdraw] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.W):
        //            {
        //                if (tsbWithdraw.Visible == true)
        //                {
        //                    tsbWithdraw_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Approve] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.A):
        //            {
        //                if (tsbApprove.Visible == true)
        //                {
        //                    tsbApprove_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Return] Toolstrip ShortCut Key                
        //        case (Keys.Alt | Keys.T):
        //            {
        //                if (tsbReturn.Visible == true)
        //                {
        //                    tsbReturn_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Revise] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.V):
        //            {
        //                if (tsbRevise.Visible == true)
        //                {
        //                    tsbRevise_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Freeze] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.F):
        //            {
        //                if (tsbFreeze.Visible == true)
        //                {
        //                    tsbFreeze_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Preview] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.P):
        //            {
        //                if (tsbPrintPreview.Visible == true)
        //                {
        //                    tsbPrintPreview_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Import] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.I):
        //            {
        //                if (tsbImport.Visible == true)
        //                {
        //                    tsbImport_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        //+ [Export] Toolstrip ShortCut Key
        //        case (Keys.Alt | Keys.E):
        //            {
        //                if (tsbExport.Visible == true)
        //                {
        //                    tsbExport_Click(new object(), new EventArgs());
        //                }
        //                break;
        //            }
        //        default:
        //            {
        //                return base.ProcessDialogKey(keyData);
        //            }
        //    }

        //    return true;
        //}

        #region Member Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="strStatus"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private void UpdateGridStatus(string strStatus)
		{
			for (int i = 0; i < dtgDailyQuotationList.Rows.Count; i++)
				if (dtgDailyQuotationList.Rows[i].Cells[COL_QUOTATION_ID].Value.ToString().Trim() == m_QuotationIDSelected.ToString())
					dtgDailyQuotationList.Rows[i].Cells[COL_STATUS].Value = strStatus;
		}

        /// <summary>
        /// Call quotation detail screen
        /// </summary>
        /// <param name="iUserAction">User action: modify, approve, suspend...</param>
        /// <returns>Dialog result of this screen</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private DialogResult ViewQuotationDetail(int iUserAction)
		{
            frmMDQuotationDetail frm = new frmMDQuotationDetail(iUserAction, m_QuotationIDSelected, m_StatusCodeSelected);
			//frm.MdiParent = this.MdiParent;
			frm.StartPosition = FormStartPosition.CenterScreen;
			frm.ShowDialog();
			return frm.DialogResult;
		}

        /// <summary>
        /// Call import screen to import quotation
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private void CallImportScreen()
		{
			frmMDImportQuotation frm = new frmMDImportQuotation();
			frm.StartPosition = FormStartPosition.CenterScreen;//FormStartPosition.CenterParent;//vlhcnhung
			frm.ShowDialog();
		}

        /// <summary>
        /// Update quotation status
        /// </summary>
        /// <param name="iStatusToUpdate">Status code to update</param>
        /// <returns>Rows effected by updating status</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private int UpdateQuotationStatus(int iStatusToUpdate)
		{
			int iRowsUpdate = 0;
			try
			{
				iRowsUpdate = m_MDQuoationBus.UpdateQuotationStatus(m_QuotationIDSelected, iStatusToUpdate);
				/// - Operation log will be saved.
				if (iRowsUpdate > 0)
					WriteLogUpdateStatus(iStatusToUpdate);
			}
			catch (Exception ex)
			{
				if (m_MDQuoationBus.DAL.m_transaction != null)
					m_MDQuoationBus.RollBack();

				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}

			//GetQuotationInfo();
			return iRowsUpdate;
		}

        /// <summary>
        /// Write log for free quotation action
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private void WriteLogFreeQuotation()
		{
			clsMDLogBase logBase = new clsMDLogBase();
			logBase.ApplicationName = this.Text;
			logBase.UserID = clsUserInfo.UserNo.ToString();
			logBase.Module = clsMDConstant.MODULE_MD;
			logBase.Key = m_QuotationIDSelected.ToString();
			logBase.Action = (int) CommonValue.ActionType.Update;

			clsMDLogInformation logInfo = new clsMDLogInformation();
			logInfo.FieldName = "IsActive";
			logInfo.OldValue = m_Isactive.ToString();
			logInfo.NewValue = false.ToString();
			logBase.LstLogInformation.Add(logInfo);
			logBase.WirteLog(m_MDQuoationBus.DAL);

			m_MDQuoationBus.Commit();
		}

        /// <summary>
        /// Write log for update quotation action
        /// </summary>
        /// <param name="iNewSatus">Quotaion's status to be updated</param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private void WriteLogUpdateStatus(int iNewSatus)
		{
			clsMDLogBase logBase = new clsMDLogBase();
			logBase.ApplicationName = this.Text;
			logBase.UserID = clsUserInfo.UserNo.ToString();
			logBase.Module = clsMDConstant.MODULE_MD;
			logBase.Key = m_QuotationIDSelected.ToString();
			logBase.Action = (int) CommonValue.ActionType.Update;

			clsMDLogInformation logInfo = new clsMDLogInformation();
			logInfo.FieldName = "IsActive";
			logInfo.OldValue = m_StatusCodeSelected.ToString();
			logInfo.NewValue = iNewSatus.ToString();
			logBase.LstLogInformation.Add(logInfo);
			logBase.WirteLog(m_MDQuoationBus.DAL);

			m_MDQuoationBus.Commit();
		}
        
        /// <summary>
        /// Get quotation list for approver
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private void GetQuotationListForApprover()
		{
			try
			{
				dtgDailyQuotationList.Rows.Clear();
				DataTable dtbQuotation = m_MDQuoationBus.GetQuotationListForApprover();
				//if (dtbQuotation.Rows.Count <= 0)
				//    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, clsMDMessage.NO_TRANSACTION_FOUND);
				for (int i = 0; i < dtbQuotation.Rows.Count; i++)
				{
					string strSequence = dtbQuotation.Rows[i]["Seq"].ToString();
					int iStatus = int.Parse(dtbQuotation.Rows[i]["Status"].ToString());
					string strStatus = GetStatusText(iStatus);
					DateTime dtCreateDate = DateTime.Parse(dtbQuotation.Rows[i]["ImportTime"].ToString());
					string strCreateDate = dtCreateDate.ToString(FORMAT_DDMMMYYYY);
					string strCreateTime = dtbQuotation.Rows[i]["EffectiveTime"].ToString();
					bool isActive = bool.Parse(dtbQuotation.Rows[i]["IsActive"].ToString());
					int iQuotaionID = int.Parse(dtbQuotation.Rows[i]["QuotationID"].ToString());
					double dVersion = double.Parse(dtbQuotation.Rows[i]["Version"].ToString());
                    //2013.05.16 UDP vlhcnhung S Display two columns Marker and Approval (UserName) the same with History Screen
                    string strApprover = dtbQuotation.Rows[i]["ApprovedBy"].ToString();
                    string strMaker = dtbQuotation.Rows[i]["CreatedBy"].ToString();
                    //2013.05.16 UDP vlhcnhung E Display two columns Marker and Approval (UserName) the same with History Screen
                    dtgDailyQuotationList.Rows.Add(strSequence, strStatus, !isActive, strCreateDate, strCreateTime, strMaker, strApprover, iQuotaionID, dVersion);
				}
			}
			catch (Exception ex)
			{
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
		}

        /// <summary>
        /// Get quotation list for maker
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private void GetQuotationListForMaker()
		{
			try
			{
				dtgDailyQuotationList.Rows.Clear();
				DataTable dtbQuotation = m_MDQuoationBus.GetQuotationListForMaker();
				//if (dtbQuotation.Rows.Count <= 0)
				//    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, clsMDMessage.NO_TRANSACTION_FOUND);
				for (int i = 0; i < dtbQuotation.Rows.Count; i++)
				{
					string strSequence = dtbQuotation.Rows[i]["Seq"].ToString();
					int iStatus = int.Parse(dtbQuotation.Rows[i]["Status"].ToString());
					string strStatus = GetStatusText(iStatus);
					DateTime dtCreateDate = DateTime.Parse(dtbQuotation.Rows[i]["ImportTime"].ToString());
					string strCreateDate = dtCreateDate.ToString(FORMAT_DDMMMYYYY);
					string strCreateTime = dtbQuotation.Rows[i]["EffectiveTime"].ToString();
					bool isActive = bool.Parse(dtbQuotation.Rows[i]["IsActive"].ToString());
					int iQuotaionID = int.Parse(dtbQuotation.Rows[i]["QuotationID"].ToString());
					double dVersion = double.Parse(dtbQuotation.Rows[i]["Version"].ToString());
                    //2013.05.16 UDP vlhcnhung S Display two columns Marker and Approval (UserName) the same with History Screen
                    string strApprover = dtbQuotation.Rows[i]["ApprovedBy"].ToString();
                    string strMaker = dtbQuotation.Rows[i]["CreatedBy"].ToString();
                    //2013.05.16 UDP vlhcnhung E Display two columns Marker and Approval (UserName) the same with History Screen
                    dtgDailyQuotationList.Rows.Add(strSequence, strStatus, !isActive, strCreateDate, strCreateTime, strMaker, strApprover, iQuotaionID, dVersion);
				}
			}
			catch (Exception ex)
			{
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
		}		

		/// <summary>
		/// modify
		/// request to approve
		/// withdraw
		/// approve
		/// freeze
		/// return
		/// revise
		/// </summary>
		/// <param name="strStatus"></param>
		private void SetRight(string strStatus, int iQuotationID)
		{
			tsbModify.Enabled = false;
			tsbRequestToApprove.Enabled = false;
			tsbWithdraw.Enabled = false;
			tsbApprove.Enabled = false;
			tsbReturn.Enabled = false;
			tsbRevise.Enabled = false;
			tsbPrintPreview.Enabled = false;
			tsbFreeze.Enabled = false;
			tsbImport.Enabled = false;
			switch (strStatus)
			{
				case clsMDConstant.QUOTATIONSTATUS_01_NEW:
					tsbModify.Enabled = true;
					tsbRequestToApprove.Enabled = true;
					//check security
                    if (tsbModify.Tag != null && !string.IsNullOrEmpty(tsbModify.Tag.ToString()))
                    {
                        tsbModify.Enabled = bool.Parse(tsbModify.Tag.ToString());
                    }
                    if (tsbRequestToApprove.Tag != null && !string.IsNullOrEmpty(tsbRequestToApprove.Tag.ToString()))
                    {
                        tsbRequestToApprove.Enabled = bool.Parse(tsbRequestToApprove.Tag.ToString());
                    }
					break;

				case clsMDConstant.QUOTATIONSTATUS_02_WAIITING_FOR_APPROVE:
					tsbWithdraw.Enabled = true;
					tsbReturn.Enabled = true;
					tsbApprove.Enabled = true;
					//check security
                    if (tsbWithdraw.Tag != null && !string.IsNullOrEmpty(tsbWithdraw.Tag.ToString()))
                    {
                        tsbWithdraw.Enabled = bool.Parse(tsbWithdraw.Tag.ToString());
                    }
                    if (tsbReturn.Tag != null && !string.IsNullOrEmpty(tsbReturn.Tag.ToString()))
                    {
                        tsbReturn.Enabled = bool.Parse(tsbReturn.Tag.ToString());
                    }
                    if (tsbApprove.Tag != null && !string.IsNullOrEmpty(tsbApprove.Tag.ToString()))
                    {
                        tsbApprove.Enabled = bool.Parse(tsbApprove.Tag.ToString());
                    }
					break;

				case clsMDConstant.QUOTATIONSTATUS_03_APPROVED:
					tsbRevise.Enabled = true;
					tsbPrintPreview.Enabled = true;
					tsbFreeze.Enabled = true;
                    if (m_MDQuoationBus.ChecQuotationFreeze(iQuotationID) > 0)
                    {
                        tsbFreeze.Enabled = false;
                    }
                    else
                    {
                        tsbFreeze.Enabled = true;
                        if (tsbFreeze.Tag != null && !string.IsNullOrEmpty(tsbFreeze.Tag.ToString()))
                        {
                            tsbFreeze.Enabled = bool.Parse(tsbFreeze.Tag.ToString());
                        }
                    }
					//check security
                    if (tsbRevise.Tag != null && !string.IsNullOrEmpty(tsbRevise.Tag.ToString()))
                    {
                        tsbRevise.Enabled = bool.Parse(tsbRevise.Tag.ToString());
                    }
                    if (tsbPrintPreview.Tag != null && !string.IsNullOrEmpty(tsbPrintPreview.Tag.ToString()))
                    {
                        tsbPrintPreview.Enabled = bool.Parse(tsbPrintPreview.Tag.ToString());
                    }
					break;

				case clsMDConstant.QUOTATIONSTATUS_04_WITHDRAWN:
					tsbModify.Enabled = true;
					//check security
                    if (tsbModify.Tag != null && !string.IsNullOrEmpty(tsbModify.Tag.ToString()))
                    {
                        tsbModify.Enabled = bool.Parse(tsbModify.Tag.ToString());
                    }
					break;

				case clsMDConstant.QUOTATIONSTATUS_05_RETURNED:
                    tsbModify.Enabled = true;
					break;

				case clsMDConstant.QUOTATIONSTATUS_06_SUSPENDED:
                    tsbModify.Enabled = true;
					break;

				case clsMDConstant.QUOTATIONSTATUS_07_OBSOLUTE:
					break;

				default:
					break;
			}
			switch (m_Role)
			{
				case (int) CommonValue.QuotationRole.Maker:
					tsbApprove.Visible = false;
					tsbReturn.Visible = false;
					tsbRevise.Visible = false;
					tsbFreeze.Visible = false;
					tsbImport.Enabled = true;
					tsbPrintPreview.Enabled = true;
                    //check security
                    if (tsbPrintPreview.Tag != null && !string.IsNullOrEmpty(tsbPrintPreview.Tag.ToString()))
                    {
                        tsbPrintPreview.Enabled = bool.Parse(tsbPrintPreview.Tag.ToString());
                    }
					break;
				case (int) CommonValue.QuotationRole.Approver:
					tsbRequestToApprove.Visible = false;
					tsbModify.Visible = false;
					tsbWithdraw.Visible = false;
					tsbImport.Visible = false;
					break;
				default:
					break;
			}
		}

        /// <summary>
        /// Approve quotation
        /// </summary>
        /// <returns>Rows effected when approving</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private int ApproveQuotation()
		{
			int iRowsUpdate = 0;
			try
			{
				iRowsUpdate = m_MDQuoationBus.ApproveQuotation(m_QuotationIDSelected, m_Version);
				if (iRowsUpdate > 0)
					WriteLogUpdateStatus((int) CommonValue.QuotationStatus.Approved);
			}
			catch (Exception ex)
			{
				if (m_MDQuoationBus.DAL.m_transaction != null)
					m_MDQuoationBus.RollBack();

				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
			return iRowsUpdate;
		}

        /// <summary>
        /// Free quotation
        /// </summary>
        /// <returns>Rows effected by freezing quotation</returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
		private int FreezeQuotation()
		{
			int iRowsUpdate = 0;
			try
			{
				iRowsUpdate = m_MDQuoationBus.FreezeQuotation(m_QuotationIDSelected);
				if (iRowsUpdate > 0)
					WriteLogFreeQuotation();
			}
			catch (Exception ex)
			{
				if (m_MDQuoationBus.DAL.m_transaction != null)
					clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				m_MDQuoationBus.RollBack();
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
			return iRowsUpdate;
        }
        #endregion

        #region Export Excel
        /// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
		private void tsbExport_Click(object sender, EventArgs e)
		{
            try
            {
                if (dtgDailyQuotationList.SelectedRows.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_QUOTATION_EXPORT);
                    return;
                }
                m_QuotationIDSelected = int.Parse(dtgDailyQuotationList.SelectedRows[0].Cells[COL_QUOTATION_ID].Value.ToString());
                ExportToExcel();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// 
		/// </summary>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
		private void ExportToExcel()
		{
			if (dtgDailyQuotationList.SelectedRows.Count > 0)
			{
				m_FileName = clsMDConstant.EXCEL_TEMPLATE_NAME_DETAIL_DAILY_QUOTATION + clsMDBus.Instance().GetServerDate();
				m_TemplateName = clsMDConstant.EXCEL_TEMPLATE_FILE_DETAIL_DAILY_QUOTATION;
				bool isOPened = false;
				m_ExcelBase = new Config.Classes.ExcelBase(m_FileName, m_TemplateName, m_ProjectName, ref isOPened, clsMDBus.Instance().GetServerDate());
				if (isOPened)
					return;
				m_worker = new Config.Classes.CWorker(ExportQuotation, Complete);
				m_worker.Start();
			}
		}

		/// <summary>
		/// Handling when completed a thread
		/// </summary>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
		private void Complete()
		{
			//m_ExcelBase.SaveFileNotAutoFitColumns();            
		}

		private void ExportQuotation()
		{
			clsMDFunction.ExportQuotation(m_ProjectName, m_QuotationIDSelected, FORMAT_DDMMMYYYY);
		}
		
		///// <summary>
		///// 
		///// </summary>
		///// <param name="dt"></param>
		///// <param name="isMergeCell"></param>
		///// @cond
		///// Author: vlhcnhung
		///// @endcond
		//private void MergeCellAndFormatNumber(DataTable dt, bool isMergeCell, int iRowStart, int iRowCountMerge, int iColStart, int iColCountMerge) 
		//{
		//    clsMDFunction.ExportQuotation(m_ProjectName, m_QuotationIDSelected, FORMAT_DDMMMYYYY);
		//}
		#endregion        
	}
}