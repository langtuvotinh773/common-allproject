﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-18 (Mon, 18 March 2013) $
 * ========================================================
 * This class is used to create or modify a user object
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Config.Classes;
using System.Security.Cryptography;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDUserAddModify : frmMDMaster
    {
        #region Global Variable
        public clsMDUserDTO m_UpdatingUser;
        public event EventHandler OnSaved;        
        const string m_Check_True = "True";
        bool m_ForceClose = false;//if m_ForceClose = true, close form not check changed data
        bool m_ResetPass = false;
        string strOldAssignDeptCodeList = string.Empty;
        public CommonValue.ActionType m_CurrentAction = CommonValue.ActionType.New;

        //get default password from table parameters
        string USER_PASSWORD;

        // For Security Checking
        clsSEAuthorizer m_Security = null; 
        
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDUserAddModify class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDUserAddModify(string title)
        {
            InitializeComponent();
            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);
            try
            { 
                this.USER_PASSWORD = clsMDBus.Instance().GetPasswordDefault();

                this.Text = title;
                this.m_UpdatingUser = new clsMDUserDTO();
                txtPassword.Text = USER_PASSWORD;
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Form Load
        /// Set default settings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDUserAddModify_Load(object sender, EventArgs e)
        {
            try
            {
                //Set common style for form
                SetFormStyleCommon();
                //if current action is Create User, system will load all department to un-assign departments to listview
                if (m_CurrentAction == CommonValue.ActionType.New)
                {
                    GetUnassign_AssignDeptList(0);
                    btnResetPass.Enabled = false;
                }
                else//if current action is Create User, system will load list assign and un-assign departments based on user
                {
                    GetUnassign_AssignDeptList(m_UpdatingUser.UserNo);
                    btnResetPass.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click button "Save"
        /// if current action is create, system will save a new user into DB
        /// if current action is modify, system will update information user into DB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            //disable all button while system excute save function.
            EnableButtonControl(false);
            try
            {
                if (this.m_CurrentAction == CommonValue.ActionType.New)
                {
                    //Save new user to db
                    if (SaveCreateAction() > 0)
                    {                        
                        this.m_ForceClose = true;
                        if (OnSaved != null)
                        {
                            OnSaved(sender, e);
                        }
                        this.Close();
                    }
                }
                else
                {
                    //update information of user to db
                    if (SaveModifyAction() > 0)
                    {                        
                        this.m_ForceClose = true;
                        if (OnSaved != null)
                        {
                            OnSaved(sender, e);
                        }
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button based on security
            EnableButtonControl(true);
        }

        /// <summary>
        /// Event click button "Cancel"
        /// If no data was changed on screen, system will close this screen
        /// If data was changed on screen, system will display a confirm message box: “Do you want to save changes of data?”
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        /// <summary>
        /// Form Close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDUserAddModify_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                //disable all button
                EnableButtonControl(false);
                try
                {
                    if (!m_ForceClose)
                    {
                        //if data was changed on screen, display confirm message to save changed data
                        if (IsDataChanged())
                        {
                            //display message 'Do you want to save changes of data?'
                            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                            if (res == DialogResult.Yes)
                            {
                                //check valid data
                                if (IsValidData())
                                {
                                    //save data and close form
                                    if (this.m_CurrentAction == CommonValue.ActionType.New)
                                    {
                                        //save new user
                                        if (SaveANewUser() > 0)
                                        {
                                            this.m_ForceClose = true;
                                            if (OnSaved != null)
                                            {
                                                OnSaved(sender, e);
                                            }
                                        }
                                        else//if save unsuccessfull, display error message and not close form
                                        {
                                            e.Cancel = true;
                                        }
                                    }
                                    else
                                    {
                                        //update information of user
                                        if (SaveAModifiedUser() > 0)
                                        {
                                            this.m_ForceClose = true;
                                            if (OnSaved != null)
                                            {
                                                OnSaved(sender, e);
                                            }
                                        }
                                        else//if save unsuccessfull, display error message and not close form
                                        {
                                            e.Cancel = true;
                                        }
                                    }
                                }
                                else
                                {
                                    //do nothing
                                    e.Cancel = true;
                                }
                            }
                            else if (res == DialogResult.Cancel)
                            {
                                //do nothing
                                e.Cancel = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    //show error message
                    clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                    //save log exception
                    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
                }
                //enable all button based on security
                EnableButtonControl(true);
            }
        }

        /// <summary>
        /// Event click ReserPassword button
        /// Enable textbox for user can input new pass
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnResetPass_Click(object sender, EventArgs e)
        {
            txtPassword.Text = USER_PASSWORD;
            m_ResetPass = true;
            btnSave_Click(sender, e);
        }

        /// <summary>
        /// Event click button ">>"
        /// Tranfer all item in ListView left to right
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnDoubleRight_Click(object sender, EventArgs e)
        {
            if (listViewLeft.Items != null && listViewLeft.Items.Count > 0)
            {
                foreach (ListViewItem item in listViewLeft.Items)
                {
                    listViewLeft.Items.Remove(item);
                    listViewRight.Items.Add(item);
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
        }

        /// <summary>
        /// Event click button ">"
        /// Tranfer selected item in ListView left to right
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSingleRight_Click(object sender, EventArgs e)
        {
            if (listViewLeft.SelectedItems.Count > 0)
            {
                foreach (ListViewItem item in listViewLeft.SelectedItems)
                {
                    listViewLeft.Items.Remove(item);
                    listViewRight.Items.Add(item);
                }
            }
            else
            {
                //if user not choose any item, display message 'Please select a department to assign.'
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one department", "assign"));
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
        }

        /// <summary>
        /// Event click button "<"
        /// Tranfer selected item in ListView right to left
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSingleLeft_Click(object sender, EventArgs e)
        {
            if (listViewRight.SelectedItems.Count > 0)
            {
                foreach (ListViewItem item in listViewRight.SelectedItems)
                {
                    listViewRight.Items.Remove(item);
                    listViewLeft.Items.Add(item);
                }
            }
            else
            {
                //if user not choose any item, display message 'Please select a department to unassign.'
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one department", "unassign"));
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
        }

        /// <summary>
        /// Event click button "<<"
        /// Tranfer all item in ListView right to left
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnDoubleLeft_Click(object sender, EventArgs e)
        {
            if (listViewRight.Items != null && listViewRight.Items.Count > 0)
            {
                foreach (ListViewItem item in listViewRight.Items)
                {
                    listViewRight.Items.Remove(item);
                    listViewLeft.Items.Add(item);
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
        }
        #endregion

        #region Member Methods
        /// <summary>
        /// Enable or disable button control
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnCancel.Enabled = value;
            btnSave.Enabled = value;
            //check security
            if (value)
            {
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
        }
      
        /// <summary>
        /// Check validation data
        /// </summary>
        /// <returns>
        /// if any required field is invalid, system will display a warning message and return false
        /// else return true
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool IsValidData()
        {
            if (string.IsNullOrEmpty(txtUserName.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "User Name"));
                txtUserName.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtFullName.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Full Name"));
                txtFullName.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtPassword.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Password"));
                txtPassword.Focus();
                return false;
            }
            
            int iNewUser = (this.m_CurrentAction == CommonValue.ActionType.New) ? 0 : 1;
            int iUserNo = (this.m_CurrentAction == CommonValue.ActionType.New) ? -1 : m_UpdatingUser.UserNo;
            Dictionary<string, int> checkDuplicate = clsMDUserBUS.Instance().ValidationDuplicateUser(iNewUser, iUserNo, txtUserName.Text.Trim());
            if (checkDuplicate.ContainsKey(clsMDConstant.MD_COL_USERNAME))
            {
                int value = checkDuplicate[clsMDConstant.MD_COL_USERNAME];
                if (value > 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_ITEM_EXISTED, "User Name"));
                    txtUserName.Focus();
                    return false;
                }
            }            
            return true;
        }

        /// <summary>
        /// load data to form
        /// </summary>
        /// <param name="obj">clsMDUserDTO</param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public void SetData(clsMDUserDTO obj)
        {            
            txtUserName.Text = obj.UserName;
            txtShortName.Text = obj.ShortName;
            txtFullName.Text = obj.FullName;            
            txtRemark.Text = obj.Remark;
            txtPassword.Text = obj.Password;
            ckbOfficer.Checked = obj.Officer.CompareTo(m_Check_True) == 0 ? true : false;
            ckbStaff01.Checked = obj.Staff01.CompareTo(m_Check_True) == 0 ? true : false;
            ckbStaff02.Checked = obj.Staff02.CompareTo(m_Check_True) == 0 ? true : false;
            ckbLockout.Checked = obj.Lockout.CompareTo(m_Check_True) == 0 ? true : false;

            GetUnassign_AssignDeptList(obj.UserNo);
        }

        /// <summary>
        /// Get Unassign, Assign Department List by UserNo
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetUnassign_AssignDeptList(int iUserNo)
        {
            listViewLeft.Items.Clear();
            listViewRight.Items.Clear();

            DataTable dtUnassignDept = clsMDUserBUS.Instance().GetUnassignDeptList(iUserNo);
            DataTable dtAssignDept = clsMDUserBUS.Instance().GetAssignDeptList(iUserNo);

            LoadDataToDeptListView(dtUnassignDept, listViewLeft);
            LoadDataToDeptListView(dtAssignDept, listViewRight);
            strOldAssignDeptCodeList = GetAssignDeptCodeList(listViewRight);
        }

        /// <summary>
        /// Load Unassign, Assign Department List to control
        /// </summary>
        /// <param name="dtUser">DataTable</param>
        /// <param name="listView">ListView</param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        void LoadDataToDeptListView(DataTable dtDept, ListView listView)
        {
            if (dtDept != null)
            {
                for (int i = 0; i < dtDept.Rows.Count; i++)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = dtDept.Rows[i][clsMDConstant.MD_COL_DEPARTMENTNAME].ToString();
                    item.Name = dtDept.Rows[i][clsMDConstant.MD_COL_DEPARTMENTCODE].ToString();                    
                    item.Tag = int.Parse(dtDept.Rows[i][clsMDConstant.MD_COL_DEPARTMENTID].ToString());
                    listView.Items.Add(item);
                }
            }
        }

        /// <summary>
        /// Get User information from controls to create or modify
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private clsMDUserDTO GetUserInfoFromControls()
        {
            clsMDUserDTO dto = new clsMDUserDTO();
            if (this.m_CurrentAction == CommonValue.ActionType.Update)
            {
                dto.UserNo = m_UpdatingUser.UserNo;
                //not update pass
                if (m_UpdatingUser.Password.CompareTo(txtPassword.Text) == 0)
                {
                    dto.Password = txtPassword.Text;
                }
                else
                {
                    dto.Password = clsMDFunction.GetMD5HashData(txtPassword.Text);
                    if (m_UpdatingUser.Password.CompareTo(txtPassword.Text) == 0)
                    {
                        dto.Password = txtPassword.Text;
                    }
                }
            }
            else
            {
                dto.DelFlag = false;
                dto.Password = clsMDFunction.GetMD5HashData(txtPassword.Text);
            }
            dto.UserName = txtUserName.Text;
            dto.ShortName = txtShortName.Text;
            dto.FullName = txtFullName.Text;
            dto.Officer = ckbOfficer.Checked.ToString();
            dto.Staff01 = ckbStaff01.Checked.ToString();
            dto.Staff02 = ckbStaff02.Checked.ToString();
            dto.Lockout = ckbLockout.Checked.ToString();
            dto.Remark = txtRemark.Text;
            dto.CreatedBy = clsUserInfo.UserNo;
            dto.UpdateDate = DateTime.Now;

            return dto;
        }

        /// <summary>
        /// Get DepartmetnID selected to assign
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private string GetAssignDeptIDList()
        {
            string strDepartmentID = string.Empty;
            foreach (ListViewItem item in listViewRight.Items)
            {
                if (string.IsNullOrEmpty(strDepartmentID))
                {
                    strDepartmentID += item.Tag.ToString();
                }
                else
                {
                    strDepartmentID += "," + item.Tag.ToString();
                }
            }
            return strDepartmentID;
        }

        /// <summary>
        /// Get DepartmetnCode selected to assign
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private string GetAssignDeptCodeList(ListView listView)
        {
            string strDepartmentCode = string.Empty;
            foreach (ListViewItem item in listView.Items)
            {
                if (string.IsNullOrEmpty(strDepartmentCode))
                {
                    strDepartmentCode += item.Name.ToString();
                }
                else
                {
                    strDepartmentCode += ", " + item.Name.ToString();
                }
            }
            return strDepartmentCode;
        }
     
        /// <summary>
        /// Save for action Create User
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private int SaveCreateAction()
        {
            //check valid data
            if (IsValidData())
            {
                //2013.06.12 UDP vlhcnhung S Show msg warning to assign user to at least department
                if (listViewRight.Items.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, "User should belong to at least one department.");
                }
                //2013.06.12 UDP vlhcnhung E Show msg warning to assign user to at least department
                //display confirm message 'Are you sure to save user?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "user"));
                if (res == DialogResult.Yes)
                {                    
                    return SaveANewUser();
                }
                else if (res == DialogResult.No)
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
            }
            return 0;
        }

        /// <summary>
        /// Save a new User
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private int SaveANewUser()
        {
            m_UpdatingUser = GetUserInfoFromControls();
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //get list DepartmentID to assign
            string selectedDept = GetAssignDeptIDList();             
            //Create User and Write data to log
            int row = clsMDUserBUS.Instance().InsertUser(m_UpdatingUser, selectedDept, logBase);
            // If Insert OK
            if (row > 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Creating", "user"));
            }
            else if (row == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Creating", "user"));
            }
            else
            {
                this.m_ForceClose = true;
                this.Close();
            }
            return row;
        }        
        
        /// <summary>
        /// Save for action Modify Department
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private int SaveModifyAction()
        {
            //check valid data
            if (IsValidData())
            {
                //2013.06.12 UDP vlhcnhung S Show msg warning to assign user to at least department
                if (listViewRight.Items.Count <= 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, "User should belong to at least one department.");
                }
                //2013.06.12 UDP vlhcnhung E Show msg warning to assign user to at least department
                //display confirm message 'Are you sure to save user?'
                DialogResult res = this.m_ResetPass==false? 
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "user"))
                : clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, "Are you sure to reset password?");                
                if (res == DialogResult.Yes)
                {                   
                    return SaveAModifiedUser();
                }
                else if (res == DialogResult.No)
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
            }
            return 0;
        }

        /// <summary>
        /// Save a modified user
        /// </summary>
        /// <returns></returns>
        private int SaveAModifiedUser()
        {
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //get list DepartmentID to assign
            m_UpdatingUser = GetUserInfoFromControls();
            string selectedDept = GetAssignDeptIDList();
            //Update User and Write data to log
            int row = clsMDUserBUS.Instance().UpdateUser(m_UpdatingUser, selectedDept, logBase);
            // If Update OK
            if (this.m_ResetPass)
            {
                //Resetting password is successful
                if (row > 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Resetting", "password"));
                }
                else if (row == 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Resetting", "password"));
                }
                else
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
                this.m_ResetPass = false;
            }
            else
            {
                if (row > 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Modifying", "user"));
                }
                else if (row == 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Modifying", "user"));
                }
                else
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
            }
            return row;
        }
        
        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool IsDataChanged()
        {
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                if (string.IsNullOrEmpty(txtUserName.Text.Trim()) && string.IsNullOrEmpty(txtShortName.Text.Trim())
                    && string.IsNullOrEmpty(txtFullName.Text.Trim()) && string.IsNullOrEmpty(txtRemark.Text.Trim())
                    && txtPassword.Text.CompareTo(USER_PASSWORD)==0 && ckbOfficer.Checked == false && ckbStaff01.Checked == false
                    && ckbStaff02.Checked == false && ckbLockout.Checked == false && !IsChangeDataAssignedDept() && ckbOfficer.Checked==false
                    && ckbStaff01.Checked==false && ckbStaff02.Checked==false && ckbLockout.Checked==false)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                if (this.m_UpdatingUser.ShortName.CompareTo(txtShortName.Text.Trim()) != 0)
                {
                    return true;
                }
                if (this.m_UpdatingUser.FullName.CompareTo(txtFullName.Text.Trim()) != 0)
                {
                    return true;
                }
                if (!clsMDFunction.ValidateMD5HashData(txtPassword.Text,this.m_UpdatingUser.Password))
                {
                    if (this.m_UpdatingUser.Password.CompareTo(txtPassword.Text) != 0)
                    {
                        return true;
                    }
                }
                if (string.IsNullOrEmpty(this.m_UpdatingUser.Officer))
                {
                    this.m_UpdatingUser.Officer = false.ToString();
                }
                if (string.IsNullOrEmpty(this.m_UpdatingUser.Staff01))
                {
                    this.m_UpdatingUser.Staff01 = false.ToString();
                }
                if (string.IsNullOrEmpty(this.m_UpdatingUser.Staff02))
                {
                    this.m_UpdatingUser.Staff02 = false.ToString();
                }
                if (string.IsNullOrEmpty(this.m_UpdatingUser.Lockout))
                {
                    this.m_UpdatingUser.Lockout = false.ToString();
                }
                if (bool.Parse(this.m_UpdatingUser.Officer) != ckbOfficer.Checked)
                {
                    return true;
                }
                if (bool.Parse(this.m_UpdatingUser.Staff01) != ckbStaff01.Checked)
                {
                    return true;
                }
                if (bool.Parse(this.m_UpdatingUser.Staff02) != ckbStaff02.Checked)
                {
                    return true;
                }
                if (bool.Parse(this.m_UpdatingUser.Lockout) != ckbLockout.Checked)
                {
                    return true;
                }
                if (this.m_UpdatingUser.Remark.CompareTo(txtRemark.Text.Trim()) != 0)
                {
                    return true;
                }
                if (IsChangeDataAssignedDept())
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool IsChangeDataAssignedDept()
        {
            ListView listRight = new ListView();
            DataTable dt = new DataTable();
            int iUserNo = 0;
            //
            if (m_CurrentAction == CommonValue.ActionType.Update)
            {
                iUserNo = m_UpdatingUser.UserNo;
            }
            dt = clsMDUserBUS.Instance().GetAssignDeptList(iUserNo);
            LoadDataToDeptListView(dt, listRight);
            //
            if (listRight.Items.Count == 0 && listViewRight.Items.Count > 0)
            {
                return true;
            }
            else if (listRight.Items.Count > 0 && listViewRight.Items.Count == 0)
            {
                return true;
            }
            else if (listRight.Items.Count != listViewRight.Items.Count)
            {
                return true;
            }
            else
            {
                Dictionary<string, string> checkList = new Dictionary<string, string>();
                foreach (ListViewItem item in listRight.Items)
                {
                    checkList.Add(item.Tag.ToString(), item.Text);
                }
                foreach (ListViewItem item in listViewRight.Items)
                {
                    if (!checkList.ContainsValue(item.Text))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Create data user to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private clsMDLogBase CreateDataSaveLog()
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_SE;
            logBase.Key = txtUserName.Text.Trim();//main key is username
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logBase.Action = (int)CommonValue.ActionType.New;
            }
            else
            {
                logBase.Action = (int)CommonValue.ActionType.Update;
            }

            clsMDLogInformation logInfo = new clsMDLogInformation();

            //UserName
            logInfo.FieldName = clsMDConstant.MD_COL_USERNAME;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingUser.UserName;
            }
            logInfo.NewValue = txtUserName.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //ShortName
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_SHORTNAME;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingUser.ShortName;
            }
            logInfo.NewValue = txtShortName.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //FullName
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_FULLNAME;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingUser.FullName;
            }
            logInfo.NewValue = txtFullName.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //Password
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_PASSWORD;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingUser.Password;
            }
            logInfo.NewValue = clsMDFunction.GetMD5HashData(txtPassword.Text);
            logBase.LstLogInformation.Add(logInfo);
            //Officer
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_OFFICER;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingUser.Officer.ToString();
            }
            logInfo.NewValue = ckbOfficer.Checked.ToString();
            logBase.LstLogInformation.Add(logInfo);
            //Staff01
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_STAFF01;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingUser.Staff01;
            }
            logInfo.NewValue = ckbStaff01.Checked.ToString();
            logBase.LstLogInformation.Add(logInfo);
            //Staff02
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_STAFF02;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingUser.Staff02.ToString();
            }
            logInfo.NewValue = ckbStaff02.Checked.ToString();
            logBase.LstLogInformation.Add(logInfo);
            //Lockout
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_LOCKOUT;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingUser.Lockout;
            }
            logInfo.NewValue = ckbLockout.Checked.ToString();
            logBase.LstLogInformation.Add(logInfo);
            //Remark
            if (!string.IsNullOrEmpty(txtRemark.Text.Trim()))
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = clsMDConstant.MD_COL_REMARK;
                if (this.m_CurrentAction == CommonValue.ActionType.New)
                {
                    logInfo.OldValue = string.Empty;
                }
                else
                {
                    logInfo.OldValue = this.m_UpdatingUser.Remark;
                }
                logInfo.NewValue = txtRemark.Text.Trim();
                logBase.LstLogInformation.Add(logInfo);
            }
            //Department
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                if (listViewRight.Items.Count > 0)
                {
                    logInfo = new clsMDLogInformation();
                    logInfo.FieldName = clsMDConstant.MD_COL_DEPARTMENTCODE;
                    logInfo.OldValue = string.Empty;
                    logInfo.NewValue = GetAssignDeptCodeList(listViewRight);
                    logBase.LstLogInformation.Add(logInfo);
                }
            }
            else
            {
                if (listViewRight.Items.Count > 0 || !string.IsNullOrEmpty(strOldAssignDeptCodeList))
                {
                    logInfo = new clsMDLogInformation();
                    logInfo.FieldName = clsMDConstant.MD_COL_DEPARTMENTCODE;
                    logInfo.OldValue = strOldAssignDeptCodeList;
                    logInfo.NewValue = GetAssignDeptCodeList(listViewRight);
                    logBase.LstLogInformation.Add(logInfo);
                }
            }
            return logBase;
        }
        #endregion        
    }
}
