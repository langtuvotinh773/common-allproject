﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMasListCeilingFloor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dtgCeilingFloorList = new System.Windows.Forms.DataGridView();
            this.colCCYPair = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCeiling = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFloor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCeilingFloorID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnModify = new System.Windows.Forms.Button();
            this.btCreate = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCeilingFloorList)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgCeilingFloorList
            // 
            this.dtgCeilingFloorList.AllowUserToAddRows = false;
            this.dtgCeilingFloorList.AllowUserToDeleteRows = false;
            this.dtgCeilingFloorList.AllowUserToResizeColumns = false;
            this.dtgCeilingFloorList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgCeilingFloorList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgCeilingFloorList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgCeilingFloorList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgCeilingFloorList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCCYPair,
            this.colCeiling,
            this.colFloor,
            this.colCeilingFloorID});
            this.dtgCeilingFloorList.EnableHeadersVisualStyles = false;
            this.dtgCeilingFloorList.Location = new System.Drawing.Point(12, 12);
            this.dtgCeilingFloorList.MultiSelect = false;
            this.dtgCeilingFloorList.Name = "dtgCeilingFloorList";
            this.dtgCeilingFloorList.RowHeadersVisible = false;
            this.dtgCeilingFloorList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgCeilingFloorList.Size = new System.Drawing.Size(575, 241);
            this.dtgCeilingFloorList.TabIndex = 0;
            this.dtgCeilingFloorList.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dtgRateList_RowsRemoved);
            // 
            // colCCYPair
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCCYPair.DefaultCellStyle = dataGridViewCellStyle2;
            this.colCCYPair.FillWeight = 127.1574F;
            this.colCCYPair.HeaderText = "CCY Pair";
            this.colCCYPair.Name = "colCCYPair";
            this.colCCYPair.ReadOnly = true;
            // 
            // colCeiling
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colCeiling.DefaultCellStyle = dataGridViewCellStyle3;
            this.colCeiling.HeaderText = "Ceiling";
            this.colCeiling.Name = "colCeiling";
            this.colCeiling.ReadOnly = true;
            // 
            // colFloor
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colFloor.DefaultCellStyle = dataGridViewCellStyle4;
            this.colFloor.FillWeight = 127.1574F;
            this.colFloor.HeaderText = "Floor";
            this.colFloor.Name = "colFloor";
            this.colFloor.ReadOnly = true;
            // 
            // colCeilingFloorID
            // 
            this.colCeilingFloorID.HeaderText = "Column1";
            this.colCeilingFloorID.Name = "colCeilingFloorID";
            this.colCeilingFloorID.Visible = false;
            // 
            // btnModify
            // 
            this.btnModify.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModify.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnModify.Location = new System.Drawing.Point(350, 259);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(75, 23);
            this.btnModify.TabIndex = 2;
            this.btnModify.Text = "&Modify";
            this.btnModify.UseVisualStyleBackColor = false;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // btCreate
            // 
            this.btCreate.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btCreate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btCreate.Location = new System.Drawing.Point(269, 259);
            this.btCreate.Name = "btCreate";
            this.btCreate.Size = new System.Drawing.Size(75, 23);
            this.btCreate.TabIndex = 1;
            this.btCreate.Text = "C&reate";
            this.btCreate.UseVisualStyleBackColor = false;
            this.btCreate.Click += new System.EventHandler(this.btCreate_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(512, 259);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDelete.Location = new System.Drawing.Point(431, 259);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 127.1574F;
            this.dataGridViewTextBoxColumn1.HeaderText = "CCY Pair";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 243;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 127.1574F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Floor";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 242;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 127.1574F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Floor";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 182;
            // 
            // frmMasListCeilingFloor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(599, 294);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnModify);
            this.Controls.Add(this.btCreate);
            this.Controls.Add(this.dtgCeilingFloorList);
            this.Name = "frmMasListCeilingFloor";
            this.Text = "SBV Ceiling Floor List";
            ((System.ComponentModel.ISupportInitialize)(this.dtgCeilingFloorList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

		private System.Windows.Forms.DataGridView dtgCeilingFloorList;
        private System.Windows.Forms.Button btnModify;
		private System.Windows.Forms.Button btCreate;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.DataGridViewTextBoxColumn colCCYPair;
		private System.Windows.Forms.DataGridViewTextBoxColumn colCeiling;
		private System.Windows.Forms.DataGridViewTextBoxColumn colFloor;
		private System.Windows.Forms.DataGridViewTextBoxColumn colCeilingFloorID;
    }
}