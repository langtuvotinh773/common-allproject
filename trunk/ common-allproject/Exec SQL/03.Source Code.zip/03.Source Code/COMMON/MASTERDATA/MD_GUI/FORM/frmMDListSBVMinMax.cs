﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage ceiling/floor
 * of Master data module.
 */
using System;
using System.Data;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using System.Collections.Generic;
using Phoenix.Common.MasterData.UserControl;
using Phoenix.Common.MasterData.Dto;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDListSBVMinMax : frmMDMaster
    {
        #region Pprivate Variables

        // For Security Checking
        private clsSEAuthorizer m_Security = null;

        private string m_colSBVMinMaxID = "colSBVMinMaxID";
        private string m_colCurrency = "colCurrency";
        private string m_colTenors = "colTenors";
        private string m_colTDMin = "colTDMin";
        private string m_colTDMax = "colTDMax";
        private string m_colLoanMin = "colLoanMin";
        private string m_colLoanMax = "colLoanMax";

        private DataTable m_dtCurrencyMaster;

        private string m_CCY = string.Empty;
        private int m_TransType = 0;

        private clsMDSBVMinMaxBUS m_SBVMinMaxBus;

        private List<clsMDSBVMinMaxDTO> m_SBVMinMaxList;

        #endregion
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDListSBVMinMax()
        {
            try
            {
                InitializeComponent();
                //draw header grid
                DrawHeaderGrid();

                SetFormStyleCommon();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);
                
                //fill data combobox CCY
                FillDataComboboxCCY();
                //fill data combobox Transaction Type
                FillDataComboboxTransactionType();

            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }


        #endregion


        #region Event

        /// <summary>
        /// Close form even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Create Ceiling/Floor even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btCreate_Click(object sender, EventArgs e)
        {
            try
            {
                //show form Inquiry Board Rate History
                frmMDAddModifySBVMinMax frm = new frmMDAddModifySBVMinMax();
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    btnSearch_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Call modify SBV Min Max screen event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgSBVMinMaxList.Rows.Count > 0)
                {
                    short ID = (short)dtgSBVMinMaxList.SelectedRows[0].Cells[m_colSBVMinMaxID].Value;
                    //show form Inquiry Board Rate History
                    frmMDAddModifySBVMinMax frm = new frmMDAddModifySBVMinMax(ID);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        btnSearch_Click(null, null);
                    }
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        clsMDMessage.WARNING_NO_DATA_TO_MODIFY);
                }
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Search Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                m_CCY = (string)cbbCCY.SelectedValue;
                m_TransType = (int)cbbTransactionType.SelectedValue;

                m_SBVMinMaxBus = new clsMDSBVMinMaxBUS();
                dtgSBVMinMaxList.Rows.Clear();
                //get SBV Min Max list
                m_SBVMinMaxList = m_SBVMinMaxBus.GetSBVMinMaxList(m_CCY, m_TransType);

                if (m_SBVMinMaxList.Count > 0)
                {
                    List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
                    DataGridViewRow row;
                    foreach (clsMDSBVMinMaxDTO dto in m_SBVMinMaxList)
                    {
                        row = new DataGridViewRow();
                        row.CreateCells(dtgSBVMinMaxList);

                        row.Cells[dtgSBVMinMaxList.Columns[m_colSBVMinMaxID].Index].Value = dto.SBVMinMaxID;
                        row.Cells[dtgSBVMinMaxList.Columns[m_colCurrency].Index].Value = dto.CCY;
                        row.Cells[dtgSBVMinMaxList.Columns[m_colTenors].Index].Value = dto.Tenor;
                        row.Cells[dtgSBVMinMaxList.Columns[m_colTDMin].Index].Value = dto.DepositMin;
                        row.Cells[dtgSBVMinMaxList.Columns[m_colTDMax].Index].Value = dto.DepositMax;
                        row.Cells[dtgSBVMinMaxList.Columns[m_colLoanMin].Index].Value = dto.TDMin;
                        row.Cells[dtgSBVMinMaxList.Columns[m_colLoanMax].Index].Value = dto.TDMax;
                        lstRows.Add(row);
                    }
                    dtgSBVMinMaxList.Rows.AddRange(lstRows.ToArray());
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                       clsMDMessage.NO_TRANSACTION_FOUND);
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        #endregion


        #region Functions

        /// <summary>
        /// Load data for Combobox Transaction Type
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co        
        /// @endcond
        private void FillDataComboboxTransactionType()
        {
            List<CbbObject> lst = new List<CbbObject>();
            lst.Add(new CbbObject(0, String.Empty));
            lst.Add(new CbbObject(clsMDConstant.SBV_MIN_MAX_TRANS_TYPE_DEPOSIT, clsMDConstant.SBV_MIN_MAX_DEPOSIT));
            lst.Add(new CbbObject(clsMDConstant.SBV_MIN_MAX_TRANS_TYPE_LOAN, clsMDConstant.SBV_MIN_MAX_LOAN));

            cbbTransactionType.DataSource = lst;
            cbbTransactionType.DisplayMember = clsMDConstant.DISPLAY;
            cbbTransactionType.ValueMember = clsMDConstant.VALUE;

        }

        /// <summary>
        /// Load data for Combobox Currency
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co        
        /// @endcond
        private void FillDataComboboxCCY()
        {
            //get Currency List
            m_dtCurrencyMaster = clsMDCurrencyMasterBUS.Instance().GetCurrencyList();

            if (m_dtCurrencyMaster == null) return;
            DataRow row = m_dtCurrencyMaster.NewRow();
            row[0] = String.Empty;

            m_dtCurrencyMaster.Rows.InsertAt(row, 0);
            cbbCCY.DataSource = m_dtCurrencyMaster;
            cbbCCY.ValueMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.DisplayMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.SelectedIndex = 0;

        }

        /// <summary>
        /// Load ceiling/floor list
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void DrawHeaderGrid()
        {
            DataGridViewTextBoxColumn colSBVID = new DataGridViewTextBoxColumn();
            colSBVID.HeaderText = "SBVMinMaxID";
            colSBVID.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            colSBVID.Width = 74;
            colSBVID.Name = m_colSBVMinMaxID;
            colSBVID.Visible = false;
            dtgSBVMinMaxList.Columns.Add(colSBVID);            

            DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
            col1.HeaderText = "Currency";
            col1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            col1.Width = 74;
            col1.Name = m_colCurrency;
            dtgSBVMinMaxList.Columns.Add(col1);

            DataGridViewTextBoxColumn col2 = new DataGridViewTextBoxColumn();
            col2.HeaderText = "Tenors";
            col2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            col2.Width = 74;
            col2.Name = m_colTenors;
            dtgSBVMinMaxList.Columns.Add(col2);

            DataGridViewTextBoxColumn col3 = new DataGridViewTextBoxColumn();
            col3.HeaderText = "TD" + clsMDConstant._ + "Min";
            col3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            col3.Width = 74;
            col3.Name = m_colTDMin;
            col3.DefaultCellStyle.Format = clsMDConstant.FORMAT_NUMBER_ON_DATAGRID;
            dtgSBVMinMaxList.Columns.Add(col3);

            DataGridViewTextBoxColumn col4 = new DataGridViewTextBoxColumn();
            col4.HeaderText = "TD" + clsMDConstant._ + "Max";
            col4.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            col4.Width = 74;
            col4.Name = m_colTDMax;
            col4.DefaultCellStyle.Format = clsMDConstant.FORMAT_NUMBER_ON_DATAGRID;
            dtgSBVMinMaxList.Columns.Add(col4);

            DataGridViewTextBoxColumn col5 = new DataGridViewTextBoxColumn();
            col5.HeaderText = "Loan" + clsMDConstant._ + "Min";
            col5.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            col5.Width = 74;
            col5.Name = m_colLoanMin;
            col5.DefaultCellStyle.Format = clsMDConstant.FORMAT_NUMBER_ON_DATAGRID;
            dtgSBVMinMaxList.Columns.Add(col5);

            DataGridViewTextBoxColumn col6 = new DataGridViewTextBoxColumn();
            col6.HeaderText = "Loan" + clsMDConstant._ + "Max";
            col6.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            col6.Width = 74;
            col6.Name = m_colLoanMax;
            col6.DefaultCellStyle.Format = clsMDConstant.FORMAT_NUMBER_ON_DATAGRID;
            dtgSBVMinMaxList.Columns.Add(col6);

            StackedHeaderDecorator objREnderer = new StackedHeaderDecorator(dtgSBVMinMaxList);

            dtgSBVMinMaxList.ReadOnly = true;
        }
        #endregion
    }
}