﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-16 (Thur, 16 May 2013) $
 * ========================================================
 * This class is used to view Special Customer List
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;
using MasterCommon = Phoenix.Common.MasterData.Com;
using MasterBus = Phoenix.Common.MasterData.Bus;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDListSpecialCustomer : frmMDMaster
    {
        #region Global Variable
        DataTable m_DataTable = null;
        DataView m_DataView = null;

        // For Security Checking
        clsSEAuthorizer m_Security = null;
        ExcelBase m_ExcelBase;
        /// worker object, working for background thread
        private CWorker m_worker;
        /// Project name
        private string m_ProjectName = clsMDConstant.PROJECT_NAME_MASTERDATA;
        //For List View   
        // Code Column
        private const string m_colCustCode = "colCustomerCode";
        // Full Name Column
        private const string m_colFullName = "colFullName";
        // Short Name Column
        private const string m_colShortName = "colShortName";
        // Customer Type Column
        private const string m_colCustType = "colCustomerType";
        // Special Column
        private const string m_colSpecial = "colSpecial";
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDListSpecialCustomer class.
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public frmMDListSpecialCustomer()
        {
            InitializeComponent();
            
            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);
            this.Text = clsMDConstant.CUSTOMER_SPECIAL_TITLE_LIST;
            m_DataView = new DataView();
        }

        /// <summary>
        /// Event form load
        /// Load data default: list special customer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void frmMDListSpecialCustomer_Load(object sender, EventArgs e)
        {
            try
            {
                //Set common style for form
                SetFormStyleCommon();
                //Load Customer Type combobox               
                FillComboboxData();
                //Get all list department
                GetCustomerList();
                // Enable control
                EnableControl(true);
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Define EventHandle after excute action save in frmMDModifySpecialCustomer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void frmUpdate_OnSaved(object sender, EventArgs e)
        {
            //Refresh data on grid
            GetCustomerList();
            //enable button control if they are disable
            EnableControl(true);
        }

        /// <summary>
        /// Event on click "Update"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgCustomer.SelectedRows.Count > 0)
                {
                    if (dtgCustomer.SelectedRows.Count > 1)
                    {
                        //if user choose more than one item on grid
                        //display message to require user choose one item on grid before click modify button
                        //'Please select a department to modify.'                           
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a customer", "update"));
                    }
                    else
                    {
                        //get selected row
                        DataGridViewRow rowSelected = dtgCustomer.CurrentRow;
                        //tranfer to Modify Department Screen
                        frmMDModifySpecialCustomer frmUpdate = new frmMDModifySpecialCustomer(clsMDConstant.CUSTOMER_SPECIAL_TITLE_UPDATE);
                        //define action after called save action on frmMDModifySpecialCustomer screen
                        frmUpdate.OnSaved += new EventHandler(frmUpdate_OnSaved);
                        //set updated object
                        frmUpdate.m_UpdatingCus.CustomerCode = rowSelected.Cells[m_colCustCode].Value.ToString();
                        frmUpdate.m_UpdatingCus = clsMDCustomerBUS.Instance().GetCustomer(frmUpdate.m_UpdatingCus.CustomerCode);
                        if (frmUpdate.m_UpdatingCus != null)
                        {
                            frmUpdate.SetData(frmUpdate.m_UpdatingCus);
                            frmUpdate.StartPosition = FormStartPosition.CenterScreen;                            
                            DialogResult result = frmUpdate.ShowDialog();
                            if (result == DialogResult.OK)
                                GetCustomerList();
                        }
                        else
                        {
                            //if system can not get information of selected object
                            //display error message
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.ERROR_NOT_FOUND_ITEM);
                        }
                    }
                }
                else
                {
                    //if user choose more than one item on grid
                    //display message to require user choose one item on grid before click modify button
                    //'Please select a department to modify.'                           
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a customer", "modify"));
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event on click "Close"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            // Close form
            this.Close();
        }

        /// <summary>
        /// Event on click "Search"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            clsMDCustomerDTO dto = new clsMDCustomerDTO();
            dto.CustomerCode = cbbCustomerCode.Text.ToString();
            dto.FullName = cbbCustomerName.Text.ToString();
            dto.CustomerType = cbbCustomerType.Items.Count > 0 ? cbbCustomerType.SelectedValue.ToString() : "";
            if (ckbSpecial.Checked)
                dto.Special = true;
            else
                dto.Special = false;
            try
            {
                //search list customer based on input params
                m_DataTable = clsMDCustomerBUS.Instance().GetCustomerList(dto, clsMDConstant.SPECIAL_CUSTOMER);
                //update data on grid
                UpdateGridView(m_DataTable);
                if (m_DataTable == null || (m_DataTable != null && m_DataTable.Rows.Count == 0))
                {
                    //display message 'No transaction found!'
                    clsMDMesageCollection.MessageNoTransactions();
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //enable all button control while system excute search function
            EnableControl(true);
        }

        /// <summary>
        ///Event on click "Export"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnExport_Click(object sender, EventArgs e)
        {
            if (dtgCustomer.Rows.Count > 0)
            {
                EnableControl(false);
                m_worker = new Config.Classes.CWorker(ExportToExcel, Complete);
                m_worker.Start();
            }
            else
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.NO_TRANSACTION_FOUND);
            }
        }

        /// <summary>
        ///Event Key press
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbCustomerName_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                clsCommonClass.AutoComplete(cbbCustomerName, e);
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        ///Event Key Press
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbCustomerCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                clsCommonClass.AutoComplete(cbbCustomerCode, e);
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        ///Event Key Down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbCustomerName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.PageDown)
            {
                ComboBox cbb = (ComboBox)sender;
                object cbbValue = cbb.SelectedValue;
                String _FN = cbb.Text.Substring(0, ((ComboBox)sender).Text.Trim().Length);
                DataTable _dt = clsMDCustomerBUS.Instance().GetListCustomerByName(_FN);
                frmMDSearchData frm = new frmMDSearchData(_dt);
                frm.StartPosition = FormStartPosition.CenterScreen;     
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    if (frm.selectedRow != null)
                    {
                        cbb.SelectedValue = frm.selectedRow.Cells[1].Value.ToString().Trim();
                    }
                }
                else
                {
                    if (cbbValue != null)
                    {
                        cbb.SelectedValue = cbbValue;
                    }
                }
                e.Handled = true;
                cbb.Focus();
                cbb.SelectAll();
            }
            else
                if (e.KeyCode == Keys.PageUp)
                {
                    ComboBox cbb = (ComboBox)sender;
                    object cbbValue = cbb.SelectedValue;
                    String _FN = cbb.Text.Substring(0, ((ComboBox)sender).Text.Trim().Length);
                    DataTable _dt = clsMDCustomerBUS.Instance().GetListCustomerByName(_FN);
                    frmMDSearchData frm = new frmMDSearchData(_dt);
                    frm.StartPosition = FormStartPosition.CenterScreen;   
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        if (frm.selectedRow != null)
                        {
                            cbb.SelectedValue = frm.selectedRow.Cells[1].Value.ToString().Trim();
                        }
                    }
                    else
                    {
                        if (cbbValue != null)
                        {
                            cbb.SelectedValue = cbbValue;
                        }
                    }
                    e.Handled = true;
                    cbb.Focus();
                    cbb.SelectAll();
                }
        }
        /// <summary>
        ///Event Key Down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbCustomerCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.PageDown)
            {
                ComboBox cbb = (ComboBox)sender;
                object cbbValue = cbb.SelectedValue;
                String _FN = cbb.Text.Substring(0, ((ComboBox)sender).Text.Trim().Length);
                DataTable _dt = clsMDCustomerBUS.Instance().GetListCustomerByCode(_FN);
                frmMDSearchData frm = new frmMDSearchData(_dt);
                frm.StartPosition = FormStartPosition.CenterScreen;   
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    if (frm.selectedRow != null)
                    {
                        cbb.SelectedValue = frm.selectedRow.Cells[0].Value.ToString().Trim();
                    }
                }
                else
                {
                    if (cbbValue != null)
                    {
                        cbb.SelectedValue = cbbValue;
                    }
                }
                e.Handled = true;
                cbb.Focus();
                cbb.SelectAll();
            }
            else
                if (e.KeyCode == Keys.PageUp)
                {
                    ComboBox cbb = (ComboBox)sender;
                    object cbbValue = cbb.SelectedValue;
                    String _FN = cbb.Text.Substring(0, ((ComboBox)sender).Text.Trim().Length);
                    DataTable _dt = clsMDCustomerBUS.Instance().GetListCustomerByName(_FN);
                    frmMDSearchData frm = new frmMDSearchData(_dt);
                    frm.StartPosition = FormStartPosition.CenterScreen;   
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        if (frm.selectedRow != null)
                        {
                            cbb.SelectedValue = frm.selectedRow.Cells[0].Value.ToString().Trim();
                        }
                    }
                    else
                    {
                        if (cbbValue != null)
                        {
                            cbb.SelectedValue = cbbValue;
                        }
                    }
                    e.Handled = true;
                    cbb.Focus();
                    cbb.SelectAll();
                }
        }
        #endregion

        #region Member method
        /// <summary>
        /// Get list all of customer
        /// </summary>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void GetCustomerList()
        {
            m_DataTable = clsMDCustomerBUS.Instance().GetCustomerList(new clsMDCustomerDTO(), clsMDConstant.SPECIAL_CUSTOMER);
            UpdateGridView(m_DataTable);
        }

        /// <summary>
        /// Update DataSource of Special Customer DataGridView
        /// </summary>
        /// <param name="list">list data customer dto</param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void UpdateGridView(DataTable customer)
        {
            DataGridViewRow row = new DataGridViewRow();
            List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
            int iCustType ;
            bool isSpecial;
            string strCustType;
            string strSpecial;
            // Clear datagrid
            dtgCustomer.Rows.Clear();
            // Set data for datadrid
            customer.TableName = "Special Customer";
            m_DataView.Table = customer;
            dtgCustomer.AutoGenerateColumns = false;

            // Get list customer type
            List<CbbObject> lstCustType = clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_CUSTOMER_TYPE);
            for (int i = 0; i < customer.Rows.Count; i++)
            {
                iCustType = 0;
                isSpecial = false;
                strCustType = "";
                strSpecial = "";
                row = new DataGridViewRow();
                row.CreateCells(dtgCustomer);
                row.Cells[dtgCustomer.Columns[m_colCustCode].Index].Value = customer.Rows[i]["Code"].ToString();
                row.Cells[dtgCustomer.Columns[m_colFullName].Index].Value = customer.Rows[i]["Name"].ToString();
                row.Cells[dtgCustomer.Columns[m_colShortName].Index].Value = customer.Rows[i]["ShortName"].ToString();
                strCustType = customer.Rows[i]["CustType"].ToString();
                strSpecial = customer.Rows[i]["Special"].ToString();
                if (!strCustType.Equals(""))
                {
                    iCustType = int.Parse(strCustType);
                    strCustType = lstCustType[iCustType].Display.ToString();
                }
                if (!strSpecial.Equals(""))
                {
                    isSpecial = bool.Parse(strSpecial);
                }
                row.Cells[dtgCustomer.Columns[m_colCustType].Index].Value = strCustType;
                row.Cells[dtgCustomer.Columns[m_colSpecial].Index].Value = isSpecial;
                lstRows.Add(row);
            }
            dtgCustomer.Rows.AddRange(lstRows.ToArray());
        }  

        /// <summary>
        /// Get data for report
        /// </summary>
        /// <param name="iRowCount"></param>
        /// <param name="iColCount"></param>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private object[,] FillDataForReport(DataGridView dgv, int iRowCount, int iColCount)
        {
            object[,] arrResult = new object[iRowCount+1, iColCount];
            int pos = 0;
            int i = 0;
            for (pos = 0; pos < iColCount; pos++)
            {
                arrResult[i, pos] = MasterCommon.clsMDConstant.HEADER_CUSTOMER_EXPORT[pos];
            }
            pos = 0;
            for (i = 0; i < dgv.Rows.Count; i++)
            {
                for (int j = 0; j < dgv.Columns.Count; j++)
                {
                    if (dgv.Rows[i].Cells[j].Visible == true)
                    {
                        arrResult[i+1, pos] = dgv.Rows[i].Cells[j].FormattedValue;
                        pos++;
                    }                    
                }
                pos = 0;
            }
            return arrResult;
        }

        /// <summary>
        /// Export to excel
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void ExportToExcel()
        {
            string strFileName = MasterCommon.clsMDConstant.EXCEL_TEMPLATE_NAME_CUSTOMER;
            string strTemplateName = MasterCommon.clsMDConstant.EXCEL_TEMPLATE_FILE_CUSTOMER;
            bool isOpened = false;
            m_ExcelBase = new ExcelBase(strFileName, strTemplateName, m_ProjectName, ref isOpened, MasterBus.clsMDBus.Instance().GetServerDate());
            if (isOpened)
            {
                return;
            }
            int iColStart = 1, iRowStart = 5, iRowEnd = iRowStart + dtgCustomer.Rows.Count - 1;
            int iColEnd = MasterCommon.clsMDConstant.HEADER_CUSTOMER_EXPORT.Length;
            object[,] m_arrData = FillDataForReport(dtgCustomer, dtgCustomer.Rows.Count, iColEnd);
            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);
        }

        /// <summary>
        /// Handling when completed a thread
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void Complete()
        {
            EnableControl(true);
            m_ExcelBase.SaveFile(true);
            if (m_worker != null)
                m_worker.Stop();
        }

        /// <summary>
        /// Fill combobox data
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void FillComboboxData()
        {
            //Load data for Customer Type combobox
            LoadCustomerType(cbbCustomerType);
            if (cbbCustomerType.Items.Count == 0)
                cbbCustomerType.DataSource = clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_CUSTOMER_TYPE);

            //Load data for Customer Code combobox
            //LoadCustomerName(cbbCustomerName);
            if (cbbCustomerName.Items.Count == 0)
                cbbCustomerName.DataSource = clsMDCustomerBUS.Instance().GetNameCustomerList();
            cbbCustomerName.DropDownStyle = ComboBoxStyle.DropDown;

            //Load data for Customer Code combobox
            LoadCustomerCode(cbbCustomerCode);
            if (cbbCustomerCode.Items.Count == 0)
                cbbCustomerCode.DataSource = clsMDCustomerBUS.Instance().GetCodeCustomerList();
            cbbCustomerCode.DropDownStyle = ComboBoxStyle.DropDown;
        }

        /// <summary>
        /// Enable or disable button action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void EnableControl(bool value)
        {
            btnSearch.Enabled = value;
            btnExport.Enabled = value;
            btnClose.Enabled = value;
            if (value)
            {
                if (dtgCustomer.Rows.Count == 0 || !ckbSpecial.Checked)
                {
                    btnExport.Enabled = false;
                }                
            }
        }

        #endregion
      
    }
        
}
