﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-20 (Wed, 20 March 2013) $
 * ========================================================
 * This class is used to create or modify a team object
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDTeamAddModify : frmMDMaster
    {
        #region Global Variable
        public clsMDTeamDTO m_UpdatingTeam;
        public event EventHandler OnSaved;
        public CommonValue.ActionType m_CurrentAction;
        bool m_ForceClose = false;
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDTeamAddModify class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDTeamAddModify(string title)
        {
            InitializeComponent();
            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);

            this.Text = title;
            this.m_UpdatingTeam = new clsMDTeamDTO();
            m_CurrentAction = CommonValue.ActionType.New;//default
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Form Load
        /// Set default settings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDTeamAddModify_Load(object sender, EventArgs e)
        {
            try
            {
                //Set common style for form
                SetFormStyleCommon();
                //Load data for combo box
                GetDataForComboBoxDepartment();
                GetDataForComboBoxTeamType();
                //disable txtTeamCode if current action is modify
                if (this.m_CurrentAction == CommonValue.ActionType.Update)
                {
                    if (m_UpdatingTeam != null)
                    {
                        //load data of updating team
                        SetData(m_UpdatingTeam);
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click button "Save"
        /// if current action is create, system will save a new team into DB
        /// if current action is modify, system will update information team into DB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            //disable all button while system excute save function.
            EnableButtonControl(false);
            try
            {
                if (this.m_CurrentAction == CommonValue.ActionType.New)
                {
                    //Save new team to db
                    if (SaveCreateAction() > 0)
                    {
                        this.m_ForceClose = true;
                        if (OnSaved != null)
                        {
                            OnSaved(sender, e);
                        }
                        this.Close();
                    }
                }
                else
                {
                    //update information of team to db
                    if (SaveModifyAction() > 0)
                    {
                        this.m_ForceClose = true;
                        if (OnSaved != null)
                        {
                            OnSaved(sender, e);
                        }
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button while system finish save function.
            EnableButtonControl(true);
        }

        /// <summary>
        /// Event click button "Cancel"
        /// If no data was changed on screen, system will close this screen
        /// If data was changed on screen, system will display a confirm message box: “Do you want to save changes of data?”
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //clsoe form
            this.Close();
        }

        /// <summary>
        /// Form close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMDTeamAddModify_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                try
                {
                    if (!m_ForceClose)
                    {
                        //if data was changed on screen, display confirm message to save changed data
                        if (IsDataChanged())
                        {
                            //display message 'Do you want to save changes of data?'
                            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                            if (res == DialogResult.Yes)
                            {
                                //check valid data
                                if (IsValidData())
                                {
                                    //save data and close form
                                    if (this.m_CurrentAction == CommonValue.ActionType.New)
                                    {
                                        //save new team
                                        if (SaveANewTeam() > 0)
                                        {
                                            this.m_ForceClose = true;
                                            if (OnSaved != null)
                                            {
                                                OnSaved(sender, e);
                                            }
                                            this.Close();
                                        }
                                        else//if save unsuccessfull, display error message and not close form
                                        {
                                            e.Cancel = true;
                                        }
                                    }
                                    else
                                    {
                                        //update information of team
                                        if (SaveAModifiedTeam() > 0)
                                        {
                                            this.m_ForceClose = true;
                                            if (OnSaved != null)
                                            {
                                                OnSaved(sender, e);
                                            }
                                            this.Close();
                                        }
                                        else//if save unsuccessfull, display error message and not close form
                                        {
                                            e.Cancel = true;
                                        }
                                    }
                                }
                                else
                                {
                                    e.Cancel = true;
                                }
                            }
                            else if (res == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.m_ForceClose = true;
                    //show error message
                    clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                    //save log exception
                    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
                }
            }
        }
        #endregion

        #region Member Methods
        /// <summary>
        /// Enable or disable button control
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnCancel.Enabled = value;
            btnSave.Enabled = value;
            //check security
            if (value)
            {
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
        }

        /// <summary>
        /// Get list of departments for cbbDepartment
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetDataForComboBoxDepartment()
        {
            DataTable depts = clsMDTeamBUS.Instance().GetDepartmentList();
            if (depts == null) return;

            //item null is value default
            depts.Rows.InsertAt(depts.NewRow(), 0);
            depts.AcceptChanges();

            cbbDepartment.DataSource = depts;
            cbbDepartment.ValueMember = clsMDConstant.MD_COL_DEPARTMENTID;
            cbbDepartment.DisplayMember = clsMDConstant.MD_COL_DEPARTMENTNAME;

            cbbDepartment.SelectedIndex = 0;
        }

        /// <summary>
        /// Get list of teamTypes for cbbTeamType
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetDataForComboBoxTeamType()
        {
            DataTable teamTypes = clsMDTeamBUS.Instance().GetTeamTypeList();
            if (teamTypes == null) return;

            //item null is value default
            teamTypes.Rows.InsertAt(teamTypes.NewRow(), 0);
            teamTypes.AcceptChanges();

            cbbTeamType.DataSource = teamTypes;
            cbbTeamType.ValueMember = clsMDConstant.MD_COL_TEAMTYPEID;
            cbbTeamType.DisplayMember = clsMDConstant.MD_COL_TEAMTYPENAME;

            cbbTeamType.SelectedIndex = 0;
        }

        /// <summary>
        /// load data to form
        /// </summary>
        /// <param name="obj">clsMDTeamDTO</param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public void SetData(clsMDTeamDTO obj)
        {            
            cbbDepartment.SelectedValue = obj.DepartmentID;
            cbbTeamType.SelectedValue = obj.TeamTypeID;
            txtTeamCode.Text = obj.TeamCode;
            txtTeamName.Text = obj.TeamName;
            txtRemark.Text = obj.Remark;
        }

        /// <summary>
        /// Save for action Create Team
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private int SaveCreateAction()
        {
            //check valid data
            if (IsValidData())
            {
                //display confirm message 'Are you sure to save team?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "team"));                
                if (res == DialogResult.Yes)
                {
                    return SaveANewTeam();
                }
                else if (res == DialogResult.No)
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
            }
            return 0;
        }

        /// <summary>
        /// Save a new User
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private int SaveANewTeam()
        {
            m_UpdatingTeam = GetTeamInfoFromControls();
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //Save new team and Write data to log
            int iRow = clsMDTeamBUS.Instance().InsertTeam(m_UpdatingTeam, logBase);
            // If Insert OK
            if (iRow > 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Creating", "team"));
            }
            else if (iRow == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Creating", "team"));
            }
            else
            {
                this.m_ForceClose = true;
                this.Close();
            }
            return iRow;
        }

        /// <summary>
        /// Get information of team from controls to create or modify
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private clsMDTeamDTO GetTeamInfoFromControls()
        {
            clsMDTeamDTO dto = new clsMDTeamDTO();
            if (this.m_CurrentAction == CommonValue.ActionType.Update)
            {
                dto.TeamID = m_UpdatingTeam.TeamID;
            }
            else
            {
                dto.DelFlag = false;
            }
            dto.DepartmentID = int.Parse(cbbDepartment.SelectedValue.ToString());
            dto.TeamTypeID = int.Parse(cbbTeamType.SelectedValue.ToString());
            dto.TeamCode = txtTeamCode.Text.Trim();
            dto.TeamName = txtTeamName.Text.Trim();
            dto.Remark = txtRemark.Text;
            dto.CreatedBy = clsUserInfo.UserNo;
            dto.UpdateDate = DateTime.Now;            
            return dto;
        }  

        /// <summary>
        /// Check validation data
        /// </summary>
        /// <returns>
        /// if any required field is invalid, system will display a warning message and return false
        /// else return true
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool IsValidData()
        {
            //check Department
            if (string.IsNullOrEmpty(cbbDepartment.Text))
            {                
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Department"));
                cbbDepartment.Focus();
                return false;
            }
            else
            {
                if (cbbDepartment.FindStringExact(cbbDepartment.Text.Trim()) < 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_COMBOBOX_SELECTED_NOT_FOUND, "Department"));
                    cbbDepartment.Focus();
                    return false;
                }
            }
            //check TeamType
            if (string.IsNullOrEmpty(cbbTeamType.Text))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Team Type"));
                cbbTeamType.Focus();
                return false;
            }
            else
            {
                if (cbbTeamType.FindStringExact(cbbTeamType.Text.Trim()) < 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_COMBOBOX_SELECTED_NOT_FOUND, "Team Type"));
                    cbbTeamType.Focus();
                    return false;
                }
            }
            //check TeamCode
            if (string.IsNullOrEmpty(txtTeamCode.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Team Code"));
                txtTeamCode.Focus();
                return false;
            }
            //check TeamName
            if (string.IsNullOrEmpty(txtTeamName.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Team Name"));
                txtTeamName.Focus();
                return false;
            }            
            int iNewTeam = (this.m_CurrentAction == CommonValue.ActionType.New) ? 0 : 1;
            int iTeamID = (this.m_CurrentAction == CommonValue.ActionType.New) ? -1 : m_UpdatingTeam.TeamID;
            Dictionary<string, int> checkDuplicate = clsMDTeamBUS.Instance().ValidationDuplicateTeam(iNewTeam, iTeamID, txtTeamCode.Text.Trim(), txtTeamName.Text.Trim());
            //check duplicate TeamCode
            if (checkDuplicate.ContainsKey(clsMDConstant.MD_COL_TEAMCODE))
            {
                int value = checkDuplicate[clsMDConstant.MD_COL_TEAMCODE];
                if (value > 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_ITEM_EXISTED, "Team Code"));
                    txtTeamCode.Focus();
                    return false;
                }
            }
            //Check duplicate TeamName
            //if (checkDuplicate.ContainsKey(clsMDConstant.MD_COL_TEAMNAME))
            //{
            //    int value = checkDuplicate[clsMDConstant.MD_COL_TEAMNAME];
            //    if (value > 0)
            //    {
            //        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_VALUE_IS_DUPLICATE, "Team Name"));
            //        txtTeamName.Focus();
            //        return false;
            //    }
            //}
            return true;
        }

        /// <summary>
        /// Save for action Modify Team
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private int SaveModifyAction()
        {
            //check valid data
            if (IsValidData())
            {
                //display confirm message 'Are you sure to save team?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "team"));                
                if (res == DialogResult.Yes)
                {
                    return SaveAModifiedTeam();
                }
                else if (res == DialogResult.No)
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
            }
            return 0;
        }

        /// <summary>
        /// Save a modified team
        /// </summary>
        /// <returns></returns>
        private int SaveAModifiedTeam()
        {
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //Save new team and Write data to log
            m_UpdatingTeam = GetTeamInfoFromControls();
            int row = clsMDTeamBUS.Instance().UpdateTeam(m_UpdatingTeam, logBase);
            // If Update OK
            if (row > 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Modifying", "team"));
            }
            else if (row == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Modifying", "team"));
            }
            else
            {
                this.m_ForceClose = true;
                this.Close();
            }
            return row;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        private bool IsDataChanged()
        {
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                if (string.IsNullOrEmpty(txtTeamCode.Text.Trim()) && string.IsNullOrEmpty(txtTeamName.Text.Trim())
                    && string.IsNullOrEmpty(txtRemark.Text.Trim()) && string.IsNullOrEmpty(cbbDepartment.Text.Trim()) 
                    && string.IsNullOrEmpty(cbbTeamType.Text.Trim()))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                if (this.m_UpdatingTeam.DepartmentID.CompareTo(int.Parse(cbbDepartment.SelectedValue.ToString())) != 0)
                {
                    return true;
                }
                if (this.m_UpdatingTeam.TeamTypeID.CompareTo(int.Parse(cbbTeamType.SelectedValue.ToString())) != 0)
                {
                    return true;
                }
                if (this.m_UpdatingTeam.TeamCode.CompareTo(txtTeamCode.Text.Trim()) != 0)
                {
                    return true;
                }
                if (this.m_UpdatingTeam.TeamName.CompareTo(txtTeamName.Text.Trim()) != 0)
                {
                    return true;
                }
                if (this.m_UpdatingTeam.Remark.CompareTo(txtRemark.Text.Trim()) != 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Create data team to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private clsMDLogBase CreateDataSaveLog()
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_SE;
            logBase.Key = txtTeamCode.Text.Trim();//main key is TeamCode
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logBase.Action = (int)CommonValue.ActionType.New;
            }
            else
            {
                logBase.Action = (int)CommonValue.ActionType.Update;
            }

            clsMDLogInformation logInfo = new clsMDLogInformation();

            //TeamCode
            logInfo.FieldName = clsMDConstant.MD_COL_TEAMCODE;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingTeam.TeamCode;
            }
            logInfo.NewValue = txtTeamCode.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //TeamName
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_TEAMNAME;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingTeam.TeamName;
            }
            logInfo.NewValue = txtTeamName.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //DepartmentCode
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_DEPARTMENTCODE;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingTeam.DepartmentCode + " " + this.m_UpdatingTeam.DepartmentID;
            }
            DataTable depts = clsMDTeamBUS.Instance().GetDepartmentList();
            DataRow[] drDept = depts.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_DEPARTMENTID, cbbDepartment.SelectedValue.ToString()));
            logInfo.NewValue = drDept[0][clsMDConstant.MD_COL_DEPARTMENTCODE].ToString() + " " + cbbDepartment.SelectedValue.ToString();
            logBase.LstLogInformation.Add(logInfo);
            //TeamTypeCode
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_TEAMTYPECODE;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingTeam.TeamTypeCode + " " + this.m_UpdatingTeam.TeamTypeID;
            }
            DataTable teamTypes = clsMDTeamBUS.Instance().GetTeamTypeList();
            DataRow[] drTeamType = teamTypes.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_TEAMTYPEID, cbbTeamType.SelectedValue.ToString()));
            logInfo.NewValue = drTeamType[0][clsMDConstant.MD_COL_TEAMTYPECODE].ToString() + " " + cbbTeamType.SelectedValue.ToString();
            logBase.LstLogInformation.Add(logInfo);
            //Remark
            if (!string.IsNullOrEmpty(txtRemark.Text.Trim()))
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = clsMDConstant.MD_COL_REMARK;
                if (this.m_CurrentAction == CommonValue.ActionType.New)
                {
                    logInfo.OldValue = string.Empty;
                }
                else
                {
                    logInfo.OldValue = this.m_UpdatingTeam.Remark;
                }
                logInfo.NewValue = txtRemark.Text.Trim();
                logBase.LstLogInformation.Add(logInfo);
            }
            return logBase;
        }
        #endregion
    }
}
