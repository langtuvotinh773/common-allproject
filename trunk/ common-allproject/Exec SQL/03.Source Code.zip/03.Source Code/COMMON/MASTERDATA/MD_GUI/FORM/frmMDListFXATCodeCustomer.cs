﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-20 (Mon, 20 May 2013) $
 * ========================================================
 * This class is used to view FXAT Customer List
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDListFXATCodeCustomer : frmMDMaster
    {
        #region Global Variable
        DataTable m_DataTable = null;
        DataView m_DataView = null;

        // For Security Checking
        clsSEAuthorizer m_Security = null;
        /// Project name
        private string m_ProjectName = clsMDConstant.PROJECT_NAME_MASTERDATA;

        private int MAX_LENGTH_FXATCODE = 4;
        private int MAX_LENGTH_LOCATION = 3;

        //For List View   
        // Code Column
        private const string m_colCustCode = "colCustomerCode";
        // Full Name Column
        private const string m_colFullName = "colFullName";
        // Short Name Column
        private const string m_colShortName = "colShortName";
        // Customer Type Column
        private const string m_colCustType = "colCustomerType";
        // FXATCode Column
        private const string m_colFXATCode = "colFXATCode";
        // Location Column
        private const string m_colLocationCode = "colLocation";

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDFListFXATCodeCustomer class.
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public frmMDListFXATCodeCustomer()
        {
            InitializeComponent();
            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);

            this.Text = clsMDConstant.CUSTOMER_FXATCODE_TITLE_LIST;
            m_DataView = new DataView();
        }

        /// <summary>
        /// Event form load
        /// Load data default: list FXAT Code customer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void frmMDFListFXATCodeCustomer_Load(object sender, EventArgs e)
        {
            try
            {
                //Set common style for form
                SetFormStyleCommon();
                //Load Customer Type combobox               
                FillComboboxData();
                //Get all list department
                GetCustomerList();
                //Set limit text for control
                cbbFXATCode.MaxLength = MAX_LENGTH_FXATCODE;
                cbbLocation.MaxLength = MAX_LENGTH_LOCATION;
                //Enable control
                EnableControl(true);
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Event functions
        /// <summary>
        /// Event on click "Search"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            clsMDCustomerDTO dto = new clsMDCustomerDTO();
            dto.CustomerCode = cbbCustomerCode.Text.ToString();
            dto.FullName = cbbCustomerName.Text.ToString();
            dto.CustomerType = cbbCustomerType.Items.Count > 0 ? cbbCustomerType.SelectedValue.ToString() : "";
            dto.FXATCode = cbbFXATCode.Text.ToString();
            dto.Location = cbbLocation.Text.ToString();
            try
            {
                //search list customer based on input params
                m_DataTable = clsMDCustomerBUS.Instance().GetCustomerList(dto, clsMDConstant.FXAT_CODE_CUSTOMER);
                //update data on grid
                UpdateGridView(m_DataTable);
                if (m_DataTable == null || (m_DataTable != null && m_DataTable.Rows.Count == 0))
                {
                    //display message 'No transaction found!'
                    clsMDMesageCollection.MessageNoTransactions();
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //enable all button control while system excute search function
            EnableControl(true);
        }

        /// <summary>
        ///Event Key Press
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbCustomerName_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                clsCommonClass.AutoComplete(cbbCustomerName, e);
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        ///Event Key Press
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbCustomerCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                clsCommonClass.AutoComplete(cbbCustomerCode, e);
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }
        
        /// <summary>
        ///Event Key Down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbCustomerName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.PageDown)
            {
                ComboBox cbb = (ComboBox)sender;
                object cbbValue = cbb.SelectedValue;
                String _FN = cbb.Text.Substring(0, ((ComboBox)sender).Text.Trim().Length);
                DataTable _dt = clsMDCustomerBUS.Instance().GetListCustomerByName(_FN);
                frmMDSearchData frm = new frmMDSearchData(_dt);
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    if (frm.selectedRow != null)
                    {
                        cbb.SelectedValue = frm.selectedRow.Cells[1].Value.ToString().Trim();
                    }
                }
                else
                {
                    if (cbbValue != null)
                    {
                        cbb.SelectedValue = cbbValue;
                    }
                }
                e.Handled = true;
                cbb.Focus();
                cbb.SelectAll();
            }
            else
                if (e.KeyCode == Keys.PageUp)
                {
                    ComboBox cbb = (ComboBox)sender;
                    object cbbValue = cbb.SelectedValue;
                    String _FN = cbb.Text.Substring(0, ((ComboBox)sender).Text.Trim().Length);
                    DataTable _dt = clsMDCustomerBUS.Instance().GetListCustomerByName(_FN);
                    frmMDSearchData frm = new frmMDSearchData(_dt);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        if (frm.selectedRow != null)
                        {
                            cbb.SelectedValue = frm.selectedRow.Cells[1].Value.ToString().Trim();
                        }
                    }
                    else
                    {
                        if (cbbValue != null)
                        {
                            cbb.SelectedValue = cbbValue;
                        }
                    }
                    e.Handled = true;
                    cbb.Focus();
                    cbb.SelectAll();
                }
        }

        /// <summary>
        ///Event Key Down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbCustomerCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.PageDown)
            {
                ComboBox cbb = (ComboBox)sender;
                object cbbValue = cbb.SelectedValue;
                String _FN = cbb.Text.Substring(0, ((ComboBox)sender).Text.Trim().Length);
                DataTable _dt = clsMDCustomerBUS.Instance().GetListCustomerByCode(_FN);
                frmMDSearchData frm = new frmMDSearchData(_dt);
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    if (frm.selectedRow != null)
                    {
                        cbb.SelectedValue = frm.selectedRow.Cells[0].Value.ToString().Trim();
                    }
                }
                else
                {
                    if (cbbValue != null)
                    {
                        cbb.SelectedValue = cbbValue;
                    }
                }
                e.Handled = true;
                cbb.Focus();
                cbb.SelectAll();
            }
            else
                if (e.KeyCode == Keys.PageUp)
                {
                    ComboBox cbb = (ComboBox)sender;
                    object cbbValue = cbb.SelectedValue;
                    String _FN = cbb.Text.Substring(0, ((ComboBox)sender).Text.Trim().Length);
                    DataTable _dt = clsMDCustomerBUS.Instance().GetListCustomerByName(_FN);
                    frmMDSearchData frm = new frmMDSearchData(_dt);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        if (frm.selectedRow != null)
                        {
                            cbb.SelectedValue = frm.selectedRow.Cells[0].Value.ToString().Trim();
                        }
                    }
                    else
                    {
                        if (cbbValue != null)
                        {
                            cbb.SelectedValue = cbbValue;
                        }
                    }
                    e.Handled = true;
                    cbb.Focus();
                    cbb.SelectAll();
                }
        }

        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }

        /// <summary>
        /// Event on click "Update"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgCustomer.SelectedRows.Count > 0)
                {
                    if (dtgCustomer.SelectedRows.Count > 1)
                    {
                        //if user choose more than one item on grid
                        //display message to require user choose one item on grid before click modify button
                        //'Please select a department to modify.'                           
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a customer", "update"));
                    }
                    else
                    {
                        //get selected row
                        DataGridViewRow rowSelected = dtgCustomer.CurrentRow;
                        //tranfer to Modify Department Screen
                        frmMDModifyFXATCodeCustomer frmUpdate = new frmMDModifyFXATCodeCustomer(clsMDConstant.CUSTOMER_FXATCODE_TITLE_UPDATE);
                        //define action after called save action on frmMDModifySpecialCustomer screen
                        frmUpdate.OnSaved += new EventHandler(frmUpdate_OnSaved);
                        //set updated object
                        frmUpdate.m_UpdatingCus.CustomerCode = rowSelected.Cells[m_colCustCode].Value.ToString();
                        frmUpdate.m_UpdatingCus = clsMDCustomerBUS.Instance().GetCustomer(frmUpdate.m_UpdatingCus.CustomerCode);
                        if (frmUpdate.m_UpdatingCus != null)
                        {
                            frmUpdate.SetData(frmUpdate.m_UpdatingCus);
                            frmUpdate.StartPosition = FormStartPosition.CenterScreen;
                            DialogResult result = frmUpdate.ShowDialog();
                        }
                        else
                        {
                            //if system can not get information of selected object
                            //display error message
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.ERROR_NOT_FOUND_ITEM);
                        }
                    }
                }
                else
                {
                    //if user choose more than one item on grid
                    //display message to require user choose one item on grid before click modify button
                    //'Please select a department to modify.'                           
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a customer", "modify"));
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event KeyPress
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbFXATCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                clsCommonClass.AutoComplete(cbbFXATCode, e);
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Event KeyPress
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void cbbLocation_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                clsCommonClass.AutoComplete(cbbLocation, e);
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }
        #endregion

        #region Member method
        /// <summary>
        /// Fill combobox data
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void FillComboboxData()
        {
            //Load data for Customer Type combobox
            LoadCustomerType(cbbCustomerType);
            if (cbbCustomerType.Items.Count == 0)
                cbbCustomerType.DataSource = clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_CUSTOMER_TYPE);

            //Load data for Customer Code combobox
            //LoadCustomerName(cbbCustomerName);
            if (cbbCustomerName.Items.Count == 0)
                cbbCustomerName.DataSource = clsMDCustomerBUS.Instance().GetNameCustomerList();
            cbbCustomerName.DropDownStyle = ComboBoxStyle.DropDown;

            //Load data for Customer Code combobox
            LoadCustomerCode(cbbCustomerCode);
            if (cbbCustomerCode.Items.Count == 0)
                cbbCustomerCode.DataSource = clsMDCustomerBUS.Instance().GetCodeCustomerList();
            cbbCustomerCode.DropDownStyle = ComboBoxStyle.DropDown;

            //Load data for FXAT Code combobox
            LoadFXATCode(cbbFXATCode);
            if (cbbFXATCode.Items.Count == 0)
                cbbFXATCode.DataSource = clsMDCustomerBUS.Instance().GetFXATCodeList();
            cbbFXATCode.DropDownStyle = ComboBoxStyle.DropDown;

            //Load data for FXAT Code combobox
            LoadLocationCode(cbbLocation);
            if (cbbLocation.Items.Count == 0)
                cbbLocation.DataSource = clsMDCustomerBUS.Instance().GetLocationCodeList();
            cbbLocation.DropDownStyle = ComboBoxStyle.DropDown;
        }

        /// <summary>
        /// Get list all of customer
        /// </summary>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void GetCustomerList()
        {
            m_DataTable = clsMDCustomerBUS.Instance().GetCustomerList(new clsMDCustomerDTO(), clsMDConstant.FXAT_CODE_CUSTOMER);
            UpdateGridView(m_DataTable);
        }

        /// <summary>
        /// Update DataSource of Special Customer DataGridView
        /// </summary>
        /// <param name="list">list data customer dto</param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void UpdateGridView(DataTable customer)
        {
            DataGridViewRow row = new DataGridViewRow();
            List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
            int iCustType;
            string strCustType;
            // Clear datagrid
            dtgCustomer.Rows.Clear();

            // Set data for datadrid
            customer.TableName = "FXAT Code Customer";
            m_DataView.Table = customer;
            dtgCustomer.AutoGenerateColumns = false;

            // Get list customer type
            List<CbbObject> lstCustType = clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_CUSTOMER_TYPE);

            for (int i = 0; i < customer.Rows.Count; i++)
            {
                iCustType = 0;
                strCustType = "";
                row = new DataGridViewRow();
                row.CreateCells(dtgCustomer);
                row.Cells[dtgCustomer.Columns[m_colCustCode].Index].Value = customer.Rows[i]["Code"].ToString();
                row.Cells[dtgCustomer.Columns[m_colFullName].Index].Value = customer.Rows[i]["Name"].ToString();
                row.Cells[dtgCustomer.Columns[m_colShortName].Index].Value = customer.Rows[i]["ShortName"].ToString();
                row.Cells[dtgCustomer.Columns[m_colFXATCode].Index].Value = customer.Rows[i]["FXATCode"].ToString();
                row.Cells[dtgCustomer.Columns[m_colLocationCode].Index].Value = customer.Rows[i]["LocationCode"].ToString();
                strCustType = customer.Rows[i]["CustType"].ToString();
                if (!strCustType.Equals(""))
                {
                    iCustType = int.Parse(strCustType);
                    strCustType = lstCustType[iCustType].Display.ToString();
                }
                row.Cells[dtgCustomer.Columns[m_colCustType].Index].Value = strCustType;
                lstRows.Add(row);
            }
            dtgCustomer.Rows.AddRange(lstRows.ToArray());
        }

        /// <summary>
        /// Enable or disable button action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void EnableControl(bool value)
        {
            btnSearch.Enabled = value;
            btnClose.Enabled = value;
        }

        /// <summary>
        /// Define EventHandle after excute action save in frmMDModifyFXATCodeCustomer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pqkhai        
        /// @endcond
        private void frmUpdate_OnSaved(object sender, EventArgs e)
        {
            //Refresh data on grid
            GetCustomerList();
            //Refresh data on combobox
            FillComboboxData();
            //enable button control if they are disable
            EnableControl(true);
        }
        #endregion  

      

        
    }
}
