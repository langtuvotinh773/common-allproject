﻿namespace Phoenix.Common.MasterData.Gui.Report
{
    
    
    public partial class Quotation {
    }
}
