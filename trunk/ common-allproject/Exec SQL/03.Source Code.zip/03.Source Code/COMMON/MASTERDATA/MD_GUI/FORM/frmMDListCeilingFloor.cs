﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage ceiling/floor
 * of Master data module.
 */
using System;
using System.Data;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using System.Collections.Generic;

namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMasListCeilingFloor : frmMDMaster
	{
        // For Security Checking
        clsSEAuthorizer m_Security = null;
		/// <summary>
		/// CCY Pair column
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		const string COL_CCY_PAIR = "colCCYPair";
		/// <summary>
		/// Ceiling Column
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		const string COL_CEILING = "colCeiling";
		/// <summary>
		/// Floor column
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		const string COL_FLOOR = "colFloor";
		/// <summary>
		/// Ceiling/Floor ID Column
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		const string COL_CEILING_FLOOR_ID = "colCeilingFloorID";
		/// <summary>
		/// clsMDCeilingFloorBus Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		clsMDCeilingFloorBUS m_CeilingFloorBUS = new clsMDCeilingFloorBUS();

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmMasListCeilingFloor()
		{
			InitializeComponent();
            
            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);
            
            try
            {
                Init();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}

		/// <summary>
		/// Init value of controls on this form
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void Init()
		{
			SetFormStyleCommon();

			btnModify.Enabled = false;
			LoadCeilingFloorList();
		}		

		/// <summary>
		/// Search Ceiling/Floor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void Search()
		{
			SetStateForButton();
		}

		/// <summary>
		/// Check if user check item item on datagrid
		/// </summary>
		/// <returns>True if user check at lease 1 item, false otherwise</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool HaveItemChecked()
		{
			for (int i = 0; i < dtgCeilingFloorList.Rows.Count; i++)
				if (dtgCeilingFloorList.Rows[i].Cells[0].Value.ToString() == true.ToString())
					return true;
			return false;
		}

		/// <summary>
		/// Writelog
		/// </summary>
		/// <param name="iUserAction">User action</param>
		/// <param name="strKeyDelete">Key to delete</param>
		/// <param name="strForeignKeyDelete">Foreign key to delete</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void WriteLog(int iUserAction, string strKeyDelete, string strForeignKeyDelete)
		{

			//History Header
			clsMDLogBase logBase = new clsMDLogBase();
			logBase.ApplicationName = this.Text;
			logBase.UserID = clsUserInfo.UserNo.ToString();
			logBase.Module = clsMDConstant.MODULE_MD;

			switch (iUserAction)
			{
				case (int) CommonValue.ActionType.Delete:
					logBase.Action = (int) CommonValue.ActionType.Delete;
					logBase.Key = strKeyDelete + " " + strForeignKeyDelete;
					logBase.WirteLog(m_CeilingFloorBUS.DAL);
					m_CeilingFloorBUS.Commit();

					break;
			}
		}
		
		/// <summary>
		/// Set state for button
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void SetStateForButton()
		{
			if (dtgCeilingFloorList.Rows.Count <= 0)
				btnModify.Enabled = false;
			else btnModify.Enabled = true;
		}
		
		/// <summary>
		/// Load ceiling/floor list
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void LoadCeilingFloorList()
		{
            dtgCeilingFloorList.Rows.Clear();
            DataTable dtbCeilingFloor = m_CeilingFloorBUS.GetCeilingFloorList();
            List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
            DataGridViewRow row = new DataGridViewRow();
            //Suppend Layout
            dtgCeilingFloorList.SuspendLayout();
            for (int i = 0; i < dtbCeilingFloor.Rows.Count; i++)
            {
                row = new DataGridViewRow();
                row.CreateCells(dtgCeilingFloorList);
                row.Cells[dtgCeilingFloorList.Columns[COL_CCY_PAIR].Index].Value = dtbCeilingFloor.Rows[i]["ExchangeCCYPair"];
                row.Cells[dtgCeilingFloorList.Columns[COL_CEILING].Index].Value = decimal.Parse(dtbCeilingFloor.Rows[i]["Ceiling"].ToString());
                row.Cells[dtgCeilingFloorList.Columns[COL_FLOOR].Index].Value = decimal.Parse(dtbCeilingFloor.Rows[i]["Floor"].ToString());
                row.Cells[dtgCeilingFloorList.Columns[COL_CEILING_FLOOR_ID].Index].Value = dtbCeilingFloor.Rows[i]["CeilingFloorID"];

                row.Cells[dtgCeilingFloorList.Columns[COL_CEILING].Index].Style.Format = GetFormatDecimal(decimal.Parse(dtbCeilingFloor.Rows[i]["Ceiling"].ToString()));
                row.Cells[dtgCeilingFloorList.Columns[COL_FLOOR].Index].Style.Format = GetFormatDecimal(decimal.Parse(dtbCeilingFloor.Rows[i]["Floor"].ToString()));

                lstRows.Add(row);
            }
            //Resume Layout
            dtgCeilingFloorList.Rows.AddRange(lstRows.ToArray());
            dtgCeilingFloorList.ResumeLayout();

            if (dtgCeilingFloorList.Rows.Count > 0)
            {
                dtgCeilingFloorList.Rows[0].Selected = true;
                SetACtion(true);
            }
            else
                SetACtion(false);
		}

		/// <summary>
		/// Set action
		/// </summary>
		/// <param name="isAllowedTodo">boolean value to show that user has right to do this or not</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void SetACtion(bool isAllowedTodo)
		{
			btnModify.Enabled = isAllowedTodo;
			btnDelete.Enabled = isAllowedTodo;
		}

		/// <summary>
		/// Close form even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	
		/// <summary>
		/// Create Ceiling/Floor even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btCreate_Click(object sender, EventArgs e)
		{
            try
            {
                frmMDAddModifyCeilingFloor frm = new frmMDAddModifyCeilingFloor();
                frm.StartPosition = FormStartPosition.CenterScreen;
                DialogResult result = frm.ShowDialog();
                if (result == DialogResult.OK)
                    LoadCeilingFloorList();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}
		
		/// <summary>
		/// Call modify ceiling/floor screen even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnModify_Click(object sender, EventArgs e)
		{
			try
			{
				if (dtgCeilingFloorList.SelectedRows.Count <= 0)
					clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "ceiling/floor", "modify"));
				else
				{
					string strCCY = dtgCeilingFloorList.SelectedRows[0].Cells[0].Value.ToString();
					string strCeiling = dtgCeilingFloorList.SelectedRows[0].Cells[1].Value.ToString();
					string strFllor = dtgCeilingFloorList.SelectedRows[0].Cells[2].Value.ToString();
					frmMDAddModifyCeilingFloor frm = new frmMDAddModifyCeilingFloor(int.Parse(dtgCeilingFloorList.SelectedRows[0].Cells[COL_CEILING_FLOOR_ID].Value.ToString()), strCCY, strCeiling, strFllor);
					frm.StartPosition = FormStartPosition.CenterScreen;
					DialogResult result = frm.ShowDialog();
					if (result == DialogResult.OK)
						LoadCeilingFloorList();
				}
			}
			catch (Exception ex)
			{
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
		}
		
		/// <summary>
		/// Delete ceiling/floor even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnDelete_Click(object sender, EventArgs e)
		{
			try
			{
				if (dtgCeilingFloorList.SelectedRows.Count <= 0)
					clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM_FOR_ACTION, "ceiling/floor", "delete"));
				else
				{

					int iCeilingFloorID = -1;
					string strExchangeCCYPairID = "";
					if (dtgCeilingFloorList.SelectedRows.Count > 0)
					{
						iCeilingFloorID = int.Parse(dtgCeilingFloorList.SelectedRows[0].Cells[COL_CEILING_FLOOR_ID].Value.ToString());
						strExchangeCCYPairID = dtgCeilingFloorList.SelectedRows[0].Cells[COL_CCY_PAIR].Value.ToString();
					}
					if (clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_DELETE_CEILING_FLOOR) == DialogResult.Yes)
						if (m_CeilingFloorBUS.DeleteCeilingFloor(iCeilingFloorID) > 0)
						{
                            WriteLog((int)CommonValue.ActionType.Delete, iCeilingFloorID.ToString(), strExchangeCCYPairID);
							clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, DELETING, CEILING_FLOOR));							
							LoadCeilingFloorList();
						}
						else
						{
							clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, DELETING, CEILING_FLOOR));
							if (m_CeilingFloorBUS.DAL.m_transaction != null)
								m_CeilingFloorBUS.RollBack();
						}
				}
			}
			catch (Exception ex)
			{
                m_CeilingFloorBUS.RollBack();
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
				clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
			}
		}
		
		/// <summary>
		/// Search even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnSearch_Click(object sender, EventArgs e)
		{
            try
            {
                Search();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
		}
		
		/// <summary>
		/// Rows removed even of datagrid
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void dtgRateList_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			SetStateForButton();
		}
	}
}