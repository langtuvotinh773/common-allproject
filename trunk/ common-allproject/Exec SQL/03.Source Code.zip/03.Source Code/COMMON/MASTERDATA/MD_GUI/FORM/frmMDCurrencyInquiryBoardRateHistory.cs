﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using UserCtrl.DatagridStackHolder.Master;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.Functions;
using Config.Classes;
using Phoenix.Common.MasterData.Dto;
using System.Data;
using Phoenix.Common.Security.Com;
using System.Drawing;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDCurrencyInquiryBoardRateHistory : frmMDMaster
    {
        private List<int> lstCCYPair;
        private int iChecked = 0;
        #region Private Variables

        // For Security Checking
        clsSEAuthorizer m_Security = null;

        private clsMDBoardRaterBUS m_BoardRateBus;
        private List<clsMDBoardRateDetailDTO> m_BoardRateDetailList;
        //Input search condition
        private string m_CCYList;
        private DateTime? m_FromDate = null;
        private DateTime? m_ToDate = null;
        private bool? m_IsActive = null;
        private int? m_TermID = null;

        private string m_colCheck = "colCheck";
        private string m_colCCYCode = "colCCYCode";
        private string m_CCYCode = "CCYCode";

        private string m_Term = "Term";
        private string m_CCYTermsID = "CCYTermsID";

        private string m_colBoardRateDetailID = "colBoardRateDetailID";
        private string m_colDate = "colDate";
        private string m_colTime = "colTime";
        private string m_colInActive = "colInActive";
        private string m_colCCY = "colCCY";
        private string m_colTerm = "colTerm";
        private string m_colDeposit1 = "colDeposit1";
        private string m_colDeposit2 = "colDeposit2";
        private string m_colDeposit3 = "colDeposit3";
        private string m_colDeposit4 = "colDeposit4";
        private string m_colDeposit5 = "colDeposit5";
        private string m_colDeposit6 = "colDeposit6";
        private string m_colDeposit7 = "colDeposit7";
        private string m_colDeposit8 = "colDeposit8";
        private string m_colDeposit9 = "colDeposit9";

        private string m_colLoan1 = "colLoan1";
        private string m_colLoan2 = "colLoan2";
        private string m_colLoan3 = "colLoan3";
        private string m_colLoan4 = "colLoan4";
        private string m_colLoan5 = "colLoan5";
        private string m_colLoan6 = "colLoan6";
        private string m_colLoan7 = "colLoan7";
        private string m_colLoan8 = "colLoan8";
        private string m_colLoan9 = "colLoan9";
        private clsExcelBase m_ExcelBase = null;

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDCurrencyInquiryBoardRateHistory()
        {
            try
            {
                InitializeComponent();
                SetFormStyleCommon();

                //Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                //Draw Grid Board Rate header
                DrawGridBoardRate();
                //fill exchange CCY
                FillExchangeCCY();
                //fill term list to combobox term
                FillDataComboboxTermStatus();
                //fill active to combobox Inactive
                FillDataComboboxIsActive();
                DateTime serverDate = clsMDBus.Instance().GetServerDateTime();
                dtpFrom.Value = serverDate;
                dtpTo.Value = serverDate;
                lstCCYPair = new List<int>();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion


        #region Event Methods

        /// <summary>
        /// Search event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                GetDataForSearch();
                m_BoardRateBus = new clsMDBoardRaterBUS();
                dtgDetail.Rows.Clear();
                //get Inquiry Board rate history list
                m_BoardRateDetailList = m_BoardRateBus.GetCurrencyInquiryBoardRateHistoryList(m_FromDate, m_ToDate, m_TermID, m_IsActive, m_CCYList);
                FillDataToDataGridView();
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Export event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgDetail.Rows.Count > 0)
                {
                    m_ExcelBase = new clsExcelBase(clsMDConstant.EXCEL_TEMPLATE_FILE_CURRENCY_INQUIRY_BOARD_RATE_HISTORY, clsMDConstant.PROJECT_NAME_MASTERDATA, clsMDBus.Instance().GetServerDate());
                    int iRowStart = 7;
                    int iColCount = 23;
                    string cellStart = "A7";
                    string cellEnd = "W" + (iRowStart - 1 + dtgDetail.Rows.Count);
                    m_ExcelBase.InsertCellObject(2, 1, clsMDConstant.EXCEL_TEMPLATE_TITLE_CURRENCY_INQUIRY_BOARD_RATE_HISTORY);
                    object[,] data = FillDataForReport(dtgDetail.Rows.Count, iColCount, iRowStart);
                    m_ExcelBase.ExportRange(cellStart, cellEnd, data);
                    m_ExcelBase.SaveFile();
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.INFO_NO_DATA_EXPORT);
                }
            }
            catch (System.Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Close event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void dtgCCYPair_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {


            try
            {
                if (e.ColumnIndex == 0)
                {
                    //get list records is checked on grid Repayment
                    if (Boolean.Parse(dtgCCYPair.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString()) == true)
                    {
                        if (!lstCCYPair.Contains(e.RowIndex))
                        {
                            lstCCYPair.Add(e.RowIndex);
                        }
                    }
                    else
                    {
                        if (lstCCYPair.Contains(e.RowIndex))
                        {
                            lstCCYPair.Remove(e.RowIndex);
                        }
                    }
                    //check "Checkbox All Repayment" when check all checkboxes of all records 
                    chkAll.CheckedChanged -= new EventHandler(chkAll_CheckedChanged);
                    if (lstCCYPair.Count == dtgCCYPair.Rows.Count)
                    {
                        chkAll.Checked = true;
                    }
                    else
                    {
                        chkAll.Checked = false;
                    }
                    chkAll.CheckedChanged += new EventHandler(chkAll_CheckedChanged);
                }
            }
            catch
            {

            }

        }



        private void dtgCCYPair_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //set value of check column repayment
                if (e.ColumnIndex == 0 || e.ColumnIndex == dtgCCYPair.Columns.Count - 1)
                {
                    if (e.RowIndex >= 0)
                        dtgCCYPair[0, e.RowIndex].Value = (!bool.Parse(dtgCCYPair[0, e.RowIndex].Value.ToString())).ToString();
                }
                else
                {
                    dtgCCYPair.ReadOnly = true;
                }

            }
            catch
            {

            }
        }

        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox check = (CheckBox)sender;
            //set check true all check box on grid repayment
            //if checkall = true: all check box on grid is true
            //if checkall = false: all check box on grid is false
            if (check.Checked)
            {
                clsCommonFunctions.SetAllCheck(dtgCCYPair, true);
            }
            else
            {
                clsCommonFunctions.SetAllCheck(dtgCCYPair, false);
            }


        }
        #endregion

        #region Member Methods
        /// <summary>
        /// Load data for Combobox Status
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillDataComboboxTermStatus()
        {
            DataTable dtCCYTerm = clsMDCCYTermsBUS.Instance().GetCCYTermsList();
            dtCCYTerm.Rows.InsertAt(dtCCYTerm.NewRow(), 0);
            cbbTerm.DataSource = dtCCYTerm;
            cbbTerm.DisplayMember = m_Term;
            cbbTerm.ValueMember = m_CCYTermsID;
            cbbTerm.SelectedIndex = 0;
        }

        /// <summary>
        /// Load data for Combobox Currency
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co        
        /// @endcond
        private void FillExchangeCCY()
        {
            DataTable dtCurrencyMaster = clsMDCurrencyMasterBUS.Instance().GetCurrencyList();
            if (dtCurrencyMaster.Rows.Count > 0)
            {
                List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
                DataGridViewRow row;
                for (int i = 0; i < dtCurrencyMaster.Rows.Count; i++)
                {
                    row = new DataGridViewRow();
                    row.CreateCells(dtgCCYPair);
                    row.Cells[dtgCCYPair.Columns[m_colCheck].Index].Value = false;
                    row.Cells[dtgCCYPair.Columns[m_colCCYCode].Index].Value = dtCurrencyMaster.Rows[i][m_CCYCode];
                    lstRows.Add(row);
                }
                dtgCCYPair.Rows.AddRange(lstRows.ToArray());
            }
        }

        /// <summary>
        /// Load data for Combobox IsActive
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillDataComboboxIsActive()
        {
            List<CbbObject> lst = new List<CbbObject>();
            lst.Add(new CbbObject(new Nullable<bool>(), string.Empty));
            lst.Add(new CbbObject(true, clsMDConstant.BOARD_RATE_ACTIVE));
            lst.Add(new CbbObject(false, clsMDConstant.BOARD_RATE_IN_ACTIVE));

            cbbIsActive.DataSource = lst;
            cbbIsActive.DisplayMember = clsMDConstant.DISPLAY;
            cbbIsActive.ValueMember = clsMDConstant.VALUE;
            cbbIsActive.SelectedIndex = 0;
        }

        /// <summary>
        /// Draw Board Rate datagridview
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void DrawGridBoardRate()
        {
            DataGridViewTextBoxColumn colBoardRateDetailID = new DataGridViewTextBoxColumn();
            colBoardRateDetailID.HeaderText = "BoardRateDetailID";
            colBoardRateDetailID.Visible = false;
            colBoardRateDetailID.Name = m_colBoardRateDetailID;
            dtgDetail.Columns.Add(colBoardRateDetailID);
            dtgDetail.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            DataGridViewTextBoxColumn colDate = new DataGridViewTextBoxColumn();
            colDate.HeaderText = "Date";
            colDate.Width = 85;
            colDate.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            colDate.Name = m_colDate;
            colDate.DefaultCellStyle.Format = "HH:mm";
            dtgDetail.Columns.Add(colDate);
            dtgDetail.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            DataGridViewTextBoxColumn colTime = new DataGridViewTextBoxColumn();
            colTime.HeaderText = "Time";
            colTime.Width = 40;
            colTime.Name = m_colTime;
            colTime.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            dtgDetail.Columns.Add(colTime);
            dtgDetail.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            DataGridViewCheckBoxColumn colInActive = new DataGridViewCheckBoxColumn();
            colInActive.HeaderText = "InActive";
            colInActive.Width = 50;
            colInActive.Name = m_colInActive;
            dtgDetail.Columns.Add(colInActive);
            dtgDetail.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            DataGridViewTextBoxColumn colCCY = new DataGridViewTextBoxColumn();
            colCCY.HeaderText = "Currency";
            colCCY.Width = 50;
            colCCY.Name = m_colCCY;
            dtgDetail.Columns.Add(colCCY);
            dtgDetail.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            DataGridViewTextBoxColumn colTerm = new DataGridViewTextBoxColumn();
            colTerm.HeaderText = "Terms";
            colTerm.Width = 40;
            colTerm.Name = m_colTerm;
            dtgDetail.Columns.Add(colTerm);
            dtgDetail.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            DataGridViewTextBoxColumn colDeposit1 = new DataGridViewTextBoxColumn();
            colDeposit1.HeaderText = "DEPOSIT" + clsMDConstant._ + "SAME DAY" + clsMDConstant._ + "Value Date";
            colDeposit1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colDeposit1.Width = 74;
            colDeposit1.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colDeposit1.Name = m_colDeposit1;
            dtgDetail.Columns.Add(colDeposit1);

            DataGridViewTextBoxColumn colDeposit2 = new DataGridViewTextBoxColumn();
            colDeposit2.HeaderText = "DEPOSIT" + clsMDConstant._ + "SAME DAY" + clsMDConstant._ + "Maturity Date";
            colDeposit2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colDeposit2.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colDeposit2.Width = 74;
            colDeposit2.Name = m_colDeposit2;
            dtgDetail.Columns.Add(colDeposit2);

            DataGridViewTextBoxColumn colDeposit3 = new DataGridViewTextBoxColumn();
            colDeposit3.HeaderText = "DEPOSIT" + clsMDConstant._ + "SAME DAY" + clsMDConstant._ + "Value";
            colDeposit3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            colDeposit3.Width = 74;
            colDeposit3.Name = m_colDeposit3;
            dtgDetail.Columns.Add(colDeposit3);

            DataGridViewTextBoxColumn colDeposit4 = new DataGridViewTextBoxColumn();
            colDeposit4.HeaderText = "DEPOSIT" + clsMDConstant._ + "TOM" + clsMDConstant._ + "Value Date";
            colDeposit4.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colDeposit4.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colDeposit4.Width = 74;
            colDeposit4.Name = m_colDeposit4;
            dtgDetail.Columns.Add(colDeposit4);

            DataGridViewTextBoxColumn colDeposit5 = new DataGridViewTextBoxColumn();
            colDeposit5.HeaderText = "DEPOSIT" + clsMDConstant._ + "TOM" + clsMDConstant._ + "Maturity Date";
            colDeposit5.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colDeposit5.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colDeposit5.Width = 74;
            colDeposit5.Name = m_colDeposit5;
            dtgDetail.Columns.Add(colDeposit5);

            DataGridViewTextBoxColumn colDeposit6 = new DataGridViewTextBoxColumn();
            colDeposit6.HeaderText = "DEPOSIT" + clsMDConstant._ + "TOM" + clsMDConstant._ + "Value";
            colDeposit6.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            colDeposit6.Width = 74;
            colDeposit6.Name = m_colDeposit6;
            dtgDetail.Columns.Add(colDeposit6);

            DataGridViewTextBoxColumn colDeposit7 = new DataGridViewTextBoxColumn();
            colDeposit7.HeaderText = "DEPOSIT" + clsMDConstant._ + "SPOT" + clsMDConstant._ + "Value Date";
            colDeposit7.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colDeposit7.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colDeposit7.Width = 74;
            colDeposit7.Name = m_colDeposit7;
            dtgDetail.Columns.Add(colDeposit7);

            DataGridViewTextBoxColumn colDeposit8 = new DataGridViewTextBoxColumn();
            colDeposit8.HeaderText = "DEPOSIT" + clsMDConstant._ + "SPOT" + clsMDConstant._ + "Maturity Date";
            colDeposit8.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colDeposit8.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colDeposit8.Width = 74;
            colDeposit8.Name = m_colDeposit8;
            dtgDetail.Columns.Add(colDeposit8);

            DataGridViewTextBoxColumn colDeposit9 = new DataGridViewTextBoxColumn();
            colDeposit9.HeaderText = "DEPOSIT" + clsMDConstant._ + "SPOT" + clsMDConstant._ + "Value";
            colDeposit9.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            colDeposit9.Width = 74;
            colDeposit9.Name = m_colDeposit9;
            dtgDetail.Columns.Add(colDeposit9);

            DataGridViewTextBoxColumn colLoan1 = new DataGridViewTextBoxColumn();
            colLoan1.HeaderText = "LOAN" + clsMDConstant._ + "SAME DAY" + clsMDConstant._ + "Value Date";
            colLoan1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colLoan1.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colLoan1.Width = 74;
            colLoan1.Name = m_colLoan1;
            dtgDetail.Columns.Add(colLoan1);

            DataGridViewTextBoxColumn colLoan2 = new DataGridViewTextBoxColumn();
            colLoan2.HeaderText = "LOAN" + clsMDConstant._ + "SAME DAY" + clsMDConstant._ + "Maturity Date";
            colLoan2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colLoan2.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colLoan2.Width = 74;
            colLoan2.Name = m_colLoan2;
            dtgDetail.Columns.Add(colLoan2);

            DataGridViewTextBoxColumn colLoan3 = new DataGridViewTextBoxColumn();
            colLoan3.HeaderText = "LOAN" + clsMDConstant._ + "SAME DAY" + clsMDConstant._ + "Value";
            colLoan3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            colLoan3.Width = 74;
            colLoan3.Name = m_colLoan3;
            dtgDetail.Columns.Add(colLoan3);

            DataGridViewTextBoxColumn colLoan4 = new DataGridViewTextBoxColumn();
            colLoan4.HeaderText = "LOAN" + clsMDConstant._ + "TOM" + clsMDConstant._ + "Value Date";
            colLoan4.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colLoan4.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colLoan4.Width = 74;
            colLoan4.Name = m_colLoan4;
            dtgDetail.Columns.Add(colLoan4);

            DataGridViewTextBoxColumn colLoan5 = new DataGridViewTextBoxColumn();
            colLoan5.HeaderText = "LOAN" + clsMDConstant._ + "TOM" + clsMDConstant._ + "Maturity Date";
            colLoan5.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colLoan5.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colLoan5.Width = 74;
            colLoan5.Name = m_colLoan5;
            dtgDetail.Columns.Add(colLoan5);

            DataGridViewTextBoxColumn colLoan6 = new DataGridViewTextBoxColumn();
            colLoan6.HeaderText = "LOAN" + clsMDConstant._ + "TOM" + clsMDConstant._ + "Value";
            colLoan6.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            colLoan6.Width = 74;
            colLoan6.Name = m_colLoan6;
            dtgDetail.Columns.Add(colLoan6);

            DataGridViewTextBoxColumn colLoan7 = new DataGridViewTextBoxColumn();
            colLoan7.HeaderText = "LOAN" + clsMDConstant._ + "SPOT" + clsMDConstant._ + "Value Date";
            colLoan7.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colLoan7.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colLoan7.Width = 74;
            colLoan7.Name = m_colLoan7;
            dtgDetail.Columns.Add(colLoan7);

            DataGridViewTextBoxColumn colLoan8 = new DataGridViewTextBoxColumn();
            colLoan8.HeaderText = "LOAN" + clsMDConstant._ + "SPOT" + clsMDConstant._ + "Maturity Date";
            colLoan8.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colLoan8.DefaultCellStyle.Format = clsMDConstant.DATETIME_FORMAT_DDMMMYYYY;
            colLoan8.Width = 74;
            colLoan8.Name = m_colLoan8;
            dtgDetail.Columns.Add(colLoan8);

            DataGridViewTextBoxColumn colLoan9 = new DataGridViewTextBoxColumn();
            colLoan9.HeaderText = "LOAN" + clsMDConstant._ + "SPOT" + clsMDConstant._ + "Value";
            colLoan9.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            colLoan9.Width = 74;
            colLoan9.Name = m_colLoan9;
            dtgDetail.Columns.Add(colLoan9);

            StackedHeaderDecorator objREnderer = new StackedHeaderDecorator(dtgDetail);

        }

        /// <summary>
        /// Fill Data to Grid View
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillDataToDataGridView()
        {
            if (m_BoardRateDetailList.Count > 0)
            {
                List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
                DataGridViewRow row;
                int countTerm = 10;
                int iBR = 0;
                for (int i = 0; i < m_BoardRateDetailList.Count / 2; i++)
                {
                    iBR = i + countTerm * (i / countTerm);
                    row = new DataGridViewRow();
                    row.CreateCells(dtgDetail);
                    row.Cells[dtgDetail.Columns[m_colBoardRateDetailID].Index].Value = m_BoardRateDetailList[iBR].BoardRateDetailID;
                    row.Cells[dtgDetail.Columns[m_colDate].Index].Value = m_BoardRateDetailList[iBR].ImportTime == null ? string.Empty
                        : m_BoardRateDetailList[iBR].ImportTime.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY); ;
                    row.Cells[dtgDetail.Columns[m_colTime].Index].Value = m_BoardRateDetailList[iBR].ImportTime == null ? string.Empty
                        : m_BoardRateDetailList[iBR].ImportTime.Value.ToString(clsMDConstant.MD_FORMAT_HHMM);
                    row.Cells[dtgDetail.Columns[m_colInActive].Index].Value = !m_BoardRateDetailList[iBR].IsActive;
                    row.Cells[dtgDetail.Columns[m_colCCY].Index].Value = m_BoardRateDetailList[iBR].CCY;
                    row.Cells[dtgDetail.Columns[m_colTerm].Index].Value = m_BoardRateDetailList[iBR].Term;

                    row.Cells[dtgDetail.Columns[m_colDeposit1].Index].Value = m_BoardRateDetailList[iBR].SameDayValueDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].SameDayValueDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colDeposit2].Index].Value = m_BoardRateDetailList[iBR].SameDayMaturityDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].SameDayMaturityDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colDeposit3].Index].Value = m_BoardRateDetailList[iBR].SameDay;

                    row.Cells[dtgDetail.Columns[m_colDeposit4].Index].Value = m_BoardRateDetailList[iBR].TomValueDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].TomValueDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colDeposit5].Index].Value = m_BoardRateDetailList[iBR].TomMaturityDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].TomMaturityDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colDeposit6].Index].Value = m_BoardRateDetailList[iBR].Tom;

                    row.Cells[dtgDetail.Columns[m_colDeposit7].Index].Value = m_BoardRateDetailList[iBR].SpotValueDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].SpotValueDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colDeposit8].Index].Value = m_BoardRateDetailList[iBR].SpotMaturityDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].SpotMaturityDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colDeposit9].Index].Value = m_BoardRateDetailList[iBR].Spot;
                    iBR = iBR + countTerm;

                    row.Cells[dtgDetail.Columns[m_colLoan1].Index].Value = m_BoardRateDetailList[iBR].SameDayValueDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].SameDayValueDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colLoan2].Index].Value = m_BoardRateDetailList[iBR].SameDayMaturityDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].SameDayMaturityDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colLoan3].Index].Value = m_BoardRateDetailList[iBR].SameDay;

                    row.Cells[dtgDetail.Columns[m_colLoan4].Index].Value = m_BoardRateDetailList[iBR].TomValueDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].TomValueDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colLoan5].Index].Value = m_BoardRateDetailList[iBR].TomMaturityDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].TomMaturityDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colLoan6].Index].Value = m_BoardRateDetailList[iBR].Tom;

                    row.Cells[dtgDetail.Columns[m_colLoan7].Index].Value = m_BoardRateDetailList[iBR].SpotValueDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].SpotValueDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colLoan8].Index].Value = m_BoardRateDetailList[iBR].SpotMaturityDate == null ? string.Empty
                        : m_BoardRateDetailList[iBR].SpotMaturityDate.Value.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    row.Cells[dtgDetail.Columns[m_colLoan9].Index].Value = m_BoardRateDetailList[iBR].Spot;

                    lstRows.Add(row);
                }
                dtgDetail.Rows.AddRange(lstRows.ToArray());
            }
        }

        /// <summary>
        /// Fill Data grid to excel Board Rate
        /// </summary>
        /// <param name="iRowCount"></param>
        /// <param name="iColCount"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private object[,] FillDataForReport(int iRowCount, int iColCount, int iRowStart)
        {
            object[,] data = new object[iRowCount, iColCount];

            for (int i = 0; i < dtgDetail.Rows.Count; i++)
            {
                int iCol = 0;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDate].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colTime].Value;
                if ((bool)dtgDetail.Rows[i].Cells[m_colInActive].Value)
                {
                    //if InActive = true => insert picture to excel report Board Rate
                    m_ExcelBase.InsertPicture(i + iRowStart, 3, AppDomain.CurrentDomain.BaseDirectory + clsMDConstant.MODULE_LG + "_GUI\\ICON\\CHECK.PNG", 14, 14);
                }
                data[i, iCol++] = null;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colCCY].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colTerm].Value;

                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDeposit1].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDeposit2].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDeposit3].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDeposit4].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDeposit5].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDeposit6].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDeposit7].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDeposit8].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colDeposit9].Value;

                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colLoan1].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colLoan2].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colLoan3].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colLoan4].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colLoan5].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colLoan6].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colLoan7].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colLoan8].Value;
                data[i, iCol++] = dtgDetail.Rows[i].Cells[m_colLoan9].Value;
            }
            return data;
        }

        /// <summary>
        /// Get Data for Search event
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataForSearch()
        {
            List<string> CCYList = new List<string>();
            if (dtgCCYPair.Rows.Count > 0)
            {
                for (int i = 0; i < dtgCCYPair.Rows.Count; i++)
                {
                    if ((bool)dtgCCYPair.Rows[i].Cells[m_colCheck].Value)
                    {
                        CCYList.Add(dtgCCYPair.Rows[i].Cells[m_colCCYCode].Value.ToString());
                    }

                }
                if (CCYList.Count > 0)
                {
                    m_CCYList = "'" + String.Join("','", CCYList.ToArray()) + "'";
                }
                else
                {
                    m_CCYList = string.Empty;
                }
            }

            if (String.IsNullOrEmpty(dtpFrom.Text))
            {
                m_FromDate = new Nullable<DateTime>();
            }
            else
            {
                m_FromDate = dtpFrom.Value;
            }
            if (String.IsNullOrEmpty(dtpTo.Text))
            {
                m_ToDate = new Nullable<DateTime>();
            }
            else
            {
                m_ToDate = dtpTo.Value;
            }
            m_TermID = cbbTerm.SelectedValue.GetType() == typeof(DBNull) ? new Nullable<int>() : (int)cbbTerm.SelectedValue;
            m_IsActive = (bool?)cbbIsActive.SelectedValue;
        }



        
        public void SetAllCheck(DataGridView dtgv, bool bValue)
        {
            if (dtgv.Rows.Count > 0)
            {
                for (int i = 0; i < dtgv.Rows.Count; i++)
                {
                    dtgv[0, i].Value = bValue.ToString();
                }
            }
        }
        #endregion








    }
}
