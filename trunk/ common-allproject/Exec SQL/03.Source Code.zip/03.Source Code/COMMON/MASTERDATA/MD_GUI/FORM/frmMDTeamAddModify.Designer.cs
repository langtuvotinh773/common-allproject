﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDTeamAddModify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDepartmentCode = new System.Windows.Forms.Label();
            this.lblTeamCode = new System.Windows.Forms.Label();
            this.lblTeamName = new System.Windows.Forms.Label();
            this.cbbDepartment = new System.Windows.Forms.ComboBox();
            this.txtTeamCode = new System.Windows.Forms.TextBox();
            this.txtTeamName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblTeamTypeCode = new System.Windows.Forms.Label();
            this.cbbTeamType = new System.Windows.Forms.ComboBox();
            this.txtRemark = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // lblDepartmentCode
            // 
            this.lblDepartmentCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDepartmentCode.AutoSize = true;
            this.lblDepartmentCode.Location = new System.Drawing.Point(23, 33);
            this.lblDepartmentCode.Name = "lblDepartmentCode";
            this.lblDepartmentCode.Size = new System.Drawing.Size(62, 13);
            this.lblDepartmentCode.TabIndex = 0;
            this.lblDepartmentCode.Text = "Department";
            // 
            // lblTeamCode
            // 
            this.lblTeamCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTeamCode.AutoSize = true;
            this.lblTeamCode.Location = new System.Drawing.Point(23, 54);
            this.lblTeamCode.Name = "lblTeamCode";
            this.lblTeamCode.Size = new System.Drawing.Size(62, 13);
            this.lblTeamCode.TabIndex = 4;
            this.lblTeamCode.Text = "Team Code";
            // 
            // lblTeamName
            // 
            this.lblTeamName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTeamName.AutoSize = true;
            this.lblTeamName.Location = new System.Drawing.Point(274, 54);
            this.lblTeamName.Name = "lblTeamName";
            this.lblTeamName.Size = new System.Drawing.Size(65, 13);
            this.lblTeamName.TabIndex = 6;
            this.lblTeamName.Text = "Team Name";
            // 
            // cbbDepartment
            // 
            this.cbbDepartment.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbbDepartment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbbDepartment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbbDepartment.FormattingEnabled = true;
            this.cbbDepartment.Items.AddRange(new object[] {
            "TLAD"});
            this.cbbDepartment.Location = new System.Drawing.Point(103, 26);
            this.cbbDepartment.Name = "cbbDepartment";
            this.cbbDepartment.Size = new System.Drawing.Size(150, 21);
            this.cbbDepartment.TabIndex = 1;
            // 
            // txtTeamCode
            // 
            this.txtTeamCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTeamCode.Location = new System.Drawing.Point(103, 48);
            this.txtTeamCode.Margin = new System.Windows.Forms.Padding(5);
            this.txtTeamCode.MaxLength = 20;
            this.txtTeamCode.Name = "txtTeamCode";
            this.txtTeamCode.Size = new System.Drawing.Size(150, 20);
            this.txtTeamCode.TabIndex = 5;
            // 
            // txtTeamName
            // 
            this.txtTeamName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTeamName.Location = new System.Drawing.Point(358, 48);
            this.txtTeamName.MaxLength = 50;
            this.txtTeamName.Name = "txtTeamName";
            this.txtTeamName.Size = new System.Drawing.Size(150, 20);
            this.txtTeamName.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Remark";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(344, 198);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.Location = new System.Drawing.Point(433, 198);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblTeamTypeCode
            // 
            this.lblTeamTypeCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTeamTypeCode.AutoSize = true;
            this.lblTeamTypeCode.Location = new System.Drawing.Point(274, 33);
            this.lblTeamTypeCode.Name = "lblTeamTypeCode";
            this.lblTeamTypeCode.Size = new System.Drawing.Size(61, 13);
            this.lblTeamTypeCode.TabIndex = 2;
            this.lblTeamTypeCode.Text = "Team Type";
            // 
            // cbbTeamType
            // 
            this.cbbTeamType.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbbTeamType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbbTeamType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbbTeamType.FormattingEnabled = true;
            this.cbbTeamType.Items.AddRange(new object[] {
            "TT-01"});
            this.cbbTeamType.Location = new System.Drawing.Point(358, 26);
            this.cbbTeamType.Name = "cbbTeamType";
            this.cbbTeamType.Size = new System.Drawing.Size(150, 21);
            this.cbbTeamType.TabIndex = 3;
            // 
            // txtRemark
            // 
            this.txtRemark.Location = new System.Drawing.Point(103, 72);
            this.txtRemark.MaxLength = 100;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(405, 101);
            this.txtRemark.TabIndex = 9;
            this.txtRemark.Text = "";
            // 
            // frmMDTeamAddModify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(543, 251);
            this.Controls.Add(this.txtRemark);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtTeamName);
            this.Controls.Add(this.cbbTeamType);
            this.Controls.Add(this.txtTeamCode);
            this.Controls.Add(this.cbbDepartment);
            this.Controls.Add(this.lblTeamName);
            this.Controls.Add(this.lblTeamTypeCode);
            this.Controls.Add(this.lblTeamCode);
            this.Controls.Add(this.lblDepartmentCode);
            this.Name = "frmMDTeamAddModify";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Create Team";
            this.Load += new System.EventHandler(this.frmMDTeamAddModify_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDTeamAddModify_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDepartmentCode;
        private System.Windows.Forms.Label lblTeamCode;
        private System.Windows.Forms.Label lblTeamName;
        private System.Windows.Forms.ComboBox cbbDepartment;
        private System.Windows.Forms.TextBox txtTeamCode;
        private System.Windows.Forms.TextBox txtTeamName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblTeamTypeCode;
        private System.Windows.Forms.ComboBox cbbTeamType;
        private System.Windows.Forms.RichTextBox txtRemark;
    }
}