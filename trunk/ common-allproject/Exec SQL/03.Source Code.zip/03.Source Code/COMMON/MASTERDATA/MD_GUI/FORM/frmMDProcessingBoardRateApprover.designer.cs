﻿namespace Phoenix.Common.MasterData.Gui
{
	partial class frmMDProcessingBoardRateApprover
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMDProcessingBoardRateApprover));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dtgBoardRateList = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbApprove = new System.Windows.Forms.ToolStripButton();
            this.tsbReturn = new System.Windows.Forms.ToolStripButton();
            this.tsbRevise = new System.Windows.Forms.ToolStripButton();
            this.tsbFreeze = new System.Windows.Forms.ToolStripButton();
            this.tsbPrintPreview = new System.Windows.Forms.ToolStripButton();
            this.tsbExport = new System.Windows.Forms.ToolStripButton();
            this.colBoardRateID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colInactive = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaker = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colApprover = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatusID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgBoardRateList)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtgBoardRateList
            // 
            this.dtgBoardRateList.AllowUserToAddRows = false;
            this.dtgBoardRateList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgBoardRateList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgBoardRateList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgBoardRateList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colBoardRateID,
            this.colStatus,
            this.colInactive,
            this.colDate,
            this.colTime,
            this.colMaker,
            this.colApprover,
            this.colStatusID});
            this.dtgBoardRateList.Location = new System.Drawing.Point(12, 40);
            this.dtgBoardRateList.Name = "dtgBoardRateList";
            this.dtgBoardRateList.ReadOnly = true;
            this.dtgBoardRateList.RowHeadersVisible = false;
            this.dtgBoardRateList.Size = new System.Drawing.Size(764, 287);
            this.dtgBoardRateList.TabIndex = 1;
            this.dtgBoardRateList.DoubleClick += new System.EventHandler(this.dtgBoardRateList_DoubleClick);
            this.dtgBoardRateList.SelectionChanged += new System.EventHandler(this.dtgDailyQuotationList_SelectionChanged);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(620, 338);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "&Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(701, 338);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbApprove,
            this.tsbReturn,
            this.tsbRevise,
            this.tsbFreeze,
            this.tsbPrintPreview,
            this.tsbExport});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(788, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbApprove
            // 
            this.tsbApprove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbApprove.Image = ((System.Drawing.Image)(resources.GetObject("tsbApprove.Image")));
            this.tsbApprove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbApprove.Name = "tsbApprove";
            this.tsbApprove.Size = new System.Drawing.Size(23, 22);
            this.tsbApprove.Text = "Approve";
            this.tsbApprove.ToolTipText = "Approve";
            this.tsbApprove.Click += new System.EventHandler(this.tsbApprove_Click);
            // 
            // tsbReturn
            // 
            this.tsbReturn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbReturn.Image = ((System.Drawing.Image)(resources.GetObject("tsbReturn.Image")));
            this.tsbReturn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbReturn.Name = "tsbReturn";
            this.tsbReturn.Size = new System.Drawing.Size(23, 22);
            this.tsbReturn.Text = "Return";
            this.tsbReturn.ToolTipText = "Return";
            this.tsbReturn.Click += new System.EventHandler(this.tsbReturn_Click);
            // 
            // tsbRevise
            // 
            this.tsbRevise.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRevise.Image = ((System.Drawing.Image)(resources.GetObject("tsbRevise.Image")));
            this.tsbRevise.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRevise.Name = "tsbRevise";
            this.tsbRevise.Size = new System.Drawing.Size(23, 22);
            this.tsbRevise.Text = "Revise";
            this.tsbRevise.ToolTipText = "Revise";
            this.tsbRevise.Click += new System.EventHandler(this.tsbRevise_Click);
            // 
            // tsbFreeze
            // 
            this.tsbFreeze.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbFreeze.Image = ((System.Drawing.Image)(resources.GetObject("tsbFreeze.Image")));
            this.tsbFreeze.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFreeze.Name = "tsbFreeze";
            this.tsbFreeze.Size = new System.Drawing.Size(23, 22);
            this.tsbFreeze.Text = "Freeze";
            this.tsbFreeze.ToolTipText = "Freeze";
            this.tsbFreeze.Click += new System.EventHandler(this.tsbFreeze_Click);
            // 
            // tsbPrintPreview
            // 
            this.tsbPrintPreview.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPrintPreview.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrintPreview.Image")));
            this.tsbPrintPreview.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrintPreview.Name = "tsbPrintPreview";
            this.tsbPrintPreview.Size = new System.Drawing.Size(23, 22);
            this.tsbPrintPreview.Text = "Preview";
            this.tsbPrintPreview.ToolTipText = "Preview";
            this.tsbPrintPreview.Click += new System.EventHandler(this.tsbPrintPreview_Click);
            // 
            // tsbExport
            // 
            this.tsbExport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbExport.Image = ((System.Drawing.Image)(resources.GetObject("tsbExport.Image")));
            this.tsbExport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExport.Name = "tsbExport";
            this.tsbExport.Size = new System.Drawing.Size(23, 22);
            this.tsbExport.Text = "Export";
            this.tsbExport.ToolTipText = "Export";
            this.tsbExport.Click += new System.EventHandler(this.tsbExport_Click);
            // 
            // colBoardRateID
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colBoardRateID.DefaultCellStyle = dataGridViewCellStyle1;
            this.colBoardRateID.FillWeight = 81.21828F;
            this.colBoardRateID.HeaderText = "BoardRateID";
            this.colBoardRateID.Name = "colBoardRateID";
            this.colBoardRateID.ReadOnly = true;
            this.colBoardRateID.Visible = false;
            // 
            // colStatus
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colStatus.DefaultCellStyle = dataGridViewCellStyle2;
            this.colStatus.FillWeight = 104.6954F;
            this.colStatus.HeaderText = "Status";
            this.colStatus.MinimumWidth = 150;
            this.colStatus.Name = "colStatus";
            this.colStatus.ReadOnly = true;
            // 
            // colInactive
            // 
            this.colInactive.FillWeight = 104.6954F;
            this.colInactive.HeaderText = "Inactive";
            this.colInactive.Name = "colInactive";
            this.colInactive.ReadOnly = true;
            // 
            // colDate
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "dd-MMM-yyyy";
            this.colDate.DefaultCellStyle = dataGridViewCellStyle3;
            this.colDate.FillWeight = 104.6954F;
            this.colDate.HeaderText = "Date";
            this.colDate.Name = "colDate";
            this.colDate.ReadOnly = true;
            // 
            // colTime
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.Format = "HH:mm";
            dataGridViewCellStyle4.NullValue = null;
            this.colTime.DefaultCellStyle = dataGridViewCellStyle4;
            this.colTime.FillWeight = 104.6954F;
            this.colTime.HeaderText = "Time";
            this.colTime.Name = "colTime";
            this.colTime.ReadOnly = true;
            // 
            // colMaker
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colMaker.DefaultCellStyle = dataGridViewCellStyle5;
            this.colMaker.HeaderText = "Maker";
            this.colMaker.Name = "colMaker";
            this.colMaker.ReadOnly = true;
            // 
            // colApprover
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colApprover.DefaultCellStyle = dataGridViewCellStyle6;
            this.colApprover.HeaderText = "Approver";
            this.colApprover.Name = "colApprover";
            this.colApprover.ReadOnly = true;
            // 
            // colStatusID
            // 
            this.colStatusID.HeaderText = "StatusID";
            this.colStatusID.Name = "colStatusID";
            this.colStatusID.ReadOnly = true;
            this.colStatusID.Visible = false;
            // 
            // frmMDProcessingBoardRateApprover
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 372);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dtgBoardRateList);
            this.Name = "frmMDProcessingBoardRateApprover";
            this.Text = "Ongoing Boardrate (Approver view)";
            this.Shown += new System.EventHandler(this.frmMDProcessingDailyQuotation_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.dtgBoardRateList)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

        private System.Windows.Forms.DataGridView dtgBoardRateList;
		private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbApprove;
        private System.Windows.Forms.ToolStripButton tsbReturn;
        private System.Windows.Forms.ToolStripButton tsbRevise;
        private System.Windows.Forms.ToolStripButton tsbFreeze;
        private System.Windows.Forms.ToolStripButton tsbPrintPreview;
        private System.Windows.Forms.ToolStripButton tsbExport;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBoardRateID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colInactive;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaker;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApprover;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatusID;
	}
}