﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-20 (Wed, 20 March 2013) $
 * ========================================================
 * This class is used to view Team List
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Dto;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDTeamListView : frmMDMaster
    {
        #region Global Variable
        DataTable m_DataTable = null;
        DataView m_DataView = null;
        // For Security Checking
        clsSEAuthorizer m_Security = null;
		bool CommonError = false;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDTeamListView class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDTeamListView()
        {
			try
			{
				// Check authorization
				m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
				m_Security.CheckAuthorizationOnScreen(this);
				InitializeComponent();

				this.Text = clsMDConstant.TEAM_TITLE_LIST;
				this.m_DataView = new DataView();

                //Get all list team
                GetTeamList();
                //Load data for combo box
                GetDataForComboBoxDepartment();
                GetDataForComboBoxTeamType();
			}
			catch (Exception ex)
            {                
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
				//CommonError = true;
                Close();
            }
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Event form load, system will load data default:
        /// Data for ComboBox Department
        /// Data for ComboBox TeamType
        /// Data for DataGridView Team
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmMasTeamListView_Load(object sender, EventArgs e)
        {			
            try
            {
                //Set common style for form
                SetFormStyleCommon();                
            }
            catch (Exception ex)
            { 
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event form shown
        /// Set default DataGridView User not selected row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmMDTeamListView_Shown(object sender, EventArgs e)
        {
            //if (CommonError)
            //{
            //    this.Close();
            //}
        }

        /// <summary>
        /// Event form close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmMasTeamListView_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        /// <summary>
        /// Event click button "Search"
        /// Get list of users based on input params(DepartmentID, TeamTypeID, TeamCode, TeamName)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //disable all button
            EnableButtonControl(false);
            try
            {
                //get list team based on input params
                SearchTeams(GetInputParams());
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button based on security
            EnableButtonControl(true);
        }

        /// <summary>
        /// Event click button "Create" to tranfer Create Team screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnCreate_Click(object sender, EventArgs e)
        {
            ///tranfer to Create Team Screen
            frmMDTeamAddModify frm = new frmMDTeamAddModify(clsMDConstant.TEAM_TITLE_CREATE);
            frm.OnSaved += new EventHandler(frmNewModify_OnSaved);
            frm.m_CurrentAction = CommonValue.ActionType.New;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        /// <summary>
        /// Event click button "Modify" to tranfer Modify Team screen
        /// User must select a user to modify
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnModify_Click(object sender, EventArgs e)
        {            
            try
            {
                if (dtgTeamList.SelectedRows.Count > 0)
                {
                    if (dtgTeamList.SelectedRows.Count > 1)
                    {
                        //if user choose more than one item on grid
                        //display message to require user choose one item on grid before click modify button
                        //'Please select a team to modify.'                        
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a team", "modify"));
                    }
                    else
                    {
                        //get selected row
                        DataGridViewRow rowSelected = dtgTeamList.CurrentRow;
                        frmMDTeamAddModify frmModify = new frmMDTeamAddModify(clsMDConstant.TEAM_TITLE_MODIFY);
                        //define action after called save action on frmMDUserAddModify screen
                        frmModify.OnSaved += new EventHandler(frmNewModify_OnSaved);
                        //set updated object
                        frmModify.m_CurrentAction = CommonValue.ActionType.Update;
                        frmModify.m_UpdatingTeam.TeamID = int.Parse(rowSelected.Cells[clsMDConstant.MD_COL_TEAMID].Value.ToString());
                        frmModify.m_UpdatingTeam = clsMDTeamBUS.Instance().GetTeam(frmModify.m_UpdatingTeam.TeamID);
                        if (frmModify.m_UpdatingTeam != null)
                        {                            
                            frmModify.StartPosition = FormStartPosition.CenterScreen;
                            frmModify.ShowDialog();
                        }
                        else
                        {
                            //if system can not get information of selected object
                            //display error message
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.ERROR_NOT_FOUND_ITEM);
                        }
                    }
                }
                else
                {
                    //if user choose more than one item on grid
                    //display message to require user choose one item on grid before click modify button
                    //'Please select a team to modify.'                        
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a team", "modify"));
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }      
        }

        /// <summary>
        /// Event click button "Delete" to delete Team
        /// User must select a team to delete
        /// System set DelFlag = 1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //disable all button while system excute delete function.
            EnableButtonControl(false);
            try
            {
                DeleteTeam();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button based on security
            EnableButtonControl(true);
        }

        /// <summary>
        /// Event click button "Assign Team" to tranfer Assign Users To Team screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnAssign_Click(object sender, EventArgs e)
        {
            if (dtgTeamList.SelectedRows.Count > 0)
            {
                //tranfer to Assign Screeen
                frmMDAssignUsersToTeam frm = new frmMDAssignUsersToTeam(clsMDConstant.TEAM_TITLE_ASSIGN_USER);
                frm.OnSaved += new EventHandler(frmNewModify_OnSaved);

                DataGridViewRow rowSelected = dtgTeamList.CurrentRow;
                frm.iSelectedTeam = int.Parse(rowSelected.Cells[clsMDConstant.MD_COL_TEAMID].Value.ToString());

                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
            }
            else
            {
                //display message to require user choose one item on grid before click assign button
                //'Please select a team to assign.'
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a team", "assign"));
            }
        }

        /// <summary>
        /// Event click button "Close"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }
        #endregion

        #region Member Methods
        /// <summary>
        /// Enable or disable button control
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnSearch.Enabled = value;
            btnCreate.Enabled = value;
            btnModify.Enabled = value;
            btnDelete.Enabled = value;
            btnAssignUser.Enabled = value;
            btnClose.Enabled = value;
            if (value == true)
            {
                //check security
                if (btnSearch.Tag != null && !string.IsNullOrEmpty(btnSearch.Tag.ToString()))
                {
                    btnSearch.Enabled = bool.Parse(btnSearch.Tag.ToString());
                }
                if (btnCreate.Tag != null && !string.IsNullOrEmpty(btnCreate.Tag.ToString()))
                {
                    btnCreate.Enabled = bool.Parse(btnCreate.Tag.ToString());
                }
                if (btnModify.Tag != null && !string.IsNullOrEmpty(btnModify.Tag.ToString()))
                {
                    btnModify.Enabled = bool.Parse(btnModify.Tag.ToString());
                }
                if (btnDelete.Tag != null && !string.IsNullOrEmpty(btnDelete.Tag.ToString()))
                {
                    btnDelete.Enabled = bool.Parse(btnDelete.Tag.ToString());
                }
                if (btnAssignUser.Tag != null && !string.IsNullOrEmpty(btnAssignUser.Tag.ToString()))
                {
                    btnAssignUser.Enabled = bool.Parse(btnAssignUser.Tag.ToString());
                }
                //check logic
                if (m_DataTable != null && m_DataTable.Rows.Count == 0)
                {
                    btnDelete.Enabled = false;
                    btnModify.Enabled = false;
                    btnAssignUser.Enabled = false;
                }
            }
        }
       
        /// <summary>
        /// Get list of all user when form load
        /// Not get input params
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetTeamList()
        {
            m_DataTable = clsMDTeamBUS.Instance().GetTeamList(new clsMDTeamDTO());
            UpdateGridView(m_DataTable);
            dtgTeamList.ClearSelection();
        }

        /// <summary>
        /// update DataSource of Team DataGridView
        /// </summary>
        /// <param name="list">List<clsMDUserDTO></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void UpdateGridView(DataTable team)
        {
            dtgTeamList.DataSource = null;
            team.TableName = "Team";
            m_DataView.Table = team;             
            dtgTeamList.AutoGenerateColumns = false;
            dtgTeamList.DataSource = m_DataView;
        }

        /// <summary>
        /// Get list of departments for cbbDepartment
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetDataForComboBoxDepartment()
        {
            DataTable depts = clsMDTeamBUS.Instance().GetDepartmentList();
            if (depts == null) return;

            depts.Rows.InsertAt(depts.NewRow(), 0);
            depts.AcceptChanges();

            cbbDepartment.DataSource = depts;
            cbbDepartment.ValueMember = clsMDConstant.MD_COL_DEPARTMENTID;
            cbbDepartment.DisplayMember = clsMDConstant.MD_COL_DEPARTMENTNAME;
            cbbDepartment.SelectedIndex = 0;
        }

        /// <summary>
        /// Get list of teamTypes for cbbTeamType
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetDataForComboBoxTeamType()
        {
            DataTable teamTypes = clsMDTeamBUS.Instance().GetTeamTypeList();
            if (teamTypes == null) return;

            teamTypes.Rows.InsertAt(teamTypes.NewRow(), 0);
            teamTypes.AcceptChanges();

            cbbTeamType.DataSource = teamTypes;
            cbbTeamType.ValueMember = clsMDConstant.MD_COL_TEAMTYPEID;
            cbbTeamType.DisplayMember = clsMDConstant.MD_COL_TEAMTYPENAME;
            cbbTeamType.SelectedIndex = 0;
        }

        /// <summary>
        /// Get list of teams based on input params search
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void SearchTeams(clsMDTeamDTO dto)
        {
            m_DataTable = clsMDTeamBUS.Instance().GetTeamList(dto);
            UpdateGridView(m_DataTable);           
            if (m_DataTable == null || (m_DataTable != null && m_DataTable.Rows.Count == 0))
            {
                //display message 'No transaction found!'
                clsMDMesageCollection.MessageNoTransactions();                
            }
        }

        /// <summary>
        /// Get values of params to search
        /// </summary>
        /// <returns>clsMDUserDTO</returns>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private clsMDTeamDTO GetInputParams()
        {
            clsMDTeamDTO dto = new clsMDTeamDTO();
            if (String.IsNullOrEmpty(cbbDepartment.Text.Trim()))
            {
                dto.DepartmentID = -1;
            }
            else
            {
                if (cbbDepartment.FindStringExact(cbbDepartment.Text.Trim()) < 0)
                {
                    dto.DepartmentID = -1;
                }
                else
                {
                    dto.DepartmentID = int.Parse(cbbDepartment.SelectedValue.ToString());
                }
            }
            if (String.IsNullOrEmpty(cbbTeamType.Text.Trim()))
            {
                dto.TeamTypeID = -1;
            }
            else
            {
                if (cbbTeamType.FindStringExact(cbbTeamType.Text.Trim()) < 0)
                {
                    dto.TeamTypeID = -1;
                }
                else
                {
                    dto.TeamTypeID = int.Parse(cbbTeamType.SelectedValue.ToString());
                }
            }
            dto.TeamCode = txtTeamCode.Text.Trim();
            dto.TeamName = txtTeamName.Text.Trim();

            return dto;
        }

        /// <summary>
        /// Delete selected user
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void DeleteTeam()
        {            
            if (dtgTeamList.SelectedRows.Count > 0)
            {
                //display confirm message 'Are you sure to delete this team?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, string.Format(clsMDMessage.CONFIRM_ACTION_DELETE_DATA, "team"));
                if (res == DialogResult.Yes)
                {                    
                    DataGridViewRow dataRow = dtgTeamList.CurrentRow;
                    int iTeamID = int.Parse(dataRow.Cells[clsMDConstant.MD_COL_TEAMID].Value.ToString());

                    clsMDUserDTO dtoUser = new clsMDUserDTO();
                    dtoUser.TeamID = iTeamID;
                    DataTable dtUser = clsMDUserBUS.Instance().GetUserList(dtoUser);
                    if (dtUser != null && dtUser.Rows.Count > 0)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.ERROR_ACTION_CANNOT_DELETE, "team", "user"));
                        return;
                    }

                    //create data for save log
                    clsMDLogBase logBase = new clsMDLogBase();
                    logBase.ApplicationName = this.Text;
                    logBase.UserID = clsUserInfo.UserNo.ToString();
                    logBase.Module = clsMDConstant.MODULE_SE;
                    logBase.Action = (int)CommonValue.ActionType.Delete;
                    logBase.Key = dataRow.Cells[clsMDConstant.MD_COL_TEAMCODE].Value.ToString() + " " +
                                    dataRow.Cells[clsMDConstant.MD_COL_TEAMID].Value.ToString();

                    //Delete logic Team and Write Delete information to Log History
                    int iRow = clsMDTeamBUS.Instance().DeleteTeam(iTeamID, logBase);
                    if (iRow > 0)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Deleting", "team"));

                        //Refresh data on grid after delete
                        //GetTeamList();
                        SearchTeams(GetInputParams());
                    }
                    else if (iRow == 0)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Deleting", "team"));

                        //Refresh data on grid after delete
                        //GetTeamList();
                        SearchTeams(GetInputParams());
                    }
                    //else
                    //{
                    //    this.Close();
                    //}
                }                
            }
            else
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a team", "delete"));
            }            
        }

        /// <summary>
        /// Define EventHandle after excute action save in frmMasTeamAddModify
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmNewModify_OnSaved(object sender, EventArgs e)
        {
            //2013.06.11 UDP vlhcnhung S Reload data on grid after create/modify team
            //GetTeamList();
            SearchTeams(GetInputParams());
            //2013.06.11 UDP vlhcnhung E Reload data on grid after create/modify team
            EnableButtonControl(true);
        }
        #endregion
    }
}
