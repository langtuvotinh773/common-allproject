﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDAddModifyPrefixTDNo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSave = new System.Windows.Forms.Button();
            this.lblCCY = new System.Windows.Forms.Label();
            this.lblValue = new System.Windows.Forms.Label();
            this.lblRemark = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbbCCY = new System.Windows.Forms.ComboBox();
            this.rtbRemark = new System.Windows.Forms.RichTextBox();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(122, 158);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblCCY
            // 
            this.lblCCY.AutoSize = true;
            this.lblCCY.Location = new System.Drawing.Point(53, 29);
            this.lblCCY.Name = "lblCCY";
            this.lblCCY.Size = new System.Drawing.Size(28, 13);
            this.lblCCY.TabIndex = 0;
            this.lblCCY.Text = "CCY";
            // 
            // lblValue
            // 
            this.lblValue.AutoSize = true;
            this.lblValue.Location = new System.Drawing.Point(53, 50);
            this.lblValue.Name = "lblValue";
            this.lblValue.Size = new System.Drawing.Size(34, 13);
            this.lblValue.TabIndex = 1;
            this.lblValue.Text = "Value";
            // 
            // lblRemark
            // 
            this.lblRemark.AutoSize = true;
            this.lblRemark.Location = new System.Drawing.Point(53, 71);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(44, 13);
            this.lblRemark.TabIndex = 2;
            this.lblRemark.Text = "Remark";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(203, 158);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cbbCCY
            // 
            this.cbbCCY.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbCCY.FormattingEnabled = true;
            this.cbbCCY.Location = new System.Drawing.Point(108, 25);
            this.cbbCCY.Name = "cbbCCY";
            this.cbbCCY.Size = new System.Drawing.Size(170, 21);
            this.cbbCCY.TabIndex = 0;
            // 
            // rtbRemark
            // 
            this.rtbRemark.Location = new System.Drawing.Point(108, 74);
            this.rtbRemark.MaxLength = 200;
            this.rtbRemark.Name = "rtbRemark";
            this.rtbRemark.Size = new System.Drawing.Size(170, 71);
            this.rtbRemark.TabIndex = 2;
            this.rtbRemark.Text = "";
            // 
            // txtValue
            // 
            this.txtValue.Location = new System.Drawing.Point(108, 49);
            this.txtValue.MaxLength = 1;
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(170, 20);
            this.txtValue.TabIndex = 1;
            // 
            // frmMDAddModifyPrefixTDNo
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(345, 193);
            this.Controls.Add(this.txtValue);
            this.Controls.Add(this.rtbRemark);
            this.Controls.Add(this.cbbCCY);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblRemark);
            this.Controls.Add(this.lblValue);
            this.Controls.Add(this.lblCCY);
            this.Controls.Add(this.btnSave);
            this.Name = "frmMDAddModifyPrefixTDNo";
            this.Text = "Create Prefix TD No.";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDAddModifyPrefixTDNo_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Label lblCCY;
		private System.Windows.Forms.Label lblValue;
        private System.Windows.Forms.Label lblRemark;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cbbCCY;
        private System.Windows.Forms.RichTextBox rtbRemark;
        private System.Windows.Forms.TextBox txtValue;
    }
}