﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage threshold
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Config.Classes;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDAddModifyThreshold : frmMDMaster
	{
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        /// <summary>
        /// Is close form not check changed data
        /// </summary>
        bool m_ForceClose = false;
		/// <summary>
		/// CCY
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		string m_CCY;
		/// <summary>
		/// Transaction Type
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		string m_TransactionType;
		/// <summary>
		/// Threshold
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		double m_Threshold;
		/// <summary>
		/// Threshold ID
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		int m_ThresholdId;
		/// <summary>
		/// Action type: create or modify
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		int m_ActionType = -1;
		/// <summary>
		/// Value to show id the data is changed or not
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool m_IsChange = false;
		/// <summary>
		/// Form text: update threshold case
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private const string UPDATE_THRESHOLD = "Modify Threshold";
		/// <summary>
		/// Form text: create threshold case
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private const string CREATE_THRESHOLD = "Create Threshold"; 
		/// <summary>
		/// CCY
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		const string CCY = "CCY";
		/// <summary>
		/// Transaction type string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		const string TRANSACTION_TYPE= "Transaction Type";		
		/// <summary>
		/// clsMDThresholdBus Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsMDThresholdBUS m_MDThresholdBUS = new clsMDThresholdBUS();

		bool CommonError = false;
		
		/// <summary>
		/// Constructor: for create threshold case
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmMDAddModifyThreshold()
		{
			InitializeComponent();
            
            try
            {
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_ActionType = (int)CommonValue.ThresholdAction.Create;
                Init();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				CommonError = true;
            }
		}

		/// <summary>
		/// Constructor: for update threshold case
		/// </summary>
		/// <param name="strCCY">CCY</param>
		/// <param name="strTransactionType">Transaction Type</param>
		/// <param name="iThreshold">Threshold</param>
		/// <param name="iThresholdId">Threshold ID</param>
		public frmMDAddModifyThreshold(string strCCY, string strTransactionType, double iThreshold, int iThresholdId)
		{
			InitializeComponent();
            try
            {
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_CCY = strCCY;
                m_TransactionType = strTransactionType;
                m_Threshold = iThreshold;
                m_ActionType = (int)CommonValue.ThresholdAction.Modify;
                m_ThresholdId = iThresholdId;
                Init();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				CommonError = true;
            }
		}
	
		/// <summary>
		/// Initialize controls's value
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void Init()
		{
            SetFormStyleCommon();
            //LoadTransactionTypeWithoutEmptyItem(cbbTransactionType);
            LoadCurrency(cbbCCY);
            if (cbbCCY.Items.Count == 0)
            {
                List<CbbObject> lstCbbObj = new List<CbbObject>();
                lstCbbObj = clsMDCeilingFloorBUS.Instance().GetCurencyList();
                cbbCCY.DataSource = lstCbbObj;
            }

            List<CbbObject> lstTransactionType = new List<CbbObject>();
            lstTransactionType = clsMDGetDataCombobox.Instance().TransactionTypeWithoutEmptyItem;
            if (lstTransactionType == null)
            {
                lstTransactionType = clsMDBus.Instance().GetListMDParametersWithoutEmptyItem(clsMDConstant.PARAMETERS_TRANSACTION_TYPE);
            }
            switch (m_ActionType)
            {
                case (int)CommonValue.ThresholdAction.Modify:
                    this.Text = UPDATE_THRESHOLD;
                    //cbbTransactionType.Enabled = false;
                    cbbCCY.Enabled = false;
                    dtgTransactionType.ReadOnly = true;
                    dtgTransactionType.DefaultCellStyle.BackColor = clsMDConstant.BG_DGV_READONLY_COLUMN;
                    //cbbTransactionType.SelectedIndex = cbbTransactionType.FindString(m_TransactionType);
                    cbbCCY.SelectedIndex = cbbCCY.FindString(m_CCY);
                    txtThreshold.Text = m_Threshold + "";
                    if (lstTransactionType != null)
                    {
                        for (int i = 0; i < lstTransactionType.Count; i++)
                        {
                            if (((CbbObject)lstTransactionType[i]).Display.ToString() == m_TransactionType)
                            {
                                dtgTransactionType.Rows.Add(true, ((CbbObject)lstTransactionType[i]).Display, ((CbbObject)lstTransactionType[i]).Value);
                            }
                            else
                            {
                                dtgTransactionType.Rows.Add(false, ((CbbObject)lstTransactionType[i]).Display, ((CbbObject)lstTransactionType[i]).Value);
                            }
                            
                        }
                    }
                    break;
                case (int)CommonValue.ThresholdAction.Create:
                    this.Text = CREATE_THRESHOLD;
                    //cbbTransactionType.Enabled = true;
                    cbbCCY.Enabled = true;
                    dtgTransactionType.ReadOnly = false;
                    dtgTransactionType.DefaultCellStyle.BackColor = Color.White;
                    if (lstTransactionType != null)
                    {
                        for (int i = 0; i < lstTransactionType.Count; i++)
                        {
                            dtgTransactionType.Rows.Add(false, ((CbbObject)lstTransactionType[i]).Display, ((CbbObject)lstTransactionType[i]).Value);
                        }
                    }
                    break;
            }

			m_IsChange = false;
		}
		
		/// <summary>
		/// Check if user choose any transaction type or not
		/// </summary>
		/// <returns>True if user selected at least 1 item, false otherwise</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool DontHaveSelectTransactionType()
		{
            for (int i = 0; i < dtgTransactionType.Rows.Count; i++)
            {
                if (dtgTransactionType.Rows[i].Cells[0].Value.ToString() == true.ToString())
                {
                    return false;
                }
            }
			return true;
		}
		
		/// <summary>
		/// Check if the condition input on form are valid or not
		/// </summary>
		/// <returns>True if data valid, false otherwise</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool CheckValidCondition()
		{
			bool isValid = false;
			if (cbbCCY.SelectedIndex == 0)
			{
				clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " [" + CCY + "]"));
				cbbCCY.Focus();
			}
			else if (DontHaveSelectTransactionType())
			{
				clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " [" + TRANSACTION_TYPE + "]"));
				dtgTransactionType.Focus();
			}
            else if (txtThreshold.Text.Trim() == "")
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_PLEASE_INPUT, " [" + THRESHOLD + "]"));
                txtThreshold.Focus();
            }
            else
            {
                isValid = true;
            }
			if (!isValid)
				DialogResult = DialogResult.None;
			if (isValid == false)
				m_IsChange = true;
			return isValid;
		}
		
		/// <summary>
		/// Check if threshold is exist not not
		/// </summary>
		/// <param name="resultExist">Dialog result of confirming override or not</param>
		/// <returns>True if the threshold id exist, false otherwise</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool CheckExistThreshold(ref DialogResult resultExist)
		{
            if (m_ActionType == (int)CommonValue.ActionType.Update)
            {
                return false;
            }
			int iItemExist = 0;
			for (int i = 0; i < dtgTransactionType.Rows.Count; i++)
			{
				if (dtgTransactionType.Rows[i].Cells["colCheck"].Value.ToString() == true.ToString())
				{
					string strCCYCode = ((CbbObject) cbbCCY.SelectedItem).Value.ToString();
					int iTransactionType = int.Parse(dtgTransactionType.Rows[i].Cells["colTransactionValue"].Value.ToString());
					DataTable dtbCurrencyThresholdExist = m_MDThresholdBUS.CheckExistThreshold(strCCYCode, iTransactionType);
					iItemExist += dtbCurrencyThresholdExist.Rows.Count;
				}
			}
			if (iItemExist > 0)
			{
				DialogResult result = clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_OVERRIDE_THREADHOLD);
				if (result == DialogResult.Yes)
					return true;
				else if (result == DialogResult.Cancel)
				{
					resultExist = DialogResult.Cancel;
					return false;
				}
				else
				{
					resultExist = DialogResult.No;
					return false;
				}
			}
			return true;
		}
		
		/// <summary>
		/// Save threshold
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool SaveThreshold()
		{
            try
            {
                DialogResult resultCheckExist = new DialogResult();
                bool isAllowToOverride = CheckExistThreshold(ref resultCheckExist);
                bool isOverride = false;
                if (resultCheckExist == DialogResult.Cancel || resultCheckExist == DialogResult.No)
                {
                    return true;
                }
                if (CheckValidCondition())
                {
                    //if (txtThreshold.Text.Trim() == "")
                    //    txtThreshold.Text = "0";
                    string strCCYCode = ((CbbObject)cbbCCY.SelectedItem).Value.ToString();
                    string strThreshold = txtThreshold.Text.Trim().Replace(",", "");
                    string strThresholdExist = "";
                    int iThresholdIdExist = -1;
                    int iTransactionType = -1;// int.Parse(((CbbObject) cbbTransactionType.SelectedItem).Value.ToString());
                    int iSuccessCount = 0;
                    for (int i = 0; i < dtgTransactionType.Rows.Count; i++)
                    {
                        if (dtgTransactionType.Rows[i].Cells["colCheck"].Value.ToString() == true.ToString())
                        {
                            isOverride = false;
                            iTransactionType = int.Parse(dtgTransactionType.Rows[i].Cells["colTransactionValue"].Value.ToString());

                            ///- System validates data and saves it to database.				
                            switch (m_ActionType)
                            {
                                ///- In case of creating new 
                                case (int)CommonValue.CeilingFloorAction.Create:
                                    ///Ceiling.Floor that already existed in DB, 
                                    DataTable dtbCurrencyThresholdExist = m_MDThresholdBUS.CheckExistThreshold(strCCYCode, iTransactionType);
                                    if (dtbCurrencyThresholdExist.Rows.Count > 0)
                                    {
                                        iThresholdIdExist = int.Parse(dtbCurrencyThresholdExist.Rows[0]["ThresholdId"].ToString());
                                        strThresholdExist = dtbCurrencyThresholdExist.Rows[0]["Threshold"].ToString();

                                        ///system will alert a warning message. 
                                        //if (DialogResult.Yes == clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_OVVERIDE_THREADHOLD))
                                        if (isAllowToOverride)
                                        {	///If user agrees to override data, system will update 
                                            isOverride = true;
                                            m_ThresholdId = iThresholdIdExist;
                                            if (m_MDThresholdBUS.OverideThreshold(iThresholdIdExist, strThreshold) > 0)
                                            {
                                                iSuccessCount++;
                                            }
                                            ///- System will popup a message to announce “Data was saved successfully”									
                                            //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, OVERRIDING, THRESHOLD));
                                            //else
                                            //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, OVERRIDING, THRESHOLD));
                                        }
                                    }
                                    else
                                    {
                                        int iNewThresholdID = m_MDThresholdBUS.CreateThreshold(strCCYCode, iTransactionType, strThreshold);
                                        if (iNewThresholdID != m_ThresholdId)
                                        {
                                            ///- System will popup a message to announce “Data was saved successfully”
                                            //clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS,CREATING, THRESHOLD));
                                            m_ThresholdId = iNewThresholdID;
                                            iSuccessCount++;
                                        }
                                        //else
                                        //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, CREATING, THRESHOLD));
                                    }
                                    break;
                                case (int)CommonValue.CeilingFloorAction.Modify:
                                    if (m_MDThresholdBUS.UpdateThreshold(m_ThresholdId, strCCYCode, iTransactionType, strThreshold) > 0)
                                    {
                                        iSuccessCount++;
                                    }
                                    ///- System will popup a message to announce “Data was saved successfully”
                                    //{
                                    //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, MODIFYING, THRESHOLD));
                                    //}
                                    //else
                                    //    clsMDMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, MODIFYING, THRESHOLD));
                                    break;

                            }

                            ///- In case of actor clicks [No] on confirm message box, system will not save data in database and close confirm message.
                            ///- Operation log wil be saved.
                        }
                    }
                    if (m_ActionType == (int)CommonValue.ActionType.New)
                    {
                        if (iSuccessCount > 0)
                        {
                            WriteLog(isOverride, m_ActionType, iTransactionType, m_ThresholdId, strThresholdExist);
                            //- System will popup a message to announce “Data was saved successfully”									
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, CREATING, THRESHOLD));
                            this.m_ForceClose = true;
                        }
                        else
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, CREATING, THRESHOLD));
                    }
                    else
                    {
                        if (iSuccessCount > 0)
                        {
                            WriteLog(isOverride, m_ActionType, iTransactionType, m_ThresholdId, strThresholdExist);
                            //- System will popup a message to announce “Data was saved successfully”									
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, MODIFYING, THRESHOLD));
                            this.m_ForceClose = true;
                        }
                        else
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, MODIFYING, THRESHOLD));
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                if (m_MDThresholdBUS.DAL.m_transaction != null)
                    m_MDThresholdBUS.RollBack();
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }		
			//m_IsChange = false;
            return true;
		}
		
		/// <summary>
		/// Write log
		/// </summary>
		/// <param name="isOverride">Is override case or not</param>
		/// <param name="iActionType">action type</param>
		/// <param name="iTransactionType">transaction type</param>
		/// <param name="iThresholdId">Threshold ID</param>
		/// <param name="strThresholdExist">Threshold exist string, in case of override</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void WriteLog(bool isOverride, int iActionType, int iTransactionType, int iThresholdId, string strThresholdExist)
		{	//History Header
			clsMDLogBase logBase = new clsMDLogBase();
			logBase.ApplicationName = this.Text;
			logBase.UserID = clsUserInfo.UserNo.ToString();
			logBase.Module = clsMDConstant.MODULE_MD;
			logBase.Key = iThresholdId.ToString();
			clsMDLogInformation logInfo = new clsMDLogInformation();
			if (isOverride)
			{
				logBase.ApplicationName = UPDATE_THRESHOLD;
				logBase.Action = (int) CommonValue.ActionType.Update; 
				if (m_Threshold != double.Parse(txtThreshold.Text.Replace(",","")))
				{
					logInfo = new clsMDLogInformation();
					logInfo.FieldName = THRESHOLD;
					logInfo.OldValue = strThresholdExist;
					logInfo.NewValue = txtThreshold.Text;
					logBase.LstLogInformation.Add(logInfo);
				} 
			}
			else
				switch (iActionType)
				{
					case (int) CommonValue.ActionType.Update:
						logBase.Action = (int) CommonValue.ActionType.Update;

						if (m_Threshold != double.Parse(txtThreshold.Text.Replace(",", "")))
						{
							logInfo = new clsMDLogInformation();
							logInfo.FieldName = THRESHOLD;
							logInfo.OldValue = m_Threshold.ToString();
							logInfo.NewValue = txtThreshold.Text;
							logBase.LstLogInformation.Add(logInfo);
						} 
						break;
					case (int) CommonValue.ActionType.New:

						logBase.Action = (int) CommonValue.ActionType.New;

						logInfo = new clsMDLogInformation();
						logInfo.FieldName = CCY;
						logInfo.OldValue = string.Empty;
						logInfo.NewValue = ((CbbObject) cbbCCY.SelectedItem).Display.ToString();
						logBase.LstLogInformation.Add(logInfo);

						logInfo = new clsMDLogInformation();
						logInfo.FieldName = TRANSACTION_TYPE;
						logInfo.OldValue = string.Empty;
						logInfo.NewValue = iTransactionType.ToString();
						logBase.LstLogInformation.Add(logInfo); 

						logInfo = new clsMDLogInformation();
						logInfo.FieldName = THRESHOLD;
						logInfo.OldValue = string.Empty;
						logInfo.NewValue = txtThreshold.Text;
						logBase.LstLogInformation.Add(logInfo);
						break;
				}
			logBase.WirteLog(m_MDThresholdBUS.DAL);
			m_MDThresholdBUS.Commit();
			DialogResult = DialogResult.OK;
			m_IsChange = false;
		}
		
		/// <summary>
		/// Save even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnSave_Click(object sender, EventArgs e)
		{
            DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.ARE_YOU_SURE_TO_SAVE_DATA);
            ///- User clicks on “Save” button.
            ///- System display a confirm message box “Are you sure to save data?”
            ///- User clicks on “Yes” button.

            if (result == DialogResult.Yes)
                SaveThreshold();
            else if (result == DialogResult.No)
            {
                m_IsChange = false;
                DialogResult = DialogResult.No;
            }
		}

		/// <summary>
		/// Cancel even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
			//m_IsChange = false;
			this.Close();
		}

		/// <summary>
		/// Form closing even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void frmMasAddCeilingFloor_FormClosing(object sender, FormClosingEventArgs e)
		{
            if (!this.m_ForceClose)
            {
                Console.WriteLine(m_IsChange.ToString());
                if (m_IsChange)
                {
                    DialogResult result = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                    if (result == DialogResult.Yes)
                    {
                        if (!SaveThreshold())
                        {
                            e.Cancel = true;
                        }
                    }
                    else if (result == DialogResult.Cancel)
                        e.Cancel = true;
                }
            }
		}
		
		/// <summary>
		/// Seleted indexchanged even of combobox
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void cbbCCY_SelectedIndexChanged(object sender, EventArgs e)
		{
			m_IsChange = true;
		}

		/// <summary>
		/// Threshold textbox leave even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void txtThreshold_Leave(object sender, EventArgs e)
		{
			//if (txtThreshold.Text.Trim() == "")
			//    txtThreshold.Text = "0";
		}

		/// <summary>
		/// Threshold textbox changed even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void txtThreshold_TextChanged(object sender, EventArgs e)
		{
			m_IsChange = true;
		}

		/// <summary>
		/// Datagrid cell enter even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void dtgTransactionType_CellEnter(object sender, DataGridViewCellEventArgs e)
		{
            if (e.ColumnIndex == 0)
            {
                m_IsChange = true;
            }
			Console.WriteLine(m_IsChange.ToString());
		}

		/// <summary>
		/// Form shown even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void frmMDAddModifyThreshold_Shown(object sender, EventArgs e)
		{
			if(CommonError)
			{
				this.m_ForceClose = true;
				this.Close();
			}
			m_IsChange = false;
		}
		 
	}
}