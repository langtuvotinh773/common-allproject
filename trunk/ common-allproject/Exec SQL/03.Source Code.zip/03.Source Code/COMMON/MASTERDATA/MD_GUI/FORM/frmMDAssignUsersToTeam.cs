﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-21 (Thu, 21 March 2013) $
 * ========================================================
 * This class is used to Assign Users To Team
 * Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDAssignUsersToTeam : frmMDMaster
    {
        #region Global Variable
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        /// <summary>
        /// Event Handle after save action
        /// </summary>
        public event EventHandler OnSaved;
        
        string strTitleNormalUserLeft = "Unassign Users";
        string strTitleNormalUserRight = "Assign Users";
        string strTitleUserLeftTemplate = "Unassign Users (Belong to {0})";
        string strTitleUserRightTemplate = "Assign Users (Belong to {0})"; 
        string strTitleNormalTeamLeft = "Unassign Departments";
        string strTitleNormalTeamRight = "Assign Departments";
        string strTitleTeamLeftTemplate = "Unassign Teams (Belong to {0})";
        string strTitleTeamRightTemplate = "Assign Teams (Belong to {0})";
        string strTitleTeamLeftFully = string.Empty;
        string strTitleTeamRightFully = string.Empty;
        /// <summary>
        /// Is the first form load
        /// </summary>
        bool m_FormLoad = true;
        bool m_FirstLoad = true;

        public int iSelectedTeam = -1;
        public int iSelectedUser = -1;
        string m_SelectedUserName = string.Empty;

        string strOldAssignTeamCodeList = string.Empty;
        string strOldAssignUserNameList = string.Empty;

        /// <summary>
        /// Is close form not check changed data
        /// </summary>
        bool m_ForceClose = false;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDAssignUsersToTeam class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDAssignUsersToTeam(string title)
        {
            InitializeComponent();
            this.Text = title;

            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);
        }
        public frmMDAssignUsersToTeam()
        {
            InitializeComponent();   
         
            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);
        }
        #endregion

        #region Event Fucntions
        /// <summary>
        /// Form Load
        /// Set default settings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDAssignUsersToTeam_Load(object sender, EventArgs e)
        {
            //Set common style for form
            SetFormStyleCommon();                 
            btnSave.Enabled = false;
            m_FormLoad = false;
            if (iSelectedTeam > 0)
            {
                radTeam.Checked = true;                
            }
            else if (iSelectedUser > 0)
            {
                radUser.Checked = true;               
            }
            else
            {
                radTeam.Checked = true;
            }
        }

        /// <summary>
        /// Form close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMDAssignUsersToTeam_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                if (!m_ForceClose)
                {
                    //disable all button while system excute close and check changes of data
                    EnableButtonControl(false);
                    try
                    {
                        SaveChangedData(sender, e);
                    }
                    catch (Exception ex)
                    {                        
                        //show error message
                        clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                        //save log exception
                        clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
                    }
                    //enable all button
                    EnableButtonControl(true);
                }
            }
        }

        /// <summary>
        /// Radio Team selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void radTeam_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radTeam.Checked)
                {
                    //if data was changed on sreen, display message confirm to save changes of data
                    if (!this.m_FirstLoad)
                    {
                        if (IsChangeData())
                        {
                            SaveChangedData(null, null);
                        }
                    }     

                    //set m_FormLoad = true to stop event cbbTeam_SelectedIndexChanged when load data for ComboBox Team
                    m_FormLoad = true;
                    //reset value for Radio, Combo Box, TextBox, lable Title
                    cbbTeam.Enabled = true;
                    cbbTeam.ResetText();
                    cbbUser.SelectedIndex = -1;
                    cbbUser.ResetText();
                    cbbUser.Enabled = false;
                    radUser.Checked = false;
                    txtDeptNameForUser.ResetText();

                    lblLeft.Text = strTitleNormalUserLeft;
                    lblRight.Text = strTitleNormalUserRight;
                    //Create ListView based on Team
                    CreateUserListView();
                    //Load data for ComboBox Team
                    GetDataForComboBoxTeam();
                    //reset m_FormLoad = true to excute event cbbTeam_SelectedIndexChanged when load data for ComboBox Team
                    m_FormLoad = false;                   

                    if (iSelectedTeam <= 0)
                    {
                        if (cbbTeam.Items.Count > 0)
                        {
                            cbbTeam.SelectedIndex = 0;
                        }
                        iSelectedTeam = int.Parse(cbbTeam.SelectedValue.ToString()); 
                    }
                    else
                    {
                        cbbTeam.SelectedValue = iSelectedTeam.ToString();
                    }
                    iSelectedUser = -1;

                    btnSearch_Click(sender, e);
                    //lblControlName.Text = "Team Name: ";
                    lblControlValue.Text = string.Empty;//cbbTeam.Text;

                }
                btnSave.Enabled = false;
                this.m_FirstLoad = false;
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;                
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Radio User selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void radUser_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radUser.Checked)
                {
                    //if data was changed on sreen, display message confirm to save changes of data
                    if (!this.m_FirstLoad)
                    {
                        if (IsChangeData())
                        {
                            SaveChangedData(null, null);
                        }
                    }

                    //set m_FormLoad = true to stop event cbbTeam_SelectedIndexChanged when load data for ComboBox User
                    m_FormLoad = true;
                    //reset value for Radio, Combo Box, TextBox, lable Title
                    cbbUser.ResetText();
                    cbbUser.Enabled = true;
                    cbbTeam.SelectedIndex = -1;
                    cbbTeam.ResetText();
                    radTeam.Checked = false;
                    cbbTeam.Enabled = false;
                    txtDeptName.ResetText();
                    txtTeamTypeName.ResetText();
                    lblLeft.Text = strTitleNormalTeamLeft;
                    lblRight.Text = strTitleNormalTeamRight;
                    //Create ListView based on User
                    CreateTeamListView();
                    //Load data for ComboBox User
                    GetDataForComboBoxUser();
                    //reset m_FormLoad = true to excute event cbbTeam_SelectedIndexChanged when load data for ComboBox User
                    m_FormLoad = false;
                    
                    if (iSelectedUser <= 0)
                    {
                        if (cbbUser.Items.Count > 0)
                        {
                            cbbUser.SelectedIndex = 0;
                        }
                        iSelectedUser = int.Parse(cbbUser.SelectedValue.ToString());                        
                    }
                    else
                    {
                        cbbUser.SelectedValue = iSelectedUser.ToString();
                    }
                    iSelectedTeam = -1;
                    btnSearch_Click(sender, e);
                    //lblControlName.Text = "Full Name: ";
                    lblControlValue.Text = string.Empty;// cbbUser.Text;
                }
                btnSave.Enabled = false;
                this.m_FirstLoad = false;
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;                
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click button "Search"
        /// Search list unassign, assign based on selected radio Team or User
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //disable all button while system excute search function.
            EnableButtonControl(false);
            try
            {
                //if data was changed on sreen, display message confirm to save changes of data
                if (!this.m_FirstLoad)
                {
                    try
                    {
                        if (IsChangeData())
                        {
                            SaveChangedData(null, null);
                        }
                    }
                    catch (Exception ex)
                    {
                        this.m_ForceClose = true;
                        //show error message
                        clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                        //save log exception
                        clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
                    }
                }

                listViewLeft.Items.Clear();
                listViewRight.Items.Clear();
                if (radTeam.Checked)
                {
                    if (iSelectedTeam <= 0)
                    {
                        iSelectedTeam = -1;
                    }
                    else
                    {
                        iSelectedTeam = int.Parse(cbbTeam.SelectedValue.ToString());
                        lblControlName.Text = "Team Name: " + cbbTeam.Text;
                    }
                    iSelectedUser = -1;
                    GetUnassign_AssignUserList();
                    if (!string.IsNullOrEmpty(txtDeptName.Text))
                    {
                        lblLeft.Text = string.Format(strTitleUserLeftTemplate, txtDeptName.Text);
                        lblRight.Text = string.Format(strTitleUserRightTemplate, txtDeptName.Text);
                    }
                    else
                    {
                        lblLeft.Text = strTitleNormalUserLeft;
                        lblRight.Text = strTitleNormalUserRight;
                    }
                }
                else
                {
                    if (iSelectedUser <= 0)
                    {
                        iSelectedUser = -1;
                    }
                    else
                    {
                        iSelectedUser = int.Parse(cbbUser.SelectedValue.ToString());
                        lblControlName.Text = string.Format("Full Name: {0} - User Name: {1}", cbbUser.Text, m_SelectedUserName);
                    }
                    iSelectedTeam = -1;
                    GetUnassign_AssignTeamList();
                    //
                    string strDept = txtDeptNameForUser.Text;
                    if (!string.IsNullOrEmpty(strDept))
                    {
                        strTitleTeamLeftFully = string.Format(strTitleTeamLeftTemplate, strDept);
                        strTitleTeamRightFully = string.Format(strTitleTeamRightTemplate, strDept);
                        if (strDept.Length > 20)
                        {
                            strDept = strDept.Substring(0, 20) + "...";
                        }
                        //create short title
                        lblLeft.Text = string.Format(strTitleTeamLeftTemplate, strDept);
                        lblRight.Text = string.Format(strTitleTeamRightTemplate, strDept);
                    }
                    else
                    {
                        lblLeft.Text = strTitleNormalTeamLeft;
                        lblRight.Text = strTitleNormalTeamRight;
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button while system finish search function.
            EnableButtonControl(true);
            btnSave.Enabled = false;
        }

        /// <summary>
        /// Event click button ">>"
        /// Tranfer all item in ListView left to right
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnDoubleRight_Click(object sender, EventArgs e)
        {
            if (listViewLeft.Items != null && listViewLeft.Items.Count > 0)
            {
                foreach (ListViewItem item in listViewLeft.Items)
                {
                    TranferItemFromLeftToRight(item, listViewLeft, listViewRight);
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
            if (IsChangeData())
            {
                btnSave.Enabled = true;
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
            else
            {
                btnSave.Enabled = false;
            }
        }

        /// <summary>
        /// Event click button [>]
        /// Tranfer selected item in ListView left to right
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSingleRight_Click(object sender, EventArgs e)
        {
            if (listViewLeft.SelectedItems.Count > 0)
            {                
                foreach (ListViewItem item in listViewLeft.SelectedItems)
                {
                    TranferItemFromLeftToRight(item, listViewLeft, listViewRight);
                }
            }
            else
            {
                if (radTeam.Checked)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one user", "assign"));
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one team", "assign"));
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
            if (IsChangeData())
            {
                btnSave.Enabled = true;
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
            else
            {
                btnSave.Enabled = false;
            }
        }

        /// <summary>
        /// Event click button [<]
        /// Tranfer selected item in ListView right to left
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSingleLeft_Click(object sender, EventArgs e)
        {
            if (listViewRight.SelectedItems.Count > 0)
            {
                foreach (ListViewItem item in listViewRight.SelectedItems)
                {
                    TranferItemFromRightToLeft(item, listViewLeft, listViewRight);
                }
            }
            else
            {
                if (radTeam.Checked)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one user", "unassign"));
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one team", "unassign"));
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
            if (IsChangeData())
            {
                btnSave.Enabled = true;
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
            else
            {
                btnSave.Enabled = false;
            }
        }

        /// <summary>
        /// Event click button [<<]
        /// Tranfer all item in ListView right to left
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnDoubleLeft_Click(object sender, EventArgs e)
        {
            if (listViewRight.Items != null && listViewRight.Items.Count > 0)
            {
                foreach (ListViewItem item in listViewRight.Items)
                {
                    TranferItemFromRightToLeft(item, listViewLeft, listViewRight);
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
            if (IsChangeData())
            {
                btnSave.Enabled = true;
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
            else
            {
                btnSave.Enabled = false;
            }
        } 

        /// <summary>
        /// When user selected index changed of cbbTeam
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void cbbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(cbbTeam.Text.Trim()) && !this.m_FirstLoad)
                {
                    iSelectedTeam = -1;
                }
                if (!this.m_FormLoad)
                {
                    if (!string.IsNullOrEmpty(cbbTeam.Text.Trim()))
                    {
                        int iTeamID;
                        if (cbbTeam.FindStringExact(cbbTeam.Text) < 0)
                        {
                            iTeamID = -1;
                        }
                        else
                        {
                            iTeamID = int.Parse(cbbTeam.SelectedValue.ToString());
                            clsMDTeamDTO teamDTO = clsMDTeamBUS.Instance().GetTeam(iTeamID);
                            if (teamDTO != null)
                            {
                                txtDeptName.Text = teamDTO.DepartmentName;
                                txtTeamTypeName.Text = teamDTO.TeamTypeName;
                                //if (!string.IsNullOrEmpty(teamDTO.DepartmentName.Trim()))
                                //{
                                //    lblLeft.Text = string.Format(strTitleUserLeftTemplate, teamDTO.DepartmentName);
                                //    lblRight.Text = string.Format(strTitleUserRightTemplate, teamDTO.DepartmentName);
                                //}
                                //else
                                //{
                                //    lblLeft.Text = strTitleNormalUserLeft;
                                //    lblRight.Text = strTitleNormalUserRight;
                                //}
                            }
                        }
                    }
                    btnSave.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }        

        /// <summary>
        /// When user selected index changed of cbbUser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void cbbUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(cbbUser.Text.Trim()) && !this.m_FirstLoad)
                {
                    iSelectedUser = -1;
                }
                if (!m_FormLoad)
                {
                    if (!string.IsNullOrEmpty(cbbUser.Text.Trim()))
                    {
                        int iUserID;
                        if (cbbUser.FindStringExact(cbbUser.Text.Trim()) < 0)
                        {
                            iUserID = -1;
                        }
                        else
                        {
                            iUserID = int.Parse(cbbUser.SelectedValue.ToString());
                            clsMDUserDTO userDTO = clsMDUserBUS.Instance().GetUser(iUserID);
                            if (userDTO != null)
                            {
                                m_SelectedUserName = userDTO.UserName;
                                if (!string.IsNullOrEmpty(userDTO.Department))
                                {
                                    string strDept = userDTO.Department.Replace("  ", " ").Trim();
                                    int index = strDept.LastIndexOf(",");
                                    if (index == strDept.Length - 1)
                                    {
                                        //remove comma at the last of department name
                                        strDept = strDept.Substring(0, strDept.Length - 1);
                                    }
                                    txtDeptNameForUser.Text = strDept;
                                    //strTitleTeamLeftFully = string.Format(strTitleTeamLeftTemplate, strDept);
                                    //strTitleTeamRightFully = string.Format(strTitleTeamRightTemplate, strDept);
                                    //if (strDept.Length > 20)
                                    //{
                                    //    strDept = strDept.Substring(0, 20) + "...";
                                    //}
                                    ////create short title
                                    //lblLeft.Text = string.Format(strTitleTeamLeftTemplate, strDept);
                                    //lblRight.Text = string.Format(strTitleTeamRightTemplate, strDept);
                                }
                                else
                                {
                                    lblLeft.Text = strTitleNormalTeamLeft;
                                    lblRight.Text = strTitleNormalTeamRight;
                                    txtDeptNameForUser.Text = string.Empty;
                                }
                            }
                            else
                            {
                                m_SelectedUserName = string.Empty;
                            }
                        }
                    }
                    btnSave.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click button "Save"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {            
            //disable all button while system excute save assignment function.
            EnableButtonControl(false);
            try
            {
                if (radTeam.Checked)
                {
                    if (iSelectedTeam == -1)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a team", "assign"));
                        cbbTeam.Focus();
                        return;
                    }
                }
                else
                {
                    if (iSelectedUser == -1)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "assign"));
                        cbbUser.Focus();
                        return;
                    }
                }
                if (listViewLeft.Items.Count > 0 || listViewRight.Items.Count > 0)
                {
                    //display message 'Do you want to save assignment?'
                    DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "assignment"));
                    if (res == DialogResult.Yes)
                    {
                        if (iSelectedTeam > 0 && iSelectedUser == -1)
                        {
                            if (SaveAssignUserList())
                            {
                                this.m_ForceClose = true;
                                if (OnSaved != null)
                                {
                                    OnSaved(sender, e);
                                }
                                this.Close();
                            }
                        }
                        else
                        {
                            if (SaveAssignTeamList())
                            {
                                this.m_ForceClose = true;
                                if (OnSaved != null)
                                {
                                    OnSaved(sender, e);
                                }
                                this.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button while system finish assignment function.
            EnableButtonControl(true);
        }

        /// <summary>
        /// Event click button "Cancel"
        /// System will close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        /// <summary>
        /// Show tooltip when mouse hover on title label
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void lblLeft_MouseEnter(object sender, EventArgs e)
        {
            if(radUser.Checked)
            {
                if (lblLeft.Text.Contains("..."))
                {
                    toolTip1.UseAnimation = false;
                    toolTip1.UseFading = false;
                    Point toolTipPoint = lblLeft.PointToClient(Cursor.Position);
                    if (toolTip1.Active)
                    {
                        toolTip1.Show(strTitleTeamLeftFully, lblLeft, toolTipPoint.X, toolTipPoint.Y + 15, 1000);
                    }
                }
            }
        }

        /// <summary>
        /// Show tooltip when mouse hover on title label
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void lblRight_MouseEnter(object sender, EventArgs e)
        {
            if (radUser.Checked)
            {
                if (lblRight.Text.Contains("..."))
                {
                    toolTip1.UseAnimation = false;
                    toolTip1.UseFading = false;
                    Point toolTipPoint = lblLeft.PointToClient(Cursor.Position);
                    if (toolTip1.Active)
                    {
                        toolTip1.Show(strTitleTeamRightFully, lblLeft, toolTipPoint.X, toolTipPoint.Y + 15, 1000);
                    }
                }
            }
        }

        /// <summary>
        /// Sort when click header of listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void listViewLeft_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            ItemComparer sorter = listViewLeft.ListViewItemSorter as ItemComparer;
            if (sorter == null)
            {
                sorter = new ItemComparer(e.Column);
                sorter.Order = SortOrder.Ascending;
                listViewLeft.ListViewItemSorter = sorter;
            }
            // if clicked column is already the column that is being sorted
            if (e.Column == sorter.Column)
            {
                // Reverse the current sort direction
                if (sorter.Order == SortOrder.Ascending)
                    sorter.Order = SortOrder.Descending;
                else
                    sorter.Order = SortOrder.Ascending;
            }
            else
            {
                // Set the column number that is to be sorted; default to ascending.
                sorter.Column = e.Column;
                sorter.Order = SortOrder.Ascending;
            }
            listViewLeft.Sort();
        }

        /// <summary>
        /// Sort when click header of listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void listViewRight_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            ItemComparer sorter = listViewRight.ListViewItemSorter as ItemComparer;
            if (sorter == null)
            {
                sorter = new ItemComparer(e.Column);
                sorter.Order = SortOrder.Ascending;
                listViewRight.ListViewItemSorter = sorter;
            }
            // if clicked column is already the column that is being sorted
            if (e.Column == sorter.Column)
            {
                // Reverse the current sort direction
                if (sorter.Order == SortOrder.Ascending)
                    sorter.Order = SortOrder.Descending;
                else
                    sorter.Order = SortOrder.Ascending;
            }
            else
            {
                // Set the column number that is to be sorted; default to ascending.
                sorter.Column = e.Column;
                sorter.Order = SortOrder.Ascending;
            }
            listViewRight.Sort();
        }
        #endregion

        #region Member Methods
        /// <summary>
        /// Enable or disable button
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnSearch.Enabled = value;
            btnCancel.Enabled = value;
            btnSave.Enabled = value;
            btnDoubleLeft.Enabled = value;
            btnSingleLeft.Enabled = value;
            btnDoubleRight.Enabled = value;
            btnSingleRight.Enabled = value;
            if (value)
            {
                //check security
                if (btnSearch.Tag != null && !string.IsNullOrEmpty(btnSearch.Tag.ToString()))
                {
                    btnSearch.Enabled = bool.Parse(btnSearch.Tag.ToString());
                }
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }             
            }
        }

        /// <summary>
        /// When radio department selected
        /// List View left and right are User List
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        void CreateUserListView()
        {
            listViewLeft.Clear();
            listViewRight.Clear();
            ArrayList arrTitleLeft = new ArrayList(new string[] { "Unassign User", "Team", "Team Type" });
            for (int i = 0; i < arrTitleLeft.Count; i++)
            {
                listViewLeft.Columns.Add(arrTitleLeft[i].ToString().Replace(" ", ""), arrTitleLeft[i].ToString());
                listViewLeft.Columns[i].Width = 88;
            }
            ArrayList arrTitleRight = new ArrayList(new string[] { "Assign User", "Team", "Team Type" });
            for (int i = 0; i < arrTitleLeft.Count; i++)
            {
                listViewRight.Columns.Add(arrTitleRight[i].ToString().Replace(" ", ""), arrTitleRight[i].ToString());
                listViewRight.Columns[i].Width = 88;
            }
        }

        /// <summary>
        /// Get list team for cbbTeam
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetDataForComboBoxTeam()
        {
            cbbTeam.DataSource = null;

            DataTable team = clsMDTeamBUS.Instance().GetAllTeamList();
            if (team == null) return;

            cbbTeam.DataSource = team;
            cbbTeam.ValueMember = clsMDConstant.MD_COL_TEAMID;
            cbbTeam.DisplayMember = clsMDConstant.MD_COL_TEAMNAME;
            cbbTeam.SelectedIndex = -1;
        }

        /// <summary>
        /// Get list department for cbbDepartment
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetDataForComboBoxUser()
        {
            cbbUser.DataSource = null;

            DataTable users = clsMDUserBUS.Instance().GetUserList();
            if (users == null) return;

            cbbUser.DataSource = users;
            cbbUser.ValueMember = clsMDConstant.MD_COL_USER_NO;
            cbbUser.DisplayMember = clsMDConstant.MD_COL_USERNAME;
            cbbUser.SelectedIndex = -1;
        }

        /// <summary>
        /// When radio user selected
        /// List View left and right are Department List
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        void CreateTeamListView()
        {
            listViewLeft.Clear();
            listViewRight.Clear();
            ArrayList arrTitleLeft = new ArrayList(new string[] { "Unassign Team", "Department", "Team Type" });
            for (int i = 0; i < arrTitleLeft.Count; i++)
            {
                listViewLeft.Columns.Add(arrTitleLeft[i].ToString().Replace(" ", ""), arrTitleLeft[i].ToString());
                listViewLeft.Columns[i].Width = 78;
            }
            ArrayList arrTitleRight = new ArrayList(new string[] { "Assign Team", "Department", "Team Type" });
            for (int i = 0; i < arrTitleLeft.Count; i++)
            {
                listViewRight.Columns.Add(arrTitleRight[i].ToString().Replace(" ", ""), arrTitleRight[i].ToString());
                listViewRight.Columns[i].Width = 78;
            }
            listViewLeft.Columns[0].Width = 95;
            listViewRight.Columns[0].Width = 95;
        }

        /// <summary>
        /// Get Unassign, Assign User List by TeamID
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetUnassign_AssignUserList()
        {
            listViewLeft.Items.Clear();
            listViewRight.Items.Clear();
            if (iSelectedTeam == -1)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a team", "assign"));
                cbbTeam.Focus();
            }
            else
            {
                DataTable dtUnassignUser = clsMDUserBUS.Instance().GetUnassignUserListByTeamID(iSelectedTeam);
                DataTable dtAssignUser = clsMDUserBUS.Instance().GetAssignUserListByTeamID(iSelectedTeam);
                LoadDataToUserListView(dtUnassignUser, listViewLeft);
                LoadDataToUserListView(dtAssignUser, listViewRight);
                this.strOldAssignTeamCodeList = string.Empty;
                this.strOldAssignUserNameList = GetAssignCodeList(listViewRight);
            }
        }

        /// <summary>
        /// Get Unassign, Assign Team List by UserNo
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetUnassign_AssignTeamList()
        {
            listViewLeft.Items.Clear();
            listViewRight.Items.Clear();
            if (iSelectedUser == -1)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "assign"));
                cbbUser.Focus();
            }
            else
            {
                DataTable dtUnassignTeam = clsMDUserBUS.Instance().GetUnassignTeamList(iSelectedUser);
                DataTable dtAssignTeam = clsMDUserBUS.Instance().GetAssignTeamList(iSelectedUser);
                LoadDataToTeamListView(dtUnassignTeam, listViewLeft);
                LoadDataToTeamListView(dtAssignTeam, listViewRight);
                this.strOldAssignTeamCodeList = GetAssignCodeList(listViewRight);
                this.strOldAssignUserNameList = string.Empty;
            }
        }

        /// <summary>
        /// Load Unassign, Assign User List to control
        /// </summary>
        /// <param name="dtUser">DataTable</param>
        /// <param name="listView">ListView</param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        void LoadDataToUserListView(DataTable dtUser, ListView listView)
        {
            if (dtUser != null)
            {
                for (int i = 0; i < dtUser.Rows.Count; i++)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = dtUser.Rows[i][clsMDConstant.MD_COL_FULLNAME].ToString();
                    item.SubItems.Add(dtUser.Rows[i][clsMDConstant.MD_COL_TEAMNAME].ToString());
                    item.SubItems.Add(dtUser.Rows[i][clsMDConstant.MD_COL_TEAMTYPENAME].ToString());
                    item.Tag = int.Parse(dtUser.Rows[i][clsMDConstant.MD_COL_USER_NO].ToString());
                    item.Name = dtUser.Rows[i][clsMDConstant.MD_COL_USERNAME].ToString();
                    listView.Items.Add(item);
                }
            }
        }

        /// <summary>
        /// Load Unassign, Assign Team List to control
        /// </summary>
        /// <param name="dtUser">DataTable</param>
        /// <param name="listView">ListView</param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        void LoadDataToTeamListView(DataTable dtTeam, ListView listView)
        {
            if (dtTeam != null)
            {
                for (int i = 0; i < dtTeam.Rows.Count; i++)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = dtTeam.Rows[i][clsMDConstant.MD_COL_TEAMNAME].ToString();
                    item.SubItems.Add(dtTeam.Rows[i][clsMDConstant.MD_COL_DEPARTMENTNAME].ToString());
                    item.SubItems.Add(dtTeam.Rows[i][clsMDConstant.MD_COL_TEAMTYPENAME].ToString());
                    item.Tag = int.Parse(dtTeam.Rows[i][clsMDConstant.MD_COL_TEAMID].ToString());
                    item.Name = dtTeam.Rows[i][clsMDConstant.MD_COL_TEAMCODE].ToString();
                    listView.Items.Add(item);
                }
            }
        }

        /// <summary>
        /// Check not select Teams with the same TeamType in assign list 
        /// </summary>
        /// <param name="listView">ListView: list selected assign team</param>
        /// <param name="item">ListViewItem: item need check same TeamType</param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private bool IsExistTeamSameTeamType(ListView lvTeam, ListViewItem item)
        {
            foreach (ListViewItem it in lvTeam.Items)
            {
                string strTeamTypeName = item.SubItems[it.SubItems.Count - 1].Text;
                if (it.SubItems[it.SubItems.Count - 1].Text.CompareTo(strTeamTypeName) == 0)
                {
                    return true;
                }
            }
            return false;
        }
        
        /// <summary>
        /// Check not select Users with the same TeamType in assign list
        /// </summary>
        /// <param name="strTeamTypeName">TeamType of selected Team</param>
        /// <param name="item">item need check same team type</param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private bool IsExistUserBelongSameTeamType(string strTeamTypeName, ListViewItem item)
        {
            string[] teamTypeNames = item.SubItems[item.SubItems.Count - 1].Text.Split(char.Parse(","));
            for (int i = 0; i < teamTypeNames.Length; i++)
            {
                if (strTeamTypeName.CompareTo(teamTypeNames[i].Trim()) == 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Save List Assign User
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private bool SaveAssignUserList()
        {
            //get data assignment
            string strUserId = string.Empty;
            foreach (ListViewItem item in listViewRight.Items)
            {
                if (string.IsNullOrEmpty(strUserId))
                {
                    strUserId += item.Tag.ToString();
                }
                else
                {
                    strUserId += "," + item.Tag.ToString();
                }
            }
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();

            //Save assignment and Write data to log
            int row = clsMDUserBUS.Instance().UpdataAssignUsersToTeam(strUserId, iSelectedTeam, clsUserInfo.UserNo, logBase);
            if (row >= 0)
            {
                if (row > 0 || IsChangeData() == false)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Assigning", "users to team"));
                    return true;
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Assigning", "users to team"));
                }
            }
            else
            {
                this.Close();
            }
            return false;
        }

        /// <summary>
        /// Save List Assign Team
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private bool SaveAssignTeamList()
        {
            string strTeamId = string.Empty;
            foreach (ListViewItem item in listViewRight.Items)
            {
                if (string.IsNullOrEmpty(strTeamId))
                {
                    strTeamId += item.Tag.ToString();
                }
                else
                {
                    strTeamId += "," + item.Tag.ToString();
                }
            }
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();

            //Save assignment and Write data to log
            int row = clsMDUserBUS.Instance().UpdataAssignTeamsToUser(iSelectedUser, strTeamId, clsUserInfo.UserNo, logBase);
            if (row >= 0)
            {
                if (row > 0 || IsChangeData() == false)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Assigning", "users to team"));
                    //GetUnassign_AssignUserList();
                    return true;
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Assigning", "users to team"));
                }
            }
            else
            {
                this.Close();
            }
            return false;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private bool IsChangeData()
        {
            ListView listRight = new ListView();
            DataTable dt = new DataTable();
            
            if (listViewLeft.Items.Count == 0 && listViewRight.Items.Count == 0)
            {
                return false;
            }

            if (iSelectedTeam == -1 && iSelectedUser >= 0) 
            {
                dt = clsMDUserBUS.Instance().GetAssignTeamList(iSelectedUser);
                LoadDataToTeamListView(dt, listRight);
            }
            else
            {
                dt = clsMDUserBUS.Instance().GetAssignUserListByTeamID(iSelectedTeam);
                LoadDataToUserListView(dt, listRight);
            }
            if (listRight.Items.Count == 0 && listViewRight.Items.Count > 0)
            {
                return true;
            }
            else if (listRight.Items.Count > 0 && listViewRight.Items.Count == 0)
            {
                return true;
            }
            else if (listRight.Items.Count != listViewRight.Items.Count)
            {
                return true;
            }
            else
            {
                Dictionary<string, string> checkList = new Dictionary<string, string>();
                foreach (ListViewItem item in listRight.Items)
                {
                    checkList.Add(item.Tag.ToString(), item.Text);
                }
                foreach (ListViewItem item in listViewRight.Items)
                {
                    if (!checkList.ContainsValue(item.Text))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Tranfer selected ListViewItem from right ListView to left ListView
        /// </summary>
        /// <param name="item">ListViewItem need tranfered</param>
        /// <param name="left">ListView</param>
        /// <param name="right">ListView</param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void TranferItemFromRightToLeft(ListViewItem item, ListView left, ListView right)
        {
            if (radTeam.Checked)
            {
                string strTeamName = item.SubItems[item.SubItems.Count - 2].Text;
                string strTeamTypeName = item.SubItems[item.SubItems.Count - 1].Text;
                strTeamName = strTeamName.Replace(cbbTeam.Text + ", ", "").Trim();
                strTeamName = strTeamName.Replace(cbbTeam.Text, "").Trim();
                strTeamTypeName = strTeamTypeName.Replace(txtTeamTypeName.Text + ", ", "").Trim();
                strTeamTypeName = strTeamTypeName.Replace(txtTeamTypeName.Text, "").Trim();
                if (strTeamName.IndexOf(",") == (strTeamName.Length - 1) && strTeamName.IndexOf(",") > -1)
                {
                    strTeamName = strTeamName.Substring(0, strTeamName.Length - 1);
                }
                if (strTeamTypeName.IndexOf(",") == (strTeamTypeName.Length - 1) && strTeamTypeName.IndexOf(",") > -1)
                {
                    strTeamTypeName = strTeamTypeName.Substring(0, strTeamTypeName.Length - 1);
                }
                item.SubItems[item.SubItems.Count - 2].Text = strTeamName;
                item.SubItems[item.SubItems.Count - 1].Text = strTeamTypeName;
            }
            right.Items.Remove(item);
            left.Items.Add(item);
        }

        /// <summary>
        /// Tranfer selected ListViewItem from left ListView to right ListView
        /// </summary>
        /// <param name="item"></param>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void TranferItemFromLeftToRight(ListViewItem item, ListView left, ListView right)
        {
            string strTeamName = string.Empty, strTeamTypeName = string.Empty;
            if (radUser.Checked)
            {
                if (!IsExistTeamSameTeamType(right, item))
                {
                    left.Items.Remove(item);
                    right.Items.Add(item);
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.ERROR_CHOOSE_TEAM_SAME_TEAMTYPE, item.Text));
                    return;
                }
            }
            else
            {
                if (!IsExistUserBelongSameTeamType(txtTeamTypeName.Text.Trim(), item))
                {
                    strTeamName = item.SubItems[item.SubItems.Count - 2].Text;
                    strTeamTypeName = item.SubItems[item.SubItems.Count - 1].Text;
                    strTeamName = string.IsNullOrEmpty(strTeamName.Trim()) ? cbbTeam.Text.Trim() : strTeamName + ", " + cbbTeam.Text.Trim();
                    strTeamTypeName = string.IsNullOrEmpty(strTeamTypeName.Trim()) ? txtTeamTypeName.Text : strTeamTypeName + ", " + txtTeamTypeName.Text;
                    item.SubItems[item.SubItems.Count - 2].Text = strTeamName;
                    item.SubItems[item.SubItems.Count - 1].Text = strTeamTypeName;
                    //
                    left.Items.Remove(item);
                    right.Items.Add(item);
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.ERROR_CHOOSE_USER_SAME_TEAMTYPE, item.Text));
                    return;
                }
            }
        }

        /// <summary>
        /// Create data to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private clsMDLogBase CreateDataSaveLog()
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_SE;
            clsMDLogInformation logInfo = new clsMDLogInformation();
            if (iSelectedTeam > 0 && iSelectedUser == -1)
            {
                logBase.Key = clsMDTeamBUS.Instance().GetTeam(iSelectedTeam).TeamCode;
                if (string.IsNullOrEmpty(strOldAssignUserNameList))
                {
                    logBase.Action = (int)CommonValue.ActionType.New;
                }
                else
                {
                    logBase.Action = (int)CommonValue.ActionType.Update;
                }
                //UserName
                logInfo.FieldName = clsMDConstant.MD_COL_USERNAME;
                logInfo.OldValue = strOldAssignUserNameList;
                logInfo.NewValue = GetAssignCodeList(listViewRight);
                logBase.LstLogInformation.Add(logInfo);
            }
            else
            {
                logBase.Key = clsMDUserBUS.Instance().GetUser(iSelectedUser).UserName;
                if (string.IsNullOrEmpty(strOldAssignTeamCodeList))
                {
                    logBase.Action = (int)CommonValue.ActionType.New;
                }
                else
                {
                    logBase.Action = (int)CommonValue.ActionType.Update;
                }
                //TeamCode
                logInfo.FieldName = clsMDConstant.MD_COL_DEPARTMENTCODE;
                logInfo.OldValue = strOldAssignTeamCodeList;
                logInfo.NewValue = GetAssignCodeList(listViewRight);
                logBase.LstLogInformation.Add(logInfo);
            }
            return logBase;
        }

        /// <summary>
        /// Get TeamCode or UserName selected to assign
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private string GetAssignCodeList(ListView listView)
        {
            string strSelectedCode = string.Empty;
            foreach (ListViewItem item in listView.Items)
            {
                if (string.IsNullOrEmpty(strSelectedCode))
                {
                    strSelectedCode += item.Name.ToString();
                }
                else
                {
                    strSelectedCode += ", " + item.Name.ToString();
                }
            }
            return strSelectedCode;
        }

        /// <summary>
        /// Save data was changed on sreen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="eventClose"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void SaveChangedData(object sender, FormClosingEventArgs eventClose)
        {
            //if data was changed on screen, display confirm message to save changed data
            if (IsChangeData())
            {
                //display message 'Do you want to save changes of data?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                if (res == DialogResult.Yes)
                {
                    if (iSelectedTeam > 0)
                    {
                        if (SaveAssignUserList())
                        {
                            if (eventClose != null)
                            {
                                if (OnSaved != null)
                                {
                                    if (sender != null)
                                    {
                                        OnSaved(sender, eventClose);
                                    }
                                }
                                this.Close();
                            }
                        }
                    }
                    else
                    {
                        if (SaveAssignTeamList())
                        {
                            if (eventClose != null)
                            {
                                if (OnSaved != null)
                                {
                                    if (sender != null)
                                    {
                                        OnSaved(sender, eventClose);
                                    }
                                }
                                this.Close();
                            }
                        }
                    }
                }
                else if (res == DialogResult.Cancel)
                {
                    eventClose.Cancel = true;
                }
            }
        }
        #endregion                
    }
}
