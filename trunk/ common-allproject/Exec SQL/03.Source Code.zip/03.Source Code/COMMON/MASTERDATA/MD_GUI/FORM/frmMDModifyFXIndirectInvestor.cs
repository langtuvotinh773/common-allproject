﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pqkhai $
 * $Date: 2013-05-16 (Thu, 16 May 2013) $
 * ========================================================
 * This class is used to create or modify a customer
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDModifyFXIndirectInvestor : frmMDMaster
    {
        #region Global Variable

        public clsMDCustomerDTO m_UpdatingCus;
        public event EventHandler OnSaved;
        public CommonValue.ActionType m_CurrentAction;
        bool m_ForceClose = false;
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        //Private member
        private string m_CustomerCode = "";
        private string m_FullName = "";
        private string m_ShortName = "";
        private int m_CustomerType = 0;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the frmMDModifySpecialCustomer class.
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public frmMDModifyFXIndirectInvestor()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initializes a new instance of the frmMDModifySpecialCustomer class.
        /// </summary>
        /// <param name="obj">title</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public frmMDModifyFXIndirectInvestor(string title)
        {
            InitializeComponent();

            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);

            this.Text = title;
            m_UpdatingCus = new clsMDCustomerDTO();
            m_CurrentAction = CommonValue.ActionType.New; //default

            // Disable all textbox
            txtCustCode.ReadOnly = true;
            txtFullName.ReadOnly = true;
            txtShortName.ReadOnly = true;
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Click Save button
        /// </summary>
        /// <param name="obj">sender</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            //disable all button
            EnableControl(false);
            try
            {
                //update information of customer to db
                if (SaveModifyAction() > 0)
                {
                    this.m_ForceClose = true;
                    if (OnSaved != null)
                    {
                        OnSaved(sender, e);
                    }
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //Enable control
            EnableControl(true);
        }

        /// <summary>
        /// Click Cancel button
        /// </summary>
        /// <param name="obj">sender</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }

        /// <summary>
        /// When close form
        /// </summary>
        /// <param name="obj">sender</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void frmMDModifyFXIndirectInvestor_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                try
                {
                    if (!m_ForceClose)
                    {
                        //if data was changed on screen, display confirm message to save changed data
                        if (IsDataChanged())
                        {
                            //display message 'Do you want to save changes of data?'
                            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                            if (res == DialogResult.Yes)
                            {
                                //update information of dept
                                if (SaveAModifiedCus() > 0)
                                {
                                    this.m_ForceClose = true;
                                    if (OnSaved != null)
                                    {
                                        OnSaved(sender, e);
                                    }
                                    this.Close();
                                }
                                else//if save unsuccessfull, display error message and not close form
                                {
                                    e.Cancel = true;
                                }
                            }
                            else if (res == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.m_ForceClose = true;
                    //show error message
                    clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                    //save log exception
                    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                }
            }
        }
        #endregion

        #region Member method
        /// <summary>
        /// load data to form
        /// </summary>
        /// <param name="obj">Customer object</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void SetData(clsMDCustomerDTO obj)
        {
            // Set data for Customer Code
            m_CustomerCode = obj.CustomerCode;
            txtCustCode.Text = m_CustomerCode;

            // Set data for Customer Full Name
            m_FullName = obj.FullName;
            txtFullName.Text = m_FullName;

            // Set data for Customer Short Name
            m_ShortName = obj.ShortName;
            txtShortName.Text = m_ShortName;            

            //Set data for Special checkbox
            if (obj.IndirectInvestor == true)
                ckbInvestor.Checked = true;
            else
                ckbInvestor.Checked = false;
        }    

        /// <summary>
        /// Save for action Modify Customer
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private int SaveModifyAction()
        {
            //display confirm message 'Are you sure to save customer?'
            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "customer"));
            if (res == DialogResult.Yes)
            {
                return SaveAModifiedCus();
            }
            else if (res == DialogResult.No)
            {
                this.m_ForceClose = true;
                this.Close();
            }
            return 0;
        }

        /// <summary>
        /// Save a modify customer
        /// </summary>
        /// <returns></returns>
        private int SaveAModifiedCus()
        {
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //Update dept and Write data to log
            //Update customer
            m_UpdatingCus = GetCustomerInfoFromControls();
            int iRow = clsMDCustomerBUS.Instance().UpdateCustomer(m_UpdatingCus, clsMDConstant.INDIRECT_INVESTOR, logBase);
            // If Update OK
            if (iRow > 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Modifying", "customer"));
            }
            else if (iRow == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Modifying", "customer"));
            }
            else
            {
                this.Close();
            }
            return iRow;
        }

        /// <summary>
        /// Get customer information to modify
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private clsMDCustomerDTO GetCustomerInfoFromControls()
        {
            clsMDCustomerDTO dto = new clsMDCustomerDTO();
            dto.CustomerCode = m_UpdatingCus.CustomerCode;
            dto.FullName = m_UpdatingCus.FullName;
            dto.ShortName = m_UpdatingCus.ShortName;
            //dto.CustomerType = m_UpdatingCus.CustomerType;
            if (ckbInvestor.Checked)
                dto.IndirectInvestor = true;
            else
                dto.IndirectInvestor = false;
            return dto;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        private bool IsDataChanged()
        {
            if (this.m_UpdatingCus.IndirectInvestor == false && ckbInvestor.Checked || this.m_UpdatingCus.IndirectInvestor == true && !ckbInvestor.Checked)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Enable or disable button action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private void EnableControl(bool value)
        {
            btnSave.Enabled = value;
            btnCancel.Enabled = value;           
        }

        /// <summary>
        /// Create data FX Indirect Investor customer to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        private clsMDLogBase CreateDataSaveLog()
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = txtCustCode.Text.Trim(); //main key is customer code
            logBase.Action = (int)CommonValue.ActionType.Update;

            clsMDLogInformation logInfo = new clsMDLogInformation();

            //Indirect Investor
            logInfo.FieldName = clsMDConstant.MD_COL_INDIRECT_INVESTOR;
            logInfo.OldValue = this.m_UpdatingCus.IndirectInvestor.ToString();
            logInfo.NewValue = ckbInvestor.Checked.ToString();
            logBase.LstLogInformation.Add(logInfo);
            return logBase;
        }
        #endregion
    }
}
