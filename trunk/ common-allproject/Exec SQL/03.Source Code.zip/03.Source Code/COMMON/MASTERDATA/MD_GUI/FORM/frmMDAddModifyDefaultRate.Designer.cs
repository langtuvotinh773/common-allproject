﻿namespace Phoenix.Common.MasterData.Gui
{
    partial class frmMDAddModifyDefaultRate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.dtpInputDateFrom = new System.Windows.Forms.DateTimePicker();
            this.lblInputDateFrom = new System.Windows.Forms.Label();
            this.lblInputDateTo = new System.Windows.Forms.Label();
            this.dtpInputDateTo = new System.Windows.Forms.DateTimePicker();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.cbbCCY = new System.Windows.Forms.ComboBox();
            this.lblCCY = new System.Windows.Forms.Label();
            this.txtRate = new UserCtrl.NumberOnlyTextBox();
            this.lblRate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtgDefaulRateList = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.colCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOldRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgDefaulRateList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(329, 271);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(410, 271);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // dtpInputDateFrom
            // 
            this.dtpInputDateFrom.CustomFormat = "dd-MMM-yyyy";
            this.dtpInputDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInputDateFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpInputDateFrom.Location = new System.Drawing.Point(79, 12);
            this.dtpInputDateFrom.Name = "dtpInputDateFrom";
            this.dtpInputDateFrom.Size = new System.Drawing.Size(104, 20);
            this.dtpInputDateFrom.TabIndex = 9;
            this.dtpInputDateFrom.Value = new System.DateTime(2013, 4, 24, 16, 5, 56, 169);
            // 
            // lblInputDateFrom
            // 
            this.lblInputDateFrom.AutoSize = true;
            this.lblInputDateFrom.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblInputDateFrom.Location = new System.Drawing.Point(9, 16);
            this.lblInputDateFrom.Name = "lblInputDateFrom";
            this.lblInputDateFrom.Size = new System.Drawing.Size(56, 13);
            this.lblInputDateFrom.TabIndex = 8;
            this.lblInputDateFrom.Text = "From Date";
            // 
            // lblInputDateTo
            // 
            this.lblInputDateTo.AutoSize = true;
            this.lblInputDateTo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblInputDateTo.Location = new System.Drawing.Point(209, 16);
            this.lblInputDateTo.Name = "lblInputDateTo";
            this.lblInputDateTo.Size = new System.Drawing.Size(46, 13);
            this.lblInputDateTo.TabIndex = 8;
            this.lblInputDateTo.Text = "To Date";
            // 
            // dtpInputDateTo
            // 
            this.dtpInputDateTo.CustomFormat = "dd-MMM-yyyy";
            this.dtpInputDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInputDateTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpInputDateTo.Location = new System.Drawing.Point(272, 12);
            this.dtpInputDateTo.Name = "dtpInputDateTo";
            this.dtpInputDateTo.Size = new System.Drawing.Size(104, 20);
            this.dtpInputDateTo.TabIndex = 9;
            this.dtpInputDateTo.Value = new System.DateTime(2013, 4, 24, 16, 5, 56, 169);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(497, 306);
            this.shapeContainer1.TabIndex = 10;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 14;
            this.lineShape1.X2 = 376;
            this.lineShape1.Y1 = 44;
            this.lineShape1.Y2 = 44;
            // 
            // cbbCCY
            // 
            this.cbbCCY.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbCCY.FormattingEnabled = true;
            this.cbbCCY.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbCCY.Location = new System.Drawing.Point(79, 56);
            this.cbbCCY.Name = "cbbCCY";
            this.cbbCCY.Size = new System.Drawing.Size(104, 21);
            this.cbbCCY.TabIndex = 12;
            // 
            // lblCCY
            // 
            this.lblCCY.AutoSize = true;
            this.lblCCY.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCCY.Location = new System.Drawing.Point(10, 60);
            this.lblCCY.Name = "lblCCY";
            this.lblCCY.Size = new System.Drawing.Size(28, 13);
            this.lblCCY.TabIndex = 11;
            this.lblCCY.Text = "CCY";
            // 
            // txtRate
            // 
            this.txtRate.CustomDecimal = 3;
            this.txtRate.CustomLenght = 6;
            this.txtRate.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtRate.Location = new System.Drawing.Point(272, 56);
            this.txtRate.Name = "txtRate";
            this.txtRate.NeedDecimal = true;
            this.txtRate.Size = new System.Drawing.Size(105, 20);
            this.txtRate.StringFormat = "#,0.000";
            this.txtRate.TabIndex = 14;
            // 
            // lblRate
            // 
            this.lblRate.AutoSize = true;
            this.lblRate.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblRate.Location = new System.Drawing.Point(209, 60);
            this.lblRate.Name = "lblRate";
            this.lblRate.Size = new System.Drawing.Size(30, 13);
            this.lblRate.TabIndex = 13;
            this.lblRate.Text = "Rate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(380, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "%";
            // 
            // dtgDefaulRateList
            // 
            this.dtgDefaulRateList.AllowUserToAddRows = false;
            this.dtgDefaulRateList.AllowUserToDeleteRows = false;
            this.dtgDefaulRateList.AllowUserToResizeColumns = false;
            this.dtgDefaulRateList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgDefaulRateList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgDefaulRateList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgDefaulRateList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgDefaulRateList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCCY,
            this.colRate,
            this.colOldRate});
            this.dtgDefaulRateList.EnableHeadersVisualStyles = false;
            this.dtgDefaulRateList.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtgDefaulRateList.Location = new System.Drawing.Point(14, 93);
            this.dtgDefaulRateList.MultiSelect = false;
            this.dtgDefaulRateList.Name = "dtgDefaulRateList";
            this.dtgDefaulRateList.RowHeadersVisible = false;
            this.dtgDefaulRateList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgDefaulRateList.Size = new System.Drawing.Size(301, 201);
            this.dtgDefaulRateList.TabIndex = 15;
            this.dtgDefaulRateList.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgDefaultRateList_CellMouseDoubleClick);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(410, 55);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 16;
            this.btnAdd.Text = "&Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // colCCY
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCCY.DefaultCellStyle = dataGridViewCellStyle2;
            this.colCCY.FillWeight = 127.1574F;
            this.colCCY.HeaderText = "CCY";
            this.colCCY.Name = "colCCY";
            this.colCCY.ReadOnly = true;
            // 
            // colRate
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colRate.DefaultCellStyle = dataGridViewCellStyle3;
            this.colRate.HeaderText = "Rate";
            this.colRate.Name = "colRate";
            this.colRate.ReadOnly = true;
            // 
            // colOldRate
            // 
            this.colOldRate.HeaderText = "Old Rate";
            this.colOldRate.Name = "colOldRate";
            this.colOldRate.ReadOnly = true;
            this.colOldRate.Visible = false;
            // 
            // frmMDAddModifyDefaultRate
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(497, 306);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dtgDefaulRateList);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.lblRate);
            this.Controls.Add(this.cbbCCY);
            this.Controls.Add(this.lblCCY);
            this.Controls.Add(this.dtpInputDateTo);
            this.Controls.Add(this.lblInputDateTo);
            this.Controls.Add(this.dtpInputDateFrom);
            this.Controls.Add(this.lblInputDateFrom);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "frmMDAddModifyDefaultRate";
            this.Text = "Create Default Ordinary Deposit I/S Rate";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDAddModifyDefaultRate_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dtgDefaulRateList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DateTimePicker dtpInputDateFrom;
        private System.Windows.Forms.Label lblInputDateFrom;
        private System.Windows.Forms.Label lblInputDateTo;
        private System.Windows.Forms.DateTimePicker dtpInputDateTo;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.ComboBox cbbCCY;
        private System.Windows.Forms.Label lblCCY;
        private UserCtrl.NumberOnlyTextBox txtRate;
        private System.Windows.Forms.Label lblRate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dtgDefaulRateList;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOldRate;
    }
}