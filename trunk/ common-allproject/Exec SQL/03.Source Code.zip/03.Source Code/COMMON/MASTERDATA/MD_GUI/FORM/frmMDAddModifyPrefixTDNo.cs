﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage ceiling floor
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;
using System.Data;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDAddModifyPrefixTDNo : frmMDMaster
    {
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        //If ModeAdd = true: form used to add data
        //If ModeAdd = false: form used to modify data
        private bool m_ModeAdd = true;
        private clsMDPrefixTDNoDTO m_PrefixTDNoDto;
        private clsMDPrefixTDNoBUS m_PrefixTDNoBus;
        private string m_TitleCreate = "Create Prefix TD No.";
        private string m_TitleModify = "Modify Prefix TD No.";

        #region Constructor

        /// <summary>
        /// Constructor for creating ceiling/floor
        /// </summary>
        /// @cond
        /// Author:Phuong Lap Co
        /// @endcond
        public frmMDAddModifyPrefixTDNo()
        {

            try
            {
                InitializeComponent();
                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_ModeAdd = true;
                this.Text = m_TitleCreate;
                m_PrefixTDNoDto = new clsMDPrefixTDNoDTO();

                //fill data to combobox CCY
                FillDataComboboxCCY();
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Constructor for modify data
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDAddModifyPrefixTDNo(short ID)
        {
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_ModeAdd = false;
                this.Text = m_TitleModify;
                m_PrefixTDNoDto = new clsMDPrefixTDNoDTO();

                //fill data to combobox CCY
                FillDataComboboxCCY();

                m_PrefixTDNoDto = clsMDPrefixTDNoBUS.Instance().GetPrefixTDNo(ID);

                if (m_PrefixTDNoDto != null)
                {
                    FillDataToUpdate();
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                           String.Format(clsMDMessage.ERROR_IS_DELETE, "Data"));
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion

        #region Event
        /// <summary>
        /// Save Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //check data on form
                if (!IsCheckDataInputOnForm())
                {
                    return;
                }
                DialogResult dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                    clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);

                if (dialog == DialogResult.Yes)
                {
                    if (m_ModeAdd)
                    {
                        //insert data
                        SaveData();
                    }
                    else
                    {
                        //Update data
                        UpdateData();
                    }
                }
            }
            catch (Exception ex)
            {
                try
                {
                    //rollback data
                    m_PrefixTDNoBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Cancel even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Form Closing Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void frmMDAddModifyPrefixTDNo_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    if (IsChangeValueOnForm())
                    {
                        DialogResult dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                            clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                        if (dialog == DialogResult.Yes)
                        {
                            if (m_ModeAdd)
                            {
                                //insert data
                                SaveData();
                            }
                            else
                            {
                                //Update data
                                UpdateData();
                            }
                        }
                        else if (dialog == DialogResult.No)
                        {
                            e.Cancel = false;
                        }
                        else if (dialog == DialogResult.Cancel)
                        {
                            e.Cancel = true;
                        }
                    }
                }
                else
                {
                    //close form
                    this.FormClosing -= new FormClosingEventHandler(frmMDAddModifyPrefixTDNo_FormClosing);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                try
                {
                    //rollback data
                    m_PrefixTDNoBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        #endregion

        #region Function
        /// <summary>
        /// Load data for Combobox Currency
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co        
        /// @endcond
        private void FillDataComboboxCCY()
        {
            //get Currency List
            DataTable m_dtCurrencyMaster = clsMDCurrencyMasterBUS.Instance().GetCurrencyList();

            if (m_dtCurrencyMaster == null) return;
            DataRow row = m_dtCurrencyMaster.NewRow();
            row[0] = String.Empty;
            m_dtCurrencyMaster.Rows.InsertAt(row, 0);

            cbbCCY.DataSource = m_dtCurrencyMaster;
            cbbCCY.ValueMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.DisplayMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.SelectedIndex = 0;

        }

        /// <summary>
        /// Fill Data to update
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillDataToUpdate()
        {
            cbbCCY.SelectedValue = m_PrefixTDNoDto.CCY;
            cbbCCY.Enabled = false;
            txtValue.Text = m_PrefixTDNoDto.Value;
            rtbRemark.Text = m_PrefixTDNoDto.Remark;
        }

        /// <summary>
        /// Save data
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool SaveData()
        {
            m_PrefixTDNoBus = new clsMDPrefixTDNoBUS();
            //get data for insert Applicant
            GetDataValueInsert();
            //used to check data input database
            int returnValue = m_PrefixTDNoBus.InsertPrefixTDNo(m_PrefixTDNoDto);
            if (returnValue > 0)
            {
                //write log history
                WriteLogInsert(m_PrefixTDNoDto);
                //commit data
                m_PrefixTDNoBus.Commit();
                //show message after save data is success
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                    clsMDMessage.DATA_WAS_SAVED_SUCCESSFULLY);
                frmMDAddModifyPrefixTDNo_FormClosing(null, null);
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                //rollback data
                m_PrefixTDNoBus.RollBack();
                //show message after save data failed
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    clsMDMessage.DATA_WAS_SAVED_UN_SUCCESSFULLY);
                return false;
            }

            return true;
        }


        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool UpdateData()
        {
            m_PrefixTDNoBus = new clsMDPrefixTDNoBUS();
            clsMDPrefixTDNoDTO dto = new clsMDPrefixTDNoDTO();
            //get data for insert Applicant

            GetDataValueUpdate(dto);
            //used to check data input database
            int returnValue = m_PrefixTDNoBus.UpdatePrefixTDNo(dto);
            if (returnValue > 0)
            {
                //write log history
                WriteLogUpdate(dto);
                //commit data
                m_PrefixTDNoBus.Commit();
                //show message after save data is success
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                    clsMDMessage.DATA_WAS_SAVED_SUCCESSFULLY);
                frmMDAddModifyPrefixTDNo_FormClosing(null, null);
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                //rollback data
                m_PrefixTDNoBus.RollBack();
                //show message after save data failed
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    clsMDMessage.DATA_WAS_SAVED_UN_SUCCESSFULLY);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Get Data to save
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataValueInsert()
        {
            //get data on form 
            m_PrefixTDNoDto.CCY = (string)cbbCCY.SelectedValue;
            m_PrefixTDNoDto.Value = txtValue.Text.Trim();
            m_PrefixTDNoDto.Remark = rtbRemark.Text.Trim();
        }

        /// <summary>
        /// Get Data to save
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataValueUpdate(clsMDPrefixTDNoDTO dto)
        {
            dto.PrefixTDNo = m_PrefixTDNoDto.PrefixTDNo;
            //get data on form 
            dto.CCY = (string)cbbCCY.SelectedValue;
            dto.Value = txtValue.Text.Trim();
            dto.Remark = rtbRemark.Text.Trim();
        }

        /// <summary>
        /// Check Data Input On Form
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsCheckDataInputOnForm()
        {
            //check required CCY
            if (String.IsNullOrEmpty(clsMDFunction.ConvertObjectToString(cbbCCY.SelectedValue)))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblCCY.Text));
                cbbCCY.Focus();
                return false;
            }
            if (m_ModeAdd)
            {
                m_PrefixTDNoBus = new clsMDPrefixTDNoBUS();
                //check CCY exist in database
                if (m_PrefixTDNoBus.IsExistCCYPrefixTDNo(clsMDFunction.ConvertObjectToString(cbbCCY.SelectedValue)))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        String.Format(clsMDMessage.ERR_ITEM_EXISTED, lblCCY.Text));
                    cbbCCY.Focus();
                    return false;
                }
            }            
            //check required value
            if (String.IsNullOrEmpty(txtValue.Text.Trim()))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, lblValue.Text));
                txtValue.Focus();
                return false;
            }
            return true;
        }

        /// <summary>
        /// Check data is changed on form
        /// Return true data is changed
        /// Return false data is not changed
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsChangeValueOnForm()
        {
            //check data is changed on form
            if (!clsMDFunction.ConvertObjectToString(m_PrefixTDNoDto.CCY).Equals(clsMDFunction.ConvertObjectToString(cbbCCY.SelectedValue)))
            {
                return true;
            }

            if (!clsMDFunction.ConvertObjectToString(m_PrefixTDNoDto.Value).Equals(txtValue.Text.Trim()))
            {
                return true;
            }

            if (!clsMDFunction.ConvertObjectToString(m_PrefixTDNoDto.Remark).Equals(rtbRemark.Text.Trim()))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Write log update status
        /// </summary>
        /// <param name="key"></param>
        /// <param name="iOldStatus"></param>
        /// <param name="iNewSatus"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLogInsert(clsMDPrefixTDNoDTO dto)
        {
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = dto.PrefixTDNo.ToString();
            logBase.Action = (int)CommonValue.ActionType.New;

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblCCY.Text,
                    OldValue = String.Empty,
                    NewValue = dto.CCY
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblValue.Text,
                    OldValue = String.Empty,
                    NewValue = dto.Value
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblRemark.Text,
                    OldValue = String.Empty,
                    NewValue = dto.Remark.ToString()
                });

            logBase.WirteLog(m_PrefixTDNoBus.DAL);
        }

        /// <summary>
        /// Write log update status
        /// </summary>
        /// <param name="key"></param>
        /// <param name="iOldStatus"></param>
        /// <param name="iNewSatus"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLogUpdate(clsMDPrefixTDNoDTO dto)
        {
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = dto.PrefixTDNo.ToString();
            logBase.Action = (int)CommonValue.ActionType.Update;

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblCCY.Text,
                    OldValue = m_PrefixTDNoDto.CCY,
                    NewValue = dto.CCY
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblValue.Text,
                    OldValue = m_PrefixTDNoDto.Value,
                    NewValue = dto.Value
                });

            logBase.LstLogInformation.Add(
                new clsMDLogInformation
                {
                    FieldName = lblRemark.Text,
                    OldValue = m_PrefixTDNoDto.Remark,
                    NewValue = dto.Remark
                });

            logBase.WirteLog(m_PrefixTDNoBus.DAL);
        }

        #endregion
    }
}