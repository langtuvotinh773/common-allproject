﻿namespace Phoenix.Common.MasterData.Gui
{
	partial class frmMDProcessingDailyQuotation
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMDProcessingDailyQuotation));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbRequestToApprove = new System.Windows.Forms.ToolStripButton();
            this.tsbModify = new System.Windows.Forms.ToolStripButton();
            this.tsbWithdraw = new System.Windows.Forms.ToolStripButton();
            this.tsbApprove = new System.Windows.Forms.ToolStripButton();
            this.tsbReturn = new System.Windows.Forms.ToolStripButton();
            this.tsbRevise = new System.Windows.Forms.ToolStripButton();
            this.tsbFreeze = new System.Windows.Forms.ToolStripButton();
            this.tsbPrintPreview = new System.Windows.Forms.ToolStripButton();
            this.tsbImport = new System.Windows.Forms.ToolStripButton();
            this.tsbExport = new System.Windows.Forms.ToolStripButton();
            this.dtgDailyQuotationList = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.coSeq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colInactive = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaker = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colApprover = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQuotationID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVersion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgDailyQuotationList)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbRequestToApprove,
            this.tsbModify,
            this.tsbWithdraw,
            this.tsbApprove,
            this.tsbReturn,
            this.tsbRevise,
            this.tsbFreeze,
            this.tsbPrintPreview,
            this.tsbImport,
            this.tsbExport});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(788, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbRequestToApprove
            // 
            this.tsbRequestToApprove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRequestToApprove.Image = ((System.Drawing.Image)(resources.GetObject("tsbRequestToApprove.Image")));
            this.tsbRequestToApprove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRequestToApprove.Name = "tsbRequestToApprove";
            this.tsbRequestToApprove.Size = new System.Drawing.Size(23, 22);
            this.tsbRequestToApprove.Text = "toolStripButton1";
            this.tsbRequestToApprove.ToolTipText = "Request to Approve";
            this.tsbRequestToApprove.Click += new System.EventHandler(this.tsbRequestToApprove_Click);
            // 
            // tsbModify
            // 
            this.tsbModify.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbModify.Image = ((System.Drawing.Image)(resources.GetObject("tsbModify.Image")));
            this.tsbModify.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbModify.Name = "tsbModify";
            this.tsbModify.Size = new System.Drawing.Size(23, 22);
            this.tsbModify.Text = "toolStripButton2";
            this.tsbModify.ToolTipText = "Modify";
            this.tsbModify.Click += new System.EventHandler(this.tsbModify_Click);
            // 
            // tsbWithdraw
            // 
            this.tsbWithdraw.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbWithdraw.Image = ((System.Drawing.Image)(resources.GetObject("tsbWithdraw.Image")));
            this.tsbWithdraw.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbWithdraw.Name = "tsbWithdraw";
            this.tsbWithdraw.Size = new System.Drawing.Size(23, 22);
            this.tsbWithdraw.Text = "toolStripButton3";
            this.tsbWithdraw.ToolTipText = "Withdraw";
            this.tsbWithdraw.Click += new System.EventHandler(this.tsbWithdraw_Click);
            // 
            // tsbApprove
            // 
            this.tsbApprove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbApprove.Image = ((System.Drawing.Image)(resources.GetObject("tsbApprove.Image")));
            this.tsbApprove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbApprove.Name = "tsbApprove";
            this.tsbApprove.Size = new System.Drawing.Size(23, 22);
            this.tsbApprove.Text = "toolStripButton1";
            this.tsbApprove.ToolTipText = "Approve";
            this.tsbApprove.Click += new System.EventHandler(this.tsbApprove_Click);
            // 
            // tsbReturn
            // 
            this.tsbReturn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbReturn.Image = ((System.Drawing.Image)(resources.GetObject("tsbReturn.Image")));
            this.tsbReturn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbReturn.Name = "tsbReturn";
            this.tsbReturn.Size = new System.Drawing.Size(23, 22);
            this.tsbReturn.Text = "toolStripButton1";
            this.tsbReturn.ToolTipText = "Return";
            this.tsbReturn.Click += new System.EventHandler(this.tsbReturn_Click);
            // 
            // tsbRevise
            // 
            this.tsbRevise.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRevise.Image = ((System.Drawing.Image)(resources.GetObject("tsbRevise.Image")));
            this.tsbRevise.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRevise.Name = "tsbRevise";
            this.tsbRevise.Size = new System.Drawing.Size(23, 22);
            this.tsbRevise.Text = "toolStripButton1";
            this.tsbRevise.ToolTipText = "Revise";
            this.tsbRevise.Click += new System.EventHandler(this.tsbRevise_Click);
            // 
            // tsbFreeze
            // 
            this.tsbFreeze.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbFreeze.Image = ((System.Drawing.Image)(resources.GetObject("tsbFreeze.Image")));
            this.tsbFreeze.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFreeze.Name = "tsbFreeze";
            this.tsbFreeze.Size = new System.Drawing.Size(23, 22);
            this.tsbFreeze.Text = "Freeze";
            this.tsbFreeze.ToolTipText = "Freeze";
            this.tsbFreeze.Click += new System.EventHandler(this.tsbFreeze_Click);
            // 
            // tsbPrintPreview
            // 
            this.tsbPrintPreview.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPrintPreview.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrintPreview.Image")));
            this.tsbPrintPreview.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrintPreview.Name = "tsbPrintPreview";
            this.tsbPrintPreview.Size = new System.Drawing.Size(23, 22);
            this.tsbPrintPreview.Text = "toolStripButton4";
            this.tsbPrintPreview.ToolTipText = "Preview";
            this.tsbPrintPreview.Click += new System.EventHandler(this.tsbPrintPreview_Click);
            // 
            // tsbImport
            // 
            this.tsbImport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbImport.Image = ((System.Drawing.Image)(resources.GetObject("tsbImport.Image")));
            this.tsbImport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbImport.Name = "tsbImport";
            this.tsbImport.Size = new System.Drawing.Size(23, 22);
            this.tsbImport.Text = "toolStripButton5";
            this.tsbImport.ToolTipText = "Import";
            this.tsbImport.Click += new System.EventHandler(this.tsbImport_Click);
            // 
            // tsbExport
            // 
            this.tsbExport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbExport.Image = ((System.Drawing.Image)(resources.GetObject("tsbExport.Image")));
            this.tsbExport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExport.Name = "tsbExport";
            this.tsbExport.Size = new System.Drawing.Size(23, 22);
            this.tsbExport.Text = "tsbExport";
            this.tsbExport.ToolTipText = "Export";
            this.tsbExport.Click += new System.EventHandler(this.tsbExport_Click);
            // 
            // dtgDailyQuotationList
            // 
            this.dtgDailyQuotationList.AllowUserToAddRows = false;
            this.dtgDailyQuotationList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgDailyQuotationList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgDailyQuotationList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgDailyQuotationList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.coSeq,
            this.colStatus,
            this.colInactive,
            this.colDate,
            this.colTime,
            this.colMaker,
            this.colApprover,
            this.colQuotationID,
            this.colVersion});
            this.dtgDailyQuotationList.Location = new System.Drawing.Point(12, 40);
            this.dtgDailyQuotationList.Name = "dtgDailyQuotationList";
            this.dtgDailyQuotationList.ReadOnly = true;
            this.dtgDailyQuotationList.RowHeadersVisible = false;
            this.dtgDailyQuotationList.Size = new System.Drawing.Size(764, 393);
            this.dtgDailyQuotationList.TabIndex = 1;
            this.dtgDailyQuotationList.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dtgDailyQuotationList_RowsRemoved);
            this.dtgDailyQuotationList.SelectionChanged += new System.EventHandler(this.dtgDailyQuotationList_SelectionChanged);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(620, 439);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "&Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(701, 439);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // coSeq
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.coSeq.DefaultCellStyle = dataGridViewCellStyle1;
            this.coSeq.FillWeight = 81.21828F;
            this.coSeq.HeaderText = "Seq";
            this.coSeq.Name = "coSeq";
            this.coSeq.ReadOnly = true;
            // 
            // colStatus
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colStatus.DefaultCellStyle = dataGridViewCellStyle2;
            this.colStatus.FillWeight = 104.6954F;
            this.colStatus.HeaderText = "Status";
            this.colStatus.MinimumWidth = 150;
            this.colStatus.Name = "colStatus";
            this.colStatus.ReadOnly = true;
            // 
            // colInactive
            // 
            this.colInactive.FillWeight = 104.6954F;
            this.colInactive.HeaderText = "Inactive";
            this.colInactive.Name = "colInactive";
            this.colInactive.ReadOnly = true;
            // 
            // colDate
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "dd/MMM/yyyy";
            this.colDate.DefaultCellStyle = dataGridViewCellStyle3;
            this.colDate.FillWeight = 104.6954F;
            this.colDate.HeaderText = "Date";
            this.colDate.Name = "colDate";
            this.colDate.ReadOnly = true;
            // 
            // colTime
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.Format = "T";
            dataGridViewCellStyle4.NullValue = null;
            this.colTime.DefaultCellStyle = dataGridViewCellStyle4;
            this.colTime.FillWeight = 104.6954F;
            this.colTime.HeaderText = "Time";
            this.colTime.Name = "colTime";
            this.colTime.ReadOnly = true;
            // 
            // colMaker
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colMaker.DefaultCellStyle = dataGridViewCellStyle5;
            this.colMaker.HeaderText = "Maker";
            this.colMaker.Name = "colMaker";
            this.colMaker.ReadOnly = true;
            // 
            // colApprover
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colApprover.DefaultCellStyle = dataGridViewCellStyle6;
            this.colApprover.HeaderText = "Approver";
            this.colApprover.Name = "colApprover";
            this.colApprover.ReadOnly = true;
            // 
            // colQuotationID
            // 
            this.colQuotationID.HeaderText = "Column1";
            this.colQuotationID.Name = "colQuotationID";
            this.colQuotationID.ReadOnly = true;
            this.colQuotationID.Visible = false;
            // 
            // colVersion
            // 
            this.colVersion.HeaderText = "Column1";
            this.colVersion.Name = "colVersion";
            this.colVersion.ReadOnly = true;
            this.colVersion.Visible = false;
            // 
            // frmMDProcessingDailyQuotation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 471);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dtgDailyQuotationList);
            this.Controls.Add(this.toolStrip1);
            this.Name = "frmMDProcessingDailyQuotation";
            this.Text = "Processing Daily Quotation (Maker)";
            this.Shown += new System.EventHandler(this.frmMDProcessingDailyQuotation_Shown);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgDailyQuotationList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.ToolStripButton tsbRequestToApprove;
		private System.Windows.Forms.ToolStripButton tsbModify;
		private System.Windows.Forms.ToolStripButton tsbWithdraw;
		private System.Windows.Forms.ToolStripButton tsbPrintPreview;
		private System.Windows.Forms.ToolStripButton tsbImport;
		private System.Windows.Forms.ToolStripButton tsbApprove;
		private System.Windows.Forms.ToolStripButton tsbReturn;
		private System.Windows.Forms.ToolStripButton tsbRevise;
		private System.Windows.Forms.DataGridView dtgDailyQuotationList;
		private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.ToolStripButton tsbExport;
        private System.Windows.Forms.ToolStripButton tsbFreeze;
        private System.Windows.Forms.DataGridViewTextBoxColumn coSeq;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colInactive;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaker;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApprover;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQuotationID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVersion;
	}
}