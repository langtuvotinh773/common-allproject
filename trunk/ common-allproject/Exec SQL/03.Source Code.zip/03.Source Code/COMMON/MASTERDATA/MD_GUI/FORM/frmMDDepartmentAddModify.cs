﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-14 (Thu, 14 March 2013) $
 * ========================================================
 * This class is used to create or modify a department
 * Belong to Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDDepartmentAddModify : frmMDMaster
    {
        #region Global Variable
        public clsMDDepartmentDTO m_UpdatingDept;
        public event EventHandler OnSaved;
        public CommonValue.ActionType m_CurrentAction;
        bool m_ForceClose = false;
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDDepartmentAddModify class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDDepartmentAddModify(string title)
        {
            InitializeComponent();

            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);

            this.Text = title;
            m_UpdatingDept = new clsMDDepartmentDTO();
            m_CurrentAction = CommonValue.ActionType.New;//default
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Form Load
        /// Set default settings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDDepartmentAddModify_Load(object sender, EventArgs e)
        {
            //Set common style for form
            SetFormStyleCommon(); 
        }

        /// <summary>
        /// Form Close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDDepartmentAddModify_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                try
                {
                    if (!m_ForceClose)
                    {
                        //if data was changed on screen, display confirm message to save changed data
                        if (IsDataChanged())
                        {
                            //disable all button
                            EnableButtonControl(false);
                            //display message 'Do you want to save changes of data?'
                            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                            if (res == DialogResult.Yes)
                            {
                                //check valid data
                                if (IsValidData())
                                {
                                    //save data and close form
                                    if (this.m_CurrentAction == CommonValue.ActionType.New)
                                    {
                                        //save new dept
                                        if (SaveANewDept() > 0)
                                        {
                                            this.m_ForceClose = true;
                                            if (OnSaved != null)
                                            {
                                                OnSaved(sender, e);
                                            }
                                            this.Close();
                                        }
                                        else//if save unsuccessfull, display error message and not close form
                                        {
                                            e.Cancel = true;
                                        }
                                    }
                                    else
                                    {
                                        //update information of dept
                                        if (SaveAModifiedDept() > 0)
                                        {
                                            this.m_ForceClose = true;
                                            if (OnSaved != null)
                                            {
                                                OnSaved(sender, e);
                                            }
                                            this.Close();
                                        }
                                        else//if save unsuccessfull, display error message and not close form
                                        {
                                            e.Cancel = true;
                                        }
                                    }
                                }
                                else
                                {
                                    e.Cancel = true;
                                }
                            }
                            else if (res == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                            //enable all button
                            EnableButtonControl(true);
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.m_ForceClose = true;
                    //show error message
                    clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                    //save log exception
                    clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
                }
            }
        }

        /// <summary>
        /// Event click button "Save"
        /// if current action is create, system will save a new department into DB
        /// if current action is modify, system will update information department into DB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            //disable all button
            EnableButtonControl(false);
            try
            {
                if (this.m_CurrentAction == CommonValue.ActionType.New)
                {
                    //Save new dept to db
                    if (SaveCreateAction() > 0)
                    {
                        this.m_ForceClose = true;
                        if (OnSaved != null)
                        {
                            OnSaved(sender, e);
                        }
                        this.Close();
                    }
                }
                else
                {
                    //update information of dept to db
                    if (SaveModifyAction() > 0)
                    {
                        this.m_ForceClose = true;
                        if (OnSaved != null)
                        {
                            OnSaved(sender, e);
                        }
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button
            EnableButtonControl(true);
        }

        /// <summary>
        /// Event click button "Cancel"
        /// If no data was changed on screen, system will close this screen
        /// If data was changed on screen, system will display a confirm message box: “Do you want to save changes of data?”
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }
        #endregion 

        #region Member Methods      

        /// <summary>
        /// Enable or disable button control
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnCancel.Enabled = value;
            btnSave.Enabled = value;
            //check security
            if (value)
            {
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
        }

        /// <summary>
        /// Check validation data
        /// </summary>
        /// <returns>
        /// if any required field is invalid, system will display a warning message and return false
        /// else return true
        /// </returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private bool IsValidData()
        {
            if (string.IsNullOrEmpty(txtDeptCode.Text.Trim()))
            {                
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Department Code"));
                txtDeptCode.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtDeptName.Text.Trim()))
            {                
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_REQUIRED, "Department Name"));
                txtDeptName.Focus();
                return false;
            }
            int iNewDept = (this.m_CurrentAction == CommonValue.ActionType.New) ? 0 : 1;
            int iDeptNo = (this.m_CurrentAction == CommonValue.ActionType.New) ? -1 : m_UpdatingDept.DepartmentID;
            Dictionary<string, int> checkDuplicate = clsMDDepartmentBUS.Instance().ValidationDuplicateDepartment(iNewDept, iDeptNo, txtDeptCode.Text.Trim(), txtDeptName.Text.Trim());
            if (checkDuplicate.ContainsKey(clsMDConstant.MD_COL_DEPARTMENTCODE))
            {
                int value = checkDuplicate[clsMDConstant.MD_COL_DEPARTMENTCODE];
                if (value > 0)
                {                    
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERR_ITEM_EXISTED, "Department Code"));
                    txtDeptCode.Focus();
                    return false;
                }
            }
            //if (checkDuplicate.ContainsKey(clsMDConstant.MD_COL_DEPARTMENTNAME))
            //{
            //    int value = checkDuplicate[clsMDConstant.MD_COL_DEPARTMENTNAME];
            //    if (value > 0)
            //    {                   
            //        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.ERROR_VALUE_IS_DUPLICATE, "Department Name"));
            //        txtDeptName.Focus();
            //        return false;
            //    }
            //}
            return true;
        }
        
        /// <summary>
        /// load data to form
        /// </summary>
        /// <param name="obj">Department object</param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public void SetData(clsMDDepartmentDTO obj)
        {            
            txtDeptCode.Text = obj.DepartmentCode;
            txtDeptName.Text = obj.DepartmentName;
            txtRemark.Text = obj.Remark;
        }

        /// <summary>
        /// Get department information to create or modify
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private clsMDDepartmentDTO GetDepartmentInfoFromControls()
        {
            clsMDDepartmentDTO dto = new clsMDDepartmentDTO();
            if (this.m_CurrentAction == CommonValue.ActionType.Update)
            {
                dto.DepartmentID = m_UpdatingDept.DepartmentID;
            }
            else
            {
                dto.DelFlag = false;
            }
            dto.DepartmentCode = txtDeptCode.Text;
            dto.DepartmentName = txtDeptName.Text;
            dto.Remark = txtRemark.Text;
            dto.CreatedBy = clsUserInfo.UserNo;
            dto.UpdateDate = DateTime.Now;
            return dto;
        }
        
        /// <summary>
        /// Save for action Create Department
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private int SaveCreateAction()
        {
            //check valid data
            if (IsValidData())
            {
                //display confirm message 'Are you sure to save department?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "department"));
                if (res == DialogResult.Yes)
                {
                    return SaveANewDept();
                }
                else if (res == DialogResult.No)
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
            }
            return 0;
        }

        /// <summary>
        /// Save a new department
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private int SaveANewDept()
        {
            m_UpdatingDept = GetDepartmentInfoFromControls();
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //Save new dept and Write data to log
            int iRow = clsMDDepartmentBUS.Instance().InsertDepartment(m_UpdatingDept, logBase);
            // If Insert OK
            if (iRow > 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Creating", "department"));
            }
            else if (iRow == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Creating", "department"));
            }
            else
            {
                this.m_ForceClose = true;
                this.Close();
            }
            return iRow;
        }
        
        /// <summary>
        /// Save for action Modify Department
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private int SaveModifyAction()
        {
            //check valida data
            if (IsValidData())
            {
                //display confirm message 'Are you sure to save department?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "department"));
                if (res == DialogResult.Yes)
                {
                    return SaveAModifiedDept();
                }
                else if (res == DialogResult.No)
                {
                    this.m_ForceClose = true;
                    this.Close();
                }
            }
            return 0;
        }

        /// <summary>
        /// Save a modify department
        /// </summary>
        /// <returns></returns>
        private int SaveAModifiedDept()
        {            
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();
            //Update dept and Write data to log
            m_UpdatingDept = GetDepartmentInfoFromControls();
            int iRow = clsMDDepartmentBUS.Instance().UpdateDepartment(m_UpdatingDept, logBase);
            // If Update OK
            if (iRow > 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Modifying", "department"));
            }
            else if (iRow == 0)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Modifying", "department"));
            }
            else
            {
                this.Close();
            }
            return iRow;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        private bool IsDataChanged()
        {
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                if (string.IsNullOrEmpty(txtDeptCode.Text.Trim()) && string.IsNullOrEmpty(txtDeptName.Text.Trim()) && string.IsNullOrEmpty(txtRemark.Text.Trim()))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                if (this.m_UpdatingDept.DepartmentName.CompareTo(txtDeptName.Text.Trim()) != 0)
                {
                    return true;
                }
                if (this.m_UpdatingDept.Remark.CompareTo(txtRemark.Text.Trim()) != 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Create data dept to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private clsMDLogBase CreateDataSaveLog()
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_SE;
            logBase.Key = txtDeptCode.Text.Trim();//main key is deptcode
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logBase.Action = (int)CommonValue.ActionType.New;
            }
            else
            {
                logBase.Action = (int)CommonValue.ActionType.Update;
            }

            clsMDLogInformation logInfo = new clsMDLogInformation();

            //DepartmentCode
            logInfo.FieldName = clsMDConstant.MD_COL_DEPARTMENTCODE;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingDept.DepartmentCode;
            }
            logInfo.NewValue = txtDeptCode.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);
            //DepartmentName
            logInfo = new clsMDLogInformation();
            logInfo.FieldName = clsMDConstant.MD_COL_DEPARTMENTNAME;
            if (this.m_CurrentAction == CommonValue.ActionType.New)
            {
                logInfo.OldValue = string.Empty;
            }
            else
            {
                logInfo.OldValue = this.m_UpdatingDept.DepartmentName;
            }
            logInfo.NewValue = txtDeptName.Text.Trim();
            logBase.LstLogInformation.Add(logInfo);            
            //Remark
            if (!string.IsNullOrEmpty(txtRemark.Text.Trim()))
            {
                logInfo = new clsMDLogInformation();
                logInfo.FieldName = clsMDConstant.MD_COL_REMARK;
                if (this.m_CurrentAction == CommonValue.ActionType.New)
                {
                    logInfo.OldValue = string.Empty;
                }
                else
                {
                    logInfo.OldValue = this.m_UpdatingDept.Remark;
                }
                logInfo.NewValue = txtRemark.Text.Trim();
                logBase.LstLogInformation.Add(logInfo);
            }
            return logBase;
        }
        #endregion
    }
}
