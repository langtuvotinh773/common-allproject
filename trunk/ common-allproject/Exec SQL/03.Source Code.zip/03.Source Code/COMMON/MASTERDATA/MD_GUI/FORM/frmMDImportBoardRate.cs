﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phuong Lap Co $
 * $Date: 2013-08-01 10:37:30 +0700 (Thu, 01 Agu 2013) $
 * $Revision: 3978 $
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.UserControl;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;
using Config.Classes;
using System.IO;
using Phoenix.Common.MasterData.Dto;
using Excel = Microsoft.Office.Interop.Excel;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDImportBoardRate : frmMDMaster
    {
        // For Security Checking
        clsSEAuthorizer m_Security = null;
        Phoenix.Common.Log.Dto.clsCOMExternalTransactionLogDTO externalLog;
        DataTable m_dtCurrencyMaster;
        DataTable m_dtCCYTerm;
        List<clsMDCurrencyHolidayDTO> m_lstCurrencyHoliday;
        //include Board Rate on grid
        clsMDBoardRateDTO m_BoardRateExcelDto = null;
        clsMDBoardRateDTO m_BoardRatePreviousDto = null;
        //List<clsMDBoardRateDetailDTO> listImportBRDetail = null;
        bool m_IsNotError = false;
        private string colTermName = "Term";
        private clsMDCommonValue.BoardRateStatus m_BoardRateStatus;
        //private clsMDCommonValue.BoardRateAction m_BoardRateAction;
        private clsMDBoardRaterBUS m_BoardRateBus;
        private int m_BoardRateID = 0;
        private List<int[,]> m_MatrixHLList;
        private int[,] m_MatrixHightlight;
        //m_IsCallMaker = true : is called from maker screen
        //m_IsCallMaker = false : is called from maker screen
        private bool m_IsCallMaker;
        private string m_CellCommonStart = "A1";
        private string m_CellCommonEnd = "B2";
        private string m_CellStart = "A1";
        private string m_CellEnd = "M15";
        private int m_iOldStatus = 0;
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the frmMDImportBoardRate class.
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmMDImportBoardRate(clsMDCommonValue.BoardRateStatus boardRateStatus, int boardRateID, bool isCallMarker)
        {
            try
            {
                InitializeComponent();
                SetFormStyleCommon();

                //Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                m_BoardRateStatus = boardRateStatus;
                m_BoardRateID = boardRateID;
                m_IsCallMaker = isCallMarker;

                //get Currency List
                m_dtCurrencyMaster = clsMDCurrencyMasterBUS.Instance().GetCurrencyList();
                //get CCY Term table
                m_dtCCYTerm = clsMDCCYTermsBUS.Instance().GetCCYTermsList();

                //fill data combobox CCY
                FillDataComboboxCCY();

                //set title Import Board Rate and system full fill action by board rate status
                InitializeBoardRate();
                //system full fill action
                SystemFullFillAction();
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }
        #endregion  

        #region Event Method
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void cbbAction_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                switch (m_BoardRateStatus)
                {
                    case clsMDCommonValue.BoardRateStatus.WaitingforApprove:
                        if (cbbAction.SelectedValue.GetType() == typeof(int))
                        {
                            if ((int)cbbAction.SelectedValue == (int)clsMDCommonValue.BoardRateAction.Return)
                            {
                                lblRemark.Visible = true;
                                txtRemark.Visible = true;
                            }
                            else
                            {
                                lblRemark.Visible = false;
                                txtRemark.Visible = false;
                            }
                        }
                        break;
                    case clsMDCommonValue.BoardRateStatus.Approved:
                        if (cbbAction.SelectedValue.GetType() == typeof(int))
                        {
                            if ((int)cbbAction.SelectedValue == (int)clsMDCommonValue.BoardRateAction.Revise)
                            {
                                lblRemark.Visible = true;
                                txtRemark.Visible = true;
                            }
                            else
                            {
                                lblRemark.Visible = false;
                                txtRemark.Visible = false;
                            }
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Combobox CCY selected value changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void cbbCCY_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (cbbCCY.SelectedValue.GetType() == typeof(string))
                {
                    string CCY = (string)cbbCCY.SelectedValue;
                    if (string.IsNullOrEmpty(CCY))
                    {
                        for (int i = 1; i < dtgDetail.Columns.Count; i++)
                        {
                            dtgDetail.Columns[i].Visible = true;
                        }
                    }
                    else
                    {
                        for (int i = 1; i < dtgDetail.Columns.Count; i++)
                        {
                            if (dtgDetail.Columns[i].HeaderText.ToUpper().Contains(CCY.ToUpper()))
                            {
                                dtgDetail.Columns[i].Visible = true;
                            }
                            else
                            {
                                dtgDetail.Columns[i].Visible = false;
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event click button "Browse" to tranfer OpenFileDialogs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                String sName = "";
                //Title OpenFileDialog
                //openFileDialogImport.Title = "Browse Import Board Rate File";
                openFileDialogImport.FileName = sName;
                //Filter files .txt
                openFileDialogImport.Filter = clsMDConstant.DIALOG_IMPORT_FILTER_TXT_EXCEL;
                //Show OpenFileDialog 
                string strDirectory = clsMDBoardRaterBUS.Instance().GetLastestFileDirectoryOfBoardRate();
                if (!string.IsNullOrEmpty(strDirectory))
                {
                    FileInfo file = new FileInfo(strDirectory);
                    DirectoryInfo drInfo = file.Directory;
                    openFileDialogImport.InitialDirectory = drInfo.ToString();
                }
                if (openFileDialogImport.ShowDialog() == DialogResult.OK)
                {
                    txtDirectory.Text = openFileDialogImport.FileName;
                }
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Read data from excel file and load to GUI
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnImport_Click(object sender, EventArgs e)
        {
            if (!IsValidFileImport())
            {
                return;
            }
            try
            {
                //initialize matrix hight light list
                m_MatrixHLList = new List<int[,]>();
                if (!GetDataBoardRateFromExcelFile(out m_BoardRateExcelDto))
                {
                    return;
                }

                #region Import data by status board rate

                switch (m_BoardRateStatus)
                {
                    case clsMDCommonValue.BoardRateStatus.Blank:

                        //draw Board Rate on grid
                        DrawGridBoardRate(m_BoardRateExcelDto);

                        int iCol = 1;
                        //hight light cell different
                        if (m_MatrixHLList.Count > 0)
                        {
                            for (int i = 0; i < m_MatrixHLList.Count; i++)
                            {
                                int[,] matrix = m_MatrixHLList[i];

                                for (int j = 0; j < 10; j++)
                                {
                                    for (int k = 1; k < 13; k++)
                                    {
                                        iCol = 12 * i + k;
                                        if (matrix[j + 5, k] == 1)
                                        {
                                            dtgDetail.Rows[j].Cells[iCol].Style.BackColor = Color.Yellow;
                                        }
                                    }
                                }
                            }
                        }

                        break;

                    case clsMDCommonValue.BoardRateStatus.New:

                        break;

                    case clsMDCommonValue.BoardRateStatus.WaitingforApprove:
                        if (m_IsCallMaker)
                        {

                        }
                        else
                        {

                        }

                        break;

                    case clsMDCommonValue.BoardRateStatus.Approved:
                        if (m_IsCallMaker)
                        {
                            //draw Board Rate on grid
                            DrawGridBoardRate(m_BoardRateExcelDto);
                        }

                        break;

                    case clsMDCommonValue.BoardRateStatus.Withdrawed:
                        //draw Board Rate on grid
                        DrawGridBoardRate(m_BoardRateExcelDto);

                        break;

                    case clsMDCommonValue.BoardRateStatus.Returned:
                        DrawGridBoardRate(m_BoardRateExcelDto, m_BoardRatePreviousDto);

                        //hight light cell different
                        if (dtgDetail.Rows.Count > 0)
                        {
                            for (int i = 0; i < dtgDetail.Rows.Count; i++)
                            {
                                for (int j = 1; j < dtgDetail.Columns.Count; j++)
                                {
                                    if (m_MatrixHightlight[i + 5, j] == 1)
                                    {
                                        dtgDetail.Rows[i].Cells[j].Style.BackColor = Color.Yellow;
                                    }
                                }
                            }
                        }

                        break;

                    case clsMDCommonValue.BoardRateStatus.Suspended:
                        DrawGridBoardRate(m_BoardRateExcelDto, m_BoardRatePreviousDto);

                        //hight light cell different
                        if (dtgDetail.Rows.Count > 0)
                        {

                            for (int i = 0; i < dtgDetail.Rows.Count; i++)
                            {
                                for (int j = 1; j < dtgDetail.Columns.Count; j++)
                                {
                                    if (m_MatrixHightlight[i + 5, j] == 1)
                                    {
                                        dtgDetail.Rows[i].Cells[j].Style.BackColor = Color.Yellow;
                                    }
                                }
                            }
                        }

                        break;

                    case clsMDCommonValue.BoardRateStatus.Obsolete:

                        break;
                    case clsMDCommonValue.BoardRateStatus.Freeze:

                        break;

                    default:
                        break;

                }

                #endregion
            }
            catch (Exception ex)
            {
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Button Cancel event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Import data to DB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                int iNewStatus = 0;
                DialogResult dialog;
                string strMessageConfirm = string.Empty;
                string strMsgSuccess = string.Empty;
                string strMsgFail = string.Empty;

                if (dtgDetail.Rows.Count == 0)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                            clsMDMessage.INFO_NO_DATA_IMPORT);
                    return;
                }
                switch (m_BoardRateStatus)
                {
                    case clsMDCommonValue.BoardRateStatus.Blank:
                        #region Process for Status = Blank

                        GetActionMessageByStatus(ref iNewStatus, ref strMessageConfirm, ref strMsgSuccess, ref strMsgFail);
                        m_BoardRateExcelDto.Status = iNewStatus;

                        dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                                            strMessageConfirm);
                        if (dialog == DialogResult.Yes)
                        {
                            m_BoardRateBus = new clsMDBoardRaterBUS();

                            externalLog.LogDate = clsMDBus.Instance().GetServerDateTime();
                            int row = m_BoardRateBus.InsertBoardRate(m_BoardRateExcelDto, externalLog);
                            if (row > 0)
                            {
                                m_BoardRateBus.Commit();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, strMsgSuccess);
                                this.Close();
                            }
                            else
                            {
                                m_BoardRateBus.RollBack();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, strMsgFail);
                            }
                        }
                        #endregion
                        break;

                    case clsMDCommonValue.BoardRateStatus.New:
                        #region Process for Status = New

                        GetActionMessageByStatus(ref iNewStatus, ref strMessageConfirm, ref strMsgSuccess, ref strMsgFail);
                        m_BoardRatePreviousDto.Status = iNewStatus;

                        dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, strMessageConfirm);

                        if (dialog == DialogResult.Yes)
                        {
                            m_BoardRateBus = new clsMDBoardRaterBUS();

                            int row = m_BoardRateBus.UpdateBoardRate(m_BoardRatePreviousDto);
                            if (row > 0)
                            {
                                WriteLogUpdateStatus(m_BoardRatePreviousDto.BoardRateID, m_iOldStatus, m_BoardRatePreviousDto.Status);
                                m_BoardRateBus.Commit();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, strMsgSuccess);
                                this.Close();
                            }
                            else
                            {
                                m_BoardRateBus.RollBack();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, strMsgFail);
                            }
                        }
                        #endregion
                        break;

                    case clsMDCommonValue.BoardRateStatus.WaitingforApprove:
                        #region Process for Status = WaitingforApprove

                        GetActionMessageByStatus(ref iNewStatus, ref strMessageConfirm, ref strMsgSuccess, ref strMsgFail);
                        m_BoardRatePreviousDto.Status = iNewStatus;

                        dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, strMessageConfirm);
                        if (dialog == DialogResult.Yes)
                        {
                            m_BoardRateBus = new clsMDBoardRaterBUS();
                            m_BoardRatePreviousDto.Remark = (int)cbbAction.SelectedValue == (int)clsMDCommonValue.BoardRateAction.Return ? txtRemark.Text.Trim()
                                : m_BoardRatePreviousDto.Remark;
                            m_BoardRatePreviousDto.IsActive = (int)cbbAction.SelectedValue == (int)clsMDCommonValue.BoardRateAction.Approve ? true
                                : m_BoardRatePreviousDto.IsActive;

                            int row = m_BoardRateBus.UpdateBoardRate(m_BoardRatePreviousDto);
                            if (row > 0)
                            {
                                WriteLogUpdateStatus(m_BoardRatePreviousDto.BoardRateID, m_iOldStatus, m_BoardRatePreviousDto.Status);
                                m_BoardRateBus.Commit();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, strMsgSuccess);
                                this.Close();
                            }
                            else
                            {
                                m_BoardRateBus.RollBack();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, strMsgFail);
                            }
                        }
                        #endregion
                        break;

                    case clsMDCommonValue.BoardRateStatus.Approved:
                        #region Process for Status = Approved

                        GetActionMessageByStatus(ref iNewStatus, ref strMessageConfirm, ref strMsgSuccess, ref strMsgFail);
                        m_BoardRatePreviousDto.Status = iNewStatus;

                        dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, strMessageConfirm);
                        if (dialog == DialogResult.Yes)
                        {
                            m_BoardRateBus = new clsMDBoardRaterBUS();

                            if (m_IsCallMaker)
                            {
                                if (m_BoardRateExcelDto == null)
                                {
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                        clsMDMessage.WARNING_NO_DATA_NO_CHANGED_IMPORT);
                                    return;
                                }

                                GetActionMessageByStatus(ref iNewStatus, ref strMessageConfirm, ref strMsgSuccess, ref strMsgFail);
                                m_BoardRateExcelDto.Status = iNewStatus;

                                dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                                                    strMessageConfirm);
                                if (dialog == DialogResult.Yes)
                                {
                                    m_BoardRateBus = new clsMDBoardRaterBUS();

                                    externalLog.LogDate = clsMDBus.Instance().GetServerDateTime();
                                    int row = m_BoardRateBus.InsertBoardRate(m_BoardRateExcelDto, externalLog);
                                    if (row > 0)
                                    {
                                        m_BoardRateBus.Commit();
                                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, strMsgSuccess);
                                        this.Close();
                                    }
                                    else
                                    {
                                        m_BoardRateBus.RollBack();
                                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, strMsgFail);
                                    }
                                }
                            }
                            else
                            {
                                m_BoardRatePreviousDto.Remark = (int)cbbAction.SelectedValue == (int)clsMDCommonValue.BoardRateAction.Revise ? txtRemark.Text.Trim()
                                : m_BoardRatePreviousDto.Remark;
                                m_BoardRatePreviousDto.IsActive = false;

                                int row = m_BoardRateBus.UpdateBoardRate(m_BoardRatePreviousDto);
                                if (row > 0)
                                {
                                    WriteLogUpdateStatus(m_BoardRatePreviousDto.BoardRateID, m_iOldStatus, m_BoardRatePreviousDto.Status);
                                    m_BoardRateBus.Commit();
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, strMsgSuccess);
                                    this.Close();
                                }
                                else
                                {
                                    m_BoardRateBus.RollBack();
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, strMsgFail);
                                }
                            }
                        }

                        #endregion
                        break;

                    case clsMDCommonValue.BoardRateStatus.Withdrawed:
                        #region Process for Status = Withdrawed
                        if (m_BoardRateExcelDto == null)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                clsMDMessage.WARNING_NO_DATA_NO_CHANGED_IMPORT);
                            return;
                        }

                        GetActionMessageByStatus(ref iNewStatus, ref strMessageConfirm, ref strMsgSuccess, ref strMsgFail);
                        m_BoardRateExcelDto.Status = iNewStatus;

                        dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                                            strMessageConfirm);
                        if (dialog == DialogResult.Yes)
                        {
                            m_BoardRateBus = new clsMDBoardRaterBUS();

                            externalLog.LogDate = clsMDBus.Instance().GetServerDateTime();
                            int row = m_BoardRateBus.InsertBoardRate(m_BoardRateExcelDto, externalLog);
                            if (row > 0)
                            {
                                m_BoardRateBus.Commit();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, strMsgSuccess);
                                this.Close();
                            }
                            else
                            {
                                m_BoardRateBus.RollBack();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, strMsgFail);
                            }
                        }
                        #endregion
                        break;

                    case clsMDCommonValue.BoardRateStatus.Returned:
                        #region Process for Status = Returned
                        if (m_BoardRateExcelDto == null)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                clsMDMessage.WARNING_NO_DATA_NO_CHANGED_IMPORT);
                            return;
                        }

                        GetActionMessageByStatus(ref iNewStatus, ref strMessageConfirm, ref strMsgSuccess, ref strMsgFail);
                        m_BoardRateExcelDto.Status = iNewStatus;

                        dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                                            strMessageConfirm);
                        if (dialog == DialogResult.Yes)
                        {
                            m_BoardRateBus = new clsMDBoardRaterBUS();

                            externalLog.LogDate = clsMDBus.Instance().GetServerDateTime();
                            int row = m_BoardRateBus.InsertBoardRate(m_BoardRateExcelDto, externalLog);
                            if (row > 0)
                            {
                                m_BoardRateBus.Commit();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, strMsgSuccess);
                                this.Close();
                            }
                            else
                            {
                                m_BoardRateBus.RollBack();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, strMsgFail);
                            }
                        }
                        #endregion
                        break;

                    case clsMDCommonValue.BoardRateStatus.Suspended:
                        #region Process for Status = Suspended
                        if (m_BoardRateExcelDto == null)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                clsMDMessage.WARNING_NO_DATA_NO_CHANGED_IMPORT);
                            return;
                        }

                        GetActionMessageByStatus(ref iNewStatus, ref strMessageConfirm, ref strMsgSuccess, ref strMsgFail);
                        m_BoardRateExcelDto.Status = iNewStatus;

                        dialog = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                                            strMessageConfirm);
                        if (dialog == DialogResult.Yes)
                        {
                            m_BoardRateBus = new clsMDBoardRaterBUS();

                            externalLog.LogDate = clsMDBus.Instance().GetServerDateTime();
                            int row = m_BoardRateBus.InsertBoardRate(m_BoardRateExcelDto, externalLog);
                            if (row > 0)
                            {
                                m_BoardRatePreviousDto.Status = (int)clsMDCommonValue.BoardRateStatus.Obsolete;
                                row = m_BoardRateBus.UpdateBoardRate(m_BoardRatePreviousDto);
                                if (row > 0)
                                {
                                    WriteLogUpdateStatus(m_BoardRatePreviousDto.BoardRateID, m_iOldStatus, m_BoardRatePreviousDto.Status);
                                    m_BoardRateBus.Commit();
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, strMsgSuccess);
                                    this.Close();
                                }
                                else
                                {
                                    m_BoardRateBus.RollBack();
                                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, strMsgFail);
                                }

                            }
                            else
                            {
                                m_BoardRateBus.RollBack();
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, strMsgFail);
                            }
                        }
                        #endregion
                        break;

                    case clsMDCommonValue.BoardRateStatus.Obsolete:

                        break;

                    case clsMDCommonValue.BoardRateStatus.Freeze:

                        break;
                }

            }
            catch (Exception ex)
            {
                try
                {
                    //rollback data
                    m_BoardRateBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                Close();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Get Action message by status board rate
        /// </summary>
        /// <param name="status"></param>
        /// <param name="strMessageConfirm"></param>
        /// <param name="strMsgSuccess"></param>
        /// <param name="strMsgFail"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetActionMessageByStatus(ref int status, ref string strMessageConfirm, ref string strMsgSuccess, ref string strMsgFail)
        {
            switch ((int)cbbAction.SelectedValue)
            {
                case (int)clsMDCommonValue.BoardRateAction.Save:
                    status = (int)clsMDCommonValue.BoardRateStatus.New;
                    strMessageConfirm = clsMDMessage.ARE_YOU_SURE_TO_SAVE_DATA;
                    strMsgSuccess = clsMDMessage.DATA_WAS_SAVED_SUCCESSFULLY;
                    strMsgFail = clsMDMessage.DATA_WAS_SAVED_UN_SUCCESSFULLY;
                    break;

                case (int)clsMDCommonValue.BoardRateAction.SendForApproval:
                    status = (int)clsMDCommonValue.BoardRateStatus.WaitingforApprove;
                    strMessageConfirm = clsMDMessage.ARE_YOU_SURE_TO_REQUEST_FOR_APPROVAL;
                    strMsgSuccess = clsMDMessage.REQUEST_WAS_SENT_SUCCESSFULLY;
                    strMsgFail = clsMDMessage.REQUEST_WAS_SENT_UN_SUCCESSFULLY;
                    break;

                case (int)clsMDCommonValue.BoardRateAction.Preview:
                    //status = (int)clsMDCommonValue.BoardRateStatus.New;
                    //strMessageConfirm = clsMDMessage.ARE_YOU_SURE_TO_SAVE_DATA;
                    //strMsgSuccess = clsMDMessage.DATA_WAS_SAVED_SUCCESSFULLY;
                    //strMsgFail = clsMDMessage.DATA_WAS_SAVED_UN_SUCCESSFULLY;
                    break;

                case (int)clsMDCommonValue.BoardRateAction.Withdraw:
                    status = (int)clsMDCommonValue.BoardRateStatus.Withdrawed;
                    strMessageConfirm = clsMDMessage.ARE_YOU_SURE_TO_WITHDRAW_DATA;
                    strMsgSuccess = clsMDMessage.DATA_BR_WAS_WITHDRAWED_SUCCESSFULLY;
                    strMsgFail = clsMDMessage.DATA_BR_WAS_WITHDRAWED_UN_SUCCESSFULLY;
                    break;

                case (int)clsMDCommonValue.BoardRateAction.Approve:
                    status = (int)clsMDCommonValue.BoardRateStatus.Approved;
                    strMessageConfirm = clsMDMessage.ARE_YOU_SURE_TO_APPROVE_BOARD_RATE;
                    strMsgSuccess = clsMDMessage.DATA_BR_WAS_APPROVED_SUCCESSFULLY;
                    strMsgFail = clsMDMessage.DATA_WAS_APPROVED_UN_SUCCESSFULLY;
                    break;

                case (int)clsMDCommonValue.BoardRateAction.Return:
                    status = (int)clsMDCommonValue.BoardRateStatus.Returned;
                    strMessageConfirm = clsMDMessage.ARE_YOU_SURE_TO_RETURN_BOARD_RATE;
                    strMsgSuccess = clsMDMessage.DATA_BR_WAS_RETURNED_SUCCESSFULLY;
                    strMsgFail = clsMDMessage.DATA_BR_WAS_RETURNED_UN_SUCCESSFULLY;
                    break;

                case (int)clsMDCommonValue.BoardRateAction.Revise:
                    status = (int)clsMDCommonValue.BoardRateStatus.Suspended;
                    strMessageConfirm = clsMDMessage.ARE_YOU_SURE_TO_REVISE_BOARD_RATE;
                    strMsgSuccess = clsMDMessage.DATA_BR_WAS_REVISED_SUCCESSFULLY;
                    strMsgFail = clsMDMessage.DATA_BR_WAS_REVISED_UN_SUCCESSFULLY;
                    break;

                case (int)clsMDCommonValue.BoardRateAction.Freeze:
                    //status = (int)clsMDCommonValue.BoardRateStatus.Freeze;
                    strMessageConfirm = clsMDMessage.ARE_YOU_SURE_TO_FREEZE_BOARD_RATE;
                    strMsgSuccess = clsMDMessage.DATA_BR_WAS_FREEZED_SUCCESSFULLY;
                    strMsgFail = clsMDMessage.DATA_BR_WAS_FREEZED_UN_SUCCESSFULLY;
                    break;
            }
        }

        #endregion

        #region Member Method

        /// <summary>
        /// Initialize Board Rate when form loading.
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        private void InitializeBoardRate()
        {
            switch (m_BoardRateStatus)
            {
                case clsMDCommonValue.BoardRateStatus.Blank:
                    this.Text = clsMDConstant.BOARD_RATE_TITLE_NEW;
                    txtDirectory.Enabled = true;
                    btnBrowse.Enabled = true;
                    btnImport.Enabled = true;
                    break;

                case clsMDCommonValue.BoardRateStatus.New:
                    this.Text = clsMDConstant.BOARD_RATE_TITLE_NEW;
                    //Init control on form
                    txtDirectory.Enabled = false;
                    btnBrowse.Enabled = false;
                    btnImport.Enabled = false;

                    //get Previous board rate
                    m_BoardRatePreviousDto = clsMDBoardRaterBUS.Instance().GetBoardRateAndBoadRateDetail(m_BoardRateID);
                    m_iOldStatus = m_BoardRatePreviousDto.Status;

                    if (m_BoardRatePreviousDto != null)
                    {
                        DrawGridBoardRate(m_BoardRatePreviousDto);
                    }
                    break;

                case clsMDCommonValue.BoardRateStatus.WaitingforApprove:
                    this.Text = clsMDConstant.BOARD_RATE_TITLE_WAITFORAPPROVE;
                    //Init control on form
                    txtDirectory.Enabled = false;
                    btnBrowse.Enabled = false;
                    btnImport.Enabled = false;

                    //get Previous board rate
                    m_BoardRatePreviousDto = clsMDBoardRaterBUS.Instance().GetBoardRateAndBoadRateDetail(m_BoardRateID);
                    m_iOldStatus = m_BoardRatePreviousDto.Status;

                    if (m_BoardRatePreviousDto != null)
                    {
                        DrawGridBoardRate(m_BoardRatePreviousDto);
                    }

                    break;

                case clsMDCommonValue.BoardRateStatus.Approved:
                    this.Text = clsMDConstant.BOARD_RATE_TITLE_APPROVED;
                    if (m_IsCallMaker)
                    {
                        //Init control on form
                        txtDirectory.Enabled = true;
                        btnBrowse.Enabled = true;
                        btnImport.Enabled = true;
                    }
                    else
                    {
                        //Init control on form
                        txtDirectory.Enabled = false;
                        btnBrowse.Enabled = false;
                        btnImport.Enabled = false;
                    }

                    //get Previous board rate
                    m_BoardRatePreviousDto = clsMDBoardRaterBUS.Instance().GetBoardRateAndBoadRateDetail(m_BoardRateID);

                    m_iOldStatus = m_BoardRatePreviousDto.Status;

                    if (m_BoardRatePreviousDto != null)
                    {
                        DrawGridBoardRate(m_BoardRatePreviousDto);
                    }
                    break;

                case clsMDCommonValue.BoardRateStatus.Withdrawed:
                    this.Text = clsMDConstant.BOARD_RATE_TITLE_WITHDRAW;
                    //Init control on form
                    txtDirectory.Enabled = true;
                    btnBrowse.Enabled = true;
                    btnImport.Enabled = true;

                    //get Previous board rate
                    m_BoardRatePreviousDto = clsMDBoardRaterBUS.Instance().GetBoardRateAndBoadRateDetail(m_BoardRateID);

                    m_iOldStatus = m_BoardRatePreviousDto.Status;

                    if (m_BoardRatePreviousDto != null)
                    {
                        DrawGridBoardRate(m_BoardRatePreviousDto);
                    }
                    break;

                case clsMDCommonValue.BoardRateStatus.Returned:
                    this.Text = clsMDConstant.BOARD_RATE_TITLE_RETURN;
                    //Init control on form
                    txtDirectory.Enabled = true;
                    btnBrowse.Enabled = true;
                    btnImport.Enabled = true;

                    //get Previous board rate
                    m_BoardRatePreviousDto = clsMDBoardRaterBUS.Instance().GetBoardRateAndBoadRateDetail(m_BoardRateID);

                    m_iOldStatus = m_BoardRatePreviousDto.Status;
                    txtRemark.Text = m_BoardRatePreviousDto.Remark;

                    if (m_BoardRatePreviousDto != null)
                    {
                        DrawGridBoardRate(m_BoardRatePreviousDto);
                    }

                    lblRemark.Visible = true;
                    txtRemark.Visible = true;
                    txtRemark.Enabled = false;
                    break;

                case clsMDCommonValue.BoardRateStatus.Suspended:
                    this.Text = clsMDConstant.BOARD_RATE_TITLE_SUSPEND;
                    //Init control on form
                    txtDirectory.Enabled = true;
                    btnBrowse.Enabled = true;
                    btnImport.Enabled = true;

                    //get Previous board rate
                    m_BoardRatePreviousDto = clsMDBoardRaterBUS.Instance().GetBoardRateAndBoadRateDetail(m_BoardRateID);
                    m_iOldStatus = m_BoardRatePreviousDto.Status;
                    txtRemark.Text = m_BoardRatePreviousDto.Remark;

                    if (m_BoardRatePreviousDto != null)
                    {
                        DrawGridBoardRate(m_BoardRatePreviousDto);
                    }

                    lblRemark.Visible = true;
                    txtRemark.Visible = true;
                    txtRemark.Enabled = false;
                    break;

                case clsMDCommonValue.BoardRateStatus.Obsolete:

                    break;
                case clsMDCommonValue.BoardRateStatus.Freeze:
                    this.Text = clsMDConstant.BOARD_RATE_TITLE_FREEZE;
                    break;

                default:
                    break;
            }
        }

        /// <summary>
        /// System full fill action
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        private void SystemFullFillAction()
        {
            List<CbbObject> lst = new List<CbbObject>();

            switch (m_BoardRateStatus)
            {
                case clsMDCommonValue.BoardRateStatus.Blank:
                    lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Save, clsMDConstant.BOARD_RATE_ACTION_Save));
                    lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.SendForApproval, clsMDConstant.BOARD_RATE_ACTION_SendForApproval));
                    break;

                case clsMDCommonValue.BoardRateStatus.New:
                    lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.SendForApproval, clsMDConstant.BOARD_RATE_ACTION_SendForApproval));
                    break;

                case clsMDCommonValue.BoardRateStatus.WaitingforApprove:
                    if (m_IsCallMaker)
                    {
                        lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Withdraw, clsMDConstant.BOARD_RATE_ACTION_Withdraw));
                    }
                    else
                    {
                        lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Approve, clsMDConstant.BOARD_RATE_ACTION_Approve));
                        lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Return, clsMDConstant.BOARD_RATE_ACTION_Return));
                    }

                    break;

                case clsMDCommonValue.BoardRateStatus.Approved:
                    if (m_IsCallMaker)
                    {
                        lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Save, clsMDConstant.BOARD_RATE_ACTION_Save));
                        lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.SendForApproval, clsMDConstant.BOARD_RATE_ACTION_SendForApproval));
                    }
                    else
                    {
                        lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Revise, clsMDConstant.BOARD_RATE_ACTION_Revise));
                        lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Freeze, clsMDConstant.BOARD_RATE_ACTION_Freeze));
                    }

                    break;

                case clsMDCommonValue.BoardRateStatus.Withdrawed:
                    lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Save, clsMDConstant.BOARD_RATE_ACTION_Save));
                    lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.SendForApproval, clsMDConstant.BOARD_RATE_ACTION_SendForApproval));
                    break;

                case clsMDCommonValue.BoardRateStatus.Returned:
                    lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Save, clsMDConstant.BOARD_RATE_ACTION_Save));
                    lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.SendForApproval, clsMDConstant.BOARD_RATE_ACTION_SendForApproval));
                    break;

                case clsMDCommonValue.BoardRateStatus.Suspended:
                    lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.Save, clsMDConstant.BOARD_RATE_ACTION_Save));
                    lst.Add(new CbbObject((int)clsMDCommonValue.BoardRateAction.SendForApproval, clsMDConstant.BOARD_RATE_ACTION_SendForApproval));
                    break;

                case clsMDCommonValue.BoardRateStatus.Obsolete:

                    break;
                case clsMDCommonValue.BoardRateStatus.Freeze:

                    break;

                default:
                    break;

            }
            cbbAction.DataSource = lst;
            cbbAction.DisplayMember = clsMDConstant.DISPLAY;
            cbbAction.ValueMember = clsMDConstant.VALUE;
            //cbbAction.SelectedIndex = 0;
        }

        /// <summary>
        /// Load data for Combobox Currency
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co        
        /// @endcond
        private void FillDataComboboxCCY()
        {
            if (m_dtCurrencyMaster == null) return;
            DataRow row = m_dtCurrencyMaster.NewRow();
            row[0] = String.Empty;
            m_dtCurrencyMaster.Rows.InsertAt(row, 0);
            cbbCCY.DataSource = m_dtCurrencyMaster;
            cbbCCY.ValueMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.DisplayMember = clsMDConstant.MD_COL_CCYCODE;
            cbbCCY.SelectedIndex = 0;
        }

        /// <summary>
        /// Check FilePath is valid
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsValidFileImport()
        {
            string strFilePath = txtDirectory.Text.ToString().Trim();
            if (string.IsNullOrEmpty(strFilePath))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a file", "import"));
                btnBrowse.Focus();
                return false;
            }
            FileInfo fileInfo = new FileInfo(strFilePath);
            //Check type file is .txt
            if (fileInfo.Extension != ".xls")
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.WARNING_ACTION_FILE_TYPE_INVALID);
                btnBrowse.Focus();
                return false;
            }
            //Check file exist
            if (!fileInfo.Exists)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsMDMessage.WARNING_ACTION_FILE_IMPORT_NOT_FOUND);
                btnBrowse.Focus();
                return false;
            }
            externalLog = new Phoenix.Common.Log.Dto.clsCOMExternalTransactionLogDTO();
            externalLog.Module = clsMDConstant.MODULE_MD;
            externalLog.UserNo = clsUserInfo.UserNo;
            //externalLog.LogDate = DateTime.Now;
            externalLog.FileName = fileInfo.Name;
            externalLog.FilePath = fileInfo.DirectoryName;
            externalLog.FileType = CommonValue.FileType.Excel.ToString();

            return true;
        }

        /// <summary>
        /// Get data Board Rate from file import excel
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool GetDataBoardRateFromExcelFile(out clsMDBoardRateDTO dto)
        {
            int numSheets = 0;
            string strSheetName = string.Empty;
            object[,] data;
            //Read data from excel
            string strFilePath = this.txtDirectory.Text.Trim();

            dto = new clsMDBoardRateDTO();

            clsExcelBase excelBase = new clsExcelBase(strFilePath);
            try
            {
                m_IsNotError = true;

                //Read all number sheet in excel file            
                numSheets = excelBase.Worksheets.Count;
                //get work sheet
                excelBase.Worksheet = (Excel.Worksheet)excelBase.Worksheets[1];
                //get Sheet Name
                strSheetName = excelBase.Worksheet.Name.Trim();
                //get data to check import date
                data = (object[,])excelBase.GetRange(m_CellCommonStart, m_CellCommonEnd).get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);
                //check import date
                m_IsNotError = GetBoardRateDtoFromExcelFile(data, dto, strSheetName);

                if (m_IsNotError)
                {
                    for (int sheetNum = 2; sheetNum < numSheets + 1; sheetNum++)
                    {
                        //get work sheet
                        excelBase.Worksheet = (Excel.Worksheet)excelBase.Worksheets[sheetNum];
                        //get Sheet Name
                        strSheetName = excelBase.Worksheet.Name.Trim();
                        //string valueCell = string.Empty;
                        if (m_IsNotError)
                        {
                            DataRow[] CCY = m_dtCurrencyMaster.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_CCYCODE, strSheetName));
                            if (CCY.Length > 0)
                            {
                                data = (object[,])excelBase.GetRange(m_CellStart, m_CellEnd).get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);

                                if (!GetBoardRateDetailDtoFromExcelFile(dto, data, strSheetName))
                                {
                                    m_IsNotError = false;
                                }
                            }
                            else
                            {
                                //not existed CCY, show message box error and stop process
                                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                    String.Format(clsMDMessage.ERR_NOT_EXISTED_CCY, strSheetName));
                                m_IsNotError = false;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsExcelBase.KillProcessExcel(excelBase.App);
                excelBase = null;
                throw new System.ArgumentException(ex.Message);
            }
            finally
            {
                if (excelBase != null)
                {
                    clsExcelBase.KillProcessExcel(excelBase.App);
                }
            }
            return m_IsNotError;

        }

        /// <summary>
        /// Get Header Board Rate
        /// </summary>
        /// <param name="data"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool GetBoardRateDtoFromExcelFile(object[,] data, clsMDBoardRateDTO dto, String strSheetName)
        {
            DateTime serverDate = clsMDBus.Instance().GetServerDateTime().Date;
            //get data Board Rate header
            dto.Version = 1;
            dto.FileDirectory = txtDirectory.Text.Trim();

            if (clsMDFunction.isNullOrEmpty(data[1, 2]))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                    String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, "Cell[1,2] in sheet [" + strSheetName + "]"));
                return false;
            }

            dto.ImportTime = clsMDFunction.ConvertObjectToNullDateTime(data[1, 2], clsMDConstant.MD_FORMAT_DDMMMYY);
            if (dto.ImportTime == null)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                    String.Format(clsMDMessage.ERROR_IS_NOT_FORMAT, "Cell[1,2] in in sheet [" + strSheetName + "]"));
                return false;
            }
            else
            {
                if (!dto.ImportTime.Equals(serverDate))
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                    String.Format(clsMDMessage.ERROR_NOT_CURRENT_DATE, "Cell[1,2] in in sheet [" + strSheetName + "]"));
                    return false;
                }
            }
            dto.EffectiveTime = clsMDFunction.ConvertObjectToString(data[2, 2]);

            dto.ImportantNote = txtNotes.Text.TrimEnd();
            dto.ApprovedBy = -1;
            dto.CreatedBy = clsUserInfo.UserNo;

            return true;
        }

        /// <summary>
        /// Get Board Rate Detail
        /// </summary>
        /// <param name="data"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool GetBoardRateDetailDtoFromExcelFile(clsMDBoardRateDTO dto, object[,] data, string CCY)
        {
            DateTime? matutiryDate = null;
            //bool isCheckSuccess = true;
            m_lstCurrencyHoliday = clsMDBoardRaterBUS.Instance().GetCurrencyHolidayByCCY(CCY);

            //get list CCY
            dto.CCYList.Add(String.Format(clsMDConstant.BOARD_RATE_CCY, CCY));
            dto.ThresholdList.Add(clsMDBus.Instance().GetThresholdByCCY(CCY));

            //init matrix highhtlight
            int[,] arrMatrixHightLight = new int[15, 13];

            //get detail Board Rate
            clsMDBoardRateDetailDTO brDetail = null;

            int iRow = 6;
            int iRowDay = 5;
            int CCYTermsIDStart = 1;
            //value date 
            DateTime? valueDate = null;
            //DateTime? maturityDate = null;
            string value = string.Empty;
            bool isProcess = true;

            //get Board Rate term of DEPOSIT from O.N to 1Y
            for (int i = 0; i <= 9; i++)
            {
                brDetail = new clsMDBoardRateDetailDTO();
                //get board rate Term = O.N
                brDetail.CCYTermsID = CCYTermsIDStart++;
                brDetail.CCY = CCY;
                //TransType = DEPOSIT
                brDetail.TransType = clsMDConstant.BOARD_RATE_TRANS_TYPE_DEPOSIT;

                #region Same Day

                //check value date it empty or not format

                if (!CheckValueDate(data[iRowDay, 3], out valueDate, iRowDay, 3, CCY))
                {
                    return false;
                }

                brDetail.SameDayValueDate = valueDate;

                if (!CheckValue(data[iRow, 3], out value, iRow, 3, CCY, out isProcess))
                {
                    return false;
                }

                brDetail.SameDay = value;

                if (!CheckMaturityDate(data[iRow, 2], out matutiryDate, iRow, 2, CCY))
                {
                    return false;
                }

                brDetail.SameDayMaturityDate = matutiryDate;

                if (brDetail.SameDayMaturityDate != null)
                {
                    matutiryDate = GetMaturityDateByDataValue(brDetail.SameDayValueDate.Value, brDetail.CCYTermsID);
                    if (brDetail.SameDayMaturityDate != matutiryDate)
                    {
                        arrMatrixHightLight[iRow - 1, 1] = 1;
                    }
                }

                #endregion

                #region Tom
                //check value date it empty or not format
                if (!CheckValueDate(data[iRowDay, 5], out valueDate, iRowDay, 5, CCY))
                {
                    return false;
                }

                brDetail.TomValueDate = valueDate;

                if (!CheckValue(data[iRow, 5], out value, iRow, 5, CCY, out isProcess))
                {
                    return false;
                }

                brDetail.Tom = value;

                if (!CheckMaturityDate(data[iRow, 4], out matutiryDate, iRow, 4, CCY))
                {
                    return false;
                }

                brDetail.TomMaturityDate = matutiryDate;

                if (brDetail.TomMaturityDate != null)
                {
                    matutiryDate = GetMaturityDateByDataValue(brDetail.TomValueDate.Value, brDetail.CCYTermsID);
                    if (brDetail.TomMaturityDate != matutiryDate)
                    {
                        arrMatrixHightLight[iRow - 1, 3] = 1;
                    }
                }

                #endregion

                #region Spot
                //check value date it empty or not format
                if (!CheckValueDate(data[iRowDay, 7], out valueDate, iRowDay, 7, CCY))
                {
                    return false;
                }

                brDetail.SpotValueDate = valueDate;

                if (!CheckValue(data[iRow, 7], out value, iRow, 7, CCY, out isProcess))
                {
                    return false;
                }

                brDetail.Spot = value;

                if (!CheckMaturityDate(data[iRow, 6], out matutiryDate, iRow, 6, CCY))
                {
                    return false;
                }

                brDetail.SpotMaturityDate = matutiryDate;

                if (brDetail.SpotMaturityDate != null)
                {
                    matutiryDate = GetMaturityDateByDataValue(brDetail.SpotValueDate.Value, brDetail.CCYTermsID);
                    if (brDetail.SpotMaturityDate != matutiryDate)
                    {
                        arrMatrixHightLight[iRow - 1, 5] = 1;
                    }
                }

                #endregion

                brDetail.FormatNumber = String.Empty;
                dto.BoardRateDetails.Add(brDetail);
                iRow++;
            }

            iRow = 6;
            iRowDay = 5;
            CCYTermsIDStart = 1;
            //get Board Rate term of LOAN from O.N to 1Y
            for (int i = 0; i <= 9; i++)
            {
                brDetail = new clsMDBoardRateDetailDTO();
                //get board rate Term = O.N
                brDetail.CCYTermsID = CCYTermsIDStart++;
                brDetail.CCY = CCY;
                //TransType = LOAN
                brDetail.TransType = clsMDConstant.BOARD_RATE_TRANS_TYPE_LOAN;

                #region Same Day

                //check value date it empty or not format
                if (!CheckValueDate(data[iRowDay, 9], out valueDate, iRowDay, 9, CCY))
                {
                    return false;
                }

                brDetail.SameDayValueDate = valueDate;


                if (!CheckValue(data[iRow, 9], out value, iRow, 9, CCY, out isProcess))
                {
                    return false;
                }

                brDetail.SameDay = value;

                if (!CheckMaturityDate(data[iRow, 8], out matutiryDate, iRow, 8, CCY))
                {
                    return false;
                }

                brDetail.SameDayMaturityDate = matutiryDate;

                if (brDetail.SameDayMaturityDate != null)
                {
                    matutiryDate = GetMaturityDateByDataValue(brDetail.SameDayValueDate.Value, brDetail.CCYTermsID);
                    if (brDetail.SameDayMaturityDate != matutiryDate)
                    {
                        arrMatrixHightLight[iRow - 1, 7] = 1;
                    }
                }

                #endregion

                #region Tom
                //check value date it empty or not format
                if (!CheckValueDate(data[iRowDay, 11], out valueDate, iRowDay, 11, CCY))
                {
                    return false;
                }

                brDetail.TomValueDate = valueDate;


                if (!CheckValue(data[iRow, 11], out value, iRow, 11, CCY, out isProcess))
                {
                    return false;
                }

                brDetail.Tom = value;


                if (!CheckMaturityDate(data[iRow, 10], out matutiryDate, iRow, 10, CCY))
                {
                    return false;
                }

                brDetail.TomMaturityDate = matutiryDate;

                if (brDetail.TomMaturityDate != null)
                {
                    matutiryDate = GetMaturityDateByDataValue(brDetail.TomValueDate.Value, brDetail.CCYTermsID);
                    if (brDetail.TomMaturityDate != matutiryDate)
                    {
                        arrMatrixHightLight[iRow - 1, 9] = 1;
                    }
                }

                #endregion

                #region Spot
                //check value date it empty or not format
                if (!CheckValueDate(data[iRowDay, 13], out valueDate, iRowDay, 13, CCY))
                {
                    return false;
                }

                brDetail.SpotValueDate = valueDate;

                if (!CheckValue(data[iRow, 13], out value, iRow, 13, CCY, out isProcess))
                {
                    return false;
                }

                brDetail.Spot = value;

                if (!CheckMaturityDate(data[iRow, 12], out matutiryDate, iRow, 12, CCY))
                {
                    return false;
                }

                brDetail.SpotMaturityDate = matutiryDate;

                if (brDetail.SpotMaturityDate != null)
                {
                    matutiryDate = GetMaturityDateByDataValue(brDetail.SpotValueDate.Value, brDetail.CCYTermsID);
                    if (brDetail.SpotMaturityDate != matutiryDate)
                    {
                        arrMatrixHightLight[iRow - 1, 11] = 1;
                    }
                }
                #endregion

                brDetail.FormatNumber = String.Empty;
                dto.BoardRateDetails.Add(brDetail);
                iRow++;
            }
            //add matrix hight
            m_MatrixHLList.Add(arrMatrixHightLight);
            return true;
        }

        /// <summary>
        /// Check value date input from file excel
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="date"></param>
        /// <param name="iRow"></param>
        /// <param name="iCol"></param>
        /// <param name="CCY"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool CheckValueDate(object obj, out DateTime? date, int iRow, int iCol, string CCY)
        {
            date = null;
            //check value data is null or empty
            if (clsMDFunction.isNullOrEmpty(obj))
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                String.Format(clsMDMessage.ERROR_FIELD_REQUIRED, "Cell[" + iRow + "," + iCol + "] in sheet [" + CCY + "]"));
                return false;
            }

            date = clsMDFunction.ConvertObjectToNullDateTime(obj, clsMDConstant.MD_FORMAT_DDMMMYY);
            //check value date is not in expected format
            if (date == null)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                String.Format(clsMDMessage.ERROR_IS_NOT_FORMAT, "Cell[" + iRow + "," + iCol + "] in sheet [" + CCY + "]"));
                return false;
            }
            return true;
        }

        /// <summary>
        /// Check value input from file excel
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="date"></param>
        /// <param name="iRow"></param>
        /// <param name="iCol"></param>
        /// <param name="CCY"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool CheckValue(object obj, out string value, int iRow, int iCol, string CCY, out bool isProcess)
        {
            isProcess = true;

            value = null;
            //check value is null or empty or N/A
            if (clsMDFunction.isNullOrEmpty(obj) || clsMDFunction.ConvertObjectToString(obj).Equals(clsMDConstant.BOARD_RATE_NA_VALUE))
            {
                isProcess = false;
                value = clsMDFunction.ConvertObjectToString(obj);
                return true;
            }

            Decimal? dValue = clsMDFunction.ConvertObjectToNullDecimal(obj);
            //check value is invalid
            if (dValue == null)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                String.Format(clsMDMessage.ERROR_IS_INVALID_DATA, "Cell[" + iRow + "," + iCol + "] in sheet [" + CCY + "]"));
                isProcess = false;
                return false;
            }

            value = dValue.Value.ToString();

            return true;
        }

        /// <summary>
        /// Check maturity date input from file excel
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="date"></param>
        /// <param name="iRow"></param>
        /// <param name="iCol"></param>
        /// <param name="CCY"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool CheckMaturityDate(object obj, out DateTime? date, int iRow, int iCol, string CCY)
        {
            date = null;
            //check value is null or empty or N/A
            if (clsMDFunction.isNullOrEmpty(obj) || clsMDFunction.ConvertObjectToString(obj).Equals(clsMDConstant.BOARD_RATE_NA_VALUE))
            {
                return true;
            }

            date = clsMDFunction.ConvertObjectToNullDateTime(obj, clsMDConstant.MD_FORMAT_DDMMMYY);
            //check value date is not in expected format
            if (date == null)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                String.Format(clsMDMessage.ERROR_IS_NOT_FORMAT, "Cell[" + iRow + "," + iCol + "] in sheet [" + CCY + "]"));
                return false;
            }
            return true;
        }

        /// <summary>
        /// Get Maturity Date by value date
        /// </summary>
        /// <param name="rateValue"></param>
        /// <param name="dateValue"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private DateTime GetMaturityDateByDataValue(DateTime valueDate, int typeTerm)
        {
            DateTime maturityDate = new DateTime();
            switch (typeTerm)
            {
                /*
                 * - Term O.N & T.N: if [Value date] is Friday, [Maturity date] will be next Monday. 
                 * If this Monday is holiday, [Maturity date] will be added 1 day and so on.                 
                 * - Term 1W: [Maturity date] = [Value date] + 7. 
                 * If it falls on holiday, [Maturity date] will be moved to next business day.
                 * - Term 2W: [Maturity date] = [Value date] + 14. 
                 * If it falls on holiday, [Maturity date] will be moved to next business day.
                 * - Term 1M, 2M, 3M, ... 1Y: let say [Value date] = Day1/Month1/Year1 and [Maturity date] = Day2/Month2/Year2.
                 * + Rule1: Day2 = Day1, Month2=Month1+1 (if Term 1M) (or +2 if Term 2M,...)
                 * + Rule2: if Day2 falls on Holiday, Saturday, Sunday, it will be moved to next business day.
                 * + Rule3: If Day2 (after rule2 adjustment) falls in the next calendar month, [Maturity date] will be backward to the immediately preceding business day of the day after applying Rule1.
                 * */
                case (int)clsMDCommonValue.TermType.TERM_ON:
                    maturityDate = valueDate.AddDays(1);
                    break;
                case (int)clsMDCommonValue.TermType.TERM_TN:
                    maturityDate = valueDate.AddDays(1);
                    break;
                case (int)clsMDCommonValue.TermType.TERM_1WK:
                    maturityDate = valueDate.AddDays(7);
                    break;
                case (int)clsMDCommonValue.TermType.TERM_2WK:
                    maturityDate = valueDate.AddDays(14);
                    break;
                case (int)clsMDCommonValue.TermType.TERM_1MO:
                    maturityDate = valueDate.AddMonths(1);
                    break;
                case (int)clsMDCommonValue.TermType.TERM_2MS:
                    maturityDate = valueDate.AddMonths(2);
                    break;
                case (int)clsMDCommonValue.TermType.TERM_3MS:
                    maturityDate = valueDate.AddMonths(3);
                    break;
                case (int)clsMDCommonValue.TermType.TERM_6MS:
                    maturityDate = valueDate.AddMonths(6);
                    break;
                case (int)clsMDCommonValue.TermType.TERM_9MS:
                    maturityDate = valueDate.AddMonths(9);
                    break;
                case (int)clsMDCommonValue.TermType.TERM_1Y:
                    maturityDate = valueDate.AddYears(1);
                    break;
                default:
                    break;
            }

            //TO-DO?
            //if (maturityDate.DayOfWeek == DayOfWeek.Saturday)
            //{
            //    maturityDate = maturityDate.AddDays(1);
            //}
            //if (maturityDate.DayOfWeek == DayOfWeek.Sunday)
            //{
            //    maturityDate = maturityDate.AddDays(1);
            //}

            clsMDCurrencyHolidayDTO cur = m_lstCurrencyHoliday.Find(t => t.HolidayDate == maturityDate);
            if (cur != null)
            {
                int month = cur.HolidayDate.Month;
                while (cur != null)
                {
                    maturityDate = maturityDate.AddDays(1);
                    cur = m_lstCurrencyHoliday.Find(t => t.HolidayDate == maturityDate);
                }
                if (typeTerm == (int)clsMDCommonValue.TermType.TERM_1MO
                    || typeTerm == (int)clsMDCommonValue.TermType.TERM_2MS
                    || typeTerm == (int)clsMDCommonValue.TermType.TERM_3MS
                    || typeTerm == (int)clsMDCommonValue.TermType.TERM_6MS
                    || typeTerm == (int)clsMDCommonValue.TermType.TERM_9MS
                    || typeTerm == (int)clsMDCommonValue.TermType.TERM_1Y)
                {
                    if (maturityDate.Month > month)
                    {
                        maturityDate = new DateTime(maturityDate.Year, maturityDate.Month - 1, valueDate.Day - 1);
                        while (cur != null)
                        {
                            maturityDate = maturityDate.AddDays(-1);
                            cur = m_lstCurrencyHoliday.Find(t => t.HolidayDate == maturityDate);
                        }
                    }
                }
            }

            return maturityDate;
        }

        /// <summary>
        /// Draw Grid Board Rate datagrid
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void DrawGridBoardRate(clsMDBoardRateDTO dto)
        {
            //get Board Rate Header for grid
            DrawBoardRateHeaderGrid(dto);
            DrawGridBoardRateDetail(dto);
        }

        /// <summary>
        /// Draw Grid Board Rate datagrid and hight light with previous Board Rate
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void DrawGridBoardRate(clsMDBoardRateDTO dto, clsMDBoardRateDTO preDto)
        {
            //get Board Rate Header for grid
            DrawBoardRateHeaderGrid(dto);
            DrawGridBoardRateDetail(dto, preDto);
        }

        /// <summary>
        /// Draw grid board rate detail
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void DrawGridBoardRateDetail(clsMDBoardRateDTO dto)
        {
            int iBR = 0;
            int countTerm = 10;
            for (int j = 0; j < countTerm; j++)
            {
                object[] values = new object[12 * dto.CCYList.Count + 1];
                iBR = j;
                values[0] = m_dtCCYTerm.Rows[j][colTermName];
                for (int k = 0; k < dto.CCYList.Count; k++)
                {
                    int iValue = k * 12;
                    values[1 + iValue] = dto.BoardRateDetails[iBR].SameDay == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].SameDayMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].SameDayMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    values[2 + iValue] = dto.BoardRateDetails[iBR].SameDay;

                    values[3 + iValue] = dto.BoardRateDetails[iBR].Tom == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].TomMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].TomMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    values[4 + iValue] = dto.BoardRateDetails[iBR].Tom;

                    values[5 + iValue] = dto.BoardRateDetails[iBR].Spot == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].SpotMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].SpotMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    values[6 + iValue] = dto.BoardRateDetails[iBR].Spot;

                    iBR = iBR + countTerm;

                    values[7 + iValue] = dto.BoardRateDetails[iBR].SameDay == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].SameDayMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].SameDayMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    values[8 + iValue] = dto.BoardRateDetails[iBR].SameDay;

                    values[9 + iValue] = dto.BoardRateDetails[iBR].Tom == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].TomMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].TomMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    values[10 + iValue] = dto.BoardRateDetails[iBR].Tom;

                    values[11 + iValue] = dto.BoardRateDetails[iBR].Spot == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].SpotMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].SpotMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    values[12 + iValue] = dto.BoardRateDetails[iBR].Spot;

                    iBR = iBR + countTerm;
                }
                dtgDetail.Rows.Add(values);
            }
        }

        /// <summary>
        /// Draw grid board rate detail and hight light with previous board rate
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void DrawGridBoardRateDetail(clsMDBoardRateDTO dto, clsMDBoardRateDTO preDto)
        {
            int iBR = 0;
            int countTerm = 10;
            clsMDBoardRateDetailDTO brDetailDto = null;
            //init matrix highhtlight
            m_MatrixHightlight = new int[15, 1 + 12 * dto.CCYList.Count];

            for (int j = 0; j < countTerm; j++)
            {
                object[] values = new object[12 * dto.CCYList.Count + 1];
                iBR = j;
                values[0] = m_dtCCYTerm.Rows[j][colTermName];
                for (int k = 0; k < dto.CCYList.Count; k++)
                {
                    int iValue = k * 12;
                    values[1 + iValue] = dto.BoardRateDetails[iBR].SameDay == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].SameDayMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].SameDayMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                        && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                        && m.TransType == dto.BoardRateDetails[iBR].TransType
                        && m.SameDayMaturityDate.Equals(dto.BoardRateDetails[iBR].SameDayMaturityDate));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 1 + iValue] = 1;
                    }

                    values[2 + iValue] = dto.BoardRateDetails[iBR].SameDay;

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                        && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                        && m.TransType == dto.BoardRateDetails[iBR].TransType
                        && m.SameDay.Equals(dto.BoardRateDetails[iBR].SameDay));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 2 + iValue] = 1;
                    }

                    values[3 + iValue] = dto.BoardRateDetails[iBR].Tom == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].TomMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].TomMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                       && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                       && m.TransType == dto.BoardRateDetails[iBR].TransType
                       && m.TomMaturityDate.Equals(dto.BoardRateDetails[iBR].TomMaturityDate));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 3 + iValue] = 1;
                    }

                    values[4 + iValue] = dto.BoardRateDetails[iBR].Tom;

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                       && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                       && m.TransType == dto.BoardRateDetails[iBR].TransType
                       && m.Tom.Equals(dto.BoardRateDetails[iBR].Tom));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 4 + iValue] = 1;
                    }

                    values[5 + iValue] = dto.BoardRateDetails[iBR].Spot == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].SpotMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].SpotMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                      && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                      && m.TransType == dto.BoardRateDetails[iBR].TransType
                      && m.SpotMaturityDate.Equals(dto.BoardRateDetails[iBR].SpotMaturityDate));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 5 + iValue] = 1;
                    }

                    values[6 + iValue] = dto.BoardRateDetails[iBR].Spot;

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                      && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                      && m.TransType == dto.BoardRateDetails[iBR].TransType
                      && m.Spot.Equals(dto.BoardRateDetails[iBR].Spot));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 6 + iValue] = 1;
                    }

                    iBR = iBR + countTerm;

                    values[7 + iValue] = dto.BoardRateDetails[iBR].SameDay == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].SameDayMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].SameDayMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                      && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                      && m.TransType == dto.BoardRateDetails[iBR].TransType
                      && m.SameDayMaturityDate.Equals(dto.BoardRateDetails[iBR].SameDayMaturityDate));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 7 + iValue] = 1;
                    }

                    values[8 + iValue] = dto.BoardRateDetails[iBR].SameDay;

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                      && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                      && m.TransType == dto.BoardRateDetails[iBR].TransType
                      && m.SameDay.Equals(dto.BoardRateDetails[iBR].SameDay));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 8 + iValue] = 1;
                    }

                    values[9 + iValue] = dto.BoardRateDetails[iBR].Tom == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].TomMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].TomMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                      && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                      && m.TransType == dto.BoardRateDetails[iBR].TransType
                      && m.TomMaturityDate.Equals(dto.BoardRateDetails[iBR].TomMaturityDate));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 9 + iValue] = 1;
                    }

                    values[10 + iValue] = dto.BoardRateDetails[iBR].Tom;

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                     && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                     && m.TransType == dto.BoardRateDetails[iBR].TransType
                     && m.Tom.Equals(dto.BoardRateDetails[iBR].Tom));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 10 + iValue] = 1;
                    }

                    values[11 + iValue] = dto.BoardRateDetails[iBR].Spot == clsMDConstant.BOARD_RATE_NA_VALUE ? clsMDConstant.BOARD_RATE_NA_VALUE
                        : dto.BoardRateDetails[iBR].SpotMaturityDate == null ? String.Empty : dto.BoardRateDetails[iBR].SpotMaturityDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                     && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                     && m.TransType == dto.BoardRateDetails[iBR].TransType
                     && m.SpotMaturityDate.Equals(dto.BoardRateDetails[iBR].SpotMaturityDate));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 11 + iValue] = 1;
                    }

                    values[12 + iValue] = dto.BoardRateDetails[iBR].Spot;

                    brDetailDto = preDto.BoardRateDetails.FirstOrDefault(m => m.CCY.ToUpper().Equals(dto.BoardRateDetails[iBR].CCY.ToUpper())
                     && m.CCYTermsID == dto.BoardRateDetails[iBR].CCYTermsID
                     && m.TransType == dto.BoardRateDetails[iBR].TransType
                     && m.Spot.Equals(dto.BoardRateDetails[iBR].Spot));

                    if (brDetailDto == null)
                    {
                        m_MatrixHightlight[j + 5, 12 + iValue] = 1;
                    }

                    iBR = iBR + countTerm;
                }
                dtgDetail.Rows.Add(values);
            }
        }

        /// <summary>
        /// Draw Board Rate Header Grid
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void DrawBoardRateHeaderGrid(clsMDBoardRateDTO dto)
        {
            dtgDetail.Rows.Clear();
            dtgDetail.Columns.Clear();

            DataGridViewTextBoxColumn colTerm = new DataGridViewTextBoxColumn();
            colTerm.HeaderText = clsMDConstant.BOARD_RATE_TENORS;
            colTerm.Frozen = true;
            colTerm.Width = 55;
            dtgDetail.Columns.Add(colTerm);
            dtgDetail.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            int iIndexCCY = 0;
            for (int i = 0; i < dto.CCYList.Count; i++)
            {
                string CCY = dto.CCYList[i];
                string supCCY = dto.ThresholdList[i];
                DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
                col1.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_DEPOSIT + clsMDConstant._ + clsMDConstant.BOARD_RATE_SAME_DAY + clsMDConstant._ + clsMDConstant.BOARD_RATE_MATURITY_DATE;
                col1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                col1.Width = 74;
                col1.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col1);

                DataGridViewTextBoxColumn col2 = new DataGridViewTextBoxColumn();
                col2.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_DEPOSIT + clsMDConstant._ + clsMDConstant.BOARD_RATE_SAME_DAY + clsMDConstant._ +
                    dto.BoardRateDetails[iIndexCCY].SameDayValueDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);
                col2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                col2.Width = 74;
                col2.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col2);

                DataGridViewTextBoxColumn col3 = new DataGridViewTextBoxColumn();
                col3.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_DEPOSIT + clsMDConstant._ + clsMDConstant.BOARD_RATE_TOM + clsMDConstant._ + clsMDConstant.BOARD_RATE_MATURITY_DATE;
                col3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                col3.Width = 74;
                col3.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col3);

                DataGridViewTextBoxColumn col4 = new DataGridViewTextBoxColumn();
                col4.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_DEPOSIT + clsMDConstant._ + clsMDConstant.BOARD_RATE_TOM + clsMDConstant._ +
                    dto.BoardRateDetails[iIndexCCY].TomValueDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);
                col4.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                col4.Width = 74;
                col4.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col4);

                DataGridViewTextBoxColumn col5 = new DataGridViewTextBoxColumn();
                col5.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_DEPOSIT + clsMDConstant._ + clsMDConstant.BOARD_RATE_SPOT + clsMDConstant._ + clsMDConstant.BOARD_RATE_MATURITY_DATE;
                col5.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                col5.Width = 74;
                col5.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col5);

                DataGridViewTextBoxColumn col6 = new DataGridViewTextBoxColumn();
                col6.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_DEPOSIT + clsMDConstant._ + clsMDConstant.BOARD_RATE_SPOT + clsMDConstant._ +
                    dto.BoardRateDetails[iIndexCCY].SpotValueDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);
                col6.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                col6.Width = 74;
                col6.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col6);
                // CCY = VND Index Loan
                iIndexCCY += 10;

                DataGridViewTextBoxColumn col7 = new DataGridViewTextBoxColumn();
                col7.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_LOAN + clsMDConstant._ + clsMDConstant.BOARD_RATE_SAME_DAY + clsMDConstant._ + clsMDConstant.BOARD_RATE_MATURITY_DATE;
                col7.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                col7.Width = 74;
                col7.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col7);

                DataGridViewTextBoxColumn col8 = new DataGridViewTextBoxColumn();
                col8.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_LOAN + clsMDConstant._ + clsMDConstant.BOARD_RATE_SAME_DAY + clsMDConstant._ +
                    dto.BoardRateDetails[iIndexCCY].SameDayValueDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);
                col8.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                col8.Width = 74;
                col8.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col8);

                DataGridViewTextBoxColumn col9 = new DataGridViewTextBoxColumn();
                col9.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_LOAN + clsMDConstant._ + clsMDConstant.BOARD_RATE_TOM + clsMDConstant._ + clsMDConstant.BOARD_RATE_MATURITY_DATE;
                col9.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                col9.Width = 74;
                col9.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col9);

                DataGridViewTextBoxColumn col10 = new DataGridViewTextBoxColumn();
                col10.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_LOAN + clsMDConstant._ + clsMDConstant.BOARD_RATE_TOM + clsMDConstant._ +
                    dto.BoardRateDetails[iIndexCCY].TomValueDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);
                col10.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                col10.Width = 74;
                col10.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col10);

                DataGridViewTextBoxColumn col11 = new DataGridViewTextBoxColumn();
                col11.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_LOAN + clsMDConstant._ + clsMDConstant.BOARD_RATE_SPOT + clsMDConstant._ + clsMDConstant.BOARD_RATE_MATURITY_DATE;
                col11.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                col11.Width = 74;
                col11.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col11);

                DataGridViewTextBoxColumn col12 = new DataGridViewTextBoxColumn();
                col12.HeaderText = supCCY + clsMDConstant._ + CCY + clsMDConstant._ + clsMDConstant.BOARD_RATE_LOAN + clsMDConstant._ + clsMDConstant.BOARD_RATE_SPOT + clsMDConstant._ +
                    dto.BoardRateDetails[iIndexCCY].SpotValueDate.Value.ToString(clsMDConstant.MD_FORMAT_DDMMMYY);
                col12.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                col12.Width = 74;
                col12.SortMode = DataGridViewColumnSortMode.NotSortable;
                dtgDetail.Columns.Add(col12);
                // CCY = USD
                iIndexCCY += 10;
            }

            StackedHeaderDecorator objREnderer = new StackedHeaderDecorator(dtgDetail);
        }

        /// <summary>
        /// Write log update status
        /// </summary>
        /// <param name="key"></param>
        /// <param name="iOldStatus"></param>
        /// <param name="iNewSatus"></param>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        private void WriteLogUpdateStatus(int key, int iOldStatus, int iNewSatus)
        {
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            logBase.Key = key.ToString();
            logBase.Action = (int)CommonValue.ActionType.Update;

            clsMDLogInformation logInfo = new clsMDLogInformation();
            logInfo.FieldName = "Status";
            logInfo.OldValue = iOldStatus.ToString();
            logInfo.NewValue = iNewSatus.ToString();
            logBase.LstLogInformation.Add(logInfo);
            logBase.WirteLog(m_BoardRateBus.DAL);
        }

        #endregion

    }
}