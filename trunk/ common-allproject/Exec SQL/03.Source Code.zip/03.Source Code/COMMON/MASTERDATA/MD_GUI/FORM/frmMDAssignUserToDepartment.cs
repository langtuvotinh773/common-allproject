﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-19 (Tue, 19 March 2013) $
 * ========================================================
 * This class is used to Assign Users To Department
 * Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.MasterData.Dto;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Functions;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDAssignUserToDepartment : frmMDMaster
    {
        #region Global Variable
        // For Security Checking
        clsSEAuthorizer m_Security = null;

        public event EventHandler OnSaved;

        public int iSelectedDept = -1;
        public int iSelectedUser = -1;

        string strOldAssignDeptCodeList = string.Empty;
        string strOldAssignUserNameList = string.Empty;

        bool m_ForceClose = false;
        bool m_FirstLoad = true;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDAssignUserToDepartment class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDAssignUserToDepartment(string title)
        {
            InitializeComponent();
            this.Text = title;

            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);            
        }
        public frmMDAssignUserToDepartment()
        {
            InitializeComponent();  
          
            // Check authorization
            m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            m_Security.CheckAuthorizationOnScreen(this);
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Form Load
        /// Set default settings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void frmMDAssignUserToDepartment_Load(object sender, EventArgs e)
        {
            //Set common style for form
            SetFormStyleCommon();                 
            btnSave.Enabled = false;
            if (iSelectedDept> 0)
            {
                radDepartment.Checked = true;
            }
            else if (iSelectedUser > 0)
            {
                radUser.Checked = true;
            }
            else
            {
                radDepartment.Checked = true;
            }
        }

        /// <summary>
        /// Form close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMDAssignUserToDepartment_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                if (!m_ForceClose)
                {
                    //disable all button while system excute check changes of data before close form function.
                    EnableButtonControl(false);
                    try
                    {
                        SaveChangedData(sender, e);
                    }
                    catch (Exception ex)
                    {
                        this.m_ForceClose = true;                        
                        //show error message
                        clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                        //save log exception
                        clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
                    }
                    //enable all button
                    EnableButtonControl(true);
                }
            }
        }       

        /// <summary>
        /// Radio Department selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void radDepartment_CheckedChanged(object sender, EventArgs e)
        {
            try
            {                
                if (radDepartment.Checked)
                {
                    //if data was changed on sreen, display message confirm to save changes of data
                    if (!this.m_FirstLoad)
                    {
                        if (IsChangeData())
                        {
                            SaveChangedData(null, null);
                        }
                    }                    

                    //this.Text = clsMDConstant.DEPT_TITLE_ASSIGN_USER;
                    cbbDepartment.Enabled = true;
                    cbbDepartment.ResetText();
                    if (cbbDepartment.Items.Count > 0)
                    {
                        cbbDepartment.SelectedIndex = 0;
                    }
                    else
                    {
                        cbbDepartment.SelectedIndex = -1;
                    }

                    cbbUser.ResetText();
                    radUser.Checked = false;
                    cbbUser.Enabled = false;
                    cbbUser.SelectedIndex = -1;

                    lblLeft.Text = "Unassign Users";
                    lblRight.Text = "Assign Users";

                    CreateUserListView();
                    GetDataForComboBoxDepartment();

                    if (iSelectedDept <= 0)
                    {
                        iSelectedDept = int.Parse(cbbDepartment.SelectedValue.ToString());
                    }
                    else
                    {
                        cbbDepartment.SelectedValue = iSelectedDept.ToString(); 
                    }
                    iSelectedUser = -1;
                    btnSearch_Click(sender, e);
                    //lblControlName.Text = "Department Name: ";
                    lblControlValue.Text = string.Empty;//cbbDepartment.Text;
                }                
                btnSave.Enabled = false;
                this.m_FirstLoad = false;
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;                
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Radio User selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void radUser_CheckedChanged(object sender, EventArgs e)
        {
            try
            {                
                if (radUser.Checked)
                {
                    //if data was changed on sreen, display message confirm to save changes of data
                    if (!this.m_FirstLoad)
                    {
                        if (IsChangeData())
                        {
                            SaveChangedData(null, null);
                        }
                    }
                    
                    //this.Text = clsMDConstant.USER_TITLE_ASSIGN_DEPT;  
                    cbbUser.ResetText();
                    cbbUser.Enabled = true;
                    if (cbbUser.Items.Count > 0)
                    {
                        cbbUser.SelectedIndex = 0;
                    }
                    else
                    {
                        cbbUser.SelectedIndex = -1;
                    }

                    cbbDepartment.ResetText();
                    radDepartment.Checked = false;
                    cbbDepartment.Enabled = false;
                    cbbDepartment.SelectedIndex = -1;

                    lblLeft.Text = "Unassign Departments";
                    lblRight.Text = "Assign Departments";

                    CreateDepartmentListView();
                    GetDataForComboBoxUser();
                    
                    if (iSelectedUser <= 0)
                    {
                        iSelectedUser = int.Parse(cbbUser.SelectedValue.ToString());
                    }
                    else
                    {
                        cbbUser.SelectedValue = iSelectedUser.ToString();
                    }
                    iSelectedDept = -1;
                    btnSearch_Click(sender, e);
                    //lblControlName.Text = "Full Name: ";
                    lblControlValue.Text = string.Empty; //cbbUser.Text;
                }
                
                btnSave.Enabled = false;
                this.m_FirstLoad = false;
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;                
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Event click button "Search"
        /// Search list unassign, assign based on selected radio Department or User
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //disable all button while system excute search function.
            EnableButtonControl(false);
            try
            {
                //if data was changed on sreen, display message confirm to save changes of data
                if (!this.m_FirstLoad)
                {
                    try
                    {
                        if (IsChangeData())
                        {
                            SaveChangedData(null, null);
                        }
                    }
                    catch (Exception ex)
                    {
                        this.m_ForceClose = true;
                        //show error message
                        clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                        //save log exception
                        clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
                    }
                }
                listViewLeft.Items.Clear();
                listViewRight.Items.Clear();
                if (radDepartment.Checked)
                {
                    if (iSelectedDept < 0)
                    {
                        iSelectedDept = -1;
                    }
                    else
                    {
                        iSelectedDept = int.Parse(cbbDepartment.SelectedValue.ToString());
                        lblControlName.Text = "Department Name: " + cbbDepartment.Text;
                    }
                    iSelectedUser = -1;
                    GetUnassign_AssignUserList();
                }
                else
                {
                    if (iSelectedUser < 0)
                    {
                        iSelectedUser = -1;
                    }
                    else
                    {
                        iSelectedUser = int.Parse(cbbUser.SelectedValue.ToString());
                        lblControlName.Text = string.Format("Full Name: {0} - User Name: {1}", cbbUser.Text, clsMDUserBUS.Instance().GetUser(iSelectedUser).UserName);
                    }
                    iSelectedDept = -1;
                    GetUnassign_AssignDeptList();
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;                
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button while system finish search function.
            EnableButtonControl(true);
            //only enable Save button when data was changed on sreen
            btnSave.Enabled = false;
        }

        /// <summary>
        /// Event click button "Save"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {            
            //disable all button while system excute save function.
            EnableButtonControl(false);
            try
            {
                if (radDepartment.Checked)
                {
                    if (iSelectedDept == -1)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a department", "assign"));
                        cbbDepartment.Focus();
                        return;
                    }
                }
                else
                {
                    if (iSelectedUser == -1)
                    {
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "assign"));
                        cbbUser.Focus();
                        return;
                    }
                }
                if (listViewLeft.Items.Count > 0 || listViewRight.Items.Count > 0)
                {
                    //display message 'Do you want to save assignment?'
                    DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "assignment"));
                    if (res == DialogResult.Yes)
                    {
                        if (iSelectedDept > 0 && iSelectedUser == -1)
                        {
                            if (SaveAssignUserList())
                            {
                                this.m_ForceClose = true;
                                if (this.OnSaved != null)
                                {
                                    this.OnSaved(sender, e);
                                }
                                this.Close();
                            }
                        }
                        else
                        {
                            if (SaveAssignDeptList())
                            {
                                this.m_ForceClose = true;
                                if (this.OnSaved != null)
                                {
                                    this.OnSaved(sender, e);
                                }
                                this.Close();
                            }
                        }

                    }
                    else if (res == DialogResult.No)
                    {
                        this.m_ForceClose = true;
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
            //enable all button while system finish save function.
            EnableButtonControl(true);
        }

        /// <summary>
        /// Event click button "Cancel"
        /// System will close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Event click button ">>"
        /// Tranfer all item in ListView left to right
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnDoubleRight_Click(object sender, EventArgs e)
        {
            if (listViewLeft.Items != null && listViewLeft.Items.Count > 0)
            {
                foreach (ListViewItem item in listViewLeft.Items)
                {
                    listViewLeft.Items.Remove(item);
                    listViewRight.Items.Add(item);
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
            if (IsChangeData())
            {
                btnSave.Enabled = true;
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
            else
            {
                btnSave.Enabled = false;
            }
        }

        /// <summary>
        /// Event click button ">"
        /// Tranfer selected item in ListView left to right
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSingleRight_Click(object sender, EventArgs e)
        {
            if (listViewLeft.SelectedItems.Count > 0)
            {
                foreach (ListViewItem item in listViewLeft.SelectedItems)
                {
                    listViewLeft.Items.Remove(item);
                    listViewRight.Items.Add(item);
                }
            }
            else
            {
                if (radDepartment.Checked)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one user", "assign"));
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one department", "assign"));
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
            if (IsChangeData())
            {
                btnSave.Enabled = true;
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
            else
            {
                btnSave.Enabled = false;
            }
        }

        /// <summary>
        /// Event click button "<"
        /// Tranfer selected item in ListView right to left
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnSingleLeft_Click(object sender, EventArgs e)
        {
            if (listViewRight.SelectedItems.Count > 0)
            {
                foreach (ListViewItem item in listViewRight.SelectedItems)
                {                    
                    listViewRight.Items.Remove(item);
                    listViewLeft.Items.Add(item);
                }
            }
            else
            {
                if (radDepartment.Checked)
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one user", "unassign"));
                }
                else
                {
                    clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "at least one department", "unassign"));
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
            if (IsChangeData())
            {
                btnSave.Enabled = true;
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
            else
            {
                btnSave.Enabled = false;
            }
        }

        /// <summary>
        /// Event click button "<<"
        /// Tranfer all item in ListView right to left
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnDoubleLeft_Click(object sender, EventArgs e)
        {
            if (listViewRight.Items != null && listViewRight.Items.Count > 0)
            {
                foreach (ListViewItem item in listViewRight.Items)
                {
                    listViewRight.Items.Remove(item);
                    listViewLeft.Items.Add(item);
                }
            }
            listViewLeft.SelectedItems.Clear();
            listViewRight.SelectedItems.Clear();
            if (IsChangeData())
            {
                btnSave.Enabled = true;
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
            }
            else
            {
                btnSave.Enabled = false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void cbbUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbbUser.Text.Trim()) && !this.m_FirstLoad)
            {
                iSelectedUser = -1;
            }
            //lblControlName.Text = "Full Name: " + cbbUser.Text;       
            btnSave.Enabled = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void cbbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbbDepartment.Text.Trim()) && !this.m_FirstLoad)
            {
                iSelectedDept = -1;
            }
            //lblControlName.Text = "Department Name: " + cbbDepartment.Text;
            btnSave.Enabled = false;
        }

        /// <summary>
        /// Sort when click header of listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void listViewLeft_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            ItemComparer sorter = listViewLeft.ListViewItemSorter as ItemComparer;
            if (sorter == null)
            {
                sorter = new ItemComparer(e.Column);
                sorter.Order = SortOrder.Ascending;
                listViewLeft.ListViewItemSorter = sorter;
            }
            // if clicked column is already the column that is being sorted
            if (e.Column == sorter.Column)
            {
                // Reverse the current sort direction
                if (sorter.Order == SortOrder.Ascending)
                    sorter.Order = SortOrder.Descending;
                else
                    sorter.Order = SortOrder.Ascending;
            }
            else
            {
                // Set the column number that is to be sorted; default to ascending.
                sorter.Column = e.Column;
                sorter.Order = SortOrder.Ascending;
            }
            listViewLeft.Sort();
        }

        /// <summary>
        /// Sort when click header of listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void listViewRight_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            ItemComparer sorter = listViewRight.ListViewItemSorter as ItemComparer;
            if (sorter == null)
            {
                sorter = new ItemComparer(e.Column);
                sorter.Order = SortOrder.Ascending;
                listViewRight.ListViewItemSorter = sorter;
            }
            // if clicked column is already the column that is being sorted
            if (e.Column == sorter.Column)
            {
                // Reverse the current sort direction
                if (sorter.Order == SortOrder.Ascending)
                    sorter.Order = SortOrder.Descending;
                else
                    sorter.Order = SortOrder.Ascending;
            }
            else
            {
                // Set the column number that is to be sorted; default to ascending.
                sorter.Column = e.Column;
                sorter.Order = SortOrder.Ascending;
            }
            listViewRight.Sort();
        }
        #endregion 

        #region Member Methods
        /// <summary>
        /// Enable or disable button action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnSearch.Enabled = value;
            btnCancel.Enabled = value;
            btnSave.Enabled = value;
            btnDoubleLeft.Enabled = value;
            btnSingleLeft.Enabled = value;
            btnDoubleRight.Enabled = value;
            btnSingleRight.Enabled = value;
            if (value)
            {
                //check security
                if (btnSearch.Tag != null && !string.IsNullOrEmpty(btnSearch.Tag.ToString()))
                {
                    btnSearch.Enabled = bool.Parse(btnSearch.Tag.ToString());
                }
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                } 
            }
        }

        /// <summary>
        /// When radio department selected
        /// List View left and right are User List
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        void CreateUserListView()
        {
            listViewLeft.Clear();
            listViewRight.Clear();           
            ArrayList arrTitleLeft = new ArrayList(new string[] { "Unassign User" });
            for (int i = 0; i < arrTitleLeft.Count; i++)
            {
                listViewLeft.Columns.Add(arrTitleLeft[i].ToString().Replace(" ", ""), arrTitleLeft[i].ToString());
                listViewLeft.Columns[i].Width = 160;
            }
            ArrayList arrTitleRight = new ArrayList(new string[] { "Assign User" });
            for (int i = 0; i < arrTitleLeft.Count; i++)
            {
                listViewRight.Columns.Add(arrTitleRight[i].ToString().Replace(" ", ""), arrTitleRight[i].ToString());
                listViewRight.Columns[i].Width = 160;
            }
        }        

        /// <summary>
        /// When radio user selected
        /// List View left and right are Department List
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        void CreateDepartmentListView()
        {
            listViewLeft.Clear();
            listViewRight.Clear();
            ArrayList arrTitleLeft = new ArrayList(new string[] { "Unassign Department" });
            for (int i = 0; i < arrTitleLeft.Count; i++)
            {
                listViewLeft.Columns.Add(arrTitleLeft[i].ToString().Replace(" ", ""), arrTitleLeft[i].ToString());
                listViewLeft.Columns[i].Width = 160;
            }
            ArrayList arrTitleRight = new ArrayList(new string[] { "Assign Department" });
            for (int i = 0; i < arrTitleLeft.Count; i++)
            {
                listViewRight.Columns.Add(arrTitleRight[i].ToString().Replace(" ", ""), arrTitleRight[i].ToString());
                listViewRight.Columns[i].Width = 160;
            }
        }

        /// <summary>
        /// Get list department for cbbDepartment
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetDataForComboBoxDepartment()
        {
            cbbDepartment.DataSource = null;
            DataTable depts = clsMDDepartmentBUS.Instance().GetAllDepartmentList();
            if (depts == null) return;

            cbbDepartment.DataSource = depts;
            cbbDepartment.ValueMember = clsMDConstant.MD_COL_DEPARTMENTID;
            cbbDepartment.DisplayMember = clsMDConstant.MD_COL_DEPARTMENTNAME;

            cbbDepartment.SelectedIndex = 0;
        }

        /// <summary>
        /// Get list department for cbbDepartment
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetDataForComboBoxUser()
        {
            try
            {
                cbbUser.DataSource = null;
                DataTable users = clsMDUserBUS.Instance().GetUserList();
                if (users == null) return;

                cbbUser.DataSource = users;
                cbbUser.ValueMember = clsMDConstant.MD_COL_USER_NO;
                cbbUser.DisplayMember = clsMDConstant.MD_COL_USERNAME;

                cbbUser.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_SE);
            }
        }

        /// <summary>
        /// Get Unassign, Assign User List by DepartmentID
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetUnassign_AssignUserList()
        {
            listViewLeft.Items.Clear();
            listViewRight.Items.Clear();
            if (iSelectedDept == -1)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a department", "assign"));
                cbbDepartment.Focus();
            }
            else
            {
                DataTable dtUnassignUser = clsMDUserBUS.Instance().GetUnassignUserListByDeptID(iSelectedDept);
                DataTable dtAssignUser = clsMDUserBUS.Instance().GetAssignUserListByDeptID(iSelectedDept);
                LoadDataToUserListView(dtUnassignUser, listViewLeft);                
                LoadDataToUserListView(dtAssignUser, listViewRight);
                this.strOldAssignDeptCodeList = string.Empty;
                this.strOldAssignUserNameList = GetAssignCodeList(listViewRight);
            }
        }

        /// <summary>
        /// Load Unassign, Assign User List to control
        /// </summary>
        /// <param name="dtUser">DataTable</param>
        /// <param name="listView">ListView</param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        void LoadDataToUserListView(DataTable dtUser, ListView listView)
        {
            if (dtUser != null)
            {
                for (int i = 0; i < dtUser.Rows.Count; i++)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = dtUser.Rows[i][clsMDConstant.MD_COL_FULLNAME].ToString();
                    item.Tag = int.Parse(dtUser.Rows[i][clsMDConstant.MD_COL_USER_NO].ToString());
                    item.Name = dtUser.Rows[i][clsMDConstant.MD_COL_USERNAME].ToString();
                    listView.Items.Add(item);
                }
            }
        }

        /// <summary>
        /// Get Unassign, Assign Department List by UserNo
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetUnassign_AssignDeptList()
        {
            listViewLeft.Items.Clear();
            listViewRight.Items.Clear();
            if (iSelectedUser == -1)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.WARNING_ACTION_CHOOSE_ITEM, "a user", "assign"));
                cbbUser.Focus();
            }
            else
            {
                DataTable dtUnassignDept = clsMDUserBUS.Instance().GetUnassignDeptList(iSelectedUser);
                DataTable dtAssignDept = clsMDUserBUS.Instance().GetAssignDeptList(iSelectedUser);
                LoadDataToDeptListView(dtUnassignDept, listViewLeft);                
                LoadDataToDeptListView(dtAssignDept, listViewRight);
                this.strOldAssignDeptCodeList = GetAssignCodeList(listViewRight);
                this.strOldAssignUserNameList = string.Empty;
            }
        }

        /// <summary>
        /// Load Unassign, Assign Department List to control
        /// </summary>
        /// <param name="dtUser">DataTable</param>
        /// <param name="listView">ListView</param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        void LoadDataToDeptListView(DataTable dtDept, ListView listView)
        {
            if (dtDept != null)
            {
                for (int i = 0; i < dtDept.Rows.Count; i++)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = dtDept.Rows[i][clsMDConstant.MD_COL_DEPARTMENTNAME].ToString();
                    item.Tag = int.Parse(dtDept.Rows[i][clsMDConstant.MD_COL_DEPARTMENTID].ToString());
                    item.Name = dtDept.Rows[i][clsMDConstant.MD_COL_DEPARTMENTCODE].ToString();
                    listView.Items.Add(item);
                }
            }
        }

        /// <summary>
        /// Save List Assign User
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private bool SaveAssignUserList()
        {
            string strUserNo = string.Empty;
            foreach (ListViewItem item in listViewRight.Items)
            {                
                if (string.IsNullOrEmpty(strUserNo))
                {
                    strUserNo += item.Tag.ToString();
                }
                else
                {
                    strUserNo += ", " + item.Tag.ToString();
                }
            }            
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();

            //Save assignment and Write data to log
            int row = clsMDUserBUS.Instance().UpdataAssignUsersToDepartment(strUserNo, iSelectedDept, clsUserInfo.UserNo, logBase);

            if (row > 0 || IsChangeData() == false)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Assigning", "users to department"));
                //GetUnassign_AssignUserList();
                return true;
            }
            else
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Assigning", "users to department"));
            }
            return false;
        }

        /// <summary>
        /// Save List Assign Dept
        /// </summary>
        private bool SaveAssignDeptList()
        {
            string strDepartmentID = string.Empty;
            foreach (ListViewItem item in listViewRight.Items)
            {               
                if (string.IsNullOrEmpty(strDepartmentID))
                {
                    strDepartmentID += item.Tag.ToString();
                }
                else
                {
                    strDepartmentID += "," + item.Tag.ToString();
                }
            }
            //get data for save log
            clsMDLogBase logBase = CreateDataSaveLog();

            //Create User and Write data to log
            int row = clsMDUserBUS.Instance().UpdataAssignDepartmentsToUser(iSelectedUser, strDepartmentID, clsUserInfo.UserNo, logBase);
            if (row > 0 || IsChangeData() == false)
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Assigning", "departments to user"));
                return true;
                //GetUnassign_AssignDeptList();
            }
            else
            {
                clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Assigning", "departments to user"));
            }
            return false;
        }

        /// <summary>
        /// Check data was changed on screen
        /// </summary>
        /// <returns>
        /// if data was changed return true
        /// else return false
        /// </returns>
        private bool IsChangeData()
        {
            ListView listRight = new ListView();
            DataTable dt = new DataTable();
            if (listViewLeft.Items.Count == 0 && listViewRight.Items.Count == 0)
            {
                return false;
            }
            if (iSelectedDept == -1 && iSelectedUser >= 0) 
            {
                dt = clsMDUserBUS.Instance().GetAssignDeptList(iSelectedUser);
                LoadDataToDeptListView(dt, listRight);
            }
            else if (iSelectedDept >= 0 && iSelectedUser == -1)
            {
                dt = clsMDUserBUS.Instance().GetAssignUserListByDeptID(iSelectedDept);
                LoadDataToUserListView(dt, listRight);
            }
            else
            {
                return false;
            }
            if (listRight.Items.Count == 0 && listViewRight.Items.Count > 0)
            {
                return true;
            }
            else if (listRight.Items.Count > 0 && listViewRight.Items.Count == 0)
            {
                return true;
            }
            else if (listRight.Items.Count != listViewRight.Items.Count)
            {
                return true;
            }
            else
            {
                Dictionary<string, string> checkList = new Dictionary<string, string>();
                foreach (ListViewItem item in listRight.Items)
                {
                    checkList.Add(item.Tag.ToString(), item.Text);
                }
                foreach (ListViewItem item in listViewRight.Items)
                {
                    if (!checkList.ContainsValue(item.Text))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Get DepartmentCode or UseName selected to assign
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private string GetAssignCodeList(ListView listView)
        {
            string strSelectedCode = string.Empty;
            foreach (ListViewItem item in listView.Items)
            {
                if (string.IsNullOrEmpty(strSelectedCode))
                {
                    strSelectedCode += item.Name.ToString();
                }
                else
                {
                    strSelectedCode += "," + item.Name.ToString();
                }
            }
            return strSelectedCode;
        }

        /// <summary>
        /// Create data to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private clsMDLogBase CreateDataSaveLog()
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_SE;
            clsMDLogInformation logInfo = new clsMDLogInformation();
            if (iSelectedDept > 0 && iSelectedUser == -1)
            {
                logBase.Key = clsMDDepartmentBUS.Instance().GetDepartment(iSelectedDept).DepartmentCode;
                if (string.IsNullOrEmpty(strOldAssignUserNameList))
                {
                    logBase.Action = (int)CommonValue.ActionType.New;
                }
                else
                {
                    logBase.Action = (int)CommonValue.ActionType.Update;
                }
                //UserName
                logInfo.FieldName = clsMDConstant.MD_COL_USERNAME;
                logInfo.OldValue = strOldAssignUserNameList;
                logInfo.NewValue = GetAssignCodeList(listViewRight);
                logBase.LstLogInformation.Add(logInfo);                
            }
            else
            {
                logBase.Key = clsMDUserBUS.Instance().GetUser(iSelectedUser).UserName;
                if (string.IsNullOrEmpty(strOldAssignDeptCodeList))
                {
                    logBase.Action = (int)CommonValue.ActionType.New;
                }
                else
                {
                    logBase.Action = (int)CommonValue.ActionType.Update;
                }
                //DepartmentCode
                logInfo.FieldName = clsMDConstant.MD_COL_DEPARTMENTCODE;
                logInfo.OldValue = strOldAssignDeptCodeList;
                logInfo.NewValue = GetAssignCodeList(listViewRight);
                logBase.LstLogInformation.Add(logInfo);                
            }            
            return logBase;
        }

        /// <summary>
        /// Save changes of data on screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void SaveChangedData(object sender, FormClosingEventArgs eventClose)
        {
            //if data was changed on screen, display confirm message to save changed data
            if (IsChangeData())
            {
                //display message 'Do you want to save changes of data?'
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                if (res == DialogResult.Yes)
                {
                    if (iSelectedDept > 0)
                    {
                        if (SaveAssignUserList())
                        {
                            if (eventClose != null)
                            {
                                if (OnSaved != null)
                                {
                                    if (sender != null)
                                    {
                                        OnSaved(sender, eventClose);
                                    }
                                }
                                this.Close();
                            }
                        }
                    }
                    else
                    {
                        if (SaveAssignDeptList())
                        {
                            if (eventClose != null)
                            {
                                if (OnSaved != null)
                                {
                                    if (sender != null)
                                    {
                                        OnSaved(sender, eventClose);
                                    }
                                }
                                this.Close();
                            }
                        }
                    }
                }
                else if (res == DialogResult.Cancel)
                {
                    if (eventClose != null)
                    {
                        eventClose.Cancel = true;
                    }
                }
            }
        }
        #endregion        
    }    
}
