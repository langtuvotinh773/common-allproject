﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-04-03 (Wed, 03 April 2013) $
 * ========================================================
 * This form is used to view, create, update currency holiday list
 * for Master Data module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Com;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.MasterData.Gui
{
    public partial class frmMDCurrencyHoliday : frmMDMaster
    {
        #region Global Variable
        DataTable dtHoliday = null;
        bool isFormLoad = true;
        bool isSelectedChangedCBB = true;
        bool m_ForceClose = false;//if m_ForceClose = true, close form not check changed data
        /// Project name
        private string m_ProjectName = clsMDConstant.PROJECT_NAME_MASTERDATA;
        // For Security Checking
        clsSEAuthorizer m_Security = null;
		bool CommonError = false;
        /// <summary>
        /// Excel Base
        /// </summary>
        ExcelBase m_ExcelBase;
        #endregion      

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the frmMDCurrencyHoliday class.
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public frmMDCurrencyHoliday()
        {
			try
			{
				InitializeComponent();
				
				// Check authorization
				m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
				m_Security.CheckAuthorizationOnScreen(this);

				this.Text = clsMDConstant.HOLIDAY_TITLE;
                //Reset Remark
                this.lblRemarkDescription.Text = string.Empty;
                //load data for combo box
                FillDataComboboxCCY();
                FillDataComboboxYear();
			}
			catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
				CommonError = true;
            }
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Event form load, system will load data default:
        /// Data for ComboBox CCY        
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmMDCurrencyHoliday_Load(object sender, EventArgs e)
        {			
            try
            {
                //Set common style for form
                SetFormStyleCommon();                
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Form shown event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmMDCurrencyHoliday_Shown(object sender, EventArgs e)
        {
            if (CommonError)
            {
                this.m_ForceClose = true;
                Close();
            }
            try
            {
                string strCCY = cbbCCY.Text.Trim();
                if (dtHoliday != null && dtHoliday.Rows.Count > 0)
                {
                    //not show message confirm
                }
                else
                {
                    if (!CommonError)
                    {
                        //Display message: For [CCY/All] currency, this year does not have holiday data.
                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_YEAR_HAS_NOT_HOLIDAY, string.IsNullOrEmpty(strCCY) ? "All" : strCCY));                        
                    }
                    RefreshCalendar();
                }
                isFormLoad = false;
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event selected index changed of CombobBox Year
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void cbbYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            //isSelectedChangedCBB = true;
            //int iYear;
            //string strCCY;
            //if (cbbYear.SelectedValue != null && int.TryParse(cbbYear.SelectedValue.ToString(), out iYear))
            //{
            //    //get selected year
            //    iYear = int.Parse(cbbYear.SelectedValue.ToString());
            //    strCCY = cbbCCY.Text.Trim();
            //    //get all registed holidays based on year and ccy
            //    dtHoliday = clsMDCurrencyHolidayBUS.Instance().GetCurrencyHolidayList(iYear, strCCY);
            //    //create 12 months based on selected year
            //    CreateMonths(iYear, strCCY);

            //    if (dtHoliday != null && dtHoliday.Rows.Count > 0)
            //    {
            //        //not show message confirm
            //        btnExport.Enabled = true;
            //    }
            //    else
            //    {
            //        if (!isFormLoad)
            //        {                     
            //            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_YEAR_HAS_NOT_HOLIDAY, string.IsNullOrEmpty(strCCY) ? "All" : strCCY));
            //        }                    
            //        btnExport.Enabled = false;
            //        RefreshCalendar();
            //    }
            //}
            //isSelectedChangedCBB = false;
        }

        /// <summary>
        /// Event selected value changed of CombobBox Year
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void cbbYear_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                isSelectedChangedCBB = true;
                int iYear;
                string strCCY;
                if (cbbYear.SelectedValue != null && int.TryParse(cbbYear.SelectedValue.ToString(), out iYear))
                {
                    //get selected year
                    iYear = int.Parse(cbbYear.SelectedValue.ToString());
                    strCCY = cbbCCY.Text.Trim();
                    //get all registed holidays based on year and ccy
                    dtHoliday = clsMDCurrencyHolidayBUS.Instance().GetCurrencyHolidayList(iYear, strCCY);
                    //create 12 months based on selected year
                    CreateMonths(iYear, strCCY);

                    if (dtHoliday != null && dtHoliday.Rows.Count > 0)
                    {
                        //not show message confirm
                        btnExport.Enabled = true;
                        if (btnExport.Tag != null && !string.IsNullOrEmpty(btnExport.Tag.ToString()))
                        {
                            btnExport.Enabled = bool.Parse(btnExport.Tag.ToString());
                        }
                    }
                    else
                    {
                        if (!isFormLoad)
                        {
                            //Display message: For [CCY/All] currency, this year does not have holiday data.
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_YEAR_HAS_NOT_HOLIDAY, string.IsNullOrEmpty(strCCY) ? "All" : strCCY));
                        }
                        btnExport.Enabled = false;
                        RefreshCalendar();
                    }
                }
                isSelectedChangedCBB = false;
                //remove focus from cbbYear
                this.groupBox1.Focus();
                this.lblRemarkDescription.Text = string.Empty;
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Event selected index changed of CombobBox CCY
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void cbbCCY_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                isSelectedChangedCBB = true;
                int iYear;
                string strCCY;
                if (cbbYear.SelectedValue != null && int.TryParse(cbbYear.SelectedValue.ToString(), out iYear))
                {
                    //get selected year
                    iYear = int.Parse(cbbYear.SelectedValue.ToString());
                    strCCY = cbbCCY.Text.Trim();
                    //get all registed holidays based on year and ccy
                    dtHoliday = clsMDCurrencyHolidayBUS.Instance().GetCurrencyHolidayList(iYear, strCCY);
                    //create 12 months based on selected year
                    CreateMonths(iYear, strCCY);
                    if (dtHoliday != null && dtHoliday.Rows.Count > 0)
                    {
                        //not show message confirm
                        btnExport.Enabled = true;
                        if (btnExport.Tag != null && !string.IsNullOrEmpty(btnExport.Tag.ToString()))
                        {
                            btnExport.Enabled = bool.Parse(btnExport.Tag.ToString());
                        }
                    }
                    else
                    {
                        if (!isFormLoad)
                        {
                            //Display message: For [CCY/All] currency, this year does not have holiday data.
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.WARNING_ACTION_YEAR_HAS_NOT_HOLIDAY, string.IsNullOrEmpty(strCCY) ? "All" : strCCY));
                        }
                        btnExport.Enabled = false;
                        RefreshCalendar();
                    }
                }
                if (string.IsNullOrEmpty(cbbCCY.Text.Trim()))
                {
                    btnSave.Enabled = false;
                }
                else
                {
                    btnSave.Enabled = true;
                    if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                    {
                        btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                    }
                }
                isSelectedChangedCBB = false;
                //remove focus from cbbCCY
                this.groupBox1.Focus();
                this.lblRemarkDescription.Text = string.Empty;
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Save currency holiday
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            //disable all button while system excute save function.
            EnableButtonControl(false);
            try
            {  
                DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, string.Format(clsMDMessage.CONF_ACTION, "save", "holidays for this currency"));
                if (res == DialogResult.Yes)
                {
                    int iUserNo = clsUserInfo.UserNo;
                    string strCCY = cbbCCY.Text.Trim();
                    int iRow = 0;
                    List<DateTime> listDeletedDate = new List<DateTime>();
                    List<DateTime> listInsertedDate = new List<DateTime>();
                    List<DateTime> listUpdatedDate = new List<DateTime>();
                    GetSelectedHolidayList(ref listInsertedDate, ref listUpdatedDate, ref listDeletedDate);
                    //get data for save log
                    clsMDLogBase logBase = CreateDataSaveLog(listInsertedDate, listUpdatedDate);
                    //Save and Write data to log
                    iRow = clsMDCurrencyHolidayBUS.Instance().SaveCurrencyHolidayList(strCCY, iUserNo, listDeletedDate, listInsertedDate, listUpdatedDate, logBase);
                    if (dtHoliday != null && dtHoliday.Rows.Count > 0)
                    {
                        if (iRow > 0)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Modifying", "currency holiday"));
                            btnExport.Enabled = true;
                        }
                        else if (iRow == 0)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Modifying", "currency holiday"));
                            btnExport.Enabled = false;
                        }
                        else
                        {
                            this.m_ForceClose = true;
                            this.Close();
                        }
                    }
                    else
                    {
                        if (iRow > 0)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Creating", "currency holiday"));
                            btnExport.Enabled = true;
                        }
                        else if (iRow == 0)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Creating", "currency holiday"));
                            btnExport.Enabled = false;
                        }
                        else
                        {
                            this.m_ForceClose = true;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //enable all button while system finish save function.
            EnableButtonControl(true);     
        }

        /// <summary>
        /// Export excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnExport_Click(object sender, EventArgs e)
        {
            //disable all button while system excute export function.
            EnableButtonControl(false);
            try
            {
                ExportExcel();                
            }
            catch (Exception ex)
            {
                this.m_ForceClose = true;
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
            //enable all button while system finish export function.
            EnableButtonControl(true);     
        }        

        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Form close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void frmMDCurrencyHoliday_FormClosing(object sender, FormClosingEventArgs e)
        {
            //check security for save action
            bool isAuthorizedSave = true;
            if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
            {
                isAuthorizedSave = bool.Parse(btnSave.Tag.ToString());
            }
            //if save action is authorized and system will check changed data on screen.
            if (isAuthorizedSave)
            {
                if (!this.m_ForceClose)
                {
                    //disable all button while system excute check changes of data before close form function.
                    EnableButtonControl(false);
                    try
                    {
                        int iUserNo = clsUserInfo.UserNo;
                        string strCCY = cbbCCY.Text.Trim();
                        int iRow = 0;
                        List<DateTime> listDeletedDate = new List<DateTime>();
                        List<DateTime> listInsertedDate = new List<DateTime>();
                        List<DateTime> listUpdatedDate = new List<DateTime>();
                        GetSelectedHolidayList(ref listInsertedDate, ref listUpdatedDate, ref listDeletedDate);
                        //data was changed
                        if (listDeletedDate.Count > 0 || listInsertedDate.Count > 0)
                        {
                            DialogResult res = clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsMDMessage.CONFIRM_ACTION_SAVE_DATA_CHANGED);
                            if (res == DialogResult.Yes)
                            {
                                //get data for save log
                                clsMDLogBase logBase = CreateDataSaveLog(listInsertedDate, listUpdatedDate);
                                //Save and Write data to log
                                iRow = clsMDCurrencyHolidayBUS.Instance().SaveCurrencyHolidayList(strCCY, iUserNo, listDeletedDate, listInsertedDate, listUpdatedDate, logBase);
                                if (dtHoliday != null && dtHoliday.Rows.Count > 0)
                                {
                                    if (iRow > 0)
                                    {
                                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Modifying", "currency holiday"));
                                        btnExport.Enabled = true;
                                    }
                                    else if (iRow == 0)
                                    {
                                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Modifying", "currency holiday"));
                                        btnExport.Enabled = false;
                                        e.Cancel = true;
                                    }
                                }
                                else
                                {
                                    if (iRow > 0)
                                    {
                                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(clsMDMessage.INFO_ACTION_SUCCESS, "Creating", "currency holiday"));
                                        btnExport.Enabled = true;
                                    }
                                    else if(iRow == 0)
                                    {
                                        clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(clsMDMessage.INFO_ACTION_FAIL, "Creating", "currency holiday"));
                                        btnExport.Enabled = false;
                                        e.Cancel = true;
                                    }
                                }
                            }
                            else if (res == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        this.m_ForceClose = true;
                        //show error message
                        clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                        //save log exception
                        clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                    }
                    //enable all button
                    EnableButtonControl(true);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void btnClose_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            //if (e.KeyCode == Keys.Tab)
            //{
            //    cbbCCY.Focus();
            //}
        }
        #endregion

        #region Create 12 month

        #region January calendar
        /// <summary>
        /// Load list of holidays for January month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrJan_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on January calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrJan_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrJan.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrJan.SuspendLayout();
        }
        #endregion

        #region Feburary calendar
        /// <summary>
        /// Load list of holidays for Feburary month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrFeb_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on Feburary calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrFeb_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrFeb.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrFeb.SuspendLayout();
        }
        #endregion

        #region March calendar
        /// <summary>
        /// Load list of holidays for March month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrMar_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on March calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrMar_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrMar.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrMar.SuspendLayout();
        }
        #endregion

        #region April calendar
        /// <summary>
        /// Load list of holidays for April month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrApr_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on April calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrApr_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrApr.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrApr.SuspendLayout();
        }
        #endregion

        #region May Calendar
        /// <summary>
        /// Load list of holidays for May month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrMay_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on May calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrMay_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrMay.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrMay.SuspendLayout();
        }
        #endregion

        #region June Calendar
        /// <summary>
        /// Load list of holidays for June month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrJun_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on June calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrJun_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrJun.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrJun.SuspendLayout();
        }
        #endregion

        #region July Calendar
        /// <summary>
        /// Load list of holidays for July month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrJul_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on July calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrJul_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrJul.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrJul.SuspendLayout();
        }
        #endregion

        #region August Calendar
        /// <summary>
        /// Load list of holidays for August month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrAug_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on August calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrAug_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrAug.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrAug.SuspendLayout();
        }
        #endregion

        #region September Calendar
        /// <summary>
        /// Load list of holidays for September month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrSep_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on September calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrSep_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrSep.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrSep.SuspendLayout();
        }
        #endregion 

        #region October Calendar
        /// <summary>
        /// Load list of holidays for October month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrOct_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on October calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrOct_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrOct.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrOct.SuspendLayout();
        }
        #endregion

        #region November Calendar
        /// <summary>
        /// Load list of holidays for November month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrNov_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on October calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrNov_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrNov.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrNov.SuspendLayout();
        }
        #endregion

        #region December Calendar
        /// <summary>
        /// Load list of holidays for December month, get data from db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrDec_LoadCurrencyHoliday(object sender, UserCtrl.LoadCurrencyHolidayEventArgs e)
        {
            FillHolidayToMonth(e.HolidayCalendar);
        }

        /// <summary>
        /// Event selected date on December calendar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void clrDec_SelectedDateChanged(object sender, UserCtrl.SelectedDateChangedEventArgs e)
        {
            this.clrDec.Refresh();
            ShowInfoSelectedDay(e.SelectedDate);
            this.clrDec.SuspendLayout();
        }
        #endregion

        #endregion

        #region Member Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void EnableButtonControl(bool value)
        {
            btnSave.Enabled = value;
            btnExport.Enabled = value;
            btnClose.Enabled = value;
            if (value)
            {
                //check security
                if (btnSave.Tag != null && !string.IsNullOrEmpty(btnSave.Tag.ToString()))
                {
                    btnSave.Enabled = bool.Parse(btnSave.Tag.ToString());
                }
                if (btnExport.Tag != null && !string.IsNullOrEmpty(btnExport.Tag.ToString()))
                {
                    btnExport.Enabled = bool.Parse(btnExport.Tag.ToString());
                }
            }
        }
       
        /// <summary>
        /// Load data for Combobox Currency
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void FillDataComboboxCCY()
        {
            try
            {
                DataTable dtCurrency = clsMDCurrencyMasterBUS.Instance().GetCurrencyList();

                if (dtCurrency == null) return;

                dtCurrency.Rows.InsertAt(dtCurrency.NewRow(), 0);

                cbbCCY.DataSource = dtCurrency;
                cbbCCY.ValueMember = clsMDConstant.MD_COL_CCYCODE;
                cbbCCY.DisplayMember = clsMDConstant.MD_COL_CCYCODE;
                cbbCCY.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Load data for Combobox Year
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void FillDataComboboxYear()
        {
            try
            {
                DataTable dtYear = clsMDCurrencyHolidayBUS.Instance().GetYearList();
                //add current year and five next years
                int curYear = DateTime.Now.Year;
                for (int i = curYear; i <= curYear + 5; i++)
                {
                    DataRow[] result = dtYear.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_HOLIDAY_YEAR, i));
                    if (result.Length == 0)
                    {
                        dtYear.Rows.Add(i);
                    }
                }
                cbbYear.DataSource = dtYear;
                cbbYear.ValueMember = clsMDConstant.MD_COL_HOLIDAY_YEAR;
                cbbYear.DisplayMember = clsMDConstant.MD_COL_HOLIDAY_YEAR;
                cbbYear.SelectedValue = curYear.ToString();
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Create months based on year
        /// </summary>
        /// <param name="iYear"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void CreateMonths(int iYear, string strCCY)
        {
            //january           
            this.clrJan.Date = new DateTime(iYear, 1, 1);
            this.clrJan.SelectedCCYCode = strCCY;
            //february
            this.clrFeb.Date = new DateTime(iYear, 2, 1);
            this.clrFeb.SelectedCCYCode = strCCY;
            //march
            this.clrMar.Date = new DateTime(iYear, 3, 1);
            this.clrMar.SelectedCCYCode = strCCY;
            //April
            this.clrApr.Date = new DateTime(iYear, 4, 1);
            this.clrApr.SelectedCCYCode = strCCY;
            //May
            this.clrMay.Date = new DateTime(iYear, 5, 1);
            this.clrMay.SelectedCCYCode = strCCY;
            //June
            this.clrJun.Date = new DateTime(iYear, 6, 1);
            this.clrJun.SelectedCCYCode = strCCY;
            //July
            this.clrJul.Date = new DateTime(iYear, 7, 1);
            this.clrJul.SelectedCCYCode = strCCY;
            //August
            this.clrAug.Date = new DateTime(iYear, 8, 1);
            this.clrAug.SelectedCCYCode = strCCY;
            //September
            this.clrSep.Date = new DateTime(iYear, 9, 1);
            this.clrSep.SelectedCCYCode = strCCY;
            //October
            this.clrOct.Date = new DateTime(iYear, 10, 1);
            this.clrOct.SelectedCCYCode = strCCY;
            //November
            this.clrNov.Date = new DateTime(iYear, 11, 1);
            this.clrNov.SelectedCCYCode = strCCY;
            //December
            this.clrDec.Date = new DateTime(iYear, 12, 1);
            this.clrDec.SelectedCCYCode = strCCY;
        }

        /// <summary>
        /// Redraw calendar
        /// </summary>
        private void RefreshCalendar()
        {
            this.clrJan.Refresh();
            this.clrFeb.Refresh();
            this.clrMar.Refresh();
            this.clrApr.Refresh();
            this.clrMay.Refresh();
            this.clrJun.Refresh();
            this.clrJul.Refresh();
            this.clrAug.Refresh();
            this.clrSep.Refresh();
            this.clrOct.Refresh();
            this.clrNov.Refresh();
            this.clrDec.Refresh();
        }

        /// <summary>
        /// Get list of registed holidays of month to load calendar
        /// </summary>
        /// <param name="holidayCalendar"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void FillHolidayToMonth(UserCtrl.ctrlHolidayCalendar holidayCalendar)
        {
            try
            {
                if (dtHoliday != null && dtHoliday.Rows.Count > 0)
                {
                    DataRow[] result = dtHoliday.Select(string.Format("{0} = '{1}'", clsMDConstant.MD_COL_MONTH, holidayCalendar.Month));
                    holidayCalendar.SelectedDates.Clear();
                    foreach (DataRow dr in result)
                    {
                        DateTime date = DateTime.Parse(dr[clsMDConstant.MD_COL_HOLIDAY_DATE].ToString());
                        holidayCalendar.SelectedDates.Add(date);
                    }
                    holidayCalendar.IsExistHoliday = true;
                }
                else
                {
                    holidayCalendar.IsExistHoliday = false;
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// Get reamrk about currencies that selected date is holiday on 
        /// </summary>
        /// <param name="holidayCalendar"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void ShowInfoSelectedDay(DateTime date)
        {
            try
            {
                if (!isFormLoad && !isSelectedChangedCBB)
                {
                    //cbbCYY = blank
                    if (string.IsNullOrEmpty(cbbCCY.Text.Trim()))
                    {
                        string strInfoCCY = clsMDCurrencyHolidayBUS.Instance().GetSelectedHolidayInfo(date);
                        if (!string.IsNullOrEmpty(strInfoCCY))
                        {
                            lblRemarkDescription.Text = string.Format(clsMDMessage.INFO_ABOUT_SELECTED_HOLIDAY, date.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY), strInfoCCY);
                        }
                        else
                        {
                            lblRemarkDescription.Text = string.Empty;
                        }
                    }
                    else
                    {
                        if (date.Year < DateTime.Now.Year)
                        {
                            clsMDMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsMDMessage.WARNING_ACTION_UPDATE_HOLIDAY_IN_PAST);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
            }
        }

        /// <summary>
        /// get list of selected holiday date
        /// </summary>
        /// <param name="listInsert"></param>
        /// <param name="listUpdate"></param>
        /// <param name="listDelete"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void GetSelectedHolidayList(ref List<DateTime> listInsert, ref List<DateTime> listUpdate, ref List<DateTime> listDelete)
        {            
            int iYear = int.Parse(cbbYear.SelectedValue.ToString());
            string strCCY = cbbCCY.Text.Trim();
            List<DateTime> listSelectedDate = new List<DateTime>();
            List<UserCtrl.ctrlHolidayCalendar> listCalendar = new List<UserCtrl.ctrlHolidayCalendar>();
            listCalendar.Add(clrJan);
            listCalendar.Add(clrFeb);
            listCalendar.Add(clrMar);
            listCalendar.Add(clrApr);
            listCalendar.Add(clrMay);
            listCalendar.Add(clrJun);
            listCalendar.Add(clrJul);
            listCalendar.Add(clrAug);
            listCalendar.Add(clrSep);
            listCalendar.Add(clrOct);
            listCalendar.Add(clrNov);
            listCalendar.Add(clrDec);
            //get list of selected date from 12 months
            foreach (UserCtrl.ctrlHolidayCalendar cal in listCalendar)
            {
                if (cal.SelectedDates.Count > 0)
                {
                    foreach (DateTime date in cal.SelectedDates)
                    {
                        listSelectedDate.Add(date);
                    }
                }
            }
            //get list of selected date in db
            dtHoliday = clsMDCurrencyHolidayBUS.Instance().GetCurrencyHolidayList(iYear, strCCY);
            //analize
            if (dtHoliday != null && dtHoliday.Rows.Count > 0)
            {
                foreach (DataRow dr in dtHoliday.Rows)
                {
                    DateTime date = DateTime.Parse(dr[clsMDConstant.MD_COL_HOLIDAY_DATE].ToString());
                    //if date is existed in selected list, add to update list to update record in db
                    if(listSelectedDate.Contains(date))
                    {
                        //add to update list
                        listUpdate.Add(date);                        
                    }
                    else
                    {
                        //if date is not existed selected list, add to delete list to delete record in db
                        listDelete.Add(date);
                    }
                    //remove from selected list
                    listSelectedDate.Remove(date);
                }
            }
            //all date in selected list will be inserted 
            listInsert = listSelectedDate;
        }

        /// <summary>
        /// Export data of currency holiday to excel file
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private void ExportExcel()
        {
            int iYear;
            string strCCY;
            iYear = int.Parse(cbbYear.SelectedValue.ToString());
            strCCY = cbbCCY.Text.Trim();
            dtHoliday = clsMDCurrencyHolidayBUS.Instance().GetCurrencyHolidayExportList(iYear, strCCY);

            string strFileName = clsMDConstant.EXCEL_TEMPLATE_NAME_CURRENCY_HOLIDAY;
            string strTemplateName = clsMDConstant.EXCEL_TEMPLATE_FILE_CURRENCY_HOLIDAY;
            bool isOpened = false;
            m_ExcelBase = new ExcelBase(strFileName, strTemplateName, m_ProjectName, ref isOpened, clsMDBus.Instance().GetServerDate());
            if (isOpened)
            {
                return;
            }
            int iColStart = 1, iRowStart = 5, iRowEnd = iRowStart + dtHoliday.Rows.Count - 1;
            int iColEnd = clsMDConstant.HEADER_HOLIDAY_EXPORT.Length;            

            object[,] m_arrData = FillDataForReport(dtHoliday, dtHoliday.Rows.Count, iColEnd);
            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);

            m_ExcelBase.GetRange(1, 4, 1, iRowEnd).ColumnWidth = 7;
            m_ExcelBase.GetRange(2, 4, 2, iRowEnd).ColumnWidth = 7;
            m_ExcelBase.GetRange(3, 4, 3, iRowEnd).ColumnWidth = 12;

            m_ExcelBase.SaveFileNotAutoFitColumns(true);
        }

        /// <summary>
        /// Get data for report
        /// </summary>
        /// <param name="iRowCount"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private object[,] FillDataForReport(DataTable dt, int iRowCount, int iColCount)
        {
            object[,] arrResult = new object[iRowCount, iColCount];
            int pos = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    DateTime date = new DateTime();
                    if (DateTime.TryParse(dt.Rows[i][j].ToString(), out date))
                    {
                        arrResult[i, pos] = DateTime.Parse(dt.Rows[i][j].ToString()).ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    }
                    else
                    {
                        arrResult[i, pos] = dt.Rows[i][j].ToString();
                    }
                    pos++;
                }
                pos = 0;
            }
            return arrResult;
        }

        /// <summary>
        /// Get Old Selected Holiday
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private string GetOldSelectedHolidayList()
        {
            string strOldSelectedHoliday = string.Empty;
            if (dtHoliday != null && dtHoliday.Rows.Count > 0)
            {
                foreach (DataRow dr in dtHoliday.Rows)
                {
                    if (string.IsNullOrEmpty(strOldSelectedHoliday))
                    {
                        strOldSelectedHoliday += DateTime.Parse(dr[clsMDConstant.MD_COL_HOLIDAY_DATE].ToString()).ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    }
                    else
                    {
                        strOldSelectedHoliday += ", " + DateTime.Parse(dr[clsMDConstant.MD_COL_HOLIDAY_DATE].ToString()).ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    }
                }
            }
            return strOldSelectedHoliday;
        }

        /// <summary>
        /// Get New Selected Holiday
        /// </summary>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        private string GetNewSelectedHolidayList(List<DateTime> listInsertedDate, List<DateTime> listUpdatedDate)
        {
            List<DateTime> listDate = new List<DateTime>();
            listDate.InsertRange(0, listUpdatedDate);
            listDate.InsertRange(listDate.Count, listInsertedDate);
            listDate.Sort();
            string strNewSelectedHoliday = string.Empty;
            if (listDate.Count > 0)
            {
                foreach (DateTime date in listDate)
                {
                    if (string.IsNullOrEmpty(strNewSelectedHoliday))
                    {
                        strNewSelectedHoliday += date.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    }
                    else
                    {
                        strNewSelectedHoliday += ", " + date.ToString(clsMDConstant.DATETIME_FORMAT_DDMMMYYYY);
                    }
                }
            }
            return strNewSelectedHoliday;
        }

        /// <summary>
        /// Create data to save log
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private clsMDLogBase CreateDataSaveLog(List<DateTime> listInsertedDate, List<DateTime> listUpdatedDate)
        {
            //create data for save log
            clsMDLogBase logBase = new clsMDLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Module = clsMDConstant.MODULE_MD;
            clsMDLogInformation logInfo = new clsMDLogInformation();
            logBase.Key = cbbCCY.Text.ToString();
            if (dtHoliday != null && dtHoliday.Rows.Count>0)
            {
                logBase.Action = (int)CommonValue.ActionType.Update;
            }
            else
            {
                logBase.Action = (int)CommonValue.ActionType.New;
            }
            //Year - Holiday
            logInfo.FieldName = clsMDConstant.MD_COL_HOLIDAY_YEAR + ": " + clsMDConstant.MD_COL_HOLIDAY_DATE;
            logInfo.OldValue = cbbYear.Text + ": " + GetOldSelectedHolidayList();
            logInfo.NewValue = cbbYear.Text + ": " + GetNewSelectedHolidayList(listInsertedDate, listUpdatedDate);
            logBase.LstLogInformation.Add(logInfo);
            return logBase;
        }
        #endregion                       
    }
}
