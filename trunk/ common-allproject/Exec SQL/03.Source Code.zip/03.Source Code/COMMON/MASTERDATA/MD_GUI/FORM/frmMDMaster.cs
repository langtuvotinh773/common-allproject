﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define common character
 * of Master data module.
 */
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Dto;
using System.Collections;
using System;
using System.Reflection;
using Config.Classes; 

namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmMDMaster : Form
	{
		/// <summary>
		/// Date time format
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string FORMAT_DDMMMYYYY = "dd-MMM-yyyy";
		/// <summary>
		/// Deleting string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string DELETING = "Deleting";		
		/// <summary>
		/// Delete string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string DELETE = "delete";
		/// <summary>
		/// Ceiling/Floor string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string CEILING_FLOOR= "Ceiling/floor";
		/// <summary>
		/// Ceiling string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string CEILING = "Ceiling";
		/// <summary>
		/// Floor string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string FLOOR = "Floor";
		/// <summary>
		/// CCY Pair string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string CCY_PAIR = "CCY Pair";
		/// <summary>
		/// Overring string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string OVERRIDING="Overriding";
		/// <summary>
		/// Creating string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string CREATING = "Creating";
		/// <summary>
		/// Modifying string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string MODIFYING = "Modifying";
		/// <summary>
		/// Threshold string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string THRESHOLD = "Threshold";
        /// <summary>
        /// Threshold Date time
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public const string CUTOFFTIME = "Cut-off Time";
		/// <summary>
		/// Quotation string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string QUOTATION = "Quotation";
		//public string NUMBER_FORMAT= "#,###.#####";
		/// <summary>
		/// Note Head string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string NOTE_HEAD = "Free Text 01";
		// <summary>
		/// Note Threshold string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string NOTE_THRESHOLD = "Free Text 02";
		/// <summary>
		/// Note Mid string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string NOTE_MID = "Free Text 03";
		/// <summary>
		/// Note End string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string NOTE_END = "Free Text 04";
		/// <summary>
		/// Max length of note head
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int NOTE_HEAD_MAX_LENGTH = 1000;
		/// <summary>
		/// Max length of note threshold
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int NOTE_THRESHOLD_MAX_LENGTH = 500;
		/// <summary>
		/// Max length of note mid
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int NOTE_MID_MAX_LENGTH = 2500;
		/// <summary>
		/// Max length of note end
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int NOTE_END_MAX_LENGTH = 1000;
        public string DECIMAL_FORMAT = "#,###";

        Size oldSize = new Size(0, 0); // use for process event maximize and minimize
        Point oldPos = new Point(0, 0);

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmMDMaster()
		{
			InitializeComponent();
			SetFormStyleCommon();
		}

        /// <summary>
        /// frmMDMaster_Load & CloseTheForm Used to resole
        /// [When this screen has already openned. If click again,this screen will be focused. (don't open more)]
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMDMaster_Load(object sender, EventArgs e)
        {
            int numberOfFormOpening = 0;
            int countRepeatMaker = 0;
            int countRepeatApprover = 0;
            foreach (Form OpenForm in Application.OpenForms)
            {                
                if (OpenForm.Name.CompareTo("frmMDProcessingDailyQuotation")==0)
                {
                    if (OpenForm.Text.CompareTo(clsMDConstant.PROCESSING_DAILY_QUOTATION_APPROVER) == 0)
                    {
                        countRepeatApprover++;
                    }
                    if (OpenForm.Text.CompareTo(clsMDConstant.PROCESSING_DAILY_QUOTATION_MAKER) == 0)
                    {
                        countRepeatMaker++;
                    }
                }
                if (OpenForm.GetType() == this.GetType().UnderlyingSystemType)
                {
                    if (countRepeatApprover == 0 && countRepeatMaker == 0)
                    {
                        numberOfFormOpening++;
                    }
                    else if ((countRepeatApprover <= 2 || countRepeatMaker <= 2) && countRepeatApprover != countRepeatMaker)
                    {
                        numberOfFormOpening++;
                    }
                    if (numberOfFormOpening > 1)
                    {
                        if (!OpenForm.Modal)
                        {
                            if (!DesignMode)
                            {
                                this.BeginInvoke(new Phoenix.Common.Functions.clsError.InvokeDelegate(CloseTheForm));
                            }
                            OpenForm.Activate();
                            Application.OpenForms[OpenForm.Name].BringToFront();
                        }
                        else
                        {
                            Application.OpenForms[OpenForm.Name].DialogResult = DialogResult.None;
                            Application.OpenForms[OpenForm.Name].Close();
                        }
                        return;
                    }
                }
            }
        }

        /// <summary>
        /// frmMDMaster_Load & CloseTheForm Used to resole
        /// [When this screen has already openned. If click again,this screen will be focused. (don't open more)]
        /// </summary>
        private void CloseTheForm()
        {
            this.Close();
        }

        /// <summary>
        /// process special event
        /// </summary>
        /// <param name="m"></param>
        protected override void WndProc(ref Message m)
        {
            if (this.Parent != null)
            {
                if (m.Msg == 0x0112) // WM_SYSCOMMAND
                {
                    if (m.WParam == new IntPtr(0xF032))
                    {
                        m.WParam = new IntPtr(0xF030);
                    }
                    if (m.WParam == new IntPtr(0xF030)) // SC_MINIMIZE
                    {
                        if (this.Size != this.Parent.ClientSize)
                        {
                            //save size and location
                            oldSize = this.Size;
                            oldPos = this.Location;


                            m.WParam = new IntPtr(0xF120); // normal windown
                            this.Size = this.Parent.ClientSize;
                            this.Location = new Point(0, 0);
                        }
                        else
                        {
                            m.WParam = new IntPtr(0xF120);
                            this.Size = oldSize;
                            this.Location = oldPos;
                        }


                    }

                    if (m.WParam == new IntPtr(0xF012))
                    {
                        if (this.Parent != null)
                        {
                            if (this.Size == this.Parent.ClientSize)
                            {
                                return;
                            }
                        }
                    }
                    //  Console.WriteLine(m.ToString());
                    m.Result = new IntPtr(0);
                }
            }
            base.WndProc(ref m);
        }

        /// <summary>
        /// Call a delegate function
        /// </summary>
        /// <param name="method"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        object InvokeMethod(Delegate method, params object[] args)
        {
            return method.DynamicInvoke(args);
        }        

		/// <summary>
		/// load currency pair list for combobobx
		/// </summary>
		/// <param name="cbb">Combobox to be loaded</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void LoadCurrencyPair(ComboBox cbb)
		{
			cbb.DataSource = clsMDGetDataCombobox.Instance().CurrencyPair;
			cbb.ValueMember = clsMDConstant.VALUE;
			cbb.DisplayMember = clsMDConstant.DISPLAY;
		}
		public void LoadCurrencyPairWithoutEmptyItem(ComboBox cbb)
		{
			cbb.DataSource = clsMDGetDataCombobox.Instance().CurrencyPairWithoutEmptyItem;
			cbb.ValueMember = clsMDConstant.VALUE;
			cbb.DisplayMember = clsMDConstant.DISPLAY;
		}

		/// <summary>
		/// Get formated string
		/// </summary>
		/// <param name="strNumber">Number object to be formated</param>
		/// <param name="strFormat">Format form</param>
		/// <returns>The formated string</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string FormatNumber(object strNumber, string strFormat)
		{
			if (strNumber.ToString().Trim() == "")
				return "";
			GetFormat(ref strFormat);
			//Console.WriteLine((double.Parse(strNumber.ToString()).ToString(strFormat)));
			return (double.Parse(strNumber.ToString()).ToString(strFormat));
		}
	
		/// <summary>
		/// Get the format string
		/// </summary>
		/// <param name="strFormat">Format string</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void GetFormat(ref string strFormat)
		{
			//_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)
			if (strFormat.Contains('_') && strFormat.Contains('*'))
			{
				strFormat = strFormat.Replace("_", "");
				int iStartInd = strFormat.IndexOf('#');
				int iEndIndex = strFormat.IndexOf(')');
				strFormat = strFormat.Substring(iStartInd, iEndIndex - iStartInd);
			}
			else if (strFormat.Contains('_'))
			{
				strFormat = strFormat.Replace("_", "");
				int iStartInd = strFormat.IndexOf('#');
				int iEndIndex = strFormat.IndexOf(')');
				strFormat = strFormat.Substring(iStartInd, iEndIndex - iStartInd);
			}
		}

		/// <summary>
		/// Set common style for all forms in master project
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void SetFormStyleCommon()
		{
			this.BackColor = clsMDConstant.BG_FORM;
			this.MaximizeBox = false;
			this.FormBorderStyle = FormBorderStyle.FixedSingle;
			SetFormStyleCommon(this);
		}

		/// <summary>
		/// Set common style for all controls in LG project
		/// </summary>
		/// <param name="controls"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        public virtual void SetFormStyleCommon(Control controls)
        {
            foreach (Control c in controls.Controls)
            {
                if (c is Label)
                    c.BackColor = clsMDConstant.BG_FORM;
                else if (c is DataGridView)
                {
                    DataGridView grid = (DataGridView)c;

                    grid.AllowUserToOrderColumns = false;
                    grid.AllowUserToResizeRows = false;
                    grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                    grid.EnableHeadersVisualStyles = false;
                    grid.ColumnHeadersDefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
                    grid.CellClick += new DataGridViewCellEventHandler(grid_CellClick);
                    grid.DefaultCellStyle.SelectionBackColor = clsCommonStyles.Instance().DGVSelectionBackColor;  //clsCommonStyles.Instance().DGVReadOnlyColumnBG;		
                    grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
                    grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    //2013.06.12 ADD vlhcnhung S Background of Grid
                    if (grid.Name.CompareTo("dtgCCYPair") != 0)
                    {
                        clsCommonStyles style = new clsCommonStyles();
                        grid.AlternatingRowsDefaultCellStyle = style.DGVAlternatingRowsDefaultCellStyle;
                    }
                    //2013.06.12 ADD vlhcnhung E Background of Grid

                    grid.AllowUserToAddRows = false;
                    grid.AllowUserToDeleteRows = false;
                    grid.AllowUserToResizeColumns = false;

                    if (grid.ReadOnly == true)
                    {
                        grid.DefaultCellStyle.BackColor = clsMDConstant.BG_DGV_READONLY_COLUMN;
                    }

                    for (int i = 0; i < grid.Columns.Count; i++)
                    {
                        if (grid.Columns[i].ReadOnly == true)
                        {
                            grid.Columns[i].DefaultCellStyle.BackColor = clsMDConstant.BG_DGV_READONLY_COLUMN;
                        }
                        grid.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                    Type dgvType = grid.GetType();
                    PropertyInfo pi = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
                    pi.SetValue(grid, true, null);
                }
                else if (c is Button)
                {
                    c.BackColor = clsMDConstant.BG_BUTTON;
                }
                else if (c is GroupBox)
                {
                    SetFormStyleCommon(c);
                }
                else if (c is UserCtrl.DisableTextBox)
                {
                    c.BackColor = clsMDConstant.BG_TEXTBOX_READONLY;
                    c.ForeColor = Color.Black;
                }
                else if (c is TextBox)
                {
                    c.ImeMode = ImeMode.Disable;
                }
                else if (c is ComboBox)
                {
                    ((ComboBox)c).DropDownStyle = ComboBoxStyle.DropDownList;
                }
                if (c.HasChildren)
                    SetFormStyleCommon(c);
            }
        }

		/// <summary>
		/// Gridview header cell click event (sort and align header content to be center)
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		void grid_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			DataGridView grid = (DataGridView) sender;
			if (e.RowIndex == -1 && e.ColumnIndex != -1)
			{
				DataGridViewCheckBoxColumn column = grid.Columns[e.ColumnIndex] as DataGridViewCheckBoxColumn;
				if (column == null)
				{
                    if (grid.Columns[e.ColumnIndex].Name.CompareTo("colCSB") != 0 && grid.Columns[e.ColumnIndex].Name.CompareTo("colCSS") != 0)
                    {
                        grid.Columns[e.ColumnIndex].SortMode = DataGridViewColumnSortMode.Automatic;
                    }
				}
				//if (e.ColumnIndex != 0)
				//    grid.Columns[e.ColumnIndex].SortMode = DataGridViewColumnSortMode.Automatic;
				for (int i = 0; i < grid.Columns.Count; i++)
					if (i != e.ColumnIndex)
					{
						grid.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
						grid.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
					}
			}
		}

		/// <summary>
		/// load currency list for combobobx
		/// </summary>
		/// <param name="cbb">Combobox to be loaded</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void LoadCurrency(ComboBox cbb)
		{
			cbb.DataSource = clsMDGetDataCombobox.Instance().Currency;
			cbb.DisplayMember = clsMDConstant.DISPLAY;
			cbb.ValueMember = clsMDConstant.VALUE;
		}

		public void LoadCurrencyWithoutEmptyItem(ComboBox cbb)
		{
			cbb.DataSource = clsMDGetDataCombobox.Instance().CurrencyWithoutEmptyItem;
			cbb.DisplayMember = clsMDConstant.DISPLAY;
			cbb.ValueMember = clsMDConstant.VALUE;
		}
		
		/// <summary>
		/// load transaction type list for combobobx
		/// </summary>
		/// <param name="cbb">Combobox to be loaded</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void LoadTransactionType(ComboBox cbb)
		{
			cbb.DataSource = clsMDGetDataCombobox.Instance().TransactionType;
			cbb.DisplayMember = clsMDConstant.DISPLAY;
			cbb.ValueMember = clsMDConstant.VALUE;
		}

		/// <summary>
		/// load status list for combobobx
		/// </summary>
		/// <param name="cbb">Combobox to be loaded</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void LoadStatus(ComboBox cbb)
		{
			cbb.DataSource = clsMDGetDataCombobox.Instance().Status;
			cbb.ValueMember = clsMDConstant.VALUE;
			cbb.DisplayMember = clsMDConstant.DISPLAY;
		}

        /// <summary>
        /// Load Status combobox in case Inquiry Quotation History
        /// </summary>
        /// <param name="cbb"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        public void LoadStatusInquiryQuotationHistory(ComboBox cbb)
        {
            List<CbbObject> value = new List<CbbObject>();
            value.Add(new CbbObject(-1, string.Empty));
            value.Add(new CbbObject((int)CommonValue.QuotationStatus.Approved, clsMDConstant.QUOTATIONSTATUS_03_APPROVED));
            value.Add(new CbbObject((int)CommonValue.QuotationStatus.Obsolete, clsMDConstant.QUOTATIONSTATUS_07_OBSOLUTE));

            cbb.DataSource = value;
			cbb.ValueMember = clsMDConstant.VALUE;
			cbb.DisplayMember = clsMDConstant.DISPLAY;

            cbb.SelectedIndex = 0;
        }

        /// <summary>
        /// Load Status combobox in case Inquiry Quotation History
        /// </summary>
        /// <param name="cbb"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        public void LoadOfficerStaffLockoutComboBox(ComboBox cbb)
        {
            List<CbbObject> value = new List<CbbObject>();
            value.Add(new CbbObject(-1, string.Empty));
            value.Add(new CbbObject(1, "Yes"));
            value.Add(new CbbObject( 0, "No"));            
            //
            cbb.DataSource = value;
            cbb.ValueMember =clsMDConstant.VALUE;
            cbb.DisplayMember = clsMDConstant.DISPLAY;
            //default value
            cbb.SelectedIndex = 0;
        }

        /// <summary>
        /// Load Is Active combobox in case Inquiry Quotation History
        /// </summary>
        /// <param name="cbb"></param>
        /// @cond
        /// Author: vlhcnhung        
        /// @endcond
        public void LoadIsActiveComboBox(ComboBox cbb)
        {
            List<CbbObject> value = new List<CbbObject>();
            value.Add(new CbbObject(-1, "All"));
            value.Add(new CbbObject(1, "Active"));
            value.Add(new CbbObject(0, "InActive"));
            //
            cbb.DataSource = value;
            cbb.ValueMember = clsMDConstant.VALUE;
            cbb.DisplayMember = clsMDConstant.DISPLAY;
            //default value
            cbb.SelectedIndex = 0;
        }

		/// <summary>
		/// Get text of status belonging to to the id
		/// </summary>
		/// <param name="iStatus"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string GetStatusText(int iStatus)
		{
			switch (iStatus)
			{
				case (int) CommonValue.QuotationStatus.New:
					return clsMDConstant.QUOTATIONSTATUS_01_NEW;
				case (int) CommonValue.QuotationStatus.WaitForApprove:
					return clsMDConstant.QUOTATIONSTATUS_02_WAIITING_FOR_APPROVE;
				case (int) CommonValue.QuotationStatus.Approved:
					return clsMDConstant.QUOTATIONSTATUS_03_APPROVED;
				case (int) CommonValue.QuotationStatus.Withdrawn:
					return clsMDConstant.QUOTATIONSTATUS_04_WITHDRAWN;
				case (int) CommonValue.QuotationStatus.Returned:
					return clsMDConstant.QUOTATIONSTATUS_05_RETURNED;
				case (int) CommonValue.QuotationStatus.Suspended:
					return clsMDConstant.QUOTATIONSTATUS_06_SUSPENDED;
				case (int) CommonValue.QuotationStatus.Obsolete:
					return clsMDConstant.QUOTATIONSTATUS_07_OBSOLUTE;
				default:
					return "";
			}
		}

		/// Get text of status belonging to to the id
		/// </summary>
		/// <param name="strStatus">atus string<</param>
		/// <returns>Status value</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int GetStatusValue(string strStatus)
		{
			switch (strStatus)
			{
				case clsMDConstant.QUOTATIONSTATUS_01_NEW:
					return (int)CommonValue.QuotationStatus.New;

				case clsMDConstant.QUOTATIONSTATUS_02_WAIITING_FOR_APPROVE:
					return (int)CommonValue.QuotationStatus.WaitForApprove;

				case clsMDConstant.QUOTATIONSTATUS_03_APPROVED:
					return (int)CommonValue.QuotationStatus.Approved;

				case clsMDConstant.QUOTATIONSTATUS_04_WITHDRAWN:
					return (int)CommonValue.QuotationStatus.Withdrawn;

				case clsMDConstant.QUOTATIONSTATUS_05_RETURNED:
					return (int)CommonValue.QuotationStatus.Returned;

				case clsMDConstant.QUOTATIONSTATUS_06_SUSPENDED:
					return (int)CommonValue.QuotationStatus.Suspended;

				case clsMDConstant.QUOTATIONSTATUS_07_OBSOLUTE:
					return (int)CommonValue.QuotationStatus.Obsolete;
				default:
					return -1;
			}
		}

		/// <summary>
		/// Format for number with non-limited decimal
		/// </summary>
		/// <param name="dValue">Value to be formated</param>
		/// <returns>Formated string</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string FormatNumber(decimal dValue)
		{
			string strValue = dValue.ToString();
            string strFormat = DECIMAL_FORMAT;
			if (strValue.Contains('.'))
			{
				int iDecimalCount = strValue.Length - strValue.IndexOf('.');
				strFormat = strFormat + '.';
				for (int i = 0; i < iDecimalCount; i++)
					strFormat = strFormat + '#';
			}
			return dValue.ToString(strFormat);
		}

        /// <summary>
        /// Get format string for decimal
        /// </summary>
        /// <param name="dValue"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public string GetFormatDecimal(decimal dValue)
        {
            string strValue = dValue.ToString();
            string strFormat = DECIMAL_FORMAT;
            if (strValue.Contains('.'))
            {
                int iDecimalCount = strValue.Length - strValue.IndexOf('.');
                strFormat = strFormat + '.';
                for (int i = 0; i < iDecimalCount; i++)
                    strFormat = strFormat + '#';
            }
            return strFormat;
        }

        /// <summary>
        /// Get List object of User Action 
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public List<CbbObject> GetListUserAction()
        {
           return clsMDBus.Instance().GetListMDParameters(clsMDConstant.PARAMETERS_USER_ACTION_LOG_HISTORY);
        }

        /// <summary>
        /// load customer type list for combobobx
        /// </summary>
        /// <param name="cbb">Combobox to be loaded</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void LoadCustomerType(ComboBox cbb)
        {
            cbb.DataSource = clsMDGetDataCombobox.Instance().CustomerType;
            cbb.DisplayMember = clsMDConstant.DISPLAY;
            cbb.ValueMember = clsMDConstant.VALUE;
        }

        ///// <summary>
        ///// load customer name list for combobobx
        ///// </summary>
        ///// <param name="cbb">Combobox to be loaded</param>
        ///// @cond
        ///// Author: pqkhai
        ///// @endcond
        //public void LoadCustomerName(ComboBox cbb)
        //{
        //    cbb.DataSource = clsMDGetDataCombobox.Instance().CustomerName;
        //    cbb.DisplayMember = clsMDConstant.DISPLAY;
        //    cbb.ValueMember = clsMDConstant.VALUE;
        //}

        /// <summary>
        /// load customer code list for combobobx
        /// </summary>
        /// <param name="cbb">Combobox to be loaded</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void LoadCustomerCode(ComboBox cbb)
        {
            cbb.DataSource = clsMDGetDataCombobox.Instance().CustomerCode;
            cbb.DisplayMember = clsMDConstant.DISPLAY;
            cbb.ValueMember = clsMDConstant.VALUE;
        }

        /// <summary>
        /// load FXAT Code list for combobobx
        /// </summary>
        /// <param name="cbb">Combobox to be loaded</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void LoadFXATCode(ComboBox cbb)
        {
            cbb.DataSource = clsMDGetDataCombobox.Instance().FXATCode;
            cbb.DisplayMember = clsMDConstant.DISPLAY;
            cbb.ValueMember = clsMDConstant.VALUE;
        }

        /// <summary>
        /// load Location Code list for combobobx
        /// </summary>
        /// <param name="cbb">Combobox to be loaded</param>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public void LoadLocationCode(ComboBox cbb)
        {
            cbb.DataSource = clsMDGetDataCombobox.Instance().LocationCode;
            cbb.DisplayMember = clsMDConstant.DISPLAY;
            cbb.ValueMember = clsMDConstant.VALUE;
        }
	}
}
