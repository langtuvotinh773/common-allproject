﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-02 16:45:18 +0700 (Sat, 02 Mar 2013) $
 * $Revision: 9331 $ 
 * ========================================================
 * This class is used to transfer data fields between layers 
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Security.Dto
{
    public class clsSEDto
    {
        public string Department { get; set; }
        public int DepartmentId { get; set; }

        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public string Remark { get; set; }

        public int FnCategoryID { get; set; }
        public string FnCategoryName { get; set; }

        public string ParentID { get; set; }

        public int FunctionID { get; set; }
        public string ControlName { get; set; }
        public string FunctionName { get; set; }

        public int MenuItemId { get; set; }
        public string MenuControlName { get; set; }
        public string MenuItemName { get; set; }

        public string Filter { get; set; }

        public int UserNo { get; set; }
    }
}
