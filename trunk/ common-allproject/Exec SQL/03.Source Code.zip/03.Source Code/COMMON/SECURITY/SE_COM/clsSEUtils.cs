﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-13 15:43:08 +0700 (Wed, 13 Mar 2013) $
 * $Revision: 10648 $ 
 * ========================================================
 * This class is used to provide common utility functions
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Phoenix.Common.Popup;

using Phoenix.Common.Security.Bus;

namespace Phoenix.Common.Security.Com
{
    public enum SEAction
    {
        CreateNewRole,
        ModifyExistingRole,
        CreateParentForm,
        CreateParentMenu,
        CreateChildAction,
        CreateChildMenu,
        FormActionMgmt,
        MenuItemMgmt,
        ModifyFunction
    }

    public enum MessageType : int
    {
        Confirm = 0,
        Error = 1,
        Information = 2,
        YesNoConfirm = 3
    }

    public class clsSEUtils
    {
        /// <summary>
        /// Fill items and reset selected index for this combobox.
        /// </summary>		
        /// <param name="cbb">Combobox to fill items</param>
        /// <param name="source">A list of items data source</param>
        /// <param name="valueMember">The string that represent a value member property</param>
        /// <param name="displayMember">The string that represent a display member property</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        //public static void LoadComboBoxWithIndex(ComboBox cbb, DataTable source, string valueMember, string displayMember)
        //{
        //    if (source != null)
        //    {
        //        cbb.DataSource = source;
        //        cbb.ValueMember = valueMember;
        //        cbb.DisplayMember = displayMember;
        //        //cbb.SelectedIndex = cbb.Items.Count - 1;
        //    }
        //}

        /// <summary>
        /// Fill items for this combobox.
        /// </summary>		
        /// <param name="cbb">Combobox to fill items</param>
        /// <param name="source">A list of items data source</param>
        /// <param name="valueMember">The string that represent a value member property</param>
        /// <param name="displayMember">The string that represent a display member property</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public static void LoadComboBox(ComboBox cbb, DataTable source, string valueMember, string displayMember)
        {
            if (source != null)
            {
                cbb.ValueMember = valueMember;
                cbb.DisplayMember = displayMember;
                cbb.DataSource = source;
            }
        }

        /// <summary>
        /// Add an empty row to datatable.
        /// </summary>		
        /// <param name="dt">Datatable object to add empty row</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public static void AddEmptyRowToDataTable(DataTable dt)
        {
            if (dt != null)
            {
                DataRow emptyRow = dt.NewRow();
                emptyRow[0] = -1;
                emptyRow[1] = "";
                dt.Rows.InsertAt(emptyRow, 0);
            }
        }

        public static DialogResult ShowMessage(int type, string msg)
        {
            frmPhoenixMessage frmMsg = new frmPhoenixMessage(type, msg);
            return frmMsg.ShowDialog();
        }
    }

    public class SETreeNode : TreeNode
    {
        public string ParentId { get; set; }
        public int MenuItemId { get; set; }
        public int FunctionId { get; set; }
        public int CategoryId { get; set; }
        public string ControlName { get; set; }
        public string CategoryName { get; set; }
    }
}
