﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-27 15:28:24 +0700 (Wed, 27 Mar 2013) $
 * $Revision: 9331 $ 
 * ========================================================
 * This class is used to provide common messages
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Security.Com
{
    class clsSEMessage
    {
        public static readonly string CONFIRM_SAVE_ROLE = "{0} you want to save this role?";
        public static readonly string CONFIRM_SAVE_FUNCTION = "{0} you want to save this function?";
        public static readonly string CONFIRM_SAVE_MENU = "{0} you want to save this menu?";
        public static readonly string CONFIRM_DELETE_ROLE = "{0} you want to delete this role?";
        public static readonly string CONFIRM_DELETE_FUNCTION = "{0} you want to delete this function?";
        public static readonly string CONFIRM_DELETE_MENU = "{0} you want to delete this menu?";
        public static readonly string CONFIRM_ASSIGN_RIGHT = "{0} you want to assign these rights to this role?";
        public static readonly string CONFIRM_ASSIGN_ROLE = "{0} you want to save these changes?";

        public static readonly string CAN_NOT_BLANK = "{0} can not be blank";
        public static readonly string PLEASE_INPUT = "Please input {0}";

        public static readonly string SAVE_SUCCESS = "Saving is successful";
        public static readonly string SAVE_UNSUCCESS = "Saving is fail";
        public static readonly string MODIFY_SUCCESS = "Modifying is successfully";
        public static readonly string MODIFY_UNSUCCESS = "Modifying is fail";
        public static readonly string DELETE_SUCCESS = "Deleting is successfully";
        public static readonly string DELETE_UNSUCCESS = "Deleting is fail";

        public static readonly string THERE_IS_NO = "There is no {0} ";
        public static readonly string NOT_A_PARENT_FN = "The selected function item is not a parent";
        public static readonly string NOT_A_PARENT_MENU = "The selected menu item is not a parent";
        public static readonly string INVALID_FN = "The selected function item is invalid";
        public static readonly string INVALID_MENU = "The selected menu item is invalid";
        public static readonly string DUPLICATE_MENU = "Can not insert a duplicate menu item";
        public static readonly string DUPLICATE_ROLE = "This role already existed in system";
        public static readonly string SELECT_ROLE_TO_MODIFY = "Please select a role to modify";
        public static readonly string SELECT_ROLE_TO_DELETE = "Please select a role to delete";
        public static readonly string CANNOT_DELETE_ROLE = "This role can't deleted because one or some users were assigned to";
        public static readonly string CANNOT_DELETE_FN = "This function can't deleted because it was already assigned to a role";
        public static readonly string CANNOT_DELETE_MENU = "This menu can't deleted because it was already assigned to a role";
    }
}