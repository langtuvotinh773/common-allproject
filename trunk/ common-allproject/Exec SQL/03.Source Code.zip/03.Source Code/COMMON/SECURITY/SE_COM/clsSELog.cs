﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;
using System.Collections;
using System.Windows.Forms;
using System.Xml;
using System.Data.SqlClient;

using Microsoft.Office;
using Phoenix.Common.Security.Dal;

namespace Phoenix.Common.Security.Com
{
    /// <summary>
    /// Summary description for LogBase
    /// </summary>
    public class clsSELog
    {
        #region Global Variables
        //+ User ID
        private string userID = String.Empty;
        //+ Application Name
        private string applicationName = String.Empty;
        //+ Key
        private string key = String.Empty;
        //+ Action
        //-> 1: Insert
        //-> 2: Update
        //-> 3: Delete
        private int action = 0;
        private string module = "";
        //+ List of [Log Information]
        private List<clsSELogInfo> lstLogInformation = new List<clsSELogInfo>();
        #endregion

        #region Properties
        //+ User ID
        public string UserID
        {
            get
            {
                return userID;
            }
            set
            {
                userID = value;
            }
        }
        //+ Application Name
        public string ApplicationName
        {
            get
            {
                return applicationName;
            }
            set
            {
                applicationName = value;
            }
        }
        //+ Key
        public string Key
        {
            get
            {
                return key;
            }
            set
            {
                key = value;
            }
        }
        //+ Action
        //-> 1: Insert
        //-> 2: Update
        //-> 3: Delete
        public int Action
        {
            get
            {
                return action;
            }
            set
            {
                action = value;
            }
        }
        //+ Module
        //-> 1: COM
        //-> 2: MD
        //-> 3: CPA
        //-> 4: ...
        public string Module
        {
            get
            {
                return module;
            }
            set
            {
                module = value;
            }
        }
        //+ List of [Log Information]
        public List<clsSELogInfo> LstLogInfo
        {
            get
            {
                return lstLogInformation;
            }
            set
            {
                lstLogInformation = value;
            }
        }
        #endregion

        #region Member Method
        /// <summary>
        /// Wirte Log
        /// </summary>
        /// <param name="m_DAL"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        public void WriteLog(clsSEDal objDAL)
        {
            #region Declaration
            string content = String.Empty;
            #endregion

            #region Build Content Structure
            XmlDocument xml = new XmlDocument();
            XmlElement root = xml.CreateElement("LogContent");
            root.SetAttribute("Key", this.Key);
            xml.AppendChild(root);

            foreach (clsSELogInfo logInfo in this.lstLogInformation)
            {
                //+ Field
                XmlElement child = xml.CreateElement("Field");
                //+ Set Attribute [Name]
                child.SetAttribute("Name", logInfo.FieldName);
                //+ Log For Updating
                if (this.Action == 2)
                {
                    //+ Old Value
                    XmlElement oldValueNode = xml.CreateElement("OldValue");
                    oldValueNode.InnerText = logInfo.OldValue;
                    child.AppendChild(oldValueNode);
                    //+ New Value
                    XmlElement newValueNode = xml.CreateElement("NewValue");
                    newValueNode.InnerText = logInfo.NewValue;
                    child.AppendChild(newValueNode);
                }
                //+ Log For Inserting
                else
                {
                    //+ Value
                    XmlElement newValueNode = xml.CreateElement("Value");
                    newValueNode.InnerText = logInfo.NewValue;
                    child.AppendChild(newValueNode);
                }

                //+ Append Child
                root.AppendChild(child);
            }
            content = xml.OuterXml;
            #endregion

            #region Write Log
            SqlParameter[] parameters = new SqlParameter[5];
            parameters[0] = new SqlParameter("@user", this.UserID);
            parameters[1] = new SqlParameter("@appName", this.ApplicationName);
            parameters[2] = new SqlParameter("@content", content);
            parameters[3] = new SqlParameter("@action", this.Action);
            parameters[4] = new SqlParameter("@module", this.Module);

            objDAL.ExecuteNonQueryNonReplyWithTransaction("spCOM_InsertHistory", System.Data.CommandType.StoredProcedure, parameters);
            #endregion
        }
        #endregion
    }

    /// <summary>
    /// Summary description for clsLGLogInformation
    /// </summary>
    public class clsSELogInfo
    {
        #region Global Variables
        //+ Field Name
        string fieldName = String.Empty;
        //+ Old Value
        string oldValue = String.Empty;
        //+ New Value
        string newValue = String.Empty;
        #endregion

        #region Properties
        //+ Field Name
        public string FieldName
        {
            get
            {
                return fieldName;
            }
            set
            {
                fieldName = value;
            }
        }
        //+ Old Value
        public string OldValue
        {
            get
            {
                return oldValue;
            }
            set
            {
                oldValue = value;
            }
        }
        //+ New Value
        public string NewValue
        {
            get
            {
                return newValue;
            }
            set
            {
                newValue = value;
            }
        }
        #endregion
    }
}