﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-08 14:18:05 +0700 (Fri, 08 Mar 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This class is used to authorize rights for each user 
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

using Config.Classes;
using Phoenix.Common.Security.Bus;

namespace Phoenix.Common.Security.Com
{
    public class clsSEAuthorizer
    {
        private List<String> AuthorizedList = null;
        private List<String> UnAuthorizedList = null;
        private clsSEBus _SEBus = null;

        public clsSEAuthorizer(int userNo, string screenName)
        {
            _SEBus = new clsSEBus();
            AuthorizedList = _SEBus.GetAuthorizedFunctionList(userNo, screenName);
            UnAuthorizedList = _SEBus.GetUnAuthorizedFunctionList(userNo, screenName);
        }

        public clsSEAuthorizer(int userNo)
        {
            _SEBus = new clsSEBus();
            AuthorizedList = _SEBus.GetAuthorizedMenuListByUser(userNo);
            UnAuthorizedList = _SEBus.GetUnAuthorizedMenuListByUser(userNo);
        }

        /// <summary>
        /// Check the authorization on screen.
        /// </summary>		
        /// <param name="frm">The form object to authorize</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public void CheckAuthorizationOnScreen(Control frm)
        {
            DisableAllUnauthorizedFuntions(frm);
            EnableAllAuthorizedFuntions(frm);
        }

        /// <summary>
        /// Disable all unauthorized functions on this screen.
        /// </summary>		
        /// <param name="screen">The form object to authorize</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void DisableAllUnauthorizedFuntions(Control screen)
        {
            foreach (Control c in screen.Controls)
            {
                if (c.GetType() == typeof(ToolStrip))
                {
                    foreach (ToolStripItem ts in ((ToolStrip)c).Items)
                    {
                        foreach (string name in UnAuthorizedList)
                        {
                            if (ts.Name.Equals(name))
                            {
                                ts.Enabled = false;
                                ts.Tag = false;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    foreach (string name in UnAuthorizedList)
                    {
                        if (c.Name.Equals(name))
                        {
                            c.Enabled = false;
                            c.Tag = false;
                            break;
                        }
                    }
                }
                if (c.Controls.Count > 0)
                {
                    DisableAllUnauthorizedFuntions(c);
                }
                else
                {
                    foreach (string name in UnAuthorizedList)
                    {
                        if (c.Name.Equals(name))
                        {
                            c.Enabled = false;
                            c.Tag = false;
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Enable all authorized functions on this screen.
        /// </summary>		
        /// <param name="screen">The form object to authorize</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void EnableAllAuthorizedFuntions(Control screen)
        {
            foreach (Control c in screen.Controls)
            {
                if (c.GetType() == typeof(ToolStrip))
                {
                    foreach (ToolStripItem ts in ((ToolStrip)c).Items)
                    {
                        foreach (string name in AuthorizedList)
                        {
                            if (ts.Name.Equals(name))
                            {
                                ts.Enabled = true;
                                ts.Tag = true;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    foreach (string name in AuthorizedList)
                    {
                        if (c.Name.Equals(name))
                        {
                            c.Enabled = true;
                            c.Tag = true;
                            break;
                        }
                    }
                }
                if (c.Controls.Count > 0)
                {
                    EnableAllAuthorizedFuntions(c);
                }
                else
                {
                    foreach (string name in AuthorizedList)
                    {
                        if (c.Name.Equals(name))
                        {
                            c.Enabled = true;
                            c.Tag = true;
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Disable all menu items.
        /// </summary>		
        /// <param name="menu">The ToolStripMenuItem object to authorize</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public void DisableAllMenuItems(ToolStripMenuItem menu)
        {
            foreach (ToolStripItem item in menu.DropDownItems)
            {
                if (item is ToolStripSeparator) continue;
                ToolStripMenuItem menuBtn = item as ToolStripMenuItem;
                if (menuBtn.DropDownItems.Count > 0)
                    DisableAllMenuItems(menuBtn);
                else
                    menuBtn.Enabled = false;
            }
        }

        /// <summary>
        /// Enable all authorized menu items on this screen.
        /// </summary>		
        /// <param name="menu">The ToolStripMenuItem object to authorize</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public void EnableAllAuthorizedMenuItems(ToolStripMenuItem menu)
        {
            foreach (ToolStripItem item in menu.DropDownItems)
            {
                if (item is ToolStripSeparator) continue;
                ToolStripMenuItem menuBtn = item as ToolStripMenuItem;
                if (menuBtn.DropDownItems.Count > 0)
                    EnableAllAuthorizedMenuItems(menuBtn);
                else
                {
                    foreach (string name in AuthorizedList)
                    {
                        if (menuBtn.Name.Equals(name))
                        {
                            menuBtn.Enabled = true;
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Hide unauthorized menu items.
        /// </summary>		
        /// <param name="menu">The ToolStripMenuItem object to authorize</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public void HideUnauthorizedMenuItems(ToolStripMenuItem menu)
        {
            foreach (ToolStripItem item in menu.DropDownItems)
            {
                if (item is ToolStripSeparator) continue;
                ToolStripMenuItem menuBtn = item as ToolStripMenuItem;
                if (menuBtn.DropDownItems.Count > 0)
                    HideUnauthorizedMenuItems(menuBtn);
                else
                {
                    if (!menuBtn.Enabled)
                    {
                        menuBtn.Enabled = false;
                        menuBtn.Visible = false;
                    }
                    //foreach (string s in UnAuthorizedList)
                    //{
                    //    if (menuBtn.Name.Equals(s))
                    //    {
                    //        menuBtn.Enabled = false;
                    //        menuBtn.Visible = false;
                    //    }
                    //}
                }
            }
        }

        /// <summary>
        /// Hide empty parent menu items.
        /// </summary>		
        /// <param name="parent">The ToolStripMenuItem object to authorize</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int HideEmptyParentMenuItem(ToolStripMenuItem parent)
        {
            int count = 0;
            foreach (ToolStripItem menu in parent.DropDownItems)
            {
                if (menu is ToolStripSeparator) continue;
                ToolStripMenuItem menuBtn = menu as ToolStripMenuItem;

                if (menuBtn.DropDownItems.Count > 0)
                    count += HideEmptyParentMenuItem(menuBtn);
                else
                {
                    if (menuBtn.Enabled)
                        ++count;
                }
            }
            if (count == 0 && parent.DropDownItems.Count > 0)
            {
                parent.Visible = false;
                return 0;
            }
            else
                return 1;
        }
    }
}