﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-02 20:37:30 +0700 (Sat, 02 Mar 2013) $
 * $Revision: 9331 $ 
 * ========================================================
 * This class is used to provide business logic prcessing
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Dal;
using Phoenix.Common.Security.Dto;
using DataEncryption;

namespace Phoenix.Common.Security.Bus
{
    class clsSEBus
    {
        private clsSEDal m_SEDal;

        public clsSEBus()
        {
            m_SEDal = new clsSEDal(Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["SercurityConnectionString"].ToString()));
        }

        /// <summary>
        /// Get a list of menu items.
        /// </summary>		
        /// <param name="categoryId">Id of a category</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet GetMenuItemsList(int categoryId)
        {
            return m_SEDal.GetMenuItemsList(categoryId);
        }

        /// <summary>
        /// Get a list of functions.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet GetFunctionList(clsSEDto dto)
        {
            return m_SEDal.GetFunctionList(dto);
        }

        /// <summary>
        /// Search a list of functions with conditions.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet SearchFunction(clsSEDto dto)
        {
            return m_SEDal.SearchFunction(dto);
        }

        /// <summary>
        /// Get a list of roles was assigned to a user.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet SearchRolesAssignedToUser(clsSEDto dto)
        {
            return m_SEDal.SearchRolesAssignedToUser(dto);
        }

        /// <summary>
        /// Get a list of users was assigned to a role.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond    
        public DataSet SearchUsersAssignedToRole(clsSEDto dto)
        {
            return m_SEDal.SearchUsersAssignedToRole(dto);
        }

        /// <summary>
        /// Get un and assigned functions for a role.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet GetUnassignAssignedFunctions(clsSEDto dto)
        {
            return m_SEDal.GetUnassignAssignedFunctions(dto);
        }

        /// <summary>
        /// Get un and assigned menus for a role.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet GetUnassignAssignedMenus(clsSEDto dto)
        {
            return m_SEDal.GetUnassignAssignedMenus(dto);
        }

        /// <summary>
        /// Get a list of roles.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetRoleList()
        {
            return m_SEDal.GetRoleList();
        }

        /// <summary>
        /// Get a list of role ids and names with an empty item. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetRoleListWithEmptyItem()
        {
            DataTable dt = GetRoleList();
            clsSEUtils.AddEmptyRowToDataTable(dt);
            return dt;
        }

        /// <summary>
        /// Search a list of roles with conditions. 
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable SearchRole(clsSEDto dto)
        {
            return m_SEDal.SearchRole(dto);
        }

        /// <summary>
        /// Get a list of the top most menu items. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetTopMostMenuItemList()
        {
            return m_SEDal.GetTopMostMenuItems();
        }

        /// <summary>
        /// Get a list of menu names with an empty item. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetMemuNameListWithEmptyItem()
        {
            DataTable dt = GetTopMostMenuItemList();
            clsSEUtils.AddEmptyRowToDataTable(dt);
            return dt;
        }

        /// <summary>
        /// Get a list of function names. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetFunctionName()
        {
            return m_SEDal.GetFunctionName();
        }

        /// <summary>
        /// Get a list of function names with an empty item. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetFunctionNameWithEmptyItem()
        {
            DataTable dt = GetFunctionName();
            clsSEUtils.AddEmptyRowToDataTable(dt);
            return dt;
        }

        /// <summary>
        /// Get a list of category ids and names. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetCategoryList()
        {
            return m_SEDal.GetCategoryList();
        }

        /// <summary>
        /// Get a list of category ids and names with an empty item. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetCategoryListWithEmptyItem()
        {
            DataTable dt = GetCategoryList();
            clsSEUtils.AddEmptyRowToDataTable(dt);
            return dt;
        }

        /// <summary>
        /// Get a list of department ids and names. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetDepartmentList()
        {
            return m_SEDal.GetDepartmentList();
        }

        /// <summary>
        /// Get a list of department ids and names with an empty item. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetDepartmentListWithEmptyItem()
        {
            DataTable dt = GetDepartmentList();
            clsSEUtils.AddEmptyRowToDataTable(dt);
            return dt;
        }

        /// <summary>
        /// Get a list of user ids and names. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetUserList()
        {
            return m_SEDal.GetUserList();
        }

        /// <summary>
        /// Gets the list of menu control names.
        /// </summary>
        /// <returns></returns>
        public List<String> GetMenuControlNameList()
        {
            return m_SEDal.GetMenuControlNameList();
        }

        /// <summary>
        /// Get a list of authorized menu items for a specified user. 
        /// </summary>
        /// <param name="userNo">The order number of user</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public List<String> GetAuthorizedMenuListByUser(int userNo)
        {
            return m_SEDal.GetAuthorizedMenuListByUser(userNo);
        }

        /// <summary>
        /// Get a list of unauthorized menu items for a specified user. 
        /// </summary>
        /// <param name="userNo">The order number of user</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public List<String> GetUnAuthorizedMenuListByUser(int userNo)
        {
            return m_SEDal.GetUnAuthorizedMenuListByUser(userNo);
        }

        /// <summary>
        /// Get a list of authorized function items for a specified user. 
        /// </summary>
        /// <param name="userNo">The order number of user</param>
        /// <param name="screenName">The name of the screen</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public List<String> GetAuthorizedFunctionList(int userNo, string screenName)
        {
            return m_SEDal.GetAuthorizedFunctionList(userNo, screenName);
        }

        /// <summary>
        /// Get a list of unauthorized function items for a specified user. 
        /// </summary>
        /// <param name="userNo">The order number of user</param>
        /// <param name="screenName">The name of the screen</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public List<String> GetUnAuthorizedFunctionList(int userNo, string screenName)
        {
            return m_SEDal.GetUnAuthorizedFunctionList(userNo, screenName);
        }

        /// <summary>
        /// Assign functions to a specified role. 
        /// </summary>
        /// <param name="roleId">Id of a role</param>
        /// <param name="funcIds">The list of function ids</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int AssignFunctionsToRole(int roleId, List<Int16> funcIds)
        {
            return m_SEDal.AssignFunctionsToRole(roleId, funcIds);
        }

        /// <summary>
        /// Assign menus to a specified role. 
        /// </summary>
        /// <param name="roleId">Id of a role</param>
        /// <param name="menuIds">The list of menu item ids</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int AssignMenusToRole(int roleId, List<Int16> menuIds)
        {
            return m_SEDal.AssignMenusToRole(roleId, menuIds);
        }

        /// <summary>
        /// Assign users to a specified role. 
        /// </summary>
        /// <param name="userIds">The list of user ids</param>
        /// <param name="roleId">Id of a role</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int AssignUserToRole(List<Int16> userIds, int roleId)
        {
            return m_SEDal.AssignUserToRole(userIds, roleId);
        }

        /// <summary>
        /// Assign users to a specified role. 
        /// </summary>
        /// <param name="roleIds">The list of role ids</param>
        /// <param name="userId">Id of a user</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int AssignRoleToUser(List<Int16> roleIds, int userNo)
        {
            return m_SEDal.AssignRoleToUser(roleIds, userNo);
        }

        /// <summary>
        /// Create a parent function. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateParentFunc(clsSEDto dto)
        {
            return m_SEDal.CreateParentFunc(dto);
        }

        /// <summary>
        /// Create a child(action) function for a created parent function. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateFormAction(clsSEDto dto)
        {
            return m_SEDal.CreateFormAction(dto);
        }

        /// <summary>
        /// Create a menu item. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateMenuItem(clsSEDto dto)
        {
            return m_SEDal.CreateMenuItem(dto);
        }

        /// <summary>
        /// Create a menu item and return the scope identity of this. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateMenuItemAndReturnId(clsSEDto dto)
        {
            return m_SEDal.CreateMenuItemAndReturnId(dto);
        }

        /// <summary>
        /// Select role name. 
        /// </summary>
        /// <param name="dto">Department Id</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetRoleName()
        {
            return m_SEDal.GetRoleName();
        }

        /// <summary>
        /// Create a new role. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateNewRole(clsSEDto dto)
        {
            return m_SEDal.CreateNewRole(dto);
        }

        /// <summary>
        /// Checks the fn is existed.
        /// </summary>
        /// <param name="fnId">The fn id.</param>
        /// <param name="roleId">The role id.</param>
        /// <returns></returns>
        public bool CheckFnIsExisted(Int16 fnId, Int16 roleId)
        {
            return m_SEDal.CheckFnIsExisted(fnId, roleId);
        }

        /// <summary>
        /// Unassigns the A fn to role.
        /// </summary>
        /// <param name="fnId">The fn id.</param>
        /// <param name="roleId">The role id.</param>
        public int UnassignAFnToRole(Int16 fnId, Int16 roleId)
        {
            return m_SEDal.UnassignAFnToRole(fnId, roleId);
        }

        /// <summary>
        /// Checks the menu is existed.
        /// </summary>
        /// <param name="menuId">The menu id.</param>
        /// <param name="roleId">The role id.</param>
        /// <returns></returns>
        public bool CheckMenuIsExisted(Int16 menuId, Int16 roleId)
        {
            return m_SEDal.CheckMenuIsExisted(menuId, roleId);
        }

        /// <summary>
        /// Unassigns the A menu to role.
        /// </summary>
        /// <param name="menuId">The menu id.</param>
        /// <param name="roleId">The role id.</param>
        public int UnassignAMenuToRole(Int16 menuId, Int16 roleId)
        {
            return m_SEDal.UnassignAMenuToRole(menuId, roleId);
        }

        /// <summary>
        /// Checks the user is assigned to role.
        /// </summary>
        /// <param name="roleId">The role id.</param>
        /// <returns></returns>
        public bool CheckUserIsAssignedToRole(Int16 roleId)
        {
            return m_SEDal.CheckUserIsAssignedToRole(roleId);
        }

        /// <summary>
        /// Checks the fn is assigned to role.
        /// </summary>
        /// <param name="fnId">The fn id.</param>
        /// <returns></returns>
        public bool CheckFnIsAssignedToRole(Int16 fnId)
        {
            return m_SEDal.CheckFnIsAssignedToRole(fnId);
        }

        /// <summary>
        /// Checks the menu is assigned to role.
        /// </summary>
        /// <param name="menuId">The menu id.</param>
        /// <returns></returns>
        public bool CheckMenuIsAssignedToRole(Int16 menuId)
        {
            return m_SEDal.CheckMenuIsAssignedToRole(menuId);
        }

        /// <summary>
        /// Modify an existing function. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int ModifyFunction(clsSEDto dto)
        {
            return m_SEDal.ModifyFunction(dto);
        }

        /// <summary>
        /// Modify an existing menu item. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int ModifyMenuItem(clsSEDto dto)
        {
            return m_SEDal.ModifyMenuItem(dto);
        }

        /// <summary>
        /// Modify an existing role. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int ModifyExistingRole(clsSEDto dto)
        {
            return m_SEDal.ModifyExistingRole(dto);
        }

        /// <summary>
        /// Delete an existing function. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteFunction(clsSEDto dto)
        {
            return m_SEDal.DeleteFunction(dto);
        }

        /// <summary>
        /// Delete an existing menu item. 
        /// </summary>
        /// <returns></returns>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteMenuItem(clsSEDto dto)
        {
            return m_SEDal.DeleteMenuItem(dto);
        }

        /// <summary>
        /// Delete an existing role. 
        /// </summary>
        /// <returns></returns>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteRole(int roleId)
        {
            return m_SEDal.DeleteRole(roleId);
        }

        /// <summary>
        /// Delete a list of old roles were assigned to a user.  
        /// </summary>
        /// <returns></returns>
        /// <param name="userNo">Id of a user</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteOldRoleAssignedToUser(int userNo)
        {
            return m_SEDal.DeleteOldRoleAssignedToUser(userNo);
        }

        /// <summary>
        /// Delete a list of old users were assigned to a role.  
        /// </summary>
        /// <returns></returns>
        /// <param name="roleId">Id of a role</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteOldUserAssignedToRole(int roleId)
        {
            return m_SEDal.DeleteOldUserAssignedToRole(roleId);
        }

        /// <summary>
        /// Delete a list of old functions were assigned to a role.  
        /// </summary>
        /// <returns></returns>
        /// <param name="roleId">Id of a role</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteOldFuncAssignedToRole(int roleId)
        {
            return m_SEDal.DeleteOldFuncAssignedToRole(roleId);
        }

        /// <summary>
        /// Delete a list of old menu items were assigned to a role.  
        /// </summary>
        /// <returns></returns>
        /// <param name="roleId">Id of a role</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteOldMenuAssignedToRole(int roleId)
        {
            return m_SEDal.DeleteOldMenuAssignedToRole(roleId);
        }
    }
}