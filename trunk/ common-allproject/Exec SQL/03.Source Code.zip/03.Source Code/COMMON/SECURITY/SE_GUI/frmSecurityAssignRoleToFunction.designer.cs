﻿namespace Phoenix.Common.Security.Gui
{
    partial class frmSecurityAssignRolesToFunction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbbChildControl = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.cbbScreenName = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbGroup = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnDoubleLeft = new System.Windows.Forms.Button();
            this.btnSingleLeft = new System.Windows.Forms.Button();
            this.btnSingleRight = new System.Windows.Forms.Button();
            this.btnDoubleRight = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbbChildControl);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.cbbScreenName);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cbbGroup);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(5, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(436, 97);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // cbbChildControl
            // 
            this.cbbChildControl.FormattingEnabled = true;
            this.cbbChildControl.Location = new System.Drawing.Point(92, 63);
            this.cbbChildControl.Name = "cbbChildControl";
            this.cbbChildControl.Size = new System.Drawing.Size(200, 21);
            this.cbbChildControl.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Child Control";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.button1.Location = new System.Drawing.Point(325, 40);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // cbbScreenName
            // 
            this.cbbScreenName.FormattingEnabled = true;
            this.cbbScreenName.Location = new System.Drawing.Point(92, 41);
            this.cbbScreenName.Name = "cbbScreenName";
            this.cbbScreenName.Size = new System.Drawing.Size(200, 21);
            this.cbbScreenName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Screen Name";
            // 
            // cbbGroup
            // 
            this.cbbGroup.Location = new System.Drawing.Point(92, 19);
            this.cbbGroup.Name = "cbbGroup";
            this.cbbGroup.Size = new System.Drawing.Size(200, 21);
            this.cbbGroup.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Group";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "Admin",
            "Mod",
            "sa",
            "assistant"});
            this.listBox1.Location = new System.Drawing.Point(5, 103);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(197, 121);
            this.listBox1.TabIndex = 10;
            // 
            // btnDoubleLeft
            // 
            this.btnDoubleLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDoubleLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoubleLeft.ForeColor = System.Drawing.Color.Blue;
            this.btnDoubleLeft.Location = new System.Drawing.Point(208, 201);
            this.btnDoubleLeft.Name = "btnDoubleLeft";
            this.btnDoubleLeft.Size = new System.Drawing.Size(30, 23);
            this.btnDoubleLeft.TabIndex = 14;
            this.btnDoubleLeft.Text = "<<";
            this.btnDoubleLeft.UseVisualStyleBackColor = false;
            // 
            // btnSingleLeft
            // 
            this.btnSingleLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSingleLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingleLeft.ForeColor = System.Drawing.Color.Red;
            this.btnSingleLeft.Location = new System.Drawing.Point(208, 168);
            this.btnSingleLeft.Name = "btnSingleLeft";
            this.btnSingleLeft.Size = new System.Drawing.Size(30, 23);
            this.btnSingleLeft.TabIndex = 13;
            this.btnSingleLeft.Text = "<";
            this.btnSingleLeft.UseVisualStyleBackColor = false;
            // 
            // btnSingleRight
            // 
            this.btnSingleRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSingleRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingleRight.ForeColor = System.Drawing.Color.Red;
            this.btnSingleRight.Location = new System.Drawing.Point(208, 136);
            this.btnSingleRight.Name = "btnSingleRight";
            this.btnSingleRight.Size = new System.Drawing.Size(30, 23);
            this.btnSingleRight.TabIndex = 12;
            this.btnSingleRight.Text = ">";
            this.btnSingleRight.UseVisualStyleBackColor = false;
            // 
            // btnDoubleRight
            // 
            this.btnDoubleRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDoubleRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoubleRight.ForeColor = System.Drawing.Color.Blue;
            this.btnDoubleRight.Location = new System.Drawing.Point(208, 103);
            this.btnDoubleRight.Name = "btnDoubleRight";
            this.btnDoubleRight.Size = new System.Drawing.Size(30, 23);
            this.btnDoubleRight.TabIndex = 11;
            this.btnDoubleRight.Text = ">>";
            this.btnDoubleRight.UseVisualStyleBackColor = false;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Items.AddRange(new object[] {
            "operator"});
            this.listBox2.Location = new System.Drawing.Point(244, 103);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(197, 121);
            this.listBox2.TabIndex = 10;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.Location = new System.Drawing.Point(366, 246);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(285, 246);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 15;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            // 
            // frmSecurityAssignRolesToFunction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(447, 281);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDoubleLeft);
            this.Controls.Add(this.btnSingleLeft);
            this.Controls.Add(this.btnSingleRight);
            this.Controls.Add(this.btnDoubleRight);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "frmSecurityAssignRolesToFunction";
            this.Text = "Assign Roles To Function";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbbChildControl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cbbScreenName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbbGroup;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnDoubleLeft;
        private System.Windows.Forms.Button btnSingleLeft;
        private System.Windows.Forms.Button btnSingleRight;
        private System.Windows.Forms.Button btnDoubleRight;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;

    }
}