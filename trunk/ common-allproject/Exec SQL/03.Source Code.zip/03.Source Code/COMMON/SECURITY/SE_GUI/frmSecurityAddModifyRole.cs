﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-08 14:18:05 +0700 (Fri, 08 Mar 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This class is used to add and modify a role
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Security.Bus;
using Phoenix.Common.Security.Dto;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityAddModifyRole : frmSEMaster
    {
        private clsSEBus m_Bus = null;
        private string m_OriginalRoleName = null;
        private int m_OriginalDepartmentId = 0;
        private SEAction m_Action;

        public delegate void SaveRoleCompleted(SEAction action);
        public event SaveRoleCompleted OnSaveRoleCompleted;

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityAddModifyRole" /> class.
        /// </summary>
        /// <param name="action">The action.</param>
        public frmSecurityAddModifyRole(SEAction action)
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();

            m_Action = action;
            if (action == SEAction.CreateNewRole)
            {
                Text = "Create Role";
                btnCancel.Text = "&Close";
            }
            else
            {
                Text = "Modify Role";
                btnCancel.Text = "&Cancel";
            }
            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);
                
                // Get a list of departments
                clsSEUtils.LoadComboBox(cbbDepts, m_Bus.GetDepartmentList(), "DepartmentId", "DepartmentName");
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Fire saving event every time a role was added or modified.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void FireOnSaveRoleEvent(SEAction action)
        {
            if (OnSaveRoleCompleted != null)
            {
                OnSaveRoleCompleted(action);
            }
        }

        /// <summary>
        /// Pass an updating role information from role management screen.
        /// </summary>
        /// <param name="roleId">Id of a function</param>
        /// <param name="roleName">Parent name of function</param>
        /// <param name="dept">Parent id of function</param>
        /// <param name="roleRemark">Category of function</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public void PassUpdateRoleInfo(int roleId, string roleName, string dept, string roleRemark)
        {
            txtRoleName.Tag = roleId;
            txtRoleName.Text = roleName;
            cbbDepts.Text = dept;
            txtRemark.Text = roleRemark;

            m_OriginalRoleName = roleName;
            m_OriginalDepartmentId = Int16.Parse(cbbDepts.SelectedValue.ToString());
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtRoleName.Text.Trim().Length == 0)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.PLEASE_INPUT, "Role Name"));
                txtRoleName.Focus();
                return;
            }
            if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_SAVE_ROLE, "Do")) == DialogResult.Yes)
            {
                // Create role parameters
                clsSEDto dto = new clsSEDto();
                dto.RoleName = txtRoleName.Text;
                dto.DepartmentId = Int16.Parse(cbbDepts.SelectedValue.ToString());
                dto.Remark = txtRemark.Text;

                try
                {
                    // In case of creating new role
                    if (m_Action == SEAction.CreateNewRole)
                    {
                        // Check whether or not a role is duplicate
                        DataRow[] roleInfo = m_Bus.GetRoleName().Select("DepartmentId = '" + dto.DepartmentId + "'");
                        bool isDuplicate = false;
                        foreach (DataRow row in roleInfo)
                        {
                            if (dto.RoleName.Equals(row["RoleName"]))
                            {
                                isDuplicate = true;
                                break;
                            }
                        }
                        if (isDuplicate)
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.DUPLICATE_ROLE);
                            cbbDepts.Focus();
                            return;
                        }
                        // If it's not duplicate, create a new role
                        int recordAffected = m_Bus.CreateNewRole(dto);
                        if (recordAffected > 0)
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                            FireOnSaveRoleEvent(SEAction.CreateNewRole);
                        }
                        else
                            clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
                    }
                    // In case of modifying an existing role
                    else
                    {
                        // Check whether or not a role is duplicate
                        DataTable roleInfo = m_Bus.GetRoleName();
                        bool isDuplicate = false;
                        if (!dto.RoleName.Equals(m_OriginalRoleName) || (Int16.Parse(cbbDepts.SelectedValue.ToString()) != m_OriginalDepartmentId))
                        {
                            foreach (DataRow row in roleInfo.Rows)
                            {
                                if (dto.RoleName.Equals(row["RoleName"]) && (cbbDepts.SelectedValue.Equals(row["DepartmentId"])))
                                {
                                    isDuplicate = true;
                                    break;
                                }
                            }
                            if (isDuplicate)
                            {
                                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.DUPLICATE_ROLE);
                                cbbDepts.Focus();
                                return;
                            }
                        }
                        // If it's not duplicate, modify it.
                        dto.RoleID = Int16.Parse(txtRoleName.Tag.ToString());
                        int recordAffected = m_Bus.ModifyExistingRole(dto);
                        if (recordAffected > 0)
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.MODIFY_SUCCESS);
                            FireOnSaveRoleEvent(SEAction.ModifyExistingRole);
                        }
                        else
                            clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.MODIFY_UNSUCCESS);
                    }
                }
                catch (Exception ex)
                {
                    Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                }

                // Close form after operation
                Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}