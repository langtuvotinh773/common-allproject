﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-08 14:18:05 +0700 (Fri, 08 Mar 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This class is used to provide add and modify a function
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Dal;
using Phoenix.Common.Security.Dto;
using Phoenix.Common.Security.Bus;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityAddModifyFunc : frmSEMaster
    {
        private clsSEBus m_Bus = null;
        private SEAction m_Action;
        private string m_ParentId = null;
        private int m_FnId = 0;

        public delegate void SaveFunction();
        public event SaveFunction OnSaveFunction;

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityAddModifyFunc" /> class.
        /// </summary>
        /// <param name="action">The action.</param>
        public frmSecurityAddModifyFunc(SEAction action)
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();

            m_Action = action;
            if (m_Action == SEAction.CreateParentForm)
            {
                Text = "Create Parent Form";
                lblParent.Text = "Parent Form";
                lblFnName.Text = "Form Title Name";
                btnClose.Text = "Close";
            }
            else if (m_Action == SEAction.CreateChildAction)
            {
                Text = "Create Child Action";
                lblParent.Text = "Parent Form";
                lblFnName.Text = "Action Name";
                btnClose.Text = "Close";
            }
            else
            {
                Text = "Modify Function";
                lblParent.Text = "Parent Function";
                lblFnName.Text = "Function Name";
            }
            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                clsSEUtils.LoadComboBox(cbbCategory, m_Bus.GetCategoryList(), "CategoryId", "CategoryName");
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }   
        }

        /// <summary>
        /// Fire saving event every time a function was added or modified.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void FireSaveFnEvent()
        {
            if (OnSaveFunction != null)
            {
                OnSaveFunction();
            }
        }

        /// <summary>
        /// Pass an updating function information from function management screen.
        /// </summary>
        /// <param name="fnId">Id of a function</param>
        /// <param name="parent">Parent name of function</param>
        /// <param name="parentId">Parent id of function</param>
        /// <param name="category">Category of function</param>
        /// <param name="ctrl">Control name of function</param>
        /// <param name="func">Function name</param>
        /// <param name="desc">Short description</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public void PassUpdateFuncInfo(int fnId, string parent, string parentId, 
            string category, string ctrl, string func, string desc)
        {
            txtParent.Text = parent;
            cbbCategory.Text = category;
            //m_CategoryId = categoryId;
            if (m_Action == SEAction.CreateChildAction)
            {
                m_ParentId = parentId;
                cbbCategory.Enabled = false;
            }
            else // In case of modify
            {
                m_FnId = fnId;
                cbbCategory.Enabled = false;
                txtCtrlName.Text = ctrl;
                txtFnName.Text = func;
                txtDes.Text = desc;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtCtrlName.Text.Trim().Length == 0)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.PLEASE_INPUT, "Control Name"));
                return;
            }
            if (txtFnName.Text.Trim().Length == 0)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.PLEASE_INPUT, "Function Name"));
                return;
            }
            if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_SAVE_FUNCTION, "Do")) == DialogResult.Yes)
            {
                try
                {
                    if (m_Action == SEAction.CreateParentForm)
                    {
                        clsSEDto dto = new clsSEDto();
                        dto.ControlName = txtCtrlName.Text;
                        dto.FunctionName = txtFnName.Text;
                        dto.ParentID = null;
                        dto.FnCategoryID = Int16.Parse(cbbCategory.SelectedValue.ToString());
                        dto.Remark = txtDes.Text;
                        int recordAffected = m_Bus.CreateFormAction(dto);
                        if (recordAffected > 0)
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                            //clsFunction.ShowInfoDialog(clsSEMessage.SAVE_SUCCESS);
                            //clsSELog log = new clsSELog();
                            //log.ApplicationName = this.Text;
                            //log.UserID = clsUserInfo.UserNo.ToString();
                            //log.Action = 1;
                            //log.Key = txtCtrlName.Text + " " + txtFnName.Text + " " + cbbCategory.Text;

                            //clsSELogInfo parentInfo = new clsSELogInfo();
                            //parentInfo.FieldName = lblParent.Text;
                            //parentInfo.NewValue = txtParent.Text;
                            //log.LstLogInfo.Add(parentInfo);

                            //clsSELogInfo categoryInfo = new clsSELogInfo();
                            //categoryInfo.FieldName = lblCategory.Text;
                            //categoryInfo.NewValue = cbbCategory.Text;
                            //log.LstLogInfo.Add(categoryInfo);

                            //clsSELogInfo ctrlNameInfo = new clsSELogInfo();
                            //ctrlNameInfo.FieldName = lblCtrlName.Text;
                            //ctrlNameInfo.NewValue = txtCtrlName.Text;
                            //log.LstLogInfo.Add(ctrlNameInfo);

                            //clsSELogInfo titleInfo = new clsSELogInfo();
                            //titleInfo.FieldName = lblFnName.Text;
                            //titleInfo.NewValue = txtParent.Text;
                            //log.LstLogInfo.Add(titleInfo);

                            //clsSELogInfo desInfo = new clsSELogInfo();
                            //desInfo.FieldName = lblDescription.Text;
                            //desInfo.NewValue = txtDes.Text;
                            //log.LstLogInfo.Add(desInfo);

                            //log.WriteLog();

                            //txtCtrlName.Clear();
                            //txtFnName.Clear();
                            //txtDes.Clear();
                            //txtCtrlName.Focus();
                            FireSaveFnEvent();
                        }
                        else
                            clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
                    }
                    else if (m_Action == SEAction.CreateChildAction)
                    {
                        clsSEDto dto = new clsSEDto();
                        dto.ControlName = txtCtrlName.Text;
                        dto.FunctionName = txtFnName.Text;
                        dto.ParentID = m_ParentId;
                        dto.FnCategoryID = Int16.Parse(cbbCategory.SelectedValue.ToString());
                        dto.Remark = txtDes.Text;
                        int recordAffected = m_Bus.CreateFormAction(dto);
                        if (recordAffected > 0)
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                            FireSaveFnEvent();
                        }
                        else
                            clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
                    }
                    else
                    {
                        clsSEDto dto = new clsSEDto();
                        dto.FunctionID = m_FnId;
                        dto.ControlName = txtCtrlName.Text;
                        dto.FunctionName = txtFnName.Text;
                        dto.ParentID = m_ParentId;
                        dto.FnCategoryID = Int16.Parse(cbbCategory.SelectedValue.ToString());
                        dto.Remark = txtDes.Text;
                        int recordAffected = m_Bus.ModifyFunction(dto);
                        if (recordAffected > 0)
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.MODIFY_SUCCESS);
                            FireSaveFnEvent();
                        }
                        else
                            clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.MODIFY_UNSUCCESS);
                    }
                }
                catch (Exception ex)
                {
                    Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                }

                // Close form after operation
                Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}