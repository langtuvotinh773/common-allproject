﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-25 20:54:48 +0700 (Mon, 25 Mar 2013) $
 * $Revision: 12035 $ 
 * ========================================================
 * This class is used to add and modify a menu item
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Dto;
using Phoenix.Common.Security.Bus;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityAddModifyMenu : frmSEMaster
    {
        private clsSEBus m_Bus = null;
        private string _parentId = null;
        private string m_ChildCtrlName = null;
        private string m_ChildMenuName = null;
        private string m_ChildMenuDesc = null;
        private int m_MenuId = 0;
        private SEAction m_Action;

        public delegate void SaveMenu();
        public event SaveMenu OnSaveMenu;

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityAddModifyMenu" /> class.
        /// </summary>
        /// <param name="action">The action.</param>
        public frmSecurityAddModifyMenu(SEAction action)
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();

            m_Action = action;
            if (m_Action == SEAction.CreateParentMenu)
            {
                Text = "Create Parent Menu";
                lblParent.Text = "Parent Menu";
                lblFnName.Text = "Menu Item Name";
                btnCancel.Text = "Close";
            }
            else if (m_Action == SEAction.CreateChildMenu)
            {
                Text = "Create Child Menu";
                lblParent.Text = "Parent Menu";
                lblFnName.Text = "Menu Name";
                btnCancel.Text = "Close";
            }
            else
            {
                Text = "Modify Menu";
                lblParent.Text = "Parent Menu";
                lblFnName.Text = "Menu Name";
            }
            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                // Load category list
                clsSEUtils.LoadComboBox(cbbCategory, m_Bus.GetCategoryList(), "CategoryId", "CategoryName");
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Checks whether or not menu item is duplicate.
        /// </summary>
        /// <returns></returns>
        private bool CheckDuplicate()
        {
            List<String> menuControlList = m_Bus.GetMenuControlNameList();
            foreach (string item in menuControlList)
            {
                if (item.Equals(txtMenuCtrlName.Text))
                {
                    clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.DUPLICATE_MENU);
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Fire saving event every time a menu item was added or modified.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void FireSaveMenuEvent()
        {
            if (OnSaveMenu != null)
            {
                OnSaveMenu();
            }
        }

        /// <summary>
        /// Pass an updating menu item information from menu management screen.
        /// </summary>
        /// <param name="menuItemId">Id of a function</param>
        /// <param name="parentName">Parent name of menu item</param>
        /// <param name="parentId">Parent id of menu item</param>
        /// <param name="categoryName">Category of menu item</param>
        /// <param name="ctrlName">Control name of menu item</param>
        /// <param name="menuName">Menu item name</param>
        /// <param name="desc">Short description</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public void PassUpdateMenuInfo(int menuItemId, string parentName, string parentId, 
            string categoryName, string ctrlName, string menuName, string desc)
        {
            txtParent.Text = parentName;
            cbbCategory.Text = categoryName;
            _parentId = parentId;
            if (m_Action == SEAction.CreateChildMenu)
            {
                cbbCategory.Enabled = false;
            }
            // In case of modify
            else 
            {
                m_MenuId = menuItemId;
                cbbCategory.Enabled = false;
                txtMenuCtrlName.Text = ctrlName;
                txtMenuName.Text = menuName;
                txtDes.Text = desc;
            }
        }

        /// <summary>
        /// Pass update function information from function management screen.
        /// </summary>
        /// <param name="ctrlName">Id of a function</param>
        /// <param name="menuName">Parent name of menu item</param>
        /// <param name="categoryName">Category of menu item</param>
        /// <param name="desc">Short description</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public void PassChildMenuInfo(string ctrlName, string menuName, string categoryName, string desc)
        {
            m_ChildCtrlName = ctrlName;
            m_ChildMenuName = menuName;
            cbbCategory.Text = categoryName;
            cbbCategory.Enabled = false;
            m_ChildMenuDesc = desc;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtMenuCtrlName.Text.Trim().Length == 0)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.PLEASE_INPUT, "Menu Control Name"));
                return;
            }
            if (txtMenuName.Text.Trim().Length == 0)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.PLEASE_INPUT, "Menu Name"));
                return;
            }
            if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_SAVE_MENU, "Do")) == DialogResult.Yes)
            {
                try
                {
                    // In case of creating parent menu
                    if (m_Action == SEAction.CreateParentMenu)
                    {
                        if (CheckDuplicate()) return;

                        clsSEDto dto = new clsSEDto();
                        dto.MenuControlName = txtMenuCtrlName.Text;
                        dto.MenuItemName = txtMenuName.Text;
                        dto.ParentID = null;
                        dto.FnCategoryID = Int16.Parse(cbbCategory.SelectedValue.ToString());
                        dto.Remark = txtDes.Text;
                        int recordAffected = m_Bus.CreateMenuItem(dto);
                        if (recordAffected > 0)
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                            FireSaveMenuEvent();
                        }
                        else
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
                        }
                    }
                    // In case of creating child menu
                    else if (m_Action == SEAction.CreateChildMenu)
                    {
                        if (CheckDuplicate()) return;

                        clsSEDto dto = new clsSEDto();
                        dto.MenuControlName = txtMenuCtrlName.Text;
                        dto.MenuItemName = txtMenuName.Text;
                        dto.ParentID = _parentId;
                        dto.FnCategoryID = Int16.Parse(cbbCategory.SelectedValue.ToString());
                        dto.Remark = txtDes.Text;
                        int recordAffected = m_Bus.CreateMenuItem(dto);
                        if (recordAffected > 0)
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                            FireSaveMenuEvent();
                        }
                        else
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
                        }
                    }
                    // In case of modifying menu
                    else
                    {
                        clsSEDto dto = new clsSEDto();
                        dto.MenuItemId = m_MenuId;
                        dto.ControlName = txtMenuCtrlName.Text;
                        dto.MenuItemName = txtMenuName.Text;
                        dto.FnCategoryID = Int16.Parse(cbbCategory.SelectedValue.ToString());
                        dto.Remark = txtDes.Text;
                        int recordAffected = m_Bus.ModifyMenuItem(dto);
                        if (recordAffected > 0)
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.MODIFY_SUCCESS);
                            FireSaveMenuEvent();
                        }
                        else
                        {
                            clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.MODIFY_UNSUCCESS);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                }

                // Close form after operation
                Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}