﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-26 07:49:04 +0700 (Tue, 26 Mar 2013) $
 * $Revision: 12037 $ 
 * ========================================================
 * This class is used to manage (create, update, delete) a role
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Security.Bus;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Dto;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityRoleManagement : frmSEMaster
    {
        private clsSEBus m_Bus = null;
        //private int m_ReservedIndex = 0;

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityRoleManagement" /> class.
        /// </summary>
        public frmSecurityRoleManagement() : base()
        {
            InitializeComponent();
            SetCommonControlStyle();
            SetupDataPropertyName();

            m_Bus = new clsSEBus();

            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                // Get a list of departments
                clsSEUtils.LoadComboBox(cbbDept, m_Bus.GetDepartmentListWithEmptyItem(), "DepartmentId", "DepartmentName");
                // Get a list of roles
                //cbbRole.DisplayMember = "RoleName";
                //cbbRole.DataSource = m_Bus.GetRoleListWithEmptyItem().DefaultView.ToTable(true, "RoleName");

                // Search role list
                RefreshRoleList(m_Bus.GetRoleList());
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Check whether or not a role is selected.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private bool IsRoleSelected()
        {
            if (dtgRoleList.CurrentRow != null && dtgRoleList.CurrentRow.Selected)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Setup DataPropertyName for datagridview role.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void SetupDataPropertyName()
        {
            dtgRoleList.AutoGenerateColumns = false;
            RoleIdColumn.DataPropertyName = "RoleId";
            DeptIdColumn.DataPropertyName = "DepartmentID";
            RoleNameColumn.DataPropertyName = "RoleName";
            DeptColumn.DataPropertyName = "DepartmentName";
            RemarkColumn.DataPropertyName = "Remark";
        }

        /// <summary>
        /// Update latest role list when load form or a role was changed.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void RefreshRoleList(DataTable dataSource)
        {
            dtgRoleList.DataSource = dataSource;
            dtgRoleList.ClearSelection();
        }

        private void frmSecuritytRoleManagement_Load(object sender, EventArgs e)
        {
            dtgRoleList.ClearSelection();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            clsSEDto dto = new clsSEDto();
            dto.DepartmentId = Int16.Parse(cbbDept.SelectedValue.ToString());
            dto.RoleName = txtRole.Text;
            try
            {
                RefreshRoleList(m_Bus.SearchRole(dto));
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        private void btnAssignMenu_Click(object sender, EventArgs e)
        {
            if (!IsRoleSelected())
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, "Please select a role to assign");
                return;
            }
            string roleToAssign = dtgRoleList.CurrentRow.Cells["RoleNameColumn"].Value.ToString();
            frmSecurityAssignMenuToRole frm = new frmSecurityAssignMenuToRole(roleToAssign);
            frm.StartPosition = FormStartPosition.CenterParent;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void btnAssignRight_Click(object sender, EventArgs e)
        {
            if (!IsRoleSelected())
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, "Please select a role to assign");
                return;
            }
            string roleToAssign = dtgRoleList.CurrentRow.Cells["RoleNameColumn"].Value.ToString();
            frmSecurityAssignRightToRole frm = new frmSecurityAssignRightToRole(roleToAssign);
            frm.StartPosition = FormStartPosition.CenterParent;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            frmSecurityAddModifyRole frm = new frmSecurityAddModifyRole(SEAction.CreateNewRole);
            frm.OnSaveRoleCompleted += new frmSecurityAddModifyRole.SaveRoleCompleted(OnSaveRoleCompleted);
            frm.StartPosition = FormStartPosition.CenterParent;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if (!IsRoleSelected())
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SELECT_ROLE_TO_MODIFY);
                return;
            }
            try
            {
                //m_ReservedIndex = cbbRole.SelectedIndex;

                frmSecurityAddModifyRole frm = new frmSecurityAddModifyRole(SEAction.ModifyExistingRole);
                frm.OnSaveRoleCompleted += new frmSecurityAddModifyRole.SaveRoleCompleted(OnSaveRoleCompleted);
                int roleId = int.Parse(dtgRoleList.CurrentRow.Cells["RoleIdColumn"].Value.ToString());
                string roleName = dtgRoleList.CurrentRow.Cells["RoleNameColumn"].Value.ToString();
                string deptName = dtgRoleList.CurrentRow.Cells["DeptColumn"].Value.ToString();
                string roleRemark = dtgRoleList.CurrentRow.Cells["RemarkColumn"].Value.ToString();
                frm.PassUpdateRoleInfo(roleId, roleName, deptName, roleRemark);
                frm.StartPosition = FormStartPosition.CenterParent;
                if (!frm.IsDisposed)
                {
                    frm.ShowDialog();
                }
            }
            catch (Exception)
            {
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!IsRoleSelected())
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SELECT_ROLE_TO_DELETE);
                return;
            }
            try
            {
                if (m_Bus.CheckUserIsAssignedToRole(Int16.Parse(dtgRoleList.CurrentRow.Cells["RoleIdColumn"].Value.ToString())))
                {
                    clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.CANNOT_DELETE_ROLE);
                    return;
                }
                if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_DELETE_ROLE, "Are you sure")) == DialogResult.Yes)
                {
                    int roleId = int.Parse(dtgRoleList.CurrentRow.Cells["RoleIdColumn"].Value.ToString());
                    int recordAffected = m_Bus.DeleteRole(roleId);
                    if (recordAffected > 0)
                    {
                        //cbbRole.DataSource = m_Bus.GetRoleListWithEmptyItem().DefaultView.ToTable(true, "RoleName");
                        //if (cbbRole.Items.Count == 2)
                        //{
                        //    if (cbbRole.Items[0].ToString().Equals("") && cbbRole.Items[1].ToString().Equals(""))
                        //    {
                        //        cbbRole.Items.RemoveAt(0);
                        //    }
                        //}
                        btnSearch.PerformClick();
                        //RefreshRoleList(m_Bus.GetRoleList());
                        clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                    }
                    else
                        clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
                }
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtRoleID_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar));
        }

        private void OnSaveRoleCompleted(SEAction action)
        {
            //cbbRole.DataSource = m_Bus.GetRoleListWithEmptyItem().DefaultView.ToTable(true, "RoleName");
            //if (action == SEAction.CreateNewRole)
            //{
            //    btnSearch.PerformClick();
            //    //clsSEDto dto = new clsSEDto();
            //    //dto.RoleName = cbbRole.Text;
            //    //dto.DepartmentId = Int16.Parse(cbbDept.SelectedValue.ToString());
            //    //RefreshRoleList(m_Bus.SearchRole(dto));
            //}
            //else
            //{
            //    cbbRole.SelectedIndex = m_ReservedIndex;
            //    btnSearch.PerformClick();
            //}
            btnSearch.PerformClick();
        }
    }
}