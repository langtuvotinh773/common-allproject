﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-25 20:54:48 +0700 (Mon, 25 Mar 2013) $
 * $Revision: 12035 $ 
 * ========================================================
 * This class is used to assign role to to a specified user and vice versa
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Security.Bus;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Dto;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityAssignRoleToUser : frmSEMaster
    {
        private clsSEBus m_Bus = null;
        private DataTable m_TableUser = null;
        private DataTable m_TableRole = null;
        private List<String> m_OriginalItems = null;
        private int m_OriginalId = 0;

        private bool m_DBDisconnected = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityAssignRoleToUser" /> class.
        /// </summary>
        public frmSecurityAssignRoleToUser() : base()
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();
            m_OriginalItems = new List<String>();

            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                LoadComboBoxs();
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                m_DBDisconnected = true;
                Close();
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityAssignRoleToUser" /> class.
        /// </summary>
        /// <param name="userNo">The user no.</param>
        public frmSecurityAssignRoleToUser(int userNo) : base()
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();
            m_OriginalItems = new List<String>();

            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                LoadComboBoxs();

                cbbUserName.SelectedValue = userNo;
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                m_DBDisconnected = true;
                Close();
            }
        }

        /// <summary>
        /// Check whether data is changed or not.
        /// </summary>
        private bool CheckDataChanged()
        {
            bool isChanged = false;
            if (m_OriginalItems.Count != lvAssigned.Items.Count)
                return true;
            else
            {
                for (int i = 0; i < m_OriginalItems.Count; i++)
                {
                    if (m_OriginalItems[i].Equals(lvAssigned.Items[i].Text))
                        isChanged = false;
                    else
                        isChanged = true;
                }
            }
            return isChanged;
        }

        /// <summary>
        /// Removes the last comma.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns></returns>
        private string RemoveLastComma(string source)
        {
            int indexLastComma = source.LastIndexOf(",");
            if (indexLastComma > 0)
            {
                return source.Remove(indexLastComma);
            }
            return source;
        }

        /// <summary>
        /// Copies the role to assign list.
        /// </summary>
        private void CopyRoleToAssignList()
        {
            List<ListViewItem> lists = new List<ListViewItem>();
            for (int i = 0; i < lvUnassign.SelectedItems.Count; i++)
            {
                int ii = 1;
                string department = lvUnassign.SelectedItems[i].SubItems[ii].Text;
                if (!txtDeptUser.Text.Contains(department))
                {
                    string msg = "You are assigning role '" + lvUnassign.SelectedItems[i].Text + "' to a user of another department. Do you want to continue?";
                    DialogResult result = clsSEUtils.ShowMessage((int)MessageType.Confirm, msg);
                    if (result == DialogResult.Yes)
                    {
                        lvAssigned.Items.Add(lvUnassign.SelectedItems[i].Clone() as ListViewItem);
                        lists.Add(lvUnassign.SelectedItems[i]);
                    }
                    else if (result == DialogResult.Cancel) break;
                }
                else
                {
                    lvAssigned.Items.Add(lvUnassign.SelectedItems[i].Clone() as ListViewItem);
                    lists.Add(lvUnassign.SelectedItems[i]);
                }
                ii++;
            }
            foreach (ListViewItem item in lists)
            {
                lvUnassign.Items.Remove(item);
            }
        }

        /// <summary>
        /// Copies the user to assign list.
        /// </summary>
        private void CopyUserToAssignList()
        {
            List<ListViewItem> lists = new List<ListViewItem>();
            for (int i = 0; i < lvUnassign.SelectedItems.Count; i++)
            {
                int ii = 1;
                string department = lvUnassign.SelectedItems[i].SubItems[ii].Text;
                if (!department.Contains(txtDept.Text))
                {
                    string msg = "You are assigning user '" + lvUnassign.SelectedItems[i].Text + 
                        "' to a role of another department. Do you want to continue?";
                    DialogResult result = clsSEUtils.ShowMessage((int)MessageType.Confirm, msg);
                    if (result == DialogResult.Yes)
                    {
                        lvAssigned.Items.Add(lvUnassign.SelectedItems[i].Clone() as ListViewItem);
                        lists.Add(lvUnassign.SelectedItems[i]);
                    }
                    else if (result == DialogResult.Cancel)
                    {
                        break;
                    }
                }
                else
                {
                    lvAssigned.Items.Add(lvUnassign.SelectedItems[i].Clone() as ListViewItem);
                    lists.Add(lvUnassign.SelectedItems[i]);
                }
                ii++;
            }
            foreach (ListViewItem item in lists)
            {
                lvUnassign.Items.Remove(item);
            }
        }

        /// <summary>
        /// Fill items for user, role, department comboboxs.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void LoadComboBoxs()
        {
            cbbUserName.ValueMember = "UserNo";
            cbbUserName.DisplayMember = "FullName";
            
            cbbRoleName.ValueMember = "RoleId";
            cbbRoleName.DisplayMember = "RoleName";
            
            // Get departments list
            clsSEUtils.LoadComboBox(cbbDept, m_Bus.GetDepartmentListWithEmptyItem(), "DepartmentId", "DepartmentName");

            // Check user name radio btn as default
            radUserName.Checked = true;
        }

        /// <summary>
        /// Search a list of roles.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void SearchRoles()
        {
            clsSEDto dto = new clsSEDto();
            if (cbbUserName.SelectedValue == null) return;
            dto.UserNo = Int16.Parse(cbbUserName.SelectedValue.ToString());
            dto.DepartmentId = Int16.Parse(cbbDept.SelectedValue.ToString());
            try
            {
                DataSet ds = m_Bus.SearchRolesAssignedToUser(dto);
                if (ds != null)
                {
                    lvUnassign.Items.Clear();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        ListViewItem item = new ListViewItem();
                        item.Text = row["RoleName"].ToString();
                        item.Tag = row["RoleId"].ToString();
                        item.SubItems.Add(row["DepartmentName"].ToString());
                        lvUnassign.Items.Add(item);
                    }
                    m_OriginalItems.Clear();
                    lvAssigned.Items.Clear();
                    foreach (DataRow row in ds.Tables[1].Rows)
                    {
                        ListViewItem item = new ListViewItem();
                        item.Text = row["RoleName"].ToString();
                        item.Tag = row["RoleId"].ToString();
                        item.SubItems.Add(row["DepartmentName"].ToString());
                        lvAssigned.Items.Add(item);

                        m_OriginalItems.Add(item.Text);
                    }
                    m_OriginalId = Int16.Parse(cbbUserName.SelectedValue.ToString());
                    lblNameValue.Text = cbbUserName.Text;
                    lblNameValue.Tag = cbbUserName.SelectedValue;
                }
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();       
            }
        }

        /// <summary>
        /// Search a list of users.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void SearchUsers()
        {
            clsSEDto dto = new clsSEDto();
            if (cbbRoleName.SelectedValue == null) return;
            dto.RoleID = Int16.Parse(cbbRoleName.SelectedValue.ToString());
            //dto.DepartmentId = Int16.Parse(txtDept.Tag.ToString());
            DataSet ds = m_Bus.SearchUsersAssignedToRole(dto);
            if (ds != null)
            {
                lvUnassign.Items.Clear();
                DataTable distinctTable = ds.Tables[0].DefaultView.ToTable("Table0", true, "UserNo", "UserName", "FullName", "DepartmentName");
                foreach (DataRow row in distinctTable.Rows)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = row["FullName"].ToString();
                    item.Tag = row["UserNo"].ToString();
                    string strDeptName = RemoveLastComma(row["DepartmentName"].ToString().Trim());
                    item.SubItems.Add(strDeptName);
                    lvUnassign.Items.Add(item);
                }
                m_OriginalItems.Clear();
                lvAssigned.Items.Clear();
                foreach (DataRow row in ds.Tables[1].Rows)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = row["FullName"].ToString();
                    item.Tag = row["UserNo"].ToString();
                    string strDeptName = RemoveLastComma(row["DepartmentName"].ToString().Trim());
                    item.SubItems.Add(strDeptName);
                    lvAssigned.Items.Add(item);

                    m_OriginalItems.Add(item.Text);
                }
                m_OriginalId = Int16.Parse(cbbRoleName.SelectedValue.ToString());
                lblNameValue.Text = cbbRoleName.Text;
                lblNameValue.Tag = cbbRoleName.SelectedValue;
            }
        }

        /// <summary>
        /// Saves this instance.
        /// </summary>
        private void Save()
        {
            if (radUserName.Checked)
            {
                int userNo = Int16.Parse(cbbUserName.SelectedValue.ToString());
                m_Bus.DeleteOldRoleAssignedToUser(userNo);

                List<Int16> roleIds = new List<Int16>();
                m_OriginalItems.Clear();
                foreach (ListViewItem item in lvAssigned.Items)
                {
                    if (item.Tag != null)
                        roleIds.Add(Int16.Parse(item.Tag.ToString()));
                    m_OriginalItems.Add(item.Text);
                }
                if (roleIds.Count == 0)
                {
                    clsFunction.ShowInfoDialog(clsSEMessage.SAVE_SUCCESS);
                    return;
                }
                if (m_Bus.AssignRoleToUser(roleIds, userNo) >= 1)
                    clsFunction.ShowInfoDialog(clsSEMessage.SAVE_SUCCESS);
                else
                    clsFunction.ShowErrorDialog(clsSEMessage.SAVE_UNSUCCESS);
            }
            else
            {
                int roleId = Int16.Parse(cbbRoleName.SelectedValue.ToString());
                m_Bus.DeleteOldUserAssignedToRole(roleId);

                List<Int16> userIds = new List<Int16>();
                m_OriginalItems.Clear();
                foreach (ListViewItem item in lvAssigned.Items)
                {
                    if (item.Tag != null)
                        userIds.Add(Int16.Parse(item.Tag.ToString()));

                    m_OriginalItems.Add(item.Text);
                }
                if (userIds.Count == 0)
                {
                    clsFunction.ShowInfoDialog(clsSEMessage.SAVE_SUCCESS);
                    return;
                }
                if (m_Bus.AssignUserToRole(userIds, roleId) >= 1)
                    clsFunction.ShowInfoDialog(clsSEMessage.SAVE_SUCCESS);
                else
                    clsFunction.ShowErrorDialog(clsSEMessage.SAVE_UNSUCCESS);
            }
        }

        /// <summary>
        /// Saves this instance.
        /// </summary>
        private void SavePreviousChanges()
        {
            if (radUserName.Checked)
            {
                int roleId = Int16.Parse(cbbRoleName.SelectedValue.ToString());
                m_Bus.DeleteOldUserAssignedToRole(roleId);

                List<Int16> userIds = new List<Int16>();
                m_OriginalItems.Clear();
                foreach (ListViewItem item in lvAssigned.Items)
                {
                    if (item.Tag != null)
                        userIds.Add(Int16.Parse(item.Tag.ToString()));

                    m_OriginalItems.Add(item.Text);
                }
                if (userIds.Count == 0)
                {
                    clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                    return;
                }
                if (m_Bus.AssignUserToRole(userIds, roleId) >= 1)
                    clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                else
                    clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);   
            }
            else
            {
                int userNo = Int16.Parse(cbbUserName.SelectedValue.ToString());
                m_Bus.DeleteOldRoleAssignedToUser(userNo);

                List<Int16> roleIds = new List<Int16>();
                m_OriginalItems.Clear();
                foreach (ListViewItem item in lvAssigned.Items)
                {
                    if (item.Tag != null)
                        roleIds.Add(Int16.Parse(item.Tag.ToString()));
                    m_OriginalItems.Add(item.Text);
                }
                if (roleIds.Count == 0)
                {
                    clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                    return;
                }
                if (m_Bus.AssignRoleToUser(roleIds, userNo) >= 1)
                    clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                else
                    clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);             
            }
        }

        /// <summary>
        /// Save changes to database.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns></returns>
        private void SavePreviousChanges(int id)
        {
            if (radUserName.Checked)
            {
                m_Bus.DeleteOldRoleAssignedToUser(id);

                List<Int16> roleIds = new List<Int16>();
                m_OriginalItems.Clear();
                foreach (ListViewItem item in lvAssigned.Items)
                {
                    if (item.Tag != null)
                        roleIds.Add(Int16.Parse(item.Tag.ToString()));
                    m_OriginalItems.Add(item.Text);
                }
                if (roleIds.Count == 0)
                {
                    clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                    return;
                }
                if (m_Bus.AssignRoleToUser(roleIds, id) >= 1)
                    clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                else
                    clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
            }
            else
            {
                m_Bus.DeleteOldUserAssignedToRole(id);

                List<Int16> userIds = new List<Int16>();
                m_OriginalItems.Clear();
                foreach (ListViewItem item in lvAssigned.Items)
                {
                    if (item.Tag != null)
                        userIds.Add(Int16.Parse(item.Tag.ToString()));

                    m_OriginalItems.Add(item.Text);
                }
                if (userIds.Count == 0)
                {
                    clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                    return;
                }
                if (m_Bus.AssignUserToRole(userIds, id) >= 1)
                    clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                else
                    clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (CheckDataChanged())
                {
                    string msg = "There are some changes on " + lblNameValue.Text + ". Do you want to save?";
                    DialogResult result = clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, msg);
                    if (result == DialogResult.Yes)
                        SavePreviousChanges(Int16.Parse(lblNameValue.Tag.ToString()));
                    else
                    {
                        if (radUserName.Checked)
                            SearchRoles();
                        else
                            SearchUsers();
                    }
                }
                if (radUserName.Checked)
                    SearchRoles();
                else
                    SearchUsers();
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                m_DBDisconnected = true;
                Close();
            }
        }

        private void btnSingleRight_Click(object sender, EventArgs e)
        {
            if (radUserName.Checked)
            {
                if (lvUnassign.SelectedItems.Count == 0) return;
                CopyRoleToAssignList();
            }
            else
            {
                CopyUserToAssignList();
            }
        }

        private void btnSingleLeft_Click(object sender, EventArgs e)
        {
            if (lvAssigned.SelectedItems.Count == 0) return;
            foreach (ListViewItem item in lvAssigned.SelectedItems)
            {
                lvUnassign.Items.Add(item.Clone() as ListViewItem);
                lvAssigned.Items.Remove(item);
            }
        }

        private void btnDoubleRight_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lvUnassign.Items.Count; i++)
            {
                lvUnassign.Items[i].Selected = true;
            }
            if (radUserName.Checked)
                CopyRoleToAssignList();
            else
                CopyUserToAssignList();
        }

        private void btnDoubleLeft_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lvAssigned.Items)
            {
                lvUnassign.Items.Add(item.Clone() as ListViewItem);
                lvAssigned.Items.Remove(item);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if ((radUserName.Checked && cbbUserName.Items.Count == 0) || (radRoleName.Checked && cbbRoleName.Items.Count == 0)
                || (lvUnassign.Items.Count == 0 && lvAssigned.Items.Count == 0))
            {
                clsSEUtils.ShowMessage((int)MessageType.Information, String.Format(clsSEMessage.THERE_IS_NO, "change to save"));
                return;
            }
            try
            {
                if (radUserName.Checked)
                {
                    if (lblNameValue.Tag != cbbUserName.SelectedValue)
                    {
                        if (CheckDataChanged())
                        {
                            //string msg = "There are some changes on " + lblNameValue.Text + ". Do you want to save?";
                            string msg = String.Format(clsSEMessage.CONFIRM_ASSIGN_ROLE, "Do");
                            if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, msg) == DialogResult.Yes)
                            {
                                SavePreviousChanges(Int16.Parse(lblNameValue.Tag.ToString()));
                                SearchRoles();
                            }
                        }
                        else
                            clsSEUtils.ShowMessage((int)MessageType.Information, String.Format(clsSEMessage.THERE_IS_NO, "change to save"));
                    }
                    else
                    {
                        if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_ASSIGN_ROLE, "Do")) == DialogResult.Yes)
                        {
                            if (CheckDataChanged())
                            {
                                SavePreviousChanges(Int16.Parse(lblNameValue.Tag.ToString()));
                            }
                        }
                    }
                }
                else
                {
                    if (lblNameValue.Tag != cbbRoleName.SelectedValue)
                    {
                        if (CheckDataChanged())
                        {
                            //string msg = "There are some changes on " + lblNameValue.Text + ". Do you want to save?";
                            string msg = String.Format(clsSEMessage.CONFIRM_ASSIGN_ROLE, "Do");
                            if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, msg) == DialogResult.Yes)
                            {
                                SavePreviousChanges(Int16.Parse(lblNameValue.Tag.ToString()));
                                SearchUsers();
                            }
                        }
                        else
                            clsSEUtils.ShowMessage((int)MessageType.Information, String.Format(clsSEMessage.THERE_IS_NO, "change to save"));
                    }
                    else
                    {
                        if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_ASSIGN_ROLE, "Do")) == DialogResult.Yes)
                        {
                            if (CheckDataChanged())
                            {
                                SavePreviousChanges(Int16.Parse(lblNameValue.Tag.ToString()));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                m_DBDisconnected = true;
                Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void radUserName_CheckedChanged(object sender, EventArgs e)
        {
            if (radUserName.Checked)
            {
                try
                {
                    if (CheckDataChanged())
                    {
                        string msg = "There are some changes on " + lblNameValue.Text + ". Are you want to save?";
                        if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, msg) == DialogResult.Yes)
                            SavePreviousChanges();
                    }
                    Text = "Assign Roles to User";
                    lvUnassign.Columns[0].Text = "Roles";
                    lvAssigned.Columns[0].Text = "Roles";
                    cbbUserName.Enabled = true;
                    cbbRoleName.Enabled = false;
                    cbbDept.Enabled = true;
                    m_TableUser = m_Bus.GetUserList();
                    cbbUserName.DataSource = m_TableUser;

                    lblName.Text = "Full Name:";

                    SearchRoles();
                }
                catch (Exception ex)
                {
                    Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                    m_DBDisconnected = true;
                    Close();
                }
            }
        }

        private void radRoleName_CheckedChanged(object sender, EventArgs e)
        {
            if (radRoleName.Checked)
            {
                try
                {
                    if (CheckDataChanged())
                    {
                        string msg = "There are some changes on " + lblNameValue.Text + ". Are you want to save?";
                        if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, msg) == DialogResult.Yes)
                            SavePreviousChanges();
                    }
                    Text = "Assign Users to Role";
                    lvUnassign.Columns[0].Text = "Users";
                    lvAssigned.Columns[0].Text = "Users";
                    cbbRoleName.Enabled = true;
                    cbbUserName.Enabled = false;
                    cbbDept.Enabled = false;
                    m_TableRole = m_Bus.GetRoleList();
                    cbbRoleName.DataSource = m_TableRole;

                    lblName.Text = "Role Name:";

                    SearchUsers();
                }
                catch (Exception ex)
                {
                    Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                    m_DBDisconnected = true;
                    Close();
                }
            }
        }

        private void cbbUserName_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Updated By vlhchung 2013/04/25 start
            if (cbbUserName.SelectedValue != null)
            {
                DataRow[] rows = m_TableUser.Select("UserNo = " + cbbUserName.SelectedValue);
                if (rows.Length == 1)
                {
                    txtUserName.Text = rows[0]["UserName"].ToString();
                    //txtDeptUser.Text = rows[0]["DepartmentName"].ToString();
                    string strDeptName = RemoveLastComma(rows[0]["DepartmentName"].ToString().Trim());
                    txtDeptUser.Text = strDeptName;
                }
                else
                {
                    txtUserName.Clear();
                    txtDeptUser.Clear();
                }
            }
            else
            {
                txtUserName.Clear();
                txtDeptUser.Clear();
            }
        }

        private void cbbRoleName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbbUserName.SelectedValue != null)
            {
                DataRow[] rows = m_TableRole.Select("RoleId = " + cbbRoleName.SelectedValue.ToString());
                if (rows.Length > 0)
                {
                    txtDept.Text = rows[0]["DepartmentName"].ToString();
                    txtDept.Tag = rows[0]["DepartmentID"].ToString();
                }
            }
            else
            {
                txtDept.Clear();
            }
        }

        private void frmSecurityAssignRoleToUser_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_DBDisconnected) return;
            object c = btnSave.Tag;
            if (c != null && (bool)c && CheckDataChanged())
            {
                string msg = "There are some data changes. Do you want to save?";
                DialogResult result = clsSEUtils.ShowMessage((int)MessageType.Confirm, msg);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        SavePreviousChanges(Int16.Parse(lblNameValue.Tag.ToString()));
                    }
                    catch (Exception ex)
                    {
                        Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                    }
                }
                else if (result == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }
    }
}