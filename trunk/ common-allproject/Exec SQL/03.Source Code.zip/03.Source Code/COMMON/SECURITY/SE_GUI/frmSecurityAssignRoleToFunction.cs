﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityAssignRolesToFunction : Form
    {
        public frmSecurityAssignRolesToFunction()
        {
            InitializeComponent();
        }
    }
}