﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSEMaster : Form
    {
        public frmSEMaster()
        {
            InitializeComponent();
        }

        protected void SetCommonControlStyle()
        {
            clsCommonStyles style = clsCommonStyles.Instance();

            BackColor = clsCommonStyles.Instance().FormBG;
            foreach (Control ctrl in Controls)
            {
                if (ctrl is DataGridView)
                {
                    DataGridView dgv = ctrl as DataGridView;
                    dgv.EnableHeadersVisualStyles = false;
                    dgv.ColumnHeadersDefaultCellStyle.BackColor = style.DGVColumnHeaderBG;
                    dgv.DefaultCellStyle.BackColor = style.DGVReadOnlyColumnBG;
                    dgv.AlternatingRowsDefaultCellStyle = style.DGVAlternatingRowsDefaultCellStyle;
                }
            }
        }
    }
}
