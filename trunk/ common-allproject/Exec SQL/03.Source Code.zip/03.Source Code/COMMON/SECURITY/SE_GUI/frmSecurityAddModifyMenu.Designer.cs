﻿namespace Phoenix.Common.Security.Gui
{
    partial class frmSecurityAddModifyMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblParent = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblCtrlName = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.txtParent = new System.Windows.Forms.TextBox();
            this.txtMenuCtrlName = new System.Windows.Forms.TextBox();
            this.txtDes = new System.Windows.Forms.TextBox();
            this.cbbCategory = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblFnName = new System.Windows.Forms.Label();
            this.txtMenuName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblParent
            // 
            this.lblParent.AutoSize = true;
            this.lblParent.Location = new System.Drawing.Point(18, 18);
            this.lblParent.Name = "lblParent";
            this.lblParent.Size = new System.Drawing.Size(64, 13);
            this.lblParent.TabIndex = 0;
            this.lblParent.Text = "Parent Form";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(18, 45);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(49, 13);
            this.lblCategory.TabIndex = 0;
            this.lblCategory.Text = "Category";
            // 
            // lblCtrlName
            // 
            this.lblCtrlName.AutoSize = true;
            this.lblCtrlName.Location = new System.Drawing.Point(18, 71);
            this.lblCtrlName.Name = "lblCtrlName";
            this.lblCtrlName.Size = new System.Drawing.Size(71, 13);
            this.lblCtrlName.TabIndex = 0;
            this.lblCtrlName.Text = "Control Name";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(18, 120);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(60, 13);
            this.lblDescription.TabIndex = 0;
            this.lblDescription.Text = "Description";
            // 
            // txtParent
            // 
            this.txtParent.Enabled = false;
            this.txtParent.Location = new System.Drawing.Point(117, 13);
            this.txtParent.Name = "txtParent";
            this.txtParent.Size = new System.Drawing.Size(280, 20);
            this.txtParent.TabIndex = 0;
            // 
            // txtMenuCtrlName
            // 
            this.txtMenuCtrlName.Location = new System.Drawing.Point(117, 66);
            this.txtMenuCtrlName.MaxLength = 50;
            this.txtMenuCtrlName.Name = "txtMenuCtrlName";
            this.txtMenuCtrlName.Size = new System.Drawing.Size(280, 20);
            this.txtMenuCtrlName.TabIndex = 2;
            // 
            // txtDes
            // 
            this.txtDes.Location = new System.Drawing.Point(117, 118);
            this.txtDes.MaxLength = 200;
            this.txtDes.Multiline = true;
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(280, 100);
            this.txtDes.TabIndex = 4;
            // 
            // cbbCategory
            // 
            this.cbbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbCategory.FormattingEnabled = true;
            this.cbbCategory.Location = new System.Drawing.Point(117, 39);
            this.cbbCategory.Name = "cbbCategory";
            this.cbbCategory.Size = new System.Drawing.Size(280, 21);
            this.cbbCategory.TabIndex = 1;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSave.Location = new System.Drawing.Point(241, 253);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnCancel.Location = new System.Drawing.Point(322, 253);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblFnName
            // 
            this.lblFnName.AutoSize = true;
            this.lblFnName.Location = new System.Drawing.Point(18, 97);
            this.lblFnName.Name = "lblFnName";
            this.lblFnName.Size = new System.Drawing.Size(84, 13);
            this.lblFnName.TabIndex = 0;
            this.lblFnName.Text = "Form Title Name";
            // 
            // txtMenuName
            // 
            this.txtMenuName.Location = new System.Drawing.Point(117, 92);
            this.txtMenuName.MaxLength = 50;
            this.txtMenuName.Name = "txtMenuName";
            this.txtMenuName.Size = new System.Drawing.Size(280, 20);
            this.txtMenuName.TabIndex = 3;
            // 
            // frmSecurityAddModifyMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 288);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cbbCategory);
            this.Controls.Add(this.txtDes);
            this.Controls.Add(this.txtMenuName);
            this.Controls.Add(this.txtMenuCtrlName);
            this.Controls.Add(this.txtParent);
            this.Controls.Add(this.lblFnName);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblCtrlName);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lblParent);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmSecurityAddModifyMenu";
            this.Text = "Create Parent Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblParent;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblCtrlName;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txtParent;
        private System.Windows.Forms.TextBox txtMenuCtrlName;
        private System.Windows.Forms.TextBox txtDes;
        private System.Windows.Forms.ComboBox cbbCategory;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblFnName;
        private System.Windows.Forms.TextBox txtMenuName;
    }
}