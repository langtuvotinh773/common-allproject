﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-25 20:48:06 +0700 (Mon, 25 Mar 2013) $
 * $Revision: 12033 $ 
 * ========================================================
 * This class is used to manage (create, update, delete) a menu item
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Bus;
using Phoenix.Common.Security.Dto;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityMenuManagement : frmSEMaster
    {
        private clsSEBus m_Bus = null;
        private bool m_NotCategoryNode = false;
        private bool m_IsModifiedMenu = false;
        private int m_ReserveIndex = 0;

        private DataSet m_DS = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityMenuManagement" /> class.
        /// </summary>
        public frmSecurityMenuManagement() : base()
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();

            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                // Load combobox
                clsSEUtils.LoadComboBox(cbbMenuName, m_Bus.GetMemuNameListWithEmptyItem(), "MenuItemId", "MenuItemName");
                clsSEUtils.LoadComboBox(cbbCategory, m_Bus.GetCategoryListWithEmptyItem(), "CategoryId", "CategoryName");
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Trees the view builder.
        /// </summary>
        /// <param name="MenuItemId">The menu item id.</param>
        /// <param name="parentNode">The parent node.</param>
        private void TreeViewBuilder(int MenuItemId, SETreeNode parentNode)
        {
            //Get MenuItemName of selected Menu Item
            DataRow[] menuItemName = m_DS.Tables[1].Select("MenuItemId = " + MenuItemId);
            SETreeNode currentNode = new SETreeNode();
            currentNode.MenuItemId = Int16.Parse(menuItemName[0]["MenuItemId"].ToString());
            currentNode.ControlName = menuItemName[0]["MenuControlName"].ToString();
            currentNode.Text = menuItemName[0]["MenuItemName"].ToString();
            currentNode.CategoryId = Int16.Parse(menuItemName[0]["CategoryId"].ToString());
            currentNode.CategoryName = menuItemName[0]["CategoryName"].ToString();
            currentNode.ParentId = menuItemName[0]["ParentId"].ToString();
            currentNode.ToolTipText = menuItemName[0]["Description"].ToString();
            parentNode.Nodes.Add(currentNode);

            //Get list of child items of selected Menu Item
            DataRow[] childItemList = m_DS.Tables[1].Select("ParentId = '" + MenuItemId + "'");

            //Check having child item or not
            if (childItemList.Length == 0) return;

            //Have child items?
            for (int i = 0; i < childItemList.Length; i++)
            {
                TreeViewBuilder(Convert.ToInt32(childItemList[i]["MenuItemId"]), currentNode);
            }
        }

        /// <summary>
        /// Populate a treeview menu.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void PopulateMenuTreeView()
        {
            int categoryId = Int16.Parse(cbbCategory.SelectedValue.ToString());
            int menuId = int.Parse(cbbMenuName.SelectedValue.ToString());
            
            //clsSEDto dto = new clsSEDto();
            try
            {
                m_DS = m_Bus.GetMenuItemsList(categoryId);

                if (m_DS != null && m_DS.Tables.Count == 2)
                {
                    treeView1.Nodes.Clear();
                    SETreeNode categoryNode = null;
                    //MenuItemID and Category are not selected
                    if (menuId == -1 && categoryId == -1)
                    {
                        foreach (DataRow category in m_DS.Tables[0].Rows)
                        {
                            //Add hierarchical nodes
                            categoryNode = new SETreeNode();
                            categoryNode.Text = category["CategoryName"].ToString();

                            //Get list of child items of selected Menu Item
                            DataRow[] topMenuItemOfEachCategory = m_DS.Tables[1].Select("CategoryId = " + category["CategoryId"] + " AND ParentId IS NULL");
                            foreach (DataRow item in topMenuItemOfEachCategory)
                            {
                                TreeViewBuilder(Convert.ToInt32(item["MenuItemId"]), categoryNode);
                            }
                            if (categoryNode.Nodes.Count > 0)
                            {
                                treeView1.Nodes.Add(categoryNode);
                            }
                        }
                    }
                    //Category selected but MenuItemId is not selected
                    else if (menuId == -1 && categoryId != -1)
                    {
                        //Add hierarchical nodes
                        categoryNode = new SETreeNode();
                        categoryNode.Text = cbbCategory.Text;

                        //Get list of child items of selected Menu Item
                        DataRow[] topMenuItemOfEachCategory = m_DS.Tables[1].Select("CategoryId = '" + categoryId + "' AND ParentId IS NULL");
                        foreach (DataRow item in topMenuItemOfEachCategory)
                        {
                            TreeViewBuilder(Convert.ToInt32(item["MenuItemId"]), categoryNode);
                        }
                        if (categoryNode.Nodes.Count > 0)
                        {
                            treeView1.Nodes.Add(categoryNode);
                        }
                    }
                    //MenuItemId is selected but Category don't care
                    else
                    {
                        //Add hierarchical nodes
                        SETreeNode menuItemNode = new SETreeNode();
                        menuItemNode.MenuItemId = menuId;
                        //menuItemNode.ControlName = menuItemName[0]["MenuControlName"].ToString();
                        menuItemNode.Text = cbbMenuName.Text;
                        menuItemNode.CategoryId = categoryId;
                        DataRow[] categoryRow = m_DS.Tables[1].Select("MenuItemId = '" + menuId + "'");
                        if (categoryRow.Length > 0)
                        {
                            menuItemNode.CategoryName = categoryRow[0]["CategoryName"].ToString();
                            menuItemNode.ControlName = categoryRow[0]["MenuControlName"].ToString();
                            menuItemNode.ToolTipText = categoryRow[0]["Description"].ToString();
                        }
                        menuItemNode.ParentId = menuId.ToString();

                        //Get list of child items of selected Menu Item
                        DataRow[] childMenuItemOfCurrentNode = m_DS.Tables[1].Select("ParentId = '" + menuId + "'");
                        foreach (DataRow item in childMenuItemOfCurrentNode)
                        {
                            TreeViewBuilder(Convert.ToInt32(item["MenuItemId"]), menuItemNode);
                        }
                        treeView1.Nodes.Add(menuItemNode);
                    }
                }

                m_ReserveIndex = cbbMenuName.SelectedIndex;
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Create a child node for the parent node.
        /// </summary>		
        /// <param name="node">The parent node will contain child nodes</param>
        /// <param name="dt">DataTable contains records to get child nodes</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void CreateChildNode(SETreeNode node, DataTable dt)
        {
            DataRow[] rows = dt.Select("ParentId = '" + node.MenuItemId + "'");
            if (rows.Length == 0) return;
            for (int i = 0; i < rows.Length; i++)
            {
                SETreeNode child = new SETreeNode();
                child.MenuItemId = Int16.Parse(rows[i]["MenuItemId"].ToString());
                child.ControlName = rows[i]["MenuControlName"].ToString();
                child.Text = rows[i]["MenuItemName"].ToString();
                child.CategoryId = Int16.Parse(rows[i]["CategoryId"].ToString());
                child.ParentId = rows[i]["ParentId"].ToString();
                child.ToolTipText = rows[i]["Description"].ToString();
                node.Nodes.Add(child);
                CreateChildNode(child, dt);
            }
        }

        private void frmSecurityMenuManagement_Load(object sender, EventArgs e)
        {
            PopulateMenuTreeView();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            PopulateMenuTreeView();
        }

        private void btnCreateParent_Click(object sender, EventArgs e)
        {
            m_IsModifiedMenu = true;

            frmSecurityAddModifyMenu frm = new frmSecurityAddModifyMenu(SEAction.CreateParentMenu);
            frm.OnSaveMenu += new frmSecurityAddModifyMenu.SaveMenu(OnSaveMenu);
            frm.StartPosition = FormStartPosition.CenterParent;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void btnCreateChild_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.THERE_IS_NO, "item is selected"));
                return;
            }
            if (!m_NotCategoryNode)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.NOT_A_PARENT_MENU);
                return;
            }

            m_IsModifiedMenu = true;

            frmSecurityAddModifyMenu frm = new frmSecurityAddModifyMenu(SEAction.CreateChildMenu);
            SETreeNode node = treeView1.SelectedNode as SETreeNode;
            frm.PassUpdateMenuInfo(-1, node.Text, node.MenuItemId.ToString(), node.CategoryName, "", "", "");
            frm.OnSaveMenu += new frmSecurityAddModifyMenu.SaveMenu(OnSaveMenu);
            frm.StartPosition = FormStartPosition.CenterParent;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            SETreeNode selectedNode = treeView1.SelectedNode as SETreeNode;
            if (selectedNode == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.THERE_IS_NO, "item is selected"));
                return;
            }
            if (selectedNode != null && selectedNode.ParentId == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.INVALID_MENU);
                return;
            }

            m_IsModifiedMenu = true;

            frmSecurityAddModifyMenu frm = new frmSecurityAddModifyMenu(SEAction.ModifyFunction);
            SETreeNode node = treeView1.SelectedNode as SETreeNode;
            int menuItemId = node.MenuItemId;
            string parentId = node.ParentId.ToString();
            string categoryName = node.CategoryName;
            int categoryId = node.CategoryId;
            if (node.Parent == null)
                frm.PassUpdateMenuInfo(menuItemId, "", parentId, categoryName, node.ControlName, node.Text, node.ToolTipText);
            else
            {
                if (node.ParentId.Equals(String.Empty))
                    frm.PassUpdateMenuInfo(menuItemId, "", parentId, categoryName, node.ControlName, node.Text, node.ToolTipText);
                else
                    frm.PassUpdateMenuInfo(menuItemId, node.Parent.Text, parentId, categoryName, node.ControlName, node.Text, node.ToolTipText);
            }
            frm.OnSaveMenu += new frmSecurityAddModifyMenu.SaveMenu(OnSaveMenu);
            frm.StartPosition = FormStartPosition.CenterParent;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SETreeNode selectedNode = treeView1.SelectedNode as SETreeNode;
            if (selectedNode == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.THERE_IS_NO, "item is selected"));
                return;
            }
            if (selectedNode != null && selectedNode.ParentId == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.INVALID_MENU);
                return;
            }
            try
            {
                if (m_Bus.CheckMenuIsAssignedToRole((Int16)selectedNode.MenuItemId))
                {
                    clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.CANNOT_DELETE_MENU);
                    return;
                }
                if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_DELETE_MENU, "Are you sure")) == DialogResult.Yes)
                {
                    m_IsModifiedMenu = false;
                    clsSEDto dto = new clsSEDto();
                    //SETreeNode node = treeView1.SelectedNode as SETreeNode;
                    dto.MenuItemId = selectedNode.MenuItemId;
                    dto.ParentID = selectedNode.ParentId;
                    int recordAffected = m_Bus.DeleteMenuItem(dto);
                    if (recordAffected > 0)
                    {
                        clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.DELETE_SUCCESS);
                        cbbMenuName.DataSource = m_Bus.GetMemuNameListWithEmptyItem();
                        PopulateMenuTreeView();

                        if (cbbMenuName.Items.Count == 2)
                        {
                            if (cbbMenuName.Items[0].ToString().Equals("") && cbbMenuName.Items[1].ToString().Equals(""))
                            {
                                cbbMenuName.Items.RemoveAt(0);
                            }
                        }
                    }
                    else
                        clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.DELETE_UNSUCCESS);
                }
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            SETreeNode node = (e.Node as SETreeNode);
            if (node.ParentId == null)
                m_NotCategoryNode = false;
            else
                m_NotCategoryNode = true;
        }

        private void cbbMenuName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cbbMenuName.SelectedValue) == -1)
            {
                cbbCategory.Enabled = true;
            }
            else
            {
                cbbCategory.SelectedIndex = 0;
                cbbCategory.Enabled = false;
            }
        }

        private void OnSaveMenu()
        {
            try
            {
                cbbMenuName.DataSource = m_Bus.GetMemuNameListWithEmptyItem();
                if (m_IsModifiedMenu)
                {
                    cbbMenuName.SelectedIndex = m_ReserveIndex;
                }
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
            PopulateMenuTreeView();
        }
    }
}