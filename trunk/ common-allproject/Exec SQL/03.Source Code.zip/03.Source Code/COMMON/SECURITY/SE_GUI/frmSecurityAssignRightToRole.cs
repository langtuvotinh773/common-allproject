﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-26 07:48:35 +0700 (Tue, 26 Mar 2013) $
 * $Revision: 12036 $ 
 * ========================================================
 * This class is used to assign functions to a specified role
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Security.Bus;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Dto;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityAssignRightToRole : frmSEMaster
    {
        private clsSEBus m_Bus = null;
        private List<SETreeNode> m_CheckedNodes = null;

        private bool m_HasChange = false;
        private int m_RecordAffected = 0;

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityAssignRightToRole" /> class.
        /// </summary>
        public frmSecurityAssignRightToRole() : base()
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();
            m_CheckedNodes = new List<SETreeNode>();

            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                // Load combobox
                clsSEUtils.LoadComboBox(cbbRole, m_Bus.GetRoleList(), "RoleId", "RoleName");
                clsSEUtils.LoadComboBox(cbbCategory, m_Bus.GetCategoryListWithEmptyItem(), "CategoryId", "CategoryName");
                clsSEUtils.LoadComboBox(cbbName, m_Bus.GetFunctionNameWithEmptyItem(), "FunctionId", "FunctionName");

                radAll.Checked = true;
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityAssignRightToRole" /> class.
        /// </summary>
        /// <param name="roleToAssign">The role to assign.</param>
        public frmSecurityAssignRightToRole(string roleToAssign) : base()
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();
            m_CheckedNodes = new List<SETreeNode>();

            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                // Load Combobox
                clsSEUtils.LoadComboBox(cbbRole, m_Bus.GetRoleList(), "RoleId", "RoleName");
                clsSEUtils.LoadComboBox(cbbCategory, m_Bus.GetCategoryListWithEmptyItem(), "CategoryId", "CategoryName");
                clsSEUtils.LoadComboBox(cbbName, m_Bus.GetFunctionNameWithEmptyItem(), "FunctionId", "FunctionName");

                cbbRole.Text = roleToAssign;
                radAll.Checked = true;
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Process checking parent node from down to up on treeview.
        /// </summary>		
        /// <param name="node">The node has been checked of unchecked</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void ProcessUp(TreeNode node)
        {
            if (node.Parent != null)
            {
                node.Parent.Checked = true;
            }
        }

        /// <summary>
        /// Process checking child node from up to down on treeview.
        /// </summary>		
        /// <param name="node">The node has been checked of unchecked</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void ProcessDown(TreeNode node)
        {
            foreach (TreeNode item in node.Nodes)
            {
                item.Checked = false;
            }
        }

        /// <summary>
        /// Checks all child nodes.
        /// </summary>
        /// <param name="treeNode">The tree node.</param>
        /// <param name="ck">if set to <c>true</c> [ck].</param>
        private void CheckAllChildNodes(TreeNode treeNode, bool ck)
        {
            foreach (TreeNode node in treeNode.Nodes)
            {
                node.Checked = ck;
                if (node.Nodes.Count > 0)
                {
                    this.CheckAllChildNodes(node, ck);
                }
            }
        }

        /// <summary>
        /// Populate a treeview with a filter.
        /// </summary>		
        /// <param name="filter">The string that filter what kind of node</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void PopulateTreeView(string filter)
        {
            if (cbbRole.Items.Count == 0) return;
            
            clsSEDto dto = new clsSEDto();
            dto.RoleID = int.Parse(cbbRole.SelectedValue.ToString());
            dto.FnCategoryID = int.Parse(cbbCategory.SelectedValue.ToString());
            dto.Filter = filter;

            try
            {
                DataSet ds = m_Bus.GetUnassignAssignedFunctions(dto);
                int fId = int.Parse(cbbName.SelectedValue.ToString());
                if (fId != -1)
                {
                    DataRow[] parent = ds.Tables[1].Select("FunctionId = " + fId);
                    DataRow[] childs = ds.Tables[1].Select("ParentId = '" + fId + "'");
                    DataTable dt = ds.Tables[1].Clone();
                    if (parent.Length > 0)
                    {
                        dt.ImportRow(parent[0]);
                    }
                    foreach (DataRow child in childs)
                    {
                        dt.ImportRow(child);
                    }
                    dt.AcceptChanges();
                    ds.Tables.RemoveAt(1);
                    ds.Tables.Add(dt);
                }

                if (ds != null && ds.Tables.Count == 2)
                {
                    m_CheckedNodes.Clear();
                    tvFuncs.Nodes.Clear();
                    foreach (DataRow category in ds.Tables[0].Rows)
                    {
                        // Add hierarchical nodes
                        SETreeNode categoryNode = new SETreeNode();
                        categoryNode.FunctionId = -1;
                        categoryNode.Text = category["CategoryName"].ToString();
                        DataRow[] parentRows = ds.Tables[1].Select("ParentId = '' OR ParentId IS NULL");
                        foreach (DataRow form in parentRows)
                        {
                            if (form["CategoryId"].Equals(category["CategoryId"]))
                            {
                                SETreeNode formNode = new SETreeNode();
                                formNode.Text = form["FunctionName"].ToString();
                                formNode.FunctionId = Int16.Parse(form["FunctionId"].ToString());
                                formNode.ParentId = form["ParentId"].ToString();
                                formNode.ToolTipText = form["Description"].ToString();
                                formNode.Checked = bool.Parse(form["IsAssigned"].ToString());

                                CreateChildNode(formNode, ds.Tables[1]);
                                if (formNode.Nodes.Count == 0)
                                {
                                    m_CheckedNodes.Add(formNode);
                                }
                                categoryNode.Nodes.Add(formNode);
                            }
                        }
                        foreach (SETreeNode node in categoryNode.Nodes)
                        {
                            if (node.Checked) categoryNode.Checked = true;
                        }
                        tvFuncs.Nodes.Add(categoryNode);
                    }
                }
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Create a child node for the parent node.
        /// </summary>		
        /// <param name="node">The parent node will contain child nodes</param>
        /// <param name="dt">DataTable contains records to get child nodes</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void CreateChildNode(SETreeNode node, DataTable dt)
        {
            DataRow[] rows = dt.Select("ParentId = '" + node.FunctionId + "'");
            if (rows.Length == 0) return;
            for (int i = 0; i < rows.Length; i++)
            {
                SETreeNode child = new SETreeNode();
                child.Text = rows[i]["FunctionName"].ToString();
                child.FunctionId = Int16.Parse(rows[i]["FunctionId"].ToString());
                child.CategoryId = Int16.Parse(rows[i]["CategoryId"].ToString());
                child.ParentId = rows[i]["ParentId"].ToString();
                child.ToolTipText = rows[i]["Description"].ToString();
                child.Checked = bool.Parse(rows[i]["IsAssigned"].ToString());
                node.Nodes.Add(child);
                CreateChildNode(child, dt);
            }
        }

        /// <summary>
        /// Remove empty nodes if any from treeview.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void RemoveEmptyNode()
        {
            int index = 0, total = tvFuncs.Nodes.Count;
            for (int i = 0; i < total; i++)
            {
                if (tvFuncs.Nodes[index].Nodes.Count == 0)
                    tvFuncs.Nodes.Remove(tvFuncs.Nodes[index]);
                else
                    ++index;
            }
        }

        /// <summary>
        /// Recall populate treeview and remove empty node functions with filter string.
        /// </summary>		
        /// <param name="filter">The string that filter what kind of node</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void FilterSearchResults(string filter)
        {
            if (cbbRole.Text.Length > 0)
            {
                PopulateTreeView(filter);
                RemoveEmptyNode();
            }
        }

        /// <summary>
        /// Get a list of function ids had check status is true.
        /// </summary>		
        /// <param name="nodes">The nodes collection to selected checked nodes</param>
        /// <param name="menuIds">A list that contains menu ids of each checked node</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void GetFunctionIdList(TreeNodeCollection nodes, List<Int16> fIds)
        {
            foreach (SETreeNode node in nodes)
            {
                if (node.Nodes.Count > 0)
                {
                    if (node.Checked && node.FunctionId != -1)
                    {
                        fIds.Add((Int16)node.FunctionId);
                    }
                    GetFunctionIdList(node.Nodes, fIds);
                }
                else
                {
                    if (node.Checked && node.FunctionId != -1)
                    {
                        fIds.Add((Int16)node.FunctionId);
                    }
                }
            }
        }

        /// <summary>
        /// Processes the assign and unassign.
        /// </summary>
        private void ProcessAssignAndUnassign(SETreeNode node)
        {
            //int recordAffected = 0;
            if (node.Checked && node.FunctionId != -1)
            {
                Int16 roleId = (Int16)cbbRole.SelectedValue;
                Int16 fnId = (Int16)node.FunctionId;
                if (!m_Bus.CheckFnIsExisted(fnId, roleId))
                {
                    List<Int16> fnIds = new List<Int16>();
                    fnIds.Add(fnId);
                    m_RecordAffected += m_Bus.AssignFunctionsToRole(roleId, fnIds);
                }
            }
            else if (!node.Checked && node.FunctionId != -1)
            {
                Int16 fnId = (Int16)node.FunctionId;
                Int16 roleId = (Int16)cbbRole.SelectedValue;
                if (m_Bus.CheckFnIsExisted(fnId, roleId))
                {
                    m_RecordAffected += m_Bus.UnassignAFnToRole(fnId, roleId);
                }
            }
            //return m_RecordAffected;
        }

        /// <summary>
        /// Processes the save when not search all.
        /// </summary>
        /// <param name="nodes">The nodes.</param>
        private bool ProcessSaveWhenNotSearchAll(TreeNodeCollection nodes)
        {
            //int recordAffected = 0;
            foreach (SETreeNode node in nodes)
            {
                if (node.Nodes.Count > 0)
                {
                    ProcessAssignAndUnassign(node);
                    ProcessSaveWhenNotSearchAll(node.Nodes);
                }
                else
                {
                    ProcessAssignAndUnassign(node);
                }
            }
            if (m_RecordAffected >= 1)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Saves to DB.
        /// </summary>
        private void SaveToDB()
        {
            // Get a list of function ids
            Int16 roleId = Int16.Parse(cbbRole.SelectedValue.ToString());
            List<Int16> FuncIds = new List<Int16>();
            GetFunctionIdList(tvFuncs.Nodes, FuncIds);

            // Assign right(function) to role
            if (radAll.Checked || radAssigned.Checked)
            {
                m_Bus.DeleteOldFuncAssignedToRole(roleId);
            }
            if (m_Bus.AssignFunctionsToRole(roleId, FuncIds) == FuncIds.Count)
            {
                clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                //m_HasChange = false;
            }
            else
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (radAll.Checked)
                PopulateTreeView("All");
            else if (radUnassign.Checked)
            {
                PopulateTreeView("Unassign");
                foreach (SETreeNode node in m_CheckedNodes)
                {
                    tvFuncs.Nodes.Remove(node);
                }
            }
            else
                PopulateTreeView("Assigned");
            RemoveEmptyNode();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (tvFuncs.Nodes.Count == 0)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.THERE_IS_NO, "right to assign to this role"));
                return;
            }
            //if (!m_HasChange)
            //{
            //    clsSEUtils.ShowMessage((int)MessageType.Information, String.Format(clsSEMessage.THERE_IS_NO, "change to save"));
            //    return;
            //}
            if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_ASSIGN_RIGHT, "Do")) == DialogResult.Yes)
            {
                try
                {
                    if (Convert.ToInt16(cbbCategory.SelectedValue) == -1 && Convert.ToInt16(cbbName.SelectedValue) == -1 && radAll.Checked)
                    {
                        SaveToDB();
                    }
                    else
                    {
                        bool success = ProcessSaveWhenNotSearchAll(tvFuncs.Nodes);
                        if (success)
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                        m_RecordAffected = 0;
                    }
                    btnSearch.PerformClick();
                }
                catch (Exception ex)
                {
                    Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                    Close();
                }                
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCollapse_Click(object sender, EventArgs e)
        {
            tvFuncs.CollapseAll();
        }

        private void btnExpand_Click(object sender, EventArgs e)
        {
            tvFuncs.ExpandAll();
        }

        private void radAll_CheckedChanged(object sender, EventArgs e)
        {
            if (radAll.Checked)
            {
                FilterSearchResults("All");
                cbbRole.Focus();
            }
        }

        private void radUnassigns_CheckedChanged(object sender, EventArgs e)
        {
            if (radUnassign.Checked)
            {
                FilterSearchResults("Unassign");
                foreach (SETreeNode node in m_CheckedNodes)
                {
                    tvFuncs.Nodes.Remove(node);
                }
                RemoveEmptyNode();
            }
        }

        private void radAssigned_CheckedChanged(object sender, EventArgs e)
        {
            if (radAssigned.Checked)
            {
                FilterSearchResults("Assigned");
            }
        }

        private void tvFuncs_AfterCheck(object sender, TreeViewEventArgs e)
        {
            if (e.Action != TreeViewAction.Unknown)
            {
                if (e.Node.Nodes.Count > 0)
                {
                    CheckAllChildNodes(e.Node, e.Node.Checked);
                }
                TreeNode root = e.Node;
                while (0 != 1)
                {
                    if (root.Level == 0)
                    {
                        break;
                    }
                    else
                    {
                        if (root.Parent != null)
                        {
                            root = root.Parent;
                            if (e.Node.Checked)
                            {
                                root.Checked = e.Node.Checked;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }

            //if (e.Node.Parent == null)
            //    m_HasChange = false;
            //else
            //    m_HasChange = true;
        }

        private void frmSecurityAssignRightToRole_FormClosing(object sender, FormClosingEventArgs e)
        {
            object c = btnSave.Tag;
            if (c != null && (bool)c && m_HasChange)
            {
                string msg = "Data has been changed. " + String.Format(clsSEMessage.CONFIRM_ASSIGN_RIGHT, "Do");
                DialogResult result = clsSEUtils.ShowMessage((int)MessageType.Confirm, msg);
                if (result == DialogResult.Yes)
                    SaveToDB();
                else if (result == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }
    }
}