﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-26 08:23:59 +0700 (Tue, 26 Mar 2013) $
 * $Revision: 12039 $ 
 * ========================================================
 * This class is used to assign menu items to a specified role
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Security.Bus;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Dto;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityAssignMenuToRole : frmSEMaster
    {
        private clsSEBus m_Bus = null;
        //private List<SETreeNode> m_CheckedNodes = null;
        //private List<SETreeNode> m_UncheckedNodes = null;
        //private List<String> m_CheckedNodes = null;

        private bool m_HasChange = false;
        //private bool allowWarning = true;
        private DataSet m_DS = null;

        private int m_RecordAffected = 0;

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityAssignMenuToRole" /> class.
        /// </summary>
        public frmSecurityAssignMenuToRole()
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();

            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                // Load combobox
                clsSEUtils.LoadComboBox(cbbRole, m_Bus.GetRoleList(), "RoleId", "RoleName");
                clsSEUtils.LoadComboBox(cbbCategory, m_Bus.GetCategoryListWithEmptyItem(), "CategoryId", "CategoryName");
                clsSEUtils.LoadComboBox(cbbName, m_Bus.GetMemuNameListWithEmptyItem(), "MenuItemId", "MenuItemName");

                radAll.Checked = true;
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityAssignMenuToRole" /> class.
        /// </summary>
        public frmSecurityAssignMenuToRole(string roleToAssign) : base()
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();

            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                // Load combobox
                clsSEUtils.LoadComboBox(cbbRole, m_Bus.GetRoleList(), "RoleId", "RoleName");
                clsSEUtils.LoadComboBox(cbbCategory, m_Bus.GetCategoryListWithEmptyItem(), "CategoryId", "CategoryName");
                clsSEUtils.LoadComboBox(cbbName, m_Bus.GetMemuNameListWithEmptyItem(), "MenuItemId", "MenuItemName");

                cbbRole.Text = roleToAssign;
                radAll.Checked = true;
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Trees the view builder.
        /// </summary>
        /// <param name="MenuItemId">The menu item id.</param>
        /// <param name="parentNode">The parent node.</param>
        private void TreeViewBuilder(int MenuItemId, SETreeNode parentNode)
        {
            //Add Node in 3 cases
            //Get list of child items of selected Menu Item
            DataRow[] childItemList = m_DS.Tables[1].Select("ParentId = '" + MenuItemId + "'");
            DataRow[] menuItemName = m_DS.Tables[1].Select("MenuItemId = " + MenuItemId);

            //Case 1: If Unasign, IsAssigned = False
            if ((childItemList.Length > 0) || radAll.Checked)
            {
                SETreeNode currentNode = null;

                //If Case "All" or "Unassigned" or ("Assigned" and current noded is checked)
                if (radAll.Checked || radUnassign.Checked || Convert.ToBoolean(menuItemName[0]["IsAssigned"]))
                {
                    Boolean allowNode = false;
                    if (radUnassign.Checked)
                    {
                        for (int i = 0; i < childItemList.Length; i++)
                        {
                            if (Convert.ToBoolean(childItemList[i]["IsAssigned"]) == false)
                            {
                                allowNode = true;
                                break;
                            }
                        }
                    }
                    if (allowNode || !radUnassign.Checked)
                    {
                        currentNode = new SETreeNode();
                        currentNode.MenuItemId = Int16.Parse(menuItemName[0]["MenuItemId"].ToString());
                        currentNode.ControlName = menuItemName[0]["MenuControlName"].ToString();
                        currentNode.Text = menuItemName[0]["MenuItemName"].ToString();
                        currentNode.CategoryId = Int16.Parse(menuItemName[0]["CategoryId"].ToString());
                        currentNode.ParentId = menuItemName[0]["ParentId"].ToString();
                        currentNode.ToolTipText = menuItemName[0]["Description"].ToString();
                        if (!radUnassign.Checked)
                        {
                            currentNode.Checked = Convert.ToBoolean(menuItemName[0]["IsAssigned"]);
                        }
                        parentNode.Nodes.Add(currentNode);
                        //Have child items?
                        for (int i = 0; i < childItemList.Length; i++)
                        {
                            TreeViewBuilder(Convert.ToInt32(childItemList[i]["MenuItemId"]), currentNode);
                        }
                    }
                }
            }
            else if ((radUnassign.Checked && !Convert.ToBoolean(menuItemName[0]["IsAssigned"])) || (radAssigned.Checked && Convert.ToBoolean(menuItemName[0]["IsAssigned"])))
            {
                SETreeNode currentNode = new SETreeNode();
                currentNode.MenuItemId = Int16.Parse(menuItemName[0]["MenuItemId"].ToString());
                currentNode.ControlName = menuItemName[0]["MenuControlName"].ToString();
                currentNode.Text = menuItemName[0]["MenuItemName"].ToString();
                currentNode.CategoryId = Int16.Parse(menuItemName[0]["CategoryId"].ToString());
                currentNode.ParentId = menuItemName[0]["ParentId"].ToString();
                currentNode.ToolTipText = menuItemName[0]["Description"].ToString();
                currentNode.Checked = Convert.ToBoolean(menuItemName[0]["IsAssigned"]);
                if (!currentNode.Checked)
                {
                    parentNode.Checked = false;
                }   
                parentNode.Nodes.Add(currentNode);
            }
        }

        /// <summary>
        /// Populate a treeview menu.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void PopulateMenuTreeView(string filter)
        {
            int roleId = Int16.Parse(cbbRole.SelectedValue.ToString());
            int categoryId = Int16.Parse(cbbCategory.SelectedValue.ToString());
            
            clsSEDto dto = new clsSEDto();
            dto.RoleID = roleId;
            dto.FnCategoryID = categoryId;
            dto.Filter = filter;

            try
            {
                m_DS = m_Bus.GetUnassignAssignedMenus(dto);

                int menuItemId = int.Parse(cbbName.SelectedValue.ToString());
                if (m_DS != null && m_DS.Tables.Count == 2)
                {
                    tvMenu.Nodes.Clear();
                    SETreeNode categoryNode = null;

                    // MenuItemID and Category are not selected
                    if (menuItemId == -1 && categoryId == -1)
                    {
                        foreach (DataRow category in m_DS.Tables[0].Rows)
                        {
                            // Add hierarchical nodes
                            categoryNode = new SETreeNode();
                            categoryNode.Text = category["CategoryName"].ToString();

                            //Get list of child items of selected Menu Item
                            DataRow[] topMenuItemOfEachCategory = m_DS.Tables[1].Select("CategoryId = " + category["CategoryId"] + " AND ParentId IS NULL");
                            foreach (DataRow item in topMenuItemOfEachCategory)
                            {
                                TreeViewBuilder(Convert.ToInt32(item["MenuItemId"]), categoryNode);
                            }
                            if (categoryNode.Nodes.Count > 0)
                            {
                                foreach (SETreeNode node in categoryNode.Nodes)
                                {
                                    if (node.Checked) categoryNode.Checked = true;
                                }
                                tvMenu.Nodes.Add(categoryNode);
                            }
                        }
                    }
                    // Category selected but MenuItemId is not selected
                    else if (menuItemId == -1 && categoryId != -1)
                    {
                        // Add hierarchical nodes
                        categoryNode = new SETreeNode();
                        categoryNode.Text = cbbCategory.Text;

                        //Get list of child items of selected Menu Item
                        DataRow[] topMenuItemOfEachCategory = m_DS.Tables[1].Select("CategoryId = '" + categoryId + "' AND ParentId IS NULL");
                        foreach (DataRow item in topMenuItemOfEachCategory)
                        {
                            TreeViewBuilder(Convert.ToInt32(item["MenuItemId"]), categoryNode);
                        }
                        if (categoryNode.Nodes.Count > 0)
                        {
                            foreach (SETreeNode node in categoryNode.Nodes)
                            {
                                if (node.Checked) categoryNode.Checked = true;
                            }
                            tvMenu.Nodes.Add(categoryNode);
                        }
                    }
                    // MenuItemId is selected but Category don't care
                    else
                    {
                        // Add hierarchical nodes
                        SETreeNode menuItemNode = new SETreeNode();
                        menuItemNode.MenuItemId = menuItemId;
                        menuItemNode.Text = cbbName.Text;
                        menuItemNode.CategoryId = categoryId;

                        DataRow[] categoryRow = m_DS.Tables[1].Select("MenuItemId = '" + menuItemId + "'");
                        if (categoryRow.Length > 0)
                        {
                            menuItemNode.ControlName = categoryRow[0]["MenuControlName"].ToString();
                            menuItemNode.ToolTipText = categoryRow[0]["Description"].ToString();
                            menuItemNode.Checked = Convert.ToBoolean(categoryRow[0]["IsAssigned"]);
                        }
                        menuItemNode.ParentId = menuItemId.ToString();

                        //Get list of child items of selected Menu Item
                        DataRow[] childMenuItemOfCurrentNode = m_DS.Tables[1].Select("ParentId = '" + menuItemId + "'");
                        foreach (DataRow item in childMenuItemOfCurrentNode)
                        {
                            TreeViewBuilder(Convert.ToInt32(item["MenuItemId"]), menuItemNode);
                        }
                        tvMenu.Nodes.Add(menuItemNode);
                        if (radUnassign.Checked && menuItemNode.Nodes.Count == 0 && menuItemNode.Checked)
                        {
                            tvMenu.Nodes.Remove(menuItemNode);
                        }
                        if (radAssigned.Checked && menuItemNode.Nodes.Count == 0 && !menuItemNode.Checked)
                        {
                            tvMenu.Nodes.Remove(menuItemNode);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Process checking parent node from down to up on treeview.
        /// </summary>		
        /// <param name="node">The node has been checked of unchecked</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void ProcessUp(TreeNode node)
        {
            if (node.Parent != null)
            {
                node.Parent.Checked = true;
            }
        }

        /// <summary>
        /// Process checking child node from up to down on treeview.
        /// </summary>		
        /// <param name="node">The node has been checked of unchecked</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void ProcessDown(TreeNode node)
        {
            foreach (TreeNode item in node.Nodes)
            {
                if (item.Checked)
                {
                    item.Checked = false;
                }
            }

            // Uncheck parent node if all childs are unchecked
            if (node.Parent != null)
            {
                bool canCheck = false;
                foreach (TreeNode item in node.Parent.Nodes)
                {
                    if (item.Checked)
                    {
                        canCheck = true;
                    }
                }
                if (!canCheck)
                {
                    if (node.Parent.Checked)
                    {
                        node.Parent.Checked = false;
                    }
                }
            }
        }

        /// <summary>
        /// Checks all child nodes.
        /// </summary>
        /// <param name="treeNode">The tree node.</param>
        /// <param name="ck">if set to <c>true</c> [ck].</param>
        private void CheckAllChildNodes(TreeNode treeNode, bool ck)
        {
            foreach (TreeNode node in treeNode.Nodes)
            {
                node.Checked = ck;
                if (node.Nodes.Count > 0)
                {
                    this.CheckAllChildNodes(node, ck);
                }
            }
        }

        /// <summary>
        /// Recall populate treeview and remove empty node functions with filter string.
        /// </summary>		
        /// <param name="filter">The string that filter what kind of node</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void FilterSearchResults(string filter)
        {
            if (cbbRole.Text.Length > 0)
            {
                PopulateMenuTreeView(filter);
            }
        }

        /// <summary>
        /// Get a list of menu ids had check status is true.
        /// </summary>		
        /// <param name="nodes">The nodes collection to selected checked nodes</param>
        /// <param name="menuIds">A list that contains menu ids of each checked node</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void GetMenuIdList(TreeNodeCollection nodes, List<Int16> menuIds)
        {
            foreach (SETreeNode node in nodes)
            {
                if (node.Nodes.Count > 0)
                {
                    if (node.ControlName != null && node.Checked && node.MenuItemId != -1)
                    {
                        menuIds.Add((Int16)node.MenuItemId);
                    }
                    GetMenuIdList(node.Nodes, menuIds);
                }
                else
                {
                    if (node.ControlName != null && node.Checked && node.MenuItemId != -1)
                    {
                        menuIds.Add((Int16)node.MenuItemId);
                    }
                }
            }
            //menuIds.Reverse();
        }

        /// <summary>
        /// Processes the assign and unassign.
        /// </summary>
        private int ProcessAssignAndUnassign(SETreeNode node)
        {
            //int recordAffected = 0;
            if (node.Checked && node.MenuItemId != -1)
            {
                Int16 roleId = (Int16)cbbRole.SelectedValue;
                Int16 menuId = (Int16)node.MenuItemId;
                if (!m_Bus.CheckMenuIsExisted(menuId, roleId))
                {
                    List<Int16> menuIds = new List<Int16>();
                    menuIds.Add(menuId);
                    m_RecordAffected += m_Bus.AssignMenusToRole(roleId, menuIds);
                }
            }
            else if (!node.Checked && node.MenuItemId != -1)
            {
                Int16 menuId = (Int16)node.MenuItemId;
                Int16 roleId = (Int16)cbbRole.SelectedValue;
                if (m_Bus.CheckMenuIsExisted(menuId, roleId))
                {
                    m_RecordAffected += m_Bus.UnassignAMenuToRole(menuId, roleId);
                }
            }
            return m_RecordAffected;
        }

        /// <summary>
        /// Processes the save when not search all.
        /// </summary>
        /// <param name="nodes">The nodes.</param>
        private bool ProcessSaveWhenNotSearchAll(TreeNodeCollection nodes)
        {
            //int recordAffected = 0;
            foreach (SETreeNode node in nodes)
            {
                if (node.Nodes.Count > 0)
                {
                    ProcessAssignAndUnassign(node);
                    ProcessSaveWhenNotSearchAll(node.Nodes);
                }
                else
                {
                    ProcessAssignAndUnassign(node);
                }
            }
            if (m_RecordAffected >= 1)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Saves to DB.
        /// </summary>
        private void SaveToDB()
        {
            // Get a list of menu item ids
            Int16 roleId = Int16.Parse(cbbRole.SelectedValue.ToString());
            List<Int16> menuIds = new List<Int16>();
            GetMenuIdList(tvMenu.Nodes, menuIds);

            // Assign menu to role
            if (radAll.Checked || radAssigned.Checked)
            {
                m_Bus.DeleteOldMenuAssignedToRole(roleId);
            }
            if (m_Bus.AssignMenusToRole(roleId, menuIds) == menuIds.Count)
            {
                clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                //m_HasChange = false;
            }
            else
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.SAVE_UNSUCCESS);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (cbbRole.Items.Count > 0)
            {
                PopulateMenuTreeView("All");
            }
            else
            {
                clsSEUtils.ShowMessage((int)MessageType.Information, String.Format(clsSEMessage.THERE_IS_NO, "role to search"));
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (tvMenu.Nodes.Count == 0)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.THERE_IS_NO, "right to assign to this role"));
                return;
            }
            if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_ASSIGN_ROLE, "Do")) == DialogResult.Yes)
            {
                try
                {
                    if (Convert.ToInt16(cbbCategory.SelectedValue) == -1 && Convert.ToInt16(cbbName.SelectedValue) == -1 && radAll.Checked)
                    {
                        SaveToDB();
                    }
                    else
                    {
                        bool success = ProcessSaveWhenNotSearchAll(tvMenu.Nodes);
                        if (success)
                            clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.SAVE_SUCCESS);
                        m_RecordAffected = 0;
                    }
                    btnSearch.PerformClick();
                }
                catch (Exception ex)
                {
                    Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                    Close();
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCollapse_Click(object sender, EventArgs e)
        {
            tvMenu.CollapseAll();
        }

        private void btnExpand_Click(object sender, EventArgs e)
        {
            tvMenu.ExpandAll();
        }

        private void radAll_CheckedChanged(object sender, EventArgs e)
        {
            if (radAll.Checked && cbbRole.Items.Count > 0)
            {
                FilterSearchResults("All");
            }
        }

        private void radUnassign_CheckedChanged(object sender, EventArgs e)
        {
            if (radUnassign.Checked && cbbRole.Items.Count > 0)
            {
                FilterSearchResults("All");
            }
        }

        private void radAssigned_CheckedChanged(object sender, EventArgs e)
        {
            if (radAssigned.Checked && cbbRole.Items.Count > 0)
            {
                FilterSearchResults("All");
            }
        }

        private void tvMenu_BeforeCheck(object sender, TreeViewCancelEventArgs e)
        {
            //if (allowWarning)
            //{
            //    // If current node is parent node and is not checked
            //    if (e.Node.Nodes.Count != 0 && !e.Node.Checked)
            //    {
            //        clsSEUtils.ShowMessage((int)MessageType.Error, "Please select a leaf node");
            //        e.Cancel = true;
            //    }
            //}
        }

        private void tvMenu_AfterCheck(object sender, TreeViewEventArgs e)
        {
            if (e.Action != TreeViewAction.Unknown)
            {
                if (e.Node.Nodes.Count > 0)
                {
                    CheckAllChildNodes(e.Node, e.Node.Checked);
                }
                TreeNode root = e.Node;
                while (0 != 1)
                {
                    if (root.Level == 0)
                    {
                        break;
                    }
                    else
                    {
                        if (root.Parent != null)
                        {
                            root = root.Parent;
                            if (e.Node.Checked)
                            {
                                root.Checked = e.Node.Checked;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }

            //if (e.Node.Checked)
            //{
            //    allowWarning = false;
            //    ProcessUp(e.Node);
            //    allowWarning = true;
            //}
            //else
            //    ProcessDown(e.Node);

            //if (e.Node.Parent == null)
            //    m_HasChange = false;
            //else
            //    m_HasChange = true;
        }

        private void cbbName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cbbName.SelectedValue) == -1)
            {
                cbbCategory.Enabled = true;
            }
            else
            {
                cbbCategory.SelectedIndex = 0;
                cbbCategory.Enabled = false;
            }
        }

        private void frmSecurityAssignMenuToRole_FormClosing(object sender, FormClosingEventArgs e)
        {
            object c = btnSave.Tag;
            if (c != null && (bool)c && m_HasChange)
            {
                string msg = "Data has been changed. " + String.Format(clsSEMessage.CONFIRM_ASSIGN_RIGHT, "Do");
                DialogResult result = clsSEUtils.ShowMessage((int)MessageType.Confirm, msg);
                if (result == DialogResult.Yes)
                    SaveToDB();
                else if (result == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }
    }
}