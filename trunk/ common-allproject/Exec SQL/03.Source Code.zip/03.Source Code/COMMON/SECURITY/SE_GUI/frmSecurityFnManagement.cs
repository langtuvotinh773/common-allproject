﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-25 20:52:00 +0700 (Mon, 25 Mar 2013) $
 * $Revision: 12034 $ 
 * ========================================================
 * This class is used to manage (create, update, delete) a function
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Security.Bus;
using Phoenix.Common.Security.Dto;

namespace Phoenix.Common.Security.Gui
{
    public partial class frmSecurityFnManagement : frmSEMaster
    {
        private clsSEBus m_Bus = null;
        private string m_ParentNodeName = null;
        private bool m_IsParentSelected = false;
        private bool m_IsModifiedFn = false;
        private int m_ReserveIndex = 0;

        /// <summary>
        /// Initializes a new instance of the <see cref="frmSecurityFuncManagement" /> class.
        /// </summary>
        public frmSecurityFnManagement() : base()
        {
            InitializeComponent();
            SetCommonControlStyle();

            m_Bus = new clsSEBus();

            try
            {
                // Check security
                clsSEAuthorizer security = new clsSEAuthorizer(clsUserInfo.UserNo, Name);
                security.CheckAuthorizationOnScreen(this);

                // Load combobox
                clsSEUtils.LoadComboBox(cbbName, m_Bus.GetFunctionNameWithEmptyItem(), "FunctionId", "FunctionName");
                clsSEUtils.LoadComboBox(cbbCategory, m_Bus.GetCategoryListWithEmptyItem(), "CategoryId", "CategoryName");
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Populate a treeview function.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void PopulateFunctionTreeView()
        {
            clsSEDto dto = new clsSEDto();
            dto.FnCategoryID = Int16.Parse(cbbCategory.SelectedValue.ToString());

            try
            {
                DataSet ds = m_Bus.GetFunctionList(dto);

                int fId = int.Parse(cbbName.SelectedValue.ToString());
                if (fId != -1)
                {
                    DataRow[] parent = ds.Tables[1].Select("FunctionId = " + fId);
                    DataRow[] childs = ds.Tables[1].Select("ParentId = '" + fId + "'");
                    DataTable dt = ds.Tables[1].Clone();
                    if (parent.Length > 0)
                    {
                        dt.ImportRow(parent[0]);
                    }
                    foreach (DataRow child in childs)
                    {
                        dt.ImportRow(child);
                    }
                    dt.AcceptChanges();
                    ds.Tables.RemoveAt(1);
                    ds.Tables.Add(dt);
                }

                if (ds != null && ds.Tables.Count == 2)
                {
                    treeView1.Nodes.Clear();
                    foreach (DataRow category in ds.Tables[0].Rows)
                    {
                        // Add hierarchical nodes
                        SETreeNode categoryNode = new SETreeNode();
                        categoryNode.Text = category["CategoryName"].ToString();
                        DataRow[] parentRows = ds.Tables[1].Select("ParentId = '' OR ParentId IS NULL");
                        foreach (DataRow form in parentRows)
                        {
                            if (form["CategoryId"].Equals(category["CategoryId"]))
                            {
                                SETreeNode formNode = new SETreeNode();
                                formNode.FunctionId = Int16.Parse(form["FunctionId"].ToString());
                                formNode.Text = form["FunctionName"].ToString();
                                formNode.ControlName = form["ControlName"].ToString();
                                formNode.ParentId = form["ParentId"].ToString();
                                formNode.CategoryId = Int16.Parse(form["CategoryId"].ToString());
                                formNode.CategoryName = form["CategoryName"].ToString();
                                formNode.ToolTipText = form["Description"].ToString();
                                CreateChildNode(formNode, ds.Tables[1]);
                                categoryNode.Nodes.Add(formNode);
                            }
                        }
                        treeView1.Nodes.Add(categoryNode);
                    }
                    int index = 0, total = treeView1.Nodes.Count;
                    for (int i = 0; i < total; i++)
                    {
                        if (treeView1.Nodes[index].Nodes.Count == 0)
                            treeView1.Nodes.Remove(treeView1.Nodes[index]);
                        else
                            ++index;
                    }
                }

                m_ReserveIndex = cbbName.SelectedIndex;
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        /// <summary>
        /// Create a child node for the parent node.
        /// </summary>		
        /// <param name="node">The parent node will contain child nodes</param>
        /// <param name="dt">DataTable contains records to get child nodes</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        private void CreateChildNode(SETreeNode node, DataTable dt)
        {
            DataRow[] rows = dt.Select("ParentId = '" + node.FunctionId + "'");
            if (rows.Length == 0) return;
            for (int i = 0; i < rows.Length; i++)
            {
                SETreeNode child = new SETreeNode();
                child.FunctionId = Int16.Parse(rows[i]["FunctionId"].ToString());
                child.ControlName = rows[i]["ControlName"].ToString();
                child.Text = rows[i]["FunctionName"].ToString();
                child.ParentId = rows[i]["ParentId"].ToString();
                child.CategoryId = Int16.Parse(rows[i]["CategoryId"].ToString());
                child.CategoryName = rows[i]["CategoryName"].ToString();
                child.ToolTipText = rows[i]["Description"].ToString();
                node.Nodes.Add(child);
                CreateChildNode(child, dt);
            }
        }

        private void frmSecurityFuncManagement_Load(object sender, EventArgs e)
        {
            PopulateFunctionTreeView();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            PopulateFunctionTreeView();
        }

        private void btnCreateParent_Click(object sender, EventArgs e)
        {
            m_IsModifiedFn = true;

            frmSecurityAddModifyFunc frm = new frmSecurityAddModifyFunc(SEAction.CreateParentForm);
            frm.OnSaveFunction += new frmSecurityAddModifyFunc.SaveFunction(OnSaveFunction);
            frm.StartPosition = FormStartPosition.CenterParent;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void btnCreateChild_Click(object sender, EventArgs e)
        {
            SETreeNode selectedNode = treeView1.SelectedNode as SETreeNode;
            if (selectedNode == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.THERE_IS_NO, "item is selected"));
                return;
            }
            if (!m_IsParentSelected)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.NOT_A_PARENT_FN);
                return;
            }

            m_IsModifiedFn = true;

            frmSecurityAddModifyFunc frm = new frmSecurityAddModifyFunc(SEAction.CreateChildAction);
            string parentName = selectedNode.Text;
            string parentId = selectedNode.FunctionId.ToString();
            string category = selectedNode.Parent.Text;
            int categoryId = selectedNode.CategoryId;
            frm.PassUpdateFuncInfo(-1, parentName, parentId, category, "", "", "");
            frm.OnSaveFunction += new frmSecurityAddModifyFunc.SaveFunction(OnSaveFunction);
            frm.StartPosition = FormStartPosition.CenterParent;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog(); 
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            SETreeNode selectedNode = treeView1.SelectedNode as SETreeNode;
            if (selectedNode == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.THERE_IS_NO, "item is selected"));
                return;
            }
            if (selectedNode != null && selectedNode.ParentId == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.INVALID_FN);
                return;
            }

            m_IsModifiedFn = true;

            frmSecurityAddModifyFunc frm = new frmSecurityAddModifyFunc(SEAction.ModifyFunction);
            SETreeNode node = (treeView1.SelectedNode as SETreeNode);
            int fnId = node.FunctionId;
            string parentId = node.ParentId.ToString();
            string categoryName = node.CategoryName;
            int categoryId = node.CategoryId;
            frm.PassUpdateFuncInfo(fnId, m_ParentNodeName, parentId, categoryName, node.ControlName, node.Text, node.ToolTipText);
            frm.OnSaveFunction += new frmSecurityAddModifyFunc.SaveFunction(OnSaveFunction);
            frm.StartPosition = FormStartPosition.CenterParent;
            if (!frm.IsDisposed)
            {
                frm.ShowDialog();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SETreeNode selectedNode = treeView1.SelectedNode as SETreeNode;
            if (selectedNode == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, String.Format(clsSEMessage.THERE_IS_NO, "item is selected"));
                return;
            }
            if (selectedNode != null && selectedNode.ParentId == null)
            {
                clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.INVALID_FN);
                return;
            }
            try
            {
                if (m_Bus.CheckFnIsAssignedToRole((Int16)selectedNode.FunctionId))
                {
                    clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.CANNOT_DELETE_FN);
                    return;
                }
                if (clsSEUtils.ShowMessage((int)MessageType.YesNoConfirm, String.Format(clsSEMessage.CONFIRM_DELETE_FUNCTION, "Are you sure")) == DialogResult.Yes)
                {
                    m_IsModifiedFn = false;
                    clsSEDto dto = new clsSEDto();
                    //SETreeNode node = (SETreeNode)treeView1.SelectedNode;
                    dto.FunctionID = selectedNode.FunctionId;
                    dto.ParentID = selectedNode.ParentId;
                    int recordAffected = m_Bus.DeleteFunction(dto);
                    if (recordAffected > 0)
                    {
                        clsSEUtils.ShowMessage((int)MessageType.Information, clsSEMessage.DELETE_SUCCESS);
                        cbbName.DataSource = m_Bus.GetFunctionNameWithEmptyItem();
                        PopulateFunctionTreeView();
                    }
                    else
                        clsSEUtils.ShowMessage((int)MessageType.Error, clsSEMessage.DELETE_UNSUCCESS);
                }
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            SETreeNode node = (e.Node as SETreeNode);
            if (node.Parent != null && node.ParentId.Length == 0)
            {
                m_IsParentSelected = true;
                m_ParentNodeName = String.Empty;
            }
            else if (node.Parent != null && node.ParentId != null)
            {
                m_IsParentSelected = false;
                m_ParentNodeName = node.Parent.Text;
            }
            else
                m_IsParentSelected = false;
        }

        private void OnSaveFunction()
        {
            try
            {
                cbbName.DataSource = m_Bus.GetFunctionNameWithEmptyItem();
                if (m_IsModifiedFn)
                {
                    cbbName.SelectedIndex = m_ReserveIndex;
                }
            }
            catch (Exception ex)
            {
                Phoenix.Common.Functions.clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                Close();
            }
            PopulateFunctionTreeView();
        }
    }
}