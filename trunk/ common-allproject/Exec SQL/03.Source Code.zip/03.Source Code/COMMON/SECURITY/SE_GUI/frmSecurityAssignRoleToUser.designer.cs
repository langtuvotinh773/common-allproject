﻿namespace Phoenix.Common.Security.Gui
{
    partial class frmSecurityAssignRoleToUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbbUserName = new System.Windows.Forms.ComboBox();
            this.cbbRoleName = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radUserName = new System.Windows.Forms.RadioButton();
            this.radRoleName = new System.Windows.Forms.RadioButton();
            this.btnDoubleLeft = new System.Windows.Forms.Button();
            this.btnSingleLeft = new System.Windows.Forms.Button();
            this.btnSingleRight = new System.Windows.Forms.Button();
            this.btnDoubleRight = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.cbbDept = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDeptUser = new System.Windows.Forms.TextBox();
            this.txtDept = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lvUnassign = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.lvAssigned = new System.Windows.Forms.ListView();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblNameValue = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbbUserName
            // 
            this.cbbUserName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbUserName.FormattingEnabled = true;
            this.cbbUserName.Items.AddRange(new object[] {
            "Nguyen Van A"});
            this.cbbUserName.Location = new System.Drawing.Point(100, 16);
            this.cbbUserName.Name = "cbbUserName";
            this.cbbUserName.Size = new System.Drawing.Size(173, 21);
            this.cbbUserName.TabIndex = 1;
            this.cbbUserName.SelectedIndexChanged += new System.EventHandler(this.cbbUserName_SelectedIndexChanged);
            // 
            // cbbRoleName
            // 
            this.cbbRoleName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbRoleName.Enabled = false;
            this.cbbRoleName.FormattingEnabled = true;
            this.cbbRoleName.Location = new System.Drawing.Point(402, 16);
            this.cbbRoleName.Margin = new System.Windows.Forms.Padding(5);
            this.cbbRoleName.Name = "cbbRoleName";
            this.cbbRoleName.Size = new System.Drawing.Size(173, 21);
            this.cbbRoleName.TabIndex = 3;
            this.cbbRoleName.SelectedIndexChanged += new System.EventHandler(this.cbbRoleName_SelectedIndexChanged);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(439, 311);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.Location = new System.Drawing.Point(520, 311);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "&Close";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Role Code";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Role Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Remark";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // radUserName
            // 
            this.radUserName.AutoSize = true;
            this.radUserName.Location = new System.Drawing.Point(7, 21);
            this.radUserName.Name = "radUserName";
            this.radUserName.Size = new System.Drawing.Size(72, 17);
            this.radUserName.TabIndex = 0;
            this.radUserName.TabStop = true;
            this.radUserName.Text = "Full Name";
            this.radUserName.UseVisualStyleBackColor = true;
            this.radUserName.CheckedChanged += new System.EventHandler(this.radUserName_CheckedChanged);
            // 
            // radRoleName
            // 
            this.radRoleName.AutoSize = true;
            this.radRoleName.Location = new System.Drawing.Point(322, 21);
            this.radRoleName.Name = "radRoleName";
            this.radRoleName.Size = new System.Drawing.Size(78, 17);
            this.radRoleName.TabIndex = 2;
            this.radRoleName.TabStop = true;
            this.radRoleName.Text = "Role Name";
            this.radRoleName.UseVisualStyleBackColor = true;
            this.radRoleName.CheckedChanged += new System.EventHandler(this.radRoleName_CheckedChanged);
            // 
            // btnDoubleLeft
            // 
            this.btnDoubleLeft.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDoubleLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDoubleLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoubleLeft.ForeColor = System.Drawing.Color.Blue;
            this.btnDoubleLeft.Location = new System.Drawing.Point(286, 202);
            this.btnDoubleLeft.Name = "btnDoubleLeft";
            this.btnDoubleLeft.Size = new System.Drawing.Size(30, 27);
            this.btnDoubleLeft.TabIndex = 8;
            this.btnDoubleLeft.Text = "<<";
            this.btnDoubleLeft.UseVisualStyleBackColor = false;
            this.btnDoubleLeft.Click += new System.EventHandler(this.btnDoubleLeft_Click);
            // 
            // btnSingleLeft
            // 
            this.btnSingleLeft.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSingleLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSingleLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingleLeft.ForeColor = System.Drawing.Color.Red;
            this.btnSingleLeft.Location = new System.Drawing.Point(286, 169);
            this.btnSingleLeft.Name = "btnSingleLeft";
            this.btnSingleLeft.Size = new System.Drawing.Size(30, 27);
            this.btnSingleLeft.TabIndex = 7;
            this.btnSingleLeft.Text = "<";
            this.btnSingleLeft.UseVisualStyleBackColor = false;
            this.btnSingleLeft.Click += new System.EventHandler(this.btnSingleLeft_Click);
            // 
            // btnSingleRight
            // 
            this.btnSingleRight.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSingleRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSingleRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingleRight.ForeColor = System.Drawing.Color.Red;
            this.btnSingleRight.Location = new System.Drawing.Point(286, 136);
            this.btnSingleRight.Name = "btnSingleRight";
            this.btnSingleRight.Size = new System.Drawing.Size(30, 27);
            this.btnSingleRight.TabIndex = 6;
            this.btnSingleRight.Text = ">";
            this.btnSingleRight.UseVisualStyleBackColor = false;
            this.btnSingleRight.Click += new System.EventHandler(this.btnSingleRight_Click);
            // 
            // btnDoubleRight
            // 
            this.btnDoubleRight.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDoubleRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDoubleRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoubleRight.ForeColor = System.Drawing.Color.Blue;
            this.btnDoubleRight.Location = new System.Drawing.Point(286, 103);
            this.btnDoubleRight.Name = "btnDoubleRight";
            this.btnDoubleRight.Size = new System.Drawing.Size(30, 27);
            this.btnDoubleRight.TabIndex = 5;
            this.btnDoubleRight.Text = ">>";
            this.btnDoubleRight.UseVisualStyleBackColor = false;
            this.btnDoubleRight.Click += new System.EventHandler(this.btnDoubleRight_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(500, 82);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "Sea&rch";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // cbbDept
            // 
            this.cbbDept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbDept.FormattingEnabled = true;
            this.cbbDept.Location = new System.Drawing.Point(100, 82);
            this.cbbDept.Name = "cbbDept";
            this.cbbDept.Size = new System.Drawing.Size(173, 21);
            this.cbbDept.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Department";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.txtDeptUser);
            this.groupBox1.Controls.Add(this.txtDept);
            this.groupBox1.Controls.Add(this.txtUserName);
            this.groupBox1.Controls.Add(this.radUserName);
            this.groupBox1.Controls.Add(this.cbbUserName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbbDept);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cbbRoleName);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.radRoleName);
            this.groupBox1.Location = new System.Drawing.Point(5, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(601, 118);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // txtDeptUser
            // 
            this.txtDeptUser.Enabled = false;
            this.txtDeptUser.Location = new System.Drawing.Point(100, 60);
            this.txtDeptUser.Name = "txtDeptUser";
            this.txtDeptUser.Size = new System.Drawing.Size(173, 20);
            this.txtDeptUser.TabIndex = 9;
            // 
            // txtDept
            // 
            this.txtDept.Enabled = false;
            this.txtDept.Location = new System.Drawing.Point(402, 39);
            this.txtDept.Name = "txtDept";
            this.txtDept.Size = new System.Drawing.Size(173, 20);
            this.txtDept.TabIndex = 7;
            // 
            // txtUserName
            // 
            this.txtUserName.Enabled = false;
            this.txtUserName.Location = new System.Drawing.Point(100, 39);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(173, 20);
            this.txtUserName.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Department User";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(319, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Department";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "User Name";
            // 
            // lvUnassign
            // 
            this.lvUnassign.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lvUnassign.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvUnassign.FullRowSelect = true;
            this.lvUnassign.Location = new System.Drawing.Point(9, 57);
            this.lvUnassign.Name = "lvUnassign";
            this.lvUnassign.Size = new System.Drawing.Size(271, 248);
            this.lvUnassign.TabIndex = 4;
            this.lvUnassign.UseCompatibleStateImageBehavior = false;
            this.lvUnassign.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Roles";
            this.columnHeader1.Width = 130;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Department";
            this.columnHeader2.Width = 120;
            // 
            // lvAssigned
            // 
            this.lvAssigned.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lvAssigned.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.lvAssigned.FullRowSelect = true;
            this.lvAssigned.Location = new System.Drawing.Point(322, 57);
            this.lvAssigned.Name = "lvAssigned";
            this.lvAssigned.Size = new System.Drawing.Size(273, 248);
            this.lvAssigned.TabIndex = 9;
            this.lvAssigned.UseCompatibleStateImageBehavior = false;
            this.lvAssigned.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Roles";
            this.columnHeader3.Width = 130;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Department";
            this.columnHeader4.Width = 120;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Unassign";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(319, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Assigned";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.lblNameValue);
            this.groupBox2.Controls.Add(this.lblName);
            this.groupBox2.Controls.Add(this.lvUnassign);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnCancel);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnDoubleRight);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.btnSingleRight);
            this.groupBox2.Controls.Add(this.lvAssigned);
            this.groupBox2.Controls.Add(this.btnSingleLeft);
            this.groupBox2.Controls.Add(this.btnDoubleLeft);
            this.groupBox2.Location = new System.Drawing.Point(5, 124);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(601, 349);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // lblNameValue
            // 
            this.lblNameValue.AutoSize = true;
            this.lblNameValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameValue.ForeColor = System.Drawing.Color.Blue;
            this.lblNameValue.Location = new System.Drawing.Point(69, 12);
            this.lblNameValue.Name = "lblNameValue";
            this.lblNameValue.Size = new System.Drawing.Size(51, 16);
            this.lblNameValue.TabIndex = 1;
            this.lblNameValue.Text = "label7";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(6, 15);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(57, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Full Name:";
            // 
            // frmSecurityAssignRoleToUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 485);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmSecurityAssignRoleToUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Assign Roles to User";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSecurityAssignRoleToUser_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbbUserName;
        private System.Windows.Forms.ComboBox cbbRoleName;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.RadioButton radUserName;
        private System.Windows.Forms.RadioButton radRoleName;
        private System.Windows.Forms.Button btnDoubleLeft;
        private System.Windows.Forms.Button btnSingleLeft;
        private System.Windows.Forms.Button btnSingleRight;
        private System.Windows.Forms.Button btnDoubleRight;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ComboBox cbbDept;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListView lvUnassign;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ListView lvAssigned;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.TextBox txtDeptUser;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDept;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblNameValue;
        private System.Windows.Forms.Label lblName;
    }
}