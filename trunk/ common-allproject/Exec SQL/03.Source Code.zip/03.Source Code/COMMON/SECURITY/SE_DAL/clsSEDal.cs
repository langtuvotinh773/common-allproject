﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-02 16:45:18 +0700 (Sat, 02 Mar 2013) $
 * $Revision: 9331 $ 
 * ========================================================
 * This class is used to provide functions of data access layer
 * for SECURITY module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using Config.Classes;
using Phoenix.Common.Security.Dto;

namespace Phoenix.Common.Security.Dal
{
    public class clsSEDal : clsDALBase
    {
        private string m_ConnStr = null;

        public clsSEDal(string dbConnectionName) : base(dbConnectionName)
        {
            m_ConnStr = dbConnectionName;
        }

        /// <summary>
        /// Get a list of menu items.
        /// </summary>		
        /// <param name="categoryId">Id of a category</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet GetMenuItemsList(int categoryId)
        {
            DataSet ds = new DataSet();
            using (SqlConnection conn = new SqlConnection(m_ConnStr))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "spSE_GetMenuItemList";
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter value = new SqlParameter();
                    value.ParameterName = "@CategoryId";
                    if (categoryId == -1)
                        value.Value = DBNull.Value;
                    else
                        value.Value = categoryId;
                    cmd.Parameters.Add(value);
                    FillDataSet(cmd, ds);
                }
            }
            return ds;                 
        }

        /// <summary>
        /// Get a list of functions.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet GetFunctionList(clsSEDto dto)
        {
            DataSet ds = new DataSet();
            using (SqlConnection conn = new SqlConnection(m_ConnStr))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "spSE_GetFunctionList";
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter value = new SqlParameter();
                    value.ParameterName = "@CategoryId";
                    if (dto.FnCategoryID == -1)
                        value.Value = DBNull.Value;
                    else
                        value.Value = dto.FnCategoryID;
                    cmd.Parameters.Add(value);
                    FillDataSet(cmd, ds);
                }
            }
            return ds;
        }

        /// <summary>
        /// Search a list of functions with conditions.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet SearchFunction(clsSEDto dto)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(m_ConnStr);
            SqlCommand cmd = conn.CreateCommand();
            SqlParameter[] values = new SqlParameter[2];
            if (dto.FunctionName == "")
                values[0] = new SqlParameter("@FnName", DBNull.Value);
            else
                values[0] = new SqlParameter("@FnName", dto.FunctionName);
            if (dto.FnCategoryID == -1)
                values[1] = new SqlParameter("@CategoryId", DBNull.Value);
            else
                values[1] = new SqlParameter("@CategoryId", dto.FnCategoryID);
            cmd.CommandText = "spSE_SearchFunction";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddRange(values);
            FillDataSet(cmd, ds);

            return ds;
        }

        /// <summary>
        /// Get a list of roles was assigned to a user.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet SearchRolesAssignedToUser(clsSEDto dto)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(m_ConnStr);
            SqlCommand cmd = conn.CreateCommand();
            SqlParameter[] values = new SqlParameter[2];
            values[0] = new SqlParameter("@UserNo", dto.UserNo);
            if (dto.DepartmentId == -1)
                values[1] = new SqlParameter("@DepartmentId", DBNull.Value);
            else
                values[1] = new SqlParameter("@DepartmentId", dto.DepartmentId);
            cmd.CommandText = "spSE_SearchRolesAssignedToUser";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddRange(values);
            FillDataSet(cmd, ds);

            return ds;
        }

        /// <summary>
        /// Get a list of users was assigned to a role.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond 
        public DataSet SearchUsersAssignedToRole(clsSEDto dto)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(m_ConnStr);
            SqlCommand cmd = conn.CreateCommand();
            SqlParameter[] value = new SqlParameter[1];
            value[0] = new SqlParameter("@RoleId", dto.RoleID);
            //if (dto.DepartmentId == -1)
            //    values[1] = new SqlParameter("@DepartmentId", DBNull.Value);
            //else
            //    values[1] = new SqlParameter("@DepartmentId", dto.DepartmentId);
            cmd.CommandText = "spSE_SearchUsersAssignedToRole";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddRange(value);
            FillDataSet(cmd, ds);

            return ds;
        }

        /// <summary>
        /// Get un and assigned functions for a role.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet GetUnassignAssignedFunctions(clsSEDto dto)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(m_ConnStr);
            SqlCommand cmd = conn.CreateCommand();
            SqlParameter[] values = new SqlParameter[3];
            if (dto.RoleID == -1)
                values[0] = new SqlParameter("@RoleId", DBNull.Value);
            else
                values[0] = new SqlParameter("@RoleId", dto.RoleID);
            if (dto.FnCategoryID == -1)
                values[1] = new SqlParameter("@CategoryId", DBNull.Value);
            else
                values[1] = new SqlParameter("@CategoryId", dto.FnCategoryID);
            values[2] = new SqlParameter("@Filter", dto.Filter);
            cmd.CommandText = "spSE_GetUnassignAssignedFunctions";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddRange(values);
            FillDataSet(cmd, ds);

            return ds;
        }

        /// <summary>
        /// Get un and assigned menus for a role.
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataSet GetUnassignAssignedMenus(clsSEDto dto)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(m_ConnStr);
            SqlCommand cmd = conn.CreateCommand();
            SqlParameter[] values = new SqlParameter[3];
            if (dto.RoleID == -1)
                values[0] = new SqlParameter("@RoleId", DBNull.Value);
            else
                values[0] = new SqlParameter("@RoleId", dto.RoleID);
            if (dto.FnCategoryID == -1)
                values[1] = new SqlParameter("@CategoryId", DBNull.Value);
            else
                values[1] = new SqlParameter("@CategoryId", dto.FnCategoryID);
            values[2] = new SqlParameter("@Filter", dto.Filter);
            cmd.CommandText = "spSE_GetUnassignAssignedMenus";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddRange(values);
            FillDataSet(cmd, ds);

            return ds;
        }

        /// <summary>
        /// Get a list of function names. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetFunctionName()
        {
            return ExecuteDataReader("spSE_GetFunctionName", CommandType.StoredProcedure);
        }

        /// <summary>
        /// Get a list of the top most menu items. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetTopMostMenuItems()
        {
            return ExecuteDataReader("spSE_GetTopMostMenuItem", CommandType.StoredProcedure);
        }

        /// <summary>
        /// Get a list of category ids and names. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetCategoryList()
        {
            return ExecuteDataReader("spSE_GetCategoryList", CommandType.StoredProcedure);
        }

        /// <summary>
        /// Get a list of department ids and names. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetDepartmentList()
        {
            return ExecuteDataReader("spSE_GetDepartmentList", CommandType.StoredProcedure);
        }

        /// <summary>
        /// Get a list of user ids and names. 
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetUserList()
        {
            return ExecuteDataReader("spSE_GetUserList", CommandType.StoredProcedure);
        }

        /// <summary>
        /// Get a list of roles.
        /// </summary>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetRoleList()
        {
            return ExecuteDataReader("spSE_GetRoleList", CommandType.StoredProcedure);
        }

        /// <summary>
        /// Search a list of roles with conditions. 
        /// </summary>		
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable SearchRole(clsSEDto dto)
        {
            SqlParameter[] values = new SqlParameter[2];
            //if (dto.RoleName == null || dto.RoleName == String.Empty)
            //    values[0] = new SqlParameter("@RoleName", DBNull.Value);
            //else
            //    values[0] = new SqlParameter("@RoleName", dto.RoleName);
            values[0] = new SqlParameter("@RoleName", dto.RoleName);
            if (dto.DepartmentId == -1)
                values[1] = new SqlParameter("@DeptId", DBNull.Value);
            else
                values[1] = new SqlParameter("@DeptId", dto.DepartmentId);

            return ExecuteDataReader("spSE_SearchRole", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Gets the list of menu control names.
        /// </summary>
        /// <returns></returns>
        public List<String> GetMenuControlNameList()
        {
            List<String> List = new List<String>();
            DataTable dt = ExecuteDataReader("spSE_GetMenuControlNameList", CommandType.StoredProcedure);
            foreach (DataRow row in dt.Rows)
            {
                List.Add(row["MenuControlName"].ToString());
            }
            return List;
        }

        /// <summary>
        /// Get a list of authorized menu items for a specified user. 
        /// </summary>
        /// <param name="userNo">The order number of user</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public List<String> GetAuthorizedMenuListByUser(int userNo)
        {
            List<String> AuthorizedMenuList = new List<String>();
            SqlParameter value = new SqlParameter("@UserNo", userNo);
            DataTable dt = ExecuteDataReader("spSE_GetAuthorizedMenuList", CommandType.StoredProcedure, value);
            foreach (DataRow row in dt.Rows)
            {
                AuthorizedMenuList.Add(row["MenuControlName"].ToString());
            }
            return AuthorizedMenuList;
        }

        /// <summary>
        /// Get a list of unauthorized menu items for a specified user. 
        /// </summary>
        /// <param name="userNo">The order number of user</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public List<String> GetUnAuthorizedMenuListByUser(int userNo)
        {
            List<String> UnAuthorizedMenuList = new List<String>();
            SqlParameter value = new SqlParameter("@UserNo", userNo);
            DataTable dt = ExecuteDataReader("spSE_GetUnauthorizedMenuList", CommandType.StoredProcedure, value);
            foreach (DataRow row in dt.Rows)
            {
                UnAuthorizedMenuList.Add(row["MenuControlName"].ToString());
            }
            return UnAuthorizedMenuList;
        }

        /// <summary>
        /// Get a list of authorized function items for a specified user. 
        /// </summary>
        /// <param name="userNo">The order number of user</param>
        /// <param name="screenName">The name of the screen</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public List<String> GetAuthorizedFunctionList(int userNo, string screenName)
        {
            List<String> AuthorizedFnList = new List<String>();
            SqlParameter[] values = new SqlParameter[] { 
                new SqlParameter("@UserNo", userNo),
                new SqlParameter("@ScreenName", screenName)
            };
            DataTable dt = ExecuteDataReader("spSE_GetAuthorizedFunctionList", CommandType.StoredProcedure, values);
            foreach (DataRow row in dt.Rows)
            {
                AuthorizedFnList.Add(row["ControlName"].ToString());
            }
            return AuthorizedFnList;
        }

        /// <summary>
        /// Get a list of unauthorized function items for a specified user. 
        /// </summary>
        /// <param name="userNo">The order number of user</param>
        /// <param name="screenName">The name of the screen</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public List<String> GetUnAuthorizedFunctionList(int userNo, string screenName)
        {
            List<String> UnAuthorizedFnList = new List<String>();
            SqlParameter[] values = new SqlParameter[] { 
                new SqlParameter("@UserNo", userNo),
                new SqlParameter("@ScreenName", screenName)
            };
            DataTable dt = ExecuteDataReader("spSE_GetUnauthorizedFunctionList", CommandType.StoredProcedure, values);
            foreach (DataRow row in dt.Rows)
            {
                UnAuthorizedFnList.Add(row["ControlName"].ToString());
            }
            return UnAuthorizedFnList;
        }

        /// <summary>
        /// Assign functions to a specified role. 
        /// </summary>
        /// <param name="roleId">Id of a role</param>
        /// <param name="funcIds">The list of function ids</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int AssignFunctionsToRole(int roleId, List<Int16> funcIds)
        {
            int recordAffected = 0;
            int count = funcIds.Count;
            for (int i = 0; i < count; i++)
            {
                SqlParameter[] values = new SqlParameter[] { 
                    new SqlParameter("@FuncId", funcIds[i]),
                    new SqlParameter("@RoleId", roleId)
                };
                if (ExecuteNonQuery("spSE_AssignFuncToRole", CommandType.StoredProcedure, values) == 1)
                {
                    ++recordAffected;
                }
            }
            return recordAffected;
        }

        /// <summary>
        /// Assign menus to a specified role. 
        /// </summary>
        /// <param name="roleId">Id of a role</param>
        /// <param name="menuIds">The list of menu item ids</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int AssignMenusToRole(int roleId, List<Int16> menuIds)
        {
            int recordAffected = 0;
            int count = menuIds.Count;
            for (int i = 0; i < count; i++)
            {
                SqlParameter[] values = new SqlParameter[] { 
                    new SqlParameter("@MenuItemId", menuIds[i]),
                    new SqlParameter("@RoleId", roleId)
                };
                if (ExecuteNonQuery("spSE_AssignMenuToRole", CommandType.StoredProcedure, values) == 1)
                {
                    ++recordAffected;
                }
            }
            return recordAffected;
        }

        /// <summary>
        /// Assign users to a specified role. 
        /// </summary>
        /// <param name="userIds">The list of user ids</param>
        /// <param name="roleId">Id of a role</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int AssignRoleToUser(List<Int16> roleIds, int userNo)
        {
            int recordAffected = 0;
            for (int i = 0; i < roleIds.Count; i++)
            {
                SqlParameter[] values = new SqlParameter[] { 
                    new SqlParameter("@RoleId", roleIds[i]),
                    new SqlParameter("@UserNo", userNo)
                };
                if (ExecuteNonQuery("spSE_AssignRoleToUser", CommandType.StoredProcedure, values) == 1)
                {
                    ++recordAffected;
                }
            }
            return recordAffected;
        }

        /// <summary>
        /// Assign users to a specified role. 
        /// </summary>
        /// <param name="userIds">The list of user ids</param>
        /// <param name="roleId">Id of a role</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int AssignUserToRole(List<Int16> userIds, int roleId)
        {
            int recordAffected = 0;
            for (int i = 0; i < userIds.Count; i++)
            {
                SqlParameter[] values = new SqlParameter[] { 
                    new SqlParameter("@UserNo", userIds[i]),
                    new SqlParameter("@RoleId", roleId)
                };
                if (ExecuteNonQuery("spSE_AssignRoleToUser", CommandType.StoredProcedure, values) == 1)
                {
                    ++recordAffected;
                }
            }
            return recordAffected;
        }

        /// <summary>
        /// Create a parent function. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateParentFunc(clsSEDto dto)
        {
            if (dto == null) return -1;
            SqlParameter[] values = new SqlParameter[6];
            values[0] = new SqlParameter("@@CtrlName", dto.ControlName);
            values[1] = new SqlParameter("@FnName", dto.FunctionName);
            if (dto.ParentID == null)
                values[2] = new SqlParameter("@ParentId", DBNull.Value);
            else
                values[2] = new SqlParameter("@ParentId", dto.ParentID);
            values[3] = new SqlParameter("@CategoryId", dto.FnCategoryID);
            values[4] = new SqlParameter("@Desc", dto.Remark);

            //SqlParameter[] values = new SqlParameter[] { 
            //    new SqlParameter("@ControlName", dto.ControlName),
            //    new SqlParameter("@FuncName", dto.FunctionName),
            //    new SqlParameter("@MenuItemName", dto.MenuItemName),
            //    new SqlParameter("@ParentID", dto.ParentID),
            //    new SqlParameter("@FnCategoryID", dto.FnCategoryID),
            //    new SqlParameter("@Desc", dto.Remark)
            //};
            return ExecuteNonQuery("spSE_CreateFormFn", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Create a child(action) function for a created parent function. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateFormAction(clsSEDto dto)
        {
            if (dto == null) return 0;
            SqlParameter[] values = new SqlParameter[5];
            values[0] = new SqlParameter("@CtrlName", dto.ControlName);
            values[1] = new SqlParameter("@FnName", dto.FunctionName);
            if (dto.ParentID == null)
                values[2] = new SqlParameter("@ParentId", DBNull.Value);
            else
                values[2] = new SqlParameter("@ParentId", dto.ParentID);
            values[3] = new SqlParameter("@CategoryId", dto.FnCategoryID);
            values[4] = new SqlParameter("@Desc", dto.Remark);

            //SqlParameter[] values = new SqlParameter[] { 
            //    new SqlParameter("@CtrlName", dto.ControlName),
            //    new SqlParameter("@FnName", dto.FunctionName),
            //    new SqlParameter("@ParentId", dto.ParentID),
            //    new SqlParameter("@CategoryId", dto.FnCategoryID),
            //    new SqlParameter("@Desc", dto.Remark)
            //};
            return ExecuteNonQuery("spSE_CreateFormFn", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Create a menu item. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateMenuItem(clsSEDto dto)
        {
            if (dto == null) return 0;
            SqlParameter[] values = new SqlParameter[5];
            values[0] = new SqlParameter("@MenuCtrlName", dto.MenuControlName);
            values[1] = new SqlParameter("@MenuName", dto.MenuItemName);
            if (dto.ParentID == null)
                values[2] = new SqlParameter("@ParentId", DBNull.Value);    
            else
                values[2] = new SqlParameter("@ParentId", dto.ParentID);    
            values[3] = new SqlParameter("@CategoryId", dto.FnCategoryID);
            values[4] = new SqlParameter("@Desc", dto.Remark);
            //SqlParameter[] values = new SqlParameter[] { 
            //    new SqlParameter("@MenuCtrlName", dto.MenuControlName),
            //    new SqlParameter("@MenuName", dto.MenuItemName),
            //    new SqlParameter("@ParentId", dto.ParentID),
            //    new SqlParameter("@CategoryId", dto.FnCategoryID),
            //    new SqlParameter("@Desc", dto.Remark)
            //};
            return ExecuteNonQuery("spSE_CreateMenuItem", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Create a menu item and return the scope identity of this. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateMenuItemAndReturnId(clsSEDto dto)
        {
            if (dto == null) return -1;
            int identity = -1;
            using (SqlConnection conn = new SqlConnection(m_ConnStr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "spSE_CreateMenuItemAndReturnId";
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] values = new SqlParameter[] { 
                        new SqlParameter("@MenuCtrlName", dto.MenuControlName),
                        new SqlParameter("@MenuName", dto.MenuItemName),
                        new SqlParameter("@ParentId", dto.ParentID),
                        new SqlParameter("@CategoryId", dto.FnCategoryID),
                        new SqlParameter("@Desc", dto.Remark)
                    };
                    cmd.Parameters.AddRange(values);
                    identity = Int16.Parse(cmd.ExecuteScalar().ToString());
                }
            }
            return identity;
        }

        /// <summary>
        /// Select role name. 
        /// </summary>
        /// <param name="dto">Department Id</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public DataTable GetRoleName()
        {
            //List<String> list = new List<String>();
            //SqlParameter value = new SqlParameter();
            //value.ParameterName = "@DeptId";
            //value.Value = deptID;
            //DataTable dt = ExecuteDataReader("spSE_GetRoleName", CommandType.StoredProcedure, value);
            //foreach (DataRow row in dt.Rows)
            //{
            //    list.Add(row["RoleName"].ToString());
            //}
            //if (dt.Rows.Count == 0) return null;
            //return dt.Rows[0][0].ToString();
            //return list;
            return ExecuteDataReader("spSE_GetRoleName", CommandType.StoredProcedure);
        }

        /// <summary>
        /// Create a new role. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int CreateNewRole(clsSEDto dto)
        {
            if (dto == null) return -1;
            SqlParameter[] values = new SqlParameter[] { 
                new SqlParameter("@RoleName", dto.RoleName),
                new SqlParameter("@DeptId", dto.DepartmentId),
                new SqlParameter("@Remark", dto.Remark)
            };
            return ExecuteNonQuery("spSE_CreateRole", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Checks the fn is existed.
        /// </summary>
        /// <param name="fnId">The fn id.</param>
        /// <param name="roleId">The role id.</param>
        /// <returns></returns>
        public bool CheckFnIsExisted(Int16 fnId, Int16 roleId)
        {
            SqlParameter[] values = new SqlParameter[2] 
            {
                new SqlParameter("@fnId", fnId),
                new SqlParameter("@roleId", roleId)
            };
            DataTable dt = ExecuteDataReader("spSE_CheckFnIsExisted", CommandType.StoredProcedure, values);
            if (dt.Rows.Count == 1)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Unassigns the A fn to role.
        /// </summary>
        /// <param name="fnId">The fn id.</param>
        /// <param name="roleId">The role id.</param>
        public int UnassignAFnToRole(Int16 fnId, Int16 roleId)
        {
            SqlParameter[] values = new SqlParameter[2] 
            {
                new SqlParameter("@fnId", fnId),
                new SqlParameter("@roleId", roleId)
            };
            return ExecuteNonQuery("spSE_UnassignAFnToRole", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Checks the menu is existed.
        /// </summary>
        /// <param name="menuId">The menu id.</param>
        /// <param name="roleId">The role id.</param>
        /// <returns></returns>
        public bool CheckMenuIsExisted(Int16 menuId, Int16 roleId)
        {
            SqlParameter[] values = new SqlParameter[2] 
            {
                new SqlParameter("@menuId", menuId),
                new SqlParameter("@roleId", roleId)
            };
            DataTable dt = ExecuteDataReader("spSE_CheckMenuIsExisted", CommandType.StoredProcedure, values);
            if (dt.Rows.Count == 1)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Unassigns the A menu to role.
        /// </summary>
        /// <param name="menuId">The menu id.</param>
        /// <param name="roleId">The role id.</param>
        public int UnassignAMenuToRole(Int16 menuId, Int16 roleId)
        {
            SqlParameter[] values = new SqlParameter[2] 
            {
                new SqlParameter("@menuId", menuId),
                new SqlParameter("@roleId", roleId)
            };
            return ExecuteNonQuery("spSE_UnassignAMenuToRole", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Checks the user is assigned to role.
        /// </summary>
        /// <param name="roleId">The role id.</param>
        /// <returns></returns>
        public bool CheckUserIsAssignedToRole(Int16 roleId)
        {
            SqlParameter value = new SqlParameter();
            value.ParameterName = "@roleId";
            value.Value = roleId;

            DataTable dt = ExecuteDataReader("spSE_CheckUserIsAssignedToRole", CommandType.StoredProcedure, value);
            if (dt.Rows.Count >= 1)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Checks the fn is assigned to role.
        /// </summary>
        /// <param name="fnId">The fn id.</param>
        /// <returns></returns>
        public bool CheckFnIsAssignedToRole(Int16 fnId)
        {
            SqlParameter value = new SqlParameter();
            value.ParameterName = "@fnId";
            value.Value = fnId;

            DataTable dt = ExecuteDataReader("spSE_CheckFnIsAssignedToRole", CommandType.StoredProcedure, value);
            if (dt.Rows.Count >= 1)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Checks the menu is assigned to role.
        /// </summary>
        /// <param name="menuId">The menu id.</param>
        /// <returns></returns>
        public bool CheckMenuIsAssignedToRole(Int16 menuId)
        {
            SqlParameter value = new SqlParameter();
            value.ParameterName = "@menuId";
            value.Value = menuId;

            DataTable dt = ExecuteDataReader("spSE_CheckMenuIsAssignedToRole", CommandType.StoredProcedure, value);
            if (dt.Rows.Count >= 1)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Modify an existing function. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int ModifyFunction(clsSEDto dto)
        {
            if (dto == null) return -1;
            SqlParameter[] values = new SqlParameter[6];
            values[0] = new SqlParameter("@FnId", dto.FunctionID);
            values[1] = new SqlParameter("@CtrlName", dto.ControlName);
            values[2] = new SqlParameter("@FnName", dto.FunctionName);
            if (dto.ParentID == null)
                values[3] = new SqlParameter("@ParentId", DBNull.Value);
            else
                values[3] = new SqlParameter("@ParentId", dto.ParentID);
            values[4] = new SqlParameter("@CategoryId", dto.FnCategoryID);
            values[5] = new SqlParameter("@Desc", dto.Remark);
            
            return ExecuteNonQuery("spSE_ModifyExistingFunction", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Modify an existing menu item. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int ModifyMenuItem(clsSEDto dto)
        {
            if (dto == null) return -1;
            SqlParameter[] values = new SqlParameter[6];
            values[0] = new SqlParameter("@MenuItemId", dto.MenuItemId);
            values[1] = new SqlParameter("@MenuCtrlName", dto.ControlName);
            values[2] = new SqlParameter("@MenuItemName", dto.MenuItemName);
            if (dto.ParentID == null)
                values[3] = new SqlParameter("@ParentId", DBNull.Value);
            else
                values[3] = new SqlParameter("@ParentId", dto.ParentID);
            values[4] = new SqlParameter("@CategoryId", dto.FnCategoryID);
            values[5] = new SqlParameter("@Desc", dto.Remark);

            //SqlParameter[] values = new SqlParameter[] { 
            //    new SqlParameter("@MenuItemId", dto.MenuItemId),
            //    new SqlParameter("@MenuCtrlName", dto.ControlName),
            //    new SqlParameter("@MenuItemName", dto.MenuItemName),
            //    new SqlParameter("@ParentId", dto.ParentID),
            //    new SqlParameter("@CategoryId", dto.FnCategoryID),
            //    new SqlParameter("@Desc", dto.Remark)
            //};
            return ExecuteNonQuery("spSE_ModifyMenuItem", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Modify an existing role. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int ModifyExistingRole(clsSEDto dto)
        {
            if (dto == null) return -1;
            SqlParameter[] values = new SqlParameter[] { 
                new SqlParameter("@RoleId", dto.RoleID),
                new SqlParameter("@RoleName", dto.RoleName),
                new SqlParameter("@DeptId", dto.DepartmentId),
                new SqlParameter("@Remark", dto.Remark)
            };
            return ExecuteNonQuery("spSE_ModifyExistingRole", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Delete an existing function. 
        /// </summary>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteFunction(clsSEDto dto)
        {
            if (dto == null) return -1;
            SqlParameter[] values = new SqlParameter[] { 
                new SqlParameter("@FnId", dto.FunctionID),
                new SqlParameter("@ParentId", dto.ParentID)
            };
            return ExecuteNonQuery("spSE_DeleteFunction", CommandType.StoredProcedure, values);
        }

        /// <summary>
        /// Delete an existing menu item. 
        /// </summary>
        /// <returns></returns>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteMenuItem(clsSEDto dto)
        {
            if (dto == null) return -1;
            SqlParameter value = new SqlParameter();
            value.ParameterName = "@MenuItemId";
            value.Value = dto.MenuItemId;
            //SqlParameter[] values = new SqlParameter[] { 
            //    new SqlParameter("@MenuItemId", dto.MenuItemId),
            //    new SqlParameter("@ParentId", dto.ParentID)
            //};
            return ExecuteNonQuery("spSE_DeleteMenuItem", CommandType.StoredProcedure, value);
        }

        /// <summary>
        /// Delete an existing role. 
        /// </summary>
        /// <returns></returns>
        /// <param name="dto">Data transfer object of SE</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteRole(int roleId)
        {
            if (roleId < 0) return 0;
            return ExecuteNonQuery("spSE_DeleteRole", CommandType.StoredProcedure, new SqlParameter("@RoleId", roleId));
        }

        /// <summary>
        /// Delete a list of old functions were assigned to a role.  
        /// </summary>
        /// <returns></returns>
        /// <param name="roleId">Id of a role</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteOldFuncAssignedToRole(int roleId)
        {
            SqlParameter value = new SqlParameter("@RoleId", roleId);
            return ExecuteNonQuery("spSE_DeleteOldFuncAssignedToRole", CommandType.StoredProcedure, value);
        }

        /// <summary>
        /// Delete a list of old menu items were assigned to a role.  
        /// </summary>
        /// <returns></returns>
        /// <param name="roleId">Id of a role</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteOldMenuAssignedToRole(int roleId)
        {
            SqlParameter value = new SqlParameter("@RoleId", roleId);
            return ExecuteNonQuery("spSE_DeleteOldMenuAssignedToRole", CommandType.StoredProcedure, value);
        }

        /// <summary>
        /// Delete a list of old users were assigned to a role.  
        /// </summary>
        /// <returns></returns>
        /// <param name="roleId">Id of a role</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteOldUserAssignedToRole(int roleId)
        {
            SqlParameter value = new SqlParameter("@RoleId", roleId);
            return ExecuteNonQuery("spSE_DeleteOldUsersOfARole", CommandType.StoredProcedure, value);
        }

        /// <summary>
        /// Delete a list of old roles were assigned to a user.  
        /// </summary>
        /// <returns></returns>
        /// <param name="userNo">Id of a user</param>
        /// @cond
        /// Author: Nguyen Trung Quan
        /// @endcond
        public int DeleteOldRoleAssignedToUser(int userNo)
        {
            SqlParameter value = new SqlParameter("@UserNo", userNo);
            return ExecuteNonQuery("spSE_DeleteOldRoleOfAUser", CommandType.StoredProcedure, value);
        }

        /// <summary>
        /// Execute non query no reply with transaction
        /// </summary>
        /// <param name="query"></param>
        /// <param name="commandType"></param>
        /// <param name="parameters"></param>
        public void ExecuteNonQueryNonReplyWithTransaction(string query, CommandType commandType, SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(m_ConnStr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = query;
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlTransaction trans = conn.BeginTransaction();
                    cmd.Transaction = trans;
                    foreach (SqlParameter param in parameters)
                    {
                        cmd.Parameters.Add(param);
                    }
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        conn.Close();
                        throw new System.ArgumentException(ex.Message);
                    }
                }
            }
        }
    }
}