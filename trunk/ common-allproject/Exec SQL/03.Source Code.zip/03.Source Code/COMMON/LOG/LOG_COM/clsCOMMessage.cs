﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: vlhcnhung $
 * $Date: 2013-03-13 (Web, 13 March 2013) $
 * ========================================================
 * This class is used to define common messages 
 * For Log module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Log.Com
{
    public static class clsCOMMessage
    {
		/// <summary>
		/// No transaction found message
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string NO_TRANSACTION_FOUND = "No transaction found";

		/// <summary>
		/// Warning that user must select at least 1 item to delete
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string NO_ITEM_WAS_SELECTED = "Please select at least one record to delete";
		/// <summary>
		/// Inform that transaction log was deleted successfully
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string DELETE_TRANSACTION_SUCCESSFULLY = "Deleting transaction log is successful";
		/// <summary>
		/// Confirm if user want to delete transaction log
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string ARE_YOU_SURE_TO_DELETE_TRANSACTION_LOG = "Are you sure to delete transaction log(s)?";
		/// <summary>
		/// Confirm that user want to delete external log
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string ARE_YOU_SURE_TO_DELETE_EXTERNAL_TRANSACTION_LOG = "Are you sure to delete external transaction log(s)?";
		/// <summary>
		/// Warning that the file's type is not valid
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string WARNING_ACTION_TYPE_OF_FILE = "File type is invalid.";
		/// <summary>
		/// Warning that the file user choose to import is not found
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string WARNING_ACTION_FILE_IMPORT_NOT_FOUND = "File is not found.";
		//public static readonly string WARNING_ACTION_FILE_IS_NULL = "File is empty.";
		//public static readonly string WARNING_ACTION_FILE_IS_OPENING = "File is opening. Please close file and try again.";
		/// <summary>
		/// Warning that user does not choose any file to import
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string WARNING_ACTION_SELECT_FILE_TO_IMPORT = "You must select file to import.";
		//public static readonly string IMPORT_SUCCESSFULLY = "Imported Succesfully";
		/// <summary>
		/// Inform that user import un-successfully
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string IMPORT_UN_SUCCESSFULLY = "Imported Unsuccesfully";
		/// <summary>
		/// Warning that user action does not exist
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string THIS_USER_ACTION_DOES_NOT_EXIST = "This user action does not exist: {0}";
		/// <summary>
		/// List of user does not exist in the system
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string THIS_USER_DOES_NOT_EXIST = "User [{0}] doesn't exist in the system";
		/// <summary>
		/// Error message to show that the file structure is not correct
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string FILE_STRUCTURE_IS_INCORRECT = "File structure is incorrect";
		/// <summary>
		/// Error message to show that the datetime is invalid
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string INVALID_DATETIME_VALUE = "Invalid datetime value: {0}";
		/// <summary>
		/// Error message to show that the log datetime's format is not correct
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string FORMAT_OF_LOG_DATE_SHOULD_BE_DD_MMM_YY = "Format of Log Date should be DD-MMM-YY";
		/// <summary>
		/// Error message to show that the update datetime's format is not correct
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static readonly string FORMAT_OF_UPDATE_DATE_SHOULD_BE_DD_MMM_YY = "Format of Updated Date should be DD-MMM-YY";
		
    }
}
