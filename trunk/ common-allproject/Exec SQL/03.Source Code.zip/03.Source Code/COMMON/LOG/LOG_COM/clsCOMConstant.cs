﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define constants
 * for Log module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
namespace Phoenix.Common.Log.Com
{
	public class clsCOMConstant
	{
		#region MODULE
		/// <summary>
		/// Module Name
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string MODULE_LOG = "LOG";
		#endregion

		#region COMBOBOX OBJECT
		/// <summary>
		/// Display object of combobox
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string DISPLAY = "Display";
		/// <summary>
		/// Value object of combobox
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string VALUE = "Value";
		#endregion

		#region PARAMETER
		/// <summary>
		/// Type of parameter: user action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string PARAMETERS_USER_ACTION = "015";
		//public const string PARAMETERS_MODULE = "016";
		/// <summary>
		/// Type of parameter: import log file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string PARAMETERS_IMPORT_LOG_FILE = "017";
		#endregion

		#region COMMON
		/// <summary>
		/// Background color of a form
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static Color BG_FORM = System.Drawing.ColorTranslator.FromHtml("#E0DFE3");

		/// <summary>
		/// Background color of a button
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static Color BG_BUTTON = System.Drawing.ColorTranslator.FromHtml("#F6F7FD");

		//public static Color BG_TEXT_GROUPBOX = System.Drawing.ColorTranslator.FromHtml("#0046D5");
		//public static Color BG_SELECTED_ITEM = System.Drawing.ColorTranslator.FromHtml("#B2B4BF");
		//public static Color BG_DATAGRID_DIFF_QUOTATION = System.Drawing.ColorTranslator.FromHtml("#50D17D");

		/// <summary>
		/// Background color of datagridview header
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static Color BG_DATAGRID_HEADER = System.Drawing.ColorTranslator.FromHtml("#F9FAFD");
		/// <summary>
		/// Selection back color
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static Color DGV_SELECTION_BACK_COLOR = System.Drawing.ColorTranslator.FromHtml("#335EA8");// Color.SteelBlue;
		/// <summary>
		/// Background color of readonly column
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static Color BG_DGV_READONLY_COLUMN = Color.FromArgb(229, 225, 198);
		/// <summary>
		/// Background color of readonly textbox
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static Color BG_TEXTBOX_READONLY = System.Drawing.ColorTranslator.FromHtml("#E0DFE3");

		//public static Color BG_DATAGRIDVIEW_HEADER = Color.FromArgb(111, 195, 237);
		//public static Color BG_LISTVIEW_HEADER = Color.FromArgb(246, 247, 253);
		//public static Color BG_SELECTED_ROW_DATAGRIDVIEW = Color.FromArgb(178, 180, 191);

		#endregion

		#region IMPORT TRANSACTION
		/// <summary>
		/// Import transaction log form title
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string TRANSACTIONLOG_TITLE_IMPORT = "Import Transaction Log";
		/// <summary>
		/// File filter of dialog importing transaction file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string DIALOG_IMPORT_FILTER_TXT_EXCEL = "Excel Worksheets 2003(*.xls)|*.xls";
		/// <summary>
		/// External log list title
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string EXTERNAL_LOG_LIST = "EXTERNAL LOG LIST";
		/// <summary>
		/// Transaction log list title
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string TRANSACTION_LOG_LIST = "TRANSACTION LOG LIST";
		/// <summary>
		/// User name column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string USER_NAME = "USER NAME";
		/// <summary>
		/// Full name column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string FULL_NAME = "FULL NAME";
		/// <summary>
		/// Log date column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string LOG_DATE = "LOG DATE";
		/// <summary>
		/// Updated date column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string UPDATED_DATE = "UPDATED DATE";
		/// <summary>
		/// Module column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string MODULE = "MODULE";
		/// <summary>
		/// File name column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string FILE_NAME = "FILE NAME";
		/// <summary>
		/// User action column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string USER_ACTION = "USER ACTION";
		/// <summary>
		/// File path column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string FILE_PATH = "FILE PATH";
		/// <summary>
		/// Application name column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string APPLICATION_NAME = "APPLICATION NAME";
		/// <summary>
		/// File type column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string FILE_TYPE = "FILE TYPE";
		/// <summary>
		/// Invalid data column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string INVALID_DATA = "INVALID DATA";
		/// <summary>
		/// Error message column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string ERROR_MESSAGE = "ERROR MESSAGE";
		/// <summary>
		/// Content column of transaction log excel file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string CONTENT = "CONTENT";
		#endregion
	}
}