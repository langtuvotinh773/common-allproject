﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to get data for screens
 * of Log module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Phoenix.Common.Log.Dal;
using Phoenix.Common.Log.Dto;
using System.Data.SqlClient;
using Phoenix.Common.Log.Com;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
namespace Phoenix.Common.Log.Bus
{
	public class clsCOMTransactionLogBus
	{
		/// <summary>
		/// clsDataAccessLayer Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsDataAccessLayer m_DAL = null;
		#region Properties
		public clsDataAccessLayer DAL
		{
			get
			{
				return m_DAL;
			}
		}
		#endregion
		/// <summary>
		/// Contructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsCOMTransactionLogBus()
		{
			m_DAL = new clsDataAccessLayer();
		}

		/// <summary>
		/// Initialize clsCOMTransactionLogBus object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private static clsCOMTransactionLogBus instance;
		public static clsCOMTransactionLogBus Instance()
		{
			if (instance == null)
			{
				instance = new clsCOMTransactionLogBus();
			}
			return instance;
		}
		/// <summary>
		/// commit transaction
		/// </summary>
		/// @cond
		/// Author: phuong lap co
		/// @endcond
		public void Commit()
		{
			m_DAL.m_transaction.Commit();
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

		/// <summary>
		/// rollback transaction
		/// </summary>
		/// @cond
		/// Author: phuong lap co
		/// @endcond
		public void RollBack()
		{
            if (m_DAL.m_transaction != null)
            {
                m_DAL.m_transaction.Rollback();
            }
			if (m_DAL.m_Connection.State == ConnectionState.Open)
				m_DAL.m_Connection.Close();
			m_DAL.m_transaction = null;
		}

		/// <summary>
		/// get list transaction type
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public List<CbbObject> GetListCOMParameters(string strType)
		{
			List<CbbObject> lst = new List<CbbObject>();
			SqlParameter[] parameters = new SqlParameter[2];
			parameters[0] = new SqlParameter("@module", clsCOMConstant.MODULE_LOG);
			parameters[1] = new SqlParameter("@type", strType);
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCOM_GetParameters", CommandType.StoredProcedure, parameters);
			lst.Add(new CbbObject("", ""));
			if (reader.Rows.Count > 0)
			{
				for (int i = 0; i < reader.Rows.Count; i++)
					lst.Add(new CbbObject(reader.Rows[i]["Value"], reader.Rows[i]["Name"]));
			}
			return lst;
		}
		
		/// <summary>
		/// get list transaction type
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public List<CbbObject> GetModule()
		{
			List<CbbObject> lst = new List<CbbObject>();
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCOM_GetModule", CommandType.StoredProcedure);
			lst.Add(new CbbObject("", ""));
			if (reader.Rows.Count > 0)
			{
				for (int i = 0; i < reader.Rows.Count; i++)
					lst.Add(new CbbObject(reader.Rows[i]["CategoryId"], reader.Rows[i]["CategoryName"]));
			}
			return lst;
		}
		
		/// <summary>
		/// Get transaction log list
		/// </summary>
		/// <param name="strUserName">User Name</param>
		/// <param name="strFullName">Full Name</param>
		/// <param name="dtFromDate">From Date</param>
		/// <param name="dtToDate">To Date</param>
		/// <param name="strModule">Module</param>
		/// <param name="iUserAction">User Action</param>
		/// <returns>transaction log table</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetTransactionLogList(string strUserName, string strFullName, DateTime dtFromDate, DateTime dtToDate, string strModule, int iUserAction)
		{
			SqlParameter[] parameters = new SqlParameter[6];
			parameters[0] = new SqlParameter("@userName", strUserName);
			parameters[1] = new SqlParameter("@fullName", strFullName);
			parameters[2] = new SqlParameter("@fromDate", dtFromDate);
			parameters[3] = new SqlParameter("@toDate", dtToDate);
			parameters[4] = new SqlParameter("@module", strModule);
			parameters[5] = new SqlParameter("@userAction", iUserAction);
			return m_DAL.ExecuteDataReader("dbo.spCOM_GetTransactionLogList", CommandType.StoredProcedure, parameters);
		}

		/// <summary>
		/// Get external log list
		/// </summary>
		/// <param name="strUserName">User Name</param>
		/// <param name="strFullName">Full Name</param>
		/// <param name="dtFromDate">From Date</param>
		/// <param name="dtToDate">To Date</param>
		/// <param name="strModule">Module</param>
		/// <param name="strFileType">File Type</param>
		/// <param name="strErrorMessage">Error Message</param>
		/// <returns>External log table</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public DataTable GetExternalLogHistoryList(string strUserName, string strFullName, DateTime? dtFromDate, DateTime? dtToDate, string strModule, string strFileType, string strErrorMessage)
		{
			SqlParameter[] parameters = new SqlParameter[7];
			parameters[0] = new SqlParameter("@userName", strUserName);
			parameters[1] = new SqlParameter("@fullName", strFullName);
			if (dtFromDate==null)
				parameters[2] = new SqlParameter("@fromDate", DBNull.Value);
			else
				parameters[2] = new SqlParameter("@fromDate", dtFromDate);

			if (dtToDate == null)
				parameters[3] = new SqlParameter("@toDate", DBNull.Value);
			else
				parameters[3] = new SqlParameter("@toDate", dtToDate);
			
			parameters[4] = new SqlParameter("@module", strModule);
			parameters[5] = new SqlParameter("@fileType", strFileType);
			parameters[6] = new SqlParameter("@errorMessage", strErrorMessage);
			DataTable dtb = m_DAL.ExecuteDataReader("dbo.spCOM_GetExternalLogHistoryList", CommandType.StoredProcedure, parameters);
			return dtb;
		}

		/// <summary>
		/// Delete transaction log
		/// </summary>
		/// <param name="lstCOMTransactionLog">List of transaction log ID to delete</param>
		/// <returns>Number of rows deleted</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int DeleteTransactionLog(List<int> lstCOMTransactionLog)
		{
			int row = 0;
            try
            {
                List<SqlParameter[]> lstParams = new List<SqlParameter[]>();
                for (int i = 0; i < lstCOMTransactionLog.Count; i++)
                {
                    SqlParameter[] parameters = new SqlParameter[1];
                    parameters[0] = new SqlParameter("@iID01", lstCOMTransactionLog[i]);
                    lstParams.Add(parameters);
                    row += m_DAL.ExecuteNonQueryWithTransaction("dbo.spCOM_DeleteTransactionLog", CommandType.StoredProcedure, lstParams);
                }
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
			return row;
		}

		/// <summary>
		/// Delete external log
		/// </summary>
		/// <param name="lstCOMTransactionLog">List of external log ID to delete</param>
		/// <returns>Rows of deleted external log</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int DeleteExternalLogHistory(List<int> lstCOMTransactionLog)
		{
			int row = 0;
            try
            {
                List<SqlParameter[]> lstParams = new List<SqlParameter[]>();
                for (int i = 0; i < lstCOMTransactionLog.Count; i++)
                {
                    SqlParameter[] parameters = new SqlParameter[1];
                    parameters[0] = new SqlParameter("@importLogID", lstCOMTransactionLog[i]);
                    lstParams.Add(parameters);
                    row += m_DAL.ExecuteNonQueryWithTransaction("dbo.spCOM_DeleteExternalLogHistory", CommandType.StoredProcedure, lstParams);
                }
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
			return row;
		}

		/// <summary>
		/// Create external transaction log
		/// </summary>
		/// <param name="externalTransactionLogObj">External transaction log object to be created</param>
		/// <returns>Insertion result: > 0 if success, otherwise = 0 </returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int InsertExternalTransactionLog(clsCOMExternalTransactionLogDTO externalTransactionLogObj)
		{
            try
            {
                SqlParameter[] parameters = new SqlParameter[8];
                parameters[0] = new SqlParameter("@module", externalTransactionLogObj.Module);
                parameters[1] = new SqlParameter("@userImport", externalTransactionLogObj.UserNo);// externalTransactionLogObj.UserName);????
                parameters[2] = new SqlParameter("@importDate", externalTransactionLogObj.LogDate);
                parameters[3] = new SqlParameter("@fileName", externalTransactionLogObj.FileName);
                parameters[4] = new SqlParameter("@filePath", externalTransactionLogObj.FilePath);
                parameters[5] = new SqlParameter("@fileType", externalTransactionLogObj.FileType);
                parameters[6] = new SqlParameter("@invalidData", externalTransactionLogObj.InvalidData);
                parameters[7] = new SqlParameter("@errorMessage", externalTransactionLogObj.ErrorMessage);
                int i = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spCOM_ImportExternalTransactionLog", CommandType.StoredProcedure, parameters);
                return i;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}

		/// <summary>
		/// Create transaction log
		/// </summary>
		/// <param name="transactionLogDTO">transaction log object to be created</param>
		/// <returns>Insertion result: > 0 if success, otherwise = 0 </returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int InsertTransactionLog(clsCOMTransactionLogDTO transactionLogDTO)
		{
            try
            {
                SqlParameter[] parameters = new SqlParameter[7];
                parameters[0] = new SqlParameter("@id02", transactionLogDTO.ID02.Trim());
                parameters[1] = new SqlParameter("@module", transactionLogDTO.Module.Trim());
                parameters[2] = new SqlParameter("@userUpdate", transactionLogDTO.UserUpdate);
                parameters[3] = new SqlParameter("@updateDate", transactionLogDTO.UpdateDate);
                parameters[4] = new SqlParameter("@applicationName", transactionLogDTO.ApplicationName);
                parameters[5] = new SqlParameter("@modifyContent", transactionLogDTO.ModifyContent);
                parameters[6] = new SqlParameter("@userAction", transactionLogDTO.UserActionValue);
                int i = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spCOM_ImportTransactionLog", CommandType.StoredProcedure, parameters);
                return i;
            }
            catch (SqlException ex)
            {
                this.RollBack();
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine);
                //save log exception
                clsLogFile.LogException(ex.Message, clsMDConstant.MODULE_MD);
                return -1;
            }
		}

		/// <summary>
		/// Get lastest file directory of transaction
		/// </summary>
		/// <returns>Lastest file directory of transaction string</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string GetLastestFileDirectoryOfTransaction()
		{
			DataTable dataTable = m_DAL.ExecuteDataReader("dbo.spCOM_GetLastestFileDirectoryOfTransactioLog", CommandType.StoredProcedure);
			return dataTable.Rows[0][0].ToString();
		}

		/// <summary>
		/// Check if username is exist or not
		/// </summary>
		/// <param name="lstUserName">List user name to check</param>
		/// <param name="lstNotExist">List of user no that user does not exist in system</param>
		/// <returns>List of user no that exist</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public List<int> ExistUserName(List<string> lstUserName, ref List<string> lstNotExist)
		{
			List<int> lstUserNo = new List<int>();
			SqlParameter[] parameters = new SqlParameter[1];
			lstNotExist = new List<string>();
			DataTable dataTable = new DataTable();
			for (int i = 0; i < lstUserName.Count; i++)
			{
				parameters[0] = new SqlParameter("@userName", lstUserName[i]);
				dataTable = m_DAL.ExecuteDataReader("dbo.spCOM_ExistUserName", CommandType.StoredProcedure, parameters);
				if (dataTable.Rows.Count > 0)
					lstUserNo.Add(int.Parse(dataTable.Rows[0][0].ToString()));
				else
					lstNotExist.Add(lstUserName[i]);
			}
			return lstUserNo;
		}

		/// <summary>
		/// Get list user no that does not exist
		/// </summary>
		/// <param name="lstUserNo">List of user no to check</param>
		/// <param name="lstNotExist">List of user no that does not exist</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void ExistUserNo(List<int> lstUserNo, ref List<int> lstNotExist)
		{
			SqlParameter[] parameters = new SqlParameter[1];
			lstNotExist = new List<int>();
			DataTable dataTable = new DataTable();
			for (int i = 0; i < lstUserNo.Count; i++)
			{
				parameters[0] = new SqlParameter("@userNo", lstUserNo[i]);
				dataTable = m_DAL.ExecuteDataReader("dbo.spCOM_ExistUserNo", CommandType.StoredProcedure, parameters);

				if (int.Parse(dataTable.Rows[0][0].ToString()) <= 0)
					lstNotExist.Add(int.Parse(dataTable.Rows[0][0].ToString()));
			}
		}

		/// <summary>
		/// Check if user action is exist or not
		/// </summary>
		/// <param name="lstUserAction">List of user action</param>
		/// <param name="lstModule">List of module</param>
		/// <param name="lstNotExist">List of user action that does not exist</param>
		/// <returns>List of user action no</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		//public List<int> ExistUserAction(List<string> lstUserAction,List<string> lstModule, ref List<string> lstNotExist)
		//{
		//    SqlParameter[] parameters = new SqlParameter[2];
		//    lstNotExist = new List<string>();
		//    List<int> lstUserActionValue = new List<int>();
		//    DataTable dataTable = new DataTable();
		//    for (int i = 0; i < lstUserAction.Count; i++)
		//    {
		//        parameters[0] = new SqlParameter("@userAction", lstUserAction[i]);
		//        parameters[1] = new SqlParameter("@module", lstModule[i]);
		//        dataTable = m_DAL.ExecuteDataReader("dbo.spCOM_ExistUserAction", CommandType.StoredProcedure, parameters);

		//        if (dataTable.Rows.Count <= 0)
		//            lstNotExist.Add(lstUserAction[i]);
		//        else lstUserActionValue.Add(int.Parse(dataTable.Rows[0][0].ToString()));
		//    }
		//    return lstUserActionValue;
		//}
	}
}