﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-24 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used get data for comboboxs existing in LOG module
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 
using System.Data;
using System.Data.SqlClient; 
using Config.Classes;
using Phoenix.Common.Log.Dto;
using Phoenix.Common.Log.Com;

namespace Phoenix.Common.Log.Bus
{

	/// <summary>
	/// this class use to get data in combobox
	/// </summary>
	public class clsCOMGetDataCombobox
	{
		/// <summary>
		/// clsCOMGetDataCombobox Object
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private static clsCOMGetDataCombobox m_Style;

		/// <summary>
		/// Module Object
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private List<CbbObject> module;
		public List<CbbObject> Module
		{
			get { return module; }
			set { module = value; }
		}

		/// <summary>
		/// Filetype object
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private List<CbbObject> fileType;
		public List<CbbObject> FileType
		{
			get { return fileType; }
			set { fileType = value; }
		}

		/// <summary>
		/// User action object
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private List<CbbObject> userAction;
		public List<CbbObject> UserAction
		{
			get { return userAction; }
			set { userAction = value; }
		}

		/// <summary>
		/// initialize clsCOMGetDataCombobox object
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static clsCOMGetDataCombobox Instance()
		{
			if (m_Style == null)
			{
				m_Style = new clsCOMGetDataCombobox();
			}

			return m_Style;
		}

		/// <summary>
		/// Load data for these comboboxes: User Action, Modul, Filetype
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public void LoadData()
		{
			userAction = clsCOMTransactionLogBus.Instance().GetListCOMParameters(clsCOMConstant.PARAMETERS_USER_ACTION);            
			module = clsCOMTransactionLogBus.Instance().GetModule();
			fileType = clsCOMTransactionLogBus.Instance().GetListCOMParameters(clsCOMConstant.PARAMETERS_IMPORT_LOG_FILE);
		}
	}
}