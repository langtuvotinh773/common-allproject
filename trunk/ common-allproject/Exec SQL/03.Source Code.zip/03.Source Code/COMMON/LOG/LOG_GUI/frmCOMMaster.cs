﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define common character
 * of Log module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms; 
using Phoenix.Common.Log.Bus;
using Phoenix.Common.Log.Com;
using System.Reflection;
using Phoenix.Common.Log.Dto;
using Config.Classes;

namespace Phoenix.Common.Log.Gui
{
	public partial class frmCOMMaster : Form
	{
        public delegate void InvokeDelegate();
		/// <summary>
		/// Format datetime
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string FORMAT_YYYYMMDD = "yyyyMMdd";
		/// <summary>
		/// New - user action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string NEW = "NEW";
		/// <summary>
		/// Update - user action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string UPDATE = "UPDATE";
		/// <summary>
		/// Delete - user action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string DELETE = "DELETE";
		/// <summary>
		/// New - User action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string New= "New";
		/// <summary>
		/// Update - user action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string Update = "Update";
		/// <summary>
		/// Delete - user action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public const string Delete = "Delete";

        Size oldSize = new Size(0, 0); // use for process event maximize and minimize
        Point oldPos = new Point(0, 0);

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmCOMMaster()
		{
			InitializeComponent();
			SetFormStyleCommon();
		}

        /// <summary>
        /// frmCOMMaster_Load & CloseTheForm Used to resole
        /// [When this screen has already openned. If click again,this screen will be focused. (don't open more)]
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmCOMMaster_Load(object sender, EventArgs e)
        {
            int numberOfFormOpening = 0;

            foreach (Form OpenForm in Application.OpenForms)
            {
                if (OpenForm.GetType() == this.GetType().UnderlyingSystemType)
                {
                    numberOfFormOpening++;
                    if (numberOfFormOpening > 1)
                    {
                        if (!OpenForm.Modal)
                        {
                            if (!DesignMode)
                            {
                                this.BeginInvoke(new Phoenix.Common.Functions.clsError.InvokeDelegate(CloseTheForm));
                            }
                            OpenForm.Activate();
                            Application.OpenForms[OpenForm.Name].BringToFront();
                        }
                        else
                        {
                            Application.OpenForms[OpenForm.Name].DialogResult = DialogResult.None;
                            Application.OpenForms[OpenForm.Name].Close();
                        }
                        return;
                    }
                }
            }
        }

        /// <summary>
        /// frmCOMMaster_Load & CloseTheForm Used to resole
        /// [When this screen has already openned. If click again,this screen will be focused. (don't open more)]
        /// </summary>
        private void CloseTheForm()
        {
            this.Close();
        }

        /// <summary>
        /// process special event
        /// </summary>
        /// <param name="m"></param>
        protected override void WndProc(ref Message m)
        {
            if (this.Parent != null)
            {
                if (m.Msg == 0x0112) // WM_SYSCOMMAND
                {
                    if (m.WParam == new IntPtr(0xF032))
                    {
                        m.WParam = new IntPtr(0xF030);
                    }
                    if (m.WParam == new IntPtr(0xF030)) // SC_MINIMIZE
                    {
                        if (this.Size != this.Parent.ClientSize)
                        {
                            //save size and location
                            oldSize = this.Size;
                            oldPos = this.Location;


                            m.WParam = new IntPtr(0xF120); // normal windown
                            this.Size = this.Parent.ClientSize;
                            this.Location = new Point(0, 0);
                        }
                        else
                        {
                            m.WParam = new IntPtr(0xF120);
                            this.Size = oldSize;
                            this.Location = oldPos;
                        }


                    }

                    if (m.WParam == new IntPtr(0xF012))
                    {
                        if (this.Parent != null)
                        {
                            if (this.Size == this.Parent.ClientSize)
                            {
                                return;
                            }
                        }
                    }
                    //  Console.WriteLine(m.ToString());
                    m.Result = new IntPtr(0);
                }
            }
            base.WndProc(ref m);
        }

        /// <summary>
        /// Call a delegate function
        /// </summary>
        /// <param name="method"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        object InvokeMethod(Delegate method, params object[] args)
        {
            return method.DynamicInvoke(args);
        }        

		/// <summary>
		/// Get user action value
		/// </summary>
		/// <param name="strUserAction">User action string</param>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public int GetUserActionValue(string strUserAction)
		{
			switch (strUserAction.ToUpper())
			{
				case NEW:
					return (int) CommonValue.ActionType.New;
				case UPDATE:
					return (int) CommonValue.ActionType.Update;
				case DELETE:
					return (int) CommonValue.ActionType.Delete;
			}
			return 0;
		}

		/// <summary>
		/// Get user action text
		/// </summary>
		/// <param name="iUserAction">User action code</param>
		/// <returns>User action text</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public string GetUserActionDisplay(int iUserAction)
		{
			switch (iUserAction)
			{
				case (int) CommonValue.ActionType.New:
					return New;
				case (int) CommonValue.ActionType.Update:
					return Update;
				case (int) CommonValue.ActionType.Delete:
					return Delete;
			}
			return "";
		}
		
		/// <summary>
		/// Set common style for all forms in COM project
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void SetFormStyleCommon()
		{
			this.BackColor = clsCOMConstant.BG_FORM;
			this.MaximizeBox = false;
			this.FormBorderStyle = FormBorderStyle.FixedSingle;
			SetFormStyleCommon(this);
		}
		
		/// <summary>
		/// Set common style for all controls in COM project
		/// </summary>
		/// <param name="controls"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public virtual void SetFormStyleCommon(Control controls)
		{
			foreach (Control c in controls.Controls)
			{
				if (c is Label)
					c.BackColor = clsCOMConstant.BG_FORM;
				else if (c is DataGridView)
				{
					DataGridView grid = (DataGridView) c;

                    grid.AllowUserToOrderColumns = false;
                    grid.AllowUserToResizeColumns = false;
                    grid.AllowUserToResizeRows = false;
                    grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                    grid.EnableHeadersVisualStyles = false;

                    grid.AllowUserToAddRows = false;
                    grid.AllowUserToDeleteRows = false;
                    grid.AllowUserToResizeColumns = false;

                    grid.ColumnHeadersDefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
					grid.CellClick += new DataGridViewCellEventHandler(grid_CellClick);
					grid.CellContentClick += new DataGridViewCellEventHandler(dtg_CellContentClick);
                    grid.DefaultCellStyle.SelectionBackColor = clsCommonStyles.Instance().DGVSelectionBackColor;  //clsCommonStyles.Instance().DGVReadOnlyColumnBG;		
					grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
					grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
					grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    clsCommonStyles style = new clsCommonStyles();
                    grid.AlternatingRowsDefaultCellStyle = style.DGVAlternatingRowsDefaultCellStyle;

					grid.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
					grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
					grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;


					if (grid.ReadOnly == true)
						grid.DefaultCellStyle.BackColor = clsCOMConstant.BG_DGV_READONLY_COLUMN;

					for (int i = 0; i < grid.Columns.Count; i++)
					{
						if (grid.Columns[i].ReadOnly == true)
						{
							grid.Columns[i].DefaultCellStyle.BackColor = clsCOMConstant.BG_DGV_READONLY_COLUMN;
						}
						grid.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
					}
                    Type dgvType = grid.GetType();
                    PropertyInfo pi = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
                    pi.SetValue(grid, true, null);
				}
				else if (c is Button)
					c.BackColor = clsCOMConstant.BG_BUTTON;
				else if (c is GroupBox)
					SetFormStyleCommon(c);
				else if (c is UserCtrl.DisableTextBox)
				{
					c.BackColor = clsCOMConstant.BG_TEXTBOX_READONLY;
					c.ForeColor = Color.Black;
				}
				else if (c is TextBox)
					c.ImeMode = ImeMode.Disable;
				else if (c is ComboBox)
					((ComboBox) c).DropDownStyle = ComboBoxStyle.DropDownList;                
			}
		}        
	
		/// <summary>
		/// Datagridivew cell content click event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void dtg_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
            DataGridView grid = (DataGridView)sender;
            grid.CommitEdit(DataGridViewDataErrorContexts.Commit);
		}
				 
		/// <summary>
		/// Gridview header cell click event (sort and align header content to be center)
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		void grid_CellClick(object sender, DataGridViewCellEventArgs e)
		{
            DataGridView grid = (DataGridView)sender;
            if (e.RowIndex == -1 && e.ColumnIndex != -1)
            {
                DataGridViewCheckBoxColumn column = grid.Columns[e.ColumnIndex] as DataGridViewCheckBoxColumn;
                if (column == null)
                {
                    grid.Columns[e.ColumnIndex].SortMode = DataGridViewColumnSortMode.Automatic;
                }
                for (int i = 0; i < grid.Columns.Count; i++)
                {
                    if (i != e.ColumnIndex)
                    {
                        grid.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                }
            } 
		}
		
		/// <summary>
		/// Load data of module for combobox
		/// </summary>
		/// <param name="cbb">Combobox having data will be loaded</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        public void LoadModule(ComboBox cbb, bool hasBlankItem)
		{
            List<CbbObject> Module = clsCOMGetDataCombobox.Instance().Module;
            if (!hasBlankItem)
            {
                Module.RemoveAt(0);
            }
			cbb.DataSource = Module;
			cbb.DisplayMember = clsCOMConstant.DISPLAY;
			cbb.ValueMember = clsCOMConstant.VALUE;
            cbb.SelectedIndex = 0;
		}

		/// <summary>
		/// Load data of file type for combobox
		/// </summary>
		/// <param name="cbb">Combobox having data will be loaded</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void LoadFileType(ComboBox cbb)
		{
			cbb.DataSource = clsCOMGetDataCombobox.Instance().FileType;
			cbb.DisplayMember = clsCOMConstant.DISPLAY;
			cbb.ValueMember = clsCOMConstant.VALUE;
		}

		/// <summary>
		/// Load data of user action for combobox
		/// </summary>
		/// <param name="cbb">Combobox having data will be loaded</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public void LoadUserAction(ComboBox cbb, bool hasBlankItem)
		{
            List<CbbObject> UserAction = clsCOMGetDataCombobox.Instance().UserAction;
            if (!hasBlankItem)
            {
                UserAction.RemoveAt(0);
            }
			cbb.DataSource = UserAction;
			cbb.DisplayMember = clsCOMConstant.DISPLAY;
			cbb.ValueMember = clsCOMConstant.VALUE;
            cbb.SelectedIndex = 0;
		}
	}
}