﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to import transaction log and external transaction log
 * of Log module.
 */
using Phoenix.Common.Log.Gui;
using System.Windows.Forms;
using Phoenix.Common.Log.Com;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Collections.Generic;
using System;
using Phoenix.Common.Log.Bus;
using Config.Classes;
using Phoenix.Common.Functions;
using MasterCommon = Phoenix.Common.MasterData.Com;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Log.Dto; 
namespace Phoenix.Common.MasterData.Gui
{
	public partial class frmCOMImportTransactionLog : frmCOMMaster
	{
        // For Security Checking
        clsSEAuthorizer m_Security = null;

		/// <summary>
		/// Transaction log bus
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		clsCOMTransactionLogBus m_TransactionLogBus = new clsCOMTransactionLogBus();

		/// <summary>
		/// Transaction log type: external or not
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		int m_TransactionLogType = -1;

        /// <summary>
        /// Event handle after import success
        /// </summary>
        public event EventHandler OnSaved;

        bool CommonError = false;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="iTransactionLogType">Transaction Log type</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmCOMImportTransactionLog(int iTransactionLogType)
		{
			InitializeComponent();
			try
			{
				// Check authorization
				m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
				m_Security.CheckAuthorizationOnScreen(this);

				m_TransactionLogType = iTransactionLogType;
				switch (iTransactionLogType)
				{
					case (int) CommonValue.ImportTransactionLogType.ManageExternalLog:
						this.Text = "Import External Log";
						break;
					case (int) CommonValue.ImportTransactionLogType.ManageTransactionLog:
						this.Text = "Import Transaction Log";
						break;
				}
			}
			catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsCOMConstant.MODULE_LOG);
				CommonError = true;
            }
		}
		
		/// <summary>
		/// Check file valid or not
		/// </summary>
		/// <param name="xlWorkSheet">Excel File</param>
		/// <returns>True if valid, false otherwise</returns>
		private bool CheckFileValidTransaction(Excel.Worksheet xlWorkSheet)
		{
			///Check valid
			string strTitle = (((Excel.Range) xlWorkSheet.Cells[2, 1]).Text.ToString());
			if (strTitle != clsCOMConstant.TRANSACTION_LOG_LIST)
				return false;
			string strColA = (((Excel.Range) xlWorkSheet.Cells[4, 1]).Text.ToString());
			if (strColA != clsCOMConstant.USER_NAME)
				return false;

			string strColB = (((Excel.Range) xlWorkSheet.Cells[4, 2]).Text.ToString());
			if (strColB != clsCOMConstant.FULL_NAME)
				return false;

			string strColC = (((Excel.Range) xlWorkSheet.Cells[4, 3]).Text.ToString());
			if (strColC != clsCOMConstant.UPDATED_DATE )
				return false;

			string strColD = (((Excel.Range) xlWorkSheet.Cells[4, 4]).Text.ToString());
			if (strColD != clsCOMConstant.MODULE)
				return false;

			string strColE = (((Excel.Range) xlWorkSheet.Cells[4, 5]).Text.ToString());
			if (strColE != clsCOMConstant.USER_ACTION)
				return false;

			string strColF = (((Excel.Range) xlWorkSheet.Cells[4, 6]).Text.ToString());
			if (strColF != clsCOMConstant.APPLICATION_NAME )
				return false;

			string strColG = (((Excel.Range) xlWorkSheet.Cells[4, 7]).Text.ToString());
			if (strColG != clsCOMConstant.CONTENT)
				return false; 
		 
			return true;
		}

		/// <summary>
		/// Chek if datetime is valid or not
		/// </summary>
		/// <param name="lstDateTime"></param>
		/// <returns>Valid datetime list</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private List<string> ValidDateTime(List<string> lstDateTime)
		{
			List<string> lstResult = new List<string>();
			for (int i = 0; i < lstDateTime.Count; i++)
			{
				DateTime d = DateTime.MinValue;;
                if (DateTime.TryParse(lstDateTime[i], out d) == false)
                {
                    lstResult.Add(lstDateTime[i]);
                }
			}
			return lstResult;
		}

		/// <summary>
		/// Read transaction log list
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void ReadTractionLogListFile()
		{
			try
			{
				string strFilePath = this.txtDirectory.Text.Trim();
				List<Excel.Worksheet> listSheet = new List<Excel.Worksheet>();
				Excel.Application xlApp;
				Excel.Workbook xlWorkBook;
				object misValue = System.Reflection.Missing.Value;

				xlApp = new Excel.ApplicationClass();
				xlWorkBook = xlApp.Workbooks.Open(strFilePath, 0, true, 5, string.Empty, string.Empty, true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
				//Read all sheet in excel file            
				Excel.Worksheet xlWorkSheet = (Excel.Worksheet) xlWorkBook.Sheets[1];
				if (CheckFileValidTransaction(xlWorkSheet))
				{				//string strSheetName = xlWorkSheet.Name;
					//int iColStart = 1;
					int iRowStart = 5;
					int rowCount = xlWorkSheet.UsedRange.Rows.Count;
					int colCount = xlWorkSheet.UsedRange.Columns.Count;

					List<string> lstUserName = new List<string>();
					List<string> lstUserNameNotExist = new List<string>();
					List<string> lstUserAction = new List<string>();
					List<string> lstUserActionNotExist = new List<string>();
					//List<int> lstUserActionValue = new List<int>();
					List<string> lstDateTime = new List<string>();
					List<string> lstDateTimeInvalid = new List<string>();
					List<int> lstUserNo = new List<int>();
					List<string> lstModule = new List<string>();
					for (int i = iRowStart; i <= rowCount; i++)
					{
						string strCellValue = ((Excel.Range) xlWorkSheet.Cells[i, 1]).Text.ToString().Trim();
						lstUserName.Add(strCellValue);
						///user action
						strCellValue = ((Excel.Range) xlWorkSheet.Cells[i, 5]).Text.ToString().Trim();
						lstUserAction.Add(strCellValue);
						///module
						strCellValue = ((Excel.Range) xlWorkSheet.Cells[i, 4]).Text.ToString().Trim();
						lstModule.Add(strCellValue);
						///datetime
						strCellValue = ((Excel.Range) xlWorkSheet.Cells[i, 3]).Text.ToString().Trim();
						lstDateTime.Add(strCellValue);
					}
					lstUserNo = m_TransactionLogBus.ExistUserName(lstUserName, ref lstUserNameNotExist);
					lstDateTimeInvalid = ValidDateTime(lstDateTime);
					
					if (lstUserNameNotExist.Count == 0 && lstDateTimeInvalid.Count==0)// && lstUserActionNotExist.Count == 0)//&&lstModuleNotExist.Count == 0&&lstApplicationNameNotExist.Count == 0&&lstUserActionNotExist.Count == 0)
					{
						int iRowInserted = 0;
						for (int i = iRowStart; i <= rowCount; i++)
						{
							string strUpdateDate = ((Excel.Range) xlWorkSheet.Cells[i, 3]).Text.ToString();

							clsCOMTransactionLogDTO transactionLogDTO = new clsCOMTransactionLogDTO(
								DateTime.Parse(strUpdateDate).ToString(FORMAT_YYYYMMDD),			//ID02
								((Excel.Range) xlWorkSheet.Cells[i, 4]).Text.ToString(),			//Module 
								lstUserNo[i - iRowStart],//((Excel.Range) xlWorkSheet.Cells[i, 1]).Text.ToString(),	//UserUpdate 
								DateTime.Parse(strUpdateDate),										//UpdateDate 
									((Excel.Range) xlWorkSheet.Cells[i, 6]).Text.ToString(),				//ApplicationName 
								((Excel.Range) xlWorkSheet.Cells[i, 7]).Text.ToString(),			//ModifyContent 
								GetUserActionValue(((Excel.Range) xlWorkSheet.Cells[i, 5]).Text.ToString().Trim())//UserAction 
								);
							iRowInserted += m_TransactionLogBus.InsertTransactionLog(transactionLogDTO);
							Console.WriteLine(iRowInserted + "");
						}
						if (iRowInserted > 0)
						{
							DialogResult = DialogResult.OK;
							//clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, clsCOMMessage.IMPORT_SUCCESSFULLY);
                            clsCOMMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(MasterCommon.clsMDMessage.INFO_ACTION_SUCCESS, "Importing", "transaction log"));
							m_TransactionLogBus.Commit();
						}
						else
						{
							DialogResult = DialogResult.None;
							//clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, clsCOMMessage.IMPORT_UN_SUCCESSFULLY);
                            clsCOMMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(MasterCommon.clsMDMessage.INFO_ACTION_FAIL, "Importing", "transaction log"));
							if (m_TransactionLogBus.DAL.m_transaction != null)
								m_TransactionLogBus.RollBack();
						}
						Console.WriteLine("iRowInserted: " + iRowInserted);
					}
					else
					{
						DialogResult = DialogResult.None;
						
						///User no does not exist
						string strUserNoNotExist = GetMessageFromList(lstUserNameNotExist);

						///User action does not exist
						string strUserActionNotExist = GetMessageFromList(lstUserActionNotExist);

						///Datetime is not valid
						string strDatetimeInValid = GetMessageFromList(lstDateTimeInvalid);

						string strMessageUser = string.Format(clsCOMMessage.THIS_USER_DOES_NOT_EXIST, strUserNoNotExist);
						string strMessageUserAction = string.Format(clsCOMMessage.THIS_USER_ACTION_DOES_NOT_EXIST, strUserActionNotExist);
						string strMessageDateTimeInvalid = clsCOMMessage.FORMAT_OF_UPDATE_DATE_SHOULD_BE_DD_MMM_YY;// string.Format(clsCOMMessage.INVALID_DATETIME_VALUE, strDatetimeInValid);

						string strMessageToShow = "";
						if (lstUserNameNotExist.Count != 0)
							strMessageToShow = strMessageToShow + strMessageUser + Environment.NewLine;
						if (lstDateTimeInvalid .Count!= 0)
							strMessageToShow = strMessageToShow  + strMessageDateTimeInvalid;
						clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, strMessageToShow);
					}
				}
				else
					clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, clsCOMMessage.FILE_STRUCTURE_IS_INCORRECT);

				xlWorkBook.Close(true, misValue, misValue);
				xlApp.Quit();
				ReleaseObject(xlWorkBook);
				ReleaseObject(xlApp);
			}
			catch (Exception ex)
			{
				DialogResult = DialogResult.None;
                clsLogFile.LogException(ex.Message, MasterCommon.clsMDConstant.MODULE_MD);
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
			}
		}

		/// <summary>
		/// Get message from list
		/// </summary>
		/// <param name="lstMessage">Message list</param>
		/// <returns>Message string</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string GetMessageFromList(List<string> lstMessage)
		{
			string strResult = "";
			for (int i = 0; i < lstMessage.Count - 1; i++)
				strResult = strResult + lstMessage[i] + ", ";
			if (lstMessage.Count > 0)
				strResult = strResult + lstMessage[lstMessage.Count - 1].ToString();
			return strResult;
		}

		/// <summary>
		/// Check if external transaction log excel file is valid or not
		/// </summary>
		/// <param name="xlWorkSheet"></param>
		/// <returns>True if valid, false otherwise</returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool CheckFileValidExternal(Excel.Worksheet xlWorkSheet)
		{
			///Check valid
		 
			string strTitle = (((Excel.Range) xlWorkSheet.Cells[2, 1]).Text.ToString());
			if (strTitle != clsCOMConstant.EXTERNAL_LOG_LIST)
				return false;
			string strColA= (((Excel.Range) xlWorkSheet.Cells[4, 1]).Text.ToString());
			if (strColA != clsCOMConstant.USER_NAME)
				return false;

			string strColB = (((Excel.Range) xlWorkSheet.Cells[4, 2]).Text.ToString());
			if (strColB != clsCOMConstant.FULL_NAME)
				return false;

			string strColC = (((Excel.Range) xlWorkSheet.Cells[4, 3]).Text.ToString());
			if (strColC != clsCOMConstant.LOG_DATE)
				return false;

			string strColD = (((Excel.Range) xlWorkSheet.Cells[4, 4]).Text.ToString());
			if (strColD != clsCOMConstant.MODULE)
				return false;

			string strColE = (((Excel.Range) xlWorkSheet.Cells[4, 5]).Text.ToString());
			if (strColE != clsCOMConstant.FILE_NAME)
				return false;

			string strColF = (((Excel.Range) xlWorkSheet.Cells[4, 6]).Text.ToString());
			if (strColF != clsCOMConstant.FILE_PATH)
				return false;

			string strColG = (((Excel.Range) xlWorkSheet.Cells[4, 7]).Text.ToString());
			if (strColG != clsCOMConstant.FILE_TYPE)
				return false;

			string strColH = (((Excel.Range) xlWorkSheet.Cells[4, 8]).Text.ToString());
			if (strColH != clsCOMConstant.INVALID_DATA)
				return false;

			string strColI = (((Excel.Range) xlWorkSheet.Cells[4, 9]).Text.ToString());
			if (strColI != clsCOMConstant.ERROR_MESSAGE)
				return false;
			return true;
		}

		/// <summary>
		/// Read External log file
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void ReadExternalLogListFile()
		{
			try
			{
				string strFilePath = this.txtDirectory.Text.Trim();
				List<Excel.Worksheet> listSheet = new List<Excel.Worksheet>();
				Excel.Application xlApp;
				Excel.Workbook xlWorkBook;
				object misValue = System.Reflection.Missing.Value;

				xlApp = new Excel.ApplicationClass();
				xlWorkBook = xlApp.Workbooks.Open(strFilePath, 0, true, 5, string.Empty, string.Empty, true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
				//Read all sheet in excel file            
				Excel.Worksheet xlWorkSheet = (Excel.Worksheet) xlWorkBook.Sheets[1];
				if (CheckFileValidExternal(xlWorkSheet))
				{
					//string strSheetName = xlWorkSheet.Name;
					int iColStart = 1;
					int iRowStart = 5;
					int rowCount = xlWorkSheet.UsedRange.Rows.Count;
					int colCount = xlWorkSheet.UsedRange.Columns.Count;

					CheckFileValidExternal(xlWorkSheet);
					///Check valid structure

					List<string> lstUserName = new List<string>();

					List<string> lstDateTimeInvalid = new List<string>();
					List<string> lstDateTime = new List<string>();
					List<int> lstUserNo = new List<int>();
					List<string> lstUserNameNotExist = new List<string>();
					
					for (int i = iRowStart; i <= rowCount + 1; i++)
					{
						lstUserName.Add(((Excel.Range) xlWorkSheet.Cells[i, 1]).Text.ToString());
						lstDateTime.Add(((Excel.Range) xlWorkSheet.Cells[i, 3]).Text.ToString());
					}
					lstUserNo = m_TransactionLogBus.ExistUserName(lstUserName, ref lstUserNameNotExist);
					lstDateTimeInvalid = ValidDateTime(lstDateTime);

					if (lstUserNo.Count == lstUserName.Count && lstDateTimeInvalid.Count == 0)
					{
						int iRowInserted = 0;
						for (int i = iRowStart; i <= rowCount + 1; i++)
						{
							clsCOMExternalTransactionLogDTO externalTransactionLogObj = new clsCOMExternalTransactionLogDTO(
								//((Excel.Range) xlWorkSheet.Cells[i, 1]).Text.ToString(),
								lstUserNo[i-iRowStart],
								((Excel.Range) xlWorkSheet.Cells[i, 2]).Text.ToString(),
								DateTime.Parse(((Excel.Range) xlWorkSheet.Cells[i, 3]).Text.ToString()),
								((Excel.Range) xlWorkSheet.Cells[i, 4]).Text.ToString(),
								((Excel.Range) xlWorkSheet.Cells[i, 5]).Text.ToString(),
								((Excel.Range) xlWorkSheet.Cells[i, 6]).Text.ToString(),
								((Excel.Range) xlWorkSheet.Cells[i, 7]).Text.ToString(),
								((Excel.Range) xlWorkSheet.Cells[i, 8]).Text.ToString(),
								((Excel.Range) xlWorkSheet.Cells[i, 9]).Text.ToString());
							iRowInserted += m_TransactionLogBus.InsertExternalTransactionLog(externalTransactionLogObj);

						}
						if (iRowInserted > 0)
						{
							DialogResult = DialogResult.OK;
							//clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, clsCOMMessage.IMPORT_SUCCESSFULLY);
                            clsCOMMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, string.Format(MasterCommon.clsMDMessage.INFO_ACTION_SUCCESS, "Importing", "external log"));
							m_TransactionLogBus.Commit();
						}
						else
						{
							DialogResult = DialogResult.None;
							//clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, clsCOMMessage.IMPORT_UN_SUCCESSFULLY);
                            clsCOMMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, string.Format(MasterCommon.clsMDMessage.INFO_ACTION_FAIL, "Importing", "external log"));
						}
						Console.WriteLine("iRowInserted: " + iRowInserted);
					}
					else
					{
						DialogResult = DialogResult.None;
						string strDatetimeInValid = GetMessageFromList(lstDateTimeInvalid);
						string strUserNameNotExist =GetMessageFromList(lstUserNameNotExist);
						string strMessageDateTimeInvalid = clsCOMMessage.FORMAT_OF_LOG_DATE_SHOULD_BE_DD_MMM_YY;// string.Format(clsCOMMessage.INVALID_DATETIME_VALUE, strDatetimeInValid);
						string strMessageUser = string.Format(clsCOMMessage.THIS_USER_DOES_NOT_EXIST, strUserNameNotExist);
			
						string strMessageToShow = "";
						if (lstUserNameNotExist.Count != 0)
							strMessageToShow = strMessageToShow + strMessageUser + Environment.NewLine;
						if (lstDateTimeInvalid .Count!= 0)
							strMessageToShow = strMessageToShow + strMessageDateTimeInvalid;
						clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, strMessageToShow);
					}
				}
				else
					clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, clsCOMMessage.FILE_STRUCTURE_IS_INCORRECT);
				xlWorkBook.Close(true, misValue, misValue);
				xlApp.Quit();
				ReleaseObject(xlWorkBook);
				ReleaseObject(xlApp);

			}
			catch (Exception ex)
			{
				if (m_TransactionLogBus.DAL.m_transaction != null)
					m_TransactionLogBus.RollBack();
				DialogResult = DialogResult.None;
                clsLogFile.LogException(ex.Message, MasterCommon.clsMDConstant.MODULE_MD);
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);				
			}
		}

		/// <summary>
		/// Release object
		/// </summary>
		/// <param name="obj"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public static void ReleaseObject(object obj)
		{
			try
			{
				System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
				obj = null;
			}
			catch (Exception ex)
			{
				obj = null;
				throw new Exception("Exception Occured while releasing object " + ex.ToString());
			}
			finally
			{
				GC.Collect();
			}
		}

		/// <summary>
		/// Check FilePath is valid
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
		private bool IsValidFileImport()
		{
			string strFilePath = txtDirectory.Text.ToString().Trim();
			if (string.IsNullOrEmpty(strFilePath))
			{
				clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, clsCOMMessage.WARNING_ACTION_SELECT_FILE_TO_IMPORT);
				btnBrowse.Focus();
				return false;
			}
			FileInfo fileInfo = new FileInfo(strFilePath);
			//Check type file is .txt
			if (fileInfo.Extension != ".xls")
			{
				clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, clsCOMMessage.WARNING_ACTION_TYPE_OF_FILE);
				btnBrowse.Focus();
				return false;
			}
			//Check file exist
			if (!fileInfo.Exists)
			{
				clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, clsCOMMessage.WARNING_ACTION_FILE_IMPORT_NOT_FOUND);
				btnBrowse.Focus();
				return false;
			}
			return true;
		}

		/// <summary>
		/// Browse file to import transaction log
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnBrowse_Click(object sender, System.EventArgs e)
		{
			string strInitialDir = m_TransactionLogBus.GetLastestFileDirectoryOfTransaction();
			Console.WriteLine(strInitialDir);
			try
			{
				//Title OpenFileDialog
				openFileDialogImport.Title = clsCOMConstant.TRANSACTIONLOG_TITLE_IMPORT;
				openFileDialogImport.FileName = clsCOMConstant.TRANSACTIONLOG_TITLE_IMPORT;


				//Filter files .txt
				openFileDialogImport.Filter = clsCOMConstant.DIALOG_IMPORT_FILTER_TXT_EXCEL;

				//Show OpenFileDialog 

				openFileDialogImport.InitialDirectory = strInitialDir;

				if (openFileDialogImport.ShowDialog() == DialogResult.OK)
					txtDirectory.Text = openFileDialogImport.FileName;
			}
			catch (Exception ex)
			{
				clsLogFile.LogException(ex.Message, MasterCommon.clsMDConstant.MODULE_MD);
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                this.Close();
			}
		}

		/// <summary>
		/// Import transaction log
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnImport_Click(object sender, System.EventArgs e)
		{
			if (IsValidFileImport())
			{
				switch (m_TransactionLogType)
				{
					case (int) CommonValue.ImportTransactionLogType.ManageExternalLog:
						ReadExternalLogListFile();
						break;
					case (int) CommonValue.ImportTransactionLogType.ManageTransactionLog:
						ReadTractionLogListFile();
						break;
				}
				if (DialogResult == DialogResult.OK)
				{
					if (OnSaved != null)
					{
						OnSaved(sender, e);
					}
					this.Close();
				}
			}
		}

		/// <summary>
		/// Close form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}	
	}
}