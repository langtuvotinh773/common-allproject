﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage external transaction log
 * of Log module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms; 
using Phoenix.Common.Log.Bus;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Log.Com;
using Phoenix.Common.Log.Dto;
using MasterCommon = Phoenix.Common.MasterData.Com;
using Phoenix.Common.MasterData.Gui;
using Phoenix.Common.Security.Com;
using MasterBus = Phoenix.Common.MasterData.Bus;

namespace Phoenix.Common.Log.Gui
{
	public partial class frmCOMManageExternalLog : frmCOMMaster
	{
		// For Security Checking
		clsSEAuthorizer m_Security = null;
        /// <summary>
        /// Excel Base
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        ExcelBase m_ExcelBase;
		/// <summary>
		/// worker object, working for background thread
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private CWorker m_worker;
		/// <summary>
		/// Project name
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string m_ProjectName = MasterCommon.clsMDConstant.PROJECT_NAME_MASTERDATA;
		/// <summary>
		/// External log datatable
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		DataTable dtExternalLog;
		/// <summary>
		/// Column Name File Type
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string strColFileType = "FileType";
		/// <summary>
		/// Import log ID string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string strImportLogID = "ImportLogID";
		/// <summary>
		/// Boolean to show if form first shown
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private bool m_IsFirstShown = true;
		/// <summary>
		/// Transaction log BUS
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private clsCOMTransactionLogBus m_COMTransactionLogBus = new clsCOMTransactionLogBus();
        /// <summary>
        /// Is called action check all
        /// </summary>
        bool checkAllAction = true;
		
		bool CommonError = false;
		
		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public frmCOMManageExternalLog()
		{
            try
            {
                InitializeComponent();

                // Check authorization
                m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                m_Security.CheckAuthorizationOnScreen(this);

                clsCOMGetDataCombobox.Instance().LoadData();

                SetFormStyleCommon();
                LoadFileType(cbbFileType);
                LoadModule(cbbModule, true);
                dtpFrom.Value = DateTime.Now;
                dtpTo.Value = DateTime.Now;
                //((CustomCalendarCell) dtgExternalTransactionLogList.Columns["colLogDate"].CellTemplate).StringFormat = FORMAT_DDMMMYYYY;
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsCOMConstant.MODULE_LOG);
				CommonError = true;
            }
		}		

		/// <summary>
		/// Search External Log
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnSearch_Click(object sender, EventArgs e)
		{
			this.chkETAll.Checked = false;
			GetExternalLogHistoryList();
            EnableControl(true);
		}

		/// <summary>
		/// Call import dialog
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnImport_Click(object sender, EventArgs e)
		{
			frmCOMImportTransactionLog importDialog = new frmCOMImportTransactionLog((int) CommonValue.ImportTransactionLogType.ManageExternalLog);
			importDialog.OnSaved += new EventHandler(frm_OnSaved);
			importDialog.StartPosition = FormStartPosition.CenterScreen;
			importDialog.ShowDialog();
		}

		/// <summary>
		/// Delete an external log
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnDelete_Click(object sender, EventArgs e)
		{
            try
            {
			    List<int> lstExternalTransactionLog = new List<int>();
                for (int i = 0; i < dtgExternalTransactionLogList.Rows.Count; i++)
                {
                    if (dtgExternalTransactionLogList.Rows[i].Cells[colCheck.Name].Value.ToString() == true.ToString())
                    {
                        lstExternalTransactionLog.Add(int.Parse(dtgExternalTransactionLogList.Rows[i].Cells[colImportLogID.Name].Value.ToString()));
                    }
                }
			    if (lstExternalTransactionLog.Count <= 0)
			    {
				    clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Error, clsCOMMessage.NO_ITEM_WAS_SELECTED);
				    return;
			    }
			    if (DialogResult.Yes == clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Confirm, clsCOMMessage.ARE_YOU_SURE_TO_DELETE_EXTERNAL_TRANSACTION_LOG))
			    {
				    if (m_COMTransactionLogBus.DeleteExternalLogHistory(lstExternalTransactionLog) > 0)
				    {
					    m_COMTransactionLogBus.Commit();
					    clsCOMMesageCollection.ShowMessage((int) CommonValue.MessageType.Infomaition, clsCOMMessage.DELETE_TRANSACTION_SUCCESSFULLY);
					    GetExternalLogHistoryList();
                        if (chkETAll.Checked)
                        {
                            chkETAll.Checked = false;
                        }
				    }
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsCOMConstant.MODULE_LOG);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                m_COMTransactionLogBus.RollBack();
            }
		}

		/// <summary>
		/// Close forn
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		/// <summary>
		/// Export excel
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: vlhcnhung
		/// @endcond
        private void btnExport_Click(object sender, EventArgs e)
        {
            if (dtgExternalTransactionLogList.Rows.Count > 0)
            {
                EnableControl(false);
                m_worker = new Config.Classes.CWorker(ExportToExcel, Complete);
                m_worker.Start();
            }
            else
            {
                clsCOMMesageCollection.MessageNoTransactions();
            }
        }

		/// <summary>
		/// Form shown even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void frmCOMManageExternalLog_Shown(object sender, EventArgs e)
		{
			if(CommonError)
			{
				this.Close();
			}
			//GetExternalLogHistoryList();
			m_IsFirstShown = false;
		}

		/// <summary>
		/// "Check all" Checkbox click even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void chkETAll_Click(object sender, EventArgs e)
		{
            dtgExternalTransactionLogList.SuspendLayout();
            if (checkAllAction)
            {
                if (chkETAll.Checked)
                {
                    foreach (DataGridViewRow dr in dtgExternalTransactionLogList.Rows)
                    {
                        dr.Cells[0].Value = true;
                    }
                }
                else
                {
                    foreach (DataGridViewRow dr in dtgExternalTransactionLogList.Rows)
                    {
                        dr.Cells[0].Value = false;
                    }
                }
            }
            dtgExternalTransactionLogList.ResumeLayout();
		}

		/// <summary>
		/// On saved even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void frm_OnSaved(object sender, EventArgs e)
		{
			GetExternalLogHistoryList();
		}
 
		/// <summary>
        /// Datagridview - Cell Content Click
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>		
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void dtgExternalTransactionLogList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dtgExternalTransactionLogList.Enabled = false;
            dtgExternalTransactionLogList.SuspendLayout();
            dtgExternalTransactionLogList.CommitEdit(DataGridViewDataErrorContexts.Commit);
            if (e.ColumnIndex == 0)
            {
                checkAllAction = false;
                foreach (DataGridViewRow dr in dtgExternalTransactionLogList.Rows)
                {
                    if (string.IsNullOrEmpty(dr.Cells[0].Value.ToString()) || bool.Parse(dr.Cells[0].Value.ToString()) == false)
                    {
                        chkETAll.Checked = false;
                        break;
                    }
                    chkETAll.Checked = true;
                }
                checkAllAction = true;
            }
            dtgExternalTransactionLogList.ResumeLayout();
            dtgExternalTransactionLogList.Enabled = true;
        }

		/// <summary>
		/// Form closing even
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void frmCOMManageExternalLog_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (m_worker != null && m_worker.IsBusy)
			{
				e.Cancel = true;
				return;
			}
		}

        /// <summary>
        /// Get external log list
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void GetExternalLogHistoryList()
        {
            try
            {
                if (cbbFileType.Items.Count <= 0)
                {
                    clsCOMGetDataCombobox.Instance().LoadData();
                    LoadFileType(cbbFileType);
                    LoadModule(cbbModule, true);
                }
                dtgExternalTransactionLogList.Rows.Clear();
                string strUserName = txtUserName.Text.Trim();
                string strFullName = txtFullName.Text.Trim();

                DateTime? dtFromDate = null;
                if (dtpFrom.Text != "")
                    dtFromDate = new DateTime(dtpFrom.Value.Year, dtpFrom.Value.Month, dtpFrom.Value.Day, 0, 0, 0, 0);

                DateTime? dtToDate = null;
                if (dtpTo.Text != "")
                    dtToDate = new DateTime(dtpTo.Value.Year, dtpTo.Value.Month, dtpTo.Value.Day, 23, 59, 59, 999);

                string strModule = ((CbbObject)cbbModule.SelectedItem).Display.ToString();
                string strFileType = ((CbbObject)cbbFileType.SelectedItem).Display.ToString();
                string strErrorMessage = txtErrorMessage.Text.Trim();
                dtExternalLog = m_COMTransactionLogBus.GetExternalLogHistoryList(strUserName, strFullName, dtFromDate, dtToDate, strModule, strFileType, strErrorMessage);
                dtgExternalTransactionLogList.Rows.Clear();
                if (m_IsFirstShown == false && dtExternalLog.Rows.Count <= 0)
                {
                    clsCOMMesageCollection.MessageNoTransactions();
                }
                else
                {
                    dtgExternalTransactionLogList.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
                    dtgExternalTransactionLogList.SuspendLayout();

                    List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
                    DataGridViewRow row = new DataGridViewRow();

                    for (int i = 0; i < dtExternalLog.Rows.Count; i++)
                    {
                        row = new DataGridViewRow();
                        row.CreateCells(dtgExternalTransactionLogList);
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colCheck.Name].Index].Value = false;
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colUserName.Name].Index].Value = dtExternalLog.Rows[i]["UserName"];
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colFullName.Name].Index].Value = dtExternalLog.Rows[i]["FullName"];
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colLogDate.Name].Index].Value = DateTime.Parse(dtExternalLog.Rows[i]["LogDate"].ToString());
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colModule.Name].Index].Value = dtExternalLog.Rows[i]["Module"];
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colFileName.Name].Index].Value = dtExternalLog.Rows[i]["FileName"];
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colFilePath.Name].Index].Value = dtExternalLog.Rows[i]["FilePath"];
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colFileType.Name].Index].Value = dtExternalLog.Rows[i]["FileType"];
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colInvalidData.Name].Index].Value = dtExternalLog.Rows[i]["InvalidData"];
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colErrorMessage.Name].Index].Value = dtExternalLog.Rows[i]["ErrorMessage"];
                        row.Cells[dtgExternalTransactionLogList.Columns[this.colImportLogID.Name].Index].Value = dtExternalLog.Rows[i]["ImportLogID"];
                        lstRows.Add(row);
                    }                    
                    dtgExternalTransactionLogList.Rows.AddRange(lstRows.ToArray());
                    dtgExternalTransactionLogList.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                    dtgExternalTransactionLogList.ResumeLayout();
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsCOMConstant.MODULE_LOG);
            }
            dtgExternalTransactionLogList.ClearSelection();
        }

        /// <summary>
        /// Enable or disable button action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableControl(bool value)
        {
            btnSearch.Enabled = value;
            btnImport.Enabled = value;
            btnExport.Enabled = value;
            btnDelete.Enabled = value;
            btnClose.Enabled = value;
        }

        /// <summary>
        /// Handling when completed a thread
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void Complete()
        {
            EnableControl(true);
            m_ExcelBase.SaveFile(true);
            if (m_worker != null)
                m_worker.Stop();
        }        

        /// <summary>
        /// Export to excel
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void ExportToExcel()
        {
            string strFileName = MasterCommon.clsMDConstant.EXCEL_TEMPLATE_NAME_EXTERNAL_LOG;
            string strTemplateName = MasterCommon.clsMDConstant.EXCEL_TEMPLATE_FILE_EXTERNAL_LOG;
            bool isOpened = false;
            m_ExcelBase = new ExcelBase(strFileName, strTemplateName, m_ProjectName, ref isOpened, MasterBus.clsMDBus.Instance().GetServerDate());
            if (isOpened)
            {
                return;
            }
            int iColStart = 1, iRowStart = 5, iRowEnd = iRowStart + dtgExternalTransactionLogList.Rows.Count - 1;
            int iColEnd = MasterCommon.clsMDConstant.HEADER_QUOTATION_EXPORT_EXTERNAL_LOG.Length;
            object[,] m_arrData = FillDataForReport(dtgExternalTransactionLogList, dtgExternalTransactionLogList.Rows.Count, iColEnd);
            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);
        }

        /// <summary>
        /// Get data for report
        /// </summary>
        /// <param name="iRowCount"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private object[,] FillDataForReport(DataGridView dgv, int iRowCount, int iColCount)
        {
            object[,] arrResult = new object[iRowCount, iColCount];
            int pos = 0;
            for (int i = 0; i < dgv.Rows.Count; i++)
            {

                for (int j = 0; j < dgv.Columns.Count; j++)
                {
                    if (dgv.Columns[j].Name.CompareTo(this.colCheck.Name) != 0)
                    {
                        if (dgv.Rows[i].Cells[j].Visible == true)
                        {
                            arrResult[i, pos] = dgv.Rows[i].Cells[j].FormattedValue;
                            pos++;
                        }
                    }
                }
                pos = 0;
            }
            return arrResult;
        }        
	}
}