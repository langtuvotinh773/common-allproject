﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to manage transaction log
 * of Log module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Phoenix.Common.Log.Bus;
using Phoenix.Common.Log.Com;
using Phoenix.Common.Log.Dto;
using Config.Classes;
using Phoenix.Common.Functions;
using MasterCommon = Phoenix.Common.MasterData.Com;
using MasterBus = Phoenix.Common.MasterData.Bus;
using Phoenix.Common.MasterData.Gui;
using Phoenix.Common.Security.Com;

namespace Phoenix.Common.Log.Gui
{
    public partial class frmCOMViewTransactionLog : frmCOMMaster
    {
        /// <summary>
        /// For Security Checking
        /// </summary>
        clsSEAuthorizer m_Security = null;
        /// <summary>
        /// Excel Base
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        ExcelBase m_ExcelBase;
        /// <summary>
        /// worker object, working for background thread
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private CWorker m_worker;
        /// <summary>
        /// Project name
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private string m_ProjectName = MasterCommon.clsMDConstant.PROJECT_NAME_MASTERDATA;
        /// <summary>
        /// Transaction Log table
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        DataTable dtTransactionLog;
        /// <summary>
        /// Name of User Action Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private string strColUserActionName = "UserActionName";
        /// <summary>
        /// ID01
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private string strID01 = "ID01";
        /// <summary>
        /// Check Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_CHECK = "colCheck";
        /// <summary>
        /// User name Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_USERNAME = "colUserName";
        /// <summary>
        /// Full name Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_FULLNAME = "colFullName";
        /// <summary>
        /// Update date Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_UPDATEDDATE = "colUpdatedDate";
        /// <summary>
        /// Module Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_MODULE = "colModule";
        /// <summary>
        /// User action Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_USERACTION = "colUserAction";
        /// <summary>
        /// Application Name Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_APPLICATIONNAME = "colApplicationName";
        /// <summary>
        /// Content Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_CONTENT = "colContent";
        /// <summary>
        /// ID01 Column
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        const string COL_ID01 = "colID01";
        /// <summary>
        /// Is first shown boolean
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        bool m_IsFirstShown = true;
        /// <summary>
        /// Is called check all
        /// </summary>
        bool checkAllAction = true;
		
		bool CommonError = false;
		
        /// <summary>
        /// Transaction log bus object
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private clsCOMTransactionLogBus m_COMTransactionLogBus = new clsCOMTransactionLogBus();

        /// <summary>
        /// Initializes a new instance of the frmCOMViewTransactionLog class.
        /// </summary>
        /// @cond
        /// Author: pthyen
        /// @endcond
        public frmCOMViewTransactionLog()
        {
            InitializeComponent();            
            try
            {
				// Check authorization
				m_Security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
				m_Security.CheckAuthorizationOnScreen(this);
                clsCOMGetDataCombobox.Instance().LoadData();
                SetFormStyleCommon();
                dtgTransactionLog.Columns[COL_CONTENT].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                dtgTransactionLog.Columns[COL_CONTENT].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dtgTransactionLog.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;
                dtgTransactionLog.RowsDefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dtgTransactionLog.AutoGenerateColumns = false;

                LoadUserAction(cbbUserAction, false);
                LoadModule(cbbModule, false);
                //
                dtTransactionLog = new DataTable();
                dtpFrom.Value = new DateTime(DateTime.Today.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
                dtpTo.Value = DateTime.Now;
            }
            catch (Exception ex)
            {
                //show error message
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                //save log exception
                clsLogFile.LogException(ex.Message, clsCOMConstant.MODULE_LOG);
				CommonError = true;
            }
        }

        /// <summary>
        /// Event search click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: pthyen
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.chkTransactionAll.Checked = false;
            GetTransactionLogList();
            m_IsFirstShown = false;
            EnableControl(true);
        }

        /// <summary>
        /// Delete even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                List<int> lstTransactionLog = new List<int>();                
                for (int i = 0; i < dtgTransactionLog.Rows.Count; i++)
                {
                    if (!string.IsNullOrEmpty(dtgTransactionLog.Rows[i].Cells[colCheck.Name].Value.ToString())
                        && int.Parse(dtgTransactionLog.Rows[i].Cells[colCheck.Name].Value.ToString()) == 1)
                    {
                        lstTransactionLog.Add(int.Parse(dtgTransactionLog.Rows[i].Cells[colID01.Name].Value.ToString()));
                    }
                }
                if (lstTransactionLog.Count <= 0)
                {
                    clsCOMMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsCOMMessage.NO_ITEM_WAS_SELECTED);
                    return;
                }
                if (DialogResult.Yes == clsCOMMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsCOMMessage.ARE_YOU_SURE_TO_DELETE_TRANSACTION_LOG))
                {
                    if (m_COMTransactionLogBus.DeleteTransactionLog(lstTransactionLog) > 0)
                    {
                        m_COMTransactionLogBus.Commit();
                        clsCOMMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsCOMMessage.DELETE_TRANSACTION_SUCCESSFULLY);
                        GetTransactionLogList();
                        if (chkTransactionAll.Checked)
                        {
                            chkTransactionAll.Checked = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, clsCOMConstant.MODULE_LOG);
                m_COMTransactionLogBus.RollBack();
            }
        }

        /// <summary>
        /// Close form even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Export excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void btnExport_Click(object sender, EventArgs e)
        {
            if (dtgTransactionLog.Rows.Count > 0)
            {
                EnableControl(false);
                m_worker = new Config.Classes.CWorker(ExportToExcel, Complete);
                m_worker.Start();
            }
            else 
            {
                clsCOMMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsCOMMessage.NO_TRANSACTION_FOUND);
            }
        }

        /// <summary>
        /// Import excel even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnImport_Click(object sender, EventArgs e)
        {
            frmCOMImportTransactionLog importDialog = new frmCOMImportTransactionLog((int)CommonValue.ImportTransactionLogType.ManageTransactionLog);
            importDialog.OnSaved += new EventHandler(frm_OnSaved);
            importDialog.StartPosition = FormStartPosition.CenterScreen;
            importDialog.ShowDialog();
        }

        /// <summary>
        /// Form shown even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void frmCOMViewTransactionLog_Shown(object sender, EventArgs e)
        {
			if(CommonError)
			{
				this.Close();
			}
            m_IsFirstShown = false;
        }

        /// <summary>
        /// Form closing even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void frmCOMViewTransactionLog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_worker != null && m_worker.IsBusy)
            {
                e.Cancel = true;
                return;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void dtgTransactionLog_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dtgTransactionLog.Enabled = false;
            dtgTransactionLog.SuspendLayout();
            dtgTransactionLog.CommitEdit(DataGridViewDataErrorContexts.Commit);
            if (e.ColumnIndex == 0)
            {
                checkAllAction = false;
                foreach (DataGridViewRow dr in dtgTransactionLog.Rows)
                {
                    //if (string.IsNullOrEmpty(dr.Cells[0].Value.ToString()) || bool.Parse(dr.Cells[0].Value.ToString()) == false)
                    if (string.IsNullOrEmpty(dr.Cells[0].Value.ToString()) || int.Parse(dr.Cells[0].Value.ToString()) == 0)
                    {
                        chkTransactionAll.Checked = false;
                        break;
                    }
                    chkTransactionAll.Checked = true;
                }
                checkAllAction = true;
            }
            dtgTransactionLog.ResumeLayout();
            dtgTransactionLog.Enabled = true;
        }

        /// <summary>
        /// Check all even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void chkOLAll_Click(object sender, EventArgs e)
        {
            dtgTransactionLog.SuspendLayout();
            if (checkAllAction)
            {
                if (chkTransactionAll.Checked)
                {
                    foreach (DataGridViewRow dr in dtgTransactionLog.Rows)
                    {
                        dr.Cells[0].Value = true;
                    }
                }
                else
                {
                    foreach (DataGridViewRow dr in dtgTransactionLog.Rows)
                    {
                        dr.Cells[0].Value = false;
                    }
                }
            }
            dtgTransactionLog.ResumeLayout();
        }

        /// <summary>
        /// Get transaction log list
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void GetTransactionLogList()
        {
            EnableControl(false);
            try
            {
                if (cbbModule.Items.Count <= 0)
                {
                    clsCOMGetDataCombobox.Instance().LoadData();
                    LoadUserAction(cbbUserAction, false);
                    LoadModule(cbbModule, false);
                }
                dtgTransactionLog.DataSource = null;
                string strUserName = txtUserName.Text.Trim();
                string strFullName = txtFullName.Text.Trim();

                DateTime dtFromDate = new DateTime(dtpFrom.Value.Year, dtpFrom.Value.Month, dtpFrom.Value.Day, dtpFrom.Value.Hour, dtpFrom.Value.Minute, 0);
                DateTime dtToDate = new DateTime(dtpTo.Value.Year, dtpTo.Value.Month, dtpTo.Value.Day, dtpTo.Value.Hour, dtpTo.Value.Minute, 59, 999);

                string strModule = ((CbbObject)cbbModule.SelectedItem).Display.ToString();
                int iUserAction = ((CbbObject)cbbUserAction.SelectedItem).Value.ToString() == "" ? 0 : int.Parse(((CbbObject)cbbUserAction.SelectedItem).Value.ToString());
                dtTransactionLog = m_COMTransactionLogBus.GetTransactionLogList(strUserName, strFullName, dtFromDate, dtToDate, strModule, iUserAction);
                
                if (m_IsFirstShown == false && dtTransactionLog.Rows.Count <= 0)
                {
                    //dtgTransactionLog.Rows.Clear();
                    dtgTransactionLog.DataSource = null;
                    clsCOMMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsCOMMessage.NO_TRANSACTION_FOUND);
                }
                else
                {
                    dtgTransactionLog.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
                    dtgTransactionLog.SuspendLayout();

                    //List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
                    //DataGridViewRow row = new DataGridViewRow();
                    //for (int i = 0; i < dtTransactionLog.Rows.Count; i++)
                    //{
                    //    row = new DataGridViewRow();
                    //    row.CreateCells(dtgTransactionLog);
                    //    row.Cells[dtgTransactionLog.Columns[COL_CHECK].Index].Value = false;
                    //    row.Cells[dtgTransactionLog.Columns[COL_USERNAME].Index].Value = dtTransactionLog.Rows[i]["UserName"];
                    //    row.Cells[dtgTransactionLog.Columns[COL_FULLNAME].Index].Value = dtTransactionLog.Rows[i]["FullName"];
                    //    row.Cells[dtgTransactionLog.Columns[COL_UPDATEDDATE].Index].Value = DateTime.Parse(dtTransactionLog.Rows[i]["UpdateDate"].ToString());
                    //    row.Cells[dtgTransactionLog.Columns[COL_MODULE].Index].Value = dtTransactionLog.Rows[i]["Module"];
                    //    row.Cells[dtgTransactionLog.Columns[COL_USERACTION].Index].Value = dtTransactionLog.Rows[i]["UserActionName"];
                    //    row.Cells[dtgTransactionLog.Columns[COL_APPLICATIONNAME].Index].Value = dtTransactionLog.Rows[i]["ApplicationName"];
                    //    row.Cells[dtgTransactionLog.Columns[COL_CONTENT].Index].Value = dtTransactionLog.Rows[i]["ModifyContent"];
                    //    row.Cells[dtgTransactionLog.Columns[COL_ID01].Index].Value = dtTransactionLog.Rows[i]["ID01"];
                    //    lstRows.Add(row);
                    //}

                    //dtgTransactionLog.Rows.AddRange(lstRows.ToArray());
                    dtgTransactionLog.DataSource = null;
                    dtgTransactionLog.DataSource = dtTransactionLog;
                    dtgTransactionLog.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                    dtgTransactionLog.Columns[COL_CONTENT].Width = 500;
                    dtgTransactionLog.ResumeLayout();
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite);
                clsLogFile.LogException(ex.Message, MasterCommon.clsMDConstant.MODULE_MD);
            }
            dtgTransactionLog.ClearSelection();
            EnableControl(true);
        }

        /// <summary>
        /// Enable or disable button action
        /// </summary>
        /// <param name="value"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void EnableControl(bool value)
        {
            btnSearch.Enabled = value;
            btnImport.Enabled = value;
            btnExport.Enabled = value;
            btnDelete.Enabled = value;
            btnClose.Enabled = value;
            if (value)
            {
                if (dtgTransactionLog.Rows.Count == 0)
                {
                    btnDelete.Enabled = false;
                    btnExport.Enabled = false;
                }
            }
        }

        /// <summary>
        /// Handling when completed a thread
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void Complete()
        {
            EnableControl(true);
            m_ExcelBase.SaveFile(true);
            if (m_worker != null)
                m_worker.Stop();
        }

        /// <summary>
        /// Export to excel
        /// </summary>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void ExportToExcel()
        {
            string strFileName = MasterCommon.clsMDConstant.EXCEL_TEMPLATE_NAME_TRANSACTION_LOG;
            string strTemplateName = MasterCommon.clsMDConstant.EXCEL_TEMPLATE_FILE_TRANSACTION_LOG;
            bool isOpened = false;
            m_ExcelBase = new ExcelBase(strFileName, strTemplateName, m_ProjectName, ref isOpened, MasterBus.clsMDBus.Instance().GetServerDate());
            if (isOpened)
            {
                return;
            }
            int iColStart = 1, iRowStart = 5, iRowEnd = iRowStart + dtgTransactionLog.Rows.Count - 1;
            int iColEnd = MasterCommon.clsMDConstant.HEADER_QUOTATION_EXPORT_TRANSACTION_LOG.Length;
            string[,] m_arrData = FillDataForReport(dtgTransactionLog, dtgTransactionLog.Rows.Count, iColEnd);
            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);
        }

        /// <summary>
        /// Get data for report
        /// </summary>
        /// <param name="iRowCount"></param>
        /// <returns></returns>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private string[,] FillDataForReport(DataGridView dgv, int iRowCount, int iColCount)
        {
            string[,] arrResult = new string[iRowCount, iColCount];
            int pos = 0;
            for (int i = 0; i < dgv.Rows.Count; i++)
            {

                for (int j = 0; j < dgv.Columns.Count; j++)
                {
                    if (dtgTransactionLog.Columns[j].Name.CompareTo(this.colCheck.Name) != 0)
                    {
                        if (dgv.Rows[i].Cells[j].Visible == true)
                        {
                            arrResult[i, pos] = dgv.Rows[i].Cells[j].Value.ToString();
                            pos++;
                        }
                    }
                }
                pos = 0;
            }
            return arrResult;
        }

        /// <summary>
        /// On save even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frm_OnSaved(object sender, EventArgs e)
        {
            GetTransactionLogList();
        }
    }
}