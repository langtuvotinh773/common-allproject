﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define External Transaction object
 * of Log module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Log.Dto
{
	public class clsCOMExternalTransactionLogDTO
	{
		/// <summary>
		/// User Name Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string userName;
		public string UserName
		{
			get { return userName; }
			set { userName = value; }
		}
		/// <summary>
		/// User No Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int userNo;
		public int UserNo
		{
			get { return userNo; }
			set { userNo = value; }
		}
		/// <summary>
		/// Full Name Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string fullName;
		public string FullName
		{
			get { return fullName; }
			set { fullName = value; }
		}


		/// <summary>
		/// Log Date Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        private DateTime logDate;
        public DateTime LogDate
        {
            get { return logDate; }
            set { logDate = value; }
		}
		/// <summary>
		/// Module Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string module;
		public string Module
		{
			get { return module; }
			set { module = value; }
		}
		/// <summary>
		/// File Name Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string fileName;
		public string FileName
		{
			get { return fileName; }
			set { fileName = value; }
		}

		/// <summary>
		/// File Path Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string filePath;
		public string FilePath
		{
			get { return filePath; }
			set { filePath = value; }
		}
		/// <summary>
		/// File Type Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string fileType;
		public string FileType
		{
			get { return fileType; }
			set { fileType = value; }
		}

		/// <summary>
		/// Invalid data Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string invalidData;
		public string InvalidData
		{
			get { return invalidData; }
			set { invalidData = value; }
		}
		/// <summary>
		/// Error Message Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string errorMessage;
		public string ErrorMessage
		{
			get { return errorMessage; }
			set { errorMessage = value; }
		}

		/// <summary>
		/// Imoprt Log ID Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int importLogID;
		public int ImportLogID
		{
			get { return importLogID; }
			set { importLogID = value; }
		}

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public clsCOMExternalTransactionLogDTO()
        {
            UserName = string.Empty;
            UserNo = -1;
            FullName = string.Empty;
            LogDate = DateTime.Now;
            Module = string.Empty;
            FileName = string.Empty;
            FilePath = string.Empty;
            FileType = string.Empty;
            InvalidData = string.Empty;
            ErrorMessage = string.Empty;
            ImportLogID = -1;
        }

		// <summary>
		// Constructor
		// </summary>
		// @cond
		// Author: Yen Phan
		// @endcond
		//public clsCOMExternalTransactionLogDTO(
		//    string strUserName,
		//    string strFullName,
		//    DateTime dtlogDate,
		//    string strModule,
		//    string strFileName,
		//    string strFilePath,
		//    string strFileType,
		//    string strInvalidData,
		//    string strErrorMessage
		//    )
		//{
		//    UserName = strUserName;
		//    FullName = strFileName;
		//    logDate = dtlogDate;
		//    Module = strModule;
		//    FileName = strFileName;
		//    FilePath = strFilePath;
		//    FileType = strFileType;
		//    InvalidData = strInvalidData;
		//    ErrorMessage = strErrorMessage;
		//}


		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsCOMExternalTransactionLogDTO(
			int iUserNo,
			string strFullName,
			DateTime dtlogDate,
			string strModule,
			string strFileName,
			string strFilePath,
			string strFileType,
			string strInvalidData,
			string strErrorMessage
			)
		{
			UserNo = iUserNo;
			FullName = strFileName;
			logDate = dtlogDate;
			Module = strModule;
			FileName = strFileName;
			FilePath = strFilePath;
			FileType = strFileType;
			InvalidData = strInvalidData;
			ErrorMessage = strErrorMessage;
		}
	}
}