﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define combobox object
 * of Log module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Log.Dto
{
	public class CbbObject
	{
		/// <summary>
		/// Display object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private object m_Display;
		/// <summary>
		/// Value object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private object m_Value;
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="Value">Value object</param>
		/// <param name="Display">Display Object</param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public CbbObject(object Value, object Display)
		{
			m_Display = Display;
			m_Value = Value;
		}
		public object Display
		{
			get { return m_Display; }
			set { m_Display = Value; }
		}
		public object Value
		{
			get { return m_Value; }
			set { m_Value = Value; }
		}
	}
}