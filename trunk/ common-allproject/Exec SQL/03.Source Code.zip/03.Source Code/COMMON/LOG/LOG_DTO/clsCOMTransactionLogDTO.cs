﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define Transaction Log object
 * of Log module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Log.Dto
{
	public class clsCOMTransactionLogDTO
	{

		/// <summary>
		/// Module Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string module;
		public string Module
		{
			get { return module; }
			set { module = value; }
		}

		/// <summary>
		/// User Update Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int userUpdate;
		public int UserUpdate
		{
			get { return userUpdate; }
			set { userUpdate = value; }
		}

		/// <summary>
		/// Update Date Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private DateTime updateDate;
		public DateTime UpdateDate
		{
			get { return updateDate; }
			set { updateDate = value; }
		}

		/// <summary>
		/// Application Name Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string applicationName;
		public string ApplicationName
		{
			get { return applicationName; }
			set { applicationName = value; }
		}
		/// <summary>
		/// Modify Content Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string modifyContent;
		public string ModifyContent
		{
			get { return modifyContent; }
			set { modifyContent = value; }
		}
		/// <summary>
		/// User Action to Display Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string userActionDisplay;
		public string UserActionDisplay
		{
			get { return userActionDisplay; }
			set { userActionDisplay = value; }
		}
		/// <summary>
		/// User action value Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int userActionValue;
		public int UserActionValue
		{
			get { return userActionValue; }
			set { userActionValue = value; }
		}

		/// <summary>
		/// ID01 Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private int id01;
		public int ID01
		{
			get { return id01; }
			set { id01 = value; }
		}
		/// <summary>
		/// ID02 Object
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private string id02;
		public string ID02
		{
			get { return id02; }
			set { id02 = value; }
		}

		///// <summary>
		///// Constructor
		///// </summary>
		///// @cond
		///// Author: Yen Phan
		///// @endcond
		//public clsCOMTransactionLogDTO()
		//{
		//    Module = "";
		//    UserUpdate = -1;
		//    UpdateDate = DateTime.Now;
		//    ApplicationName = "";
		//    ModifyContent = "";
		//    UserActionDisplay = "";
		//    UserActionValue = -1;
		//    ID01 = -1;
		//}
		///// <summary>
		///// Constructor
		///// </summary>
		///// @cond
		///// Author: Yen Phan
		///// @endcond
		//public clsCOMTransactionLogDTO(
		//    string strID02,
		//    string strModule,
		//    int iUserUpdate,
		//    DateTime dtUpdateDate,
		//    string strApplicationName,
		//    string strModidfyContent,
		//    string strUserActionDisplay)
		//{
		//    ID02 = strID02;
		//    Module = strModule;
		//    UserUpdate = iUserUpdate;
		//    UpdateDate = dtUpdateDate;
		//    ApplicationName = strApplicationName;
		//    ModifyContent = strModidfyContent;
		//    UserActionDisplay = strUserActionDisplay;

		//}


		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public clsCOMTransactionLogDTO(
			string strID02,
			string strModule,
			int iUserUpdate,
			DateTime dtUpdateDate,
			string strApplicationName,
			string strModidfyContent,
			int iUserActionValue)
		{
			ID02 = strID02;
			Module = strModule;
			UserUpdate = iUserUpdate;
			UpdateDate = dtUpdateDate;
			ApplicationName = strApplicationName;
			ModifyContent = strModidfyContent;
			UserActionValue = iUserActionValue;
		}
	}
}