﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define Data Access Layer
 * for Log module.
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Config.Classes;
using DataEncryption;

namespace Phoenix.Common.Log.Dal
{
    public class clsDataAccessLayer
    {
		/// <summary>
		/// Connection string
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        private readonly string CONNECTION_STRING = //clsFunction.GetDBConnectionStr();
        Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["MDConnectionString"].ToString());
        //private readonly string CONNECTION_STRING = System.Configuration.ConfigurationSettings.AppSettings["SercurityConnectionString"].ToString();        

		/// <summary>
		/// SQL connection
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        public SqlConnection m_Connection;
		/// <summary>
		/// SQL Command
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        private SqlCommand m_Command;
		/// <summary>
		/// SQL Adapter
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        private SqlDataAdapter m_Adapter;
		/// <summary>
		/// SQL Transaction
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        public SqlTransaction m_transaction;

        /// <summary>
        /// Initializes a new instance of the <see cref="CPADataAccessLayer" /> class.
        /// </summary>
        public clsDataAccessLayer()
        {
            this.m_Connection = new SqlConnection(CONNECTION_STRING);
            this.m_Command = new SqlCommand();
            this.m_Adapter = new SqlDataAdapter();
        }

        /// <summary>
        /// Fills the specified table.
        /// </summary>
        /// <param name="table">The table.</param>
        public void Fill(DataTable table)
        {
            try
            {
                if (m_Adapter != null)
                {
                    this.m_Adapter.Fill(table);
                }
            }
            catch (SqlException ex)
            {
                string error = ex.Message;
                // clsCommonFunctions.ShowErrorDialog(error);
                clsLogFile.LogException(error);
            }
        }

        /// <summary>
        /// Fills the specified dataset.
        /// </summary>
        /// <param name="dataset">The dataset.</param>
        public void Fill(DataSet dataset)
        {
            try
            {
                if (m_Adapter != null)
                {
                    this.m_Adapter.Fill(dataset);
                }
            }
            catch (SqlException ex)
            {
                string error = ex.Message;
                // clsCommonFunctions.ShowErrorDialog(error);
                clsLogFile.LogException(error);
            }
        }

        /// <summary>
        /// Sets the command.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        public void SetCommand(string query, CommandType commandType)
        {
            this.m_Command.Parameters.Clear();
            this.m_Command.Connection = this.m_Connection;
            this.m_Command.CommandType = commandType;
            this.m_Command.CommandText = query;
        }

        /// <summary>
        /// Adds the parameter.
        /// </summary>
        /// <param name="paramter">The paramter.</param>
        public void AddParameter(SqlParameter paramter)
        {
            this.m_Command.Parameters.Add(paramter);
        }

        /// <summary>
        /// Adds the parameter.
        /// </summary>
        /// <param name="paramatername">The paramater name.</param>
        /// <param name="parametervalue">The parameter value.</param>
        public void AddParameter(string paramatername, object parametervalue)
        {
            this.m_Command.Parameters.AddWithValue(paramatername, parametervalue);
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <returns></returns>
        public int ExecuteNonQuery()
        {
            int row = 0;
            try
            {
                if (this.m_Connection.State == ConnectionState.Closed)
                    this.m_Connection.Open();

                row = this.m_Command.ExecuteNonQuery();

                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();
                return row;
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <returns></returns>
        public int ExecuteNonQuery(string query, CommandType commandType)
        {
            int row = 0;
            try
            {
                SetCommand(query, commandType);
                if (this.m_Connection.State == ConnectionState.Closed)
                    this.m_Connection.Open();

                row = this.m_Command.ExecuteNonQuery();

                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }

            return row;
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public int ExecuteNonQuery(string query, CommandType commandType, SqlParameter[] parameters)
        {
            try
            {
                SetCommand(query, commandType);
                foreach (SqlParameter param in parameters)
                {
                    AddParameter(param);
                }
                if (this.m_Connection.State == ConnectionState.Closed)
                    this.m_Connection.Open();

                int row = this.m_Command.ExecuteNonQuery();
                //int row = Convert.ToInt32(m_Command.Parameters["@Count"].Value);

                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();

                return row;
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Executes the non query. execute with list param and rollback all if false
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public int ExecuteNonQuery(string query, CommandType commandType, List<SqlParameter[]> parameters)
        {
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();
            int row = 0;
            SetCommand(query, commandType);
            SqlTransaction tran = m_Connection.BeginTransaction();
            m_Command.Transaction = tran;
            try
            {
                for (int i = 0; i < parameters.Count; i++)
                {
                    foreach (SqlParameter param in parameters[i])
                    {
                        AddParameter(param);
                    }

                    if (this.m_Command.ExecuteNonQuery() > 0)
                    {
                        row++;
                    }
                    else
                    {
                        tran.Rollback();
                        return 0;
                    }

                    //row += this.m_Command.ExecuteNonQuery();

                    //Convert.ToInt32(m_Command.Parameters["@Count"].Value);
                    this.m_Command.Parameters.Clear();
                }
                tran.Commit();
                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();

                return row;
            }
            catch (SqlException ex)
            {
                tran.Rollback();
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public int ExecuteNonQueryWithTransaction(string query, CommandType commandType, SqlParameter[] parameters)
        {
            try
            {
                if (this.m_Connection.State == ConnectionState.Closed)
                    this.m_Connection.Open();
                SetCommand(query, commandType);
                if (m_transaction == null || m_transaction.Connection == null)
                {
                    m_transaction = m_Connection.BeginTransaction();
                }
                m_Command.Transaction = m_transaction;
                foreach (SqlParameter param in parameters)
                {
                    AddParameter(param);
                }

                SqlParameter returnValue = new SqlParameter();
                returnValue.Direction = ParameterDirection.ReturnValue;

                AddParameter(returnValue);

                int row = this.m_Command.ExecuteNonQuery();                

                return row;
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Executes the non query with transaction return value
        /// </summary>
        /// <param name="query"></param>
        /// <param name="commandType"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public int ExecuteNonQueryWithTransactionReturnValue(string query, CommandType commandType, SqlParameter[] parameters)
        {
            try
            {
                if (this.m_Connection.State == ConnectionState.Closed)
                    this.m_Connection.Open();
                SetCommand(query, commandType);
                if (m_transaction == null || m_transaction.Connection == null)
                {
                    m_transaction = m_Connection.BeginTransaction();
                }
                m_Command.Transaction = m_transaction;
                foreach (SqlParameter param in parameters)
                {
                    AddParameter(param);
                }

                SqlParameter returnParam = new SqlParameter();
                returnParam.Direction = ParameterDirection.ReturnValue;

                AddParameter(returnParam);

                this.m_Command.ExecuteNonQuery();
                //used to check data insert in database
                return (int)returnParam.Value;

            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }


		 
        /// <summary>
        /// Executes the non query with transaction. execute with list param and rollback all if false
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public int ExecuteNonQueryWithTransaction(string query, CommandType commandType, List<SqlParameter[]> parameters)
        {
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();
            int row = 0;
            SetCommand(query, commandType);
            if (m_transaction == null || m_transaction.Connection == null)
            {
                m_transaction = m_Connection.BeginTransaction();
            }
            m_Command.Transaction = m_transaction;
            try
            {
                for (int i = 0; i < parameters.Count; i++)
                {
                    foreach (SqlParameter param in parameters[i])
                    {
                        AddParameter(param);
                    }

                    row += this.m_Command.ExecuteNonQuery();

                    this.m_Command.Parameters.Clear();
                    
                }

                return row;
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Executes the non query with transaction. execute with list param and rollback all if false
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public int ExecuteNonQueryDeleteWithTransaction(string query, CommandType commandType, List<SqlParameter[]> parameters)
        {
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();
            int row = 0;
            SetCommand(query, commandType);
            if (m_transaction == null || m_transaction.Connection == null)
            {
                m_transaction = m_Connection.BeginTransaction();
            }
            m_Command.Transaction = m_transaction;
            try
            {
                for (int i = 0; i < parameters.Count; i++)
                {
                    foreach (SqlParameter param in parameters[i])
                    {
                        AddParameter(param);
                    }

                    row = this.m_Command.ExecuteNonQuery();

                    this.m_Command.Parameters.Clear();

                    if (row < 1)
                    {
                        //process data fail.
                        return 0;
                    }
                }

                return row;
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        public void ExecuteNonQueryNonReply(string query, CommandType commandType, SqlParameter[] parameters)
        {
            try
            {
                SetCommand(query, commandType);
                foreach (SqlParameter param in parameters)
                {
                    AddParameter(param);
                }
                if (this.m_Connection.State == ConnectionState.Closed)
                    this.m_Connection.Open();

                this.m_Command.ExecuteNonQuery();


                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();


            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }

        }
        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="outputParamName">Name of the output param.</param>
        /// <returns>The affected row that stored procedure returns</returns>
        public int ExecuteNonQuery(string query, CommandType commandType, SqlParameter[] parameters, object outputParamName)
        {
            try
            {
                SetCommand(query, commandType);
                foreach (SqlParameter param in parameters)
                {
                    AddParameter(param);
                }
                if (this.m_Connection.State == ConnectionState.Closed)
                    this.m_Connection.Open();

                this.m_Command.ExecuteNonQuery();
                int row = Convert.ToInt32(m_Command.Parameters[outputParamName.ToString()].Value);

                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();

                return row;
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="outputParamName">Name of the output param.</param>
        /// <returns>The affected row that stored procedure returns</returns>
        public string ExecuteNonQueryWithReturn(string query, CommandType commandType, SqlParameter[] parameters, ref object returnValue)
        {
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();
            SetCommand(query, commandType);
            if (m_transaction == null || m_transaction.Connection == null)
            {
                m_transaction = m_Connection.BeginTransaction();
            }
            m_Command.Transaction = m_transaction;

            try
            {
                foreach (SqlParameter param in parameters)
                {
                    AddParameter(param);
                }

                this.m_Command.ExecuteNonQuery();
                returnValue = m_Command.Parameters[returnValue.ToString()].Value;

                return returnValue.ToString();
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="outParamName">Name of the out param.</param>
        /// <returns></returns>
        public string ExecuteNonQueryOutString(string query, CommandType commandType, SqlParameter[] parameters, string outParamName)
        {
            string result = "";
            try
            {
                if (this.m_Connection.State == ConnectionState.Closed)
                    this.m_Connection.Open();
                SetCommand(query, commandType);
                if (m_transaction == null || m_transaction.Connection == null)
                {
                    m_transaction = m_Connection.BeginTransaction();
                }
                m_Command.Transaction = m_transaction;
                foreach (SqlParameter param in parameters)
                {
                    AddParameter(param);
                }
               

                this.m_Command.ExecuteNonQuery();

                result = m_Command.Parameters[outParamName].Value.ToString();
               

                return result;
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }
        /// <summary>
        /// Commit transaction
        /// </summary>
        public void Commit()
        {
            try
            {
                m_transaction.Commit();

                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();
            }
            catch
            {
            }
        }
        /// <summary>
        /// Rollback transaction
        /// </summary>
        public void RollBack()
        {
            try
            {
                m_transaction.Rollback();

                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();
            }
            catch (Exception)
            {
            }
        }
        /// <summary>
        /// Clear all parameters in command
        /// </summary>
        public void ClearParameter()
        {
            m_Command.Parameters.Clear();
        }
        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <returns></returns>
        public DataTable ExecuteDataReader(string query, CommandType commandType)
        {
            DataTable table = new DataTable();
            try
            {
                if (m_Adapter != null)
                {
                    SetCommand(query, commandType);
                    this.m_Adapter.SelectCommand = m_Command;
                    this.m_Adapter.Fill(table);
                }
                else
                {
                    this.m_Adapter = new SqlDataAdapter();
                    this.m_Adapter.SelectCommand = m_Command;
                    this.m_Adapter.Fill(table);
                }
                m_Adapter.Dispose();
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
            return table;
        }

        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public DataTable ExecuteDataReader(string query, CommandType commandType, SqlParameter[] parameters)
        {
            DataTable table = new DataTable();
            try
            {
                if (m_Adapter != null)
                {
                    SetCommand(query, commandType);
                    foreach (SqlParameter param in parameters)
                    {
                        m_Command.Parameters.Add(param);
                    }
                    this.m_Adapter.SelectCommand = m_Command;
                    this.m_Adapter.Fill(table);
                }
                else
                {
                    this.m_Adapter = new SqlDataAdapter();
                    this.m_Adapter.SelectCommand = m_Command;
                    this.m_Adapter.Fill(table);
                }
                m_Adapter.Dispose();
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
            return table;
        }

        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <returns></returns>
        public SqlDataReader ExecuteDataReader()
        {
            SqlDataReader reader = null;
            try
            {
                if (this.m_Connection.State == ConnectionState.Closed)
                    this.m_Connection.Open();

                reader = this.m_Command.ExecuteReader(CommandBehavior.CloseConnection);

                //if (this.m_Connection.State == ConnectionState.Open)
                //    this.m_Connection.Close();
            }
            catch (SqlException ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
            return reader;
        }

        /// <summary>
        /// Executes the transaction.
        /// </summary>
        /// <returns></returns>
        public int ExecuteTransaction(ArrayList arrSQL)
        {
            int row = 0;
            //SqlConnection connect = new SqlConnection(CONNECTION_STRING);
            //connect.Open();
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();
            SqlTransaction transaction = this.m_Connection.BeginTransaction();
            try
            {

                for (int i = 0; i < arrSQL.Count; i++)
                {

                    SetCommand(arrSQL[i].ToString(), CommandType.Text);
                    this.m_Command.Transaction = transaction;
                    this.m_Command.ExecuteNonQuery();
                    //SqlCommand command = new SqlCommand(arrSQL[i].ToString(), connect);
                    //command.Transaction = transaction;                    
                    //command.ExecuteNonQuery();
                }
                transaction.Commit();
                row = 1;
                //connect.Close();   
                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();
            }
            catch (SqlException ex)
            {
                transaction.Rollback();
                throw new System.ArgumentException(ex.Message);
            }

            return row;
        }
    }
}
