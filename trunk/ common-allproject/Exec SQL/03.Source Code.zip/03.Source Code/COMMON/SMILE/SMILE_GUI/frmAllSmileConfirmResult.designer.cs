﻿namespace Phoenix.Common.Smile.Gui
{
    partial class frmAllSmileConfirmResult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFailureMessage = new System.Windows.Forms.Label();
            this.btnSuccess = new System.Windows.Forms.Button();
            this.btnFail = new System.Windows.Forms.Button();
            this.rtbFailureMessage = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // lblFailureMessage
            // 
            this.lblFailureMessage.AutoSize = true;
            this.lblFailureMessage.Location = new System.Drawing.Point(12, 9);
            this.lblFailureMessage.Name = "lblFailureMessage";
            this.lblFailureMessage.Size = new System.Drawing.Size(84, 13);
            this.lblFailureMessage.TabIndex = 0;
            this.lblFailureMessage.Text = "Failure Message";
            // 
            // btnSuccess
            // 
            this.btnSuccess.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSuccess.Location = new System.Drawing.Point(124, 230);
            this.btnSuccess.Name = "btnSuccess";
            this.btnSuccess.Size = new System.Drawing.Size(74, 24);
            this.btnSuccess.TabIndex = 2;
            this.btnSuccess.Text = "&Success";
            this.btnSuccess.UseVisualStyleBackColor = true;
            this.btnSuccess.Click += new System.EventHandler(this.btnSuccess_Click);
            // 
            // btnFail
            // 
            this.btnFail.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnFail.Location = new System.Drawing.Point(204, 230);
            this.btnFail.Name = "btnFail";
            this.btnFail.Size = new System.Drawing.Size(77, 24);
            this.btnFail.TabIndex = 3;
            this.btnFail.Text = "&Fail";
            this.btnFail.UseVisualStyleBackColor = true;
            this.btnFail.Click += new System.EventHandler(this.btnFail_Click);
            // 
            // rtbFailureMessage
            // 
            this.rtbFailureMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbFailureMessage.Location = new System.Drawing.Point(14, 28);
            this.rtbFailureMessage.Name = "rtbFailureMessage";
            this.rtbFailureMessage.Size = new System.Drawing.Size(366, 196);
            this.rtbFailureMessage.TabIndex = 4;
            this.rtbFailureMessage.Text = "";
            // 
            // frmAllSmileConfirmResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(392, 266);
            this.ControlBox = false;
            this.Controls.Add(this.rtbFailureMessage);
            this.Controls.Add(this.btnFail);
            this.Controls.Add(this.btnSuccess);
            this.Controls.Add(this.lblFailureMessage);
            this.Name = "frmAllSmileConfirmResult";
            this.Text = "Confirm Result";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFailureMessage;
        private System.Windows.Forms.Button btnSuccess;
        private System.Windows.Forms.Button btnFail;
        private System.Windows.Forms.RichTextBox rtbFailureMessage;
    }
}