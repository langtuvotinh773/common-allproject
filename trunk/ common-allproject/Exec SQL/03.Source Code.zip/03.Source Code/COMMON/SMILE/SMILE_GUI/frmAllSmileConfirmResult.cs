﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This screen is used to confirm result after importing data into Smile.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Obj;

namespace Phoenix.Common.Smile.Gui
{
    public partial class frmAllSmileConfirmResult : Form
    {
        public delegate void RunComplete(bool isSuccess, string error);
        public event RunComplete OnRunComplete;

        /// <summary>
        /// Gets or sets the error log info.
        /// </summary>
        /// <value>
        /// The error log info.
        /// </value>
        public clsErrorLogDto ErrorLogInfo { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="frmAllSmileConfirmResult" /> class.
        /// </summary>
        /// <param name="error">The error.</param>
        public frmAllSmileConfirmResult(string error)
        {
            InitializeComponent();

            rtbFailureMessage.Text = error;
            if (error != null && error.Length > 0)
                btnSuccess.Enabled = false;
        }

        private void btnSuccess_Click(object sender, EventArgs e)
        {
            Close();
            //clsSmileCommon.IS_IMPORTED_TO_SMILE = true;
            //SaveLog(true, String.Empty);
            if (OnRunComplete != null)
            {
                OnRunComplete(true, rtbFailureMessage.Text);
            }
        }

        private void btnFail_Click(object sender, EventArgs e)
        {
            if (rtbFailureMessage.Text.Length == 0)
            {
                clsSmileCommon.ShowMessage((int)MessageType.Error, "Please input error information");
                return;
            }
            Close();
            //clsSmileCommon.IS_IMPORTED_TO_SMILE = false;
            //SaveLog(false, rtbFailureMessage.Text);
            if (OnRunComplete != null)
            {
                OnRunComplete(false, rtbFailureMessage.Text);
            }
        }
    }
}