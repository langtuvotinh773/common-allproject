﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Macro;

namespace Phoenix.Common.Smile.Gui
{
    public partial class frmAllSmileProgressStatus : Form
    {
        private BackgroundWorker m_bg = null;
        private MacroType m_MacroType;
        private string m_Session = null;
        private object m_Data = null;
        private string m_Error = null;


        private frmAllSmileConfirmResult m_ConfirmResult = null;
        private clsLGONEWMacro m_LGNewEntryMacro = null;
        private clsLGOSETMacro m_LGTerminateMacro = null;

        public frmAllSmileProgressStatus(MacroType macroType, string session, object data)
        {
            InitializeComponent();

            m_MacroType = macroType;
            m_Session = session;
            m_Data = data;

            m_bg = new BackgroundWorker();
            m_bg.DoWork += new DoWorkEventHandler(DoWork);
            m_bg.RunWorkerCompleted += new RunWorkerCompletedEventHandler(RunWorkerCompleted);

            m_bg.RunWorkerAsync();
        }

        private void DoWork(object sender, DoWorkEventArgs e)
        {
            switch (m_MacroType)
            {
                case MacroType.LGONEW:
                    m_LGNewEntryMacro = new clsLGONEWMacro(m_Data);
                    m_Error = m_LGNewEntryMacro.TransferToSmile(m_Session);
                    clsSmileCommon.ActivateSmileWindow(m_Session);
                    break;
                case MacroType.LGOSET:
                    m_LGTerminateMacro = new clsLGOSETMacro(m_Data);
                    m_Error = m_LGTerminateMacro.TransferToSmile(m_Session);
                    clsSmileCommon.ActivateSmileWindow(m_Session);
                    break;
                case MacroType.TDPrematureRate:
                    break;
                case MacroType.TDPrematureBC:
                    break;
                case MacroType.CloseTD:
                    break;
                default:
                    break;
            }
        }

        private void RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Hide();
            m_ConfirmResult = new frmAllSmileConfirmResult(m_Error);
            m_ConfirmResult.Owner = Owner;
            m_ConfirmResult.StartPosition = FormStartPosition.CenterScreen;
            m_ConfirmResult.ShowDialog();
            Close();
        }
    }
}