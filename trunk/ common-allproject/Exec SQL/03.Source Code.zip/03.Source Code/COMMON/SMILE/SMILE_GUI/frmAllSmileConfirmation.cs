﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This screen is used to import data from Phoenix into Smile.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.SqlClient;

using COMMON.Properties;
using Config.Classes;
using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Obj;
using Phoenix.Common.Smile.Macro;

namespace Phoenix.Common.Smile.Gui
{
    public enum Module
    {
        LO,
        TD,
        FX,
        LG
    }

    public enum MessageType : int
    {
        Confirm = 0,
        Error = 1,
        Information = 2,
        YesNoConfirm = 3
    }

    public enum MacroType
    {
        LGONEW,
        LGOSET,
        GTON01,
        TDNewRollover,
        TDPrematureRate,
        TDPrematureBC,
        CloseTD
    }

    public enum ImportType
    {
        LGIssue,
        LGAmend,
        LGTerminate,
        GeneralTransfer
    }
    
    public partial class frmAllSmileConfirmation : Form
    {
        private const string WAITING_STATUS = "Waiting";
        private const string IMPORTING_STATUS = "Importing";
        private const string FISISH_STATUS = "Finish";
        private const string SUCCESS_STATUS = "Success";
        private const string FAIL_STATUS = "Failed";

        private BackgroundWorker m_bg = null;
        private string m_Session = null;
        private string m_Error = null;

        private int m_RowCount = 0;
        private int m_RowIndex = -1;
        private bool m_AllowViewLog = false;
        private bool m_IsCellClick = true;
        private bool m_IsSuccess = false;
        private bool m_IsImported = false;
        private object m_LastMacro = null;

        private frmAllSmileConfirmResult m_ConfirmResult = null;
        private frmAllSmileViewLog m_frmLog = null;

        private List<object> m_MacroObjList;
        public clsErrorLogDto ErrorLogInfo { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="frmAllSmileConfirmation" /> class.
        /// </summary>
        /// <param name="macroObjList">The macro object list.</param>
        public frmAllSmileConfirmation(List<object> macroObjList)
        {
            InitializeComponent();

            m_MacroObjList = macroObjList;

            m_bg = new BackgroundWorker();
            m_bg.DoWork += new DoWorkEventHandler(DoWork);
            m_bg.RunWorkerCompleted += new RunWorkerCompletedEventHandler(RunWorkerCompleted);

            ckbViewLog.Checked = true;

            for (int i = 0; i < macroObjList.Count; i++)
            {
                if (macroObjList[i] is clsLGONEWDto)
                {
                    clsLGONEWDto dto = (macroObjList[i] as clsLGONEWDto);
                    dtgMacro.Rows.Add(null, dto.MacroType.ToString(), dto.ImportType.ToString(), dto.Page1Trans1 + "-" + dto.Page1Trans2, WAITING_STATUS);
                    dtgMacro.Rows[i].Tag = dto;
                }
                else if (macroObjList[i] is clsLGOSETDto)
                {
                    clsLGOSETDto dto = (macroObjList[i] as clsLGOSETDto);
                    dtgMacro.Rows.Add(null, dto.MacroType.ToString(), dto.ImportType.ToString(), dto.Trans1 + "-" + dto.Trans2, WAITING_STATUS);
                    dtgMacro.Rows[i].Tag = dto;
                }
                else if (macroObjList[i] is clsGTON01Dto)
                {
                    clsGTON01Dto dto = (macroObjList[i] as clsGTON01Dto);
                    dtgMacro.Rows.Add(null, dto.MacroType.ToString(), dto.ImportType.ToString(), dto.TransNo, WAITING_STATUS);
                    dtgMacro.Rows[i].Tag = dto;
                }
                else if (macroObjList[i] is clsFDONEWDto)
                {
                    clsFDONEWDto dto = (macroObjList[i] as clsFDONEWDto);
                    dtgMacro.Rows.Add(null, dto.MacroType.ToString(), dto.ImportType.ToString(), dto.TDNo1 + " - " + dto.TDNo2, WAITING_STATUS);
                    dtgMacro.Rows[i].Tag = dto; 
                }
                else if (macroObjList[i] is clsFDOSETDto)
                {
                    clsFDOSETDto dto = (macroObjList[i] as clsFDOSETDto);
                    dtgMacro.Rows.Add(null, dto.MacroType.ToString(), dto.ImportType.ToString(), dto.TDNo, WAITING_STATUS);
                    dtgMacro.Rows[i].Tag = dto; 
                }
            }

            if (dtgMacro.Rows.Count > 0)
            {
                dtgMacro.Columns[0].DefaultCellStyle.NullValue = null;
                m_RowCount = dtgMacro.Rows.Count;
                dtgMacro.Rows[0].Selected = true;
                m_LastMacro = dtgMacro.Rows[0].Tag;
                PopulateListView(dtgMacro.SelectedRows[0].Tag);

                m_RowIndex = 0;
            }
            else
                btnOK.Enabled = false;
        }

        /// <summary>
        /// Loads data into listview.
        /// </summary>
        /// <param name="names">The names.</param>
        /// <param name="values">The values.</param>
        private void LoadData(string[] names, string[] values)
        {
            if (names.Length != values.Length) return;
            listView1.Items.Clear();
            for (int i = 0; i < names.Length; i++)
            {
                ListViewItem item = new ListViewItem();
                item.UseItemStyleForSubItems = false;
                item.ForeColor = System.Drawing.Color.LightGreen;
                item.Text = names[i];

                ListViewItem.ListViewSubItem sub = new ListViewItem.ListViewSubItem();
                sub.ForeColor = System.Drawing.Color.Yellow;
                sub.Text = values[i];

                item.SubItems.Add(sub);
                listView1.Items.Add(item);
            }
        }

        /// <summary>
        /// Populates the list view.
        /// </summary>
        /// <param name="macro">The macro data object.</param>
        private void PopulateListView(object macro)
        {
            if (macro is clsLGONEWDto)
            {
                clsLGONEWDto dto = (macro as clsLGONEWDto);
                LoadData(dto.FieldNames, dto.FieldValues);
            }
            else if (macro is clsLGOSETDto)
            {
                clsLGOSETDto dto = (macro as clsLGOSETDto);
                LoadData(dto.FieldNames, dto.FieldValues);
            }
            else if (macro is clsGTON01Dto)
            {
                clsGTON01Dto dto = (macro as clsGTON01Dto);
                LoadData(dto.FieldNames, dto.FieldValues);
            }
            else if (macro is clsFDONEWDto)
            {
                clsFDONEWDto dto = (macro as clsFDONEWDto);
                LoadData(dto.FieldNames, dto.FieldValues);
            }
            else if (macro is clsFDOSETDto)
            {
                clsFDOSETDto dto = (macro as clsFDOSETDto);
                LoadData(dto.FieldNames, dto.FieldValues);
            }
        }

        /// <summary>
        /// Sets the running status.
        /// </summary>
        private void SetRunningStatus()
        {
            //tsStatusImg.Text = null;
            //tsStatusImg.Image = COMMON.Properties.Resources.progress;
            //tsStatusText.ForeColor = Color.Blue;
            //tsStatusText.Text = "Importing " + macro + " macro...";

            DataGridViewRow row = dtgMacro.SelectedRows[0];
            row.Cells["colImage"].Value = COMMON.Properties.Resources.progress;
            row.Cells["colStatus"].Value = IMPORTING_STATUS;
        }

        /// <summary>
        /// Sets the finish status.
        /// </summary>
        private void SetFinishStatus()
        {
            //tsStatusImg.Image = null;
            //tsStatusImg.DisplayStyle = ToolStripItemDisplayStyle.Text;
            //tsStatusImg.Text = "Finished.";
            //tsStatusImg.ForeColor = Color.Blue;
            //tsStatusText.Text = null;
            ControlBox = true;
            DataGridViewRow row = dtgMacro.SelectedRows[0];
            row.Cells["colImage"].Value = COMMON.Properties.Resources.finish;
            row.Cells["colStatus"].Value = FISISH_STATUS;
        }

        /// <summary>
        /// Shows the log form.
        /// </summary>
        /// <param name="transNo">The trans no.</param>
        /// <param name="module">The module.</param>
        private void ShowLogForm(string transNo, Module module)
        {
            if (m_frmLog == null || m_frmLog.IsDisposed)
            {
                m_frmLog = new frmAllSmileViewLog(transNo, module);
                m_frmLog.MdiParent = (Form)Tag;
                m_frmLog.StartPosition = FormStartPosition.CenterScreen;
                m_frmLog.Show();
            }
            else
            {
                m_frmLog.GetSearchCondition(transNo, module);
                m_frmLog.Visible = true;
                m_frmLog.Activate();
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtSession.Text.Length == 0) return;
            if (clsSmileCommon.ShowMessage((int)MessageType.YesNoConfirm, "Are you sure you want to import data into Smile?") == DialogResult.Yes)
            {
                m_Session = txtSession.Text;
                ControlBox = false;
                txtSession.ReadOnly = true;
                btnOK.Enabled = false;
                btnCancel.Enabled = false;
                m_IsImported = true;
                m_bg.RunWorkerAsync();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //m_frmLog = new frmAllSmileViewLog(transNo, module);
            //m_frmLog.MdiParent = (Form)Tag;
            //clsSmileCommon.CloseViewLogWindow();
            DialogResult = DialogResult.OK;
            Close();
        }

        private void txtSession_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
            e.KeyChar = Char.ToUpper(e.KeyChar);
        }

        private void DoWork(object sender, DoWorkEventArgs e)
        {
            if (dtgMacro.Rows[m_RowIndex] == null) return;
            object macro = dtgMacro.Rows[m_RowIndex].Tag;
            if (macro is clsLGONEWDto)
            {
                ErrorLogInfo.ImportTime = DateTime.Now;
                ErrorLogInfo.ImportType = ImportType.LGIssue;
                Invoke(new Action(() => SetRunningStatus()));
                clsLGONEWMacro LGONEWMacro = new clsLGONEWMacro(macro);
                m_Error = LGONEWMacro.TransferToSmile(m_Session);
                Invoke(new Action(() => SetFinishStatus()));
                clsSmileCommon.ActivateSmileWindow(m_Session);
            }
            else if (macro is clsLGOSETDto)
            {
                ErrorLogInfo.ImportTime = DateTime.Now;
                ErrorLogInfo.ImportType = ImportType.LGTerminate;
                Invoke(new Action(() => SetRunningStatus()));
                clsLGOSETMacro LGOSETMacro = new clsLGOSETMacro(macro);
                m_Error = LGOSETMacro.TransferToSmile(m_Session);
                Invoke(new Action(() => SetFinishStatus()));
                clsSmileCommon.ActivateSmileWindow(m_Session);
            }
            else if (macro is clsGTON01Dto)
            {
                ErrorLogInfo.ImportTime = DateTime.Now;
                ErrorLogInfo.ImportType = ImportType.GeneralTransfer;
                Invoke(new Action(() => SetRunningStatus()));
                clsGTON01Macro GTON01Macro = new clsGTON01Macro(macro);
                m_Error = GTON01Macro.TransferToSmile(m_Session);
                Invoke(new Action(() => SetFinishStatus()));
                clsSmileCommon.ActivateSmileWindow(m_Session);
            }
            else if (macro is clsFDONEWDto)
            {
                ErrorLogInfo.ImportTime = DateTime.Now;
                Invoke(new Action(() => SetRunningStatus()));
                clsFDONEWMacro FDONEWMacro = new clsFDONEWMacro(macro);
                m_Error = FDONEWMacro.TransferToSmile(m_Session);
                Invoke(new Action(() => SetFinishStatus()));
                clsSmileCommon.ActivateSmileWindow(m_Session);
            }
            else if (macro is clsFDOSETDto)
            {
                ErrorLogInfo.ImportTime = DateTime.Now;
                Invoke(new Action(() => SetRunningStatus()));
                clsFDOSETMacro FDOSETMacro = new clsFDOSETMacro(macro);
                m_Error = FDOSETMacro.TransferToSmile(m_Session);
                Invoke(new Action(() => SetFinishStatus()));
                clsSmileCommon.ActivateSmileWindow(m_Session);
            }

            //ErrorLogInfo.ImportTime = DateTime.Now;
            //Invoke(new Action(() => SetRunningStatus()));
            //string str = System.Configuration.ConfigurationSettings.AppSettings["LOGConnectionString"].ToString(); ;
            //using (SqlConnection con = new SqlConnection(str))
            //{
            //    con.Open();
            //    using (SqlCommand cmd = new SqlCommand())
            //    {
            //        cmd.CommandText = "select * from tblCOM_LogHistory where ApplicationName = 'Controlling Book Report'";
            //        cmd.CommandType = CommandType.Text;
            //        cmd.Connection = con;
            //        SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            //    }
            //}
            //Invoke(new Action(() => SetFinishStatus()));

            //e.Result = true;
        }

        private void RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            m_ConfirmResult = new frmAllSmileConfirmResult(m_Error);
            m_ConfirmResult.OnRunComplete += new frmAllSmileConfirmResult.RunComplete(OnRunComplete);
            //m_ConfirmResult.Owner = Owner;
            m_ConfirmResult.StartPosition = FormStartPosition.CenterScreen;
            m_ConfirmResult.ShowDialog();
        }

        private void OnRunComplete(bool isSuccess, string error)
        {
            object macro = dtgMacro.Rows[m_RowIndex].Tag;
            if (isSuccess)
            {
                m_IsSuccess = true;
                dtgMacro.Rows[m_RowIndex].Cells["colImage"].Value = Resources.success;
                dtgMacro.Rows[m_RowIndex].Cells["colStatus"].Value = SUCCESS_STATUS;

                //object macro = dtgMacro.Rows[m_RowIndex].Tag;
                if (macro is clsLGOSETDto)
                {
                    clsLGOSETDto dto = (macro as clsLGOSETDto);
                    //clsSmileCommon.DeleteLGImportFail(dto.Trans1);
                    clsSmileCommon.UpdateLGSmileStatus(dto.Trans1, dto.Trans2, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value, 1, 1);

                    if (ErrorLogInfo == null)
                    {
                        clsErrorLogDto SmileErrorLog = new clsErrorLogDto();
                        SmileErrorLog.Module = Module.LG.ToString();
                        SmileErrorLog.ImportBy = clsUserInfo.FullName;
                        SmileErrorLog.TransNo = dto.Trans1 + "-" + dto.Trans2;

                        ErrorLogInfo = SmileErrorLog;
                    }
                    else
                        ErrorLogInfo.TransNo = dto.Trans1 + "-" + dto.Trans2;
                }
                else if (macro is clsLGONEWDto)
                {
                    clsLGONEWDto dto = (macro as clsLGONEWDto);
                    clsSmileCommon.UpdateLGSmileStatus(dto.Page1Trans1, dto.Page1Trans2, 1, 1, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value);

                    ErrorLogInfo.TransNo = dto.Page1Trans1 + "-" + dto.Page1Trans2;
                }
                else if (macro is clsGTON01Dto)
                {
                    clsGTON01Dto dto = (macro as clsGTON01Dto);
                    string tranNo = dto.TransNo.Substring(0, 6);
                    string lgsub = dto.TransNo.Substring(7, 2);
                    clsSmileCommon.UpdateLGSmileStatus(tranNo, lgsub, DBNull.Value, DBNull.Value, 1, 1, DBNull.Value, DBNull.Value);

                    ErrorLogInfo.TransNo = dto.TransNo;
                }
                m_LastMacro = macro;
            }
            else
            {
                m_IsSuccess = false;
                dtgMacro.Rows[m_RowIndex].Cells["colImage"].Value = Resources.failed;
                dtgMacro.Rows[m_RowIndex].Cells["colStatus"].Value = FAIL_STATUS;
                
                //object macro = dtgMacro.Rows[m_RowIndex].Tag;
                if (macro is clsLGOSETDto)
                {
                    clsLGOSETDto dto = (macro as clsLGOSETDto);
                    if(dto.IsDelete)
                        clsSmileCommon.DeleteLGImportFail(dto.Trans1);
                    clsSmileCommon.UpdateLGSmileStatus(dto.Trans1, dto.Trans2, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value, 1, 0);

                    ErrorLogInfo.TransNo = dto.Trans1 + "-" + dto.Trans2;
                }
                else if (macro is clsLGONEWDto)
                {
                    clsLGONEWDto dto = (macro as clsLGONEWDto);
                    clsSmileCommon.UpdateLGSmileStatus(dto.Page1Trans1, dto.Page1Trans2, 1, 0, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value);

                    ErrorLogInfo.TransNo = dto.Page1Trans1 + "-" + dto.Page1Trans2;
                }
                else if (macro is clsGTON01Dto)
                {
                    clsGTON01Dto dto = (macro as clsGTON01Dto);
                    string tranNo = dto.TransNo.Substring(0, 6);
                    string lgsub = dto.TransNo.Substring(7, 2);
                    clsSmileCommon.UpdateLGSmileStatus(tranNo, lgsub, DBNull.Value, DBNull.Value, 1, 0, DBNull.Value, DBNull.Value);

                    ErrorLogInfo.TransNo = dto.TransNo;
                }
                m_LastMacro = macro;
            }
            txtSession.ReadOnly = false;
            btnOK.Enabled = true;
            btnCancel.Enabled = true;

            // Save error log
            ErrorLogInfo.Result = isSuccess;
            ErrorLogInfo.ErrorMsg = error;
            clsSmileCommon.SaveLog(ErrorLogInfo);
            
            // If there is a macro failed. Stop here.
            if (!isSuccess)
            {
                //m_LastMacro = dtgMacro.Rows[m_RowIndex].Tag;
                return;
            }

            if (m_RowCount - m_RowIndex != 1)
            {
                if (m_RowCount > 1 && m_RowIndex < m_RowCount)
                {
                    ++m_RowIndex;
                    m_IsCellClick = false;
                    dtgMacro.Rows[m_RowIndex].Selected = true;
                    PopulateListView(dtgMacro.Rows[m_RowIndex].Tag);
                }
            }
            else
            {
                if (isSuccess)
                {
                    dtgMacro.Rows[m_RowIndex].Cells["colImage"].Value = Resources.success;
                    dtgMacro.Rows[m_RowIndex].Cells["colStatus"].Value = SUCCESS_STATUS;
                }
                btnOK.Enabled = false;
                dtgMacro.ClearSelection();

                //m_LastMacro = dtgMacro.Rows[m_RowIndex].Tag;
            }
        }

        private void ckbViewLog_CheckedChanged(object sender, EventArgs e)
        {
            if (ckbViewLog.Checked)
                m_AllowViewLog = true;
            else
                m_AllowViewLog = false;
        }

        private void frmAllSmileConfirmation_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (m_AllowViewLog)
            {
                if (m_LastMacro == null) return;
                //object macro = dtgMacro.Rows[m_RowIndex].Tag;
                if (m_LastMacro is clsLGONEWDto)
                {
                    clsLGONEWDto dto = (m_LastMacro as clsLGONEWDto);
                    clsSmileCommon.OpenViewLogForm(Tag, dto.Page1Trans1, Module.LG);
                    //ShowLogForm(dto.Page1Trans1, Module.LG);
                    //m_frmLog = new frmAllSmileViewLog(dto.Page1Trans1 + "-" + dto.Page1Trans2, Module.LG);
                    //m_frmLog.StartPosition = FormStartPosition.CenterScreen;
                    //m_frmLog.Show();
                }
                else if (m_LastMacro is clsLGOSETDto)
                {
                    clsLGOSETDto dto = (m_LastMacro as clsLGOSETDto);
                    
                    clsSmileCommon.OpenViewLogForm(Tag, dto.Trans1, Module.LG);
                    //ShowLogForm(dto.Trans1, Module.LG);
                    //m_frmLog = new frmAllSmileViewLog(dto.Trans1 + "-" + dto.Trans2, Module.LG);
                    //m_frmLog.StartPosition = FormStartPosition.CenterScreen;
                    //m_frmLog.Show();
                }
                else if (m_LastMacro is clsGTON01Dto)
                {
                    clsSmileCommon.OpenViewLogForm(Tag, (m_LastMacro as clsGTON01Dto).TransNo.Substring(0, 6), Module.LG);
                    //ShowLogForm((m_LastMacro as clsGTON01Dto).TransNo.Substring(7, 2), Module.LG);
                    //frmAllSmileViewLog frmLog = new frmAllSmileViewLog((m_LastMacro as clsGTON01Dto).TransNo, Module.LG);
                    //frmLog.StartPosition = FormStartPosition.CenterScreen;
                    //frmLog.Show();
                }
                else if (m_LastMacro is clsFDONEWDto)
                {
                    clsSmileCommon.OpenViewLogForm(Tag, (m_LastMacro as clsFDONEWDto).TDNo1, Module.LG);
                    //ShowLogForm((m_LastMacro as clsFDONEWDto).TDNo1, Module.TD);
                    //frmAllSmileViewLog frmLog = new frmAllSmileViewLog((m_LastMacro as clsFDONEWDto).TDNo1, Module.TD);
                    //frmLog.StartPosition = FormStartPosition.CenterScreen;
                    //frmLog.Show();
                }
                else if (m_LastMacro is clsFDOSETDto)
                {
                    clsSmileCommon.OpenViewLogForm(Tag, (m_LastMacro as clsFDOSETDto).TDNo, Module.LG);
                    //ShowLogForm((m_LastMacro as clsFDOSETDto).TDNo, Module.TD);
                    //frmAllSmileViewLog frmLog = new frmAllSmileViewLog((m_LastMacro as clsFDOSETDto).TDNo, Module.TD);
                    //frmLog.StartPosition = FormStartPosition.CenterScreen;
                    //frmLog.Show();
                }
            }

            if (!m_IsImported && m_LastMacro is clsLGOSETDto)
            {
                clsLGOSETDto dto = (m_LastMacro as clsLGOSETDto);
                if (!m_IsSuccess && dto.IsDelete)
                    clsSmileCommon.DeleteLGImportFail(dto.Trans1);
            }
        }

        private void dtgMacro_SelectionChanged(object sender, EventArgs e)
        {
            if (m_IsCellClick && m_RowIndex > -1)
            {
                dtgMacro.Rows[m_RowIndex].Selected = true;
            }
        }

        private void dtgMacro_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                m_IsCellClick = true;
            }
        }
    }
}