﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Phoenix.Common.Smile.Gui
{
    public partial class frmAllSmileInputSession : Form
    {
        private frmAllSmileProgressStatus frm = null;
        private MacroType m_MacroType;
        private object m_Data = null;

        public frmAllSmileInputSession(MacroType macroType, object data)
        {
            InitializeComponent();

            m_MacroType = macroType;
            m_Data = data;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            //Hide();
            Invoke(new Action(() => Hide()));
            frm = new frmAllSmileProgressStatus(m_MacroType, txtSession.Text, m_Data);
            frm.Owner = Owner;
            frm.StartPosition = FormStartPosition.CenterScreen;

            //frm.ShowDialog();
            Invoke(new Action(() => frm.ShowDialog()));

            Close();
        }

        private void txtSession_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
            e.KeyChar = Char.ToUpper(e.KeyChar);
        }
    }
}