﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-03-02 20:37:30 +0700 (Sat, 02 Mar 2013) $
 * $Revision: 9331 $ 
 * ========================================================
 * This screen is used to view log after Smile operation.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Obj;

namespace Phoenix.Common.Smile.Gui
{
    public partial class frmAllSmileViewLog : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="frmAllSmileViewLog" /> class.
        /// </summary>
        public frmAllSmileViewLog()
        {
            InitializeComponent();

            clsCommonStyles style = clsCommonStyles.Instance();

            dtgLog.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            dtgLog.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dtgLog.EnableHeadersVisualStyles = false;
            dtgLog.ColumnHeadersDefaultCellStyle.BackColor = style.DGVColumnHeaderBG;
            dtgLog.DefaultCellStyle.BackColor = style.DGVReadOnlyColumnBG;
            
            cbbTransType.DataSource = Enum.GetValues(typeof(Module));

            dtpFrom.Text = String.Empty;
            dtpTo.Text = String.Empty; 
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="frmAllSmileViewLog" /> class.
        /// </summary>
        /// <param name="transNo">The transaction no.</param>
        /// <param name="type">The module type.</param>
        public frmAllSmileViewLog(string transNo, Module type)
        {
            InitializeComponent();

            //dtgLog.AutoGenerateColumns = false;
            //dtgLog.Columns["colImportTime"].DataPropertyName = "ImportTime";
            //dtgLog.Columns["colStatus"].DataPropertyName = "Result";
            //dtgLog.Columns["colErrorMsg"].DataPropertyName = "ErrorMsg";

            clsCommonStyles style = clsCommonStyles.Instance();

            dtgLog.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            dtgLog.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dtgLog.EnableHeadersVisualStyles = false;
            dtgLog.ColumnHeadersDefaultCellStyle.BackColor = style.DGVColumnHeaderBG;
            dtgLog.DefaultCellStyle.BackColor = style.DGVReadOnlyColumnBG;
            
            cbbTransType.DataSource = Enum.GetValues(typeof(Module));

            txtTransNo.Text = transNo;
            dtpFrom.Text = String.Empty;
            dtpTo.Text = String.Empty;

            switch (type)
            {
                case Module.LO:
                    cbbTransType.SelectedIndex = 0;
                    break;
                case Module.TD:
                    cbbTransType.SelectedIndex = 1;
                    break;
                case Module.FX:
                    cbbTransType.SelectedIndex = 2;
                    break;
                case Module.LG:
                    cbbTransType.SelectedIndex = 3;
                    break;
                default:
                    break;
            }

            SearchLog();
        }

        /// <summary>
        /// Searches log information.
        /// </summary>
        private void SearchLog()
        {
            //if (cbbTransType.Text == null)
            //{
            //    return;
            //}
            clsErrorLogDto dto = new clsErrorLogDto();
            dto.TransNo = txtTransNo.Text;
            dto.Module = cbbTransType.Text;
            if (dtpFrom.Text.Length == 0 && dtpTo.Text.Length == 0)
            {
                dto.From = String.Empty;
                dto.To = String.Empty;
            }
            else
            {
                dto.From = dtpFrom.Value.ToString("yyyy/MM/dd");
                dto.To = dtpTo.Value.ToString("yyyy/MM/dd");
            }
            dtgLog.Rows.Clear();
            List<clsErrorLogDto> listLog = clsSmileCommon.SearchLog(dto);
            foreach (clsErrorLogDto item in listLog)
            {
                dtgLog.Rows.Add(item.Module, item.TransNo, item.ImportTime.ToString("yyyyMMdd hh:mm:ss tt"),
                    item.ImportBy, item.ImportTypeText, item.Status, item.ErrorMsg);
            }
            //dtgLog.DataSource = listLog;
        }

        public void GetSearchCondition(string transNo, Module module)
        {
            txtTransNo.Text = transNo;
            cbbTransType.Text = module.ToString();

            SearchLog();
        }

        private void frmAllSmileViewLog_Load(object sender, EventArgs e)
        {
            dtgLog.ClearSelection();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //if (dtpFrom.Text.Length == 0 || dtpTo.Text.Length == 0)
            //{
            //    clsSmileCommon.ShowMessage((int)MessageType.Error, "Please input valid time");
            //    return;
            //}
            SearchLog();
            dtgLog.ClearSelection();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}