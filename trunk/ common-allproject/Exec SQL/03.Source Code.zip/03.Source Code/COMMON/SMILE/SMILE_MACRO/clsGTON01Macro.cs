﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This class is used to define fields information and Smile operation
 * for General Transfer.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Obj;

namespace Phoenix.Common.Smile.Macro
{
    public class clsGTON01Macro : clsSmileBaseMacro
    {
        // Coordinates of each field in DEBIT section
        private const int DB_CCY_X = 4;
        private const int DB_VALUE_X = 4;
        private const int DB_ADVICE_X = 4;
        private const int DB_GL1_X = 5;
        private const int DB_GL2_X = 5;
        private const int DB_ACNO_X = 5;
        private const int DB_AMOUNT_X = 5;
        private const int DB_NW_X = 6;
        private const int DB_REF_X = 7;
        private const int DB_OURREF_X = 8;

        private const int DB_CCY_Y = 23;
        private const int DB_VALUE_Y = 41;
        private const int DB_ADVICE_Y = 58;
        private const int DB_GL1_Y = 10;
        private const int DB_GL2_Y = 16;
        private const int DB_ACNO_Y = 32;
        private const int DB_AMOUNT_Y = 60;
        private const int DB_NW_Y = 39;
        private const int DB_REF_Y = 61;
        private const int DB_OURREF_Y = 15;

        // Coordinates of each field in CREDIT section
        private const int CD_CCY_X = 12;
        private const int CD_GL1_X = 13;
        private const int CD_GL2_X = 13;
        private const int CD_ACNO_X = 13;
        private const int CD_AMOUNT_X = 13;
        private const int CD_CUSTOMER_X = 15;
        private const int CD_REF_X = 15;

        private const int CD_CCY_Y = 23;
        private const int CD_GL1_Y = 10;
        private const int CD_GL2_Y = 16;
        private const int CD_ACNO_Y = 32;
        private const int CD_AMOUNT_Y = 60;
        private const int CD_CUSTOMER_Y = 15;
        private const int CD_REF_Y = 61;

        // Coordinates of each field in EXCHANGE section
        private const int EX_METHOD_X = 20;
        private const int EX_METHOD_Y = 25;
        private const int EX_CUST_X = 20;
        private const int EX_CUST_Y = 39;

        /// <summary>
        /// Initializes a new instance of the <see cref="clsGTON01Macro" /> class.
        /// </summary>
        /// <param name="data">The macro object.</param>
        public clsGTON01Macro(object data)
        {
            clsGTON01Dto dto = data as clsGTON01Dto;
            List<clsSmileField> FieldList = new List<clsSmileField>();
            m_PageList = new List<clsSmilePage>();

            // Debit section
            if (dto.DebitCcy != null)
                FieldList.Add(new clsSmileField() { X = DB_CCY_X, Y = DB_CCY_Y, FieldName = "DebitCcy", FieldValue = dto.DebitCcy });
            if (dto.DebitValue != null)
                FieldList.Add(new clsSmileField() { X = DB_VALUE_X, Y = DB_VALUE_Y, FieldName = "DebitValueDate", FieldValue = dto.DebitValue });
            if (dto.DebitAdvice != null)
                FieldList.Add(new clsSmileField() { X = DB_ADVICE_X, Y = DB_ADVICE_Y, FieldName = "DebitAdvice", FieldValue = dto.DebitAdvice });
            if (dto.DebitGL1 != null)
                FieldList.Add(new clsSmileField() { X = DB_GL1_X, Y = DB_GL1_Y, FieldName = "DebitGL1", FieldValue = dto.DebitGL1 });
            if (dto.DebitGL2 != null)
                FieldList.Add(new clsSmileField() { X = DB_GL2_X, Y = DB_GL2_Y, FieldName = "DebitGL2", FieldValue = dto.DebitGL2 });
            if (dto.DebitACNo != null)
                FieldList.Add(new clsSmileField() { X = DB_ACNO_X, Y = DB_ACNO_Y, FieldName = "DebitACNo", FieldValue = dto.DebitACNo });
            if (dto.DebitAmount != null)
                FieldList.Add(new clsSmileField() { X = DB_AMOUNT_X, Y = DB_AMOUNT_Y, FieldName = "DebitAmount", FieldValue = dto.DebitAmount });
            if (dto.DebitNW != null && !dto.DebitNW.Equals(String.Empty))
            {
                FieldList.Add(new clsSmileField() { X = DB_NW_X, Y = DB_NW_Y, FieldName = "DebitNW", FieldValue = dto.DebitNW });
            }
            if (dto.DebitReference != null)
                FieldList.Add(new clsSmileField() { X = DB_REF_X, Y = DB_REF_Y, FieldName = "DebitRef", FieldValue = dto.DebitReference });
            if (dto.DebitOurRef != null)
                FieldList.Add(new clsSmileField() { X = DB_OURREF_X, Y = DB_OURREF_Y, FieldName = "OurRef", FieldValue = dto.DebitOurRef });

            // Credit section
            if (dto.CreditCcy != null)
                FieldList.Add(new clsSmileField() { X = CD_CCY_X, Y = CD_CCY_Y, FieldName = "CreditCcy", FieldValue = dto.CreditCcy });
            if (dto.CreditGL1 != null)
                FieldList.Add(new clsSmileField() { X = CD_GL1_X, Y = CD_GL1_Y, FieldName = "CreditGL1", FieldValue = dto.CreditGL1 });
            if (dto.CreditGL2 != null)
                FieldList.Add(new clsSmileField() { X = CD_GL2_X, Y = CD_GL2_Y, FieldName = "CreditGL2", FieldValue = dto.CreditGL2 });
            if (dto.CreditACNo != null)
                FieldList.Add(new clsSmileField() { X = CD_ACNO_X, Y = CD_ACNO_Y, FieldName = "CreditACNo", FieldValue = dto.CreditACNo });
            if (dto.CreditAmount != null)
                FieldList.Add(new clsSmileField() { X = CD_AMOUNT_X, Y = CD_AMOUNT_Y, FieldName = "CreditAmount", FieldValue = dto.CreditAmount });
            if (dto.CreditCustomer != null)
                FieldList.Add(new clsSmileField() { X = CD_CUSTOMER_X, Y = CD_CUSTOMER_Y, FieldName = "CreditCustomer", FieldValue = dto.CreditCustomer });
            if (dto.CreditReference != null)
                FieldList.Add(new clsSmileField() { X = CD_REF_X, Y = CD_REF_Y, FieldName = "CreditRef", FieldValue = dto.CreditReference });

            // Exchange section
            if (dto.Method != null && !dto.Method.Equals(String.Empty))
            {
                FieldList.Add(new clsSmileField() { X = EX_METHOD_X, Y = EX_METHOD_Y, FieldName = "ExMethod", FieldValue = dto.Method });
            }
            if (dto.Cust != null && !dto.Cust.Equals(String.Empty))
            {
                FieldList.Add(new clsSmileField() { X = EX_CUST_X, Y = EX_CUST_Y, FieldName = "ExCust", FieldValue = dto.Cust });
            }
            
            clsSmilePage Page = new clsSmilePage();
            Page.ScreenId = new clsSmileField { X = 1, Y = 73, FieldName = "ScreenId", FieldValue = "(GTON01)" };
            Page.IdentifyField = new clsSmileField { X = 5, Y = 10, FieldName = "G/L", FieldValue = "000 - 0000" };
            Page.IsLastPage = true;
            Page.FieldList = FieldList;

            m_PageList.Add(Page);
        }

        /// <summary>
        /// Transfers to smile.
        /// </summary>
        /// <param name="session">The session to identify the emulator window .</param>
        /// <returns></returns>
        public string TransferToSmile(string session)
        {
            return WritePages(session, m_PageList);
        }
    }
}