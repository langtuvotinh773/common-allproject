﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This class is used to define fields information and Smile operation
 * for LGIssue.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Obj;

namespace Phoenix.Common.Smile.Macro
{
    public class clsLGONEWMacro : clsSmileBaseMacro
    {
        //private List<clsSmilePage> m_PageList = null;

        // Coordinates of each field in page 1
        private const int P1_ISSUE_X = 4;
        private const int P1_EFFECTIVE_X = 5;
        private const int P1_CUSTOMER_X = 6;
        private const int P1_CCY_X = 7;
        private const int P1_GL1_X = 7;
        private const int P1_GL2_X = 7;
        private const int P1_TRANS1_X = 7;
        private const int P1_TRANS2_X = 7;
        private const int P1_ISSUE_Y = 23;
        private const int P1_EFFECTIVE_Y = 23;
        private const int P1_CUSTOMER_Y = 14;
        private const int P1_CCY_Y = 9;
        private const int P1_GL1_Y = 18;
        private const int P1_GL2_Y = 24;
        private const int P1_TRANS1_Y = 42;
        private const int P1_TRANS2_Y = 51;

        // Coordinates of each field in page 2
        private const int P2_TRANS_X = 7;
        private const int P2_EXP_X = 9;
        private const int P2_GARTYPE_X = 9;
        private const int P2_FEERATE_X = 11;
        private const int P2_ADJ_X = 11;
        private const int P2_MINIMUM_X = 12;
        private const int P2_CHGAC1_X = 16;
        private const int P2_CHGAC2_X = 16;
        private const int P2_CHGAC3_X = 16;
        private const int P2_CHGAC4_X = 16;
        private const int P2_BENE_X = 19;
        private const int P2_TRANS_Y = 59;
        private const int P2_EXP_Y = 12;
        private const int P2_GARTYPE_Y = 49;
        private const int P2_FEERATE_Y = 17;
        private const int P2_ADJ_Y = 50;
        private const int P2_MINIMUM_Y = 20;
        private const int P2_CHGAC1_Y = 11;
        private const int P2_CHGAC2_Y = 15;
        private const int P2_CHGAC3_Y = 21;
        private const int P2_CHGAC4_Y = 26;
        private const int P2_BENE_Y = 25;

        /// <summary>
        /// Initializes a new instance of the <see cref="clsLGONEWMacro" /> class.
        /// </summary>
        /// <param name="data">The macro object.</param>
        public clsLGONEWMacro(object data)
        {
            clsLGONEWDto dto = data as clsLGONEWDto;

            m_PageList = new List<clsSmilePage>();

            List<clsSmileField> Page1FieldList = new List<clsSmileField>();
            Page1FieldList.Add(new clsSmileField() { X = P1_ISSUE_X, Y = P1_ISSUE_Y, FieldName = "P1Issue", FieldValue = dto.Page1Issue });
            Page1FieldList.Add(new clsSmileField() { X = P1_EFFECTIVE_X, Y = P1_EFFECTIVE_Y, FieldName = "P1Effective", FieldValue = dto.Page1Effective });
            Page1FieldList.Add(new clsSmileField() { X = P1_CUSTOMER_X, Y = P1_CUSTOMER_Y, FieldName = "P1Customer", FieldValue = dto.Page1Customer });
            Page1FieldList.Add(new clsSmileField() { X = P1_CCY_X, Y = P1_CCY_Y, FieldName = "P1CCY", FieldValue = dto.Page1Ccy });
            Page1FieldList.Add(new clsSmileField() { X = P1_GL1_X, Y = P1_GL1_Y, FieldName = "P1LG1", FieldValue = dto.Page1GL1 });
            Page1FieldList.Add(new clsSmileField() { X = P1_GL2_X, Y = P1_GL2_Y, FieldName = "P1LG2", FieldValue = dto.Page1GL2 });
            Page1FieldList.Add(new clsSmileField() { X = P1_TRANS1_X, Y = P1_TRANS1_Y, FieldName = "P1Trans1", FieldValue = dto.Page1Trans1 });
            Page1FieldList.Add(new clsSmileField() { X = P1_TRANS2_X, Y = P1_TRANS2_Y, FieldName = "P1Trans2", FieldValue = dto.Page1Trans2 });

            List<clsSmileField> Page2FieldList = new List<clsSmileField>();
            Page2FieldList.Add(new clsSmileField() { X = P2_TRANS_X, Y = P2_TRANS_Y, FieldName = "P2Trans", FieldValue = dto.Page2Trans, IsSpecialField = true });
            Page2FieldList.Add(new clsSmileField() { X = P2_EXP_X, Y = P2_EXP_Y, FieldName = "P2Expiry", FieldValue = dto.Page2Exp });
            Page2FieldList.Add(new clsSmileField() { X = P2_GARTYPE_X, Y = P2_GARTYPE_Y, FieldName = "P2GuaranteeType", FieldValue = dto.Page2GuaranteeType });
            Page2FieldList.Add(new clsSmileField() { X = P2_FEERATE_X, Y = P2_FEERATE_Y, FieldName = "P2FeeRate", FieldValue = dto.Page2FeeRate, IsSpecialField = true });
            Page2FieldList.Add(new clsSmileField() { X = 11, Y = 33, FieldName = "col", FieldValue = "1" });
            Page2FieldList.Add(new clsSmileField() { X = P2_ADJ_X, Y = P2_ADJ_Y, FieldName = "P2adj", FieldValue = dto.Page2Adj });
            if (!dto.Page2Minimum.Equals(String.Empty))
            {
                Page2FieldList.Add(new clsSmileField() { X = P2_MINIMUM_X, Y = P2_MINIMUM_Y, FieldName = "P2Minimum", FieldValue = dto.Page2Minimum });
            }
            Page2FieldList.Add(new clsSmileField() { X = P2_CHGAC1_X, Y = P2_CHGAC1_Y, FieldName = "P2CHGAC1", FieldValue = dto.Page2CHGAC1 });
            Page2FieldList.Add(new clsSmileField() { X = P2_CHGAC2_X, Y = P2_CHGAC2_Y, FieldName = "P2CHGAC2", FieldValue = dto.Page2CHGAC2 });
            Page2FieldList.Add(new clsSmileField() { X = P2_CHGAC3_X, Y = P2_CHGAC3_Y, FieldName = "P2CHGAC3", FieldValue = dto.Page2CHGAC3 });
            Page2FieldList.Add(new clsSmileField() { X = P2_CHGAC4_X, Y = P2_CHGAC4_Y, FieldName = "P2CHGAC4", FieldValue = dto.Page2CHGAC4 });
            Page2FieldList.Add(new clsSmileField() { X = P2_BENE_X, Y = P2_BENE_Y, FieldName = "P2bene", FieldValue = dto.Page2Bene });

            clsSmilePage Page1 = new clsSmilePage();
            Page1.ScreenId = new clsSmileField { X = 1, Y = 72, FieldName = "ScreenId", FieldValue = "(LGONEW)" };
            Page1.IdentifyField = new clsSmileField { X = 7, Y = 18, FieldName = "G/L", FieldValue = "000 - 0000" };
            Page1.IsLastPage = false;
            Page1.FieldList = Page1FieldList;

            clsSmilePage Page2 = new clsSmilePage();
            Page2.ScreenId = new clsSmileField { X = 1, Y = 72, FieldName = "ScreenId", FieldValue = "(LGONEW)" };
            Page2.IdentifyField = new clsSmileField { X = 9, Y = 5, FieldName = "Expiry", FieldValue = "Expiry" };
            Page2.IsLastPage = true;
            Page2.FieldList = Page2FieldList;

            m_PageList.Add(Page1);
            m_PageList.Add(Page2);
        }

        /// <summary>
        /// Transfers to Smile.
        /// </summary>
        /// <param name="session">The session to identify the emulator window.</param>
        /// <returns></returns>
        public string TransferToSmile(string session)
        {
            return WritePages(session, m_PageList);
        }
    }
}