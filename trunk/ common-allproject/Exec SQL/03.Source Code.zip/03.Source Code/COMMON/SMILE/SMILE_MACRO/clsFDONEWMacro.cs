﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-05-10 2:00:19 +0700 (Fri, 10 May 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This class is used to define fields information and Smile operation
 * for DPDProcessingTD screen.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Obj;

namespace Phoenix.Common.Smile.Macro
{
    public class clsFDONEWMacro : clsSmileBaseMacro
    {
        // Coordinates of each field in page 1
        private const int P1_APPLICANT_X = 6;
        private const int P1_CCY_X = 7;
        private const int P1_GL1_X = 7;
        private const int P1_GL2_X = 7;
        private const int P1_TDNO1_X = 11;
        private const int P1_TDNO2_X = 7;
        private const int P1_APPLICANT_Y = 23;
        private const int P1_CCY_Y = 7;
        private const int P1_GL1_Y = 21;
        private const int P1_GL2_Y = 27;
        private const int P1_TDNO1_Y = 53;
        private const int P1_TDNO2_Y = 62;

        // Coordinates of each field in page 2
        private const int P2_AMOUNT_X = 8;
        private const int P2_MATURITY_X = 11;
        private const int P2_INTMETHOD_X = 11;
        private const int P2_YEARDAYS_X = 13;
        private const int P2_IR_X = 11;
        private const int P2_IS_X = 12;
        private const int P2_DUENOTIFY_X = 13;
        private const int P2_BRC_X = 13;
        private const int P2_PROCEEDAC1_X = 17;
        private const int P2_PROCEEDAC2_X = 17;
        private const int P2_PROCEEDAC3_X = 17;
        private const int P2_NOWH_X = 18;
        private const int P2_MATURITYAC1_X = 20;
        private const int P2_MATURITYAC2_X = 20;
        private const int P2_MATURITYAC3_X = 20;
        private const int P2_INTERESTAC1_X = 21;
        private const int P2_INTERESTAC2_X = 21;
        private const int P2_INTERESTAC3_X = 21;
        private const int P2_AMOUNT_Y = 60;
        private const int P2_MATURITY_Y = 13;
        private const int P2_INTMETHOD_Y = 38;
        private const int P2_YEARDAYS_Y = 74;
        private const int P2_IR_Y = 68;
        private const int P2_IS_Y = 68;
        private const int P2_DUENOTIFY_Y = 15;
        private const int P2_BRC_Y = 74;
        private const int P2_PROCEEDAC1_Y = 23;
        private const int P2_PROCEEDAC2_Y = 29;
        private const int P2_PROCEEDAC3_Y = 34;
        private const int P2_NOWH_Y = 41;
        private const int P2_MATURITYAC1_Y = 23;
        private const int P2_MATURITYAC2_Y = 29;
        private const int P2_MATURITYAC3_Y = 34;
        private const int P2_INTERESTAC1_Y = 23;
        private const int P2_INTERESTAC2_Y = 29;
        private const int P2_INTERESTAC3_Y = 34;

        public clsFDONEWMacro(object data)
        {
            clsFDONEWDto dto = data as clsFDONEWDto;
            m_PageList = new List<clsSmilePage>();
            List<clsSmileField> FieldList = new List<clsSmileField>();

            // Debit section
            FieldList.Add(new clsSmileField() { X = P1_APPLICANT_X, Y = P1_APPLICANT_Y, FieldName = "Applicant", FieldValue = dto.Applicant });
            FieldList.Add(new clsSmileField() { X = P1_CCY_X, Y = P1_CCY_Y, FieldName = "Ccy", FieldValue = dto.Ccy });
            FieldList.Add(new clsSmileField() { X = P1_GL1_X, Y = P1_GL1_Y, FieldName = "GLCode1", FieldValue = dto.GLCode1 });
            FieldList.Add(new clsSmileField() { X = P1_GL2_X, Y = P1_GL2_Y, FieldName = "GLCode2", FieldValue = dto.GLCode2 });
            FieldList.Add(new clsSmileField() { X = P1_TDNO1_X, Y = P1_TDNO1_Y, FieldName = "TDNo1", FieldValue = dto.TDNo1 });
            FieldList.Add(new clsSmileField() { X = P1_TDNO2_X, Y = P1_TDNO2_Y, FieldName = "TDNo1", FieldValue = dto.TDNo2 });
            FieldList.Add(new clsSmileField() { X = P2_AMOUNT_X, Y = P2_AMOUNT_Y, FieldName = "Amount", FieldValue = dto.Amount });
            FieldList.Add(new clsSmileField() { X = P2_MATURITY_X, Y = P2_MATURITY_Y, FieldName = "MaturityDate", FieldValue = dto.Maturity });
            FieldList.Add(new clsSmileField() { X = P2_INTMETHOD_X, Y = P2_INTMETHOD_Y, FieldName = "IntMethod", FieldValue = dto.IntMethod });
            FieldList.Add(new clsSmileField() { X = P2_YEARDAYS_X, Y = P2_YEARDAYS_Y, FieldName = "YearDays", FieldValue = dto.YearDays });
            FieldList.Add(new clsSmileField() { X = P2_IR_X, Y = P2_IR_Y, FieldName = "IR", FieldValue = dto.IR });
            FieldList.Add(new clsSmileField() { X = P2_IS_X, Y = P2_IS_Y, FieldName = "IS", FieldValue = dto.IS });
            FieldList.Add(new clsSmileField() { X = P2_DUENOTIFY_X, Y = P2_DUENOTIFY_Y, FieldName = "DueNotify", FieldValue = dto.DueNotify });
            FieldList.Add(new clsSmileField() { X = P2_BRC_X, Y = P2_BRC_Y, FieldName = "BaseRateCode", FieldValue = dto.BRC });
            FieldList.Add(new clsSmileField() { X = P2_PROCEEDAC1_X, Y = P2_PROCEEDAC1_Y, FieldName = "ProceedAC1", FieldValue = dto.ProceedAC1 });
            FieldList.Add(new clsSmileField() { X = P2_PROCEEDAC2_X, Y = P2_PROCEEDAC2_Y, FieldName = "ProceedAC2", FieldValue = dto.ProceedAC2 });
            FieldList.Add(new clsSmileField() { X = P2_PROCEEDAC3_X, Y = P2_PROCEEDAC3_Y, FieldName = "ProceedAC3", FieldValue = dto.ProceedAC3 });
            FieldList.Add(new clsSmileField() { X = P2_NOWH_X, Y = P2_NOWH_Y, FieldName = "NoWH", FieldValue = dto.NOWH });
            FieldList.Add(new clsSmileField() { X = P2_MATURITYAC1_X, Y = P2_MATURITYAC1_Y, FieldName = "MaturityAC1", FieldValue = dto.MaturityAC1 });
            FieldList.Add(new clsSmileField() { X = P2_MATURITYAC2_X, Y = P2_MATURITYAC2_Y, FieldName = "MaturityAC2", FieldValue = dto.MaturityAC2 });
            FieldList.Add(new clsSmileField() { X = P2_MATURITYAC3_X, Y = P2_MATURITYAC3_Y, FieldName = "MaturityAC3", FieldValue = dto.MaturityAC3 });
            FieldList.Add(new clsSmileField() { X = P2_INTERESTAC1_Y, Y = P2_INTERESTAC1_Y, FieldName = "InterestAC1", FieldValue = dto.InterestAC1 });
            FieldList.Add(new clsSmileField() { X = P2_INTERESTAC2_Y, Y = P2_INTERESTAC2_Y, FieldName = "InterestAC2", FieldValue = dto.InterestAC2 });
            FieldList.Add(new clsSmileField() { X = P2_INTERESTAC3_Y, Y = P2_INTERESTAC3_Y, FieldName = "InterestAC3", FieldValue = dto.InterestAC3 });

            clsSmilePage Page = new clsSmilePage();
            Page.ScreenId = new clsSmileField { X = 1, Y = 73, FieldName = "ScreenId", FieldValue = "(FDONEW)" };
            Page.IdentifyField = new clsSmileField { X = 5, Y = 10, FieldName = "G/L", FieldValue = "000 - 0000" };
            Page.IsLastPage = true;
            Page.FieldList = FieldList;

            m_PageList.Add(Page);
        }

        /// <summary>
        /// Transfers data to Smile.
        /// </summary>
        /// <param name="session">The session to identify the emulator window.</param>
        /// <returns></returns>
        public string TransferToSmile(string session)
        {
            return WritePages(session, m_PageList);
        }
    }
}