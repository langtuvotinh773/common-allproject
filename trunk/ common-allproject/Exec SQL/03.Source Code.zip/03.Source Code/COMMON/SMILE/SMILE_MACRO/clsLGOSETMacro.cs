﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This class is used to define fields information and Smile operation
 * for LGTerminal.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Obj;

namespace Phoenix.Common.Smile.Macro
{
    public class clsLGOSETMacro : clsSmileBaseMacro
    {
        // Coordinates of each field in page 1
        private const int VALUE_X = 4;
        private const int CUSTOMER_X = 6;
        private const int CCY_X = 7;
        private const int GL1_X = 7;
        private const int GL2_X = 7;
        private const int TRANS1_X = 7;
        private const int TRANS2_X = 7;
        
        private const int VALUE_Y = 19;
        private const int CUSTOMER_Y = 14;
        private const int CCY_Y = 9;
        private const int GL1_Y = 18;
        private const int GL2_Y = 24;
        private const int TRANS1_Y = 42;
        private const int TRANS2_Y = 51;

        /// <summary>
        /// Initializes a new instance of the <see cref="clsLGOSETMacro" /> class.
        /// </summary>
        /// <param name="data">The macro object.</param>
        public clsLGOSETMacro(object data)
        {
            clsLGOSETDto dto = data as clsLGOSETDto;

            m_PageList = new List<clsSmilePage>();

            List<clsSmileField> FieldList = new List<clsSmileField>();
            //FieldList.Add(new clsSmileField() { X = VALUE_X, Y = VALUE_Y, FieldName = "Value", FieldValue = dto.Value });
            FieldList.Add(new clsSmileField() { X = CUSTOMER_X, Y = CUSTOMER_Y, FieldName = "Customer", FieldValue = dto.Customer });
            FieldList.Add(new clsSmileField() { X = CCY_X, Y = CCY_Y, FieldName = "CCY", FieldValue = dto.Ccy });
            FieldList.Add(new clsSmileField() { X = GL1_X, Y = GL1_Y, FieldName = "LG1", FieldValue = dto.GL1 });
            FieldList.Add(new clsSmileField() { X = GL2_X, Y = GL2_Y, FieldName = "LG2", FieldValue = dto.GL2 });
            FieldList.Add(new clsSmileField() { X = TRANS1_X, Y = TRANS1_Y, FieldName = "Trans1", FieldValue = dto.Trans1 });
            FieldList.Add(new clsSmileField() { X = TRANS2_X, Y = TRANS2_Y, FieldName = "Trans2", FieldValue = dto.Trans2 });

            clsSmilePage Page = new clsSmilePage();
            Page.ScreenId = new clsSmileField { X = 1, Y = 71, FieldName = "ScreenId", FieldValue = "(LGOSET)" };
            Page.IdentifyField = new clsSmileField { X = 7, Y = 18, FieldName = "G/L", FieldValue = "000 - 0000" };
            Page.IsLastPage = true;
            Page.FieldList = FieldList;

            m_PageList.Add(Page);
        }

        /// <summary>
        /// Transfers to smile.
        /// </summary>
        /// <param name="session">The session to identify the emulator window.</param>
        /// <returns></returns>
        public string TransferToSmile(string session)
        {
            return WritePages(session, m_PageList);
        }
    }
}