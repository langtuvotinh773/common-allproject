﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-05-10 2:00:19 +0700 (Fri, 10 May 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This class is used to define fields information and Smile operation
 * for DPDProcessingTD screen.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Smile.Macro
{
    public class clsFDOSETMacro : clsSmileBaseMacro
    {
        public clsFDOSETMacro(object data)
        {
        }

        /// <summary>
        /// Transfers data to Smile.
        /// </summary>
        /// <param name="session">The session to identify emulator window.</param>
        /// <returns></returns>
        public string TransferToSmile(string session)
        {
            return WritePages(session, m_PageList);
        }
    }
}
