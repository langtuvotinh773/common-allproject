﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This base class is used to provide function to write data into Smile.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

using Phoenix.Common.Smile.Com;

namespace Phoenix.Common.Smile.Macro
{
    public class clsSmileBaseMacro
    {
        protected List<clsSmilePage> m_PageList = null;
        private clsSmileErrorMsg m_ErrorMsg = null;

        /// <summary>
        /// Writes the pages.
        /// </summary>
        /// <param name="session">The session to identify the emulator window.</param>
        /// <param name="PageList">The list of each page of one Smile screen.</param>
        /// <returns></returns>
        protected string WritePages(string session, List<clsSmilePage> PageList)
        {
            StringBuilder errorBuilder = new StringBuilder();
            m_ErrorMsg = new clsSmileErrorMsg();

            int iConnect = (int)clsSmileWrapper.Connect(session);
            if (iConnect == 0)
            {
                foreach (clsSmilePage page in PageList)
                {
                    string strError = page.WriteFieldToSmile(session);
                    if (!strError.Equals(""))
                    {
                        errorBuilder.Append(strError + "\r\n");
                        errorBuilder.Append(clsSmileCommon.DisconnectFromPS(session));
                        break;
                    }
                    if (!page.IsLastPage)
                    {
                        int iFieldEnter = (int)clsSmileWrapper.SendFieldEnter();
                        if (iFieldEnter != 0)
                        {
                            m_ErrorMsg.SENDKEY_ERROR.TryGetValue(iFieldEnter, out strError);
                            errorBuilder.Append(strError + "\r\n");
                            //errorBuilder.Append(clsSmileCommon.DisconnectFromPS(session));
                            break;
                        }
                        Thread.Sleep(500);
                    }
                }
                errorBuilder.Append(clsSmileCommon.DisconnectFromPS(session));
            }
            else
            {
                string error;
                m_ErrorMsg.CONNECTION_ERROR.TryGetValue(iConnect, out error);
                errorBuilder.Append(error);
            }
            return errorBuilder.ToString();
        }
    }
}