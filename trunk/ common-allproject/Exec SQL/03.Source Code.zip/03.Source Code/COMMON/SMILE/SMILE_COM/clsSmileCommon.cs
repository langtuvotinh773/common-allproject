﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:00:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This class is used to provide common function when 
 * interface with Smile.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Windows.Forms;

using Config.Classes;
using Phoenix.Common.Smile.Obj;
using Phoenix.Common.Smile.Gui;
using Phoenix.Common.Popup;
using DataEncryption;

namespace Phoenix.Common.Smile.Com
{
    public class clsSmileCommon
    {
        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [DllImport("user32.dll")]
        private static extern int DestroyWindow(IntPtr handle);

        private const int SW_MAXIMIZE = 3;
        private const int WM_SYSCOMMAND = 0x0112;
        private const int SC_CLOSE = 0xF060;
        public static bool IS_IMPORTED_TO_SMILE = false;
        private static string connStr = null;

        private static frmAllSmileViewLog m_frmLog = null;

        /// <summary>
        /// Activates the Smile window.
        /// </summary>
        /// <param name="session">The session to identify the emulator window.</param>
        public static void ActivateSmileWindow(string session)
        {
            Process[] processesByName = Process.GetProcessesByName("pcsws");
            foreach (Process p in processesByName)
            {
                if (p.MainWindowTitle.Contains("Session " + session))
                {
                    IntPtr pointer = p.MainWindowHandle;
                    SetForegroundWindow(pointer);
                    ShowWindow(pointer, SW_MAXIMIZE);
                }
            }
        }

        public static void OpenViewLogForm(object mdiParent, string transNo, Module module)
        {
            //Process[] processesByName = Process.GetProcessesByName("REVOLUTION");
            //foreach (Process p in processesByName)
            //{
            //    if (p.MainWindowTitle.Contains("Smile Operation Log"))
            //    {
            //        IntPtr handle = p.MainWindowHandle;
            //        DestroyWindow(handle);
            //    }
            //}
            if (m_frmLog == null || m_frmLog.IsDisposed)
            {
                m_frmLog = new frmAllSmileViewLog(transNo, module);
                m_frmLog.MdiParent = (Form)mdiParent;
                m_frmLog.StartPosition = FormStartPosition.CenterScreen;
                m_frmLog.Show();
            }
            else
            {
                m_frmLog.GetSearchCondition(transNo, module);
                m_frmLog.Visible = true;
                m_frmLog.Activate();
            }
        }

        /// <summary>
        /// Shows the error when connecting failed.
        /// </summary>
        public static void ShowErrorWhenConnectingFailed()
        {
            clsFunction.ShowErrorDialog("Can not connect to SMILE. Please try again!");
        }

        /// <summary>
        /// Shows the error when not correct screen.
        /// </summary>
        public static void ShowErrorWhenNotCorrectScreen()
        {
            clsFunction.ShowErrorDialog("The current screen is not correct. Please try again!");
        }

        /// <summary>
        /// Converts to Smile date.
        /// </summary>
        /// <param name="dt">The datetime to convert.</param>
        /// <returns></returns>
        public static string ConvertToSmileDate(DateTime dt)
        {
            return dt.ToString("yyMMdd");
        }

        /// <summary>
        /// Disconnects from PS.
        /// </summary>
        /// <param name="session">The session to identify the emulator window.</param>
        /// <returns></returns>
        public static string DisconnectFromPS(string session)
        {
            int iDisconnect = (int)clsSmileWrapper.Disconnect(session);
            if (iDisconnect != 0)
            {
                string error;
                new clsSmileErrorMsg().DISCONNECTION_ERROR.TryGetValue(iDisconnect, out error);

                return error;
            }
            return String.Empty;
        }

        /// <summary>
        /// Saves the log.
        /// </summary>
        /// <param name="dto">The dto.</param>
        public static void SaveLog(clsErrorLogDto dto)
        {
            if (dto == null) return;
            if (connStr == null)
            {
                connStr = System.Configuration.ConfigurationSettings.AppSettings["LGConnectionString"].ToString();
            }
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                }
                catch (SqlException)
                {
                    return;
                }
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "dbo.spCOM_InsertSmileErrorLog";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("@transNo", dto.TransNo));
                    cmd.Parameters.Add(new SqlParameter("@module", dto.Module));
                    cmd.Parameters.Add(new SqlParameter("@importTime", dto.ImportTime.ToString("MM/dd/yyyy hh:mm:ss tt")));
                    string type = null;
                    switch (dto.ImportType)
                    {
                        case Phoenix.Common.Smile.Gui.ImportType.LGIssue:
                            type = "New LG";
                            break;
                        case Phoenix.Common.Smile.Gui.ImportType.LGAmend:
                            type = "Amend LG";
                            break;
                        case Phoenix.Common.Smile.Gui.ImportType.LGTerminate:
                            type = "Terminate";
                            break;
                        case Phoenix.Common.Smile.Gui.ImportType.GeneralTransfer:
                            type = "General Transfer";
                            break;
                        default:
                            break;
                    }
                    cmd.Parameters.Add(new SqlParameter("@importType", type));
                    cmd.Parameters.Add(new SqlParameter("@importBy", dto.ImportBy));
                    cmd.Parameters.Add(new SqlParameter("@result", dto.Result));
                    cmd.Parameters.Add(new SqlParameter("@errorMsg", dto.ErrorMsg));
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (SqlException)
                    {
                    }
                }
            }
        }

        /// <summary>
        /// Searches the Smile operation log.
        /// </summary>
        /// <param name="dto">The error log object.</param>
        /// <returns></returns>
        public static List<clsErrorLogDto> SearchLog(clsErrorLogDto dto)
        {
            if (dto == null) return null;
            List<clsErrorLogDto> list = new List<clsErrorLogDto>();
            if (connStr == null)
            {
                connStr = Encryption.decrypt( System.Configuration.ConfigurationSettings.AppSettings["LGConnectionString"].ToString());
            }
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                }
                catch (SqlException)
                {
                    return list;
                }
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "dbo.spCOM_SearchSmileErrorLog";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Clear();
                    if (dto.TransNo.Length == 0)
                        cmd.Parameters.Add(new SqlParameter("@transNo", DBNull.Value));
                    else
                        cmd.Parameters.Add(new SqlParameter("@transNo", dto.TransNo));
                    cmd.Parameters.Add(new SqlParameter("@module", dto.Module));
                    if (dto.From.Length == 0)
                        cmd.Parameters.Add(new SqlParameter("@from", DBNull.Value));
                    else
                        cmd.Parameters.Add(new SqlParameter("@from", dto.From));
                    if (dto.To.Length == 0)
                        cmd.Parameters.Add(new SqlParameter("@to", DBNull.Value));
                    else
                        cmd.Parameters.Add(new SqlParameter("@to", dto.To));
                    try
                    {
                        SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                        while (reader.Read())
                        {
                            clsErrorLogDto item = new clsErrorLogDto();
                            item.TransNo = reader.GetString(0);
                            item.Module = reader.GetString(1);
                            item.ImportTime = reader.GetDateTime(2);
                            item.ImportBy = reader.GetString(3);
                            item.ImportTypeText = reader.GetString(4);
                            //string ImportType = reader.GetString(4);
                            //if (ImportType.Equals("New LG"))
                            //    item.ImportType = Phoenix.Common.Smile.Gui.ImportType.LGIssue;
                            //else if (ImportType.Equals("Amend LG"))
                            //    item.ImportType = Phoenix.Common.Smile.Gui.ImportType.LGAmend;
                            //else if (ImportType.Equals("General Transfer"))
                            //    item.ImportType = Phoenix.Common.Smile.Gui.ImportType.GeneralTransfer;
                            //else
                            //    item.ImportType = Phoenix.Common.Smile.Gui.ImportType.LGTerminate;
                            if (reader.GetBoolean(5))
                                item.Status = "Successful";
                            else
                                item.Status = "Fail";
                            item.ErrorMsg = reader.GetString(6);
                            list.Add(item);
                        }
                        reader.Close();
                    }
                    catch (SqlException)
                    {
                    }
                }
            }
            return list;
        }

        /// <summary>
        /// Deletes the LG import fail.
        /// </summary>
        /// <param name="LgCode">The lg code.</param>
        public static void DeleteLGImportFail(string LgCode)
        {
            if (connStr == null)
            {
                connStr = System.Configuration.ConfigurationSettings.AppSettings["LGConnectionString"].ToString();
            }
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                }
                catch (SqlException)
                {
                    return;
                }
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "dbo.spLG_DeleteTerminateImportSmileFail";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@lgCode", LgCode));
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (SqlException)
                    {
                    }
                }
            }
        }

        /// <summary>
        /// Updates the LG smile status.
        /// </summary>
        /// <param name="LgCode">The lg code.</param>
        /// <param name="subCode">The sub code.</param>
        /// <param name="numNew">The num new.</param>
        /// <param name="resultNew">The result new.</param>
        /// <param name="numGenera">The num genera.</param>
        /// <param name="resultGenera">The result genera.</param>
        /// <param name="numTerminate">The num terminate.</param>
        /// <param name="resultTerminate">The result terminate.</param>
        public static void UpdateLGSmileStatus(string LgCode ,string subCode, object numNew,object resultNew,object numGenera,object resultGenera,object numTerminate,object resultTerminate)
        {
            if (connStr == null)
            {
                connStr = Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["LGConnectionString"].ToString());
            }
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                }
                catch (SqlException)
                {
                    return;
                }
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "dbo.spLG_UpdateSmileStatus";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@lgCode", LgCode));
                    cmd.Parameters.Add(new SqlParameter("@subCode", subCode));
                    cmd.Parameters.Add(new SqlParameter("@numNew", numNew));
                    cmd.Parameters.Add(new SqlParameter("@resultNew", resultNew));
                    cmd.Parameters.Add(new SqlParameter("@numGenera", numGenera));
                    cmd.Parameters.Add(new SqlParameter("@resultGenera", resultGenera));
                    cmd.Parameters.Add(new SqlParameter("@numTerminate", numTerminate));
                    cmd.Parameters.Add(new SqlParameter("@resultTerminate", resultTerminate));
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (SqlException)
                    {
                    }
                }
            }
        }

        /// <summary>
        /// Shows the message.
        /// </summary>
        /// <param name="type">The type of message.</param>
        /// <param name="msg">The messsage.</param>
        /// <returns></returns>
        public static DialogResult ShowMessage(int type, string msg)
        {
            frmPhoenixMessage frmMsg = new frmPhoenixMessage(type, msg);
            return frmMsg.ShowDialog();
        }
    }
}