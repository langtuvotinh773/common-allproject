﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This class is used to validate and write data into Smile.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Phoenix.Common.Smile.Com  
{
    public class clsSmilePage
    {
        public clsSmileField ScreenId { get; set; }
        public clsSmileField IdentifyField { get; set; }
        public List<clsSmileField> FieldList { get; set; }
        public bool IsLastPage { get; set; }

        private string m_Session = null;
        private StringBuilder m_ErrorBuilder = null;
        private clsSmileErrorMsg m_ErrorMsg = null;

        private const string INCORRECT_SCREENID_ERROR = "The screen id is incorrect.";

        /// <summary>
        /// Initializes a new instance of the <see cref="clsSmilePage" /> class.
        /// </summary>
        public clsSmilePage()
        {
            m_ErrorBuilder = new StringBuilder();
            m_ErrorMsg = new clsSmileErrorMsg();
        }

        /// <summary>
        /// Writes the field to smile.
        /// </summary>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public string WriteFieldToSmile(string session)
        {
            m_Session = session;
            string strError;
            if (!IsExistingField(ScreenId, out strError)) return strError;
            if (!IsExistingField(IdentifyField, out strError)) return strError;
            //if (!IsCorrectPage(out strError)) return strError;
            
            foreach (clsSmileField f in FieldList)
            {
                // Copy each field to screen 
                int iCopyField = (int)clsSmileWrapper.CopyFieldToScreen(f.X, f.Y, f.FieldValue, f.FieldValue.Length);
                if (IsActionFailed(iCopyField, m_ErrorMsg.COPYSTRTOFIELD_ERROR, strError)) break;
                
                // Send key Exit if it meet a special field
                if (f.IsSpecialField)
                {
                    int iSetCursor = (int)clsSmileWrapper.SetCursorPos(f.X, f.Y + f.FieldValue.Length);
                    if (IsActionFailed(iSetCursor, m_ErrorMsg.SETCURSOR_ERROR, strError)) break;
                    
                    int iFieldExit = (int)clsSmileWrapper.SendFieldExit();
                    if (IsActionFailed(iFieldExit, m_ErrorMsg.SENDKEY_ERROR, strError)) break;
                }

                Thread.Sleep(50);
            }
            return strError;
        }

        //private bool IsMatchedScreenId(out string strError)
        //{
        //    return IsExistingField(ScreenId, out strError);
        //}

        //private bool IsCorrectPage(out string strError)
        //{
        //    return IsExistingField(IdentifyField, out strError);
        //}

        /// <summary>
        /// Determines whether [is existing field] [the specified field].
        /// </summary>
        /// <param name="field">The field.</param>
        /// <param name="strError">The STR error.</param>
        /// <returns>
        ///   <c>true</c> if [is existing field] [the specified field]; otherwise, <c>false</c>.
        /// </returns>
        private bool IsExistingField(clsSmileField field, out string strError)
        {
            string strFieldValue = String.Empty;
            bool bResult = false;
            int iRead = (int)clsSmileWrapper.ReadScreen(field.X, field.Y, field.FieldValue.Length, ref strFieldValue);
            strError = String.Empty;
            if (iRead == 0)
            {
                if (strFieldValue.Equals(field.FieldValue))
                    bResult = true;
                else
                    strError = INCORRECT_SCREENID_ERROR;
            }
            else
            {
                string readErrorStr;
                new clsSmileErrorMsg().READSCREEN_ERROR.TryGetValue(iRead, out readErrorStr);
                m_ErrorBuilder.Append(readErrorStr + "\r\n");
                m_ErrorBuilder.Append(clsSmileCommon.DisconnectFromPS(m_Session));

                strError = m_ErrorBuilder.ToString();
            }
            return bResult;
        }

        /// <summary>
        /// Determines whether [is action failed] [the specified i action].
        /// </summary>
        /// <param name="iAction">The i action.</param>
        /// <param name="errorDic">The error dic.</param>
        /// <param name="strError">The STR error.</param>
        /// <returns>
        ///   <c>true</c> if [is action failed] [the specified i action]; otherwise, <c>false</c>.
        /// </returns>
        private bool IsActionFailed(int iAction, Dictionary<int, string> errorDic, string strError)
        {
            if (iAction != 0)
            {
                string readErrorStr;
                errorDic.TryGetValue(iAction, out readErrorStr);
                m_ErrorBuilder.Append(readErrorStr + "\r\n");
                m_ErrorBuilder.Append(clsSmileCommon.DisconnectFromPS(m_Session));
                strError = m_ErrorBuilder.ToString();

                return true;
            }
            return false;
        }
    }
}