﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This class is used to provide common error that occurs
 * when interface with Smile.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Smile.Com
{
    public class clsSmileErrorMsg
    {
        // Define connection error code with contents
        public Dictionary<int, string> CONNECTION_ERROR = new Dictionary<int, string>();
        private readonly string CONNECT_ERROR_CASE_1 = "An incorrect host presentation space ID was specified. The specified session either does not exist or is a logical printer session. This return code could also mean that the API Setting for DDE/EHLLAPI is not set on.";
        private readonly string CONNECT_ERROR_CASE_4 = "Successful connection was achieved, but the session is busy.";
        private readonly string CONNECT_ERROR_CASE_5 = "Successful connection was achieved, but the session is locked (input-inhibited).";
        private readonly string CONNECT_ERROR_CASE_9 = "A system error occurred.";
        private readonly string CONNECT_ERROR_CASE_11 = "The session is already being used by another system function.";

        // Define disconnection error code with contents
        public Dictionary<int, string> DISCONNECTION_ERROR = new Dictionary<int, string>();
        private readonly string DISCONNECT_ERROR_CASE_1 = "Your program is not currently connected to the host presentation space.";
        private readonly string DISCONNECT_ERROR_CASE_9 = "A system error occurred.";

        // Define copying str to field error code with contents
        public Dictionary<int, string> COPYSTRTOFIELD_ERROR = new Dictionary<int, string>();
        private readonly string COPYSTRTOFIELD_ERROR_CASE_1 = "Your program is not connected to a host session.";
        private readonly string COPYSTRTOFIELD_ERROR_CASE_2 = "Parameter error or zero length for copy.";
        private readonly string COPYSTRTOFIELD_ERROR_CASE_5 = "The target field was protected or inhibited, or incorrect data was sent to the target field (such as a field attribute).";
        private readonly string COPYSTRTOFIELD_ERROR_CASE_6 = "Copy was completed, but data is truncated.";
        private readonly string COPYSTRTOFIELD_ERROR_CASE_7 = "The host presentation space position is not valid.";
        private readonly string COPYSTRTOFIELD_ERROR_CASE_9 = "A system error was encountered.";
        private readonly string COPYSTRTOFIELD_ERROR_CASE_24 = "Unformatted host presentation space.";

        // Define setting cursor pos error code with contents
        public Dictionary<int, string> READSCREEN_ERROR = new Dictionary<int, string>();
        private readonly string READSCREEN_ERROR_CASE_1 = "Your program is not connected to a host session.";
        private readonly string READSCREEN_ERROR_CASE_2 = "An error was made in specifying string length, or the sum of (Length − 1) + PS position is greater than the size of the connected host presentation space.";
        private readonly string READSCREEN_ERROR_CASE_4 = "The host presentation space contents were copied. The host presentation space was waiting for host response.";
        private readonly string READSCREEN_ERROR_CASE_5 = "The host presentation space was copied. The keyboard was locked.";
        private readonly string READSCREEN_ERROR_CASE_7 = "The host presentation space position is not valid.";
        private readonly string READSCREEN_ERROR_CASE_9 = "A system error was encountered.";

        // Define setting cursor pos error code with contents
        public Dictionary<int, string> SETCURSOR_ERROR = new Dictionary<int, string>();
        private readonly string SETCURSOR_ERROR_CASE_1 = "Your program is not connected to a host session.";
        private readonly string SETCURSOR_ERROR_CASE_4 = "The session is busy.";
        private readonly string SETCURSOR_ERROR_CASE_7 = "A cursor location less than 1 or greater than the size of the connected host presentation space was specified.";
        private readonly string SETCURSOR_ERROR_CASE_9 = "A system error occurred.";

        // Define setting cursor pos error code with contents
        public Dictionary<int, string> SENDKEY_ERROR = new Dictionary<int, string>();
        private readonly string SENDKEY_ERROR_CASE_1 = "Your program is not connected to a host session.";
        private readonly string SENDKEY_ERROR_CASE_2 = "An incorrect parameter was passed to EHLLAPI.";
        private readonly string SENDKEY_ERROR_CASE_4 = "The host session was busy; all of the keystrokes could not be sent.";

        public clsSmileErrorMsg()
        {
            CONNECTION_ERROR.Add(1, CONNECT_ERROR_CASE_1);
            CONNECTION_ERROR.Add(4, CONNECT_ERROR_CASE_4);
            CONNECTION_ERROR.Add(5, CONNECT_ERROR_CASE_5);
            CONNECTION_ERROR.Add(9, CONNECT_ERROR_CASE_9);
            CONNECTION_ERROR.Add(11, CONNECT_ERROR_CASE_11);

            DISCONNECTION_ERROR.Add(1, DISCONNECT_ERROR_CASE_1);
            DISCONNECTION_ERROR.Add(9, DISCONNECT_ERROR_CASE_9);

            COPYSTRTOFIELD_ERROR.Add(1, COPYSTRTOFIELD_ERROR_CASE_1);
            COPYSTRTOFIELD_ERROR.Add(2, COPYSTRTOFIELD_ERROR_CASE_2);
            COPYSTRTOFIELD_ERROR.Add(5, COPYSTRTOFIELD_ERROR_CASE_5);
            COPYSTRTOFIELD_ERROR.Add(6, COPYSTRTOFIELD_ERROR_CASE_6);
            COPYSTRTOFIELD_ERROR.Add(7, COPYSTRTOFIELD_ERROR_CASE_7);
            COPYSTRTOFIELD_ERROR.Add(9, COPYSTRTOFIELD_ERROR_CASE_9);
            COPYSTRTOFIELD_ERROR.Add(24, COPYSTRTOFIELD_ERROR_CASE_24);

            READSCREEN_ERROR.Add(1, READSCREEN_ERROR_CASE_1);
            READSCREEN_ERROR.Add(2, READSCREEN_ERROR_CASE_2);
            READSCREEN_ERROR.Add(4, READSCREEN_ERROR_CASE_4);
            READSCREEN_ERROR.Add(5, READSCREEN_ERROR_CASE_5);
            READSCREEN_ERROR.Add(7, READSCREEN_ERROR_CASE_7);
            READSCREEN_ERROR.Add(9, READSCREEN_ERROR_CASE_9);

            SETCURSOR_ERROR.Add(1, SETCURSOR_ERROR_CASE_1);
            SETCURSOR_ERROR.Add(4, SETCURSOR_ERROR_CASE_4);
            SETCURSOR_ERROR.Add(7, SETCURSOR_ERROR_CASE_7);
            SETCURSOR_ERROR.Add(9, SETCURSOR_ERROR_CASE_9);

            SENDKEY_ERROR.Add(1, SENDKEY_ERROR_CASE_1);
            SENDKEY_ERROR.Add(2, SENDKEY_ERROR_CASE_2);
            SENDKEY_ERROR.Add(4, SENDKEY_ERROR_CASE_4); 
        }
    }
}