﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This class is used to confirm result after importing data into Smile.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Common.Smile.Com
{
    public class clsSmileField
    {
        public int X { get; set; }
        public int Y { get; set; }
        public string FieldName { get; set; }
        public string FieldValue { get; set; }
        public bool IsSpecialField { get; set; }
    }
}