﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This class is used to provide wrapper function to work with
 * IBM emulator application via dll.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace Phoenix.Common.Smile.Com
{
    public class clsSmileWrapper
    {
        [DllImport("PCSHLL32.dll")]
        public static extern uint hllapi(out uint Func, StringBuilder Data, out uint Length, out uint retC);

        const uint HA_CONNECT_PS = 1; /* 000 Connect PS*/
        const uint HA_DISCONNECT_PS = 2; /* 000 Disconnect PS*/
        const uint HA_SENDKEY = 3; /* 000 Sendkey function*/
        const uint HA_WAIT = 4; /* 000 Wait function*/
        const uint HA_COPY_PS = 5; /* 000 Copy PS function*/
        const uint HA_SEARCH_PS = 6; /* 000 Search PS function*/
        const uint HA_QUERY_CURSOR_LOC = 7; /* 000 Query Cursor*/
        const uint HA_COPY_PS_TO_STR = 8; /* 000 Copy PS to String*/
        const uint HA_SET_SESSION_PARMS = 9; /* 000 Set Session*/
        const uint HA_QUERY_SESSIONS = 10; /* 000 Query Sessions*/
        const uint HA_RESERVE = 11; /* 000 Reserve function*/
        const uint HA_RELEASE = 12; /* 000 Release function*/
        const uint HA_COPY_OIA = 13; /* 000 Copy OIA function*/
        const uint HA_QUERY_FIELD_ATTR = 14; /* 000 Query Field*/
        const uint HA_COPY_STR_TO_PS = 15; /* 000 Copy string to PS*/
        const uint HA_STORAGE_MGR = 17; /* 000 Storage Manager*/
        const uint HA_PAUSE = 18; /* 000 Pause function*/
        const uint HA_QUERY_SYSTEM = 20; /* 000 Query System*/
        const uint HA_RESET_SYSTEM = 21; /* 000 Reset System*/
        const uint HA_QUERY_SESSION_STATUS = 22; /* 000 Query Session*/
        const uint HA_START_HOST_NOTIFY = 23; /* 000 Start Host*/
        const uint HA_QUERY_HOST_UPDATE = 24; /* 000 Query Host Update*/
        const uint HA_STOP_HOST_NOTIFY = 25; /* 000 Stop Host*/
        const uint HA_SEARCH_FIELD = 30; /* 000 Search Field*/
        const uint HA_FIND_FIELD_POS = 31; /* 000 Find Field*/
        const uint HA_FIND_FIELD_LEN = 32; /* 000 Find Field Length*/
        const uint HA_COPY_STR_TO_FIELD = 33; /* 000 Copy String to*/
        const uint HA_COPY_FIELD_TO_STR = 34; /* 000 Copy Field to*/
        const uint HA_SET_CURSOR = 40; /* 000 Set Cursor*/
        const uint HA_START_CLOSE_INTERCEPT = 41; /* 000 Start Close Intercept*/
        const uint HA_QUERY_CLOSE_INTERCEPT = 42; /* 000 Query Close Intercept*/
        const uint HA_STOP_CLOSE_INTERCEPT = 43; /* 000 Stop Close Intercept*/
        const uint HA_START_KEY_INTERCEPT = 50; /* 000 Start Keystroke*/
        const uint HA_GET_KEY = 51; /* 000 Get Key function*/
        const uint HA_POST_INTERCEPT_STATUS = 52; /* 000 Post Intercept*/
        const uint HA_STOP_KEY_INTERCEPT = 53; /* 000 Stop Keystroke*/
        const uint HA_LOCK_PS = 60; /* 000 Lock Presentation*/
        const uint HA_LOCK_PMSVC = 61; /* 000 Lock PM Window*/
        const uint
            HA_SEND_FILE = 90; /* 000 Send File function*/
        const uint
            HA_RECEIVE_FILE = 91; /* 000 Receive file*/
        const uint
            HA_CONVERT_POS_ROW_COL = 99; /* 000 Convert Position*/
        const uint
            HA_CONNECT_PM_SRVCS = 101; /* 000 Connect For*/
        const uint
            HA_DISCONNECT_PM_SRVCS = 102; /* 000 Disconnect From*/
        const uint
            HA_QUERY_WINDOW_COORDS = 103; /* 000 Query Presentation*/
        const uint
            HA_PM_WINDOW_STATUS = 104; /* 000 PM Window Status*/
        const uint
            HA_CHANGE_SWITCH_NAME = 105; /* 000 Change Switch List*/
        const uint
            HA_CHANGE_WINDOW_NAME = 106; /* 000 Change PS Window*/
        const uint
            HA_START_PLAYING_MACRO = 110; /* 000 Start playing macro*/
        const uint
            HA_START_STRUCTURED_FLD = 120; /* 000 Start Structured*/
        const uint
            HA_STOP_STRUCTURED_FLD = 121; /* 000 Stop Structured*/
        const uint
            HA_QUERY_BUFFER_SIZE = 122; /* 000 Query Communications*/
        const uint
            HA_ALLOCATE_COMMO_BUFF = 123; /* 000 Allocate*/
        const uint
            HA_FREE_COMMO_BUFF = 124; /* 000 Free Communications*/
        const uint
            HA_GET_ASYNC_COMPLETION = 125; /* 000 Get Asynchronous*/
        const uint
            HA_READ_STRUCTURED_FLD = 126; /* 000 Read Structured Field*/
        const uint
            HA_WRITE_STRUCTURED_FLD = 127; /* 000 Write Structured*/


        //********************************************************************/ 

        //******************* EHLLAPI RETURN CODES***************************/ 

        //********************************************************************/ 
        const uint
            HARC_SUCCESS = 0; /* 000 Good return code.*/
        const uint
            HARC99_INVALID_INP = 0; /* 000 Incorrect input*/
        const uint
            HARC_INVALID_PS = 1; /* 000 Invalid PS, Not*/
        const uint
            HARC_BAD_PARM = 2; /* 000 Bad parameter, or*/
        const uint
            HARC_BUSY = 4; /* 000 PS is busy return*/
        const uint
            HARC_LOCKED = 5; /* 000 PS is LOCKed, or*/
        const uint
            HARC_TRUNCATION = 6; /* 000 Truncation*/
        const uint
            HARC_INVALID_PS_POS = 7; /* 000 Invalid PS*/
        const uint
            HARC_NO_PRIOR_START = 8; /* 000 No prior start*/
        const uint
            HARC_SYSTEM_ERROR = 9; /* 000 A system error*/
        const uint
            HARC_UNSUPPORTED = 10; /* 000 Invalid or*/
        const uint
            HARC_UNAVAILABLE = 11; /* 000 Resource is*/
        const uint
            HARC_SESSION_STOPPED = 12; /* 000 Session has*/
        const uint
            HARC_BAD_MNEMONIC = 20; /* 000 Illegal mnemonic*/
        const uint
            HARC_OIA_UPDATE = 21; /* 000 A OIA update*/
        const uint
            HARC_PS_UPDATE = 22; /* 000 A PS update*/
        const uint
            HARC_PS_AND_OIA_UPDATE = 23; /* A PS and OIA update*/
        const uint
            HARC_STR_NOT_FOUND_UNFM_PS = 24; /* 000 String not found,*/
        const uint
            HARC_NO_KEYS_AVAIL = 25; /* 000 No keys available*/
        const uint
            HARC_HOST_UPDATE = 26; /* 000 A HOST update*/
        const uint
            HARC_FIELD_LEN_ZERO = 28; /* 000 Field length = 0*/
        const uint
            HARC_QUEUE_OVERFLOW = 31; /* 000 Keystroke queue*/
        const uint
            HARC_ANOTHER_CONNECTION = 32; /* 000 Successful. Another*/
        const uint
            HARC_INBOUND_CANCELLED = 34; /* 000 Inbound structured*/
        const uint
            HARC_OUTBOUND_CANCELLED = 35; /* 000 Outbound structured*/
        const uint
            HARC_CONTACT_LOST = 36; /* 000 Contact with the*/
        const uint
            HARC_INBOUND_DISABLED = 37; /* 000 Host structured m_MatchRecord*/
        const uint
            HARC_FUNCTION_INCOMPLETE = 38; /* 000 Requested Asynchronous*/
        const uint
            HARC_DDM_ALREADY_EXISTS = 39; /* 000 Request for DDM*/
        const uint
            HARC_ASYNC_REQUESTS_OUT = 40; /* 000 Disconnect successful.*/
        const uint
            HARC_MEMORY_IN_USE = 41; /* 000 Memory cannot be freed*/
        const uint
            HARC_NO_MATCH = 42; /* 000 No pending*/
        const uint
            HARC_OPTION_INVALID = 43; /* 000 Option requested is*/
        const uint
            HARC99_INVALID_PS = 9998; /* 000 An invalid PS id*/
        const uint
            HARC99_INVALID_CONV_OPT = 9999; /* 000 Invalid convert*/

        public static uint Connect(string sessionID)
        {
            StringBuilder sb = new StringBuilder(4);
            sb.Append(sessionID);
            string data = sessionID;
            uint f = HA_CONNECT_PS;
            uint l = 4;
            uint rc = 0;

            return hllapi(out f, sb, out l, out rc);
        }

        public static uint Disconnect(string sessionID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(sessionID);
            string data = sessionID;
            uint f = HA_DISCONNECT_PS;
            uint l = 0;
            uint rc;

            return hllapi(out f, sb, out l, out rc);
        }

        public static uint SetCursorPos(int xPos, int yPos)
        {
            StringBuilder sb = new StringBuilder(0);
            uint cpos = (uint)((xPos - 1) * 80 + yPos);
            uint f = HA_SET_CURSOR;
            uint l = 0;

            return hllapi(out f, sb, out l, out cpos);
        }

        public static uint SendFieldExit()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("@A@E");
            uint f = HA_SENDKEY;
            uint l = (uint)sb.Length;
            uint rc;

            return hllapi(out f, sb, out l, out rc);
        }

        public static uint SendFieldEnter()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("@E");
            uint f = HA_SENDKEY;
            uint l = (uint)sb.Length;
            uint rc;

            return hllapi(out f, sb, out l, out rc);
        }

        //public static uint GetCursorPos(ref int p)
        //{
        //    //StringBuilder Data = new StringBuilder(0);
        //    uint rc = 0;
        //    uint f = HA_QUERY_CURSOR_LOC;
        //    uint l = 0; //return position
        //    uint r = SmileInterfaceFunc.hllapi(ref f, Data, ref l, ref rc);
        //    p = (int)l;
        //    return r;
        //}

        public static uint SendKey(string cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(cmd);
            uint f = HA_SENDKEY;
            uint l = (uint)cmd.Length;
            uint rc;

            return hllapi(out f, sb, out l, out rc);
        }

        public static uint ReadScreen(int xPos, int yPos, int len, ref string txt)
        {
            StringBuilder Data = new StringBuilder(100);
            uint rc = (uint)((xPos - 1) * 80 + yPos);
            uint f = HA_COPY_PS_TO_STR;
            uint l = (uint)len;
            uint r = hllapi(out f, Data, out l, out rc);
            txt = Data.ToString().Substring(0, len);
            //if (txt.Length > len)
            //{
            //    txt = txt.Substring(0, len);
            //}
            //txt = txt.Trim();
            return r;
        }

        public static uint CopyFieldToScreen(int xPos, int yPos, string data, int len)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(data);
            uint pos = (uint)((xPos - 1) * 80 + yPos);
            uint f = HA_COPY_STR_TO_FIELD;
            uint l = (uint)len;

            return hllapi(out f, sb, out l, out pos);
        }
    }
}
