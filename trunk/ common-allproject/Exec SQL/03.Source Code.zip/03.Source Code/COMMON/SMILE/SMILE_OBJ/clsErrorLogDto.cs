﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:06:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This base class is used to provide error log info.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phoenix.Common.Smile.Gui;

namespace Phoenix.Common.Smile.Obj
{
    public class clsErrorLogDto
    {
        public string TransNo { get; set; }
        public string Module { get; set; }
        public DateTime ImportTime { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public ImportType ImportType { get; set; }
        public string ImportTypeText { get; set; }
        public string ImportBy { get; set; }
        public bool Result { get; set; }
        public string Status { get; set; }
        public string ErrorMsg { get; set; }
    }
}