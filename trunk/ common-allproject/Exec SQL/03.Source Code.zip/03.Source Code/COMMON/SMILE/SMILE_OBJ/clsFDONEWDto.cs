﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-05-10 1:56:21 +0700 (Fri, 10 May 2013) $
 * $Revision: 10087 $ 
 * ========================================================
 * This base class is used to provide info about each field 
 * in Smile screen.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phoenix.Common.Smile.Gui;

namespace Phoenix.Common.Smile.Obj
{
    public class clsFDONEWDto
    {
        public string Applicant { get; set; }
        public string Ccy { get; set; }
        public string GLCode1 { get; set; }
        public string GLCode2 { get; set; }
        public string TDNo1 { get; set; }
        public string TDNo2 { get; set; }
        public string Amount { get; set; }
        public string Maturity { get; set; }
        public string IntMethod { get; set; }
        public string YearDays { get; set; }
        public string IR { get; set; }
        public string IS { get; set; }
        public string DueNotify { get; set; }
        public string BRC { get; set; }
        public string ProceedAC1 { get; set; }
        public string ProceedAC2 { get; set; }
        public string ProceedAC3 { get; set; }
        public string NOWH { get; set; }
        public string MaturityAC1 { get; set; }
        public string MaturityAC2 { get; set; }
        public string MaturityAC3 { get; set; }
        public string InterestAC1 { get; set; }
        public string InterestAC2 { get; set; }
        public string InterestAC3 { get; set; }
        
        public MacroType MacroType { get; set; }
        public ImportType ImportType { get; set; }

        public string[] FieldNames
        {
            get { return GetFieldNameCollection(); }
        }

        public string[] FieldValues
        {
            get { return GetFieldValueCollection(); }
        }

        private string[] GetFieldNameCollection()
        {
            string[] fieldNames = new string[] { 
                "Applicant", "Ccy", "G/L Code", "TDNo",
                "Amount", "Maturity", "Int.Method", "Year Days",
                "Int.Rate", "I/S Rate", "Due Notify", "Base Rate Code",
                "Proceeds A/C", "Maturity A/C", "Interest A/C"
            };
            return fieldNames;
        }

        private string[] GetFieldValueCollection()
        {
            string[] fieldValues = new string[] { 
                Applicant, Ccy, GLCode1 + " - " + GLCode2, TDNo1 + " - " + TDNo2, 
                Amount, Maturity, IntMethod, YearDays, IR, IS, DueNotify, BRC,
                ProceedAC1 + " - " + ProceedAC2 + " " + ProceedAC3, NOWH,
                MaturityAC1 + " - " + MaturityAC2 + " " + MaturityAC3,
                InterestAC1 + " - " + InterestAC2 + " " + InterestAC3
            };
            return fieldValues;
        }
    }
}