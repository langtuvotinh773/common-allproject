﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:00:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This base class is used to provide info about each field 
 * in Smile screen.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Phoenix.Common.Smile.Gui;

namespace Phoenix.Common.Smile.Obj
{
    public class clsGTON01Dto
    {
        public string DebitCcy { get; set; }
        public string DebitValue { get; set; }
        public string DebitAdvice { get; set; }
        public string DebitGL1 { get; set; }
        public string DebitGL2 { get; set; }
        public string DebitCustomer { get; set; }
        public string DebitACNo { get; set; }
        public string DebitAmount { get; set; }
        public string DebitNW { get; set; }
        public string DebitReference { get; set; }
        public string DebitOurRef { get; set; }

        public string CreditCcy { get; set; }
        public string CreditGL1 { get; set; }
        public string CreditGL2 { get; set; }
        public string CreditACNo { get; set; }
        public string CreditAmount { get; set; }
        public string CreditCustomer { get; set; }
        public string CreditReference { get; set; }

        public string TransNo { get; set; }

        public string Method { get; set; }
        public string Cust { get; set; }
        public string ContractNo1 { get; set; }
        public string ContractNo2 { get; set; }

        public MacroType MacroType { get; set; }
        public ImportType ImportType { get; set; }

        public string[] FieldNames
        {
            get { return GetFieldNameCollection(); }
        }

        public string[] FieldValues
        {
            get { return GetFieldValueCollection(); }
        }

        private string[] GetFieldNameCollection()
        {
            string[] fieldNames = new string[] { 
                "DebitCcy", "DebitValue", "DebitAdvice", "DebitGL",
                "DebitACNo", "DebitAmount", "DebitNW", "DebitReference", "DebitOurRef",
                "CreditCcy", "CreditGL", "CreditACNo", "CreditAmount",
                "CreditCustomer", "CreditReference", "Method", "Cust"
            };
            return fieldNames;
        }

        private string[] GetFieldValueCollection()
        {
            string[] fieldValues = new string[] { 
                DebitCcy, DebitValue, DebitAdvice,
                DebitGL1 + " - " + DebitGL2, DebitACNo,
                DebitAmount, DebitNW, DebitReference, DebitOurRef, CreditCcy,
                CreditGL1 + " - " + CreditGL2,
                CreditACNo, CreditAmount, CreditCustomer, CreditReference,
                Method, Cust
            };
            return fieldValues;
        }
    }
}