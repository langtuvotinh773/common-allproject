﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:00:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This base class is used to provide info about each field 
 * in Smile screen.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Phoenix.Common.Smile.Gui;

namespace Phoenix.Common.Smile.Obj
{
    public class clsLGOSETDto
    {
        public string Value { get; set; }
        public string Customer { get; set; }
        public string Ccy { get; set; }
        public string GL1 { get; set; }
        public string GL2 { get; set; }
        public string Trans1 { get; set; }
        public string Trans2 { get; set; }
        public bool IsDelete { get; set; }
        public MacroType MacroType { get; set; }
        public ImportType ImportType { get; set; }

        public string[] FieldNames
        {
            get { return GetFieldNameCollection(); }
        }

        public string[] FieldValues
        {
            get { return GetFieldValueCollection(); }
        }

        private string[] GetFieldNameCollection()
        {
            string[] fieldNames = new string[] { 
                "Value", "Customer", "Ccy",
                "G/L", "Trans. No"
            };
            return fieldNames;
        }

        private string[] GetFieldValueCollection()
        {
            string[] fieldValues = new string[] { 
                Value, Customer, Ccy, GL1 + " - " + GL2, Trans1 + " - " + Trans2
            };
            return fieldValues;
        }

        public void PopulateListView(ListView lv)
        {
            lv.Items.Clear();

            string[] fieldNames = new string[] { 
                "Value", "Customer", "Ccy",
                "G/L", "Trans. No"
            };

            string[] fieldValues = new string[] { 
                Value, Customer, Ccy, GL1 + " - " + GL2, Trans1 + " - " + Trans2
            };

            for (int i = 0; i < fieldNames.Length; i++)
            {
                ListViewItem item = new ListViewItem();
                item.UseItemStyleForSubItems = false;
                //item.Font = new System.Drawing.Font("VnBrisk2", 9.0f, System.Drawing.FontStyle.Bold);
                item.ForeColor = System.Drawing.Color.LightGreen;
                item.Text = fieldNames[i];

                ListViewItem.ListViewSubItem sub = new ListViewItem.ListViewSubItem();
                //sub.Font = new System.Drawing.Font("VnBrisk2", 9.0f, System.Drawing.FontStyle.Bold);
                sub.ForeColor = System.Drawing.Color.Yellow;
                sub.Text = fieldValues[i];

                item.SubItems.Add(sub);
                lv.Items.Add(item);
            }
        }
    }
}