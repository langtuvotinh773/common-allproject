﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-04-25 11:00:50 +0700 (Thu, 25 April 2013) $
 * $Revision: 15147 $ 
 * ========================================================
 * This base class is used to provide info about each field 
 * in Smile screen.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Phoenix.Common.Smile.Gui;

namespace Phoenix.Common.Smile.Obj
{
    public class clsLGONEWDto
    {
        public string Page1Issue { get; set; }
        public string Page1Effective { get; set; }
        public string Page1Customer { get; set; }
        public string Page1Ccy { get; set; }
        public string Page1GL1 { get; set; }
        public string Page1GL2 { get; set; }
        public string Page1Trans1 { get; set; }
        public string Page1Trans2 { get; set; }

        public string Page2Trans { get; set; }
        public string Page2Exp { get; set; }
        public string Page2GuaranteeType { get; set; }
        public string Page2FeeRate { get; set; }
        public string Page2Adj { get; set; }
        public string Page2Minimum { get; set; }
        public string Page2CHGAC1 { get; set; }
        public string Page2CHGAC2 { get; set; }
        public string Page2CHGAC3 { get; set; }
        public string Page2CHGAC4 { get; set; }
        public string Page2Bene { get; set; }

        public MacroType MacroType { get; set; }
        public ImportType ImportType { get; set; }

        public string[] FieldNames 
        {
            get { return GetFieldNameCollection(); }  
        }

        public string[] FieldValues
        {
            get { return GetFieldValueCollection(); }
        }

        private string[] GetFieldNameCollection()
        { 
            string[] fieldNames = new string[] { 
                "Issue", "Effective", "Customer", "Ccy",
                "GL", "Trans. No", "Amount", "Expiry",
                "Guarantee Type", "FEE Rate", "adj", "Minimum",
                "CHG A/C", "bene / msg"
            };
            return fieldNames;
        }

        private string[] GetFieldValueCollection()
        {
            string[] fieldValues = new string[] { 
                Page1Issue, Page1Effective, Page1Customer, Page1Ccy,
                Page1GL1 + " - " + Page1GL2, Page1Trans1 + " - " + Page1Trans2,
                Page2Trans, Page2Exp, Page2GuaranteeType, Page2FeeRate,
                Page2Adj, Page2Minimum, Page2CHGAC1 + " " + Page2CHGAC2 + " - " + Page2CHGAC3 + " " + Page2CHGAC4,
                Page2Bene
            };
            return fieldValues;
        }

        public void PopulateListView(ListView lv)
        {
            lv.Items.Clear();

            string[] fieldNames = new string[] { 
                "Issue", "Effective", "Customer", "Ccy",
                "GL", "Trans. No", "Amount", "Expire",
                "Guarantee Type", "Fee Rate", "adj", "Minimum",
                "CHG A/C", "bene / msg"
            };

            string[] fieldValues = new string[] { 
                Page1Issue, Page1Effective, Page1Customer, Page1Ccy,
                Page1GL1 + " - " + Page1GL2, Page1Trans1 + " - " + Page1Trans2,
                Page2Trans, Page2Exp, Page2GuaranteeType, Page2FeeRate,
                Page2Adj, Page2Minimum, Page2CHGAC1 + " - " + Page2CHGAC2 + " " + Page2CHGAC3,
                Page2Bene
            };

            for (int i = 0; i < fieldNames.Length; i++)
            {
                ListViewItem item = new ListViewItem();
                item.UseItemStyleForSubItems = false;
                //item.Font = new System.Drawing.Font("VnBrisk2", 9.0f, System.Drawing.FontStyle.Bold);
                item.ForeColor = System.Drawing.Color.LightGreen;
                item.Text = fieldNames[i];

                ListViewItem.ListViewSubItem sub = new ListViewItem.ListViewSubItem();
                //sub.Font = new System.Drawing.Font("VnBrisk2", 9.0f, System.Drawing.FontStyle.Bold);
                sub.ForeColor = System.Drawing.Color.Yellow;
                sub.Text = fieldValues[i];

                item.SubItems.Add(sub);
                lv.Items.Add(item);
            }
        }
    }
}