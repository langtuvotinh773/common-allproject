﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: ntquan $
 * $Date: 2013-05-10 2:01:06 +0700 (Fri, 10 May 2013) $
 * $Revision: 16757 $ 
 * ========================================================
 * This base class is used to provide info about each field 
 * in Smile screen.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phoenix.Common.Smile.Gui;

namespace Phoenix.Common.Smile.Obj
{
    public class clsFDOSETDto
    {
        public string Applicant { get; set; }
        public string Ccy { get; set; }
        public string GLCode { get; set; }
        public string TDNo { get; set; }
        public string PrematureRate { get; set; }
        public string InterestAC1 { get; set; }
        public string InterestAC2 { get; set; }
        public string InterestAC3 { get; set; }

        public MacroType MacroType { get; set; }
        public ImportType ImportType { get; set; }

        public string[] FieldNames
        {
            get { return GetFieldNameCollection(); }
        }

        public string[] FieldValues
        {
            get { return GetFieldValueCollection(); }
        }

        private string[] GetFieldNameCollection()
        {
            string[] fieldNames = new string[] { 
                "Applicant", "Ccy", "G/L Code", "TDNo",
                "Pre-mature Rate", "Interest A/C"
            };
            return fieldNames;
        }

        private string[] GetFieldValueCollection()
        {
            string[] fieldValues = new string[] { 
                Applicant, Ccy, GLCode, TDNo, PrematureRate,
                InterestAC1 + " - " + InterestAC2 + " " + InterestAC3
            };
            return fieldValues;
        }
    }
}
