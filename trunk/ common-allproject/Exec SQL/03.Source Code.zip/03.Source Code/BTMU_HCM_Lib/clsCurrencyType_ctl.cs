﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer;
using System.Data;
using CommonLib;

namespace BTMU_HCM_Lib
{
    public class clsCurrencyType_ctl
    {
        public Boolean loadCurrencyList(ref DataTable table)
        {
            try
            {
                String _query = "select * "
                    + " from CurrencyType ";
                DataSet dataSet = DataAccessClass.datasetQuery(_query);
                table = dataSet.Tables[0];
                return true;
            }
            catch (Exception ex)
            {
                clsMessage.ShowError(ex.Message);
                return false;
            }
        }
    }
}
