﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using DataAccessLayer;

namespace BTMU_HCM_Lib
{
    public class BTMU_HCM_Class
    {
        public static string _countRec = "0";

        #region fill cbCustID
        public static void fill_cbCustID(ComboBox cbCustID)
        {
            string _query = "select Code from [Customer Database] where Closed = 'false'";
            DataSet _ds = DataAccessClass.datasetQuery(_query);
            _countRec = _ds.Tables[0].Rows.Count.ToString();
            //sort DataRow
            string _sExp = "Code is not null";
            string _sSort = "Code ASC";
            try
            {
                DataRow[] _dr = _ds.Tables[0].Select(_sExp, _sSort);
                //dr = ds.Tables[0].Select();
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbCustID.Items.Add(_dr[i]["Code"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion

        #region fill cbCustFN
        public static void fill_cbCustFN(ComboBox cbCustFN)
        {
            string _query = "select Name from [Customer Database] where Closed = 'false'";
            DataSet _ds = DataAccessClass.datasetQuery(_query);
            _countRec = _ds.Tables[0].Rows.Count.ToString();
            string _sExp = "Name is not null";
            string _sSort = "Name ASC";
            try
            {
                DataRow[] _dr = _ds.Tables[0].Select(_sExp, _sSort);
                //dr = ds.Tables[0].Select();
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbCustFN.Items.Add(_dr[i]["Name"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion

        #region fill cbbIrregularName
        public static void fill_cbCustIrregularName(ComboBox cbCustFN)
        {
            string _query = "select DISTINCT Name from [IrregularHandling]";
            DataSet _ds = DataAccessClass.datasetQuery(_query);
            _countRec = _ds.Tables[0].Rows.Count.ToString();
            string _sExp = "Name is not null";
            string _sSort = "Name ASC";
            try
            {
                DataRow[] _dr = _ds.Tables[0].Select(_sExp, _sSort);
                //dr = ds.Tables[0].Select();
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbCustFN.Items.Add(_dr[i]["Name"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion

        #region fill cbbIrregularGroup
        public static void fill_cbCustIrregularGroup(ComboBox cbCustFN)
        {
            string _query = "select GroupID from [IrrGroup]";
            DataSet _ds = DataAccessClass.datasetQuery(_query);
            _countRec = _ds.Tables[0].Rows.Count.ToString();
            string _sExp = "GroupID is not null";
            string _sSort = "GroupID ASC";
            try
            {
                DataRow[] _dr = _ds.Tables[0].Select(_sExp, _sSort);
                //dr = ds.Tables[0].Select();
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbCustFN.Items.Add(_dr[i]["GroupID"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion
        #region fill cbbAccount
        public static void fill_cbAccount(ComboBox cbCustFN)
        {
            string _query = "select [AC No] from [IrrAccountInfo]";
            DataSet _ds = DataAccessClass.datasetQuery(_query);
            _countRec = _ds.Tables[0].Rows.Count.ToString();
            string _sExp = "[AC No] is not null";
            string _sSort = "[AC No] ASC";
            try
            {
                DataRow[] _dr = _ds.Tables[0].Select(_sExp, _sSort);
                //dr = ds.Tables[0].Select();
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbCustFN.Items.Add(_dr[i]["AC No"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion
        #region fill SmileCustomerName
        public static void fill_cbSmileCustomerName(ComboBox cbCustFN)
        {
            string _query = "select Name from [IrrCustAddress]";
            DataSet _ds = DataAccessClass.datasetQuery(_query);
            _countRec = _ds.Tables[0].Rows.Count.ToString();
            string _sExp = "Name is not null";
            string _sSort = "Name ASC";
            try
            {
                DataRow[] _dr = _ds.Tables[0].Select(_sExp, _sSort);
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbCustFN.Items.Add(_dr[i]["Name"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion

        #region fill Referrent ID
        public static void fill_cbReferrentID(ComboBox cbRef)
        {
            string _query = "select DISTINCT Ref from [IrregularHandling]";
            DataSet _ds = DataAccessClass.datasetQuery(_query);
            _countRec = _ds.Tables[0].Rows.Count.ToString();
            string _sExp = "Ref is not null";
            string _sSort = "Ref ASC";
            try
            {
                DataRow[] _dr = _ds.Tables[0].Select(_sExp, _sSort);
                //dr = ds.Tables[0].Select();
                for (int i = 0; i < _dr.Length; i++)
                {
                    cbRef.Items.Add(_dr[i]["Ref"].ToString().Trim());
                }
            }
            catch
            {
                MessageBox.Show("Database is error!");
            }
        }
        #endregion
    }
}
