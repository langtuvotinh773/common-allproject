﻿namespace CPA.CPA_GUI.REPORT
{
    
    
    public partial class DtsCustomerTransactions {
        partial class DataTable1DataTable
        {
        }
    }
}
