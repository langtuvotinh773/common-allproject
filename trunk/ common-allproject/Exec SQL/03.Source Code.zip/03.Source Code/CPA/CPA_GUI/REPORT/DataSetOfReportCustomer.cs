﻿namespace CPA.CPA_GUI.REPORT
{
    
    
    public partial class DataSetOfReportCustomer {
        partial class DataTable1DataTable
        {
        }
    }
}
