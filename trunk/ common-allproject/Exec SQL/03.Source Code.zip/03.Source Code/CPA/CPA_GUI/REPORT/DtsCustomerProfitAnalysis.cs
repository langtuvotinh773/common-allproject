﻿namespace Phoenix.Cpa.Gui.Report {
    
    
    public partial class DtsCustomerProfitAnalysis {
        partial class DataTable1DataTable
        {
        }
    }
}
