﻿using UserCtrl;
namespace Phoenix.Cpa.Gui.Forms
{
    partial class frmViewCustomerTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgCustomerTransaction = new UserCtrl.DisableDatagrid();
            this.lblCustomerFullName = new System.Windows.Forms.Label();
            this.frmCustomerCode = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.ckbFull = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCustomerFullName = new UserCtrl.DisableTextBox();
            this.txtCustomerCode = new UserCtrl.DisableTextBox();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCustomerTransaction)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtgCustomerTransaction
            // 
            this.dtgCustomerTransaction.AllowUserToAddRows = false;
            this.dtgCustomerTransaction.AllowUserToDeleteRows = false;
            this.dtgCustomerTransaction.AllowUserToResizeColumns = false;
            this.dtgCustomerTransaction.AllowUserToResizeRows = false;
            this.dtgCustomerTransaction.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgCustomerTransaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgCustomerTransaction.Location = new System.Drawing.Point(5, 67);
            this.dtgCustomerTransaction.Name = "dtgCustomerTransaction";
            this.dtgCustomerTransaction.Size = new System.Drawing.Size(980, 460);
            this.dtgCustomerTransaction.TabIndex = 1;
            this.dtgCustomerTransaction.TabStop = false;
            // 
            // lblCustomerFullName
            // 
            this.lblCustomerFullName.AutoSize = true;
            this.lblCustomerFullName.Location = new System.Drawing.Point(283, 18);
            this.lblCustomerFullName.Name = "lblCustomerFullName";
            this.lblCustomerFullName.Size = new System.Drawing.Size(101, 13);
            this.lblCustomerFullName.TabIndex = 8;
            this.lblCustomerFullName.Text = "Customer Full Name";
            // 
            // frmCustomerCode
            // 
            this.frmCustomerCode.AutoSize = true;
            this.frmCustomerCode.Location = new System.Drawing.Point(25, 20);
            this.frmCustomerCode.Name = "frmCustomerCode";
            this.frmCustomerCode.Size = new System.Drawing.Size(79, 13);
            this.frmCustomerCode.TabIndex = 6;
            this.frmCustomerCode.Text = "Customer Code";
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnPrint.Location = new System.Drawing.Point(776, 534);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(100, 23);
            this.btnPrint.TabIndex = 0;
            this.btnPrint.Text = "&Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // ckbFull
            // 
            this.ckbFull.AutoSize = true;
            this.ckbFull.Location = new System.Drawing.Point(110, 38);
            this.ckbFull.Name = "ckbFull";
            this.ckbFull.Size = new System.Drawing.Size(42, 17);
            this.ckbFull.TabIndex = 0;
            this.ckbFull.Text = "Full";
            this.ckbFull.UseVisualStyleBackColor = true;
            this.ckbFull.CheckedChanged += new System.EventHandler(this.ckbFull_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.txtCustomerFullName);
            this.groupBox1.Controls.Add(this.txtCustomerCode);
            this.groupBox1.Controls.Add(this.ckbFull);
            this.groupBox1.Controls.Add(this.frmCustomerCode);
            this.groupBox1.Controls.Add(this.lblCustomerFullName);
            this.groupBox1.Location = new System.Drawing.Point(5, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(981, 61);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // txtCustomerFullName
            // 
            this.txtCustomerFullName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtCustomerFullName.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCustomerFullName.ForeColor = System.Drawing.Color.Black;
            this.txtCustomerFullName.Location = new System.Drawing.Point(401, 12);
            this.txtCustomerFullName.Name = "txtCustomerFullName";
            this.txtCustomerFullName.Size = new System.Drawing.Size(572, 20);
            this.txtCustomerFullName.TabIndex = 13;
            this.txtCustomerFullName.TabStop = false;
            // 
            // txtCustomerCode
            // 
            this.txtCustomerCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtCustomerCode.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCustomerCode.ForeColor = System.Drawing.Color.Black;
            this.txtCustomerCode.Location = new System.Drawing.Point(110, 13);
            this.txtCustomerCode.Name = "txtCustomerCode";
            this.txtCustomerCode.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerCode.TabIndex = 12;
            this.txtCustomerCode.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(882, 534);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 23);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmViewCustomerTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(990, 565);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dtgCustomerTransaction);
            this.Controls.Add(this.btnPrint);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmViewCustomerTransaction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Customer Transaction";
            this.Load += new System.EventHandler(this.frmViewCustomerDetail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgCustomerTransaction)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private DisableDatagrid dtgCustomerTransaction;
        private System.Windows.Forms.Label lblCustomerFullName;
        private System.Windows.Forms.Label frmCustomerCode;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.CheckBox ckbFull;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnClose;
        private DisableTextBox txtCustomerFullName;
        private DisableTextBox txtCustomerCode;
    }
}