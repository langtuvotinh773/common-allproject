﻿using UserCtrl;
namespace Phoenix.Cpa.Gui.Forms
{
	partial class frmScreenReportProfit
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblFromQuarter = new System.Windows.Forms.Label();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.lblJO = new System.Windows.Forms.Label();
            this.lblCustomerCode = new System.Windows.Forms.Label();
            this.lblToQuarter = new System.Windows.Forms.Label();
            this.lblTeam = new System.Windows.Forms.Label();
            this.lblNewPerson = new System.Windows.Forms.Label();
            this.lblCustomerFullName = new System.Windows.Forms.Label();
            this.txtCustomerFullName = new System.Windows.Forms.TextBox();
            this.txtCustomerCode = new System.Windows.Forms.TextBox();
            this.cbbDepartment = new System.Windows.Forms.ComboBox();
            this.cbbJPAcc = new System.Windows.Forms.ComboBox();
            this.cbbTeam = new System.Windows.Forms.ComboBox();
            this.cbbVNAcc = new System.Windows.Forms.ComboBox();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblListReport = new System.Windows.Forms.Label();
            this.rad0102 = new System.Windows.Forms.RadioButton();
            this.lbl0102 = new System.Windows.Forms.Label();
            this.rad03 = new System.Windows.Forms.RadioButton();
            this.lbl03 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtFromQuarter = new UserCtrl.MonthYearCalendar();
            this.txtToQuarter = new UserCtrl.MonthYearCalendar();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cbbJNJ = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFromQuarter
            // 
            this.lblFromQuarter.AutoSize = true;
            this.lblFromQuarter.Location = new System.Drawing.Point(12, 9);
            this.lblFromQuarter.Name = "lblFromQuarter";
            this.lblFromQuarter.Size = new System.Drawing.Size(68, 13);
            this.lblFromQuarter.TabIndex = 0;
            this.lblFromQuarter.Text = "From Quarter";
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Location = new System.Drawing.Point(12, 31);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(62, 13);
            this.lblDepartment.TabIndex = 0;
            this.lblDepartment.Text = "Department";
            // 
            // lblJO
            // 
            this.lblJO.AutoSize = true;
            this.lblJO.Location = new System.Drawing.Point(12, 53);
            this.lblJO.Name = "lblJO";
            this.lblJO.Size = new System.Drawing.Size(96, 13);
            this.lblJO.TabIndex = 0;
            this.lblJO.Text = "JP Account Officer";
            // 
            // lblCustomerCode
            // 
            this.lblCustomerCode.AutoSize = true;
            this.lblCustomerCode.Location = new System.Drawing.Point(12, 76);
            this.lblCustomerCode.Name = "lblCustomerCode";
            this.lblCustomerCode.Size = new System.Drawing.Size(79, 13);
            this.lblCustomerCode.TabIndex = 0;
            this.lblCustomerCode.Text = "Customer Code";
            // 
            // lblToQuarter
            // 
            this.lblToQuarter.AutoSize = true;
            this.lblToQuarter.Location = new System.Drawing.Point(378, 12);
            this.lblToQuarter.Name = "lblToQuarter";
            this.lblToQuarter.Size = new System.Drawing.Size(58, 13);
            this.lblToQuarter.TabIndex = 0;
            this.lblToQuarter.Text = "To Quarter";
            // 
            // lblTeam
            // 
            this.lblTeam.AutoSize = true;
            this.lblTeam.Location = new System.Drawing.Point(378, 34);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.Size = new System.Drawing.Size(34, 13);
            this.lblTeam.TabIndex = 0;
            this.lblTeam.Text = "Team";
            // 
            // lblNewPerson
            // 
            this.lblNewPerson.AutoSize = true;
            this.lblNewPerson.Location = new System.Drawing.Point(378, 56);
            this.lblNewPerson.Name = "lblNewPerson";
            this.lblNewPerson.Size = new System.Drawing.Size(99, 13);
            this.lblNewPerson.TabIndex = 0;
            this.lblNewPerson.Text = "VN Account Officer";
            // 
            // lblCustomerFullName
            // 
            this.lblCustomerFullName.AutoSize = true;
            this.lblCustomerFullName.Location = new System.Drawing.Point(378, 79);
            this.lblCustomerFullName.Name = "lblCustomerFullName";
            this.lblCustomerFullName.Size = new System.Drawing.Size(101, 13);
            this.lblCustomerFullName.TabIndex = 0;
            this.lblCustomerFullName.Text = "Customer Full Name";
            // 
            // txtCustomerFullName
            // 
            this.txtCustomerFullName.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCustomerFullName.Location = new System.Drawing.Point(507, 77);
            this.txtCustomerFullName.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.txtCustomerFullName.Name = "txtCustomerFullName";
            this.txtCustomerFullName.Size = new System.Drawing.Size(267, 20);
            this.txtCustomerFullName.TabIndex = 7;
            this.txtCustomerFullName.TextChanged += new System.EventHandler(this.txtCustomerFullName_TextChanged);
            // 
            // txtCustomerCode
            // 
            this.txtCustomerCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCustomerCode.Location = new System.Drawing.Point(116, 73);
            this.txtCustomerCode.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.txtCustomerCode.Name = "txtCustomerCode";
            this.txtCustomerCode.Size = new System.Drawing.Size(242, 20);
            this.txtCustomerCode.TabIndex = 6;
            this.txtCustomerCode.TextChanged += new System.EventHandler(this.txtCustomerCode_TextChanged);
            // 
            // cbbDepartment
            // 
            this.cbbDepartment.FormattingEnabled = true;
            this.cbbDepartment.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbDepartment.Location = new System.Drawing.Point(116, 27);
            this.cbbDepartment.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.cbbDepartment.Name = "cbbDepartment";
            this.cbbDepartment.Size = new System.Drawing.Size(242, 21);
            this.cbbDepartment.TabIndex = 2;
            this.cbbDepartment.SelectedIndexChanged += new System.EventHandler(this.cbbDepartment_SelectedIndexChanged);
            // 
            // cbbJPAcc
            // 
            this.cbbJPAcc.FormattingEnabled = true;
            this.cbbJPAcc.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbJPAcc.Location = new System.Drawing.Point(116, 50);
            this.cbbJPAcc.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.cbbJPAcc.Name = "cbbJPAcc";
            this.cbbJPAcc.Size = new System.Drawing.Size(242, 21);
            this.cbbJPAcc.TabIndex = 4;
            this.cbbJPAcc.SelectedIndexChanged += new System.EventHandler(this.cbbJPAcc_SelectedIndexChanged);
            // 
            // cbbTeam
            // 
            this.cbbTeam.FormattingEnabled = true;
            this.cbbTeam.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbTeam.Location = new System.Drawing.Point(507, 30);
            this.cbbTeam.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.cbbTeam.Name = "cbbTeam";
            this.cbbTeam.Size = new System.Drawing.Size(267, 21);
            this.cbbTeam.TabIndex = 3;
            this.cbbTeam.SelectedIndexChanged += new System.EventHandler(this.cbbTeam_SelectedIndexChanged);
            // 
            // cbbVNAcc
            // 
            this.cbbVNAcc.FormattingEnabled = true;
            this.cbbVNAcc.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbVNAcc.Location = new System.Drawing.Point(507, 53);
            this.cbbVNAcc.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.cbbVNAcc.Name = "cbbVNAcc";
            this.cbbVNAcc.Size = new System.Drawing.Size(267, 21);
            this.cbbVNAcc.TabIndex = 5;
            this.cbbVNAcc.SelectedIndexChanged += new System.EventHandler(this.cbbVNAcc_SelectedIndexChanged);
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportExcel.Location = new System.Drawing.Point(568, 230);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(100, 23);
            this.btnExportExcel.TabIndex = 10;
            this.btnExportExcel.Text = "&Export Excel";
            this.btnExportExcel.UseVisualStyleBackColor = true;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.lblListReport, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.rad0102, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl0102, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.rad03, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl03, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 133);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(762, 77);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // lblListReport
            // 
            this.lblListReport.AutoSize = true;
            this.lblListReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblListReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblListReport.Location = new System.Drawing.Point(52, 1);
            this.lblListReport.Margin = new System.Windows.Forms.Padding(0);
            this.lblListReport.Name = "lblListReport";
            this.lblListReport.Size = new System.Drawing.Size(709, 23);
            this.lblListReport.TabIndex = 0;
            this.lblListReport.Text = "List Report";
            this.lblListReport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rad0102
            // 
            this.rad0102.AutoSize = true;
            this.rad0102.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad0102.Checked = true;
            this.rad0102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad0102.Location = new System.Drawing.Point(4, 28);
            this.rad0102.Name = "rad0102";
            this.rad0102.Size = new System.Drawing.Size(44, 16);
            this.rad0102.TabIndex = 0;
            this.rad0102.TabStop = true;
            this.rad0102.UseVisualStyleBackColor = true;
            this.rad0102.CheckedChanged += new System.EventHandler(this.radReportByCustomer_CheckedChanged);
            // 
            // lbl0102
            // 
            this.lbl0102.AutoSize = true;
            this.lbl0102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl0102.Location = new System.Drawing.Point(55, 25);
            this.lbl0102.Name = "lbl0102";
            this.lbl0102.Size = new System.Drawing.Size(703, 22);
            this.lbl0102.TabIndex = 2;
            this.lbl0102.Text = "REPORT ON CPA BY ACCOUNT OFFICER";
            this.lbl0102.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl0102.Click += new System.EventHandler(this.label1_Click);
            // 
            // rad03
            // 
            this.rad03.AutoSize = true;
            this.rad03.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad03.Location = new System.Drawing.Point(4, 51);
            this.rad03.Name = "rad03";
            this.rad03.Size = new System.Drawing.Size(44, 22);
            this.rad03.TabIndex = 1;
            this.rad03.UseVisualStyleBackColor = true;
            this.rad03.CheckedChanged += new System.EventHandler(this.radReportByCBD1_CheckedChanged);
            // 
            // lbl03
            // 
            this.lbl03.AutoSize = true;
            this.lbl03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl03.Location = new System.Drawing.Point(55, 48);
            this.lbl03.Name = "lbl03";
            this.lbl03.Size = new System.Drawing.Size(703, 28);
            this.lbl03.TabIndex = 4;
            this.lbl03.Text = "REPORT ON CPA BY ACCOUNT OFFICER - TOP 20 CUSTOMERS";
            this.lbl03.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl03.Click += new System.EventHandler(this.label2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(1, 1);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 23);
            this.label2.TabIndex = 5;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(674, 230);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 23);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtFromQuarter
            // 
            this.txtFromQuarter.CustomFormat = "MM/yyyy";
            this.txtFromQuarter.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtFromQuarter.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtFromQuarter.Location = new System.Drawing.Point(116, 5);
            this.txtFromQuarter.Name = "txtFromQuarter";
            this.txtFromQuarter.ShowUpDown = true;
            this.txtFromQuarter.Size = new System.Drawing.Size(242, 20);
            this.txtFromQuarter.TabIndex = 0;
            this.txtFromQuarter.Value = new System.DateTime(2012, 2, 1, 0, 0, 0, 0);

            this.txtFromQuarter.ValueChanged += new System.EventHandler(this.txtFromQuarter_ValueChanged);
            // 
            // txtToQuarter
            // 
            this.txtToQuarter.CustomFormat = "MM/yyyy";
            this.txtToQuarter.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtToQuarter.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtToQuarter.Location = new System.Drawing.Point(507, 8);
            this.txtToQuarter.Name = "txtToQuarter";
            this.txtToQuarter.ShowUpDown = true;
            this.txtToQuarter.Size = new System.Drawing.Size(267, 20);
            this.txtToQuarter.TabIndex = 1;
            this.txtToQuarter.Value = new System.DateTime(2013, 1, 4, 0, 0, 0, 0);
            this.txtToQuarter.ValueChanged += new System.EventHandler(this.txtToQuarter_ValueChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn1.HeaderText = "List Report";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 450;
            // 
            // cbbJNJ
            // 
            this.cbbJNJ.FormattingEnabled = true;
            this.cbbJNJ.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbJNJ.Location = new System.Drawing.Point(116, 95);
            this.cbbJNJ.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.cbbJNJ.Name = "cbbJNJ";
            this.cbbJNJ.Size = new System.Drawing.Size(242, 21);
            this.cbbJNJ.TabIndex = 8;
            this.cbbJNJ.SelectedIndexChanged += new System.EventHandler(this.cbbJNJ_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "JNJ";
            // 
            // frmScreenReportProfit
            // 
            this.AcceptButton = this.btnExportExcel;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(793, 265);
            this.Controls.Add(this.txtToQuarter);
            this.Controls.Add(this.txtFromQuarter);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.btnExportExcel);
            this.Controls.Add(this.cbbVNAcc);
            this.Controls.Add(this.cbbTeam);
            this.Controls.Add(this.cbbJNJ);
            this.Controls.Add(this.cbbJPAcc);
            this.Controls.Add(this.cbbDepartment);
            this.Controls.Add(this.txtCustomerCode);
            this.Controls.Add(this.txtCustomerFullName);
            this.Controls.Add(this.lblCustomerCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblJO);
            this.Controls.Add(this.lblDepartment);
            this.Controls.Add(this.lblCustomerFullName);
            this.Controls.Add(this.lblNewPerson);
            this.Controls.Add(this.lblTeam);
            this.Controls.Add(this.lblToQuarter);
            this.Controls.Add(this.lblFromQuarter);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmScreenReportProfit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "History of Profit For Quaterly Report";
            this.Load += new System.EventHandler(this.frmScreenReportProfit_Load);

            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblFromQuarter;
		private System.Windows.Forms.Label lblDepartment;
		private System.Windows.Forms.Label lblJO;
		private System.Windows.Forms.Label lblCustomerCode;
		private System.Windows.Forms.Label lblToQuarter;
		private System.Windows.Forms.Label lblTeam;
		private System.Windows.Forms.Label lblNewPerson;
		private System.Windows.Forms.Label lblCustomerFullName;
		private System.Windows.Forms.TextBox txtCustomerFullName;
		private System.Windows.Forms.TextBox txtCustomerCode;
		private System.Windows.Forms.ComboBox cbbDepartment;
		private System.Windows.Forms.ComboBox cbbJPAcc;
		private System.Windows.Forms.ComboBox cbbTeam;
		private System.Windows.Forms.ComboBox cbbVNAcc;
		private System.Windows.Forms.Button btnExportExcel;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Label lblListReport;
		internal System.Windows.Forms.RadioButton rad0102;
		private System.Windows.Forms.Label lbl0102;
		internal System.Windows.Forms.RadioButton rad03;
		private System.Windows.Forms.Label lbl03;
		private System.Windows.Forms.Button btnClose;
		private MonthYearCalendar txtFromQuarter;
		private MonthYearCalendar txtToQuarter;
		private System.Windows.Forms.ComboBox cbbJNJ;
		private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
	}
}