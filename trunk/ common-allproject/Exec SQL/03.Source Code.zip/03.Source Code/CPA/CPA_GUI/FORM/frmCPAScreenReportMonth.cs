﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-02-04 20:37:30 +0700 (Thu, 04 Feb 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to handle for Report Month
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Dto;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Functions;
using DataEncryption; 
namespace Phoenix.Cpa.Gui.Forms
{

    /// <summary>
    /// This form use to expoer report month
    /// Phong: In Charge at 2/2013
    /// </summary>
	public partial class frmScreenReportMonth : MasterForm
	{
		#region VARIABLE
		///Excelbase object, used to create Excel
		ExcelBase m_ExcelBase = null;
		/// file name
		private string m_FileName = "";
		/// handle background thread
		private CWorker m_worker;
		/// template file for save
		private string m_TemplateName;
		/// from year
		private string m_YearStart;
		/// to year
		private string m_YearEnd;
		/// from month
		private string m_MonthStart;
		/// to month
		private string m_MonthEnd;
		/// from date (yyyyMM)
		private string m_DateFrom;
		/// to data (yyyyMM)
		private string m_DateTo;
		private const string FORMAT_EXPORT_CELL = "N2";
		private const string S_MONTH_MAR = "Mar";
		private const double S_ZERO =0;
		/// from year (int)
		private int m_iYearStart;
		/// to year (int)
		private int m_iYearEnd;
		/// from month (int)
		private int m_iMonthStart;
		/// to month (int)
		private int m_iMonthEnd;
		/// start month of financal year
		private int m_iPreMonth = 4;
		/// months per year
		private int m_iMonthPerYear = 12;
		/// month to delete
		private int m_iDeleteMonthCount = 0;		
		private string m_RealFrom = "";
		/// date from (datetime)
		private DateTime m_dDateFrom;
		/// date to (datetime)
		private DateTime m_dDateTo;
		/// flag to show if there is no data
		private bool m_isNoData = false;
		/// actual date
		private List<string> m_RoughDate = new List<string>();
		/// number of headers of each row
		int m_HeaderRowCount = 6;
		/// Common function object
		clsCommonFunctions m_CommonFunction = null;
		/// report bus object
		clsReportBLL m_rptBus = new clsReportBLL();
		/// department ID
		string m_DepartmentID = "";
		/// team ID
		string m_TeamID = "";
		/// Japan Account ID
		string m_JPAccID = "";
		/// Vietnam Account ID
		string m_VNAccID = "";
		/// Customer ID
		string m_CustomerID = "";
		/// Customer name 
		string m_CustomerName = "";
		/// JNJ ID
		string m_JnjID = "";
		/// used to print time ( just for testing)
		int iNow = 0;
		/// Project name, used for create excel file
		string m_ProjectName = clsCPAConstant.PROJECT_NAME_CPA;
		/// header name of report
		object[,] m_arrHeaderName;
		/// column count of report
		int m_iColCount;
		/// data matrix to export
		object[,] m_arrData;
		/// row count of report
		int m_iRowCount;
		/// column count of report
		int m_iColumnCount;
		/// radio name
		private string m_radName;

        private string m_oldTeam = "";
        private string m_oldJP = "";
        private string m_oldVN = "";
        private bool m_IsOnSetDataCombobox = false;

        string strLabel11 = " CUSTOMERS IN TERMS OF DEPOSIT AVERAGE BALANCE";
        string strLabel12 = " CUSTOMERS IN TERMS OF LOAN AVERAGE BALANCE";
        string strLabel13 = " CUSTOMERS IN TERMS OF TOTAL PROFIT";

		#region REPORT 11, 12, 13
		/// data top matrix
		object[,] m_arrDataTop;
		/// data top 20 matrix
		object[,] m_arrDataTop20;
		/// data total matrix
		object[,] m_arrDataTotal;
		/// row count of data top matrix
		int m_iRowCountDataTop = 0;
		/// row count of data total matrix
		int m_iRowCountDataTotal = 0;
		/// row count of data top 20 matrix
		int m_iRowCountDataTop20 = 0;

        int m_iTopJP = int.Parse(Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["topJP"].ToString()));
        int m_iTopNJ = int.Parse(Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["topNJ"].ToString()));
		#endregion

		#endregion

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public frmScreenReportMonth()
		{
			InitializeComponent();
            SetSecurity();


            lbl11.Text ="REPORT ON " + m_iTopJP.ToString()+ strLabel11;
            lbl12.Text = "REPORT ON " + m_iTopJP.ToString() + strLabel12;
            lbl13.Text = "REPORT ON " + m_iTopJP.ToString() + strLabel13;
			try
			{
				m_CommonFunction = new clsCommonFunctions();
 				m_TemplateName = GetTemplateName(); 
				SetFormStyle();
                clsGetDataCombobox.Instance().LoadDepartment();
				SetDataCombobox("","");

                cbbJPAcc.DataSource = clsGetDataCombobox.Instance().JPAcc;
                cbbJPAcc.DisplayMember = clsCPAConstant.USER_NAME;
                cbbJPAcc.ValueMember = clsCPAConstant.USER_ID;
                cbbJPAcc.DropDownStyle = ComboBoxStyle.DropDownList;
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

		/// <summary>
		/// Set data for combobox
		/// </summary>
		/// @cond
		/// Author: Phong Nguyen
		/// @endcond
		private void SetDataCombobox(string Department,string team)
		{
            m_IsOnSetDataCombobox = true;
            cbbDepartment.DataSource = clsGetDataCombobox.Instance().LstDepartment;
            cbbDepartment.DisplayMember = clsCPAConstant.DEPARTMENT_NAME;
            cbbDepartment.ValueMember = clsCPAConstant.DEPARTMENT_ID;
            cbbDepartment.DropDownStyle = ComboBoxStyle.DropDownList;

            if (team == "")
            {
                clsGetDataCombobox.Instance().LoadTeam(Department);
                cbbTeam.DataSource = clsGetDataCombobox.Instance().LstSection;
                cbbTeam.DisplayMember = clsCPAConstant.SECTION_NAME;
                cbbTeam.ValueMember = clsCPAConstant.SECTION_ID;
                cbbTeam.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            clsGetDataCombobox.Instance().LoadUser(Department, team);
			

			

		

			cbbVNAcc.DataSource = clsGetDataCombobox.Instance().VNAcc;
			cbbVNAcc.DisplayMember = clsCPAConstant.USER_NAME;
			cbbVNAcc.ValueMember = clsCPAConstant.USER_ID;
			cbbVNAcc.DropDownStyle = ComboBoxStyle.DropDownList;

			cbbJNJ.DataSource = clsGetDataCombobox.Instance().lstJNJ;
			cbbJNJ.DisplayMember = clsCPAConstant.NAME;
			cbbJNJ.ValueMember = clsCPAConstant.VALUE;
			cbbJNJ.DropDownStyle = ComboBoxStyle.DropDownList;

            if (m_oldTeam != "")
            {
                int index = 0;
                index = clsGetDataCombobox.Instance().LstSection.FindIndex(delegate(SectionDTO st)
                {
                    return st.SectionID == m_oldTeam;
                });
                if (index >= 0)
                   
                    cbbTeam.SelectedIndex = index;
                else
                {
                   // if (team != "")
                    m_oldTeam = "";
                }
            }
            //if (m_oldJP != "")
            //{
            //    int index = 0;
            //    index = clsGetDataCombobox.Instance().JPAcc.FindIndex(delegate(UserDTO st)
            //    {
            //        return st.UserID == m_oldJP;
            //    });
            //    if (index >= 0)
            //        cbbJPAcc.SelectedIndex = index;
            //    else
            //    {
            //        m_oldJP = "";
            //    }
            //}
            if (m_oldVN != "")
            {
                int index = 0;
                index = clsGetDataCombobox.Instance().VNAcc.FindIndex(delegate(UserDTO st)
                {
                    return st.UserID == m_oldVN;
                });
                if (index >= 0)
                    cbbVNAcc.SelectedIndex = index;
                else
                {
                    m_oldVN = "";
                }
            }
            m_IsOnSetDataCombobox = false;

           
          
            
		}



		/// <summary>
		/// Get template to export
		/// 4.radDepositAveBal
		/// 5.radLoanAveBal
		/// 6.radCommissionAndFee
		/// 7.radForexProfit
		/// 8.radTotalProfit
		/// 9.radInterestDeposit
		/// 10.radInterestLoan
		/// 11.radDepositAveBalTop50
		/// 12.radLoanAveBalTop50
		/// 13.radTotalProfitTop50
		/// </summary>
		/// <returns>string template name</returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private string GetTemplateName()
		{
			if (rad_Report_On_Deposit_Average_Balance_By_Customer.Checked == true)
				return clsCPAConstant.REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER;
			if (rad_Report_On_Loan_Average_Balance_By_Customer.Checked == true)
				return clsCPAConstant.REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER;
			if (rad_Report_On_Commission_And_Fee_By_Customer.Checked == true)
				return clsCPAConstant.REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER;
			if (rad_Report_On_Forex_Profit_By_Customer.Checked == true)
				return clsCPAConstant.REPORT_ON_FOREX_PROFIT_BY_CUSTOMER;
			if (rad_Report_On_Total_Profit_By_Customer.Checked == true)
				return clsCPAConstant.REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER;
			if (rad_Report_On_Deposit_Profit_By_Customer.Checked == true)
				return clsCPAConstant.REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER;
			if (rad_Report_On_Loan_Profit_By_Customer.Checked == true)
				return clsCPAConstant.REPORT_ON_LOAN_PROFIT_BY_CUSTOMER;
			if (rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.Checked == true)
				return clsCPAConstant.REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE;
			if (rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.Checked == true)
				return clsCPAConstant.REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE;
			if (rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.Checked == true)
				return clsCPAConstant.TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT;
			return "";
		}
		
		/// <summary>
		/// Export to Excel file
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnExportExcel_Click(object sender, EventArgs e)
		{
            try
            {

                m_JnjID = cbbJNJ.Text;
                m_TeamID = cbbTeam.SelectedValue.ToString();
                m_DepartmentID = cbbDepartment.SelectedValue.ToString();
                m_CustomerID = txtCustomerCode.Text.Trim();
                m_CustomerName = txtCustomerFullName.Text.Trim();
                m_JPAccID = cbbJPAcc.SelectedValue.ToString();
                m_VNAccID = cbbVNAcc.SelectedValue.ToString();
                m_RealFrom = clsCommonFunctions.GetMonthYearFromInputToDatabase(clFromMonthYear.Text);

   
                ExportToExcel();
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
		}
	
		/// <summary>
		/// Get file name to export excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		 
		/// <summary>
		/// Get header name to export excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void GetHeaderName()
		{
			List<string> lstHeaderName;
			switch (m_radName)
			{
				///04
				case clsCPAConstant.R_L_REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER:
					GetHeaderNameReport_On_Deposit_Average_Balance_By_Customer();
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(m_RoughDate);
					break;
				///05
				case clsCPAConstant.R_L_REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER:
					GetHeaderNameReport_On_Deposit_Average_Balance_By_Customer();
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(m_RoughDate);
					break;
				///06
				case clsCPAConstant.R_L_REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER:
					GetHeaderNameReport_On_Commission_And_Fee_By_Customer();
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(m_RoughDate);
					break;
				///07
				case clsCPAConstant.R_L_REPORT_ON_FOREX_PROFIT_BY_CUSTOMER:
					GetHeaderNameReport_On_Commission_And_Fee_By_Customer();
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(m_RoughDate);
					break;
				///08
				case clsCPAConstant.R_L_REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER:
					GetHeaderNameReport_On_Total_Profit_By_Customer();
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(m_RoughDate);
					break;
				///09
				case clsCPAConstant.R_L_REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER:
					lstHeaderName = GetHeaderNameReport_On_Deposit_Profit_By_Customer();
					m_iColCount = lstHeaderName.Count;
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(lstHeaderName);
					break;
				///10
				case clsCPAConstant.R_L_REPORT_ON_LOAN_PROFIT_BY_CUSTOMER:
					lstHeaderName = GetHeaderNameReport_On_Loan_Profit_By_Customer();
					m_iColCount = lstHeaderName.Count;
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(lstHeaderName);
					break;
				///11
				case clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE:
					lstHeaderName = GetHeaderNameReport_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance();
					m_iColCount = lstHeaderName.Count;
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(lstHeaderName);
					break;
				///12
				case clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE:
					lstHeaderName = GetHeaderNameReport_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance();
					m_iColCount = lstHeaderName.Count;
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(lstHeaderName);
					break;
				///13
				case clsCPAConstant.R_L_TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT:
					lstHeaderName = GetHeaderNameTop_50_Customers_In_Terms_Of_Total_Profit();
					m_iColCount = lstHeaderName.Count;
					m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(lstHeaderName);
					break;
				default:
					m_arrHeaderName = null;
					m_iColCount = 0;
					break;
			}
		}

		/// <summary>
		/// Get date time value
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void GetDateTimeValue()
		{
			m_YearStart = clFromMonthYear.Text.Substring(clFromMonthYear.Text.IndexOf('/') + 1, 4);
			m_YearEnd = clToMonthYear.Text.Substring(clFromMonthYear.Text.IndexOf('/') + 1, 4);
			m_MonthStart = clFromMonthYear.Text.Substring(0, clFromMonthYear.Text.Length - 5);
			m_MonthEnd = clToMonthYear.Text.Substring(0, clToMonthYear.Text.Length - 5);
			m_DateFrom = m_YearStart + m_MonthStart;
			m_DateTo = m_YearEnd + m_MonthEnd;
			m_iMonthEnd = int.Parse(m_MonthEnd);
			m_iMonthStart = int.Parse(m_MonthStart);
			m_iYearEnd = int.Parse(m_YearEnd);
			m_iYearStart = int.Parse(m_YearStart);
			m_dDateFrom = new DateTime(m_iYearStart, m_iMonthStart, 1);
			m_dDateTo = new DateTime(m_iYearEnd, m_iMonthEnd, 1);
		}
	
		/// <summary>
		/// Get start date for cal total value rpt: 
		/// Report_On_Deposit_Average_Balance_By_Customer
		/// Report_On_Loan_Average_Balance_By_Customer
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond		 
		private void GetFromDateReport_On_Average_Balance_By_Customer()
		{
            if (m_iMonthStart <= 3)
            {
                m_iYearStart--;
                m_iDeleteMonthCount = m_iMonthStart - 4 + m_iMonthPerYear;
                m_iMonthStart = m_iPreMonth;
                m_MonthStart = m_iMonthStart.ToString("00");
                m_YearStart = m_iYearStart + "";
                m_dDateFrom = new DateTime(m_iYearStart, m_iMonthStart, 1);
                m_dDateTo = new DateTime(m_iYearEnd, m_iMonthEnd, 1);
                m_DateFrom = m_YearStart + "" + m_MonthStart;
                m_DateTo = m_YearEnd + m_MonthEnd;
            }
            else
            {
                m_iDeleteMonthCount = m_iMonthStart - 4;
                m_DateFrom = m_DateFrom = m_YearStart + "" + "04";
            }
			m_dDateFrom = new DateTime(m_iYearStart, m_iPreMonth, 1);
		}
		
		/// <summary>
		/// Get start date for cal total value rpt: 
		/// Report_On_Commission_And_Fee_By_Customer
		/// Report_On_Forex_Profit_By_Customer
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond		 
		private void GetFromDateReport_On_Commission_And_Fee_By_Customer()
		{
			GetDateTimeValue();
		}

		/// <summary>
		/// Get header name of report 
		/// Report_On_Deposit_Average_Balance_By_Customer
		/// Report_On_Loan_Average_Balance_By_Customer
		/// </summary>
		/// <returns>List<string> </returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond		 
		private void GetHeaderNameReport_On_Deposit_Average_Balance_By_Customer()
		{
			GetFromDateReport_On_Average_Balance_By_Customer();

			DateTime startDay = m_dDateFrom;
			DateTime endDay = m_dDateTo;
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * clsCPAConstant.MONTH_PER_YEAR + month;
			string temp = startDay.ToString("yyyyMM");
			m_RoughDate = new List<string>();
			m_RoughDate.Add(temp);
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);
				temp = startDay.ToString("yyyyMM");
				m_RoughDate.Add(temp);
				if (startDay.Month == 3)
					m_RoughDate.Add(clsCPAConstant.R_H_AVERAGE + " " + (startDay.Year - 1).ToString());
			}
			m_RoughDate.Add(clsCPAConstant.R_COL_CHANGE);
			m_RoughDate.Insert(0, clsCPAConstant.R_H_JNJ);
			m_RoughDate.Insert(0, clsCPAConstant.R_VN_ACCOUNT_OFFICER);
			m_RoughDate.Insert(0, clsCPAConstant.R_JP_ACCOUNT_OFFICER);
            m_RoughDate.Insert(0, clsCPAConstant.R_H_TEAM);

			m_RoughDate.Insert(0, clsCPAConstant.R_H_NAME);
			m_RoughDate.Insert(0, clsCPAConstant.R_H_CODE);
		}

		/// <summary>
		/// Get header name of report 
		/// Report_On_Commission_And_Fee_By_Customer
		/// Report_On_Forex_Profit_By_Customer
		/// </summary>
		/// <returns>List<string> </returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void GetHeaderNameReport_On_Commission_And_Fee_By_Customer()
		{
			GetFromDateReport_On_Commission_And_Fee_By_Customer();
			DateTime startDay = m_dDateFrom;
			DateTime endDay = m_dDateTo;
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * clsCPAConstant.MONTH_PER_YEAR + month;
			string temp = startDay.ToString("yyyyMM");
			m_RoughDate = new List<string>();
			m_RoughDate.Add(temp);
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);
				temp = startDay.ToString("yyyyMM");
				m_RoughDate.Add(temp);
			}
			m_RoughDate.Add(clsCPAConstant.REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER_INC_DES);
			m_RoughDate.Insert(0, clsCPAConstant.R_H_JNJ);
			m_RoughDate.Insert(0, clsCPAConstant.R_VN_ACCOUNT_OFFICER);
			m_RoughDate.Insert(0, clsCPAConstant.R_JP_ACCOUNT_OFFICER);
            m_RoughDate.Insert(0, clsCPAConstant.R_H_TEAM);
			m_RoughDate.Insert(0, clsCPAConstant.R_H_NAME);
			m_RoughDate.Insert(0, clsCPAConstant.R_H_CODE);
		}

		/// <summary>
		/// Get header name of Report_On_Total_Profit_By_Customer
		/// </summary>
		/// <returns>List<string> </returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond		
		private void GetHeaderNameReport_On_Total_Profit_By_Customer()
		{

        
            if (m_iMonthStart <= 3)
            {
                m_iYearStart--;
                m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4 + m_iMonthPerYear;
                m_DateFrom = (m_iYearStart) + m_iPreMonth.ToString("00");
            }
            else
            {
                m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4;
                m_DateFrom = m_iYearStart + m_iPreMonth.ToString("00");
            }

			m_dDateFrom = new DateTime(m_iYearStart, m_iPreMonth, 1);
			DateTime startDay = m_dDateFrom;
			DateTime endDay = m_dDateTo;
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * clsCPAConstant.MONTH_PER_YEAR + month;
			string temp = startDay.ToString("yyyyMM");
			m_RoughDate = new List<string>();
			m_RoughDate.Add(temp);
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);
				temp = startDay.ToString("yyyyMM");
				m_RoughDate.Add(temp);
				if (startDay.Month == 3)
				{
					m_RoughDate.Add(clsCPAConstant.R_H_TOTAL + " " + (startDay.Year - 1).ToString());
					m_RoughDate.Add(clsCPAConstant.R_H_AVERAGE + " " + (startDay.Year - 1).ToString());
				}
			}
			m_RoughDate.Add(clsCPAConstant.R_COL_CHANGE);
			m_RoughDate.Insert(0, clsCPAConstant.R_H_JNJ);
			m_RoughDate.Insert(0, clsCPAConstant.R_VN_ACCOUNT_OFFICER);
			m_RoughDate.Insert(0, clsCPAConstant.R_JP_ACCOUNT_OFFICER);
            m_RoughDate.Insert(0, clsCPAConstant.R_H_TEAM);
			m_RoughDate.Insert(0, clsCPAConstant.R_H_NAME);
			m_RoughDate.Insert(0, clsCPAConstant.R_H_CODE);
		}

		/// <summary>
		/// Get header name of Report_On_Deposit_Profit_By_Customer
		/// </summary>
		/// <returns>List<string></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		private List<string> GetHeaderNameReport_On_Deposit_Profit_By_Customer()
		{
			List<string> result = new List<string>();
			if (m_iMonthStart <= 3)
			{
				m_iYearStart--;
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4 + m_iMonthPerYear;
				m_DateFrom = (m_iYearStart) + m_iPreMonth.ToString("00");
			}
			else
			{
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4;
				m_DateFrom = m_iYearStart + m_iPreMonth.ToString("00");
			}
			m_dDateFrom = new DateTime(m_iYearStart, m_iPreMonth, 1);
			DateTime startDay = m_dDateFrom;
			DateTime endDay = m_dDateTo;
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * m_iMonthPerYear + month;

			result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(startDay.ToString("yyyyMM")));
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);
				string temp = startDay.ToString("yyyyMM");
				result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(temp));
				if (startDay.Month == 3)
				{
					result.Add(clsCPAConstant.R_H_TOTAL + " " + (startDay.Year - 1).ToString());
					result.Add(clsCPAConstant.R_H_AVERAGE + " " + (startDay.Year - 1).ToString());
				}
			}
			//Code	Name	JP Account Officer  VN Account Officer	JNJ			
			result.Insert(0, clsCPAConstant.R_H_JNJ);
			result.Insert(0, clsCPAConstant.R_VN_ACCOUNT_OFFICER);
			result.Insert(0, clsCPAConstant.R_JP_ACCOUNT_OFFICER);
            result.Insert(0, clsCPAConstant.R_H_TEAM);
			result.Insert(0, clsCPAConstant.R_H_NAME);
			result.Insert(0, clsCPAConstant.R_H_CODE);
			result.Add(clsCPAConstant.R_COL_CHANGE);

			return result;
		}

		/// <summary>
		/// Get header name of Report_On_Loan_Profit_By_Customer
		/// </summary>
		/// <returns>List<string></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		private List<string> GetHeaderNameReport_On_Loan_Profit_By_Customer()
		{
			List<string> result = new List<string>();
			if (m_iMonthStart <= 3)
			{
				m_iYearStart--;
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4 + m_iMonthPerYear;
				m_DateFrom = (m_iYearStart) + m_iPreMonth.ToString("00");
			}
			else
			{
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4;
				m_DateFrom = m_iYearStart + m_iPreMonth.ToString("00");
			}
			m_dDateFrom = new DateTime(m_iYearStart, m_iPreMonth, 1);
			DateTime startDay = m_dDateFrom;
			DateTime endDay = m_dDateTo;
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * m_iMonthPerYear + month;


			result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(startDay.ToString("yyyyMM")));
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);
				string temp = startDay.ToString("yyyyMM");
				result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(temp));
				if (startDay.Month == 3)
				{
					result.Add(clsCPAConstant.R_H_TOTAL + " " + (startDay.Year - 1).ToString());
					result.Add(clsCPAConstant.R_H_AVERAGE + " " + (startDay.Year - 1).ToString());
				}
			}
			//Code	Name	JP Account Officer  VN Account Officer	JNJ			
			result.Insert(0, clsCPAConstant.R_H_JNJ);
			result.Insert(0, clsCPAConstant.R_VN_ACCOUNT_OFFICER);
			result.Insert(0, clsCPAConstant.R_JP_ACCOUNT_OFFICER);
            result.Insert(0, clsCPAConstant.R_H_TEAM);
			result.Insert(0, clsCPAConstant.R_H_NAME);
			result.Insert(0, clsCPAConstant.R_H_CODE);
			result.Add(clsCPAConstant.R_COL_CHANGE);

			return result;
		}

		/// <summary>
		/// Get header name of Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance
		/// </summary>
		/// <returns>List<string></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		private List<string> GetHeaderNameReport_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance()
		{
			List<string> result = new List<string>();
			if (m_iMonthStart <= 3)
			{
				m_iYearStart--;
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4 + m_iMonthPerYear;
				m_DateFrom = (m_iYearStart) + m_iPreMonth.ToString("00");
			}
			else
			{
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4;
				m_DateFrom = m_iYearStart + m_iPreMonth.ToString("00");
			}
			m_dDateFrom = new DateTime(m_iYearStart, m_iPreMonth, 1);
			DateTime startDay = m_dDateFrom;
			DateTime endDay = m_dDateTo;
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * m_iMonthPerYear + month;

			result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(startDay.ToString("yyyyMM")));
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);
				string temp = startDay.ToString("yyyyMM");
				result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(temp));
				if (startDay.Month == 3)
				{
					
					result.Add(clsCPAConstant.R_H_AVERAGE + " " + (startDay.Year - 1).ToString());
				}
			}
			//			Code	Name	JNJ			
			result.Insert(0, clsCPAConstant.R_H_JNJ);
            result.Insert(0, clsCPAConstant.R_H_TEAM);
			result.Insert(0, clsCPAConstant.R_H_NAME);
			result.Insert(0, clsCPAConstant.R_H_CODE);
			return result;
		}

		/// <summary>
		/// Get header name of Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance
		/// </summary>
		/// <returns>List<string></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		private List<string> GetHeaderNameReport_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance()
		{
			List<string> result = new List<string>();
			if (m_iMonthStart <= 3)
			{
				m_iYearStart--;
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4 + m_iMonthPerYear;
				m_DateFrom = (m_iYearStart) + m_iPreMonth.ToString("00");
			}
			else
			{
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4;
				m_DateFrom = m_iYearStart + m_iPreMonth.ToString("00");
			}
			m_dDateFrom = new DateTime(m_iYearStart, m_iPreMonth, 1);
			DateTime startDay = m_dDateFrom;
			DateTime endDay = m_dDateTo;
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * m_iMonthPerYear + month;

			result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(startDay.ToString("yyyyMM")));
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);
				string temp = startDay.ToString("yyyyMM");
				result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(temp));
				if (startDay.Month == 3)
				{
					
					result.Add(clsCPAConstant.R_H_AVERAGE + " " + (startDay.Year - 1).ToString());
				}
			}
			//			Code	Name	JNJ			
			result.Insert(0, clsCPAConstant.R_H_JNJ);
            result.Insert(0, clsCPAConstant.R_H_TEAM);
			result.Insert(0, clsCPAConstant.R_H_NAME);
			result.Insert(0, clsCPAConstant.R_H_CODE);
			return result;
		}

		/// <summary>
		/// Get header name of Top_50_Customers_In_Terms_Of_Total_Profit
		/// </summary>
		/// <returns>List<string></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		private List<string> GetHeaderNameTop_50_Customers_In_Terms_Of_Total_Profit()
		{
			List<string> result = new List<string>();
			if (m_iMonthStart <= 3)
			{
				m_iYearStart--;
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4 + m_iMonthPerYear;
				m_DateFrom = (m_iYearStart) + m_iPreMonth.ToString("00");
			}
			else
			{
				m_iDeleteMonthCount = int.Parse(m_MonthStart) - 4;
				m_DateFrom = m_iYearStart + m_iPreMonth.ToString("00");
			}
			m_dDateFrom = new DateTime(m_iYearStart, m_iPreMonth, 1);
			DateTime startDay = m_dDateFrom;
			DateTime endDay = m_dDateTo;
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * m_iMonthPerYear + month;

			result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(startDay.ToString("yyyyMM")));
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);
				string temp = startDay.ToString("yyyyMM");
				result.Add(clsCommonFunctions.GetMonthYearShowOnExcel(temp));
				if (startDay.Month == 3)
				{
					result.Add(clsCPAConstant.R_H_TOTAL + " " + (startDay.Year - 1).ToString());
					//result.Add(CConstant.R_H_AVERAGE + " " + (startDay.Year - 1).ToString());
				}
			}
			//			Code	Name	JNJ			
			result.Insert(0, clsCPAConstant.R_H_JNJ);
            result.Insert(0, clsCPAConstant.R_H_TEAM);
			result.Insert(0, clsCPAConstant.R_H_NAME);
			result.Insert(0, clsCPAConstant.R_H_CODE);
			return result;
		}

		/// <summary>
		/// Get data for Report_On_Deposit_Average_Balance_By_Customer
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private object[,] GetDataForReport_On_Total_Profit_By_Customer(ref int iRow, int iCol)
		{
			List<clsCPAReport_On_Total_Profit_By_CustomerDTO> lstCustomer = new List<clsCPAReport_On_Total_Profit_By_CustomerDTO>();

			DataTable reader = m_rptBus.GetListCPAReportOnTotalProfitByCustomer(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID, ref iRow, ref lstCustomer, m_RealFrom);
			///get data
			object[,] data = new object[iRow, iCol];// + m_HeaderRowCount
			int iCustomerIdx = 0;
			for (int idxRow = 0; idxRow < iRow; idxRow++)
			{
				List<clsCPAReport_On_Total_Profit_By_CustomerDTO> subList = lstCustomer.Where(x => x.CustomerID == lstCustomer[iCustomerIdx].CustomerID).ToList();
				clsCPAReport_On_Total_Profit_By_CustomerDTO obj = lstCustomer[iCustomerIdx];
				iCustomerIdx += subList.Count;
				int iHeaderIdx = 0;
				data[idxRow, iHeaderIdx++] = obj.CustomerID;
				data[idxRow, iHeaderIdx++] = obj.CustomerName;
                data[idxRow, iHeaderIdx++] = obj.Team;
				data[idxRow, iHeaderIdx++] = obj.ShortJP;
				data[idxRow, iHeaderIdx++] = obj.ShortVN;
				data[idxRow, iHeaderIdx++] = obj.JNJ;
    
              
				int iSub = 0;
				long iTotal = 0;
				long iAverage = 0;
				for (int iRough = m_HeaderRowCount; iRough < iCol; iRough++)
				{
					if (m_RoughDate[iRough].Contains(clsCPAConstant.R_H_TOTAL))
					{

						data[idxRow, iRough++] = iTotal;// +"";/// CConstant.DAY_IN_YEAR + "";
						data[idxRow, iRough] = (double)iAverage / clsCPAConstant.MONTH_PER_YEAR;// +"";// / CConstant.MONTH_PER_YEAR + "";
						iAverage = 0;
						iTotal = 0;
						continue;
					}
					if (iSub < subList.Count)
					{
						obj = subList[iSub];

						if (obj.YearMonth == m_RoughDate[iRough])
						{
							long iCellValue = 0;
							if (obj.CPAStatus == 1 && !obj.ReportStatus)
								iCellValue = obj.CalItem;
							//average of  12 months ( [6] * The Numbers Of Days In Month) / 365
							iTotal += iCellValue;
							iAverage += iCellValue;
							data[idxRow, iRough] = iCellValue;// +"";
							iSub++;
						}
						else
							data[idxRow, iRough] = S_ZERO;
					}
					else
						data[idxRow, iRough] = S_ZERO;

				}
			}

			///calc data for column change  
			int jColCalCountChange = 0;		 
			object[,] arrDataCalcChange = new object[iRow, 2];
			string strHeaderText;
			int iRowCountChange = m_RoughDate.Count - 1;
			while (jColCalCountChange < 2 && iRowCountChange > m_HeaderRowCount)
			{
				strHeaderText = m_RoughDate[iRowCountChange];
				if (!(strHeaderText.Contains(clsCPAConstant.R_H_TOTAL) ||
					strHeaderText.Contains(clsCPAConstant.R_H_AVERAGE) ||
					strHeaderText.Contains(clsCPAConstant.R_COL_CHANGE)))
				{
					for (int idxRow = 0; idxRow < iRow; idxRow++)
						arrDataCalcChange[idxRow, jColCalCountChange] = data[idxRow, iRowCountChange];
					jColCalCountChange++;
				}
				iRowCountChange--;
			}
			//m_ExcelBase.ExportRange(iCol + 2, 5, iCol + 3, 4 + iRow, arrDataCalcChange);
			for (int iChange = 0; iChange < iRow; iChange++)
				data[iChange, m_RoughDate.Count - 1] = double.Parse(arrDataCalcChange[iChange, 0].ToString()) - double.Parse(arrDataCalcChange[iChange, 1].ToString());

			return data;
		}
	
		/// <summary>
		/// Get data for Report_On_Deposit_Profit_By_Customer
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Co Phuong
		/// @endcond
		private object[,] GetDataForReport_On_Deposit_Profit_By_Customer(ref int iRow, object[,] arrHeaderName)
		{
			clsReportBLL bll = new clsReportBLL();
			bll.GetListCPAReportOnDepositProfitByCustomer(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID, m_RealFrom);
			iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();

            object[,] data = new object[iRow, arrHeaderName.Length];

			int iResultIndex = 0;
			for (int i = 0; i < iRow; i++)
			{

				data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
				data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
				data[i, 3] = bll.ListCPACustomer[iResultIndex].ShortJP;
				data[i, 4] = bll.ListCPACustomer[iResultIndex].ShortVN;
				data[i, 5] = bll.ListCPACustomer[iResultIndex].JNJ;
            
				double iTotal = 0;
				float iAverage = 0;
				//Int64 iAverage = 0;
				for (int j = 6; j < arrHeaderName.Length; j++)
				{
					#region Write data to report excel

					if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_TOTAL))
					{
						data[i, j] = iTotal + "";
						data[i, j + 1] = ((float) iAverage / clsCPAConstant.MONTH_PER_YEAR).ToString(FORMAT_EXPORT_CELL);
						iTotal = 0;
						iAverage = 0;
						j++;
						continue;
						//j = j + 2;
					}

					if (iResultIndex < bll.ListCPACustomer.Count)
					{
						if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[iResultIndex].YearMonth))
							&& bll.ListCPACustomer[iResultIndex].CustomerID == (string)data[i, 0])
						{
							//show report and finalize
							if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[iResultIndex].ReportStatus)
							{
								data[i, j] = (double)bll.ListCPACustomer[iResultIndex].GetProfitDeposit();
								iAverage += bll.ListCPACustomer[iResultIndex].GetProfitDeposit();
								iTotal += (double)bll.ListCPACustomer[iResultIndex].GetProfitDeposit();
							}
							else
							{
								data[i, j] = 0;
							}
							iResultIndex++;
						}
						else
						{
							data[i, j] = 0;
						}

					}
					else
					{
						data[i, j] = 0;
					}
					#endregion
				}
			}
			int jColCalCountChange = 0;
			object[,] arrDataCalcChange = new object[iRow, 2];
			for (int i = 0; i < iRow; i++)
			{
				arrDataCalcChange[i, 0] = arrDataCalcChange[i, 1] = 0;
			}
			string strHeaderText;
			int iRowCountChange = arrHeaderName.Length - 2;
			while (jColCalCountChange < 2 && iRowCountChange > m_iDeleteMonthCount + m_HeaderRowCount - 1)
			{
				strHeaderText = arrHeaderName[0, iRowCountChange].ToString();
				if (!(strHeaderText.Contains(clsCPAConstant.R_H_TOTAL) ||
					strHeaderText.Contains(clsCPAConstant.R_H_AVERAGE) ||
					strHeaderText.Contains(clsCPAConstant.R_COL_CHANGE)))
				{
					for (int idxRow = 0; idxRow < iRow; idxRow++)
						arrDataCalcChange[idxRow, jColCalCountChange] = data[idxRow, iRowCountChange];
					jColCalCountChange++;
				}
				iRowCountChange--;
			}
			//m_ExcelBase.ExportRange(iCol + 2, 5, iCol + 3, 4 + iRow, arrDataCalcChange);
			for (int iChange = 0; iChange < iRow; iChange++)
				data[iChange, arrHeaderName.Length - 1] = double.Parse(arrDataCalcChange[iChange, 0].ToString()) - double.Parse(arrDataCalcChange[iChange, 1].ToString()) + "";

			return data;
		}

		/// <summary>
		/// Get data for Report_On_Loan_Average_Balance_By_Customer
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private object[,] GetDataForReport_On_Loan_Average_Balance_By_Customer(ref int iRow, int iCol)
		{
			List<clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO> lstCustomer = new List<clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO>();
			DataTable reader = m_rptBus.GetListCPAReportOnLoanAverageBalanceByCustomer(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID, ref iRow, ref lstCustomer, m_RealFrom);
			///get data
			object[,] data = new object[iRow, iCol];// + m_HeaderRowCount
			int iCustomerIdx = 0;
			for (int idxRow = 0; idxRow < iRow; idxRow++)
			{
				List<clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO> subList = lstCustomer.Where(x => x.CustomerID == lstCustomer[iCustomerIdx].CustomerID).ToList();
				clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO obj = lstCustomer[iCustomerIdx];
				iCustomerIdx += subList.Count;
				int iHeaderIdx = 0;
				data[idxRow, iHeaderIdx++] = obj.CustomerID;
				data[idxRow, iHeaderIdx++] = obj.CustomerName;
                data[idxRow, iHeaderIdx++] = obj.Team;
				data[idxRow, iHeaderIdx++] = obj.ShortJP;
				data[idxRow, iHeaderIdx++] = obj.ShortVN;
				data[idxRow, iHeaderIdx++] = obj.JNJ;
                

				int iSub = 0;
				long iTotal = 0;
				for (int iRough = m_HeaderRowCount; iRough < iCol - 1; iRough++)
				{
					if (m_RoughDate[iRough].Contains(clsCPAConstant.R_H_AVERAGE))
					{
						data[idxRow, iRough] = (double)iTotal / clsCPAConstant.DAY_IN_YEAR;// +"";
						iTotal = 0;
						continue;
					}
					if (iSub < subList.Count)
					{
						obj = subList[iSub];

						if (obj.YearMonth == m_RoughDate[iRough])
						{
							long iCellValue = 0;
							if (obj.CPAStatus == 1 && !obj.ReportStatus)
								iCellValue = obj.CalItem;
							//Sum of  12 months ( [6] * The Numbers Of Days In Month) / 365
							iTotal += iCellValue * (DateTime.DaysInMonth(m_CommonFunction.GetYear(obj.YearMonth), m_CommonFunction.GetMonth(obj.YearMonth)));
							data[idxRow, iRough] = iCellValue;// +"";
							iSub++;
						}
						else
							data[idxRow, iRough] = S_ZERO;
					}
					else
						data[idxRow, iRough] =  S_ZERO;

				}
			}
			///calc data for column change  
			int jColCalCountChange = 0;
			object[,] arrDataCalcChange = new object[iRow, 2];
			for (int i = 0; i < iRow; i++)
			{
				arrDataCalcChange[i, 0] = arrDataCalcChange[i, 1] = 0;
			}
			string strHeaderText;
			int iRowCountChange = m_RoughDate.Count - 2;
			while (jColCalCountChange < 2 && iRowCountChange > m_iDeleteMonthCount + m_HeaderRowCount - 1)
			{
				strHeaderText = m_RoughDate[iRowCountChange];
				if (!(strHeaderText.Contains(clsCPAConstant.R_H_TOTAL) ||
					strHeaderText.Contains(clsCPAConstant.R_H_AVERAGE) ||
					strHeaderText.Contains(clsCPAConstant.R_COL_CHANGE)))
				{
					for (int idxRow = 0; idxRow < iRow; idxRow++)
						arrDataCalcChange[idxRow, jColCalCountChange] = data[idxRow, iRowCountChange];
					jColCalCountChange++;
				}
				iRowCountChange--;
			}
			//m_ExcelBase.ExportRange(iCol + 2, 5, iCol + 3, 4 + iRow, arrDataCalcChange);
			for (int iChange = 0; iChange < iRow; iChange++)
				data[iChange, m_RoughDate.Count - 1] = double.Parse(arrDataCalcChange[iChange, 0].ToString()) - double.Parse(arrDataCalcChange[iChange, 1].ToString());

			


			return data;

		}

		/// <summary>
		/// Get data for Report_On_Commission_And_Fee_By_Customer
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private object[,] GetDataForReport_On_Commission_And_Fee_By_Customer(ref int iRow, int iCol)
		{
			List<clsCPAReport_On_Commission_And_Fee_By_CustomerDTO> lstCustomer = new List<clsCPAReport_On_Commission_And_Fee_By_CustomerDTO>();
			DataTable reader = m_rptBus.GetListCPAReportCommissionAndFeeByCustomer(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID, ref iRow, ref lstCustomer);
			///get data
			object[,] data = new object[iRow, iCol];// + m_HeaderRowCount
			int iCustomerIdx = 0;
			for (int idxRow = 0; idxRow < iRow; idxRow++)
			{
				List<clsCPAReport_On_Commission_And_Fee_By_CustomerDTO> subList = lstCustomer.Where(x => x.CustomerID == lstCustomer[iCustomerIdx].CustomerID).ToList();
				clsCPAReport_On_Commission_And_Fee_By_CustomerDTO obj = lstCustomer[iCustomerIdx];
				iCustomerIdx += subList.Count;
				int iHeaderIdx = 0;
				data[idxRow, iHeaderIdx++] = obj.CustomerID;
				data[idxRow, iHeaderIdx++] = obj.CustomerName;
                data[idxRow, iHeaderIdx++] = obj.Team;
				data[idxRow, iHeaderIdx++] = obj.ShortJP;
				data[idxRow, iHeaderIdx++] = obj.ShortVN;
				data[idxRow, iHeaderIdx++] = obj.JNJ;
               
				int iSub = 0;
				long iTotal = 0;
				for (int iRough = m_HeaderRowCount; iRough < iCol - 1; iRough++)
				{
					if (m_RoughDate[iRough].Contains(clsCPAConstant.R_H_TOTAL))
					{
                        data[idxRow, iRough] = (double)iTotal / clsCPAConstant.MONTH_PER_YEAR;// +"";Math.Round((double)iAverage / CConstant.DAY_IN_YEAR, 2)
						iTotal = 0;
						continue;
					}
					if (iSub < subList.Count)
					{
						obj = subList[iSub];

						if (obj.YearMonth == m_RoughDate[iRough])
						{
							long iCellValue = 0;
							if (obj.CPAStatus == 1 && !obj.ReportStatus)
								iCellValue = obj.CalItem;
							//Sum of  12 months ( [6] * The Numbers Of Days In Month) / 365
							iTotal += iCellValue ;
							data[idxRow, iRough] = iCellValue;// +"";
							iSub++;
						}
						else
							data[idxRow, iRough] = S_ZERO;
					}
					else
						data[idxRow, iRough] = S_ZERO;
				}
			}
			///cal for change column
			int iActualColumn = m_RoughDate.Count - m_HeaderRowCount;
			if (iActualColumn == 1)///no data to cal so set change = 0
				for (int i = 0; i < iRow; i++)
					data[i, m_RoughDate.Count - 1] = S_ZERO;
			else if (iActualColumn == 2)///there is only one actual column			
				for (int i = 0; i < iRow; i++)
					data[i, m_RoughDate.Count - 1] = data[i, m_RoughDate.Count - 2];
			else///there is more than 2 actual column
				for (int i = 0; i < iRow; i++)
					data[i, m_RoughDate.Count - 1] = double.Parse(data[i, m_RoughDate.Count - 2].ToString()) - double.Parse(data[i, m_RoughDate.Count - 3].ToString()) + "";

			return data;
		}

		/// <summary>
		/// Get data for Report_On_Forex_Profit_By_Customer
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private object[,] GetDataForReport_On_Forex_Profit_By_Customer(ref int iRow, int iCol)
		{
			List<clsCPAReport_On_Forex_Profit_By_CustomerDTO> lstCustomer = new List<clsCPAReport_On_Forex_Profit_By_CustomerDTO>();
			DataTable reader = m_rptBus.GetListCPAReportOnForexProfitByCustomer(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID, ref iRow, ref lstCustomer);
			///get data
			object[,] data = new object[iRow, iCol];// + m_HeaderRowCount
			int iCustomerIdx = 0;
			for (int idxRow = 0; idxRow < iRow; idxRow++)
			{
				List<clsCPAReport_On_Forex_Profit_By_CustomerDTO> subList = lstCustomer.Where(x => x.CustomerID == lstCustomer[iCustomerIdx].CustomerID).ToList();
				clsCPAReport_On_Forex_Profit_By_CustomerDTO obj = lstCustomer[iCustomerIdx];
				iCustomerIdx += subList.Count;
				int iHeaderIdx = 0;
				data[idxRow, iHeaderIdx++] = obj.CustomerID;
				data[idxRow, iHeaderIdx++] = obj.CustomerName;
                data[idxRow, iHeaderIdx++] = obj.Team;
				data[idxRow, iHeaderIdx++] = obj.ShortJP;
				data[idxRow, iHeaderIdx++] = obj.ShortVN;
				data[idxRow, iHeaderIdx++] = obj.JNJ;
                

				int iSub = 0;
				long iTotal = 0;
				for (int iRough = m_HeaderRowCount; iRough < iCol - 1; iRough++)
				{
					if (m_RoughDate[iRough].Contains(clsCPAConstant.R_H_TOTAL))
					{
						data[idxRow, iRough] = (double)iTotal / clsCPAConstant.MONTH_PER_YEAR;// +"";
						iTotal = 0;
						continue;
					}
					if (iSub < subList.Count)
					{
						obj = subList[iSub];

						if (obj.YearMonth == m_RoughDate[iRough])
						{
							long iCellValue = 0;
							if (obj.CPAStatus == 1 && !obj.ReportStatus)
								iCellValue = obj.CalItem;
							//Sum of  12 months ( [6] * The Numbers Of Days In Month) / 365
							iTotal += iCellValue;
							data[idxRow, iRough] = iCellValue;// +"";
							iSub++;
						}
						else
							data[idxRow, iRough] = S_ZERO;
					}
					else
						data[idxRow, iRough] = S_ZERO;

				}
				if (iCol < m_HeaderRowCount + 2)
					data[idxRow, iCol - 1] = S_ZERO;
				else
					if (iCol < m_HeaderRowCount + 3)
						data[idxRow, iCol - 1] = data[idxRow, iCol - 2];
					else
						data[idxRow, iCol - 1] = double.Parse(data[idxRow, iCol - 1 - 1].ToString()) - double.Parse(data[idxRow, iCol - 1 - 2].ToString()) + "";
			}
			return data;
		}

		/// <summary>
		/// Get data for Report_On_Deposit_Average_Balance_By_Customer
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private object[,] GetDataForReport_On_Deposit_Average_Balance_By_Customer(ref int iRow, int iCol)
		{
			List<clsCPAReport_On_Deposit_Average_Balance_By_CustomerDTO> lstCustomer = new List<clsCPAReport_On_Deposit_Average_Balance_By_CustomerDTO>();

			DataTable reader = m_rptBus.GetListCPAReportOnDepositAverageBalanceByCustomer(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID, ref iRow, ref lstCustomer, m_RealFrom);
			if (iRow == 0)
				return null;
			///get data
			object[,] data = new object[iRow, iCol];// + m_HeaderRowCount
			int iCustomerIdx = 0;
			for (int idxRow = 0; idxRow < iRow; idxRow++)
			{
				List<clsCPAReport_On_Deposit_Average_Balance_By_CustomerDTO> subList = lstCustomer.Where(x => x.CustomerID == lstCustomer[iCustomerIdx].CustomerID).ToList();
				clsCPAReport_On_Deposit_Average_Balance_By_CustomerDTO obj = lstCustomer[iCustomerIdx];
				iCustomerIdx += subList.Count;
				int iHeaderIdx = 0;
				data[idxRow, iHeaderIdx++] = obj.CustomerID;
				data[idxRow, iHeaderIdx++] = obj.CustomerName;
                data[idxRow, iHeaderIdx++] = obj.Team;
				data[idxRow, iHeaderIdx++] = obj.ShortJP;
				data[idxRow, iHeaderIdx++] = obj.ShortVN;
				data[idxRow, iHeaderIdx++] = obj.JNJ;


				int iSub = 0;
				long iAverage = 0;
				for (int iRough = m_HeaderRowCount; iRough < iCol - 1; iRough++)
				{
					if (m_RoughDate[iRough].Contains(clsCPAConstant.R_H_AVERAGE))
					{
                        data[idxRow, iRough] = (double)iAverage / clsCPAConstant.DAY_IN_YEAR;// +"";
						iAverage = 0;
						continue;
					}
					if (iSub < subList.Count)
					{
						obj = subList[iSub];

						if (obj.YearMonth == m_RoughDate[iRough])
						{
							Int64 iCellValue = 0;
							if (obj.CPAStatus == 1 && !obj.ReportStatus)
								iCellValue = obj.CalItem;
							//Sum of  12 months ( [6] * The Numbers Of Days In Month) / 365
							iAverage += iCellValue * (DateTime.DaysInMonth(m_CommonFunction.GetYear(obj.YearMonth), m_CommonFunction.GetMonth(obj.YearMonth)));
							data[idxRow, iRough] = iCellValue;// +"";
							iSub++;
						}
						else
							data[idxRow, iRough] = S_ZERO;
					}
					else
						data[idxRow, iRough] = S_ZERO;
				}
			}
			 
			///calc data for column change  
			int jColCalCountChange = 0;
			object[,] arrDataCalcChange = new object[iRow, 2];
			for (int i = 0; i < iRow; i++) {
				arrDataCalcChange[i, 0] = arrDataCalcChange[i, 1] = 0;
			}
			string strHeaderText;
			int iRowCountChange = m_RoughDate.Count - 2 ;
			while (jColCalCountChange < 2 && iRowCountChange > m_iDeleteMonthCount + m_HeaderRowCount-1)
			{
				strHeaderText = m_RoughDate[iRowCountChange];
				if (!(strHeaderText.Contains(clsCPAConstant.R_H_TOTAL) ||
					strHeaderText.Contains(clsCPAConstant.R_H_AVERAGE) ||
					strHeaderText.Contains(clsCPAConstant.R_COL_CHANGE)))
				{
					for (int idxRow = 0; idxRow < iRow; idxRow++)
						arrDataCalcChange[idxRow, jColCalCountChange] = data[idxRow, iRowCountChange];
					jColCalCountChange++;
				}
				iRowCountChange--;
			}
			//m_ExcelBase.ExportRange(iCol + 2, 5, iCol + 3, 4 + iRow, arrDataCalcChange);
			for (int iChange = 0; iChange < iRow; iChange++)
				data[iChange, m_RoughDate.Count - 1] = double.Parse(arrDataCalcChange[iChange, 0].ToString()) - double.Parse(arrDataCalcChange[iChange, 1].ToString());

			return data;
		}
	 
		/// <summary>
		/// Get year from YYYYMM string
		/// </summary>
		/// <param name="strDateTime"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private int GetYear(string strDateTime)
		{
			int iYear = 0;
			if (strDateTime.Trim().Length != 6)
				return iYear;
			iYear = int.Parse(strDateTime.Substring(0, 4));
			return iYear;
		}

		/// <summary>
		/// Get year from YYYYMM string
		/// </summary>
		/// <param name="strDateTime"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private int GetMonth(string strDateTime)
		{
			int iMonth = 0;
			if (strDateTime.Trim().Length != 6)
				return iMonth;
			iMonth = int.Parse(strDateTime.Substring(4, 2));
			return iMonth;
		}

		/// <summary>
		/// Get data for report
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private bool GetDataForReport()
		{
			switch (m_radName)
			{
				///04
				case clsCPAConstant.R_L_REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER:
					m_arrData = GetDataForReport_On_Deposit_Average_Balance_By_Customer(ref m_iRowCount, m_iColumnCount);
					break;
				///05
				case clsCPAConstant.R_L_REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER:
					m_arrData = GetDataForReport_On_Loan_Average_Balance_By_Customer(ref m_iRowCount, m_iColumnCount);
					break;
				///06
				case clsCPAConstant.R_L_REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER:
					m_arrData = GetDataForReport_On_Commission_And_Fee_By_Customer(ref m_iRowCount, m_iColumnCount);
					break;
				///07
				case clsCPAConstant.R_L_REPORT_ON_FOREX_PROFIT_BY_CUSTOMER:
					m_arrData = GetDataForReport_On_Forex_Profit_By_Customer(ref m_iRowCount, m_iColumnCount);
					break;
				///08
				case clsCPAConstant.R_L_REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER:
					m_arrData = GetDataForReport_On_Total_Profit_By_Customer(ref m_iRowCount, m_iColumnCount);
					break;
				///09
				case clsCPAConstant.R_L_REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER:
					m_arrData = GetDataForReport_On_Deposit_Profit_By_Customer(ref m_iRowCount, m_arrHeaderName);
					break;
				///10
				case clsCPAConstant.R_L_REPORT_ON_LOAN_PROFIT_BY_CUSTOMER:
					m_arrData = GetDataForReport_On_Loan_Profit_By_Customer(ref m_iRowCount, m_arrHeaderName);
					break;
				///11
				case clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE:					
					m_arrDataTop = GetDataTopForReport_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance(ref m_iRowCountDataTop, m_arrHeaderName, m_iTopJP, "JP");
					m_arrDataTotal = GetDataForReport_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance(ref m_iRowCountDataTotal, m_arrHeaderName);
					m_arrDataTop20 = GetDataTopForReport_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance(ref m_iRowCountDataTop20, m_arrHeaderName, m_iTopNJ, "NJ");
					m_iRowCount = (m_iRowCountDataTop + m_iRowCountDataTop20);
					break;
				///12
				case clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE:
                    m_arrDataTop = GetDataTopForReport_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance(ref m_iRowCountDataTop, m_arrHeaderName, m_iTopJP, "JP");
					m_arrDataTotal = GetDataForReport_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance(ref m_iRowCountDataTotal, m_arrHeaderName);
                    m_arrDataTop20 = GetDataTopForReport_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance(ref m_iRowCountDataTop20, m_arrHeaderName, m_iTopNJ, "NJ");
					m_iRowCount = (m_iRowCountDataTop + m_iRowCountDataTop20) ;
					break;
				///13
				case clsCPAConstant.R_L_TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT:
                    m_arrDataTop = GetDataTopForTop_50_Customers_In_Terms_Of_Total_Profit(ref m_iRowCountDataTop, m_arrHeaderName, m_iTopJP, "JP");
					m_arrDataTotal = GetDataForTop_50_Customers_In_Terms_Of_Total_Profit(ref m_iRowCountDataTotal, m_arrHeaderName);
                    m_arrDataTop20 = GetDataTopForTop_50_Customers_In_Terms_Of_Total_Profit(ref m_iRowCountDataTop20, m_arrHeaderName, m_iTopNJ, "NJ");
					m_iRowCount = (m_iRowCountDataTop + m_iRowCountDataTop20) ;
					break;
				default:
					m_iRowCount = 0;
					m_iColCount = 0;
					break;
			}
            if (m_iRowCount == 0)
            {
                m_isNoData = true;
                Complete();
                return false;
            }
            else
            {
               
                    List<string> cpas = clsFinalizeCPABus.CheckLackingCPA(m_DateFrom, m_DateTo);
                    if (cpas.Count > 0)
                        clsMesageCollection.ShowCPANotImportYet(cpas);
                
            }
			return true;
		}
		
		/// <summary>
		/// Get which report to export - radio name
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void GetRadName()
		{
			if (rad_Report_On_Deposit_Average_Balance_By_Customer.Checked == true)
			{				
				m_radName = clsCPAConstant.R_L_REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER;
				return;
			}
			if (rad_Report_On_Loan_Average_Balance_By_Customer.Checked == true)
			{				
				m_radName = clsCPAConstant.R_L_REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER;
				return;
			}
			if (rad_Report_On_Commission_And_Fee_By_Customer.Checked == true)
			{				
				m_radName = clsCPAConstant.R_L_REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER;
				return;
			}
			if (rad_Report_On_Forex_Profit_By_Customer.Checked == true)
			{
				m_radName = clsCPAConstant.R_L_REPORT_ON_FOREX_PROFIT_BY_CUSTOMER;
				return;
			}
			if (rad_Report_On_Total_Profit_By_Customer.Checked == true)
			{				
				m_radName = clsCPAConstant.R_L_REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER;
				return;
			}
			if (rad_Report_On_Deposit_Profit_By_Customer.Checked == true)
			{
				m_radName = clsCPAConstant.R_L_REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER;
				return;
			}
			if (rad_Report_On_Loan_Profit_By_Customer.Checked == true)
			{				
				m_radName = clsCPAConstant.R_L_REPORT_ON_LOAN_PROFIT_BY_CUSTOMER;
				return;
			}
			if (rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.Checked == true)
			{
				m_radName = clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE;
				return;
			}
			if (rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.Checked == true)
			{
				m_radName = clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE;
				return;
			}
			if (rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.Checked == true)
			{
				m_radName = clsCPAConstant.R_L_TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT;
				return;
			}
		}
		
		/// <summary>
		/// Export to excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void ExportToExcel()
		{
			///if user does not choose any item
			if (!(rad_Report_On_Deposit_Average_Balance_By_Customer.Checked ||
				rad_Report_On_Loan_Average_Balance_By_Customer.Checked ||
				rad_Report_On_Commission_And_Fee_By_Customer.Checked ||
				rad_Report_On_Forex_Profit_By_Customer.Checked ||
				rad_Report_On_Total_Profit_By_Customer.Checked ||
				rad_Report_On_Deposit_Profit_By_Customer.Checked ||
				rad_Report_On_Loan_Profit_By_Customer.Checked ||
				rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.Checked ||
				rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.Checked ||
				rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.Checked))
				return;
			GetRadName();
			GetDateTimeValue();
			GetHeaderName();
			m_iColumnCount = m_RoughDate.Count;
			///Get data for report
			if (!GetDataForReport())
				return;
			///get file name to export
			m_FileName = m_radName + m_rptBus.GetServerDate();

			//DialogResult result = clsCommonFunctions.ShowSaveExcelDialog(ref m_FileName);
			//if (result == DialogResult.Cancel)
			//    return;

			bool isOpen = false;
            m_ExcelBase = new ExcelBase(m_FileName, m_TemplateName, m_ProjectName, ref isOpen, m_rptBus.GetServerDate());
			if (isOpen)
				return;
			m_rptBus = new clsReportBLL();
			btnExportExcel.Enabled = false;
			m_isNoData = false;

			switch (m_radName)
			{
				///04
				case clsCPAConstant.R_L_REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER:
					m_worker = new CWorker(SaveReport_On_Deposit_Average_Balance_By_Customer, Complete);
					m_worker.Start();
					break;
				///05
				case clsCPAConstant.R_L_REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER:
					m_worker = new CWorker(SaveReport_On_Loan_Average_Balance_By_Customer, Complete);
					m_worker.Start();
					break;
				///06
				case clsCPAConstant.R_L_REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER:
					m_worker = new CWorker(SaveReport_On_Commission_And_Fee_By_Customer, Complete);
					m_worker.Start();
					break;
				///07
				case clsCPAConstant.R_L_REPORT_ON_FOREX_PROFIT_BY_CUSTOMER:
					m_worker = new CWorker(SaveReport_On_Forex_Profit_By_Customer, Complete);
					m_worker.Start();
					break;
				///08
				case clsCPAConstant.R_L_REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER:
					m_worker = new CWorker(SaveReport_On_Total_Profit_By_Customer, Complete);
					m_worker.Start();
					break;
				///09
				case clsCPAConstant.R_L_REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER:
					m_worker = new CWorker(SaveReport_On_Deposit_Profit_By_Customer, Complete);
					m_worker.Start();
					break;
				///10
				case clsCPAConstant.R_L_REPORT_ON_LOAN_PROFIT_BY_CUSTOMER:
					m_worker = new CWorker(SaveReport_On_Loan_Profit_By_Customer, Complete);
					m_worker.Start();
					break;
				///11
				case clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE:
					m_worker = new CWorker(SaveReport_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance, Complete);
					m_worker.Start();
					break;
				///12
				case clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE:
					m_worker = new CWorker(SaveReport_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance, Complete);
					m_worker.Start();
					break;
				///13
				case clsCPAConstant.R_L_TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT:
					m_worker = new CWorker(SaveTop_50_Customers_In_Terms_Of_Total_Profit, Complete);
					m_worker.Start();
					break;
			}
		}
		
		/// <summary>
		/// Export Report_On_Deposit_Average_Balance_By_Customer to excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// report 04
		/// @endcond
		private void SaveReport_On_Deposit_Average_Balance_By_Customer()
		{ 
			iNow = DateTime.Now.Second;
			m_ExcelBase.InsertText(2, 2, clsCPAConstant.R_L_REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER);
			int iColStart = 1;
			int iRowStart = 4;

			int iColEnd = iColStart + m_RoughDate.Count - 1;
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart++, m_arrHeaderName);

			if (m_iRowCount > 0)
			{
				int iRowEnd = m_iRowCount + iRowStart - 1;
				iColEnd = iColStart + m_RoughDate.Count - 1;
				excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);


                if (m_iDeleteMonthCount > 0)
                {
                    excRange = m_ExcelBase.GetRange(iColStart + m_HeaderRowCount, iRowStart - 1, m_iDeleteMonthCount + m_HeaderRowCount, iRowStart);
                    excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
                }
				m_ExcelBase.MergeCellTitle(2, 2, 12, 1);
				//m_ExcelBase.SaveFile();
			}
		}

		/// <summary>
		/// Export Report_On_Loan_Average_Balance_By_Customer to excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// Report 05
		/// @endcond
		private void SaveReport_On_Loan_Average_Balance_By_Customer()
		{ 
			iNow = DateTime.Now.Second;
			m_ExcelBase.InsertText(2, 2, clsCPAConstant.R_L_REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER);
			int iColStart = 1;
			int iRowStart = 4;

			int iColEnd = iColStart + m_RoughDate.Count - 1;
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart++, m_arrHeaderName);

			int iRowEnd = m_iRowCount + iRowStart - 1;
			iColEnd = iColStart + m_RoughDate.Count - 1;
			excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);
			if (m_iDeleteMonthCount > 0)
			{
				excRange = m_ExcelBase.GetRange(iColStart + m_HeaderRowCount, iRowStart - 1, m_iDeleteMonthCount + m_HeaderRowCount, iRowStart);
				excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
			}
			//m_ExcelBase.SaveFile();
		}

		/// <summary>
		/// Export Report_On_Commission_And_Fee_By_Customer to excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// Report 06
		/// @endcond
		private void SaveReport_On_Commission_And_Fee_By_Customer()
		{
			iNow = DateTime.Now.Second;
			m_ExcelBase.InsertText(2, 2, clsCPAConstant.R_L_REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER);
			int iColStart = 1;
			int iRowStart = 4;

			int iColEnd = iColStart + m_RoughDate.Count - 1;
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart++, m_arrHeaderName);

			int iRowEnd = m_iRowCount + iRowStart - 1;
			iColEnd = iColStart + m_RoughDate.Count - 1;
			excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);
//			//m_ExcelBase.SaveFile();
		}

		/// <summary>
		/// Export Report_On_Forex_Profit_By_Customer to excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// Report 07
		/// @endcond
		private void SaveReport_On_Forex_Profit_By_Customer()
		{ 
			iNow = DateTime.Now.Second;
			m_ExcelBase.InsertText(2, 2, clsCPAConstant.R_L_REPORT_ON_FOREX_PROFIT_BY_CUSTOMER);
			int iColStart = 1;
			int iRowStart = 4;

			int iColEnd = iColStart + m_RoughDate.Count - 1;
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart++, m_arrHeaderName);

			int iRowEnd = m_iRowCount + iRowStart - 1;
			iColEnd = iColStart + m_RoughDate.Count - 1;
			excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);

			//m_ExcelBase.SaveFile();
		}

		/// <summary>
		/// Export Report_On_Total_Profit_By_Customer to excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// Report 08
		/// @endcond
		private void SaveReport_On_Total_Profit_By_Customer()
		{ 
			iNow = DateTime.Now.Second;

			//export header
			m_ExcelBase.InsertText(2, 2, clsCPAConstant.R_L_REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER);
			int iColStart = 1;
			int iRowStart = 4;

			int iColEnd = iColStart + m_RoughDate.Count - 1;
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart++, m_arrHeaderName);

			//export data
			int iRowEnd = m_iRowCount + iRowStart - 1;
			iColEnd = iColStart + m_RoughDate.Count - 1;
			excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);

			//delete temp month
			if (m_iDeleteMonthCount > 0)
			{
				excRange = m_ExcelBase.GetRange(iColStart + m_HeaderRowCount, iRowStart - 1, m_iDeleteMonthCount + m_HeaderRowCount, iRowStart);
				excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
			}
			//m_ExcelBase.SaveFile();
		}

		/// <summary>
		/// Export Report_On_Deposit_Profit_By_Customer to excel
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// Report 09
		/// @endcond
		private void SaveReport_On_Deposit_Profit_By_Customer()
		{
			iNow = DateTime.Now.Second;
			// set title report
			m_ExcelBase.InsertText(2, 2, clsCPAConstant.R_L_REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER);

			int iColStart = 1;
			int iRowStart = 4;
			int iColEnd = iColStart + m_iColCount - 1;

			//export header
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart, m_arrHeaderName);

			//export data
			excRange = m_ExcelBase.ExportRange(iColStart, iRowStart + 1, iColEnd, iRowStart + m_iRowCount, m_arrData);

			//delete range excel by month count
			if (m_iDeleteMonthCount > 0)
			{
				excRange = m_ExcelBase.GetRange(iColStart + 6, iRowStart - 1, m_iDeleteMonthCount + 6, iRowStart + m_iRowCount);
				excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
			}
			//m_ExcelBase.SaveFile();
		}

		/// <summary>
		/// Export Report_On_Loan_Profit_By_Customer to excel
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// Report 10
		/// @endcond
		private void SaveReport_On_Loan_Profit_By_Customer()
		{
			iNow = DateTime.Now.Second;
			// set title report
			m_ExcelBase.InsertText(2, 2, clsCPAConstant.R_L_REPORT_ON_LOAN_PROFIT_BY_CUSTOMER); 

			int iColStart = 1;
			int iRowStart = 4;
			int iColEnd = iColStart + m_iColCount - 1;

			//export header
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart, m_arrHeaderName);

			//export data
			excRange = m_ExcelBase.ExportRange(iColStart, iRowStart + 1, iColEnd, iRowStart + m_iRowCount, m_arrData);

			//delete range excel by month count
			if (m_iDeleteMonthCount > 0)
			{
				excRange = m_ExcelBase.GetRange(iColStart + 6, iRowStart - 1, m_iDeleteMonthCount + 6, iRowStart + m_iRowCount);
				excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
			}
			//m_ExcelBase.SaveFile();
		}

		/// <summary>
		/// Export Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance to excel
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// Report 11
		/// @endcond 
		private void SaveReport_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance()
		{

			iNow = DateTime.Now.Second;
			// set title report
			m_ExcelBase.InsertText(2, 2,"REPORT ON TOP "+m_iTopJP.ToString() + clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE);
			m_ExcelBase.InsertText(2, 3, String.Format(clsCPAConstant.R_H_FROM_TO, clsCommonFunctions.GetMonthYearShowOnDataGrid(clsCommonFunctions.GetMonthYearFromInputToDatabase(clFromMonthYear.Text)),
                clsCommonFunctions.GetMonthYearShowOnDataGrid(clsCommonFunctions.GetMonthYearFromInputToDatabase(clToMonthYear.Text))));
			int iRowEnd = 0;
			int iColStart = 1;
			int iRowStart = 5;
			int iColEnd = iColStart + m_iColCount - 1;
			//int iRowCount = 0;
			int iDataTopCount = 0;
			//export header
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart, m_arrHeaderName);
			 object[,] dataRate = GetDataRateTopReport(iDataTopCount, m_arrDataTop, m_arrDataTotal, 50);
		   
            //export data top 50
            if (m_JnjID == "JP" || m_JnjID == "")
            {
                iDataTopCount = m_iRowCountDataTop;
                iRowStart = iRowStart + 1;
                iRowEnd = iRowStart + m_iRowCountDataTop;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTop);				
				m_ExcelBase.GetRange(iColStart, iRowEnd - 1, iColEnd, iRowEnd).Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                m_ExcelBase.MergeCell(1, iRowEnd, 4, 1, Excel.XlHAlign.xlHAlignCenter);
        
                //export data by condition search			
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTotal);

                //export data rate by condition search
                dataRate = GetDataRateTopReport(iDataTopCount, m_arrDataTop, m_arrDataTotal, m_iTopJP);

                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, dataRate);
                m_ExcelBase.MergeCell(1, iRowStart - 1, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                m_ExcelBase.MergeCell(1, iRowStart, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                iRowStart += 1;
            }

            if (m_JnjID == "NJ" || m_JnjID == "")
            {
                //export data top 20			
                iDataTopCount = m_iRowCountDataTop20;
                iRowStart = iRowStart + 1;
                iRowEnd = iRowStart + m_iRowCountDataTop20;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTop20);
				m_ExcelBase.GetRange(iColStart, iRowEnd - 1, iColEnd, iRowEnd).Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                m_ExcelBase.MergeCell(1, iRowEnd, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                //export data by condition search
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTotal);

                //export data rate by condition search
                dataRate = GetDataRateTopReport(iDataTopCount, m_arrDataTop20, m_arrDataTotal, m_iTopNJ);

                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, dataRate);
                m_ExcelBase.MergeCell(1, iRowStart - 1, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                m_ExcelBase.MergeCell(1, iRowStart, 4, 1, Excel.XlHAlign.xlHAlignCenter);
            }
			//delete range excel by month count
			if (m_iDeleteMonthCount > 0)
			{
				excRange = m_ExcelBase.GetRange(iColStart + 4, iRowStart - 1, m_iDeleteMonthCount + 4, iRowStart + iRowEnd);
				excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
			}
			//m_ExcelBase.SaveFile();
		}
		
		/// <summary>
		/// Export Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance to excel
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// Report 12
		/// @endcond
		private void SaveReport_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance()
		{
			iNow = DateTime.Now.Second;
			// set title report
			m_ExcelBase.InsertText(2, 2,"REPORT ON TOP "+m_iTopJP.ToString() + clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE);
			m_ExcelBase.InsertText(2, 3, String.Format(clsCPAConstant.R_H_FROM_TO, clsCommonFunctions.GetMonthYearShowOnDataGrid(clsCommonFunctions.GetMonthYearFromInputToDatabase(clFromMonthYear.Text)),
                clsCommonFunctions.GetMonthYearShowOnDataGrid(clsCommonFunctions.GetMonthYearFromInputToDatabase(clToMonthYear.Text))));
			int iRowEnd = 0;
			int iColStart = 1;
			int iRowStart = 5;
			int iColEnd = iColStart + m_iColCount - 1;
			//int iRowCount = 0;
			int iDataTopCount = 0;
			//export header
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart, m_arrHeaderName);
            if (m_JnjID == "JP" || m_JnjID == "")
            {
                //export data top 50
                iDataTopCount = m_iRowCountDataTop;
                iRowStart = iRowStart + 1;
                iRowEnd = iRowStart + m_iRowCountDataTop;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTop);
				m_ExcelBase.GetRange(iColStart, iRowEnd - 1, iColEnd, iRowEnd).Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                m_ExcelBase.MergeCell(1, iRowEnd, 4, 1, Excel.XlHAlign.xlHAlignCenter);
               
                //export data by condition search
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTotal);

                //export data rate by condition search
                object[,] dataRate = GetDataRateTopReport(iDataTopCount, m_arrDataTop, m_arrDataTotal, m_iTopJP);
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, dataRate);
                m_ExcelBase.MergeCell(1, iRowStart - 1, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                m_ExcelBase.MergeCell(1, iRowStart, 4, 1, Excel.XlHAlign.xlHAlignCenter);

                iRowStart += 1;
            }
            if (m_JnjID == "NJ" || m_JnjID == "")
            {
                //export data top 20
                iDataTopCount = m_iRowCountDataTop20;
                iRowStart = iRowStart + 1;
                iRowEnd = iRowStart + m_iRowCountDataTop20;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTop20);
				m_ExcelBase.GetRange(iColStart, iRowEnd - 1, iColEnd, iRowEnd).Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                m_ExcelBase.MergeCell(1, iRowEnd, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                //export data by condition search            
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTotal);

                //export data rate by condition search
                object[,]  dataRate = GetDataRateTopReport(iDataTopCount, m_arrDataTop20, m_arrDataTotal, m_iTopNJ);
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, dataRate);
                m_ExcelBase.MergeCell(1, iRowStart - 1, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                m_ExcelBase.MergeCell(1, iRowStart, 4, 1, Excel.XlHAlign.xlHAlignCenter);
            }		 
			//delete range excel by month count
			if (m_iDeleteMonthCount > 0)
			{
				excRange = m_ExcelBase.GetRange(iColStart + 4, iRowStart - 1, m_iDeleteMonthCount + 4, iRowStart + iRowEnd);
				excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
			}
			//m_ExcelBase.SaveFile();
		}
	
		/// <summary>
		/// Export Top_50_Customers_In_Terms_Of_Total_Profit to excel
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// Report 13
		/// @endcond
		private void SaveTop_50_Customers_In_Terms_Of_Total_Profit()
		{
			iNow = DateTime.Now.Second;
			// set title report
			m_ExcelBase.InsertText(2, 2,"REPORT ON TOP "+m_iTopJP.ToString()+ clsCPAConstant.R_L_TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT);
            m_ExcelBase.InsertText(2, 3, String.Format(clsCPAConstant.R_H_FROM_TO, clsCommonFunctions.GetMonthYearShowOnDataGrid(clsCommonFunctions.GetMonthYearFromInputToDatabase(clFromMonthYear.Text)),
                clsCommonFunctions.GetMonthYearShowOnDataGrid(clsCommonFunctions.GetMonthYearFromInputToDatabase(clToMonthYear.Text))));
			int iRowEnd = 0;
			int iColStart = 1;
			int iRowStart = 5;
			int iColEnd = iColStart + m_iColCount - 1;
			int iDataTopCount = 0;
			//export header
			Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart, m_arrHeaderName);
            if (m_JnjID == "JP" || m_JnjID == "")
            {
                //export data top 50
                iDataTopCount = m_iRowCountDataTop;
                iRowStart = iRowStart + 1;
                iRowEnd = iRowStart + m_iRowCountDataTop;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTop);
				m_ExcelBase.GetRange(iColStart, iRowEnd - 1, iColEnd, iRowEnd).Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                m_ExcelBase.MergeCell(1, iRowEnd, 4, 1, Excel.XlHAlign.xlHAlignCenter);
               
                //export data by condition search			
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTotal);

                //export data rate by condition search
                object[,] dataRate = GetDataRateTopReport(iDataTopCount, m_arrDataTop, m_arrDataTotal, m_iTopJP);
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, dataRate);
                m_ExcelBase.MergeCell(1, iRowStart - 1, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                m_ExcelBase.MergeCell(1, iRowStart, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                iRowStart += 1;
            }
            if (m_JnjID == "NJ" || m_JnjID == "")
            {
                //export data top 20			
                iDataTopCount = m_iRowCountDataTop20;
                iRowStart = iRowStart + 1;
                iRowEnd = iRowStart + m_iRowCountDataTop20;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTop20);
				m_ExcelBase.GetRange(iColStart, iRowEnd - 1, iColEnd, iRowEnd).Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                m_ExcelBase.MergeCell(1, iRowEnd, 4, 1, Excel.XlHAlign.xlHAlignCenter);
               
                //export data by condition search            
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrDataTotal);

                //export data rate by condition search
                object[,] dataRate = GetDataRateTopReport(iDataTopCount, m_arrDataTop20, m_arrDataTotal, m_iTopNJ);
                iRowStart = iRowEnd + 1;
                iRowEnd = iRowStart;
                excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, dataRate);
                m_ExcelBase.MergeCell(1, iRowStart - 1, 4, 1, Excel.XlHAlign.xlHAlignCenter);
                m_ExcelBase.MergeCell(1, iRowStart, 4, 1, Excel.XlHAlign.xlHAlignCenter);
            }
			//delete range excel by month count
			if (m_iDeleteMonthCount > 0)
			{
				excRange = m_ExcelBase.GetRange(iColStart + 4, iRowStart - 1, m_iDeleteMonthCount + 4, iRowStart + iRowEnd);
				excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
			}
			//m_ExcelBase.SaveFile();
		}

		/// <summary>
		/// Get data for Report_On_Loan_Profit_By_Customer
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Co Phuong
		/// @endcond
		private object[,] GetDataForReport_On_Loan_Profit_By_Customer(ref int iRow, object[,] arrHeaderName)
		{
            clsReportBLL bll = new clsReportBLL();
            bll.GetListCPAReportOnLoanProfitByCustomer(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID, m_RealFrom);
            iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();

            object[,] data = new object[iRow, arrHeaderName.Length];

            int iResultIndex = 0;
            for (int i = 0; i < iRow; i++)
            {

                data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
                data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
                data[i, 3] = bll.ListCPACustomer[iResultIndex].ShortJP;
                data[i, 4] = bll.ListCPACustomer[iResultIndex].ShortVN;
                data[i, 5] = bll.ListCPACustomer[iResultIndex].JNJ;
                
                long iTotal = 0;
                float iAverage = 0;
                //Int64 iAverage = 0;
                for (int j = 6; j < arrHeaderName.Length; j++)
                {
                    #region Write data to report excel

					if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_TOTAL))
                    {
                        data[i, j] = iTotal + "";
                        data[i, j + 1] = ((float)iAverage / clsCPAConstant.MONTH_PER_YEAR).ToString(FORMAT_EXPORT_CELL);
                        iTotal = 0;
                        iAverage = 0;
                        j++;
                        continue;
                        //j = j + 2;
                    }

                    if (iResultIndex < bll.ListCPACustomer.Count)
                    {
                        if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[iResultIndex].YearMonth))
                            && bll.ListCPACustomer[iResultIndex].CustomerID == (string)data[i, 0])
                        {
                            //show report and finalize
                            if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[iResultIndex].ReportStatus)
                            {
                                data[i, j] = bll.ListCPACustomer[iResultIndex].GetProfitOfLoan();
                                iAverage += bll.ListCPACustomer[iResultIndex].GetProfitOfLoan();
                                iTotal += bll.ListCPACustomer[iResultIndex].GetProfitOfLoan();
                            }
                            else
                            {
                                data[i, j] = 0;
                            }
                            iResultIndex++;
                        }
                        else
                        {
                            data[i, j] = 0;
                        }

                    }
                    else
                    {
                        data[i, j] = 0;
                    }
                    #endregion
                }
            }
            int jColCalCountChange = 0;
            object[,] arrDataCalcChange = new object[iRow, 2];
            for (int i = 0; i < iRow; i++)
            {
                arrDataCalcChange[i, 0] = arrDataCalcChange[i, 1] = 0;
            }
            string strHeaderText;
            int iRowCountChange = arrHeaderName.Length - 2;
            while (jColCalCountChange < 2 && iRowCountChange > m_iDeleteMonthCount + m_HeaderRowCount - 1)
            {
				strHeaderText = arrHeaderName[0, iRowCountChange].ToString();
                if (!(strHeaderText.Contains(clsCPAConstant.R_H_TOTAL) ||
                    strHeaderText.Contains(clsCPAConstant.R_H_AVERAGE) ||
                    strHeaderText.Contains(clsCPAConstant.R_COL_CHANGE)))
                {
                    for (int idxRow = 0; idxRow < iRow; idxRow++)
                        arrDataCalcChange[idxRow, jColCalCountChange] = data[idxRow, iRowCountChange];
                    jColCalCountChange++;
                }
                iRowCountChange--;
            }
            //m_ExcelBase.ExportRange(iCol + 2, 5, iCol + 3, 4 + iRow, arrDataCalcChange);
            for (int iChange = 0; iChange < iRow; iChange++)
                data[iChange, arrHeaderName.Length - 1] = double.Parse(arrDataCalcChange[iChange, 0].ToString()) - double.Parse(arrDataCalcChange[iChange, 1].ToString()) + "";

            return data;
            //clsReportBLL bll = new clsReportBLL();
          
		}
		
		/// <summary>
		/// Get data for top Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Co Phuong
		/// @endcond
		private object[,] GetDataTopForReport_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance(ref int iRow, object[,] arrHeaderName, int iTop, string jnj)
		{
			clsReportBLL bll = new clsReportBLL();
			bll.GetListTopCPAReportOnTopCustomerInTermDepositAverageBalance(m_DateFrom, m_DateTo, jnj, iTop,txtCustomerCode.Text.Trim(),txtCustomerFullName.Text.Trim(),m_DepartmentID,m_TeamID,m_JPAccID,m_VNAccID,m_RealFrom);
			iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();

			//phong 
			List<int> lstIndex = new List<int>();
			string cusId = "";
			if (bll.ListCPACustomer.Count > 0) cusId = bll.ListCPACustomer[0].CustomerID;
			lstIndex.Add(0);
			for (int i = 0; i < bll.ListCPACustomer.Count; i++)
			{
				if (bll.ListCPACustomer[i].CustomerID != cusId)
				{

					lstIndex.Add(i);
					cusId = bll.ListCPACustomer[i].CustomerID;
				}
			}

			//<--phong
            object[,] data = new object[iRow + 1, arrHeaderName.Length];
			data[iRow, 1] = String.Format(clsCPAConstant.R_TOTAL_TOP, iTop);
			int iResultIndex = 0;
			for (int i = 0; i < iRow; i++)
			{
				//phong : new algorithm
				if (i != 0)
					iResultIndex = lstIndex[i];

				data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
				data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
				data[i, 3] = bll.ListCPACustomer[iResultIndex].JNJ;
            
				Int64 iTotal = 0;
				for (int j = 4; j < arrHeaderName.Length; j++)
				{
					int count = 0;
					#region Write data to report excel
					try
					{
						count = lstIndex[i + 1];
					}
					catch (Exception ex)
					{
						count = bll.ListCPACustomer.Count;
					}
					for (int k = lstIndex[i]; k < count; k++)
					{
						if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[k].YearMonth))
							&& bll.ListCPACustomer[k].CustomerID == (string)data[i, 0])
						{
							//show report and finalize
							if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[k].ReportStatus )
							{
								data[i, j] = (double)bll.ListCPACustomer[k].Report_Value;
								iTotal += bll.ListCPACustomer[k].Report_Value * DateTime.DaysInMonth(GetYear(bll.ListCPACustomer[k].YearMonth), GetMonth(bll.ListCPACustomer[k].YearMonth));
							}
							else
							{
								data[i, j] = S_ZERO;
							}

							if (data[iRow, j] == null)
							{
								data[iRow, j] = data[i, j];
							}
							else
							{
                                data[iRow, j] = (double)data[iRow, j] + (double)data[i, j];
							}


							iResultIndex++;
							break;
						}
						else
						{
							data[i, j] = S_ZERO;
                            if (data[iRow, j]== null)
                            {
                                data[iRow, j] = data[i, j];
                            }
                          //  data[iRow, j] = (Convert.ToDouble(data[iRow, j]) + Convert.ToDouble(data[i, j])).ToString(FORMAT_EXPORT_CELL);
						}
					}


					if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_AVERAGE))
					{
						data[i, j] =  (double)iTotal / clsCPAConstant.DAY_IN_YEAR;
						if (data[iRow, j] == null)
						{
							data[iRow, j] = data[i, j];
						}
						else
						{
                            data[iRow, j] = (double)data[iRow, j] + (double)data[i, j];
						}
						iTotal = 0;
						continue;
					}
					//<--phong 
					//if (iResultIndex < bll.ListCPACustomer.Count)
					//{
					//    if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[iResultIndex].YearMonth))
					//        && bll.ListCPACustomer[iResultIndex].CustomerID == data[i, 0])
					//    {
					//        //show report and finalize
					//        if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[iResultIndex].ReportStatus)
					//        {
					//            data[i, j] = (bll.ListCPACustomer[iResultIndex].Report_Value).ToString(FORMAT_EXPORT_CELL);
					//            iTotal += bll.ListCPACustomer[iResultIndex].Report_Value * DateTime.DaysInMonth(GetYear(bll.ListCPACustomer[iResultIndex].YearMonth), GetMonth(bll.ListCPACustomer[iResultIndex].YearMonth));
					//        }
					//        else
					//        {
					//            data[i, j] = S_ZERO;
					//        }

					//        if (String.IsNullOrEmpty(data[iRow, j]))
					//        {
					//            data[iRow, j] = data[i, j];
					//        }
					//        else
					//        {
					//            data[iRow, j] = (Convert.ToDouble(data[iRow, j]) + Convert.ToDouble(data[i, j])).ToString(FORMAT_EXPORT_CELL);
					//        }


					//        iResultIndex++;
					//    }
					//    else
					//    {
					//        data[i, j] = S_ZERO;
					//        data[iRow, j] = S_ZERO;
					//    }
					//}
					//else
					//{
					//    data[i, j] = S_ZERO;
					//}

					#endregion
				}
			}

			return data;
		}

		/// <summary>
		/// Get data for Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Co Phuong
		/// @endcond
		private object[,] GetDataForReport_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance(ref int iRow, object[,] arrHeaderName)
		{
			clsReportBLL bll = new clsReportBLL();
            bll.GetListCPAReportTopCustomerInTermOfDepositAverageBalance(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID, m_RealFrom);
			iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();
            //phong
            List<int> lstIndex = new List<int>();
            string cusId = "";
            if (bll.ListCPACustomer.Count > 0)
                cusId = bll.ListCPACustomer[0].CustomerID;
            lstIndex.Add(0);
            for (int i = 0; i < bll.ListCPACustomer.Count; i++)
            {
                if (bll.ListCPACustomer[i].CustomerID != cusId)
                {
                    lstIndex.Add(i);
                    cusId = bll.ListCPACustomer[i].CustomerID;
                }
            }
			//<--phong
			object[,] data = new object[iRow, arrHeaderName.Length];
			object[,] dataTotal = new object[1, arrHeaderName.Length];
			dataTotal[0, 1] = clsCPAConstant.R_H_TOTAL;
			int iResultIndex = 0;
			for (int i = 0; i < iRow; i++)
			{
				//phong
				if (i != 0)
					iResultIndex = lstIndex[i];
				//<--
				data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
				data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
				data[i, 3] = bll.ListCPACustomer[iResultIndex].JNJ;
                
				double iTotal = 0;
				for (int j = 4; j < arrHeaderName.Length; j++)
				{
					#region Write data to report excel

					if (dataTotal[0, j] == null)
					{
						dataTotal[0, j] = S_ZERO;
					}
					if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_AVERAGE))
					{
						data[i, j] = (double) iTotal / clsCPAConstant.DAY_IN_YEAR;
						if (dataTotal[0, j]==null)
						{
							dataTotal[0, j] = data[i, j];
						}
						else
						{
							dataTotal[0, j] = (double)dataTotal[0, j] + (double)data[i, j];
						}
						iTotal = 0;
						continue;
					}
					if (iResultIndex < bll.ListCPACustomer.Count)
					{
						if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[iResultIndex].YearMonth))
							&& bll.ListCPACustomer[iResultIndex].CustomerID == (string)data[i, 0])
						{
							//show report and finalize
							if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[iResultIndex].ReportStatus)
							{
								data[i, j] = (double) bll.ListCPACustomer[iResultIndex].GetTermsOfDepositAverageBalance();
								if (dataTotal[0, j] == null)
								{
									dataTotal[0, j] = data[i, j];
								}
								else
								{
									dataTotal[0, j] = (double)dataTotal[0, j] + (double)data[i, j];
								}
								iTotal += bll.ListCPACustomer[iResultIndex].GetTermsOfDepositAverageBalance() * DateTime.DaysInMonth(GetYear(bll.ListCPACustomer[iResultIndex].YearMonth), GetMonth(bll.ListCPACustomer[iResultIndex].YearMonth));
							}
							else
							{
								data[i, j] = S_ZERO;
							}
							iResultIndex++;
						}
						else
						{
							data[i, j] = S_ZERO;
						}
					}
					else
					{
						data[i, j] = S_ZERO;
					}

					#endregion
				}
			}
			return dataTotal;
		}

		/// <summary>
		/// Get data rate for Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance
		/// Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance
		/// Top_50_Customers_In_Terms_Of_Total_Profit
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Co Phuong
		/// @endcond
		private object[,] GetDataRateTopReport(int iCountDataTop,object[,] dataTop, object[,] dataTotal, int iTop)
		{
			object[,] data = new object[1, dataTotal.Length];
            data[0, 1] = string.Format(clsCPAConstant.R_TOTAL_RATE, iTop);
			for (int i = 4; i < dataTotal.Length; i++)
			{
				if (Convert.ToDouble(dataTotal[0, i]) == 0)
				{
					data[0, i] = S_ZERO;
				}
				else
				{
					data[0, i] = (double)dataTop[iCountDataTop, i]/ (double)dataTotal[0, i] * 100;
				}
			}
			return data;
		}
		
		/// <summary>
		/// Get data for top Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Co Phuong
		/// @endcond
		private object[,] GetDataTopForReport_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance(ref int iRow, object[,] arrHeaderName, int iTop, string jnj)
		{
			clsReportBLL bll = new clsReportBLL();
            bll.GetListTopCPAReportOnTopCustomerInTermOfLoanAverageBalance(m_DateFrom, m_DateTo, jnj, iTop,txtCustomerCode.Text.Trim(), txtCustomerFullName.Text.Trim(), m_DepartmentID, m_TeamID, m_JPAccID, m_VNAccID,m_RealFrom);
			iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();
			//phong
			List<int> lstIndex = new List<int>();
			string cusId = "";
			if (bll.ListCPACustomer.Count > 0)
				cusId = bll.ListCPACustomer[0].CustomerID;
			lstIndex.Add(0);
			for (int i = 0; i < bll.ListCPACustomer.Count; i++)
			{
				if (bll.ListCPACustomer[i].CustomerID != cusId)
				{

					lstIndex.Add(i);
					cusId = bll.ListCPACustomer[i].CustomerID;
				}
			}
			//<--phong
			object[,] data = new object[iRow + 1, arrHeaderName.Length];
			data[iRow, 1] = String.Format(clsCPAConstant.R_TOTAL_TOP, iTop);
			int iResultIndex = 0;
			for (int i = 0; i < iRow; i++)
			{
				//phong : new algorithm
				if (i != 0)
					iResultIndex = lstIndex[i];

				data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
				data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
				data[i, 3] = bll.ListCPACustomer[iResultIndex].JNJ;
               
				Int64 iTotal = 0;
				for (int j = 4; j < arrHeaderName.Length; j++)
				{
					int count = 0;
					#region Write data to report excel
					try
					{
						count = lstIndex[i + 1];
					}
					catch (Exception ex)
					{
						count = bll.ListCPACustomer.Count;
					}
					for (int k = lstIndex[i]; k < count; k++)
					{
						if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[k].YearMonth))
							&& bll.ListCPACustomer[k].CustomerID == (string)data[i, 0])
						{
							//show report and finalize
							if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[k].ReportStatus)
							{
								data[i, j] = (double)bll.ListCPACustomer[k].Report_Value;
								iTotal += bll.ListCPACustomer[k].Report_Value * DateTime.DaysInMonth(GetYear(bll.ListCPACustomer[k].YearMonth), GetMonth(bll.ListCPACustomer[k].YearMonth));
							}
							else
							{
								data[i, j] = S_ZERO;
							}

							if (data[iRow, j] == null)
							{
								data[iRow, j] = data[i, j];
							}
							else
							{
								data[iRow, j] =(double)data[iRow, j] + (double)data[i, j];
							}


							iResultIndex++;
							break;
						}
						else
						{
							data[i, j] = S_ZERO;
                            if (data[iRow, j] ==null)
                            {
                                data[iRow, j] = data[i, j];
                            }
							//data[iRow, j] = S_ZERO;
						}
					}


					if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_AVERAGE))
					{
						data[i, j] = (double)iTotal / clsCPAConstant.DAY_IN_YEAR;
						if (data[iRow, j] == null)
						{
							data[iRow, j] = data[i, j];
						}
						else
						{
							data[iRow, j] = (double)data[iRow, j] +(double)data[i, j];
						}
						iTotal = 0;
						continue;
					}
					//<--phong 
					//if (iResultIndex < bll.ListCPACustomer.Count)
					//{
					//    if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[iResultIndex].YearMonth))
					//        && bll.ListCPACustomer[iResultIndex].CustomerID == data[i, 0])
					//    {
					//        //show report and finalize
					//        if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[iResultIndex].ReportStatus)
					//        {
					//            data[i, j] = (bll.ListCPACustomer[iResultIndex].Report_Value).ToString(FORMAT_EXPORT_CELL);
					//            iTotal += bll.ListCPACustomer[iResultIndex].Report_Value * DateTime.DaysInMonth(GetYear(bll.ListCPACustomer[iResultIndex].YearMonth), GetMonth(bll.ListCPACustomer[iResultIndex].YearMonth));
					//        }
					//        else
					//        {
					//            data[i, j] = S_ZERO;
					//        }

					//        if (String.IsNullOrEmpty(data[iRow, j]))
					//        {
					//            data[iRow, j] = data[i, j];
					//        }
					//        else
					//        {
					//            data[iRow, j] = (Convert.ToDouble(data[iRow, j]) + Convert.ToDouble(data[i, j])).ToString(FORMAT_EXPORT_CELL);
					//        }


					//        iResultIndex++;
					//    }
					//    else
					//    {
					//        data[i, j] = S_ZERO;
					//        data[iRow, j] = S_ZERO;
					//    }
					//}
					//else
					//{
					//    data[i, j] = S_ZERO;
					//}
                    //if (iResultIndex < bll.ListCPACustomer.Count)
                    //{
                    //    if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[iResultIndex].YearMonth))
                    //        && bll.ListCPACustomer[iResultIndex].CustomerID == data[i, 0])
                    //    {
                    //        //show report and finalize
                    //        if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[iResultIndex].ReportStatus)
                    //        {
                    //            data[i, j] = (bll.ListCPACustomer[iResultIndex].GetTermsOfDepositAverageBalance()).ToString(FORMAT_EXPORT_CELL);
                    //            if (String.IsNullOrEmpty(dataTotal[0, j]))
                    //            {
                    //                dataTotal[0, j] = data[i, j];
                    //            }
                    //            else
                    //            {
                    //                dataTotal[0, j] = (Convert.ToDouble(dataTotal[0, j]) + Convert.ToDouble(data[i, j])).ToString(FORMAT_EXPORT_CELL);
                    //            }
                    //            iTotal += bll.ListCPACustomer[iResultIndex].GetTermsOfDepositAverageBalance() * DateTime.DaysInMonth(GetYear(bll.ListCPACustomer[iResultIndex].YearMonth), GetMonth(bll.ListCPACustomer[iResultIndex].YearMonth));
                    //        }
                    //        else
                    //        {
                    //            data[i, j] = S_ZERO;
                    //        }
                    //        iResultIndex++;
                    //    }
                    //    else
                    //    {
                    //        data[i, j] = S_ZERO;
                    //    }
                    //}
                    //else
                    //{
                    //    data[i, j] = S_ZERO;
                    //}

					#endregion
				}
			}

			return data;
		}

		/// <summary>
		/// Get data for Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Co Phuong
		/// @endcond
		private object[,] GetDataForReport_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance(ref int iRow, object[,] arrHeaderName)
		{
			clsReportBLL bll = new clsReportBLL();
			bll.GetListCPAReportOnTopCustomerInTermOfLoanAverageBalance(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID,m_RealFrom);
			iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();
			object[,] data = new object[iRow, arrHeaderName.Length];
			object[,] dataTotal = new object[1, arrHeaderName.Length];
			dataTotal[0, 1] = clsCPAConstant.R_H_TOTAL;
			int iResultIndex = 0;
			for (int i = 0; i < iRow; i++)
			{
				data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
				data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
				data[i, 3] = bll.ListCPACustomer[iResultIndex].JNJ;
             
				Int64 iTotal = 0;
				for (int j = 4; j < arrHeaderName.Length; j++)
				{
					#region Write data to report excel

					if (dataTotal[0, j] == null)
					{
						dataTotal[0, j] = S_ZERO;
					}
					if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_AVERAGE))
					{
						data[i, j] = (double) iTotal / clsCPAConstant.DAY_IN_YEAR;
						if (dataTotal[0, j] == null)
						{
							dataTotal[0, j] = data[i, j];
						}
						else
						{
							dataTotal[0, j] = (double)dataTotal[0, j] + (double)data[i, j];
						}
						iTotal = 0;
						continue;
					}
					if (iResultIndex < bll.ListCPACustomer.Count)
					{
						if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[iResultIndex].YearMonth))
							&& bll.ListCPACustomer[iResultIndex].CustomerID == (string)data[i, 0])
						{
							//show report and finalize
							if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[iResultIndex].ReportStatus)
							{
								data[i, j] = (double)bll.ListCPACustomer[iResultIndex].GetTermsOfLoanAverageBalance();
								if (dataTotal[0, j] == null)
								{
									dataTotal[0, j] = data[i, j];
								}
								else
								{
									dataTotal[0, j] = (double)dataTotal[0, j] +(double)data[i, j];
								}
								iTotal += bll.ListCPACustomer[iResultIndex].GetTermsOfLoanAverageBalance() * DateTime.DaysInMonth(GetYear(bll.ListCPACustomer[iResultIndex].YearMonth), GetMonth(bll.ListCPACustomer[iResultIndex].YearMonth));
							}
							else
							{
								data[i, j] = S_ZERO;
							}
							iResultIndex++;
						}
						else
						{
							data[i, j] = S_ZERO;
						}
					}
					else
					{
						data[i, j] = S_ZERO;
					}
					#endregion
				}
			}
			return dataTotal;
		}
		
		/// <summary>
		/// Get data for top Top_50_Customers_In_Terms_Of_Total_Profit
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Co Phuong
		/// @endcond
		private object[,] GetDataTopForTop_50_Customers_In_Terms_Of_Total_Profit(ref int iRow, object[,] arrHeaderName, int iTop, string jnj)
		{
			clsReportBLL bll = new clsReportBLL();
            bll.GetListTopCPAReportOnTopCustomerInTermOfTotalProfit(m_DateFrom, m_DateTo, jnj, iTop, txtCustomerCode.Text.Trim(), txtCustomerFullName.Text.Trim(), m_DepartmentID, m_TeamID, m_JPAccID, m_VNAccID,m_RealFrom);
			iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();
			//phong
			List<int> lstIndex = new List<int>();
			string cusId = "";
			if (bll.ListCPACustomer.Count > 0)
				cusId = bll.ListCPACustomer[0].CustomerID;
			lstIndex.Add(0);
			for (int i = 0; i < bll.ListCPACustomer.Count; i++)
			{
				if (bll.ListCPACustomer[i].CustomerID != cusId)
				{

					lstIndex.Add(i);
					cusId = bll.ListCPACustomer[i].CustomerID;
				}
			}
			//<--phong

			object[,] data = new object[iRow + 1, arrHeaderName.Length];
			data[iRow, 1] = String.Format(clsCPAConstant.R_TOTAL_TOP, iTop);
			int iResultIndex = 0;
			for (int i = 0; i < iRow; i++)
			{
				//phong : new algorithm
				if (i != 0)
					iResultIndex = lstIndex[i];

				data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
				data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
				data[i, 3] = bll.ListCPACustomer[iResultIndex].JNJ;
               
				Int64 iTotal = 0;
				for (int j = 4; j < arrHeaderName.Length; j++)
				{
					int count = 0;
					#region Write data to report excel
					try
					{
						count = lstIndex[i + 1];
					}
					catch (Exception ex)
					{
						count = bll.ListCPACustomer.Count;
					}
					for (int k = lstIndex[i]; k < count; k++)
					{
						if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[k].YearMonth))
							&& bll.ListCPACustomer[k].CustomerID == (string)data[i, 0])
						{
							//show report and finalize
							if (bll.ListCPACustomer[k].CPAStatus == 1 && !bll.ListCPACustomer[k].ReportStatus)
							{
								data[i, j] = (double)bll.ListCPACustomer[k].Report_Value;
								iTotal += bll.ListCPACustomer[k].Report_Value;
							}
							else
							{
								data[i, j] = S_ZERO;
							}

							if (data[iRow, j] == null)
							{
								data[iRow, j] = data[i, j];
							}
							else
							{
								data[iRow, j] = (double)data[iRow, j] +(double)data[i, j];
							}


							iResultIndex++;
							break;
						}
						else
						{
							data[i, j] = S_ZERO;
                            if (data[iRow, j] == null)
                            {
                                data[iRow, j] = data[i, j];
                            }
							//data[iRow, j] = S_ZERO;
						}
					}


                    if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_TOTAL))
					{
						data[i, j] = (double) iTotal;
						if (data[iRow, j] == null)
						{
							data[iRow, j] = data[i, j];
						}
						else
						{
							data[iRow, j] = (double)data[iRow, j] +(double)data[i, j];
						}
						iTotal = 0;
						continue;
					}
					//<--phong 
					//if (iResultIndex < bll.ListCPACustomer.Count)
					//{
					//    if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[iResultIndex].YearMonth))
					//        && bll.ListCPACustomer[iResultIndex].CustomerID == data[i, 0])
					//    {
					//        //show report and finalize
					//        if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[iResultIndex].ReportStatus)
					//        {
					//            data[i, j] = (bll.ListCPACustomer[iResultIndex].Report_Value).ToString(FORMAT_EXPORT_CELL);
					//            iTotal += bll.ListCPACustomer[iResultIndex].Report_Value * DateTime.DaysInMonth(GetYear(bll.ListCPACustomer[iResultIndex].YearMonth), GetMonth(bll.ListCPACustomer[iResultIndex].YearMonth));
					//        }
					//        else
					//        {
					//            data[i, j] = S_ZERO;
					//        }

					//        if (String.IsNullOrEmpty(data[iRow, j]))
					//        {
					//            data[iRow, j] = data[i, j];
					//        }
					//        else
					//        {
					//            data[iRow, j] = (Convert.ToDouble(data[iRow, j]) + Convert.ToDouble(data[i, j])).ToString(FORMAT_EXPORT_CELL);
					//        }


					//        iResultIndex++;
					//    }
					//    else
					//    {
					//        data[i, j] = S_ZERO;
					//        data[iRow, j] = S_ZERO;
					//    }
					//}
					//else
					//{
					//    data[i, j] = S_ZERO;
					//}

					#endregion
				}
			}

			return data;
		}

		/// <summary>
		/// Get data for Top_50_Customers_In_Terms_Of_Total_Profit
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Co Phuong
		/// @endcond
		private object[,] GetDataForTop_50_Customers_In_Terms_Of_Total_Profit(ref int iRow, object[,] arrHeaderName)
		{
			clsReportBLL bll = new clsReportBLL();
			bll.GetListCPAReportOnTopCustomerInTermOfTotalProfit(m_DateFrom, m_DateTo, m_CustomerID, m_CustomerName, m_DepartmentID, m_TeamID, m_JnjID, m_VNAccID, m_JPAccID,m_RealFrom);
			iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();
			object[,] data = new object[iRow, arrHeaderName.Length];
			object[,] dataTotal = new object[1, arrHeaderName.Length];
			dataTotal[0, 1] = clsCPAConstant.R_H_TOTAL;
			int iResultIndex = 0;
			for (int i = 0; i < iRow; i++)
			{
				data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
				data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
				data[i, 3] = bll.ListCPACustomer[iResultIndex].JNJ;
                
				Int64 iTotal = 0;
				for (int j = 4; j < arrHeaderName.Length; j++)
				{
					#region Write data to report excel

					if (dataTotal[0, j] == null)
					{
						dataTotal[0, j] = S_ZERO;
					}
					if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_TOTAL))
					{
						data[i, j] =(double) iTotal;
						if (dataTotal[0, j] == null)
						{
							dataTotal[0, j] = data[i, j];
						}
						else
						{
							dataTotal[0, j] = (double)dataTotal[0, j] +(double)data[i, j];
						}
						iTotal = 0;
						continue;
					}
					if (iResultIndex < bll.ListCPACustomer.Count)
					{
						if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[iResultIndex].YearMonth))
							&& bll.ListCPACustomer[iResultIndex].CustomerID == (string)data[i, 0])
						{
							//show report and finalize
							if (bll.ListCPACustomer[iResultIndex].CPAStatus == 1 && !bll.ListCPACustomer[iResultIndex].ReportStatus)
							{
								data[i, j] = (double)bll.ListCPACustomer[iResultIndex].GetTotalProfit();
								if (dataTotal[0, j] == null)
								{
									dataTotal[0, j] = data[i, j];
								}
								else
								{
									dataTotal[0, j] =(double)dataTotal[0, j] + (double)data[i, j];
								}
								iTotal += bll.ListCPACustomer[iResultIndex].GetTotalProfit();
							}
							else
							{
								data[i, j] = S_ZERO;
							}
							iResultIndex++;
						}
						else
						{
							data[i, j] = S_ZERO;
						}
					}
					else
					{
						data[i, j] = S_ZERO;
					}
					#endregion
				}
			}
			return dataTotal;
		}
		
		/// <summary>
		/// Handling when completed a thread
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void Complete()
		{
			btnExportExcel.Enabled = true;
			
			if (m_isNoData == true)
			{
                clsMesageCollection.MessageNoTransactions();
			}
			else
			{
				m_ExcelBase.SaveFile();
				
			}
            if(m_worker != null)
                 m_worker.Stop();

		}

		/// <summary>
		/// Check input month year
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private bool CheckMonthYear()
		{
			string strFromMY = clFromMonthYear.Text;
			string strToMY = clToMonthYear.Text;
			if (strFromMY == "" || strToMY == "")
				return false;
			if (strFromMY.Length < 6 || strToMY.Length < 6)
				return false;
			int iMonthFrom = int.Parse(strFromMY.Substring(0, strFromMY.Length - 5));
			int iMonthTo = int.Parse(strToMY.Substring(0, strToMY.Length - 5));
			int iYearFrom = int.Parse(strFromMY.Substring(strFromMY.Length - 5 + 1, 4));
			int iYearTo = int.Parse(strToMY.Substring(strToMY.Length - 5 + 1, 4));
			int iYearCurrent = DateTime.Now.Year;
			int iMonthCurrent = DateTime.Now.Month;
			if (iYearCurrent < iYearFrom || iYearCurrent < iYearTo)
				return false;
			if (iYearCurrent == iYearFrom && iMonthFrom > iMonthCurrent)
				return false;
			if (iYearCurrent == iYearTo && iMonthTo > iMonthCurrent)
				return false;

			if (iYearTo < iYearFrom)
				return false;
			if (iYearTo == iYearFrom && iMonthTo < iMonthFrom)
				return false;

			return true;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void radDepositAveBal_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER;
			m_TemplateName = clsCPAConstant.REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void radLoanAveBal_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER;
			m_TemplateName = clsCPAConstant.REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void radCommissionAndFee_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER;
			m_TemplateName = clsCPAConstant.REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void radForexProfit_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_REPORT_ON_FOREX_PROFIT_BY_CUSTOMER;
			m_TemplateName = clsCPAConstant.REPORT_ON_FOREX_PROFIT_BY_CUSTOMER;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void radTotalProfit_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER;
			m_TemplateName = clsCPAConstant.REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void radInterestDeposit_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER;
			m_TemplateName = clsCPAConstant.REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void radInterestLoan_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_REPORT_ON_LOAN_PROFIT_BY_CUSTOMER;
			m_TemplateName = clsCPAConstant.REPORT_ON_LOAN_PROFIT_BY_CUSTOMER;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void radDepositAveBalTop50_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE;
			m_TemplateName = clsCPAConstant.REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void radLoanAveBalTop50_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE;
			m_TemplateName = clsCPAConstant.REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE;
		}

		/// <summary>
		/// Set value for template name
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void radTotalProfitTop50_CheckedChanged(object sender, EventArgs e)
		{
			m_radName = clsCPAConstant.R_L_TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT;
			m_TemplateName = clsCPAConstant.TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT;
		}

		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label1_Click(object sender, EventArgs e)
		{
			radDepositAveBal_CheckedChanged(sender, e);
			rad_Report_On_Deposit_Average_Balance_By_Customer.Checked = true;
		}

		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label2_Click(object sender, EventArgs e)
		{
			radLoanAveBal_CheckedChanged(sender, e);
			rad_Report_On_Loan_Average_Balance_By_Customer.Checked = true; 
		}

		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label3_Click(object sender, EventArgs e)
		{
			radCommissionAndFee_CheckedChanged(sender, e);
			rad_Report_On_Commission_And_Fee_By_Customer.Checked = true;
		}

		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label4_Click(object sender, EventArgs e)
		{
			radForexProfit_CheckedChanged(sender, e);
			rad_Report_On_Forex_Profit_By_Customer.Checked = true;
		}

		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label5_Click(object sender, EventArgs e)
		{
			radTotalProfit_CheckedChanged(sender, e);
			rad_Report_On_Total_Profit_By_Customer.Checked = true;
		}

		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label6_Click(object sender, EventArgs e)
		{
			radInterestDeposit_CheckedChanged(sender, e);
			rad_Report_On_Deposit_Profit_By_Customer.Checked = true;
		}

		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label7_Click(object sender, EventArgs e)
		{
			radInterestLoan_CheckedChanged(sender, e);
			rad_Report_On_Loan_Profit_By_Customer.Checked = true;
		}

		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label8_Click(object sender, EventArgs e)
		{
			radDepositAveBalTop50_CheckedChanged(sender, e);
			rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.Checked = true;
		}
        
		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label9_Click(object sender, EventArgs e)
		{
			radLoanAveBalTop50_CheckedChanged(sender, e);
			rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.Checked = true;
		}

		/// <summary>
		/// Call radio CheckedChanged function
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void label10_Click(object sender, EventArgs e)
		{
			radTotalProfitTop50_CheckedChanged(sender, e);
			rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.Checked = true;
		}

		/// <summary>
		/// Close this form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		/// <summary>
		/// Load Form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void frmScreenReportMonth_Load(object sender, EventArgs e)
		{ }

        private void cbbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            
                SetDataCombobox(((DepartmentDTO)cbbDepartment.SelectedItem).DepartmentID, "");
            
           
        }

        private void cbbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (m_IsOnSetDataCombobox == false)
            {
                m_oldTeam = ((SectionDTO)cbbTeam.SelectedItem).SectionID;
                SetDataCombobox(((DepartmentDTO)cbbDepartment.SelectedItem).DepartmentID, ((SectionDTO)cbbTeam.SelectedItem).SectionID);
            }
        }

        private void cbbVNAcc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(m_IsOnSetDataCombobox == false)
            m_oldVN = ((UserDTO)cbbVNAcc.SelectedItem).UserID;
        }

        private void cbbJPAcc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (m_IsOnSetDataCombobox == false)
            m_oldJP = ((UserDTO)cbbJPAcc.SelectedItem).UserID;
        }

		
		  
	}
}