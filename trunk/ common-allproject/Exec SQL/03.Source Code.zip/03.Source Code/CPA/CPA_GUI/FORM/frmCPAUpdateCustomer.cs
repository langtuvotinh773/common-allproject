﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Update CPA Screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Common;
using Phoenix.Cpa.Dto;
using Config.Classes;
using Phoenix.Common.Functions;

namespace Phoenix.Cpa.Gui.Forms
{

    /// <summary>
    /// Update customer transaction
    /// Phong: In Charge at 2/2013
    /// </summary>
    public partial class frmUpdateCustomerTransaction : MasterForm
    {
        #region Data member
        string[] LogName = { "Overdraft Ave.Balance", "Commercial Bill Ave.Balance", "Loan Ave.Balance","Overdraft Int Receivable", "Commercial Bill Int Receivable", "Loan Int Receivable", "Overdraft Int Payable", "Commercial Bill Int Payable", "Loan Int Payable", "L/T Loan (Fixed) Ave.Balance", 
                            "L/T Loan (Float) Ave.Balance", "L/T Loan (Fixed) Int Receivable", "L/T Loan (Float) Int Receivable", "L/T Loan (Fixed) Int Payable", "L/T Loan (Float) Int Payable", "B/B Ave.Balance", "B/R Ave.Balance", "B/B Int Receivable", "B/R Int Receivable", "B/B Int Payable",
                            "B/R Int Payable", "Other Application Ave.Balance", "Other Application Int Receivable", "Other Application Int Payable", "Depo (Liquid) Ave.Balance", "Depo (Fixed) Ave.Balance", "Depo (Liquid) Int Receivable", "Depo (Fixed) Int Receivable", "Depo (Liquid) Int Payable", "Depo (Fixed) Int Payable",
                            "Other Source Ave.Balance", "Other Source Int Receivable", "Other Source Int Payable", "Reserve Ave.Balance", "Reserve Int Receivable", "Reserve Int Payable", "Guaranteet Ave.Balance", "Clean L/Ct Ave.Balance", "Acceptancet Ave.Balance", "Commitmentt Ave.Balance",
                            "Otherst Ave.Balance", "Guarantee Income", "Clean L/C Income", "Acceptance Income", "Commitment Income", "Others Income", "Doc L/C Monthly Turnover", "Exp Bill Handling Monthly Turnover", "Imp bill Handling Monthly Turnover", "Collecting Monthly Turnover",
                            "Payment Monthly Turnover", "Remittance Monthly Turnover", "Loan Monthly Turnover", "Others Monthly Turnover", "FX Profit/Loss Monthly Turnover","Others Monthly Turnover", "Doc L/C Income", "Exp Bill Handling Income", "Imp bill Handling Income", "Collecting Income",
                            "Payment Income", "Remittance Income", "Loan Income", "Others Income", "FX Profit/Loss Income","Others Income","Not Show In Report","","","","","","","","","",""};
        List<TextBox> editTextBoxs = null;
        private clsUpdateCustomerTransBLL m_BLL = null;
        private DataTable m_Table;
       
        private bool m_IsBtnSaveClicked = false;
        private string[] m_SearchConditions;
        private DataTable m_NewTable;
        
        #endregion

        #region Constructor, common functions

        /// <summary>
        /// Initializes a new instance of the <see cref="frmUpdateCustomerTransaction" /> class.
        /// </summary>
        /// <param name="searchConditions">The search conditions.</param>
        public frmUpdateCustomerTransaction(string[] searchConditions)
        {
            InitializeComponent();
            SetSecurity();

            // Get search conditions
            m_SearchConditions = searchConditions;
            editTextBoxs = GetEditableTextBoxs();
           
            
        }
        protected override void OnShown(EventArgs e)
        {
            for (int i = 0; i < editTextBoxs.Count; i++)
            {
                tb_LostFocus(editTextBoxs[i]);
            }
            base.OnShown(e);
        }

        /// <summary>
        /// Gets the editable textboxs.
        /// </summary>
        /// <returns></returns>
        private List<TextBox> GetEditableTextBoxs()
        {
            editTextBoxs = new List<TextBox>();
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl.Name.Contains("textbox"))
                    editTextBoxs.Add(ctrl as TextBox);
            }
            editTextBoxs.Sort(delegate(TextBox t1, TextBox t2)
            {
                int s1 = int.Parse(t1.Name.Substring(7));
                int s2 = int.Parse(t2.Name.Substring(7));
                return s1.CompareTo(s2);
            });
            return editTextBoxs;
        }

        /// <summary>
        /// Fills the data to controls.
        /// </summary>
        /// <param name="dt">The dt.</param>
        private void FillDataToControls(DataTable dt)
        {
            int columnsCount = 71;
            // Clear any bound data to editable controls before re-bind
            foreach (TextBox tb in editTextBoxs)
            {
                tb.DataBindings.Clear();
            }
            ckbNotShow.DataBindings.Clear();
            // Bind data to editable controls
            for (int i = 2; i < columnsCount - 3; i++)
            {
                editTextBoxs[i - 2].DataBindings.Add("text", dt, dt.Columns[i].ColumnName);
               
            }
            ckbNotShow.DataBindings.Add("checked", dt, dt.Columns[columnsCount - 3].ColumnName);
        }

        /// <summary>
        /// Saves the history.
        /// </summary>
        private void SaveHistory(clsUpdateCustomerTransBLL bus)
        {
            // Save history
            clsCPALogBase log = new clsCPALogBase();
            log.Key = txtMonthYear.Text + " " + txtCustCode.Text;
            log.UserID = clsUserInfo.UserNo.ToString();
            log.ApplicationName = this.Text;
            log.Action = (int)CommonValue.ActionType.Update;

            // Save revision history
                
                DataRow custRow = m_Table.Rows[0];

                DataRow newRow = m_NewTable.Rows[0];
                for (int i = 2; i < 68; i++)
                {


                    string oldValue = custRow[i].ToString();
                    string newValue = (Int64.Parse(((string)newRow[i]).Replace(",", string.Empty))).ToString();

                    if (!oldValue.Equals(newValue))
                    {
                        log.LstLogInformation.Add(new clsCPALogInformation
                        {

                            FieldName = LogName[i-2],
                            OldValue = oldValue,
                            NewValue = newValue
                        });
                    }
                }
                string oldvl = custRow[68].ToString();
                string newvl = ((string)newRow[68]).Replace(",", string.Empty);
                if (!oldvl.Equals(newvl))
                {
                    log.LstLogInformation.Add(new clsCPALogInformation
                    {

                        FieldName = LogName[68 - 2],
                        OldValue = oldvl,
                        NewValue = newvl
                    });
                }
                log.WirteLog(bus.m_DAL);
            
        }

        /// <summary>
        /// Indicates if there is no transaction found.
        /// </summary>
        private void IndicateNoTransaction()
        {
            clsCommonFunctions.ShowWarningDialog(clsCPACommonMessage.NO_TRANSACTION_FOUND);
            ckbNotShow.DataBindings.Clear();
            ckbNotShow.Enabled = false;
            btnSave.Enabled = false;
            foreach (TextBox tb in editTextBoxs)
            {
                tb.DataBindings.Clear();
                tb.Enabled = false;
            }
        }

        #endregion

        #region Event functions

        /// <summary>
        /// Handles the Load event of the frmUpdateCustomerTransaction control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void frmUpdateCustomerTransaction_Load(object sender, EventArgs e)
        {
            SetFormStyle();
            // Set readonly texboxs color
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is TextBox)
                {
                    TextBox tb = (ctrl as TextBox);
                    if (tb.Name != "textbox" && tb.ReadOnly)
                    {
                        tb.BackColor = clsCommonStyles.Instance().ReadOnlyTextBoxBG;
                    }
                }
            }

            // Get data from db based on search conditions
            if (m_SearchConditions.Length == 3)
            {
                // Fill customer information to controls
                txtCustCode.Text = m_SearchConditions[0];
                txtCustFullName.Text = m_SearchConditions[1];
                txtMonthYear.Text = clsCommonFunctions.GetMonthYearShowOnDataGrid(m_SearchConditions[2]);

                // Setup textbox controls event and validation
                foreach (TextBox tb in editTextBoxs)
                {
                    clsCommonFunctions.SetTextLengthOfTextBox(tb, 10);
                    tb.Enter += new EventHandler(tb_Enter);
                    tb.KeyPress += new KeyPressEventHandler(tb_KeyPress);
                    tb.LostFocus += new EventHandler(tb_LostFocus);
                }
                // Get transaction data and fill to editable controls
                m_BLL = new clsUpdateCustomerTransBLL();
                m_Table = m_BLL.GetTransactionData(txtCustCode.Text, m_SearchConditions[2]);
               // m_BLL.Commit();
                if (m_Table.Rows.Count > 0)
                {
                    m_NewTable = m_Table.Clone();
                    for (int i = 0; i < m_NewTable.Columns.Count; i++)
                    {
                        m_NewTable.Columns[i].DataType = typeof(string);

                    }
                    m_NewTable.Rows.Add();

                    for (int i = 2; i < 68; i++)
                    {
                        try
                        {
                            m_NewTable.Rows[0][i] = ((Int64)m_Table.Rows[0][i]).ToString();
                        }
                        catch (Exception)
                        {
                            m_Table.Rows[0][i] = 0;
                            m_NewTable.Rows[0][i] = 0;
                        }

                    }
                    m_NewTable.Rows[0][68] = m_Table.Rows[0][68];
                    clsCPACustomerDTO dto = new clsCPACustomerDTO(m_Table.Rows[0]);



                    if (m_Table != null && m_Table.Rows.Count > 0)
                        FillDataToControls(m_NewTable);
                    else
                    {
                        IndicateNoTransaction();
                    }
                }
                else
                {
                    IndicateNoTransaction();
                }
            }
            else
            {
                IndicateNoTransaction();
            }
		

            
        }

        void tb_LostFocus(object sender, EventArgs e)
        {
            TextBox tb = (sender as TextBox);

            string text = tb.Text.Replace(",",string.Empty).Trim();

            if(text == "" || text == "-") tb.Text = "0";
            else
            {
                tb.Text = (Int64.Parse(text)).ToString("#,0");
            }
        }


        void tb_LostFocus(object sender)
        {
            TextBox tb = (sender as TextBox);

            string text = tb.Text.Replace(",", string.Empty).Trim();

            if (text == "" || text == "-") tb.Text = "0";
            else
            {
                tb.Text = (Int64.Parse(text)).ToString("#,0");
            }
        }
        /// <summary>
        /// Handles the FormClosing event of the frmUpdateCustomerTransaction control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="FormClosingEventArgs" /> instance containing the event data.</param>
        private void frmUpdateCustomerTransaction_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (ForceClose == false)
            {
                
               
                // Commit all changes to the data source before perform updating operation
                foreach (TextBox tb in editTextBoxs)
                {
                    tb.BindingContext[m_NewTable].EndCurrentEdit();
                }
                ckbNotShow.BindingContext[m_NewTable].EndCurrentEdit();
                // If there are changes in data source, show saving confirmation dialog
                if (m_NewTable.GetChanges() != null)
                {

                    bool isChange = false;
                    // Execute database operation
                    DataTable newTable = m_Table.Copy();
                    for (int i = 2; i < 68; i++)
                    {
                        Int64 value = 0;
                        try
                        {
                            value = Int64.Parse(((string)m_NewTable.Rows[0][i]).Replace(",", string.Empty));

                        }
                        catch (Exception)
                        {
                        }
                        if (value != (Int64)m_Table.Rows[0][i])
                        {
                            newTable.Rows[0][i] = value;
                            isChange = true;
                        }
                    }
                    if ((string)m_NewTable.Rows[0]["ReportStatus"] != ((bool)m_Table.Rows[0]["ReportStatus"]).ToString())
                    {
                        isChange = true;
                        newTable.Rows[0]["ReportStatus"] = m_NewTable.Rows[0]["ReportStatus"];
                    }
                    // If there is a number of affected row greater than zero, 
                    // it's OK and save revision history to DB
                    if (isChange)
                    {

                        DialogResult dialogResult = DialogResult.Cancel;
                        if (m_IsBtnSaveClicked)
                        {
                            dialogResult = clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                                                      COMMON.Properties.Settings.Default.CONF_ACTION, new string[] { clsCPAConstant.ACT_UPDATE, clsCPAConstant.CPA_TEXT });
                        }
                        else
                        {
                            dialogResult = clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                                                             clsCPACommonMessage.DO_YOU_WANT_SAVE);
                        }
                        if (dialogResult == DialogResult.Yes)
                        {
                            clsUpdateCustomerTransBLL bus = new clsUpdateCustomerTransBLL();
                            int affectedRow = bus.UpdateTransaction(newTable, m_SearchConditions[2], txtCustCode.Text);

                           
                            if (affectedRow == 0)
                                clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                                                               COMMON.Properties.Settings.Default.INFO_ACTION_FAIL, new string[] { clsCPAConstant.ACT_UPDATING, "CPA" });
                            else
                            {
                                SaveHistory(bus);
                                bus.Commit();
                                clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                                                               COMMON.Properties.Settings.Default.INFO_ACTION_SUCCESS, new string[] { clsCPAConstant.ACT_UPDATING, "CPA" });
                                
                            }
                        }
                        if (dialogResult == DialogResult.Cancel)
                        {
                            e.Cancel = true;
                        }



                    }
                }
                DataTable data = m_BLL.GetTransactionData(txtCustCode.Text, m_SearchConditions[2]);
                frmCPAListCPA.UpdatingCPA = new clsCPACustomerDTO(data.Rows[0]);
            }
        }

        /// <summary>
        /// Every time the frmUpdateCustomerTransaction is activated, clear clipboard
        /// to disallow paste value to editable textbox(s)
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void frmUpdateCustomerTransaction_Activated(object sender, EventArgs e)
        {
            //Clipboard.Clear();
        }

        /// <summary>
        /// Handles the Click event of the btnSave control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
    
                m_IsBtnSaveClicked = true;
                this.Close();
            }
            catch (Exception ex)
            {
                this.ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
        }

        /// <summary>
        /// Handles the Enter event of the textbox control.
        /// Disable paste function to textbox(s)
        /// </summary>
        private void tb_Enter(object sender, EventArgs e)
        {
            //Clipboard.Clear();
        }

        /// <summary>
        /// Validate the length of editable textbox(s) that doesn't 
        /// exceed ten characters, otherwise show warning dialog
        /// </summary>
        private void tb_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            clsCommonFunctions.ValidateNumbersOnTextBox(e, (TextBox)sender);

            TextBox tb = (sender as TextBox);
            if (e.KeyChar == 22)
            {
                string a = Clipboard.GetText();
                try
                {
                    a = a.Replace(",", string.Empty);
                    Int64 temp = Int64.Parse(a);
                    Clipboard.SetData(DataFormats.Text, a.ToString());
                    if (temp < 0)
                    {
                        if (tb.Text.Length > 0 && tb.SelectedText[0] != '-') e.Handled = true;
                        if (tb.SelectedText.Length == tb.Text.Length) e.Handled = false;
                    }

                    
                }
                catch (Exception)
                {
                    e.Handled = true;

                }
            }

            string[] separate = tb.Text.Split(',');
            int more = separate.Length - 1;
            if (tb.Text.Length >0 && tb.Text[0] != '-') tb.MaxLength = 10 + more;
            else tb.MaxLength = 11 + more;
 
        }

        /// <summary>
        /// Handles the Click event of the btnClose control.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

      
    }
}