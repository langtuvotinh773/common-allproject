﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Report Profit Screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Dto;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Functions;
using DataEncryption;
namespace Phoenix.Cpa.Gui.Forms
{
    /// <summary>
    /// This form use to expoer report profit
    /// </summary>
    public partial class frmScreenReportProfit : MasterForm
    {
		/// Excel base object
        ExcelBase m_ExcelBase = null;
		/// worker object, working for background thread
        private CWorker m_worker;
        //private string strFileName = "";
		/// template of file to export
		private string m_TemplateName;
		/// from quarter
		private string m_FromQuarterText = "";
		/// to quarter
		private string m_ToQuarterText = "";
		/// department value
		private string m_DepartmentValue = "";
		/// team ID
		private string m_TeamID = "";
		/// Japan Account ID
		private string m_JpAccID = "";
		/// Vietnam Account ID
		private string m_VnAccID = "";
		/// Customer code
        private string m_CusCode = "";
		/// Customer Full name
		private string m_CusFullName = "";
		/// JNJ ID
		private string m_JnjID = "";
		/// Department name
		private string m_DepartmentName = "";
		/// Team name
		private string m_TeamName = "";
		/// Japan account name
		private string m_JpAccName = "";
		/// Vietnam account name
		private string m_VnAccName = "";
		/// JNJ Name
		private string m_JnjName = "";
		/// start month
		private string m_realFrom = "";
		/// start year
		private int m_iFromYear = 0;
		/// to year
		private int m_iToYear = 0;
		/// from quarter (int)
		private int m_iFromQuarter = 0;
		/// to quarter (int)
		private int m_iToQuarter = 0;
		/// from date
		private string m_DateFrom = "";
		/// to date
		private string m_DateTo = "";
		/// from month (int)
		private int m_iFromMonth;
		/// to month (int)
		private int m_iToMonth;
		/// common function object
		clsCommonFunctions m_CommonFunction = null;
		/// report bus object
		clsReportBLL m_rptBus = new clsReportBLL();
		/// date to export
		private List<string> m_RoughDate = new List<string>();
		/// header columns count of each row
		int m_HeaderRowCount = 5;
		/// month columns to delete
        private int m_iDeleteMonthCount = 0;
        /// Sum from [Quarter 2 in previous year] to [Quarter 1 in calculated year]
		private int m_iMonthStartSum = 4;
		/// File name to export
        private string m_FileName = "";
        private const string FORMAT_EXPORT_CELL = "N2";
        private const string S_MONTH_MAR = clsCPAConstant.MAR;
		private const string S_ZERO = "0.00";
		/// Project name
		private string m_ProjectName = clsCPAConstant.PROJECT_NAME_CPA;
		/// Check of there is no data or not
		private bool m_isNoData = false;
		/// radio name
		private string m_radName;
		/// data matrix
		object[,] m_arrData;
		/// data total matrix
		object[,] m_arrDataTotal;
		/// data total top matrix
		object[,] m_arrDataTop;
		/// number of rows to export
		int m_iRowCount;
		/// number of rows to export on group by
		int m_iRowCountGroupBy;
		/// number of column to export
		int m_iColCount;
		/// data total matrix (object)
		object[,] m_arrTotal;
		/// data table gotten from database
		DataTable m_dataTable;
		/// header name array
		object[,] m_arrHeaderName;
		/// number of data top matrix's rows
		int m_iRowCountDataTop;
		/// number of data datatotal matrix's rows 
		int m_iRowCountDataTotal;
		/// header name list
		List<string> m_lstHeaderName;
		/// CCPAReport_On_CPA_By_Account_Officer's customer list
        List<clsCPAReport_On_CPA_By_Account_OfficerDTO> m_lstCustomer;

        private string m_oldTeam = "";
        private string m_oldJP = "";
        private string m_oldVN = "";
        private bool m_IsOnSetDataCombobox = false;


        //data total of top 
        int m_iTop = int.Parse(Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["TopCustomerByAccountOfficer"].ToString()));
        object[,] m_DataTotalTop;
        
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public frmScreenReportProfit()
        {
            InitializeComponent();
            SetSecurity();
           
            try
            {
                SetFormStyle();
                Init();
                m_TemplateName = GetTemplateName();
                txtFromQuarter.isQuarter = true;
                txtToQuarter.isQuarter = true;
                int quarter = clsCommonFunctions.FindQuarterByMonth(DateTime.Now.Month);

                txtFromQuarter.Value = new DateTime(DateTime.Now.Year, quarter, 1);
                txtToQuarter.Value = new DateTime(DateTime.Now.Year, quarter, 1);



                lblListReport.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
                label2.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
                SetFormStyle();
            }
            catch (Exception ex) { Config.Classes.clsLogFile.LogException(ex.Message, clsCPAConstant.CPA_TEXT); }
        }

        private void Init()
        {
            m_CommonFunction = new Config.Classes.clsCommonFunctions();
            clsGetDataCombobox.Instance().LoadDepartment();
            cbbJPAcc.DataSource = clsGetDataCombobox.Instance().JPAcc;
            cbbJPAcc.DisplayMember = clsCPAConstant.USER_NAME;
            cbbJPAcc.ValueMember = clsCPAConstant.USER_ID;
            cbbJPAcc.DropDownStyle = ComboBoxStyle.DropDownList;
            SetDataCombobox("","");

        }
        /// <summary>
        /// Set data to commbobox 
        /// </summary>
        /// Phong

        private void SetDataCombobox(string dep, string team)
        {
            m_IsOnSetDataCombobox = true;
            cbbDepartment.DataSource = clsGetDataCombobox.Instance().LstDepartment;
            cbbDepartment.DisplayMember = clsCPAConstant.DEPARTMENT_NAME;
            cbbDepartment.ValueMember = clsCPAConstant.DEPARTMENT_ID;
            cbbDepartment.DropDownStyle = ComboBoxStyle.DropDownList;

            if (team == "")
            {
                clsGetDataCombobox.Instance().LoadTeam(dep);
                cbbTeam.DataSource = clsGetDataCombobox.Instance().LstSection;
                cbbTeam.DisplayMember = clsCPAConstant.SECTION_NAME;
                cbbTeam.ValueMember = clsCPAConstant.SECTION_ID;
                cbbTeam.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            clsGetDataCombobox.Instance().LoadUser(dep, team);




           

            cbbVNAcc.DataSource = clsGetDataCombobox.Instance().VNAcc;
            cbbVNAcc.DisplayMember = clsCPAConstant.USER_NAME;
            cbbVNAcc.ValueMember = clsCPAConstant.USER_ID;
            cbbVNAcc.DropDownStyle = ComboBoxStyle.DropDownList;

            cbbJNJ.DataSource = clsGetDataCombobox.Instance().lstJNJ;
            cbbJNJ.DisplayMember = clsCPAConstant.NAME;
            cbbJNJ.ValueMember = clsCPAConstant.VALUE;
            cbbJNJ.DropDownStyle = ComboBoxStyle.DropDownList;

            if (m_oldTeam != "")
            {
                int index = 0;
                index = clsGetDataCombobox.Instance().LstSection.FindIndex(delegate(SectionDTO st)
                {
                    return st.SectionID == m_oldTeam;
                });
                if (index >= 0)

                    cbbTeam.SelectedIndex = index;
                else
                {
                    // if (team != "")
                    m_oldTeam = "";
                }
            }
            
            if (m_oldVN != "")
            {
                int index = 0;
                index = clsGetDataCombobox.Instance().VNAcc.FindIndex(delegate(UserDTO st)
                {
                    return st.UserID == m_oldVN;
                });
                if (index >= 0)
                    cbbVNAcc.SelectedIndex = index;
                else
                {
                    m_oldVN = "";
                }
            }
            m_IsOnSetDataCombobox = false;
        }

        ///// <summary>
        ///// Set form style
        ///// </summary>
        ///// @cond
        ///// Author: Phan Tran Hoang Yen
        ///// @endcond
        //private void SetFormStyle()
        //{
        //    lbl0102.Text = clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER;
        //    lbl03.Text = strLabel03 + m_iTop.ToString() + " CUSTOMERS";
        //    this.BackColor = clsCPAConstant.BG_FORM;
        //    btnExportExcel.BackColor = clsCPAConstant.BG_BUTTON;
        //    btnClose.BackColor = clsCPAConstant.BG_BUTTON;
		//}

        /// <summary>
        /// Get template to export
        /// </summary>
        /// <returns>string template name</returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private string GetTemplateName()
        {
            if (rad0102.Checked == true)
                return clsCPAConstant.REPORT_ON_CPA_BY_ACCOUNT_OFFICER;
            if (rad03.Checked == true)
                return clsCPAConstant.REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS;
            return "";
        }
        /// <summary>
        /// Check "from", "to" quarters input
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private bool CheckQuarterInput()
        {
            try
            {
                m_FromQuarterText = txtFromQuarter.Text;
                m_ToQuarterText = txtToQuarter.Text;

                if (m_FromQuarterText == "" || m_ToQuarterText == "")
                    return false;
                //if (strToQuarterText.Length < 5 || strFromQuarterText.Length < 5)
                //    return false;

                m_iFromYear = int.Parse(m_FromQuarterText.Substring(3, 4));
                m_iToYear = int.Parse(m_ToQuarterText.Substring(3, 4));

                if (m_iFromYear > m_iToYear)
                    return false;

                m_iFromQuarter = int.Parse(m_FromQuarterText.Substring(0, 2));
                m_iToQuarter = int.Parse(m_ToQuarterText.Substring(0, 2));

                if (m_iToQuarter > 4 || m_iFromQuarter > 4)
                    return false;
                if (m_iFromYear == m_iToYear && m_iToQuarter < m_iFromQuarter)
                    return false;

                int iMaxQuarter = GetMaxQuarter();

                if (m_iToYear == DateTime.Now.Year && m_iToQuarter > iMaxQuarter)
                    return false;

                if (m_iFromYear == DateTime.Now.Year && m_iFromQuarter > iMaxQuarter)
                    return false;

                return true;
            }
            catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
            return false;
        }

        /// <summary>
        /// Get Max Quarter of current year
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private int GetMaxQuarter()
        {
            int iMonth = DateTime.Now.Month;
            return iMonth / 3 + (iMonth % 3 == 0 ? 0 : 1);
        }

        /// <summary>
        /// Get which report to export - radio name
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void GetRadName()
        {
            if (rad0102.Checked == true)
            {
                m_radName = clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER;
                return;
            }
            if (rad03.Checked == true)
            {
                m_radName = clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS;
                return;
            }
        }

        private bool GetDataForReport()
        {
            switch (m_radName)
            {
                ///01 - 02 
                case clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER:
                    m_arrData = GetDataForReport_On_CPA_By_Account_Officer(ref m_iRowCount, ref m_arrTotal, ref m_lstCustomer, ref m_dataTable);

                    m_arrDataTotal = GetDataForReport_On_CPA_By_Account_Officer_Total(ref m_iRowCountGroupBy, m_arrData);

                    break;
                ///03
                case clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS:
                    m_arrDataTop = GetDataTopForReport_On_CPA_By_Account_Officer_Top_20_Customers(ref m_iRowCountDataTop, m_arrHeaderName, m_iTop, cbbJNJ.Text);
                    m_arrDataTotal = GetDataForReport_On_CPA_By_Account_Officer_Top_20_Customers(ref m_iRowCountDataTotal, m_arrHeaderName);
                    m_iRowCount = m_iRowCountDataTotal * m_iRowCountDataTop;
                    break;
                default:
                    m_iRowCount = 0;
                    m_iColCount = 0; 
                    break;
            }
            if (m_iRowCount == 0)
            {
                m_isNoData = true;
                Complete();
                return false;
            }
            else
            {
                List<string> cpas = clsFinalizeCPABus.CheckLackingCPA(m_DateFrom, m_DateTo);
                if (cpas.Count > 0)
                    clsMesageCollection.ShowCPANotImportYet(cpas);
            }
            return true;
        }
        /// <summary>
        /// Export to excel
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void ExportToExcel()
        {
            if (rad03.Checked == true && cbbVNAcc.Text == "")
            {
                clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsCPAConstant.INPUT_VNACC_REQUIRE);
                return;
            }
            if (!(rad0102.Checked || rad03.Checked))
                return;
            GetRadName();
            GetHeaderName();
            m_iColCount = m_RoughDate.Count;
            if (!GetDataForReport())
                return;
            m_FileName = m_radName + m_rptBus.GetServerDate();

            //DialogResult result = Config.Classes.clsCommonFunctions.ShowSaveExcelDialog(ref m_FileName);
            //if (result == DialogResult.Cancel)
            //    return;
            bool isOPened = false;
            m_ExcelBase = new Config.Classes.ExcelBase(m_FileName, m_TemplateName, m_ProjectName, ref isOPened, m_rptBus.GetServerDate());
            if (isOPened)
                return;
            m_CusCode = txtCustomerCode.Text.Trim();
            m_CusFullName = txtCustomerFullName.Text.Trim();
            m_isNoData = false;
            btnExportExcel.Enabled = false;
            switch (m_radName)
            {
                case clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER:
                    m_worker = new Config.Classes.CWorker(SaveReport_On_CPA_By_Account_Officer, Complete);
                    m_worker.Start();
                    break;
                case clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS:
                    m_worker = new Config.Classes.CWorker(SaveReport_On_CPA_By_Account_Officer_Top_20_Customers, Complete);
                    m_worker.Start();
                    break;
            }
        }

        private void GetHeaderName()
        {
            switch (m_radName)
            {
                case clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER:
                    GetHeaderNameReport_On_CPA_By_Account_Officer();
                    m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(m_RoughDate);

                    break;
                case clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS:
                    m_lstHeaderName = GetHeaderNameReport_On_CPA_By_Account_Officer_Top_20_Customers();
                    m_arrHeaderName = clsCommonFunctions.GetMatrixFromList(m_lstHeaderName);
                    break;
            }
        }
        /// <summary>
        /// Handling when completed a thread
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void Complete()
        {
            PrintTrackTime("rpt01");
            btnExportExcel.Enabled = true;
            if (m_isNoData == true)
            {
                clsMesageCollection.MessageNoTransactions();
            }
            else
            {
                m_ExcelBase.SaveFile();
                //System.Diagnostics.Process.Start(m_FileName);
            }
        }

        /// <summary>
        /// Print title of a report
        /// </summary>
        /// <param name="strRptName"></param>
        /// <param name="strRptTitle"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void PrintTitle(string strRptName, string strRptTitle)
        {
            m_ExcelBase.InsertText(2, 2, strRptName);
            m_ExcelBase.InsertText(3, 2, strRptTitle);
        }

        /// <summary>
        /// Export report R_01(All-VN) to excel 
        /// </summary>	
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond 
        private void SaveReport_On_CPA_By_Account_Officer()
        {
            PrintTrackTime("rpt01");
            //Title
            int iStart = 3;
            m_ExcelBase.InsertText(2, 2, clsCPAConstant.REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TITLE);
            m_ExcelBase.InsertText(1, iStart += 2, clsCPAConstant.R_H_FROM_QUARTER);
            m_ExcelBase.InsertText(1, iStart += 2, clsCPAConstant.R_H_DEPARTMENT);
            m_ExcelBase.InsertText(1, iStart += 2, clsCPAConstant.R_JP_ACCOUNT_OFFICER);
            m_ExcelBase.InsertText(1, iStart += 2, clsCPAConstant.COL_CUSTOMER_CODE);
            m_ExcelBase.InsertText(1, iStart += 2, clsCPAConstant.R_H_JNJ);
            iStart = 3;
            m_ExcelBase.InsertText(3, iStart += 2, clsCPAConstant.R_H_TO_QUARTER);
            m_ExcelBase.InsertText(3, iStart += 2, clsCPAConstant.R_H_TEAM);
            m_ExcelBase.InsertText(3, iStart += 2, clsCPAConstant.R_VN_ACCOUNT_OFFICER);
            m_ExcelBase.InsertText(3, iStart += 2, clsCPAConstant.R_H_CUSTOMER_FULL_NAME);
            iStart = 3;
            m_ExcelBase.InsertText(2, iStart += 2, "'" + m_FromQuarterText);
            m_ExcelBase.InsertText(2, iStart += 2, "'" + m_DepartmentName);
            m_ExcelBase.InsertText(2, iStart += 2, "'" + m_JpAccName);
            m_ExcelBase.InsertText(2, iStart += 2, "'" + m_CusCode);
           
            m_ExcelBase.InsertText(2, iStart += 2, "'" + m_JnjName);

            ////Header
            
            int iColStart = 1;
            int iRowStart = 15;
            int iColEnd = iColStart + m_RoughDate.Count - 1;
            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart++, m_arrHeaderName);

            //Get data  
            
            
            int iRowEnd = m_iRowCount + iRowStart - 1;
           
            iColEnd = iColStart + m_RoughDate.Count - 1;
            Excel.Range excRange = m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);
            
            iRowEnd++;
            excRange = m_ExcelBase.ExportRange(5, iRowEnd, iColEnd, iRowEnd, m_arrTotal);
            excRange.Font.Bold = true;
            excRange = m_ExcelBase.GetRange(1, iRowEnd, m_HeaderRowCount - 1, iRowEnd);
            //excRange.ClearContents();
            //excRange.ClearFormats();
            m_ExcelBase.InsertText(5, iRowEnd, clsCPAConstant.R_H_TOTAL);

            iRowEnd += 2;
            m_ExcelBase.InsertText(m_HeaderRowCount, iRowEnd, clsCPAConstant.R_01_BY_ACOUNT_OFFICER);
            excRange = m_ExcelBase.GetRange(m_HeaderRowCount, iRowEnd, m_HeaderRowCount, iRowEnd);
            excRange.Font.Bold = true;


            ///save report 02
            m_iColCount = m_iColCount - m_iDeleteMonthCount - m_HeaderRowCount + 1;
            //m_arrDataTotal = GetDataForReport_On_CPA_By_Account_Officer_Total(m_lstCustomer, m_dataTable, m_iColCount, ref m_iRowCount);
            iRowStart = iRowEnd + 1;
            iRowEnd = iRowStart + m_iRowCountGroupBy - 1;
            m_ExcelBase.ExportRange(m_HeaderRowCount, iRowStart, m_HeaderRowCount + m_iColCount + m_iDeleteMonthCount - 1, iRowEnd, m_arrDataTotal);




            if (m_iDeleteMonthCount > 0)
            {
                excRange = m_ExcelBase.GetRange(iColStart + m_HeaderRowCount, iRowStart - 1, m_iDeleteMonthCount + m_HeaderRowCount, iRowStart);
                excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
            }
            iStart = 3;
            m_ExcelBase.InsertText(4, iStart += 2, "'" + m_ToQuarterText, clsCPAConstant.REPORT_BORDER_COLOR);
            m_ExcelBase.InsertText(4, iStart += 2, "'" + m_TeamName, clsCPAConstant.REPORT_BORDER_COLOR);
            m_ExcelBase.InsertTextWithMerge(4, iStart += 2, "'" + m_VnAccName, 4);

            m_ExcelBase.InsertTextWithMerge(4,iStart+= 2,m_CusFullName,4);

           
            iStart = 3;
            m_ExcelBase.InsertText(6, iStart += 2, clsCPAConstant.R_H_DATE);

            iStart = 3;

            m_ExcelBase.InsertText(7, iStart += 2, "'" + DateTime.Now.ToString("MM-dd-yyyy"), clsCPAConstant.REPORT_BORDER_COLOR);
            //m_ExcelBase.SaveFile();
        }
        /// <summary>
        /// Export report spCPA_Report_On_CPA_By_Account_Officer_Top_20_Customers to excel
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond 
        private void SaveReport_On_CPA_By_Account_Officer_Top_20_Customers()
        {
            // set title report
            m_ExcelBase.InsertText(2, 2, clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS + m_iTop.ToString() + " CUSTOMERS");


            int iRowEnd = 0;
            int iColStart = 1;
            int iRowStart = 4;
            int iColEnd = iColStart + m_lstHeaderName.Count - 1;
            //int iRowCount = 0;
            int iDataTopCount = 0;
            //export header
            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart, m_arrHeaderName);

            //export data top 20


            iDataTopCount = m_iRowCountDataTop;
            iRowStart = iRowStart + 1;
            iRowEnd = iRowStart + m_iRowCountDataTop;
            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd - 1, m_arrDataTop);


            iRowStart = iRowEnd + 1;
            iRowEnd = iRowStart;
            m_ExcelBase.ExportRange(iColStart+4, iRowStart, iColEnd, iRowEnd, m_arrDataTotal);

            //export data rate by condition search
            object[,] dataRate = GetDataRateTopReport(iDataTopCount, m_arrDataTop, m_arrDataTotal, m_iTop);
            iRowStart = iRowEnd + 1;
            iRowEnd = iRowStart;
            m_ExcelBase.ExportRange(iColStart+4, iRowStart, iColEnd, iRowEnd, dataRate);

            //delete range excel by month count
            if (m_iDeleteMonthCount > 0)
            {
                Excel.Range excRange = m_ExcelBase.GetRange(iColStart + 5, iRowStart - 1, m_iDeleteMonthCount + 5, iRowStart + iRowEnd);
                excRange.EntireColumn.Delete(System.Reflection.Missing.Value);
            }
            //m_ExcelBase.SaveFile();
        }


        /// <summary>
        /// Print debug time for testing
        /// </summary>
        /// <param name="title"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond 
        private void PrintTrackTime(string title)
        {
            Console.WriteLine(title + ".........." + DateTime.Now.Second);
        }

        /// <summary>
        /// Get data for report 02
        /// </summary>
        /// <param name="lstCustomer"></param>
        /// <param name="dtb"></param>
        /// <param name="iColCount"></param>
        /// <param name="refiRowCount"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond 
        private object[,] GetDataForReport_On_CPA_By_Account_Officer_Total(ref int refiRowCount, object[,] rawData)
        {
            int iRowCount = m_dataTable.AsEnumerable().GroupBy(r => r.Field<string>(clsCPAConstant.JAPAN_ACCOUNT)).Count();
            iRowCount += m_dataTable.AsEnumerable().GroupBy(r => r.Field<string>(clsCPAConstant.VN_ACCOUNT)).Count();
            iRowCount += m_dataTable.AsEnumerable().GroupBy(r => r.Field<string>(clsCPAConstant.TEAM)).Count();
            refiRowCount = iRowCount;
          
           
           
           // arrResult[0, 4] = JPAcc;
            int currentRow = 0;
            List<string> lstJPAcc = new List<string>();
            List<string> lstVNAcc = new List<string>();
            List<string> lstTeam = new List<string>();

            for (int i = 0; i < m_iRowCount; i++)
            {
                string jp = (string)rawData[i, 3];
                string vn = (string)rawData[i, 4];
                string te = (string)rawData[i, 2];
                if (!lstJPAcc.Contains(jp))
                {
                    lstJPAcc.Add(jp);
                }

                if (!lstVNAcc.Contains(vn))
                    lstVNAcc.Add(vn);
                if (!lstTeam.Contains(te))
                    lstTeam.Add(te);
            }

            lstJPAcc.Sort();
            lstTeam.Sort();
            lstVNAcc.Sort();
            object[,] arrResult = new object[lstJPAcc.Count+ lstTeam.Count + lstVNAcc.Count, m_iColCount - 4];
            SetDefaultValue(arrResult, lstJPAcc.Count + lstTeam.Count + lstVNAcc.Count, m_iColCount - 4);
            for (int j = 0; j < lstJPAcc.Count; j++)
            {
                arrResult[currentRow, 0] = lstJPAcc[j];
                for (int i = 0; i < m_iRowCount; i++)
                {
                    if ((string)rawData[i, 3] == lstJPAcc[j])
                    {
                        
                        for (int k = 5; k < m_iColCount; k++)
                        {
                            arrResult[currentRow, k-4] = (double)arrResult[currentRow, k-4] + (double)rawData[i, k];
                        }
                    }
                   
                }
                currentRow = currentRow + 1;
            }

            for (int j = 0; j < lstVNAcc.Count; j++)
            {
                arrResult[currentRow, 0] = lstVNAcc[j];
                for (int i = 0; i < m_iRowCount; i++)
                {
                    if ((string)rawData[i, 4] == lstVNAcc[j])
                    {

                        for (int k = 5; k < m_iColCount; k++)
                        {
                            arrResult[currentRow, k - 4] = (double)arrResult[currentRow, k - 4] + (double)rawData[i, k];
                        }
                    }

                }
                currentRow = currentRow + 1;
            }

            for (int j = 0; j < lstTeam.Count; j++)
            {
                arrResult[currentRow, 0] = lstTeam[j];
                for (int i = 0; i < m_iRowCount; i++)
                {
                    if ((string)rawData[i, 2] == lstTeam[j])
                    {

                        for (int k = 5; k < m_iColCount; k++)
                        {
                            arrResult[currentRow, k - 4] = (double)arrResult[currentRow, k - 4] + (double)rawData[i, k];
                        }
                    }

                }
                currentRow = currentRow + 1;
            }

           
            return arrResult;
        }
        /// <summary>
        /// Get data for report 01
        /// </summary>
        /// <param name="iRow"></param>
        /// <param name="iCol"></param>
        /// <param name="arrTotal"></param>
        /// <param name="reader"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond  
        private object[,] GetDataForReport_On_CPA_By_Account_Officer(ref int iRow, ref object[,] arrTotal, ref List<clsCPAReport_On_CPA_By_Account_OfficerDTO> lstCustomerResult, ref DataTable reader)
        {
            List<clsCPAReport_On_CPA_By_Account_OfficerDTO> lstCustomer = new List<clsCPAReport_On_CPA_By_Account_OfficerDTO>();
            reader = m_rptBus.GetListCPAReportOnCPAByAccountOfficer(m_DateFrom, m_DateTo, m_CusCode, m_CusFullName, m_DepartmentValue, m_TeamID, m_JnjName, m_VnAccID, m_JpAccID, ref iRow, ref lstCustomer, m_realFrom);

            lstCustomerResult = lstCustomer;
            ///get data
            object[,] data = new object[iRow, m_iColCount];// + m_HeaderRowCount
            data = SetDefaultValue(data, iRow, m_iColCount);


            arrTotal = new object[1, m_iColCount-4];
            arrTotal = SetDefaultValue(arrTotal, 1, m_iColCount-4);
            double[,] tempArray = new double[1, m_iColCount];
            if (lstCustomer.Count > 0)
            {
               int currentRow = 0;
               data[currentRow, 0] = lstCustomer[0].CustomerID;
               data[currentRow, 1] = lstCustomer[0].CustomerName;
               data[currentRow, 2] = lstCustomer[0].Team;
               data[currentRow, 3] = lstCustomer[0].ShortJP;
               data[currentRow, 4] = lstCustomer[0].ShortVN;
                string cusID = lstCustomer[0].CustomerID;
                for (int i = 0; i < lstCustomer.Count; i++)
                {

                    
                    if (lstCustomer[i].CustomerID == cusID) //same customerID
                    {
                       
                        int insertToColumn = m_RoughDate.FindIndex( // get column need to insert
                            delegate(string condition)
                            {
                                return condition == lstCustomer[i].YearMonth;
                            }
                        );

                        if (insertToColumn == 27)
                        {
                        }
                        if (lstCustomer[i].ReportStatus == false && lstCustomer[i].CPAStatus == 1)
                        {
                            data[currentRow, insertToColumn] = (double)lstCustomer[i].CalItem;
                            tempArray[0, insertToColumn] += (double)lstCustomer[i].CalItem;
                            arrTotal[0, insertToColumn-4] = tempArray[0, insertToColumn];
     
                        }

                    }
                    else  //orther customerID
                    {

                        //reset all data for each customer
                        cusID = lstCustomer[i].CustomerID;
                        currentRow = currentRow + 1; //increase row   
                        data[currentRow, 0] = lstCustomer[i].CustomerID;
                        data[currentRow, 1] = lstCustomer[i].CustomerName;
                        data[currentRow, 2] = lstCustomer[i].Team;
                        data[currentRow, 3] = lstCustomer[i].ShortJP;
                        data[currentRow, 4] = lstCustomer[i].ShortVN;

                        //find index of monthyear
                        int insertToColumn = m_RoughDate.FindIndex(
                            delegate(string condition)
                            {
                                return condition == lstCustomer[i].YearMonth;
                            }
                            );
                        //data on each month of a customer
                        if (lstCustomer[i].ReportStatus == false && lstCustomer[i].CPAStatus == 1)
                        {
                            data[currentRow, insertToColumn] = (double)lstCustomer[i].CalItem;
                            tempArray[0, insertToColumn] += (double)lstCustomer[i].CalItem;
                            arrTotal[0, insertToColumn-4] = tempArray[0, insertToColumn];
                        }
                    }
                }

                // caculating total/ave quarter and year
                for (int j = 8; j < m_iColCount; )
                {
                    string month = m_RoughDate[j - 1].Remove(0, 4);
                    if (j < m_iColCount)
                    {
                        double totalQuarterall = 0;
                        double totalYearAll = 0;
                        double totalForAveYearAll = 0;

                        
                        for (int i = 0; i < m_iRowCount; i++)
                        {

                            double total = (double)data[i, j - 1] + (double)data[i, j - 2] + (double)data[i, j - 3];//sum of 3 month in quarter
                            data[i, j] = total;
                            double ave = Math.Round(total / 3, 2);//average
                            if (j < m_iColCount - 1)
                                data[i, j + 1] = ave;
                            totalQuarterall += total;
                            
                            if (month == "03")
                            {
                                //sum of 12 months
                                double totolYear = (double)data[i, j - 18] + (double)data[i, j - 17] + (double)data[i, j - 16] + (double)data[i, j - 13] +
                                    (double)data[i, j - 12] + (double)data[i, j - 11] + (double)data[i, j - 8] + (double)data[i, j - 7] + (double)data[i, j - 6] +
                                    total;
                                totalYearAll += totolYear;


                                int year = int.Parse(m_RoughDate[j - 18].Remove(4));
                                double totalAveYear = (double)data[i, j - 18] + (double)data[i, j - 17]  + (double)data[i, j - 16]  + (double)data[i, j - 13]  +
                                    (double)data[i, j - 12] + (double)data[i, j - 11]  + (double)data[i, j - 8]  + (double)data[i, j - 7] + (double)data[i, j - 6]  +
                                    (double)data[i, j - 1]  + (double)data[i, j - 2] + (double)data[i, j - 3];
                                totalForAveYearAll += totalAveYear;
                                data[i, j + 2] = totolYear;
                                double aveYear = totalAveYear / 12;//average
                                data[i, j + 3] = aveYear;
                               
                            }
                            
                        }
                        // this value of row final total 
                        arrTotal[0, j-4] = totalQuarterall;
                        double aveQuarterAll = totalQuarterall / 3;
                        arrTotal[0, j - 3] = aveQuarterAll;
                        
                        if (month == "03")
                        {
                            arrTotal[0, j - 2] = totalYearAll;
                            double aveYearAll = totalForAveYearAll / 12;

                            
                            arrTotal[0, j - 1] = aveYearAll;
                            j = j + 2;
                        }
                        j = j + 5;
                    }
                }

            }
          //  arrTotal[0, 0] = arrTotal[0, 1] = arrTotal[0, 2] = arrTotal[0, 3] = "";
            return data;
        }


        /// <summary>
        /// set defaul value for array = 0
        /// </summary>
        /// <param name="array"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        private object[,] SetDefaultValue(object[,] array, int row, int col)
        {
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    double a = 0;
                    array[i, j] = a;
                }
            }
            return array;
        }
        /// <summary>
		/// Get data for top REPORT ON CPA BY ACCOUNT  OFFICER - TOP 20 CUSTOMERS
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Co Phuong
        /// @endcond
        private object[,] GetDataTopForReport_On_CPA_By_Account_Officer_Top_20_Customers(ref int iRow, object[,] arrHeaderName, int iTop, string jnj)
        {
            clsReportBLL bll = new clsReportBLL();
            //select data for report 03
            bll.GetListTopCPACustomerReport_On_CPA_By_Account_Officer_Top_20_Customers(m_DateFrom, m_DateTo, jnj, iTop, txtCustomerCode.Text.Trim(), txtCustomerFullName.Text.Trim(), m_DepartmentValue, m_TeamID, m_JpAccID, m_VnAccID,m_realFrom);
            iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();

            //phong
            List<int> lstIndex = new List<int>();
           
            string cusId = "";
            if (bll.ListCPACustomer.Count > 0)
            {
                cusId = bll.ListCPACustomer[0].CustomerID;
            }
            lstIndex.Add(0);
            for (int i = 0; i < bll.ListCPACustomer.Count; i++)
            {
                if (bll.ListCPACustomer[i].CustomerID != cusId)
                {

                    lstIndex.Add(i);
                    cusId = bll.ListCPACustomer[i].CustomerID;
                }
            }

            object[,] data = new object[iRow + 1, arrHeaderName.Length];

            m_DataTotalTop = new object[1, arrHeaderName.Length - 4];
            data[iRow, 4] = String.Format(clsCPAConstant.R_TOTAL_TOP, iTop);
            m_DataTotalTop[0, 0] = String.Format(clsCPAConstant.R_TOTAL_TOP, iTop);
            int iResultIndex = 0;
            for (int i = 0; i < iRow; i++)
            {
                //phong
                if (i != 0)
                    iResultIndex = lstIndex[i];
                //<--phong
                data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
                data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
                data[i, 3] = bll.ListCPACustomer[iResultIndex].ShortJP;
                data[i, 4] = bll.ListCPACustomer[iResultIndex].ShortVN;
                double iTotalYear = 0;
                double iTotalQuarter = 0;
                double iTotalAveYear = 0;
                double zero = 0;
                for (int j = 5; j < arrHeaderName.Length; j++)
                {
                    int count = 0;
                   
                    try
                    {
                        count = lstIndex[i + 1];
                    }
                    catch (Exception ex)
                    {
                        count = bll.ListCPACustomer.Count;
                    }
                    for (int k = lstIndex[i]; k < count; k++)
                    {
                       
                       
                        
                            if ((string)arrHeaderName[0, j] == Config.Classes.clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[k].YearMonth)
                                && bll.ListCPACustomer[iResultIndex].CustomerID == data[i, 0].ToString())
                            {
                                //show report and finalize
                                if (bll.ListCPACustomer[k].CPAStatus == 1 && !bll.ListCPACustomer[k].ReportStatus)
                                {
                                    data[i, j] = (double)bll.ListCPACustomer[k].Report_Value;
                                    // sum total by quarter
                                    iTotalQuarter += (double)bll.ListCPACustomer[k].Report_Value;
                                    // sum total by year
                                    iTotalYear += (double)bll.ListCPACustomer[k].Report_Value;
                                    iTotalAveYear += (double)bll.ListCPACustomer[k].Report_Value;
                                }
                                else
                                {
                                    data[i, j] = zero;
                                }

                                if (data[iRow, j] == null)
                                {
                                    data[iRow, j] = data[i, j];
                                    m_DataTotalTop[0, j - 4] = data[iRow, j];
                                }
                                else
                                {
                                    data[iRow, j] = (double)data[iRow, j] + (double)data[i, j];
                                    m_DataTotalTop[0, j - 4] = data[iRow, j];
                                }

                                iResultIndex++;
                                break;

                            }
                            else
                            {
                                data[i, j] = zero;
                            }
                            
                    }
                    if (data[iRow, j] == null)
                    {
                        data[iRow, j] = zero;
                        m_DataTotalTop[0, j - 4] = data[iRow, j];
                    }
                    if (data[iRow, j + 1] == null)
                    {
                        data[iRow, j + 1] = zero;
                        m_DataTotalTop[0, j - 4] = data[iRow, j];
                    }
                    ///cal total
                    if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_TOTAL) )
                    {
                        if (arrHeaderName[0, j].ToString().Contains("~"))///cal for quarterly
                        {
                            //export total quarter
                            data[i, j] = iTotalQuarter.ToString(FORMAT_EXPORT_CELL);
                            data[iRow, j] = (Convert.ToDouble(data[iRow, j]) + Convert.ToDouble(data[i, j])).ToString(FORMAT_EXPORT_CELL);
                            m_DataTotalTop[0, j - 4] = data[iRow, j];
                            //export average quarter
                            data[i, j + 1] = (double)iTotalQuarter / clsCPAConstant.MONTH_PER_QUARTER;
                            data[iRow, j + 1] = (double)data[iRow, j + 1] + (double)data[i, j + 1];
                            m_DataTotalTop[0, j - 3] = data[iRow, j +1];
                            j++;
                            iTotalQuarter = 0;
                        }
                        else ///cal for yearly
                        {
                            //export total year
                            data[i, j] = iTotalYear;
                            data[iRow, j] = (double)data[iRow, j] + (double)data[i, j];
                            m_DataTotalTop[0, j - 4] = data[iRow, j];
                            //export average year
                            data[i, j + 1] =iTotalAveYear / clsCPAConstant.MONTH_PER_YEAR;
                            data[iRow, j + 1] = (double)data[iRow, j + 1] + (double)data[i, j + 1];
                            m_DataTotalTop[0, j - 3] = data[iRow, j + 1];
                            j++;
                            iTotalYear = 0;
                        }
                        continue;
                    }
                   
                }
            }

            return data;
        }

        /// <summary>
        /// Get data for report 03
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Co Phuong
        /// @endcond
        private object[,] GetDataForReport_On_CPA_By_Account_Officer_Top_20_Customers(ref int iRow, object[,] arrHeaderName)
        {
            clsReportBLL bll = new clsReportBLL();
            bll.GetListCPAReportOnCPAbyAccountOfficerTop20Customer(m_DateFrom, m_DateTo, m_CusCode, m_CusFullName, m_DepartmentValue, m_TeamID, m_JnjName, m_VnAccID, m_JpAccID,m_realFrom);
            iRow = bll.ListCPACustomer.AsEnumerable().GroupBy(r => r.CustomerID).Count();
            object[,] data = new object[iRow, arrHeaderName.Length];
            object[,] dataTotal = new object[1, arrHeaderName.Length - 4];
            dataTotal[0, 0] = clsCPAConstant.R_H_TOTAL;
            int iResultIndex = 0;

            List<int> lstIndex = new List<int>();

            string cusId = "";
            if (bll.ListCPACustomer.Count > 0)
            {
                cusId = bll.ListCPACustomer[0].CustomerID;
            }
            lstIndex.Add(0);
            for (int i = 0; i < bll.ListCPACustomer.Count; i++)
            {
                if (bll.ListCPACustomer[i].CustomerID != cusId)
                {

                    lstIndex.Add(i);
                    cusId = bll.ListCPACustomer[i].CustomerID;
                }
            }
            double zero = 0;
            for (int i = 0; i < iRow; i++)
            {
                data[i, 0] = bll.ListCPACustomer[iResultIndex].CustomerID;
                data[i, 1] = bll.ListCPACustomer[iResultIndex].CustomerName;
                data[i, 2] = bll.ListCPACustomer[iResultIndex].Team;
                data[i, 3] = bll.ListCPACustomer[iResultIndex].ShortJP;
                data[i, 4] = bll.ListCPACustomer[iResultIndex].ShortVN;
                double iTotalYear = 0;
                double iTotalQuarter = 0;
                double iTotalAveYear = 0;
                for (int j = 5; j < arrHeaderName.Length; j++)
                {
                    int count = 0;

                    try
                    {
                        count = lstIndex[i + 1];
                    }
                    catch (Exception ex)
                    {
                        count = bll.ListCPACustomer.Count;
                    }
                    for (int k = lstIndex[i]; k < count; k++)
                    {


                        if (arrHeaderName[0, j].Equals(clsCommonFunctions.GetMonthYearShowOnExcel(bll.ListCPACustomer[k].YearMonth))
                                && bll.ListCPACustomer[k].CustomerID == data[i, 0].ToString())
                            {
                                //check show report and finalize data
                                if (bll.ListCPACustomer[k].CPAStatus == 1 && !bll.ListCPACustomer[k].ReportStatus)
                                {
                                    data[i, j] = (double)bll.ListCPACustomer[k].GetCPaByAccount();
                                    if (dataTotal[0, j-4]== null)
                                    {
                                        dataTotal[0, j-4] = (double)data[i, j];
                                    }
                                    else
                                    {
                                        dataTotal[0, j-4] = (double)dataTotal[0, j-4] + (double)data[i, j];
                                    }
                                    // sum total quarter
                                    iTotalQuarter += (double)bll.ListCPACustomer[k].GetCPaByAccount();
                                    // sum total year
                                    iTotalYear += (double)bll.ListCPACustomer[k].GetCPaByAccount();
                                    iTotalAveYear += (double)bll.ListCPACustomer[k].GetCPaByAccount();
                                }
                                else
                                {

                                    data[i, j] = zero;
                                }
                                iResultIndex++;
                                break;
                            }
                            else
                            {
                                data[i, j] = zero;
                            }
                       

                    }
                    if (dataTotal[0, j-4] == null )
                    {
                        dataTotal[0, j-4] = zero;
                        
                    }
                    if (dataTotal[0, j -3] == null)
                    {
                        dataTotal[0, j -3] = zero;
                    }
                    // cal total
                    if (arrHeaderName[0, j].ToString().Contains(clsCPAConstant.R_H_TOTAL))
                    {
                        if (arrHeaderName[0, j].ToString().Contains("~"))///cal for quarterly
                        {
                            // sum total quarter
                            data[i, j] = iTotalQuarter;
                            dataTotal[0, j-4] = (double)dataTotal[0, j-4] + (double)data[i, j];
                            // sum average quarter
                            data[i, j + 1] = (double)iTotalQuarter / clsCPAConstant.MONTH_PER_QUARTER;
                            
                            dataTotal[0, j - 3] = (double)dataTotal[0, j - 3] + (double)data[i, j + 1];
                            j++;
                            iTotalQuarter = 0;
                        }
                        else ///cal for yearly
                        {
                            data[i, j] = iTotalYear;
                            dataTotal[0, j-4] = (double)dataTotal[0, j-4] + (double)data[i, j];
                            data[i, j + 1] = (double)iTotalAveYear / clsCPAConstant.MONTH_PER_YEAR;
                            dataTotal[0, j -3] = (double)dataTotal[0, j-3] + (double)data[i, j + 1];
                            j++;
                            iTotalYear = 0;
                        }
                        continue;
                    }
                }
            }
            return dataTotal;
        }

        /// <summary>
        /// Get data rate for report 03
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Co Phuong
        /// @endcond
        private object[,] GetDataRateTopReport(int iCountDataTop, object[,] dataTop, object[,] dataTotal, int iTop)
        {
            object[,] data = new object[1, dataTotal.Length];
            data[0, 0] = string.Format(clsCPAConstant.R_TOTAL_RATE, iTop);
            for (int i = 1; i < dataTotal.Length; i++)
            {
                if (Convert.ToDouble(dataTotal[0, i]) == 0)
                {
                    data[0, i] = 0;
                }
                else
                {
                    data[0, i] = ((Convert.ToDouble(dataTop[iCountDataTop, i+4]) / Convert.ToDouble(dataTotal[0, i])) * 100);
                }
            }
            return data;

        }

        /// <summary>
        /// Export to excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            try
            {
                m_realFrom = txtFromQuarter.Value.Year.ToString();
                m_realFrom += clsCommonFunctions.FindStartMonthByQuater(txtFromQuarter.Value.Month);
                if (CheckQuarterInput() == false)
                {
                    clsMesageCollection.MessageNoTransactions();
                    return;
                }

                ExportToExcel();
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
        }

        /// <summary>
        /// Get date for report 01&02
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void GetDateForReport_On_CPA_By_Account_Officer()
        {
            m_iFromMonth = int.Parse(clsCommonFunctions.FindStartMonthByQuater(m_iFromQuarter));
            if (m_iFromMonth < m_iMonthStartSum)
            {
                m_iFromYear--;
                m_iDeleteMonthCount = m_iFromMonth - 4 + clsCPAConstant.MONTH_PER_YEAR + (m_iFromMonth - 4 + clsCPAConstant.MONTH_PER_YEAR) / 3 * 2;
            }
            else
                m_iDeleteMonthCount = m_iFromMonth - 4 + (m_iFromMonth - 4) / 3 * 2;

            m_iFromMonth = m_iMonthStartSum;
            m_DateFrom = m_iFromYear + "" + m_iMonthStartSum.ToString("00");
            m_iToMonth = int.Parse(clsCommonFunctions.FindEndMonthByQuater(m_iToQuarter));
            m_DateTo = m_iToYear + "" + clsCommonFunctions.FindEndMonthByQuater(txtToQuarter.Value.Month);
        }
        /// <summary>
        /// Get header name of report no.01
        /// </summary>
        /// <returns>List<string></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void GetHeaderNameReport_On_CPA_By_Account_Officer()
        {
            GetDateForReport_On_CPA_By_Account_Officer();
            DateTime startDay = new DateTime(m_iFromYear, m_iFromMonth, 1);
            DateTime endDay = new DateTime(m_iToYear, m_iToMonth, 1);
            int year = endDay.Year - startDay.Year;
            int month = endDay.Month - startDay.Month;
            int totalMonth = year * 12 + month;
            m_RoughDate = new List<string>();
            m_RoughDate.Add(startDay.ToString("yyyyMM"));
            for (int i = 0; i < totalMonth; i++)
            {
                startDay = startDay.AddMonths(1);
                string temp = startDay.ToString("yyyyMM");
                m_RoughDate.Add(temp);

                if (startDay.Month == 3 || startDay.Month == 6 || startDay.Month == 9 || startDay.Month == 12)
                {
                    DateTime date = startDay.AddMonths(-2);
					string strDate = (clsCommonFunctions.GetMonthYearShowOnExcelFromTo(date.ToString("yyyyMM"))).Remove(3);
					m_RoughDate.Add(clsCPAConstant.R_H_TOTAL + " " + strDate + "~" + clsCommonFunctions.GetMonthYearShowOnExcelFromTo(temp));//.Remove(4, 1));
					m_RoughDate.Add(clsCPAConstant.R_H_AVERAGE + " " + strDate + "~" + clsCommonFunctions.GetMonthYearShowOnExcelFromTo(temp));//.Remove(4, 1));
                    if (startDay.Month == 3)
                    {
                        m_RoughDate.Add(clsCPAConstant.R_H_TOTAL + " " + (startDay.Year - 1).ToString());
                        m_RoughDate.Add(clsCPAConstant.R_H_AVERAGE + " " + (startDay.Year - 1).ToString());
                    }
                }
            }
            m_RoughDate.Insert(0, clsCPAConstant.R_VN_ACCOUNT_OFFICER);
            m_RoughDate.Insert(0, clsCPAConstant.R_JP_ACCOUNT_OFFICER);
            m_RoughDate.Insert(0, clsCPAConstant.R_H_TEAM);
            m_RoughDate.Insert(0, clsCPAConstant.R_H_NAME);
            m_RoughDate.Insert(0, clsCPAConstant.R_H_CODE);
        }

        /// <summary>
        /// Get date for report 03
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDateForReport_On_CPA_By_Account_Officer_Top_20_Customers()
        {
            m_iFromMonth = int.Parse(clsCommonFunctions.FindStartMonthByQuater(m_iFromQuarter));
            if (m_iFromMonth < m_iMonthStartSum)
            {
                m_iFromYear--;
                m_iDeleteMonthCount = m_iFromMonth - 4 + clsCPAConstant.MONTH_PER_YEAR + (m_iFromMonth - 4 + clsCPAConstant.MONTH_PER_YEAR) / 3 * 2;
            }
            else
                m_iDeleteMonthCount = m_iFromMonth - 4 + (m_iFromMonth - 4) / 3 * 2;

            m_iFromMonth = m_iMonthStartSum;
            m_DateFrom = m_iFromYear + "" + m_iFromMonth.ToString("00");
            m_iToMonth = int.Parse(clsCommonFunctions.FindEndMonthByQuater(m_iToQuarter));
            m_DateTo = m_iToYear + "" + m_iToMonth.ToString("00");
        }

        /// <summary>
        /// Get header name of report no.03
        /// </summary>
        /// <returns>List<string></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private List<string> GetHeaderNameReport_On_CPA_By_Account_Officer_Top_20_Customers()
        {
            GetDateForReport_On_CPA_By_Account_Officer_Top_20_Customers();
            DateTime startDay = new DateTime(m_iFromYear, m_iFromMonth, 1);
            DateTime endDay = new DateTime(m_iToYear, m_iToMonth, 1);
            int year = endDay.Year - startDay.Year;
            int month = endDay.Month - startDay.Month;
            int totalMonth = year * 12 + month;
            List<string> strResult = new List<string>();
            strResult.Add(startDay.ToString("yyyyMM"));
            for (int i = 0; i < totalMonth; i++)
            {
                startDay = startDay.AddMonths(1);
                string temp = startDay.ToString("yyyyMM");
                strResult.Add(temp);

                if (startDay.Month == 3 || startDay.Month == 6 || startDay.Month == 9 || startDay.Month == 12)
                {
                    DateTime date = startDay.AddMonths(-2);
                    string a = (clsCommonFunctions.GetMonthYearShowOnExcelFromTo(date.ToString("yyyyMM"))).Remove(3);
                    strResult.Add(clsCPAConstant.R_H_TOTAL + " " + a + "~" + (clsCommonFunctions.GetMonthYearShowOnExcelFromTo(temp)));//.Remove(4, 1));
                    strResult.Add(clsCPAConstant.R_H_AVERAGE + " " + a + "~" + (clsCommonFunctions.GetMonthYearShowOnExcelFromTo(temp)));//.Remove(4, 1));
                    if (startDay.Month == 3)
                    {
                        strResult.Add(clsCPAConstant.R_H_TOTAL + " " + (startDay.Year - 1).ToString());
                        strResult.Add(clsCPAConstant.R_H_AVERAGE + " " + (startDay.Year - 1).ToString());
                    }
                }
            }
            strResult.Insert(0, clsCPAConstant.R_VN_ACCOUNT_OFFICER);
            strResult.Insert(0, clsCPAConstant.R_JP_ACCOUNT_OFFICER);
            strResult.Insert(0, clsCPAConstant.R_H_TEAM);
            strResult.Insert(0, clsCPAConstant.R_H_NAME);
            strResult.Insert(0, clsCPAConstant.R_H_CODE);

            
            return strResult;
        }

        /// <summary>
        /// Set value for template name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void radReportByCustomer_CheckedChanged(object sender, EventArgs e)
        {
            m_radName = clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER;
            m_TemplateName = clsCPAConstant.REPORT_ON_CPA_BY_ACCOUNT_OFFICER;
        }

        /// <summary>
        /// Set value for template name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void radReportByCBD1_CheckedChanged(object sender, EventArgs e)
        {
            m_radName = clsCPAConstant.R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS;
            m_TemplateName = clsCPAConstant.REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS;
        }

        /// <summary>
        /// Set value for template name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void radReportByCBD1Top20_CheckedChanged(object sender, EventArgs e)
        {
            m_TemplateName = clsCPAConstant.REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS;
        }

        /// <summary>
        /// call radReportByCustomer_CheckedChanged even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void label1_Click(object sender, EventArgs e)
        {
            radReportByCustomer_CheckedChanged(sender, e);
            rad0102.Checked = true;
        }

        /// <summary>
        /// call radReportByCBD1_CheckedChanged even
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void label2_Click(object sender, EventArgs e)
        {
            radReportByCBD1_CheckedChanged(sender, e);
            rad03.Checked = true;
        }


        /// <summary>
        /// Close this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmScreenReportProfit_Load(object sender, EventArgs e)
        {
            m_FromQuarterText = txtFromQuarter.Value.ToString("yyyyMM");
            m_ToQuarterText = txtToQuarter.Value.ToString("yyyyMM");
            m_DepartmentValue = cbbDepartment.SelectedValue.ToString();
            m_JpAccID = cbbJPAcc.SelectedValue.ToString();
            m_JnjID = cbbJNJ.SelectedValue.ToString();
            m_CusCode = txtCustomerCode.Text.Trim();
            m_TeamID = cbbTeam.SelectedValue.ToString();
            m_VnAccID = cbbVNAcc.SelectedValue.ToString();
            m_CusFullName = txtCustomerFullName.Text.Trim();

        }
        /// <summary>
        /// Get department value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void cbbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_DepartmentValue = ((DepartmentDTO)cbbDepartment.SelectedItem).DepartmentID;
            m_DepartmentName = ((DepartmentDTO)cbbDepartment.SelectedItem).DepartmentName;
            SetDataCombobox(m_DepartmentValue, "");
        }
        /// <summary>
        /// Get VN Acc value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void cbbVNAcc_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_VnAccID = ((UserDTO)cbbVNAcc.SelectedItem).UserID;
            m_VnAccName = ((UserDTO)cbbVNAcc.SelectedItem).UserName;

            if (m_IsOnSetDataCombobox == false)
                m_oldVN = ((UserDTO)cbbVNAcc.SelectedItem).UserID;
               
        }
        /// <summary>
        /// Get Team value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond 
        private void cbbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TeamID = ((SectionDTO)cbbTeam.SelectedItem).SectionID;
            m_TeamName = ((SectionDTO)cbbTeam.SelectedItem).SectionName;
            if (m_IsOnSetDataCombobox == false)
            {
                m_oldTeam = ((SectionDTO)cbbTeam.SelectedItem).SectionID;
                SetDataCombobox(m_DepartmentValue, m_TeamID);
            } 
          
        }
        /// <summary>
        /// Get JP Acc value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void cbbJPAcc_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_JpAccID = ((UserDTO)cbbJPAcc.SelectedItem).UserID;
            m_JpAccName = ((UserDTO)cbbJPAcc.SelectedItem).UserName;
            

            if (m_IsOnSetDataCombobox == false)
                m_oldJP = ((UserDTO)cbbJPAcc.SelectedItem).UserID;
        }
        /// <summary>
        /// Get JNJ value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void cbbJNJ_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_JnjID = ((ParameterDTO)cbbJNJ.SelectedItem).Value;
            m_JnjName = ((ParameterDTO)cbbJNJ.SelectedItem).Name;
        }
        /// <summary>
        /// Get from quarter value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void txtFromQuarter_ValueChanged(object sender, EventArgs e)
        {
            m_FromQuarterText = txtFromQuarter.Value.ToString("yyyyMM");
        }
        /// <summary>
        /// Get To quarter value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void txtToQuarter_ValueChanged(object sender, EventArgs e)
        {
            m_ToQuarterText = txtToQuarter.Value.ToString("yyyyMM");
        }

        /// <summary>
        /// Get customer code
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void txtCustomerCode_TextChanged(object sender, EventArgs e)
        {
            m_CusCode = txtCustomerCode.Text.Trim();
        }

        /// <summary>
        /// Get customer name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void txtCustomerFullName_TextChanged(object sender, EventArgs e)
        {
            m_CusFullName = txtCustomerFullName.Text.Trim();
        }

       

   
        

    }
}