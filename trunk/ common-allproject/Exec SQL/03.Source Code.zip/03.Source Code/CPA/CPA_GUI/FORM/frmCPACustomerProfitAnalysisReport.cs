﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Customer Profiability Analysis Report Screen
 * for CPA module.
 */
using System;
using System.Windows.Forms;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Functions;
namespace Phoenix.Cpa.Gui.Forms
{
    /// <summary>
    /// This form use to export Customer profit analysis report
    /// Phong: in charge at 2/2013
    /// </summary>
    public partial class frmCustomerProfitAnalysisReport : MasterForm
	{  
		/// <summary>
		/// Constructor
		/// </summary>
		/// <exception cref="ex"></exception>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public frmCustomerProfitAnalysisReport()
		{
			InitializeComponent();
			try
			{ 
				LoadJNJList();
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
			//Yen Phan
			SetFormStyle();
		}
		
		/// <summary>
		/// Export report
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// <exception cref="ioE"></exception>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnExportReport_Click(object sender, EventArgs e)
		{

            try
            {
                btnExportReport.Enabled = false;
               
                Run();
                Complete();
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
		}


        private void Run()
        {
            frmReportCustomerProfitAnalysis frm = new frmReportCustomerProfitAnalysis(txtCustomerCode.Text.Trim(), txtCustomerFullName.Text.Trim(), cbbJNJ.SelectedValue.ToString(), clMonthYear.Value);
            if (frm.Show == true)
                frm.Show();
            else
                frm.Close();
        }
        private void Complete()
        {
            btnExportReport.Enabled = true;      
        }
		/// <summary>
		/// Load JNJ List
		/// </summary>
		/// <exception cref="ex"></exception>

		private void LoadJNJList()
		{
			try
			{

				cbbJNJ.DataSource = clsGetDataCombobox.Instance().lstJNJ;
				cbbJNJ.DisplayMember = clsCPAConstant.NAME;
				cbbJNJ.ValueMember = clsCPAConstant.NAME;
				cbbJNJ.DropDownStyle = ComboBoxStyle.DropDownList;
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

		/// <summary>
		/// Close this form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


	}
}
