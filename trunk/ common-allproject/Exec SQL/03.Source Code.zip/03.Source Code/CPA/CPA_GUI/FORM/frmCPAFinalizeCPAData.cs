﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Finalized Data Screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms; 
using System.Collections;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Functions;
namespace Phoenix.Cpa.Gui.Forms
{
    /// <summary>
    /// This form use to view and update Finalized status of CPA
    /// Phong: in charge at 2/2013
    /// </summary>
    public partial class frmFinalizeCPAData : MasterForm
	{
        
		clsFinalizeCPABus m_FinalCPABus = null;
		string m_MonthYearCond = "";
		string m_Complete = "0";
		ArrayList m_completeList;
        string m_UserName = clsUserInfo.UserNo.ToString();
		bool m_FormClose = false;
		int m_selectedrowIndex = 0;
		int m_selectedcolumnIndex = 0;
        private List<int> iRowChanges;
        private string m_From = "";
        private string m_To = "";
		/*<summary> Dictionary<key, value>
		 key: month year 
		 ex: 012013
		 value: check or not 
		 ex: 1 or 0
		 Yen Phan
		 </summary>
		 */
		Dictionary<string, string> m_DicCompleteList = new Dictionary<string, string>();

		/// <summary>
		/// Initializes a new instance of the <see cref="frmFinalizeCPAData" /> class
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public frmFinalizeCPAData() : base()
		{
			InitializeComponent();
			m_FinalCPABus = new clsFinalizeCPABus();
            SetSecurity();
            //format datagrid
            dtgCompleteCPA.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dtgCompleteCPA.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dtgCompleteCPA.Columns[1].DefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
            dtgCompleteCPA.ColumnHeadersDefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
            dtgCompleteCPA.EnableHeadersVisualStyles = false;
            dtgCompleteCPA.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgCompleteCPA.GotFocus += new EventHandler(dtgCompleteCPA_GotFocus);

            iRowChanges = new List<int>();
            m_From = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString("00");
            m_To = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString("00");
            searhCPA();
			//Yen Phan
			SetFormStyle();
		}

        void dtgCompleteCPA_GotFocus(object sender, EventArgs e)
        {
            try
            {
                dtgCompleteCPA.CurrentCell = dtgCompleteCPA.Rows[0].Cells[0];
            }
            catch(Exception ex)
            {
            }
        }
		


		/// <summary>
		/// btnSearch_Click
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnSearch_Click(object sender, EventArgs e)
		{
            try
            {
                m_From = clsCommonFunctions.GetMonthYearFromInputToDatabase(cldMonthYearFrom.Text);
                m_To = clsCommonFunctions.GetMonthYearFromInputToDatabase(cldMonthYearTo.Text);
                searhCPA();
            }
            catch (Exception ex)
            {
                this.ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
		}
				
		/// <summary>
		/// Indicate that if there is any change on datagridview by user
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private bool ChangedByUser()
		{
			try
			{
				for (int i = 0; i < dtgCompleteCPA.Rows.Count; i++)
					if (dtgCompleteCPA[0, i].Value.ToString() != m_completeList[i].ToString())
						return true;
				return false;
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
			return false;
		}

		
		/// <summary>
		/// Search CPA with input conditions
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void searhCPA()
		{
            m_FinalCPABus = new clsFinalizeCPABus();
				dtgCompleteCPA.Rows.Clear();
              
				m_Complete = convertBoolToTinyInt(ckbComplete.Checked.ToString());

				ArrayList arrCusFinalCPADs = m_FinalCPABus.GetFinalizeCPADs(m_From,m_To, m_Complete);

                
				if (arrCusFinalCPADs != null)
				{
                    for (int i = 0; i < arrCusFinalCPADs.Count; i++)
					{
						string[] row = (string[]) arrCusFinalCPADs[i];
						dtgCompleteCPA.Rows.Add(convertTinyIntToBool(row[0]),clsCommonFunctions.GetMonthYearShowOnDataGrid((string)row[1]));
					}
				}
				LoadCompleteStatusList();

                if (arrCusFinalCPADs.Count == 0 && this.Visible == true)
                {
                    clsMesageCollection.MessageNoTransactions();

                } 
		}

		/// <summary>
		/// Load Complete status list
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void LoadCompleteStatusList()
		{
			try
			{
				int iRowCount = dtgCompleteCPA.Rows.Count;
				m_completeList = new ArrayList(iRowCount);
				string strCheckValue = "";
				string strDateTimeKey = "";
				m_DicCompleteList.Clear();
				for (int i = 0; i < iRowCount; i++)
				{
					strCheckValue = dtgCompleteCPA[0, i].Value.ToString();
					strDateTimeKey = dtgCompleteCPA[1, i].Value.ToString();
					m_completeList.Add(strCheckValue);
					m_DicCompleteList.Add(strDateTimeKey, convertBoolToTinyInt(strCheckValue));
				}
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

		/// <summary>
		/// Convert tiny int to boolean
		/// </summary>
		/// <param name="strTinyInt"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private bool convertTinyIntToBool(string strTinyInt)
		{
			if (strTinyInt == "0")
				return false;
			return true;
		}

		/// <summary>
		/// Convert boolean to tiny int 
		/// </summary>
		/// <param name="strComplete"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private string convertBoolToTinyInt(string strComplete)
		{
			if (bool.Parse(strComplete))
				return "1";
			return "0";
		}

		/// <summary>
		/// dtgCompleteCPA_CellEndEdit
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void dtgCompleteCPA_CellEndEdit(object sender, DataGridViewCellEventArgs e)
		{
			dtgCompleteCPA.ReadOnly = true;
		}

		/// <summary>
		/// dtgCompleteCPA_CellMouseClick
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void dtgCompleteCPA_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				if (e.ColumnIndex == 0 && e.RowIndex >= 0)
					dtgCompleteCPA[0, e.RowIndex].Value = !(bool.Parse(dtgCompleteCPA[0, e.RowIndex].Value.ToString()));
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

		/// <summary>
		/// btnSave_Click
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnSave_Click(object sender, EventArgs e)
		{
            try
            {
                save();
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                 Environment.NewLine +
                 ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
                try
                {
                    m_FinalCPABus.RollBack();
                }
                catch (Exception )
                {
                }
            }
        
           
		}


		/// <summary>
		/// Show dialog transition of save procedure
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void save()
		{
			DialogResult dlgResult = new DialogResult();

            if (iRowChanges.Count > 0)           
            {

                dlgResult = clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                                                            COMMON.Properties.Settings.Default.CONF_ACTION, new string[] { clsCPAConstant.ACT_UPDATE, clsCPAConstant.FINALIZE_TEXT });
                if (dlgResult == DialogResult.Yes)
                {
                    //Save to database
                    SaveFinalizeCPAList();
                    searhCPA();
                    
                }
                
                    
            }
		
		}

		/// <summary>
		/// Save data in dataGridview to database
		/// Reload complete list
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void SaveFinalizeCPAList()
		{
            m_FinalCPABus = new clsFinalizeCPABus();
				if (cldMonthYearFrom.Text.Contains("/"))
					m_MonthYearCond = cldMonthYearFrom.Text.Replace("/", "");
				else m_MonthYearCond = cldMonthYearFrom.Text;

				ArrayList arrFinalCPAList = new ArrayList();
                int intResult = 0;
                for (int i = 0; i < iRowChanges.Count; i++)
                {
                    arrFinalCPAList.Add(new string[] { convertBoolToTinyInt(dtgCompleteCPA[0, iRowChanges[i]].Value.ToString()), clsCommonFunctions.GetYearMonthFromDatagridToDatabase(dtgCompleteCPA[1, iRowChanges[i]].Value.ToString()) });
                    
                    
                }
               
                intResult = m_FinalCPABus.UpdateFinalizeCPA(arrFinalCPAList);
                if (intResult >= 1)
                {    

                    clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                                                            COMMON.Properties.Settings.Default.INFO_ACTION_SUCCESS, new string[] { clsCPAConstant.ACT_UPDATING, clsCPAConstant.FINALIZE_TEXT });
                    m_FinalCPABus.Commit();
                    arrFinalCPAList.Clear();
                    iRowChanges.Clear();
                }
                else
                {
                   
                   clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                                                           COMMON.Properties.Settings.Default.INFO_ACTION_FAIL, new string[] { clsCPAConstant.ACT_UPDATING, clsCPAConstant.FINALIZE_TEXT });
                }
				LoadCompleteStatusList();
			
		}
		

		/// <summary>
		/// Change value of the checkbox when tab on this header row by space bar
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void dtgCompleteCPA_KeyDown(object sender, KeyEventArgs e)
		{

            if (e.KeyValue == 9)
            {

               // if (mRowCur == dtgCompleteCPA.Rows.Count - 1) mRowCur = 0;
                if (dtgCompleteCPA.Rows.Count > mRowCur + 1)
                {
                   // mRowCur = mRowCur + 1;
                    dtgCompleteCPA.CurrentCell = dtgCompleteCPA.Rows[mRowCur].Cells[1];
                    dtgCompleteCPA.Rows[mRowCur].Selected = true;
                }
                if (mRowCur == dtgCompleteCPA.Rows.Count - 1)
                {
                    btnSave.Focus();
                    //dtgCompleteCPA.CurrentCell = dtgCompleteCPA.Rows[0].Cells[0];
                }
            }
			if (e.KeyCode == Keys.Space && m_selectedrowIndex >= 0 && m_selectedcolumnIndex == 0)
				dtgCompleteCPA[m_selectedcolumnIndex, m_selectedrowIndex].Value = !(bool.Parse(dtgCompleteCPA[m_selectedcolumnIndex, m_selectedrowIndex].Value.ToString()));

		}

		/// <summary>
		/// dtgCompleteCPA_CellEnter
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void dtgCompleteCPA_CellEnter(object sender, DataGridViewCellEventArgs e)
		{
			m_selectedcolumnIndex = e.ColumnIndex;
			m_selectedrowIndex = e.RowIndex;
		}

		/// <summary>
		/// Close this form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {            
            this.Close();
        }


        /// <summary>
        /// get changed data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgCompleteCPA_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 && e.RowIndex >=0)
            {
                if (dtgCompleteCPA[e.ColumnIndex, e.RowIndex].Value.ToString() != m_completeList[e.RowIndex].ToString())
                    iRowChanges.Add(e.RowIndex);
                else
                {
                    if (iRowChanges.Contains(e.RowIndex))
                        iRowChanges.Remove(e.RowIndex);
                }

            }
        }
        /// <summary>
        /// check save data before close form 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmFinalizeCPAData_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (ForceClose == false)
            {
                DialogResult dlgResult = new DialogResult();

                if (iRowChanges.Count > 0)
                {


                    dlgResult = clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                                                               clsCPACommonMessage.DO_YOU_WANT_SAVE);
                    if (dlgResult == DialogResult.Yes)
                    {
                        //Save to database
                        SaveFinalizeCPAList();

                    }
                    if (dlgResult != DialogResult.Cancel)
                        iRowChanges.Clear();
                    if (dlgResult == DialogResult.Cancel)
                        e.Cancel = true;
                }
            }
        }
        int mRowCur = 0;
        private void dtgCompleteCPA_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            mRowCur = e.RowIndex;
        }

 
	}
}