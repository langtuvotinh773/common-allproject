﻿using UserCtrl;
namespace Phoenix.Cpa.Gui.Forms
{
    partial class frmScreenReportMonth
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbbVNAcc = new System.Windows.Forms.ComboBox();
            this.cbbTeam = new System.Windows.Forms.ComboBox();
            this.cbbJPAcc = new System.Windows.Forms.ComboBox();
            this.cbbDepartment = new System.Windows.Forms.ComboBox();
            this.txtCustomerCode = new System.Windows.Forms.TextBox();
            this.txtCustomerFullName = new System.Windows.Forms.TextBox();
            this.lblCustomerCode = new System.Windows.Forms.Label();
            this.lblJO = new System.Windows.Forms.Label();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.lblCustomerFullName = new System.Windows.Forms.Label();
            this.lblNewPerson = new System.Windows.Forms.Label();
            this.lblTeam = new System.Windows.Forms.Label();
            this.lblToMonthYear = new System.Windows.Forms.Label();
            this.lblFromMonthYear = new System.Windows.Forms.Label();
            this.lblJNJ = new System.Windows.Forms.Label();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblListReport = new System.Windows.Forms.Label();
            this.rad_Report_On_Deposit_Average_Balance_By_Customer = new System.Windows.Forms.RadioButton();
            this.rad_Report_On_Loan_Average_Balance_By_Customer = new System.Windows.Forms.RadioButton();
            this.rad_Report_On_Commission_And_Fee_By_Customer = new System.Windows.Forms.RadioButton();
            this.rad_Report_On_Forex_Profit_By_Customer = new System.Windows.Forms.RadioButton();
            this.rad_Report_On_Total_Profit_By_Customer = new System.Windows.Forms.RadioButton();
            this.rad_Report_On_Deposit_Profit_By_Customer = new System.Windows.Forms.RadioButton();
            this.rad_Report_On_Loan_Profit_By_Customer = new System.Windows.Forms.RadioButton();
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance = new System.Windows.Forms.RadioButton();
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance = new System.Windows.Forms.RadioButton();
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.cbbJNJ = new System.Windows.Forms.ComboBox();
            this.clToMonthYear = new UserCtrl.MonthYearCalendar();
            this.clFromMonthYear = new UserCtrl.MonthYearCalendar();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbbVNAcc
            // 
            this.cbbVNAcc.FormattingEnabled = true;
            this.cbbVNAcc.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbVNAcc.Location = new System.Drawing.Point(494, 50);
            this.cbbVNAcc.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.cbbVNAcc.Name = "cbbVNAcc";
            this.cbbVNAcc.Size = new System.Drawing.Size(253, 21);
            this.cbbVNAcc.TabIndex = 5;
            this.cbbVNAcc.SelectedIndexChanged += new System.EventHandler(this.cbbVNAcc_SelectedIndexChanged);
            // 
            // cbbTeam
            // 
            this.cbbTeam.FormattingEnabled = true;
            this.cbbTeam.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbTeam.Location = new System.Drawing.Point(494, 28);
            this.cbbTeam.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.cbbTeam.Name = "cbbTeam";
            this.cbbTeam.Size = new System.Drawing.Size(253, 21);
            this.cbbTeam.TabIndex = 3;
            this.cbbTeam.SelectedIndexChanged += new System.EventHandler(this.cbbTeam_SelectedIndexChanged);
            // 
            // cbbJPAcc
            // 
            this.cbbJPAcc.FormattingEnabled = true;
            this.cbbJPAcc.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbJPAcc.Location = new System.Drawing.Point(111, 50);
            this.cbbJPAcc.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.cbbJPAcc.Name = "cbbJPAcc";
            this.cbbJPAcc.Size = new System.Drawing.Size(224, 21);
            this.cbbJPAcc.TabIndex = 4;
            this.cbbJPAcc.SelectedIndexChanged += new System.EventHandler(this.cbbJPAcc_SelectedIndexChanged);
            // 
            // cbbDepartment
            // 
            this.cbbDepartment.FormattingEnabled = true;
            this.cbbDepartment.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbDepartment.Location = new System.Drawing.Point(111, 28);
            this.cbbDepartment.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.cbbDepartment.Name = "cbbDepartment";
            this.cbbDepartment.Size = new System.Drawing.Size(224, 21);
            this.cbbDepartment.TabIndex = 2;
            this.cbbDepartment.SelectedIndexChanged += new System.EventHandler(this.cbbDepartment_SelectedIndexChanged);
            // 
            // txtCustomerCode
            // 
            this.txtCustomerCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCustomerCode.Location = new System.Drawing.Point(111, 72);
            this.txtCustomerCode.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.txtCustomerCode.Name = "txtCustomerCode";
            this.txtCustomerCode.Size = new System.Drawing.Size(224, 20);
            this.txtCustomerCode.TabIndex = 6;
            // 
            // txtCustomerFullName
            // 
            this.txtCustomerFullName.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCustomerFullName.Location = new System.Drawing.Point(494, 72);
            this.txtCustomerFullName.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.txtCustomerFullName.Name = "txtCustomerFullName";
            this.txtCustomerFullName.Size = new System.Drawing.Size(254, 20);
            this.txtCustomerFullName.TabIndex = 7;
            // 
            // lblCustomerCode
            // 
            this.lblCustomerCode.AutoSize = true;
            this.lblCustomerCode.Location = new System.Drawing.Point(9, 78);
            this.lblCustomerCode.Name = "lblCustomerCode";
            this.lblCustomerCode.Size = new System.Drawing.Size(79, 13);
            this.lblCustomerCode.TabIndex = 5;
            this.lblCustomerCode.Text = "Customer Code";
            // 
            // lblJO
            // 
            this.lblJO.AutoSize = true;
            this.lblJO.Location = new System.Drawing.Point(9, 57);
            this.lblJO.Name = "lblJO";
            this.lblJO.Size = new System.Drawing.Size(96, 13);
            this.lblJO.TabIndex = 6;
            this.lblJO.Text = "JP Account Officer";
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Location = new System.Drawing.Point(9, 35);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(62, 13);
            this.lblDepartment.TabIndex = 3;
            this.lblDepartment.Text = "Department";
            // 
            // lblCustomerFullName
            // 
            this.lblCustomerFullName.AutoSize = true;
            this.lblCustomerFullName.Location = new System.Drawing.Point(366, 78);
            this.lblCustomerFullName.Name = "lblCustomerFullName";
            this.lblCustomerFullName.Size = new System.Drawing.Size(101, 13);
            this.lblCustomerFullName.TabIndex = 4;
            this.lblCustomerFullName.Text = "Customer Full Name";
            // 
            // lblNewPerson
            // 
            this.lblNewPerson.AutoSize = true;
            this.lblNewPerson.Location = new System.Drawing.Point(366, 57);
            this.lblNewPerson.Name = "lblNewPerson";
            this.lblNewPerson.Size = new System.Drawing.Size(99, 13);
            this.lblNewPerson.TabIndex = 9;
            this.lblNewPerson.Text = "VN Account Officer";
            // 
            // lblTeam
            // 
            this.lblTeam.AutoSize = true;
            this.lblTeam.Location = new System.Drawing.Point(366, 35);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.Size = new System.Drawing.Size(34, 13);
            this.lblTeam.TabIndex = 10;
            this.lblTeam.Text = "Team";
            // 
            // lblToMonthYear
            // 
            this.lblToMonthYear.AutoSize = true;
            this.lblToMonthYear.Location = new System.Drawing.Point(366, 13);
            this.lblToMonthYear.Name = "lblToMonthYear";
            this.lblToMonthYear.Size = new System.Drawing.Size(80, 13);
            this.lblToMonthYear.TabIndex = 7;
            this.lblToMonthYear.Text = "To Month/Year";
            // 
            // lblFromMonthYear
            // 
            this.lblFromMonthYear.AutoSize = true;
            this.lblFromMonthYear.Location = new System.Drawing.Point(9, 13);
            this.lblFromMonthYear.Name = "lblFromMonthYear";
            this.lblFromMonthYear.Size = new System.Drawing.Size(90, 13);
            this.lblFromMonthYear.TabIndex = 8;
            this.lblFromMonthYear.Text = "From Month/Year";
            // 
            // lblJNJ
            // 
            this.lblJNJ.AutoSize = true;
            this.lblJNJ.Location = new System.Drawing.Point(9, 100);
            this.lblJNJ.Name = "lblJNJ";
            this.lblJNJ.Size = new System.Drawing.Size(25, 13);
            this.lblJNJ.TabIndex = 6;
            this.lblJNJ.Text = "JNJ";
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnExportExcel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnExportExcel.Location = new System.Drawing.Point(542, 410);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(100, 23);
            this.btnExportExcel.TabIndex = 9;
            this.btnExportExcel.Text = "&Export Excel";
            this.btnExportExcel.UseVisualStyleBackColor = false;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.lblListReport, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_On_Deposit_Average_Balance_By_Customer, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_On_Loan_Average_Balance_By_Customer, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_On_Commission_And_Fee_By_Customer, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_On_Forex_Profit_By_Customer, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_On_Total_Profit_By_Customer, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_On_Deposit_Profit_By_Customer, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_On_Loan_Profit_By_Customer, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl11, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl12, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl13, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 130);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 11;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(736, 258);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // lblListReport
            // 
            this.lblListReport.AutoSize = true;
            this.lblListReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblListReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblListReport.Location = new System.Drawing.Point(52, 1);
            this.lblListReport.Margin = new System.Windows.Forms.Padding(0);
            this.lblListReport.Name = "lblListReport";
            this.lblListReport.Size = new System.Drawing.Size(683, 23);
            this.lblListReport.TabIndex = 4;
            this.lblListReport.Text = "List Report";
            this.lblListReport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rad_Report_On_Deposit_Average_Balance_By_Customer
            // 
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.AutoSize = true;
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.Checked = true;
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.Location = new System.Drawing.Point(4, 28);
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.Name = "rad_Report_On_Deposit_Average_Balance_By_Customer";
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.Size = new System.Drawing.Size(44, 16);
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.TabIndex = 0;
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.TabStop = true;
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.UseVisualStyleBackColor = true;
            this.rad_Report_On_Deposit_Average_Balance_By_Customer.CheckedChanged += new System.EventHandler(this.radDepositAveBal_CheckedChanged);
            // 
            // rad_Report_On_Loan_Average_Balance_By_Customer
            // 
            this.rad_Report_On_Loan_Average_Balance_By_Customer.AutoSize = true;
            this.rad_Report_On_Loan_Average_Balance_By_Customer.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_On_Loan_Average_Balance_By_Customer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_On_Loan_Average_Balance_By_Customer.Location = new System.Drawing.Point(4, 51);
            this.rad_Report_On_Loan_Average_Balance_By_Customer.Name = "rad_Report_On_Loan_Average_Balance_By_Customer";
            this.rad_Report_On_Loan_Average_Balance_By_Customer.Size = new System.Drawing.Size(44, 16);
            this.rad_Report_On_Loan_Average_Balance_By_Customer.TabIndex = 1;
            this.rad_Report_On_Loan_Average_Balance_By_Customer.TabStop = true;
            this.rad_Report_On_Loan_Average_Balance_By_Customer.UseVisualStyleBackColor = true;
            this.rad_Report_On_Loan_Average_Balance_By_Customer.CheckedChanged += new System.EventHandler(this.radLoanAveBal_CheckedChanged);
            // 
            // rad_Report_On_Commission_And_Fee_By_Customer
            // 
            this.rad_Report_On_Commission_And_Fee_By_Customer.AutoSize = true;
            this.rad_Report_On_Commission_And_Fee_By_Customer.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_On_Commission_And_Fee_By_Customer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_On_Commission_And_Fee_By_Customer.Location = new System.Drawing.Point(4, 74);
            this.rad_Report_On_Commission_And_Fee_By_Customer.Name = "rad_Report_On_Commission_And_Fee_By_Customer";
            this.rad_Report_On_Commission_And_Fee_By_Customer.Size = new System.Drawing.Size(44, 16);
            this.rad_Report_On_Commission_And_Fee_By_Customer.TabIndex = 2;
            this.rad_Report_On_Commission_And_Fee_By_Customer.TabStop = true;
            this.rad_Report_On_Commission_And_Fee_By_Customer.UseVisualStyleBackColor = true;
            this.rad_Report_On_Commission_And_Fee_By_Customer.CheckedChanged += new System.EventHandler(this.radCommissionAndFee_CheckedChanged);
            // 
            // rad_Report_On_Forex_Profit_By_Customer
            // 
            this.rad_Report_On_Forex_Profit_By_Customer.AutoSize = true;
            this.rad_Report_On_Forex_Profit_By_Customer.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_On_Forex_Profit_By_Customer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_On_Forex_Profit_By_Customer.Location = new System.Drawing.Point(4, 97);
            this.rad_Report_On_Forex_Profit_By_Customer.Name = "rad_Report_On_Forex_Profit_By_Customer";
            this.rad_Report_On_Forex_Profit_By_Customer.Size = new System.Drawing.Size(44, 16);
            this.rad_Report_On_Forex_Profit_By_Customer.TabIndex = 3;
            this.rad_Report_On_Forex_Profit_By_Customer.TabStop = true;
            this.rad_Report_On_Forex_Profit_By_Customer.UseVisualStyleBackColor = true;
            this.rad_Report_On_Forex_Profit_By_Customer.CheckedChanged += new System.EventHandler(this.radForexProfit_CheckedChanged);
            // 
            // rad_Report_On_Total_Profit_By_Customer
            // 
            this.rad_Report_On_Total_Profit_By_Customer.AutoSize = true;
            this.rad_Report_On_Total_Profit_By_Customer.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_On_Total_Profit_By_Customer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_On_Total_Profit_By_Customer.Location = new System.Drawing.Point(4, 120);
            this.rad_Report_On_Total_Profit_By_Customer.Name = "rad_Report_On_Total_Profit_By_Customer";
            this.rad_Report_On_Total_Profit_By_Customer.Size = new System.Drawing.Size(44, 16);
            this.rad_Report_On_Total_Profit_By_Customer.TabIndex = 4;
            this.rad_Report_On_Total_Profit_By_Customer.TabStop = true;
            this.rad_Report_On_Total_Profit_By_Customer.UseVisualStyleBackColor = true;
            this.rad_Report_On_Total_Profit_By_Customer.CheckedChanged += new System.EventHandler(this.radTotalProfit_CheckedChanged);
            // 
            // rad_Report_On_Deposit_Profit_By_Customer
            // 
            this.rad_Report_On_Deposit_Profit_By_Customer.AutoSize = true;
            this.rad_Report_On_Deposit_Profit_By_Customer.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_On_Deposit_Profit_By_Customer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_On_Deposit_Profit_By_Customer.Location = new System.Drawing.Point(4, 143);
            this.rad_Report_On_Deposit_Profit_By_Customer.Name = "rad_Report_On_Deposit_Profit_By_Customer";
            this.rad_Report_On_Deposit_Profit_By_Customer.Size = new System.Drawing.Size(44, 16);
            this.rad_Report_On_Deposit_Profit_By_Customer.TabIndex = 5;
            this.rad_Report_On_Deposit_Profit_By_Customer.TabStop = true;
            this.rad_Report_On_Deposit_Profit_By_Customer.UseVisualStyleBackColor = true;
            this.rad_Report_On_Deposit_Profit_By_Customer.CheckedChanged += new System.EventHandler(this.radInterestDeposit_CheckedChanged);
            // 
            // rad_Report_On_Loan_Profit_By_Customer
            // 
            this.rad_Report_On_Loan_Profit_By_Customer.AutoSize = true;
            this.rad_Report_On_Loan_Profit_By_Customer.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_On_Loan_Profit_By_Customer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_On_Loan_Profit_By_Customer.Location = new System.Drawing.Point(4, 166);
            this.rad_Report_On_Loan_Profit_By_Customer.Name = "rad_Report_On_Loan_Profit_By_Customer";
            this.rad_Report_On_Loan_Profit_By_Customer.Size = new System.Drawing.Size(44, 16);
            this.rad_Report_On_Loan_Profit_By_Customer.TabIndex = 6;
            this.rad_Report_On_Loan_Profit_By_Customer.TabStop = true;
            this.rad_Report_On_Loan_Profit_By_Customer.UseVisualStyleBackColor = true;
            this.rad_Report_On_Loan_Profit_By_Customer.CheckedChanged += new System.EventHandler(this.radInterestLoan_CheckedChanged);
            // 
            // rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance
            // 
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.AutoSize = true;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.Location = new System.Drawing.Point(4, 189);
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.Name = "rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance";
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.Size = new System.Drawing.Size(44, 16);
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.TabIndex = 7;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.TabStop = true;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.UseVisualStyleBackColor = true;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance.CheckedChanged += new System.EventHandler(this.radDepositAveBalTop50_CheckedChanged);
            // 
            // rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance
            // 
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.AutoSize = true;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.Location = new System.Drawing.Point(4, 212);
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.Name = "rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance";
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.Size = new System.Drawing.Size(44, 16);
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.TabIndex = 8;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.TabStop = true;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.UseVisualStyleBackColor = true;
            this.rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance.CheckedChanged += new System.EventHandler(this.radLoanAveBalTop50_CheckedChanged);
            // 
            // rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit
            // 
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.AutoSize = true;
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.Location = new System.Drawing.Point(4, 235);
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.Name = "rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit";
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.Size = new System.Drawing.Size(44, 19);
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.TabIndex = 9;
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.TabStop = true;
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.UseVisualStyleBackColor = true;
            this.rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit.CheckedChanged += new System.EventHandler(this.radTotalProfitTop50_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(55, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(677, 22);
            this.label1.TabIndex = 5;
            this.label1.Text = "REPORT ON DEPOSIT AVERAGE BALANCE BY CUSTOMER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(55, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(677, 22);
            this.label2.TabIndex = 6;
            this.label2.Text = "REPORT ON LOAN AVERAGE BALANCE BY CUSTOMER";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(55, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(677, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "REPORT ON COMMISSION AND FEE BY CUSTOMER";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(55, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(677, 22);
            this.label4.TabIndex = 2;
            this.label4.Text = "REPORT ON FOREX PROFIT  BY CUSTOMER";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(55, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(677, 22);
            this.label5.TabIndex = 2;
            this.label5.Text = "REPORT ON TOTAL PROFIT BY CUSTOMER";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(55, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(677, 22);
            this.label6.TabIndex = 2;
            this.label6.Text = "REPORT ON DEPOSIT PROFIT  BY CUSTOMER";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(55, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(677, 22);
            this.label7.TabIndex = 2;
            this.label7.Text = "REPORT ON  LOAN PROFIT BY CUSTOMER";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl11.Location = new System.Drawing.Point(55, 186);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(677, 22);
            this.lbl11.TabIndex = 2;
            this.lbl11.Text = "REPORT ON TOP 50 CUSTOMERS IN TERMS OF DEPOSIT AVERAGE BALANCE";
            this.lbl11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl11.Click += new System.EventHandler(this.label8_Click);
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl12.Location = new System.Drawing.Point(55, 209);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(677, 22);
            this.lbl12.TabIndex = 2;
            this.lbl12.Text = "REPORT ON TOP 50 CUSTOMERS IN TERMS OF LOAN AVERAGE BALANCE";
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl12.Click += new System.EventHandler(this.label9_Click);
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl13.Location = new System.Drawing.Point(55, 232);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(677, 25);
            this.lbl13.TabIndex = 2;
            this.lbl13.Text = "REPORT ON TOP 50 CUSTOMERS IN TERMS OF TOTAL PROFIT";
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl13.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(1, 1);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 23);
            this.label11.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(648, 410);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 23);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cbbJNJ
            // 
            this.cbbJNJ.FormattingEnabled = true;
            this.cbbJNJ.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbJNJ.Location = new System.Drawing.Point(111, 93);
            this.cbbJNJ.Name = "cbbJNJ";
            this.cbbJNJ.Size = new System.Drawing.Size(224, 21);
            this.cbbJNJ.TabIndex = 8;
            // 
            // clToMonthYear
            // 
            this.clToMonthYear.CustomFormat = "MM/yyyy";
            this.clToMonthYear.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.clToMonthYear.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.clToMonthYear.Location = new System.Drawing.Point(494, 7);
            this.clToMonthYear.Name = "clToMonthYear";
            this.clToMonthYear.ShowUpDown = true;
            this.clToMonthYear.Size = new System.Drawing.Size(254, 20);
            this.clToMonthYear.TabIndex = 1;
            // 
            // clFromMonthYear
            // 
            this.clFromMonthYear.CustomFormat = "MM/yyyy";
            this.clFromMonthYear.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.clFromMonthYear.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.clFromMonthYear.Location = new System.Drawing.Point(111, 7);
            this.clFromMonthYear.Name = "clFromMonthYear";
            this.clFromMonthYear.ShowUpDown = true;
            this.clFromMonthYear.Size = new System.Drawing.Size(224, 20);
            this.clFromMonthYear.TabIndex = 0;
            // 
            // frmScreenReportMonth
            // 
            this.AcceptButton = this.btnExportExcel;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(768, 445);
            this.Controls.Add(this.clFromMonthYear);
            this.Controls.Add(this.clToMonthYear);
            this.Controls.Add(this.cbbJNJ);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.btnExportExcel);
            this.Controls.Add(this.cbbVNAcc);
            this.Controls.Add(this.cbbTeam);
            this.Controls.Add(this.cbbJPAcc);
            this.Controls.Add(this.cbbDepartment);
            this.Controls.Add(this.txtCustomerCode);
            this.Controls.Add(this.txtCustomerFullName);
            this.Controls.Add(this.lblJNJ);
            this.Controls.Add(this.lblCustomerCode);
            this.Controls.Add(this.lblJO);
            this.Controls.Add(this.lblDepartment);
            this.Controls.Add(this.lblCustomerFullName);
            this.Controls.Add(this.lblNewPerson);
            this.Controls.Add(this.lblTeam);
            this.Controls.Add(this.lblToMonthYear);
            this.Controls.Add(this.lblFromMonthYear);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmScreenReportMonth";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Month Report";
            this.Load += new System.EventHandler(this.frmScreenReportMonth_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbbVNAcc;
        private System.Windows.Forms.ComboBox cbbTeam;
        private System.Windows.Forms.ComboBox cbbJPAcc;
        private System.Windows.Forms.ComboBox cbbDepartment;
        private System.Windows.Forms.TextBox txtCustomerCode;
        private System.Windows.Forms.TextBox txtCustomerFullName;
        private System.Windows.Forms.Label lblCustomerCode;
        private System.Windows.Forms.Label lblJO;
        private System.Windows.Forms.Label lblDepartment;
        private System.Windows.Forms.Label lblCustomerFullName;
        private System.Windows.Forms.Label lblNewPerson;
        private System.Windows.Forms.Label lblTeam;
        private System.Windows.Forms.Label lblToMonthYear;
        private System.Windows.Forms.Label lblFromMonthYear;
        private System.Windows.Forms.Label lblJNJ;
		private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblListReport;
        internal System.Windows.Forms.RadioButton rad_Report_On_Deposit_Average_Balance_By_Customer;
        internal System.Windows.Forms.RadioButton rad_Report_On_Loan_Average_Balance_By_Customer;
        internal System.Windows.Forms.RadioButton rad_Report_On_Commission_And_Fee_By_Customer;
        internal System.Windows.Forms.RadioButton rad_Report_On_Forex_Profit_By_Customer;
        internal System.Windows.Forms.RadioButton rad_Report_On_Total_Profit_By_Customer;
        internal System.Windows.Forms.RadioButton rad_Report_On_Deposit_Profit_By_Customer;
        internal System.Windows.Forms.RadioButton rad_Report_On_Loan_Profit_By_Customer;
        internal System.Windows.Forms.RadioButton rad_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance;
        internal System.Windows.Forms.RadioButton rad_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance;
        internal System.Windows.Forms.RadioButton rad_Report_Top_50_Customers_In_Terms_Of_Total_Profit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbbJNJ;
        private MonthYearCalendar clToMonthYear;
		private MonthYearCalendar clFromMonthYear;
    }
}