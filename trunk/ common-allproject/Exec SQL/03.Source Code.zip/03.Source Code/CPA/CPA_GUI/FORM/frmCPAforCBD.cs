﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define CPa for CBD Screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Phoenix.Cpa.Dto;
using Phoenix.Cpa.Common;
using Phoenix.Cpa.Bus;
using Config.Classes;
using Phoenix.Common.Functions;
namespace Phoenix.Cpa.Gui.Forms
{

    /// <summary>
    /// This form use to view CPA for CBD department
    /// Phong: in charge at 2/2013
    /// </summary>
    public partial class frmCPAforCBD : MasterForm
    {

        private string m_YearMonth = "";

        private string customerCode = "";
        public bool HasData = true;
        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="cusCode"></param>
        public frmCPAforCBD(string cusCode)

        {
            InitializeComponent();
            customerCode = cusCode;
            SetDynamicSize();
            try
            {
                txtCustomerCode.Text = customerCode;

                m_YearMonth = DateTime.Today.Year.ToString() + DateTime.Today.Month.ToString("00");
                AddColumns();
                // create style for datagrid
                addRow_DataGridView();
                dtgCPAforCBD.DefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
                dtgCPAforCBD.ColumnHeadersDefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
                dtgCPAforCBD.DefaultCellStyle.SelectionBackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
                dtgCPAforCBD.DefaultCellStyle.SelectionForeColor = Color.Black;
                dtgCPAforCBD.EnableHeadersVisualStyles = false;
             
                SetFormStyle();
                //load data
                LoadData();
            }
            catch (Exception ex)
            {

                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);

                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
        }
        /// <summary>
        /// loaddata
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmCPAforCBD_Load(object sender, EventArgs e)
        {
            
        }


        /// <summary>
        /// load data from database
        /// </summary>
        private void LoadData()
        {

            string preMonth = (DateTime.Today.AddMonths(-11)).Year.ToString() + (DateTime.Today.AddMonths(-11)).Month.ToString("00");
            clsReportBLL bll = new clsReportBLL();
            bll.GetListCPACustomer(preMonth, m_YearMonth, customerCode, "", "", "", "", "", "");
            List<clsCPACustomerDTO> lst = bll.ListCPACustomer;
            if (lst.Count > 0)
            {
                AddData(lst);
            }
            else
            {
                HasData = false;
            }
        }
        /// <summary>
        /// set value to datagrid
        /// </summary>
        /// <param name="lst"></param>
        public void AddData(List<clsCPACustomerDTO> lst)
        {
            if (lst.Count > 0)
            {
                txtCustomerFullName.Text = lst[0].CustomerName;
                for (int i = 0; i < lst.Count; i++)
                {
                    dtgCPAforCBD.Rows[0].Cells[lst[i].YearMonth].Value = (lst[i].GetDepositAverageBalance()).ToString("#,0");
                    dtgCPAforCBD.Rows[1].Cells[lst[i].YearMonth].Value = (lst[i].GetLoanAverageBalance()).ToString("#,0");
                    dtgCPAforCBD.Rows[2].Cells[lst[i].YearMonth].Value = (lst[i].GetCommissionFee()).ToString("#,0");
                    dtgCPAforCBD.Rows[3].Cells[lst[i].YearMonth].Value = (lst[i].ForeignExchangePL_INC).ToString("#,0");
                    dtgCPAforCBD.Rows[4].Cells[lst[i].YearMonth].Value = (lst[i].GetTotalProfit()).ToString("#,0");
                    dtgCPAforCBD.Rows[5].Cells[lst[i].YearMonth].Value = (lst[i].GetProfitDeposit()).ToString("#,0");
                    dtgCPAforCBD.Rows[6].Cells[lst[i].YearMonth].Value = (lst[i].GetProfitOfLoan()).ToString("#,0");
                }
            }
        }


        /// <summary>
        /// add columns to datagrid
        /// </summary>
        private void AddColumns()
        {
            List<string> lstColumns = GetList12Month(m_YearMonth);
            for (int i = lstColumns.Count-1; i >= 0; i--)
            {
                DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
                col1.HeaderText = clsCommonFunctions.GetMonthYearShowOnDataGrid(lstColumns[i]);
                col1.Name = lstColumns[i];
                col1.Width = 80;
                
                col1.SortMode = DataGridViewColumnSortMode.NotSortable;
                col1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                col1.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dtgCPAforCBD.Columns.Add(col1);
            }

        }

        /// <summary>
        /// get list name of columns
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        private List<string> GetList12Month(string input)
        {
            List<string> result = new List<string>();
            DateTime date = new DateTime(int.Parse(input.Remove(4)), int.Parse(input.Remove(0, 4)), 1);
            result.Add(date.ToString("yyyyMM"));
            for (int i = 0; i < 11; i++)
            {
                date = date.AddMonths(-1);
                result.Add(date.ToString("yyyyMM"));
            }
            return result;
        }
        /// <summary>
        /// add defaul value on datagrin and header rows
        /// </summary>
        private void addRow_DataGridView()
        {
            this.dtgCPAforCBD.RowHeadersWidth = 190;
            dtgCPAforCBD.RowHeadersDefaultCellStyle.BackColor = Color.FromArgb(224, 223, 227);
            this.dtgCPAforCBD.Rows.Add(0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0,0);
			this.dtgCPAforCBD.Rows[0].HeaderCell.Value = clsCPAConstant.DEPOSIT_AVERAGE_BALANCE;
            this.dtgCPAforCBD.Rows.Add(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			this.dtgCPAforCBD.Rows[1].HeaderCell.Value = clsCPAConstant.LOAN_AVERAGE_BALANCE;
            this.dtgCPAforCBD.Rows.Add(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			this.dtgCPAforCBD.Rows[2].HeaderCell.Value = clsCPAConstant.PROFIT_OF_COMMISSION_AND_FEE;
            this.dtgCPAforCBD.Rows.Add(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			this.dtgCPAforCBD.Rows[3].HeaderCell.Value = clsCPAConstant.PROFIT_OF_FOREX;
            this.dtgCPAforCBD.Rows.Add(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			this.dtgCPAforCBD.Rows[4].HeaderCell.Value = clsCPAConstant.TOTAL_PROFIT;
            this.dtgCPAforCBD.Rows.Add(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			this.dtgCPAforCBD.Rows[5].HeaderCell.Value = clsCPAConstant.PROFIT_OF_DEPOSIT;
            this.dtgCPAforCBD.Rows.Add(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			this.dtgCPAforCBD.Rows[6].HeaderCell.Value = clsCPAConstant.PROFIT_OF_LOAN;
            dtgCPAforCBD.Height = dtgCPAforCBD.Rows[0].Height * 8 + dtgCPAforCBD.ColumnHeadersHeight ;
            

			
        }
        /// <summary>
        /// form close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        /// <summary>
        /// repain textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmCPAforCBD_Paint(object sender, PaintEventArgs e)
        {
            Pen p = new Pen(Color.FromArgb(64, 118, 219));
            Graphics g = e.Graphics;
            int variance = 3;
            g.DrawRectangle(p, new Rectangle(txtCustomerCode.Location.X - variance, txtCustomerCode.Location.Y - variance, txtCustomerCode.Width + variance, txtCustomerCode.Height + variance));
            g.DrawRectangle(p, new Rectangle(txtCustomerFullName.Location.X - variance, txtCustomerFullName.Location.Y - variance, txtCustomerFullName.Width + variance, txtCustomerFullName.Height + variance));
        }


    }
}
