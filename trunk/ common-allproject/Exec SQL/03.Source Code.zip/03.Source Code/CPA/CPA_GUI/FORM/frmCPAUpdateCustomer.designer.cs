﻿
using UserCtrl;
namespace Phoenix.Cpa.Gui.Forms
{
    partial class frmUpdateCustomerTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.frmCustomerCode = new System.Windows.Forms.Label();
            this.lblCustomerFullName = new System.Windows.Forms.Label();
            this.lblToMonthYear = new System.Windows.Forms.Label();
            this.ckbNotShow = new System.Windows.Forms.CheckBox();
            this.textbox1 = new System.Windows.Forms.TextBox();
            this.textbox4 = new System.Windows.Forms.TextBox();
            this.textbox7 = new System.Windows.Forms.TextBox();
            this.textbox2 = new System.Windows.Forms.TextBox();
            this.textbox5 = new System.Windows.Forms.TextBox();
            this.textbox8 = new System.Windows.Forms.TextBox();
            this.textbox10 = new System.Windows.Forms.TextBox();
            this.textbox12 = new System.Windows.Forms.TextBox();
            this.textbox14 = new System.Windows.Forms.TextBox();
            this.textbox11 = new System.Windows.Forms.TextBox();
            this.textbox13 = new System.Windows.Forms.TextBox();
            this.textbox15 = new System.Windows.Forms.TextBox();
            this.textbox16 = new System.Windows.Forms.TextBox();
            this.textbox18 = new System.Windows.Forms.TextBox();
            this.textbox20 = new System.Windows.Forms.TextBox();
            this.textbox17 = new System.Windows.Forms.TextBox();
            this.textbox19 = new System.Windows.Forms.TextBox();
            this.textbox21 = new System.Windows.Forms.TextBox();
            this.textbox22 = new System.Windows.Forms.TextBox();
            this.textbox23 = new System.Windows.Forms.TextBox();
            this.textbox24 = new System.Windows.Forms.TextBox();
            this.textbox25 = new System.Windows.Forms.TextBox();
            this.textbox26 = new System.Windows.Forms.TextBox();
            this.textbox31 = new System.Windows.Forms.TextBox();
            this.textbox34 = new System.Windows.Forms.TextBox();
            this.textbox27 = new System.Windows.Forms.TextBox();
            this.textbox28 = new System.Windows.Forms.TextBox();
            this.textbox32 = new System.Windows.Forms.TextBox();
            this.textbox35 = new System.Windows.Forms.TextBox();
            this.textbox29 = new System.Windows.Forms.TextBox();
            this.textbox30 = new System.Windows.Forms.TextBox();
            this.textbox33 = new System.Windows.Forms.TextBox();
            this.textbox36 = new System.Windows.Forms.TextBox();
            this.textbox37 = new System.Windows.Forms.TextBox();
            this.textbox38 = new System.Windows.Forms.TextBox();
            this.textbox39 = new System.Windows.Forms.TextBox();
            this.textbox40 = new System.Windows.Forms.TextBox();
            this.textbox41 = new System.Windows.Forms.TextBox();
            this.textbox42 = new System.Windows.Forms.TextBox();
            this.textbox43 = new System.Windows.Forms.TextBox();
            this.textbox44 = new System.Windows.Forms.TextBox();
            this.textbox45 = new System.Windows.Forms.TextBox();
            this.textbox46 = new System.Windows.Forms.TextBox();
            this.textbox47 = new System.Windows.Forms.TextBox();
            this.textbox48 = new System.Windows.Forms.TextBox();
            this.textbox49 = new System.Windows.Forms.TextBox();
            this.textbox50 = new System.Windows.Forms.TextBox();
            this.textbox51 = new System.Windows.Forms.TextBox();
            this.textbox57 = new System.Windows.Forms.TextBox();
            this.textbox58 = new System.Windows.Forms.TextBox();
            this.textbox59 = new System.Windows.Forms.TextBox();
            this.textbox60 = new System.Windows.Forms.TextBox();
            this.textbox61 = new System.Windows.Forms.TextBox();
            this.textbox52 = new System.Windows.Forms.TextBox();
            this.textbox53 = new System.Windows.Forms.TextBox();
            this.textbox55 = new System.Windows.Forms.TextBox();
            this.textbox56 = new System.Windows.Forms.TextBox();
            this.textbox62 = new System.Windows.Forms.TextBox();
            this.textbox63 = new System.Windows.Forms.TextBox();
            this.textbox64 = new System.Windows.Forms.TextBox();
            this.textbox65 = new System.Windows.Forms.TextBox();
            this.textbox66 = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.textbox9 = new System.Windows.Forms.TextBox();
            this.textbox6 = new System.Windows.Forms.TextBox();
            this.textbox3 = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.textbox54 = new System.Windows.Forms.TextBox();
            this.txtMonthYear = new UserCtrl.DisableTextBox();
            this.txtCustFullName = new UserCtrl.DisableTextBox();
            this.txtCustCode = new UserCtrl.DisableTextBox();
            this.txtLoan = new UserCtrl.DisableTextBox();
            this.txtIntPayable = new UserCtrl.DisableTextBox();
            this.txtIncome2 = new UserCtrl.DisableTextBox();
            this.txtIncome1 = new UserCtrl.DisableTextBox();
            this.txtIntReceivable = new UserCtrl.DisableTextBox();
            this.txtMonthlyTurnover = new UserCtrl.DisableTextBox();
            this.txtAveBln2 = new UserCtrl.DisableTextBox();
            this.txtAveBln1 = new UserCtrl.DisableTextBox();
            this.txtReserve = new UserCtrl.DisableTextBox();
            this.txtOtherApp = new UserCtrl.DisableTextBox();
            this.txtOtherSource = new UserCtrl.DisableTextBox();
            this.txtBR = new UserCtrl.DisableTextBox();
            this.txtOthers3 = new UserCtrl.DisableTextBox();
            this.txtPayment = new UserCtrl.DisableTextBox();
            this.txtOthers = new UserCtrl.DisableTextBox();
            this.txtFixedDepo = new UserCtrl.DisableTextBox();
            this.txtBB = new UserCtrl.DisableTextBox();
            this.txtFX = new UserCtrl.DisableTextBox();
            this.txtCollecting = new UserCtrl.DisableTextBox();
            this.txtCommitment = new UserCtrl.DisableTextBox();
            this.txtLiquidDepo = new UserCtrl.DisableTextBox();
            this.txtOthers2 = new UserCtrl.DisableTextBox();
            this.txtImpBill = new UserCtrl.DisableTextBox();
            this.txtAcceptance = new UserCtrl.DisableTextBox();
            this.txtFloatLoan = new UserCtrl.DisableTextBox();
            this.txtLoan2 = new UserCtrl.DisableTextBox();
            this.txtExpBill = new UserCtrl.DisableTextBox();
            this.txtCleanLC = new UserCtrl.DisableTextBox();
            this.txtFixedLoan = new UserCtrl.DisableTextBox();
            this.Remittance = new UserCtrl.DisableTextBox();
            this.txtDocLC = new UserCtrl.DisableTextBox();
            this.txtGuarantee = new UserCtrl.DisableTextBox();
            this.txtCommercialBill = new UserCtrl.DisableTextBox();
            this.txtOverdraft = new UserCtrl.DisableTextBox();
            this.SuspendLayout();
            // 
            // frmCustomerCode
            // 
            this.frmCustomerCode.AutoSize = true;
            this.frmCustomerCode.Location = new System.Drawing.Point(9, 15);
            this.frmCustomerCode.Name = "frmCustomerCode";
            this.frmCustomerCode.Size = new System.Drawing.Size(79, 13);
            this.frmCustomerCode.TabIndex = 2;
            this.frmCustomerCode.Text = "Customer Code";
            // 
            // lblCustomerFullName
            // 
            this.lblCustomerFullName.AutoSize = true;
            this.lblCustomerFullName.Location = new System.Drawing.Point(231, 13);
            this.lblCustomerFullName.Name = "lblCustomerFullName";
            this.lblCustomerFullName.Size = new System.Drawing.Size(101, 13);
            this.lblCustomerFullName.TabIndex = 4;
            this.lblCustomerFullName.Text = "Customer Full Name";
            // 
            // lblToMonthYear
            // 
            this.lblToMonthYear.AutoSize = true;
            this.lblToMonthYear.Location = new System.Drawing.Point(803, 16);
            this.lblToMonthYear.Name = "lblToMonthYear";
            this.lblToMonthYear.Size = new System.Drawing.Size(64, 13);
            this.lblToMonthYear.TabIndex = 6;
            this.lblToMonthYear.Text = "Month/Year";
            // 
            // ckbNotShow
            // 
            this.ckbNotShow.AutoSize = true;
            this.ckbNotShow.Location = new System.Drawing.Point(12, 51);
            this.ckbNotShow.Name = "ckbNotShow";
            this.ckbNotShow.Size = new System.Drawing.Size(119, 17);
            this.ckbNotShow.TabIndex = 3;
            this.ckbNotShow.Text = "Not Show in Report";
            this.ckbNotShow.UseVisualStyleBackColor = true;
            // 
            // textbox1
            // 
            this.textbox1.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox1.Location = new System.Drawing.Point(107, 111);
            this.textbox1.Margin = new System.Windows.Forms.Padding(0);
            this.textbox1.Name = "textbox1";
            this.textbox1.Size = new System.Drawing.Size(90, 20);
            this.textbox1.TabIndex = 4;
            this.textbox1.Text = "12345";
            // 
            // textbox4
            // 
            this.textbox4.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox4.Location = new System.Drawing.Point(197, 111);
            this.textbox4.Margin = new System.Windows.Forms.Padding(0);
            this.textbox4.Name = "textbox4";
            this.textbox4.Size = new System.Drawing.Size(90, 20);
            this.textbox4.TabIndex = 5;
            // 
            // textbox7
            // 
            this.textbox7.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox7.Location = new System.Drawing.Point(287, 111);
            this.textbox7.Margin = new System.Windows.Forms.Padding(0);
            this.textbox7.Name = "textbox7";
            this.textbox7.Size = new System.Drawing.Size(100, 20);
            this.textbox7.TabIndex = 6;
            // 
            // textbox2
            // 
            this.textbox2.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox2.Location = new System.Drawing.Point(107, 131);
            this.textbox2.Margin = new System.Windows.Forms.Padding(0);
            this.textbox2.Name = "textbox2";
            this.textbox2.Size = new System.Drawing.Size(90, 20);
            this.textbox2.TabIndex = 7;
            this.textbox2.Text = "12345";
            // 
            // textbox5
            // 
            this.textbox5.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox5.Location = new System.Drawing.Point(197, 131);
            this.textbox5.Margin = new System.Windows.Forms.Padding(0);
            this.textbox5.Name = "textbox5";
            this.textbox5.Size = new System.Drawing.Size(90, 20);
            this.textbox5.TabIndex = 8;
            // 
            // textbox8
            // 
            this.textbox8.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox8.Location = new System.Drawing.Point(287, 131);
            this.textbox8.Margin = new System.Windows.Forms.Padding(0);
            this.textbox8.Name = "textbox8";
            this.textbox8.Size = new System.Drawing.Size(100, 20);
            this.textbox8.TabIndex = 9;
            // 
            // textbox10
            // 
            this.textbox10.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox10.Location = new System.Drawing.Point(107, 171);
            this.textbox10.Margin = new System.Windows.Forms.Padding(0);
            this.textbox10.Name = "textbox10";
            this.textbox10.Size = new System.Drawing.Size(90, 20);
            this.textbox10.TabIndex = 13;
            this.textbox10.Text = "12345";
            // 
            // textbox12
            // 
            this.textbox12.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox12.Location = new System.Drawing.Point(197, 171);
            this.textbox12.Margin = new System.Windows.Forms.Padding(0);
            this.textbox12.Name = "textbox12";
            this.textbox12.Size = new System.Drawing.Size(90, 20);
            this.textbox12.TabIndex = 14;
            // 
            // textbox14
            // 
            this.textbox14.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox14.Location = new System.Drawing.Point(287, 171);
            this.textbox14.Margin = new System.Windows.Forms.Padding(0);
            this.textbox14.Name = "textbox14";
            this.textbox14.Size = new System.Drawing.Size(100, 20);
            this.textbox14.TabIndex = 15;
            // 
            // textbox11
            // 
            this.textbox11.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox11.Location = new System.Drawing.Point(107, 191);
            this.textbox11.Margin = new System.Windows.Forms.Padding(0);
            this.textbox11.Name = "textbox11";
            this.textbox11.Size = new System.Drawing.Size(90, 20);
            this.textbox11.TabIndex = 16;
            this.textbox11.Text = "12345";
            // 
            // textbox13
            // 
            this.textbox13.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox13.Location = new System.Drawing.Point(197, 191);
            this.textbox13.Margin = new System.Windows.Forms.Padding(0);
            this.textbox13.Name = "textbox13";
            this.textbox13.Size = new System.Drawing.Size(90, 20);
            this.textbox13.TabIndex = 17;
            // 
            // textbox15
            // 
            this.textbox15.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox15.Location = new System.Drawing.Point(287, 191);
            this.textbox15.Margin = new System.Windows.Forms.Padding(0);
            this.textbox15.Name = "textbox15";
            this.textbox15.Size = new System.Drawing.Size(100, 20);
            this.textbox15.TabIndex = 18;
            // 
            // textbox16
            // 
            this.textbox16.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox16.Location = new System.Drawing.Point(107, 211);
            this.textbox16.Margin = new System.Windows.Forms.Padding(0);
            this.textbox16.Name = "textbox16";
            this.textbox16.Size = new System.Drawing.Size(90, 20);
            this.textbox16.TabIndex = 19;
            this.textbox16.Text = "12345";
            // 
            // textbox18
            // 
            this.textbox18.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox18.Location = new System.Drawing.Point(197, 211);
            this.textbox18.Margin = new System.Windows.Forms.Padding(0);
            this.textbox18.Name = "textbox18";
            this.textbox18.Size = new System.Drawing.Size(90, 20);
            this.textbox18.TabIndex = 20;
            // 
            // textbox20
            // 
            this.textbox20.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox20.Location = new System.Drawing.Point(287, 211);
            this.textbox20.Margin = new System.Windows.Forms.Padding(0);
            this.textbox20.Name = "textbox20";
            this.textbox20.Size = new System.Drawing.Size(100, 20);
            this.textbox20.TabIndex = 21;
            // 
            // textbox17
            // 
            this.textbox17.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox17.Location = new System.Drawing.Point(107, 231);
            this.textbox17.Margin = new System.Windows.Forms.Padding(0);
            this.textbox17.Name = "textbox17";
            this.textbox17.Size = new System.Drawing.Size(90, 20);
            this.textbox17.TabIndex = 22;
            this.textbox17.Text = "12345";
            // 
            // textbox19
            // 
            this.textbox19.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox19.Location = new System.Drawing.Point(197, 231);
            this.textbox19.Margin = new System.Windows.Forms.Padding(0);
            this.textbox19.Name = "textbox19";
            this.textbox19.Size = new System.Drawing.Size(90, 20);
            this.textbox19.TabIndex = 23;
            // 
            // textbox21
            // 
            this.textbox21.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox21.Location = new System.Drawing.Point(287, 231);
            this.textbox21.Margin = new System.Windows.Forms.Padding(0);
            this.textbox21.Name = "textbox21";
            this.textbox21.Size = new System.Drawing.Size(100, 20);
            this.textbox21.TabIndex = 24;
            // 
            // textbox22
            // 
            this.textbox22.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox22.Location = new System.Drawing.Point(107, 251);
            this.textbox22.Margin = new System.Windows.Forms.Padding(0);
            this.textbox22.Name = "textbox22";
            this.textbox22.Size = new System.Drawing.Size(90, 20);
            this.textbox22.TabIndex = 25;
            this.textbox22.Text = "12345";
            // 
            // textbox23
            // 
            this.textbox23.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox23.Location = new System.Drawing.Point(197, 251);
            this.textbox23.Margin = new System.Windows.Forms.Padding(0);
            this.textbox23.Name = "textbox23";
            this.textbox23.Size = new System.Drawing.Size(90, 20);
            this.textbox23.TabIndex = 26;
            // 
            // textbox24
            // 
            this.textbox24.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox24.Location = new System.Drawing.Point(287, 251);
            this.textbox24.Margin = new System.Windows.Forms.Padding(0);
            this.textbox24.Name = "textbox24";
            this.textbox24.Size = new System.Drawing.Size(100, 20);
            this.textbox24.TabIndex = 27;
            // 
            // textbox25
            // 
            this.textbox25.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox25.Location = new System.Drawing.Point(107, 290);
            this.textbox25.Margin = new System.Windows.Forms.Padding(0);
            this.textbox25.Name = "textbox25";
            this.textbox25.Size = new System.Drawing.Size(90, 20);
            this.textbox25.TabIndex = 28;
            this.textbox25.Text = "12345";
            // 
            // textbox26
            // 
            this.textbox26.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox26.Location = new System.Drawing.Point(107, 310);
            this.textbox26.Margin = new System.Windows.Forms.Padding(0);
            this.textbox26.Name = "textbox26";
            this.textbox26.Size = new System.Drawing.Size(90, 20);
            this.textbox26.TabIndex = 31;
            // 
            // textbox31
            // 
            this.textbox31.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox31.Location = new System.Drawing.Point(107, 330);
            this.textbox31.Margin = new System.Windows.Forms.Padding(0);
            this.textbox31.Name = "textbox31";
            this.textbox31.Size = new System.Drawing.Size(90, 20);
            this.textbox31.TabIndex = 34;
            // 
            // textbox34
            // 
            this.textbox34.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox34.Location = new System.Drawing.Point(107, 350);
            this.textbox34.Margin = new System.Windows.Forms.Padding(0);
            this.textbox34.Name = "textbox34";
            this.textbox34.Size = new System.Drawing.Size(90, 20);
            this.textbox34.TabIndex = 37;
            // 
            // textbox27
            // 
            this.textbox27.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox27.Location = new System.Drawing.Point(197, 290);
            this.textbox27.Margin = new System.Windows.Forms.Padding(0);
            this.textbox27.Name = "textbox27";
            this.textbox27.Size = new System.Drawing.Size(90, 20);
            this.textbox27.TabIndex = 29;
            // 
            // textbox28
            // 
            this.textbox28.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox28.Location = new System.Drawing.Point(197, 310);
            this.textbox28.Margin = new System.Windows.Forms.Padding(0);
            this.textbox28.Name = "textbox28";
            this.textbox28.Size = new System.Drawing.Size(90, 20);
            this.textbox28.TabIndex = 32;
            // 
            // textbox32
            // 
            this.textbox32.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox32.Location = new System.Drawing.Point(197, 330);
            this.textbox32.Margin = new System.Windows.Forms.Padding(0);
            this.textbox32.Name = "textbox32";
            this.textbox32.Size = new System.Drawing.Size(90, 20);
            this.textbox32.TabIndex = 35;
            // 
            // textbox35
            // 
            this.textbox35.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox35.Location = new System.Drawing.Point(197, 350);
            this.textbox35.Margin = new System.Windows.Forms.Padding(0);
            this.textbox35.Name = "textbox35";
            this.textbox35.Size = new System.Drawing.Size(90, 20);
            this.textbox35.TabIndex = 38;
            // 
            // textbox29
            // 
            this.textbox29.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox29.Location = new System.Drawing.Point(287, 290);
            this.textbox29.Margin = new System.Windows.Forms.Padding(0);
            this.textbox29.Name = "textbox29";
            this.textbox29.Size = new System.Drawing.Size(100, 20);
            this.textbox29.TabIndex = 30;
            // 
            // textbox30
            // 
            this.textbox30.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox30.Location = new System.Drawing.Point(287, 310);
            this.textbox30.Margin = new System.Windows.Forms.Padding(0);
            this.textbox30.Name = "textbox30";
            this.textbox30.Size = new System.Drawing.Size(100, 20);
            this.textbox30.TabIndex = 33;
            // 
            // textbox33
            // 
            this.textbox33.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox33.Location = new System.Drawing.Point(287, 330);
            this.textbox33.Margin = new System.Windows.Forms.Padding(0);
            this.textbox33.Name = "textbox33";
            this.textbox33.Size = new System.Drawing.Size(100, 20);
            this.textbox33.TabIndex = 36;
            // 
            // textbox36
            // 
            this.textbox36.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox36.Location = new System.Drawing.Point(287, 350);
            this.textbox36.Margin = new System.Windows.Forms.Padding(0);
            this.textbox36.Name = "textbox36";
            this.textbox36.Size = new System.Drawing.Size(100, 20);
            this.textbox36.TabIndex = 39;
            // 
            // textbox37
            // 
            this.textbox37.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox37.Location = new System.Drawing.Point(493, 111);
            this.textbox37.Margin = new System.Windows.Forms.Padding(0);
            this.textbox37.Name = "textbox37";
            this.textbox37.Size = new System.Drawing.Size(90, 20);
            this.textbox37.TabIndex = 40;
            // 
            // textbox38
            // 
            this.textbox38.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox38.Location = new System.Drawing.Point(493, 131);
            this.textbox38.Margin = new System.Windows.Forms.Padding(0);
            this.textbox38.Name = "textbox38";
            this.textbox38.Size = new System.Drawing.Size(90, 20);
            this.textbox38.TabIndex = 42;
            // 
            // textbox39
            // 
            this.textbox39.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox39.Location = new System.Drawing.Point(493, 151);
            this.textbox39.Margin = new System.Windows.Forms.Padding(0);
            this.textbox39.Name = "textbox39";
            this.textbox39.Size = new System.Drawing.Size(90, 20);
            this.textbox39.TabIndex = 44;
            // 
            // textbox40
            // 
            this.textbox40.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox40.Location = new System.Drawing.Point(493, 171);
            this.textbox40.Margin = new System.Windows.Forms.Padding(0);
            this.textbox40.Name = "textbox40";
            this.textbox40.Size = new System.Drawing.Size(90, 20);
            this.textbox40.TabIndex = 46;
            // 
            // textbox41
            // 
            this.textbox41.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox41.Location = new System.Drawing.Point(493, 191);
            this.textbox41.Margin = new System.Windows.Forms.Padding(0);
            this.textbox41.Name = "textbox41";
            this.textbox41.Size = new System.Drawing.Size(90, 20);
            this.textbox41.TabIndex = 48;
            // 
            // textbox42
            // 
            this.textbox42.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox42.Location = new System.Drawing.Point(581, 111);
            this.textbox42.Margin = new System.Windows.Forms.Padding(0);
            this.textbox42.Name = "textbox42";
            this.textbox42.Size = new System.Drawing.Size(90, 20);
            this.textbox42.TabIndex = 41;
            // 
            // textbox43
            // 
            this.textbox43.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox43.Location = new System.Drawing.Point(581, 131);
            this.textbox43.Margin = new System.Windows.Forms.Padding(0);
            this.textbox43.Name = "textbox43";
            this.textbox43.Size = new System.Drawing.Size(90, 20);
            this.textbox43.TabIndex = 43;
            // 
            // textbox44
            // 
            this.textbox44.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox44.Location = new System.Drawing.Point(581, 151);
            this.textbox44.Margin = new System.Windows.Forms.Padding(0);
            this.textbox44.Name = "textbox44";
            this.textbox44.Size = new System.Drawing.Size(90, 20);
            this.textbox44.TabIndex = 45;
            // 
            // textbox45
            // 
            this.textbox45.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox45.Location = new System.Drawing.Point(581, 171);
            this.textbox45.Margin = new System.Windows.Forms.Padding(0);
            this.textbox45.Name = "textbox45";
            this.textbox45.Size = new System.Drawing.Size(90, 20);
            this.textbox45.TabIndex = 47;
            // 
            // textbox46
            // 
            this.textbox46.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox46.Location = new System.Drawing.Point(581, 191);
            this.textbox46.Margin = new System.Windows.Forms.Padding(0);
            this.textbox46.Name = "textbox46";
            this.textbox46.Size = new System.Drawing.Size(90, 20);
            this.textbox46.TabIndex = 49;
            // 
            // textbox47
            // 
            this.textbox47.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox47.Location = new System.Drawing.Point(806, 111);
            this.textbox47.Margin = new System.Windows.Forms.Padding(0);
            this.textbox47.Name = "textbox47";
            this.textbox47.Size = new System.Drawing.Size(100, 20);
            this.textbox47.TabIndex = 50;
            // 
            // textbox48
            // 
            this.textbox48.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox48.Location = new System.Drawing.Point(806, 131);
            this.textbox48.Margin = new System.Windows.Forms.Padding(0);
            this.textbox48.Name = "textbox48";
            this.textbox48.Size = new System.Drawing.Size(100, 20);
            this.textbox48.TabIndex = 52;
            // 
            // textbox49
            // 
            this.textbox49.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox49.Location = new System.Drawing.Point(806, 151);
            this.textbox49.Margin = new System.Windows.Forms.Padding(0);
            this.textbox49.Name = "textbox49";
            this.textbox49.Size = new System.Drawing.Size(100, 20);
            this.textbox49.TabIndex = 54;
            // 
            // textbox50
            // 
            this.textbox50.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox50.Location = new System.Drawing.Point(806, 171);
            this.textbox50.Margin = new System.Windows.Forms.Padding(0);
            this.textbox50.Name = "textbox50";
            this.textbox50.Size = new System.Drawing.Size(100, 20);
            this.textbox50.TabIndex = 56;
            // 
            // textbox51
            // 
            this.textbox51.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox51.Location = new System.Drawing.Point(806, 191);
            this.textbox51.Margin = new System.Windows.Forms.Padding(0);
            this.textbox51.Name = "textbox51";
            this.textbox51.Size = new System.Drawing.Size(100, 20);
            this.textbox51.TabIndex = 58;
            // 
            // textbox57
            // 
            this.textbox57.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox57.Location = new System.Drawing.Point(906, 111);
            this.textbox57.Margin = new System.Windows.Forms.Padding(0);
            this.textbox57.Name = "textbox57";
            this.textbox57.Size = new System.Drawing.Size(100, 20);
            this.textbox57.TabIndex = 51;
            // 
            // textbox58
            // 
            this.textbox58.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox58.Location = new System.Drawing.Point(906, 131);
            this.textbox58.Margin = new System.Windows.Forms.Padding(0);
            this.textbox58.Name = "textbox58";
            this.textbox58.Size = new System.Drawing.Size(100, 20);
            this.textbox58.TabIndex = 53;
            // 
            // textbox59
            // 
            this.textbox59.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox59.Location = new System.Drawing.Point(906, 151);
            this.textbox59.Margin = new System.Windows.Forms.Padding(0);
            this.textbox59.Name = "textbox59";
            this.textbox59.Size = new System.Drawing.Size(100, 20);
            this.textbox59.TabIndex = 55;
            // 
            // textbox60
            // 
            this.textbox60.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox60.Location = new System.Drawing.Point(906, 171);
            this.textbox60.Margin = new System.Windows.Forms.Padding(0);
            this.textbox60.Name = "textbox60";
            this.textbox60.Size = new System.Drawing.Size(100, 20);
            this.textbox60.TabIndex = 57;
            // 
            // textbox61
            // 
            this.textbox61.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox61.Location = new System.Drawing.Point(906, 191);
            this.textbox61.Margin = new System.Windows.Forms.Padding(0);
            this.textbox61.Name = "textbox61";
            this.textbox61.Size = new System.Drawing.Size(100, 20);
            this.textbox61.TabIndex = 59;
            // 
            // textbox52
            // 
            this.textbox52.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox52.Location = new System.Drawing.Point(806, 211);
            this.textbox52.Margin = new System.Windows.Forms.Padding(0);
            this.textbox52.Name = "textbox52";
            this.textbox52.Size = new System.Drawing.Size(100, 20);
            this.textbox52.TabIndex = 60;
            // 
            // textbox53
            // 
            this.textbox53.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox53.Location = new System.Drawing.Point(806, 231);
            this.textbox53.Margin = new System.Windows.Forms.Padding(0);
            this.textbox53.Name = "textbox53";
            this.textbox53.Size = new System.Drawing.Size(100, 20);
            this.textbox53.TabIndex = 62;
            // 
            // textbox55
            // 
            this.textbox55.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox55.Location = new System.Drawing.Point(806, 271);
            this.textbox55.Margin = new System.Windows.Forms.Padding(0);
            this.textbox55.Name = "textbox55";
            this.textbox55.Size = new System.Drawing.Size(100, 20);
            this.textbox55.TabIndex = 66;
            // 
            // textbox56
            // 
            this.textbox56.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox56.Location = new System.Drawing.Point(806, 291);
            this.textbox56.Margin = new System.Windows.Forms.Padding(0);
            this.textbox56.Name = "textbox56";
            this.textbox56.Size = new System.Drawing.Size(100, 20);
            this.textbox56.TabIndex = 68;
            // 
            // textbox62
            // 
            this.textbox62.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox62.Location = new System.Drawing.Point(906, 211);
            this.textbox62.Margin = new System.Windows.Forms.Padding(0);
            this.textbox62.Name = "textbox62";
            this.textbox62.Size = new System.Drawing.Size(100, 20);
            this.textbox62.TabIndex = 61;
            // 
            // textbox63
            // 
            this.textbox63.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox63.Location = new System.Drawing.Point(906, 231);
            this.textbox63.Margin = new System.Windows.Forms.Padding(0);
            this.textbox63.Name = "textbox63";
            this.textbox63.Size = new System.Drawing.Size(100, 20);
            this.textbox63.TabIndex = 63;
            // 
            // textbox64
            // 
            this.textbox64.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox64.Location = new System.Drawing.Point(906, 251);
            this.textbox64.Margin = new System.Windows.Forms.Padding(0);
            this.textbox64.Name = "textbox64";
            this.textbox64.Size = new System.Drawing.Size(100, 20);
            this.textbox64.TabIndex = 65;
            // 
            // textbox65
            // 
            this.textbox65.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox65.Location = new System.Drawing.Point(906, 271);
            this.textbox65.Margin = new System.Windows.Forms.Padding(0);
            this.textbox65.Name = "textbox65";
            this.textbox65.Size = new System.Drawing.Size(100, 20);
            this.textbox65.TabIndex = 67;
            // 
            // textbox66
            // 
            this.textbox66.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox66.Location = new System.Drawing.Point(906, 291);
            this.textbox66.Margin = new System.Windows.Forms.Padding(0);
            this.textbox66.Name = "textbox66";
            this.textbox66.Size = new System.Drawing.Size(100, 20);
            this.textbox66.TabIndex = 69;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(800, 404);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 23);
            this.btnSave.TabIndex = 70;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // textbox9
            // 
            this.textbox9.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox9.Location = new System.Drawing.Point(287, 151);
            this.textbox9.Margin = new System.Windows.Forms.Padding(0);
            this.textbox9.Name = "textbox9";
            this.textbox9.Size = new System.Drawing.Size(100, 20);
            this.textbox9.TabIndex = 12;
            // 
            // textbox6
            // 
            this.textbox6.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox6.Location = new System.Drawing.Point(197, 151);
            this.textbox6.Margin = new System.Windows.Forms.Padding(0);
            this.textbox6.Name = "textbox6";
            this.textbox6.Size = new System.Drawing.Size(90, 20);
            this.textbox6.TabIndex = 11;
            // 
            // textbox3
            // 
            this.textbox3.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox3.Location = new System.Drawing.Point(107, 151);
            this.textbox3.Margin = new System.Windows.Forms.Padding(0);
            this.textbox3.Name = "textbox3";
            this.textbox3.Size = new System.Drawing.Size(90, 20);
            this.textbox3.TabIndex = 10;
            this.textbox3.Text = "12345";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(906, 404);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 23);
            this.btnClose.TabIndex = 71;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // textbox54
            // 
            this.textbox54.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textbox54.Location = new System.Drawing.Point(806, 251);
            this.textbox54.Margin = new System.Windows.Forms.Padding(0);
            this.textbox54.Name = "textbox54";
            this.textbox54.Size = new System.Drawing.Size(100, 20);
            this.textbox54.TabIndex = 64;
            // 
            // txtMonthYear
            // 
            this.txtMonthYear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtMonthYear.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtMonthYear.ForeColor = System.Drawing.Color.Black;
            this.txtMonthYear.Location = new System.Drawing.Point(879, 10);
            this.txtMonthYear.Name = "txtMonthYear";
            this.txtMonthYear.Size = new System.Drawing.Size(100, 20);
            this.txtMonthYear.TabIndex = 2;
            this.txtMonthYear.TabStop = false;
            // 
            // txtCustFullName
            // 
            this.txtCustFullName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtCustFullName.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCustFullName.ForeColor = System.Drawing.Color.Black;
            this.txtCustFullName.Location = new System.Drawing.Point(345, 9);
            this.txtCustFullName.Name = "txtCustFullName";
            this.txtCustFullName.Size = new System.Drawing.Size(433, 20);
            this.txtCustFullName.TabIndex = 1;
            this.txtCustFullName.TabStop = false;
            // 
            // txtCustCode
            // 
            this.txtCustCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtCustCode.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCustCode.ForeColor = System.Drawing.Color.Black;
            this.txtCustCode.Location = new System.Drawing.Point(99, 9);
            this.txtCustCode.Name = "txtCustCode";
            this.txtCustCode.Size = new System.Drawing.Size(116, 20);
            this.txtCustCode.TabIndex = 0;
            this.txtCustCode.TabStop = false;
            // 
            // txtLoan
            // 
            this.txtLoan.BackColor = System.Drawing.SystemColors.Control;
            this.txtLoan.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtLoan.ForeColor = System.Drawing.Color.Black;
            this.txtLoan.Location = new System.Drawing.Point(12, 151);
            this.txtLoan.Margin = new System.Windows.Forms.Padding(0);
            this.txtLoan.Name = "txtLoan";
            this.txtLoan.ReadOnly = true;
            this.txtLoan.Size = new System.Drawing.Size(95, 20);
            this.txtLoan.TabIndex = 11;
            this.txtLoan.TabStop = false;
            this.txtLoan.Text = "Loan";
            // 
            // txtIntPayable
            // 
            this.txtIntPayable.BackColor = System.Drawing.SystemColors.Control;
            this.txtIntPayable.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtIntPayable.ForeColor = System.Drawing.Color.Black;
            this.txtIntPayable.Location = new System.Drawing.Point(287, 91);
            this.txtIntPayable.Margin = new System.Windows.Forms.Padding(0);
            this.txtIntPayable.Name = "txtIntPayable";
            this.txtIntPayable.ReadOnly = true;
            this.txtIntPayable.Size = new System.Drawing.Size(100, 20);
            this.txtIntPayable.TabIndex = 3;
            this.txtIntPayable.TabStop = false;
            this.txtIntPayable.Text = "Int Payable";
            this.txtIntPayable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtIncome2
            // 
            this.txtIncome2.BackColor = System.Drawing.SystemColors.Control;
            this.txtIncome2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtIncome2.ForeColor = System.Drawing.Color.Black;
            this.txtIncome2.Location = new System.Drawing.Point(906, 91);
            this.txtIncome2.Margin = new System.Windows.Forms.Padding(0);
            this.txtIncome2.Name = "txtIncome2";
            this.txtIncome2.ReadOnly = true;
            this.txtIncome2.Size = new System.Drawing.Size(100, 20);
            this.txtIncome2.TabIndex = 3;
            this.txtIncome2.TabStop = false;
            this.txtIncome2.Text = "Income";
            this.txtIncome2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtIncome1
            // 
            this.txtIncome1.BackColor = System.Drawing.SystemColors.Control;
            this.txtIncome1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtIncome1.ForeColor = System.Drawing.Color.Black;
            this.txtIncome1.Location = new System.Drawing.Point(581, 91);
            this.txtIncome1.Margin = new System.Windows.Forms.Padding(0);
            this.txtIncome1.Name = "txtIncome1";
            this.txtIncome1.ReadOnly = true;
            this.txtIncome1.Size = new System.Drawing.Size(90, 20);
            this.txtIncome1.TabIndex = 3;
            this.txtIncome1.TabStop = false;
            this.txtIncome1.Text = "Income";
            this.txtIncome1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtIntReceivable
            // 
            this.txtIntReceivable.BackColor = System.Drawing.SystemColors.Control;
            this.txtIntReceivable.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtIntReceivable.ForeColor = System.Drawing.Color.Black;
            this.txtIntReceivable.Location = new System.Drawing.Point(197, 91);
            this.txtIntReceivable.Margin = new System.Windows.Forms.Padding(0);
            this.txtIntReceivable.Name = "txtIntReceivable";
            this.txtIntReceivable.ReadOnly = true;
            this.txtIntReceivable.Size = new System.Drawing.Size(90, 20);
            this.txtIntReceivable.TabIndex = 3;
            this.txtIntReceivable.TabStop = false;
            this.txtIntReceivable.Text = "Int Receivable";
            this.txtIntReceivable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMonthlyTurnover
            // 
            this.txtMonthlyTurnover.BackColor = System.Drawing.SystemColors.Control;
            this.txtMonthlyTurnover.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtMonthlyTurnover.ForeColor = System.Drawing.Color.Black;
            this.txtMonthlyTurnover.Location = new System.Drawing.Point(806, 91);
            this.txtMonthlyTurnover.Margin = new System.Windows.Forms.Padding(0);
            this.txtMonthlyTurnover.Name = "txtMonthlyTurnover";
            this.txtMonthlyTurnover.ReadOnly = true;
            this.txtMonthlyTurnover.Size = new System.Drawing.Size(100, 20);
            this.txtMonthlyTurnover.TabIndex = 3;
            this.txtMonthlyTurnover.TabStop = false;
            this.txtMonthlyTurnover.Text = "Monthly Turnover";
            this.txtMonthlyTurnover.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAveBln2
            // 
            this.txtAveBln2.BackColor = System.Drawing.SystemColors.Control;
            this.txtAveBln2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtAveBln2.ForeColor = System.Drawing.Color.Black;
            this.txtAveBln2.Location = new System.Drawing.Point(493, 91);
            this.txtAveBln2.Margin = new System.Windows.Forms.Padding(0);
            this.txtAveBln2.Name = "txtAveBln2";
            this.txtAveBln2.ReadOnly = true;
            this.txtAveBln2.Size = new System.Drawing.Size(90, 20);
            this.txtAveBln2.TabIndex = 3;
            this.txtAveBln2.TabStop = false;
            this.txtAveBln2.Text = "Ave.Balance";
            this.txtAveBln2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAveBln1
            // 
            this.txtAveBln1.BackColor = System.Drawing.SystemColors.Control;
            this.txtAveBln1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtAveBln1.ForeColor = System.Drawing.Color.Black;
            this.txtAveBln1.Location = new System.Drawing.Point(107, 91);
            this.txtAveBln1.Margin = new System.Windows.Forms.Padding(0);
            this.txtAveBln1.Name = "txtAveBln1";
            this.txtAveBln1.ReadOnly = true;
            this.txtAveBln1.Size = new System.Drawing.Size(90, 20);
            this.txtAveBln1.TabIndex = 3;
            this.txtAveBln1.TabStop = false;
            this.txtAveBln1.Text = "Ave.Balance";
            this.txtAveBln1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtReserve
            // 
            this.txtReserve.BackColor = System.Drawing.SystemColors.Control;
            this.txtReserve.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtReserve.ForeColor = System.Drawing.Color.Black;
            this.txtReserve.Location = new System.Drawing.Point(12, 350);
            this.txtReserve.Margin = new System.Windows.Forms.Padding(0);
            this.txtReserve.Name = "txtReserve";
            this.txtReserve.ReadOnly = true;
            this.txtReserve.Size = new System.Drawing.Size(95, 20);
            this.txtReserve.TabIndex = 3;
            this.txtReserve.TabStop = false;
            this.txtReserve.Text = "Reserve";
            // 
            // txtOtherApp
            // 
            this.txtOtherApp.BackColor = System.Drawing.SystemColors.Control;
            this.txtOtherApp.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtOtherApp.ForeColor = System.Drawing.Color.Black;
            this.txtOtherApp.Location = new System.Drawing.Point(12, 251);
            this.txtOtherApp.Margin = new System.Windows.Forms.Padding(0);
            this.txtOtherApp.Name = "txtOtherApp";
            this.txtOtherApp.ReadOnly = true;
            this.txtOtherApp.Size = new System.Drawing.Size(95, 20);
            this.txtOtherApp.TabIndex = 3;
            this.txtOtherApp.TabStop = false;
            this.txtOtherApp.Text = "Other Application";
            // 
            // txtOtherSource
            // 
            this.txtOtherSource.BackColor = System.Drawing.SystemColors.Control;
            this.txtOtherSource.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtOtherSource.ForeColor = System.Drawing.Color.Black;
            this.txtOtherSource.Location = new System.Drawing.Point(12, 330);
            this.txtOtherSource.Margin = new System.Windows.Forms.Padding(0);
            this.txtOtherSource.Name = "txtOtherSource";
            this.txtOtherSource.ReadOnly = true;
            this.txtOtherSource.Size = new System.Drawing.Size(95, 20);
            this.txtOtherSource.TabIndex = 3;
            this.txtOtherSource.TabStop = false;
            this.txtOtherSource.Text = "Other Source";
            // 
            // txtBR
            // 
            this.txtBR.BackColor = System.Drawing.SystemColors.Control;
            this.txtBR.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtBR.ForeColor = System.Drawing.Color.Black;
            this.txtBR.Location = new System.Drawing.Point(12, 231);
            this.txtBR.Margin = new System.Windows.Forms.Padding(0);
            this.txtBR.Name = "txtBR";
            this.txtBR.ReadOnly = true;
            this.txtBR.Size = new System.Drawing.Size(95, 20);
            this.txtBR.TabIndex = 3;
            this.txtBR.TabStop = false;
            this.txtBR.Text = "B/R";
            // 
            // txtOthers3
            // 
            this.txtOthers3.BackColor = System.Drawing.SystemColors.Control;
            this.txtOthers3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtOthers3.ForeColor = System.Drawing.Color.Black;
            this.txtOthers3.Location = new System.Drawing.Point(705, 291);
            this.txtOthers3.Margin = new System.Windows.Forms.Padding(0);
            this.txtOthers3.Name = "txtOthers3";
            this.txtOthers3.ReadOnly = true;
            this.txtOthers3.Size = new System.Drawing.Size(101, 20);
            this.txtOthers3.TabIndex = 3;
            this.txtOthers3.TabStop = false;
            this.txtOthers3.Text = "Others";
            // 
            // txtPayment
            // 
            this.txtPayment.BackColor = System.Drawing.SystemColors.Control;
            this.txtPayment.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtPayment.ForeColor = System.Drawing.Color.Black;
            this.txtPayment.Location = new System.Drawing.Point(705, 191);
            this.txtPayment.Margin = new System.Windows.Forms.Padding(0);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.ReadOnly = true;
            this.txtPayment.Size = new System.Drawing.Size(101, 20);
            this.txtPayment.TabIndex = 3;
            this.txtPayment.TabStop = false;
            this.txtPayment.Text = "Payment";
            // 
            // txtOthers
            // 
            this.txtOthers.BackColor = System.Drawing.SystemColors.Control;
            this.txtOthers.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtOthers.ForeColor = System.Drawing.Color.Black;
            this.txtOthers.Location = new System.Drawing.Point(420, 191);
            this.txtOthers.Margin = new System.Windows.Forms.Padding(0);
            this.txtOthers.Name = "txtOthers";
            this.txtOthers.ReadOnly = true;
            this.txtOthers.Size = new System.Drawing.Size(80, 20);
            this.txtOthers.TabIndex = 3;
            this.txtOthers.TabStop = false;
            this.txtOthers.Text = "Others";
            // 
            // txtFixedDepo
            // 
            this.txtFixedDepo.BackColor = System.Drawing.SystemColors.Control;
            this.txtFixedDepo.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtFixedDepo.ForeColor = System.Drawing.Color.Black;
            this.txtFixedDepo.Location = new System.Drawing.Point(12, 310);
            this.txtFixedDepo.Margin = new System.Windows.Forms.Padding(0);
            this.txtFixedDepo.Name = "txtFixedDepo";
            this.txtFixedDepo.ReadOnly = true;
            this.txtFixedDepo.Size = new System.Drawing.Size(95, 20);
            this.txtFixedDepo.TabIndex = 3;
            this.txtFixedDepo.TabStop = false;
            this.txtFixedDepo.Text = "Depo (Fixed)";
            // 
            // txtBB
            // 
            this.txtBB.BackColor = System.Drawing.SystemColors.Control;
            this.txtBB.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtBB.ForeColor = System.Drawing.Color.Black;
            this.txtBB.Location = new System.Drawing.Point(12, 211);
            this.txtBB.Margin = new System.Windows.Forms.Padding(0);
            this.txtBB.Name = "txtBB";
            this.txtBB.ReadOnly = true;
            this.txtBB.Size = new System.Drawing.Size(95, 20);
            this.txtBB.TabIndex = 3;
            this.txtBB.TabStop = false;
            this.txtBB.Text = "B/B";
            // 
            // txtFX
            // 
            this.txtFX.BackColor = System.Drawing.SystemColors.Control;
            this.txtFX.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtFX.ForeColor = System.Drawing.Color.Black;
            this.txtFX.Location = new System.Drawing.Point(705, 271);
            this.txtFX.Margin = new System.Windows.Forms.Padding(0);
            this.txtFX.Name = "txtFX";
            this.txtFX.ReadOnly = true;
            this.txtFX.Size = new System.Drawing.Size(101, 20);
            this.txtFX.TabIndex = 3;
            this.txtFX.TabStop = false;
            this.txtFX.Text = "FX Profit/Loss";
            // 
            // txtCollecting
            // 
            this.txtCollecting.BackColor = System.Drawing.SystemColors.Control;
            this.txtCollecting.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCollecting.ForeColor = System.Drawing.Color.Black;
            this.txtCollecting.Location = new System.Drawing.Point(705, 171);
            this.txtCollecting.Margin = new System.Windows.Forms.Padding(0);
            this.txtCollecting.Name = "txtCollecting";
            this.txtCollecting.ReadOnly = true;
            this.txtCollecting.Size = new System.Drawing.Size(101, 20);
            this.txtCollecting.TabIndex = 3;
            this.txtCollecting.TabStop = false;
            this.txtCollecting.Text = "Collecting";
            // 
            // txtCommitment
            // 
            this.txtCommitment.BackColor = System.Drawing.SystemColors.Control;
            this.txtCommitment.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCommitment.ForeColor = System.Drawing.Color.Black;
            this.txtCommitment.Location = new System.Drawing.Point(420, 171);
            this.txtCommitment.Margin = new System.Windows.Forms.Padding(0);
            this.txtCommitment.Name = "txtCommitment";
            this.txtCommitment.ReadOnly = true;
            this.txtCommitment.Size = new System.Drawing.Size(80, 20);
            this.txtCommitment.TabIndex = 3;
            this.txtCommitment.TabStop = false;
            this.txtCommitment.Text = "Commitment";
            // 
            // txtLiquidDepo
            // 
            this.txtLiquidDepo.BackColor = System.Drawing.SystemColors.Control;
            this.txtLiquidDepo.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtLiquidDepo.ForeColor = System.Drawing.Color.Black;
            this.txtLiquidDepo.Location = new System.Drawing.Point(12, 290);
            this.txtLiquidDepo.Margin = new System.Windows.Forms.Padding(0);
            this.txtLiquidDepo.Name = "txtLiquidDepo";
            this.txtLiquidDepo.ReadOnly = true;
            this.txtLiquidDepo.Size = new System.Drawing.Size(95, 20);
            this.txtLiquidDepo.TabIndex = 3;
            this.txtLiquidDepo.TabStop = false;
            this.txtLiquidDepo.Text = "Depo (Liquid)";
            // 
            // txtOthers2
            // 
            this.txtOthers2.BackColor = System.Drawing.SystemColors.Control;
            this.txtOthers2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtOthers2.ForeColor = System.Drawing.Color.Black;
            this.txtOthers2.Location = new System.Drawing.Point(705, 251);
            this.txtOthers2.Margin = new System.Windows.Forms.Padding(0);
            this.txtOthers2.Name = "txtOthers2";
            this.txtOthers2.ReadOnly = true;
            this.txtOthers2.Size = new System.Drawing.Size(101, 20);
            this.txtOthers2.TabIndex = 3;
            this.txtOthers2.TabStop = false;
            this.txtOthers2.Text = "Others";
            // 
            // txtImpBill
            // 
            this.txtImpBill.BackColor = System.Drawing.SystemColors.Control;
            this.txtImpBill.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtImpBill.ForeColor = System.Drawing.Color.Black;
            this.txtImpBill.Location = new System.Drawing.Point(705, 151);
            this.txtImpBill.Margin = new System.Windows.Forms.Padding(0);
            this.txtImpBill.Name = "txtImpBill";
            this.txtImpBill.ReadOnly = true;
            this.txtImpBill.Size = new System.Drawing.Size(101, 20);
            this.txtImpBill.TabIndex = 3;
            this.txtImpBill.TabStop = false;
            this.txtImpBill.Text = "Imp bill Handling";
            // 
            // txtAcceptance
            // 
            this.txtAcceptance.BackColor = System.Drawing.SystemColors.Control;
            this.txtAcceptance.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtAcceptance.ForeColor = System.Drawing.Color.Black;
            this.txtAcceptance.Location = new System.Drawing.Point(420, 151);
            this.txtAcceptance.Margin = new System.Windows.Forms.Padding(0);
            this.txtAcceptance.Name = "txtAcceptance";
            this.txtAcceptance.ReadOnly = true;
            this.txtAcceptance.Size = new System.Drawing.Size(80, 20);
            this.txtAcceptance.TabIndex = 3;
            this.txtAcceptance.TabStop = false;
            this.txtAcceptance.Text = "Acceptance";
            // 
            // txtFloatLoan
            // 
            this.txtFloatLoan.BackColor = System.Drawing.SystemColors.Control;
            this.txtFloatLoan.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtFloatLoan.ForeColor = System.Drawing.Color.Black;
            this.txtFloatLoan.Location = new System.Drawing.Point(12, 191);
            this.txtFloatLoan.Margin = new System.Windows.Forms.Padding(0);
            this.txtFloatLoan.Name = "txtFloatLoan";
            this.txtFloatLoan.ReadOnly = true;
            this.txtFloatLoan.Size = new System.Drawing.Size(95, 20);
            this.txtFloatLoan.TabIndex = 3;
            this.txtFloatLoan.TabStop = false;
            this.txtFloatLoan.Text = "L/T Loan (Float)";
            // 
            // txtLoan2
            // 
            this.txtLoan2.BackColor = System.Drawing.SystemColors.Control;
            this.txtLoan2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtLoan2.ForeColor = System.Drawing.Color.Black;
            this.txtLoan2.Location = new System.Drawing.Point(705, 231);
            this.txtLoan2.Margin = new System.Windows.Forms.Padding(0);
            this.txtLoan2.Name = "txtLoan2";
            this.txtLoan2.ReadOnly = true;
            this.txtLoan2.Size = new System.Drawing.Size(101, 20);
            this.txtLoan2.TabIndex = 3;
            this.txtLoan2.TabStop = false;
            this.txtLoan2.Text = "Loan";
            // 
            // txtExpBill
            // 
            this.txtExpBill.BackColor = System.Drawing.SystemColors.Control;
            this.txtExpBill.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtExpBill.ForeColor = System.Drawing.Color.Black;
            this.txtExpBill.Location = new System.Drawing.Point(705, 131);
            this.txtExpBill.Margin = new System.Windows.Forms.Padding(0);
            this.txtExpBill.Name = "txtExpBill";
            this.txtExpBill.ReadOnly = true;
            this.txtExpBill.Size = new System.Drawing.Size(101, 20);
            this.txtExpBill.TabIndex = 3;
            this.txtExpBill.TabStop = false;
            this.txtExpBill.Text = "Exp Bill Handling";
            // 
            // txtCleanLC
            // 
            this.txtCleanLC.BackColor = System.Drawing.SystemColors.Control;
            this.txtCleanLC.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCleanLC.ForeColor = System.Drawing.Color.Black;
            this.txtCleanLC.Location = new System.Drawing.Point(420, 131);
            this.txtCleanLC.Margin = new System.Windows.Forms.Padding(0);
            this.txtCleanLC.Name = "txtCleanLC";
            this.txtCleanLC.ReadOnly = true;
            this.txtCleanLC.Size = new System.Drawing.Size(80, 20);
            this.txtCleanLC.TabIndex = 3;
            this.txtCleanLC.TabStop = false;
            this.txtCleanLC.Text = "Clean L/C";
            // 
            // txtFixedLoan
            // 
            this.txtFixedLoan.BackColor = System.Drawing.SystemColors.Control;
            this.txtFixedLoan.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtFixedLoan.ForeColor = System.Drawing.Color.Black;
            this.txtFixedLoan.Location = new System.Drawing.Point(12, 171);
            this.txtFixedLoan.Margin = new System.Windows.Forms.Padding(0);
            this.txtFixedLoan.Name = "txtFixedLoan";
            this.txtFixedLoan.ReadOnly = true;
            this.txtFixedLoan.Size = new System.Drawing.Size(95, 20);
            this.txtFixedLoan.TabIndex = 3;
            this.txtFixedLoan.TabStop = false;
            this.txtFixedLoan.Text = "L/T Loan (Fixed)";
            // 
            // Remittance
            // 
            this.Remittance.BackColor = System.Drawing.SystemColors.Control;
            this.Remittance.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Remittance.ForeColor = System.Drawing.Color.Black;
            this.Remittance.Location = new System.Drawing.Point(705, 211);
            this.Remittance.Margin = new System.Windows.Forms.Padding(0);
            this.Remittance.Name = "Remittance";
            this.Remittance.ReadOnly = true;
            this.Remittance.Size = new System.Drawing.Size(101, 20);
            this.Remittance.TabIndex = 3;
            this.Remittance.TabStop = false;
            this.Remittance.Text = "Remittance";
            // 
            // txtDocLC
            // 
            this.txtDocLC.BackColor = System.Drawing.SystemColors.Control;
            this.txtDocLC.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtDocLC.ForeColor = System.Drawing.Color.Black;
            this.txtDocLC.Location = new System.Drawing.Point(705, 111);
            this.txtDocLC.Margin = new System.Windows.Forms.Padding(0);
            this.txtDocLC.Name = "txtDocLC";
            this.txtDocLC.ReadOnly = true;
            this.txtDocLC.Size = new System.Drawing.Size(101, 20);
            this.txtDocLC.TabIndex = 3;
            this.txtDocLC.TabStop = false;
            this.txtDocLC.Text = "Doc L/C";
            // 
            // txtGuarantee
            // 
            this.txtGuarantee.BackColor = System.Drawing.SystemColors.Control;
            this.txtGuarantee.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtGuarantee.ForeColor = System.Drawing.Color.Black;
            this.txtGuarantee.Location = new System.Drawing.Point(420, 111);
            this.txtGuarantee.Margin = new System.Windows.Forms.Padding(0);
            this.txtGuarantee.Name = "txtGuarantee";
            this.txtGuarantee.ReadOnly = true;
            this.txtGuarantee.Size = new System.Drawing.Size(80, 20);
            this.txtGuarantee.TabIndex = 3;
            this.txtGuarantee.TabStop = false;
            this.txtGuarantee.Text = "Guarantee";
            // 
            // txtCommercialBill
            // 
            this.txtCommercialBill.BackColor = System.Drawing.SystemColors.Control;
            this.txtCommercialBill.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCommercialBill.ForeColor = System.Drawing.Color.Black;
            this.txtCommercialBill.Location = new System.Drawing.Point(12, 131);
            this.txtCommercialBill.Margin = new System.Windows.Forms.Padding(0);
            this.txtCommercialBill.Name = "txtCommercialBill";
            this.txtCommercialBill.ReadOnly = true;
            this.txtCommercialBill.Size = new System.Drawing.Size(95, 20);
            this.txtCommercialBill.TabIndex = 3;
            this.txtCommercialBill.TabStop = false;
            this.txtCommercialBill.Text = "Commercial Bill";
            // 
            // txtOverdraft
            // 
            this.txtOverdraft.BackColor = System.Drawing.SystemColors.Control;
            this.txtOverdraft.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtOverdraft.ForeColor = System.Drawing.Color.Black;
            this.txtOverdraft.Location = new System.Drawing.Point(12, 111);
            this.txtOverdraft.Margin = new System.Windows.Forms.Padding(0);
            this.txtOverdraft.Name = "txtOverdraft";
            this.txtOverdraft.ReadOnly = true;
            this.txtOverdraft.Size = new System.Drawing.Size(95, 20);
            this.txtOverdraft.TabIndex = 3;
            this.txtOverdraft.TabStop = false;
            this.txtOverdraft.Text = "Overdraft";
            // 
            // frmUpdateCustomerTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(1019, 438);
            this.Controls.Add(this.textbox54);
            this.Controls.Add(this.txtMonthYear);
            this.Controls.Add(this.txtCustFullName);
            this.Controls.Add(this.txtCustCode);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.textbox9);
            this.Controls.Add(this.textbox6);
            this.Controls.Add(this.textbox3);
            this.Controls.Add(this.txtLoan);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.ckbNotShow);
            this.Controls.Add(this.lblToMonthYear);
            this.Controls.Add(this.lblCustomerFullName);
            this.Controls.Add(this.txtIntPayable);
            this.Controls.Add(this.txtIncome2);
            this.Controls.Add(this.txtIncome1);
            this.Controls.Add(this.txtIntReceivable);
            this.Controls.Add(this.txtMonthlyTurnover);
            this.Controls.Add(this.txtAveBln2);
            this.Controls.Add(this.txtAveBln1);
            this.Controls.Add(this.textbox36);
            this.Controls.Add(this.textbox24);
            this.Controls.Add(this.textbox33);
            this.Controls.Add(this.textbox21);
            this.Controls.Add(this.textbox30);
            this.Controls.Add(this.textbox20);
            this.Controls.Add(this.textbox29);
            this.Controls.Add(this.textbox15);
            this.Controls.Add(this.textbox14);
            this.Controls.Add(this.textbox8);
            this.Controls.Add(this.textbox7);
            this.Controls.Add(this.textbox35);
            this.Controls.Add(this.textbox23);
            this.Controls.Add(this.textbox32);
            this.Controls.Add(this.textbox19);
            this.Controls.Add(this.textbox28);
            this.Controls.Add(this.textbox66);
            this.Controls.Add(this.textbox61);
            this.Controls.Add(this.textbox46);
            this.Controls.Add(this.textbox18);
            this.Controls.Add(this.textbox27);
            this.Controls.Add(this.textbox65);
            this.Controls.Add(this.textbox60);
            this.Controls.Add(this.textbox45);
            this.Controls.Add(this.textbox13);
            this.Controls.Add(this.textbox64);
            this.Controls.Add(this.textbox59);
            this.Controls.Add(this.textbox44);
            this.Controls.Add(this.textbox12);
            this.Controls.Add(this.textbox63);
            this.Controls.Add(this.textbox58);
            this.Controls.Add(this.textbox43);
            this.Controls.Add(this.textbox5);
            this.Controls.Add(this.textbox62);
            this.Controls.Add(this.textbox57);
            this.Controls.Add(this.textbox42);
            this.Controls.Add(this.textbox4);
            this.Controls.Add(this.textbox34);
            this.Controls.Add(this.textbox22);
            this.Controls.Add(this.textbox31);
            this.Controls.Add(this.textbox17);
            this.Controls.Add(this.textbox26);
            this.Controls.Add(this.textbox56);
            this.Controls.Add(this.textbox51);
            this.Controls.Add(this.textbox41);
            this.Controls.Add(this.textbox16);
            this.Controls.Add(this.textbox25);
            this.Controls.Add(this.textbox55);
            this.Controls.Add(this.textbox50);
            this.Controls.Add(this.textbox40);
            this.Controls.Add(this.textbox11);
            this.Controls.Add(this.textbox49);
            this.Controls.Add(this.textbox39);
            this.Controls.Add(this.textbox53);
            this.Controls.Add(this.textbox48);
            this.Controls.Add(this.textbox38);
            this.Controls.Add(this.textbox10);
            this.Controls.Add(this.textbox52);
            this.Controls.Add(this.textbox47);
            this.Controls.Add(this.textbox37);
            this.Controls.Add(this.textbox2);
            this.Controls.Add(this.textbox1);
            this.Controls.Add(this.txtReserve);
            this.Controls.Add(this.txtOtherApp);
            this.Controls.Add(this.txtOtherSource);
            this.Controls.Add(this.txtBR);
            this.Controls.Add(this.txtOthers3);
            this.Controls.Add(this.txtPayment);
            this.Controls.Add(this.txtOthers);
            this.Controls.Add(this.txtFixedDepo);
            this.Controls.Add(this.txtBB);
            this.Controls.Add(this.txtFX);
            this.Controls.Add(this.txtCollecting);
            this.Controls.Add(this.txtCommitment);
            this.Controls.Add(this.txtLiquidDepo);
            this.Controls.Add(this.txtOthers2);
            this.Controls.Add(this.txtImpBill);
            this.Controls.Add(this.txtAcceptance);
            this.Controls.Add(this.txtFloatLoan);
            this.Controls.Add(this.txtLoan2);
            this.Controls.Add(this.txtExpBill);
            this.Controls.Add(this.txtCleanLC);
            this.Controls.Add(this.txtFixedLoan);
            this.Controls.Add(this.Remittance);
            this.Controls.Add(this.txtDocLC);
            this.Controls.Add(this.txtGuarantee);
            this.Controls.Add(this.txtCommercialBill);
            this.Controls.Add(this.txtOverdraft);
            this.Controls.Add(this.frmCustomerCode);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmUpdateCustomerTransaction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update Customer Transaction";
            this.Load += new System.EventHandler(this.frmUpdateCustomerTransaction_Load);
            this.Activated += new System.EventHandler(this.frmUpdateCustomerTransaction_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmUpdateCustomerTransaction_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label frmCustomerCode;
        private System.Windows.Forms.Label lblCustomerFullName;
        private System.Windows.Forms.Label lblToMonthYear;
        private System.Windows.Forms.CheckBox ckbNotShow;
        private DisableTextBox txtOverdraft;
        private DisableTextBox txtAveBln1;
        private System.Windows.Forms.TextBox textbox1;
        private System.Windows.Forms.TextBox textbox4;
        private System.Windows.Forms.TextBox textbox7;
        private DisableTextBox txtIntReceivable;
        private DisableTextBox txtIntPayable;
        private DisableTextBox txtCommercialBill;
        private System.Windows.Forms.TextBox textbox2;
        private System.Windows.Forms.TextBox textbox5;
        private System.Windows.Forms.TextBox textbox8;
        private DisableTextBox txtFixedLoan;
        private System.Windows.Forms.TextBox textbox10;
        private System.Windows.Forms.TextBox textbox12;
        private System.Windows.Forms.TextBox textbox14;
        private DisableTextBox txtFloatLoan;
        private System.Windows.Forms.TextBox textbox11;
        private System.Windows.Forms.TextBox textbox13;
        private System.Windows.Forms.TextBox textbox15;
        private DisableTextBox txtBB;
        private System.Windows.Forms.TextBox textbox16;
        private System.Windows.Forms.TextBox textbox18;
        private System.Windows.Forms.TextBox textbox20;
        private DisableTextBox txtBR;
        private System.Windows.Forms.TextBox textbox17;
        private System.Windows.Forms.TextBox textbox19;
        private System.Windows.Forms.TextBox textbox21;
        private DisableTextBox txtOtherApp;
        private System.Windows.Forms.TextBox textbox22;
        private System.Windows.Forms.TextBox textbox23;
        private System.Windows.Forms.TextBox textbox24;
        private DisableTextBox txtLiquidDepo;
        private DisableTextBox txtFixedDepo;
        private DisableTextBox txtOtherSource;
        private DisableTextBox txtReserve;
        private System.Windows.Forms.TextBox textbox25;
        private System.Windows.Forms.TextBox textbox26;
        private System.Windows.Forms.TextBox textbox31;
        private System.Windows.Forms.TextBox textbox34;
        private System.Windows.Forms.TextBox textbox27;
        private System.Windows.Forms.TextBox textbox28;
        private System.Windows.Forms.TextBox textbox32;
        private System.Windows.Forms.TextBox textbox35;
        private System.Windows.Forms.TextBox textbox29;
        private System.Windows.Forms.TextBox textbox30;
        private System.Windows.Forms.TextBox textbox33;
        private System.Windows.Forms.TextBox textbox36;
        private DisableTextBox txtGuarantee;
        private DisableTextBox txtCleanLC;
        private DisableTextBox txtAcceptance;
        private DisableTextBox txtCommitment;
        private DisableTextBox txtOthers;
        private System.Windows.Forms.TextBox textbox37;
        private System.Windows.Forms.TextBox textbox38;
        private System.Windows.Forms.TextBox textbox39;
        private System.Windows.Forms.TextBox textbox40;
        private System.Windows.Forms.TextBox textbox41;
        private System.Windows.Forms.TextBox textbox42;
        private System.Windows.Forms.TextBox textbox43;
        private System.Windows.Forms.TextBox textbox44;
        private System.Windows.Forms.TextBox textbox45;
        private System.Windows.Forms.TextBox textbox46;
        private DisableTextBox txtAveBln2;
        private DisableTextBox txtIncome1;
        private DisableTextBox txtDocLC;
        private DisableTextBox txtExpBill;
        private DisableTextBox txtImpBill;
        private DisableTextBox txtCollecting;
        private DisableTextBox txtPayment;
        private System.Windows.Forms.TextBox textbox47;
        private System.Windows.Forms.TextBox textbox48;
        private System.Windows.Forms.TextBox textbox49;
        private System.Windows.Forms.TextBox textbox50;
        private System.Windows.Forms.TextBox textbox51;
        private System.Windows.Forms.TextBox textbox57;
        private System.Windows.Forms.TextBox textbox58;
        private System.Windows.Forms.TextBox textbox59;
        private System.Windows.Forms.TextBox textbox60;
        private System.Windows.Forms.TextBox textbox61;
        private DisableTextBox txtMonthlyTurnover;
        private DisableTextBox txtIncome2;
        private DisableTextBox Remittance;
        private DisableTextBox txtLoan2;
        private DisableTextBox txtOthers2;
        private DisableTextBox txtFX;
        private DisableTextBox txtOthers3;
        private System.Windows.Forms.TextBox textbox52;
        private System.Windows.Forms.TextBox textbox53;
        private System.Windows.Forms.TextBox textbox55;
        private System.Windows.Forms.TextBox textbox56;
        private System.Windows.Forms.TextBox textbox62;
        private System.Windows.Forms.TextBox textbox63;
        private System.Windows.Forms.TextBox textbox64;
        private System.Windows.Forms.TextBox textbox65;
        private System.Windows.Forms.TextBox textbox66;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox textbox9;
        private System.Windows.Forms.TextBox textbox6;
        private System.Windows.Forms.TextBox textbox3;
        private DisableTextBox txtLoan;
        private System.Windows.Forms.Button btnClose;
        private DisableTextBox txtCustCode;
        private DisableTextBox txtCustFullName;
        private DisableTextBox txtMonthYear;
        private System.Windows.Forms.TextBox textbox54;
    }
}