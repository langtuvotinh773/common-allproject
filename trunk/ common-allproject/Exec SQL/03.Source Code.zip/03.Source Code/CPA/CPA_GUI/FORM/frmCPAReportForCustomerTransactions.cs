﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Customer Transaction Report
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using CrystalDecisions.Shared; 
using System.Globalization;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Common;
using CPA.CPA_GUI.REPORT;
using System.Windows.Forms;
namespace Phoenix.Cpa.Gui.Forms
{
    /// <summary>
    /// Phong: Create at 2/2013
    /// </summary>
    public partial class frmReportForCustomerTransactions : MasterForm
    {
        public bool Show = true;
        public frmReportForCustomerTransactions(string yearMonth , string customerCode, string jnj,string customerName )
        {
            InitializeComponent();
			//Yen Phan
		//	this.BackColor = clsCPAConstant.BG_FORM;
            string yearmonth = yearMonth;   
            DateTime time = new DateTime(int.Parse(yearmonth.Remove(4)),int.Parse(yearmonth.Remove(0,4)),1);
            ParameterFields myParams = new ParameterFields();
            ParameterField myParam1 = new ParameterField();
            ParameterField myParam2 = new ParameterField();
            ParameterField myParam3 = new ParameterField();
            ParameterDiscreteValue myDiscreteValue1 = new ParameterDiscreteValue();

          
            ParameterDiscreteValue myDiscreteValue4 = new ParameterDiscreteValue();
            ParameterField myParam4 = new ParameterField();
			myParam4.ParameterFieldName = clsCPAConstant.REPORT_FOR_CUSTOMER_TRANSACTIONS_PARAM_04_NAME;
			myDiscreteValue4.Value = time.ToString("MMM yyyy");
            myParam4.CurrentValues.Add(myDiscreteValue4);
            myParams.Add(myParam4);


        

            List<string> parameter = GetListColumns(yearmonth);
            for (int i = 0; i < parameter.Count; i++)
            {
                ParameterDiscreteValue myDiscreteValue14 = new ParameterDiscreteValue();
                ParameterField myParam14 = new ParameterField();
				myParam14.ParameterFieldName = clsCPAConstant.REPORT_FOR_CUSTOMER_TRANSACTIONS_PARAM_14_NAME + (12 - i).ToString("00");
                myDiscreteValue14.Value = parameter[i];
                myParam14.CurrentValues.Add(myDiscreteValue14);
                myParams.Add(myParam14);
            }


            // Assign the params collection to the report viewer
            crystalReportViewer1.ParameterFieldInfo = myParams;

            

            clsViewListTransactionBLL bll = new clsViewListTransactionBLL();
            DataTable data = bll.GetDataForReport(customerCode, yearmonth, jnj, customerName);
          
            if (data.Rows.Count > 0)
            {
                int rowindex = 0;
                int columnindex = 0;
                foreach (DataRow row in data.Rows)
                {
                    columnindex = 0;
                    foreach (var item in row.ItemArray)
                    {
                        if (item.GetType() == typeof(DBNull)) data.Rows[rowindex][columnindex] = 0;
                        if (columnindex == 67) break;
                        columnindex++;

                    }
                    rowindex++;
                }
                DtsCustomerTransactions dataReport = new DtsCustomerTransactions();


                string currentID = "";
                List<string> months = new List<string>();
                int iMonth = 12;
                int index = -1;
                DataRow[] rows = data.Select(string.Empty, "CustomerID desc"); //sort list CPA

                foreach (DataRow row in rows) // loop all rows
                {
                    iMonth = GetIndexFromYeatMonth((string)row["YearMonth"], yearmonth);
                    if (currentID != (string)row["CustomerID"]) // if not same customer ID, create a new row in dataset
                    {
                        currentID = (string)row["CustomerID"];
                        index++; //increate index 
                        dataReport.DataTable1.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "");
                    }

                    string strMonth = "month" + iMonth.ToString("00");
                    if ((bool)row["ReportStatus"] != true && (byte)row["CPA_Status"] == 1) // get value from row data to dataset
                    {
                        dataReport.DataTable1.Rows[index][strMonth + "1"] = ((Int64)row["STL_Loan_AVE"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "2"] = ((Int64)row["LTL_Fixed_AVE"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "3"] = ((Int64)row["LTL_Floating_AVE"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "4"] = ((Int64)row["BB_AVE"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "5"] = ((Int64)row["Dep_Liquid_AVE"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "6"] = ((Int64)row["Dep_Fixed_AVE"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "7"] = ((Int64)row["Guarantee_AVE"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "8"] = ((Int64)row["Acceptance_AVE"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "9"] = ((Int64)row["DocLC_TUR"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "10"] = ((Int64)row["ExpBillHandling_TUR"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "11"] = ((Int64)row["ImpBillHandling_TUR"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "12"] = ((Int64)row["Collecting_TUR"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "13"] = ((Int64)row["Payment_TUR"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "14"] = ((Int64)row["Remittance_TUR"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "15"] = ((Int64)row["ForeignExchangePL_TUR"]).ToString("#,0");
                        dataReport.DataTable1.Rows[index][strMonth + "16"] = ((Int64)row["Others01_TUR"]).ToString("#,0");
                    }
                    dataReport.DataTable1.Rows[index]["customerCode"] = (string)row["CustomerID"];
                    dataReport.DataTable1.Rows[index]["customerName"] = (string)row["Name"];
                    dataReport.DataTable1.Rows[index]["jnj"] = (string)row["JNJ"];
                    iMonth--;

                }
               
                CrystalReport11.SetDataSource(dataReport);
                
            }
            else
            {
                Show = false;
                clsMesageCollection.MessageNoTransactions();
            }
            
        }

        
        private int GetIndexFromYeatMonth(string input, string owner)
        {
            DateTime target = new DateTime(int.Parse(input.Remove(4)),int.Parse(input.Remove(0,4)),1);
            DateTime standard = new DateTime(int.Parse(owner.Remove(4)), int.Parse(owner.Remove(0, 4)), 1);
            int distance = (standard.Year - target.Year) * 12 + (standard.Month - target.Month);
            return 12 - distance;
        }

        private List<string> GetListColumns(string input)
        {
            List<string> result = new List<string>();
            DateTime date = new DateTime(int.Parse(input.Remove(4)), int.Parse(input.Remove(0, 4)), 1);
            for (int i = 0; i < 12; i++)
            {
               DateTime temp = date.AddMonths(-i);
                string a = temp.ToString("Y", CultureInfo.CreateSpecificCulture("en-US"));
                if (temp.Year < date.Year)
                {
                    result.Add("Pre "+a.Remove(3));
                }
                else
                    result.Add(a.Remove(3));

            }
            return result;
        }

       
    }
}
