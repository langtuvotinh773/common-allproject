﻿namespace Phoenix.Cpa.Gui.Forms
{
    partial class frmListCustomerError
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblMonthYear = new System.Windows.Forms.Label();
            this.lblErrorType = new System.Windows.Forms.Label();
            this.cbbMonthYear = new System.Windows.Forms.ComboBox();
            this.cbbErrorType = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtgCustomerErrorList = new System.Windows.Forms.DataGridView();
            this.clDelete = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.clCustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clCustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clMonthYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clErrorType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clAccountOfficer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clImportedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDelete = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCustomerErrorList)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMonthYear
            // 
            this.lblMonthYear.AutoSize = true;
            this.lblMonthYear.Location = new System.Drawing.Point(6, 22);
            this.lblMonthYear.Name = "lblMonthYear";
            this.lblMonthYear.Size = new System.Drawing.Size(64, 13);
            this.lblMonthYear.TabIndex = 0;
            this.lblMonthYear.Text = "Month/Year";
            // 
            // lblErrorType
            // 
            this.lblErrorType.AutoSize = true;
            this.lblErrorType.Location = new System.Drawing.Point(229, 22);
            this.lblErrorType.Name = "lblErrorType";
            this.lblErrorType.Size = new System.Drawing.Size(56, 13);
            this.lblErrorType.TabIndex = 0;
            this.lblErrorType.Text = "Error Type";
            // 
            // cbbMonthYear
            // 
            this.cbbMonthYear.FormattingEnabled = true;
            this.cbbMonthYear.Location = new System.Drawing.Point(74, 16);
            this.cbbMonthYear.Name = "cbbMonthYear";
            this.cbbMonthYear.Size = new System.Drawing.Size(100, 21);
            this.cbbMonthYear.TabIndex = 0;
            // 
            // cbbErrorType
            // 
            this.cbbErrorType.FormattingEnabled = true;
            this.cbbErrorType.Location = new System.Drawing.Point(291, 17);
            this.cbbErrorType.Name = "cbbErrorType";
            this.cbbErrorType.Size = new System.Drawing.Size(186, 21);
            this.cbbErrorType.TabIndex = 1;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(493, 17);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 21);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtgCustomerErrorList
            // 
            this.dtgCustomerErrorList.AllowUserToAddRows = false;
            this.dtgCustomerErrorList.AllowUserToDeleteRows = false;
            this.dtgCustomerErrorList.AllowUserToResizeColumns = false;
            this.dtgCustomerErrorList.AllowUserToResizeRows = false;
            this.dtgCustomerErrorList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgCustomerErrorList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgCustomerErrorList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgCustomerErrorList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgCustomerErrorList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clDelete,
            this.clCustomerCode,
            this.clCustomerName,
            this.clMonthYear,
            this.clErrorType,
            this.clAccountOfficer,
            this.clImportedBy});
            this.dtgCustomerErrorList.Location = new System.Drawing.Point(5, 133);
            this.dtgCustomerErrorList.Name = "dtgCustomerErrorList";
            this.dtgCustomerErrorList.ReadOnly = true;
            this.dtgCustomerErrorList.RowHeadersVisible = false;
            this.dtgCustomerErrorList.Size = new System.Drawing.Size(782, 298);
            this.dtgCustomerErrorList.TabIndex = 1;
            this.dtgCustomerErrorList.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCustomerErrorList_CellValueChanged);
            this.dtgCustomerErrorList.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgCustomerErrorList_CellMouseClick);
            this.dtgCustomerErrorList.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCustomerErrorList_RowEnter);
            this.dtgCustomerErrorList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCustomerErrorList_CellClick);
            this.dtgCustomerErrorList.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtgCustomerErrorList_KeyDown);
            this.dtgCustomerErrorList.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCustomerErrorList_CellEnter);
            // 
            // clDelete
            // 
            this.clDelete.FillWeight = 70.48863F;
            this.clDelete.HeaderText = "";
            this.clDelete.Name = "clDelete";
            this.clDelete.ReadOnly = true;
            this.clDelete.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // clCustomerCode
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.clCustomerCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.clCustomerCode.FillWeight = 99.87798F;
            this.clCustomerCode.HeaderText = "Customer Code";
            this.clCustomerCode.Name = "clCustomerCode";
            this.clCustomerCode.ReadOnly = true;
            this.clCustomerCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // clCustomerName
            // 
            this.clCustomerName.FillWeight = 106.599F;
            this.clCustomerName.HeaderText = "Customer Name";
            this.clCustomerName.Name = "clCustomerName";
            this.clCustomerName.ReadOnly = true;
            this.clCustomerName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // clMonthYear
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "MMM yyyy";
            this.clMonthYear.DefaultCellStyle = dataGridViewCellStyle3;
            this.clMonthYear.FillWeight = 104.8709F;
            this.clMonthYear.HeaderText = "Month Year";
            this.clMonthYear.Name = "clMonthYear";
            this.clMonthYear.ReadOnly = true;
            this.clMonthYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // clErrorType
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.clErrorType.DefaultCellStyle = dataGridViewCellStyle4;
            this.clErrorType.FillWeight = 107.714F;
            this.clErrorType.HeaderText = "Error Type";
            this.clErrorType.Name = "clErrorType";
            this.clErrorType.ReadOnly = true;
            this.clErrorType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // clAccountOfficer
            // 
            this.clAccountOfficer.FillWeight = 111.1843F;
            this.clAccountOfficer.HeaderText = "Account Officer";
            this.clAccountOfficer.Name = "clAccountOfficer";
            this.clAccountOfficer.ReadOnly = true;
            this.clAccountOfficer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // clImportedBy
            // 
            this.clImportedBy.FillWeight = 99.26532F;
            this.clImportedBy.HeaderText = "Imported by";
            this.clImportedBy.Name = "clImportedBy";
            this.clImportedBy.ReadOnly = true;
            this.clImportedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnDelete.Location = new System.Drawing.Point(581, 437);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 23);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.cbbErrorType);
            this.groupBox1.Controls.Add(this.lblMonthYear);
            this.groupBox1.Controls.Add(this.lblErrorType);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.cbbMonthYear);
            this.groupBox1.Location = new System.Drawing.Point(5, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(783, 127);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(9, 56);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(765, 65);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Error Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.Location = new System.Drawing.Point(379, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(310, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "04: CPA list is mismatch (Not Exist in Phoenix but Exist in SMILE)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(379, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(308, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "03: CPA list is mismatch (Exist in Phoenix but not Exist in SMILE)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(62, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(261, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "02:  Customer account is closed all in Phoenix system.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(62, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "01:  Customer does not Exist in Phoenix";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(687, 437);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 23);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 106.599F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Customer Code";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.Width = 108;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 107.7025F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Customer Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.Width = 101;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn3.FillWeight = 111.9279F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Month Year";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn3.Width = 101;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn4.FillWeight = 114.9623F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Error Type";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 101;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.FillWeight = 118.6662F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Account Officer";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 119;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.FillWeight = 105.9451F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Imported by";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 101;
            // 
            // frmListCustomerError
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(791, 472);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.dtgCustomerErrorList);
            this.Name = "frmListCustomerError";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List Customer Error ";
            this.Load += new System.EventHandler(this.frmListCustomerError_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmListCustomerError_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dtgCustomerErrorList)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblMonthYear;
        private System.Windows.Forms.Label lblErrorType;
        private System.Windows.Forms.ComboBox cbbMonthYear;
        private System.Windows.Forms.ComboBox cbbErrorType;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dtgCustomerErrorList;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn clDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn clCustomerCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn clCustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clMonthYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn clErrorType;
        private System.Windows.Forms.DataGridViewTextBoxColumn clAccountOfficer;
        private System.Windows.Forms.DataGridViewTextBoxColumn clImportedBy;
    }
}