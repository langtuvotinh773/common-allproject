﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-02-25 20:37:30 +0700 (Mon, 25 Feb 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for report customer information
 * for CPA module.
 */
using System;
using Config.Classes;
using Phoenix.Cpa.Common;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Dto;
namespace Phoenix.Cpa.Gui.Forms
{

    /// <summary>
    /// This class use to create report Customer Master
    /// Phong: In Charge at 3/2013
    /// </summary>
	public class CReportCustomerInformation
	{
		private string m_FileName = ""; //location of file name
		private ExcelBase m_ExcelBase;
		private string m_TemplateName; 
		string m_ProjectName;
		private clsReportBLL m_rptBus;
		private bool m_isNoData;

		clsCPACustomerInformationReportDTO m_CustomerInfoDTO;


		public CReportCustomerInformation(clsCPACustomerInformationReportDTO customerInfoDTO)
		{
			m_FileName = "";
			m_ExcelBase = null;
			m_TemplateName = clsCPAConstant.CUSTOMER_INFORMATION_TEMPLATE;
			m_ProjectName = clsCPAConstant.PROJECT_NAME_CPA;
			m_rptBus = new clsReportBLL();
			m_isNoData = false;
			m_CustomerInfoDTO = customerInfoDTO;
		}


        /// <summary>
        /// Expoer to excel funtion
        /// </summary>
		public void ExportToExcel()
		{
			GetFileName();
			bool isOpen = false;

            m_ExcelBase = new ExcelBase(m_FileName, m_TemplateName, m_ProjectName, ref isOpen, m_rptBus.GetServerDate());
			if (isOpen)
				return;
			m_rptBus = new clsReportBLL();
			m_isNoData = false;
            SaveReportCustomerInformation();
		
		}
		/// <summary>
		/// Export customer's information report to excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void SaveReportCustomerInformation()
		{

			try
			{

                InsertText(m_CustomerInfoDTO.CustomerCode,7,27);
                InsertText(m_CustomerInfoDTO.CustomerName, 9, 27);
                InsertText(m_CustomerInfoDTO.CustomerShortName, 12, 27);
                InsertText(m_CustomerInfoDTO.SortingIndex, 14, 27);
                InsertText(m_CustomerInfoDTO.Postal, 14, 65);
                InsertText(m_CustomerInfoDTO.Telephone, 14, 101);
                InsertText(m_CustomerInfoDTO.Fax, 15, 101);
                InsertText(m_CustomerInfoDTO.Address, 17, 27);
                InsertText(m_CustomerInfoDTO.Location, 22, 27);
                InsertText(m_CustomerInfoDTO.IndustryCode, 28, 59);
                if (m_CustomerInfoDTO.CpaList == true)
                    InsertText("X", 40, 62);
                else
                    InsertText("X", 41, 62);

               
			}
			catch (Exception ex) { Console.WriteLine(ex.Message); }
			m_ExcelBase.SaveFile(0.56);

		}


        /// <summary>
        /// insert char by char to excel
        /// </summary>
        /// <param name="text">input text</param>
        /// <param name="rowI">row start in excel</param>
        /// <param name="colI">column start in excel</param>
        private void InsertText(string text, int rowI, int colI)
        {
            text = text.ToUpper();
            for (int i = 0; i < text.Length; i++)
            {
                if (colI == 129 && (rowI != 14 || rowI != 15))
                {
                    colI = 27;
                    rowI += 1;
                }
                m_ExcelBase.InsertText(colI, rowI, text[i].ToString());
                colI += 3;
            }
        }


        


		/// <summary>
		/// Get file name to export excel
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void GetFileName()
		{
			string strServerDate = m_rptBus.GetServerDate();
			m_FileName = clsCPAConstant.R_L_CUSTOMER_INFORMATION + strServerDate;
		}
	}
}