﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Master Form
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Phoenix.Common.Security.Com;
using Config.Classes;
using CPA.Properties;
using Phoenix.Cpa.Bus;

namespace Phoenix.Cpa.Gui.Forms
{
    public partial class MasterForm : Form
    {
        private clsSEAuthorizer _security = null;
        public bool ForceClose = false;
        public bool isMaxSize = false;
        public MasterForm()
        {
            InitializeComponent();
            if (Screen.PrimaryScreen.Bounds.Width > 1024)
            {

                isMaxSize = true;
            }
            SetFormStyle();
        }

        public void SetSecurity()
        {
            _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            _security.CheckAuthorizationOnScreen(this);
            //clsGetDataCombobox.Instance().LoadData();
            //clsTemplateManager.Instance().CreateDirectory();

        }
        public void SetFormStyle()
        {
            this.BackColor = clsCommonStyles.Instance().FormBG;
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            SetFormStyleCommon(this);
        }

        public virtual void SetFormStyleCommon(Control controls)
        {
            foreach (Control c in controls.Controls)
            {
                if (c is Label)
                    c.BackColor = clsCommonStyles.Instance().LabelBG;
                else if (c is DataGridView)
                {
                    DataGridView grid = (DataGridView)c;

                    grid.AllowUserToOrderColumns = false;
                    grid.AllowUserToResizeColumns = false;
                    grid.AllowUserToResizeRows = false;
                    grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                    grid.EnableHeadersVisualStyles = false;
                    grid.AlternatingRowsDefaultCellStyle = clsCommonStyles.Instance().DGVAlternatingRowsDefaultCellStyle;
                    grid.ColumnHeadersDefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
                   
                    grid.DefaultCellStyle.SelectionBackColor = clsCommonStyles.Instance().DGVSelectionBackColor; //clsCommonStyles.Instance().DGVReadOnlyColumnBG;		
                    grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    if (grid.ReadOnly == true)
                    {
                        grid.StandardTab = true;
                        grid.DefaultCellStyle.BackColor = Config.Classes.clsCommonStyles.Instance().DGVReadOnlyColumnBG;
                    }
                    else
                    {
                        //grid.SelectionMode = DataGridViewSelectionMode.CellSelect ;
                        grid.StandardTab = false;
                    }
                    for (int i = 0; i < grid.Columns.Count; i++)
                    {
                        if (grid.Columns[i].ReadOnly == true)
                        {
                            grid.Columns[i].DefaultCellStyle.BackColor = Config.Classes.clsCommonStyles.Instance().DGVReadOnlyColumnBG;
                        }
                        grid.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                   
                }
                else if (c is Button)
                    c.BackColor = clsCommonStyles.Instance().ButtonBG;
                else if (c is GroupBox)
                    SetFormStyleCommon(c);
                else if (c is UserCtrl.DisableTextBox)
                {
                    c.BackColor = clsCommonStyles.Instance().ReadOnlyTextBoxBG;
                    c.ForeColor = Color.Black;
                }
                else if (c is TextBox)
                    c.ImeMode = ImeMode.Disable;
                else if (c is ComboBox)
                    ((ComboBox)c).DropDownStyle = ComboBoxStyle.DropDownList;
            }
        }



        public void SetDynamicSize()
        {
            if (Screen.PrimaryScreen.Bounds.Width > 1024)
            {
                this.Width = int.Parse(Settings.Default.MAX_WIDTH);
                
            }
        }
    }
}
