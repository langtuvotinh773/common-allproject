﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Customer Transaction Report Screen
 * for CPA module.
 */
using System;
using System.Windows.Forms;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Functions;
namespace Phoenix.Cpa.Gui.Forms
{
    /// <summary>
    /// This form use to export customer transaction report
    /// Phong: in charge at 2/2013
    /// </summary>
	public partial class frmCustomerTransactionsReport : MasterForm
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public frmCustomerTransactionsReport()
		{
			InitializeComponent();
			try
			{ 
				LoadJNJList();
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
			//Yen Phan
			SetFormStyle();
		}
		
		/// <summary>
		/// Load JNJ List
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void LoadJNJList()
		{
			cbbJNJ.DataSource = clsGetDataCombobox.Instance().lstJNJ;
			cbbJNJ.DisplayMember = clsCPAConstant.NAME;
			cbbJNJ.ValueMember = clsCPAConstant.NAME;
			cbbJNJ.DropDownStyle = ComboBoxStyle.DropDownList;
		}

		/// <summary>
		/// Export to Excel
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnExportReport_Click(object sender, EventArgs e)
		{
            try
            {
                if (!CheckMonthYear())
                {
                    clsCommonFunctions.ShowWarningDialog(clsCPACommonMessage.ERROR_INPUT_MONTH_YEAR);
                    return;
                }
                btnExportReport.Enabled = false;
               
                Run();
                Complete();
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
			
		}


        private void Run()
        {
            frmReportForCustomerTransactions frm = new frmReportForCustomerTransactions(clsCommonFunctions.GetMonthYearFromInputToDatabase(txtMonthYear.Text), txtCustomerCode.Text.Trim(), cbbJNJ.SelectedValue.ToString(), txtCustomerFullName.Text.Trim());
            if (frm.Show == true)
                frm.Show();
        }

        private void Complete()
        {
            btnExportReport.Enabled = true;
           
        }
		/// <summary>
		/// Check month year input
		/// </summary>
		/// <returns>bool</returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private bool CheckMonthYear()
		{
			string strMYInput = txtMonthYear.Text;
			if (strMYInput == "")
				return false;
			if (strMYInput.Length < 6)
				return false;

			int iMonth = int.Parse(strMYInput.Substring(0, 2));
			int iYear = int.Parse(strMYInput.Substring(3, 4));
			int iMonthCurr = DateTime.Now.Month;
			int iYearCurr = DateTime.Now.Year;
			if (iYearCurr < iYear)
				return false;
			if (iYear == iYearCurr && iMonthCurr < iMonth)
				return false;
			return true;
		}

		/// <summary>
		/// Close this form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void frmCustomerTransactionsReport_Load(object sender, EventArgs e)
		{

		}
	}
}