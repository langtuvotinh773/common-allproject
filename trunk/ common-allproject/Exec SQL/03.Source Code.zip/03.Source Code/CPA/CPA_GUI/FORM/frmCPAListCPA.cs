﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to defineList CPA Screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Collections;
using Phoenix.Cpa.Bus;
using Config.Classes;
using Phoenix.Cpa.Dto;
using Phoenix.Cpa.Common;
using Phoenix.Common.Functions;

using Phoenix.Common.Popup;
namespace Phoenix.Cpa.Gui.Forms
{
    /// <summary>
    /// This form use to view list CPA
    /// Phong
    /// 01/02/2013 : Create file
    /// </summary>
    public partial class frmCPAListCPA : MasterForm
    {

        #region Variables
        private DataTable dtOldTable;
        private DataTable m_Data;
        private clsListCPABLL m_bll;
        private List<int> iRowChanges = new List<int>();
        private string m_From = "";
        private string m_To = "";
        public static clsCPACustomerDTO UpdatingCPA;
        private int m_CurrentRowIndex = 0;
        private List<DataGridViewRow> rowChanges;
        private bool isTabOnBtnSearch = false; // tab in buttom search or not
        int m_CurRow = 0;//selected row in datagrid
        #endregion
        /// <summary>
        /// contructor and init value on GUI
        /// </summary>
        public frmCPAListCPA() : base()
        {
            InitializeComponent();
            this.Text = clsCPAConstant.FORM_TEXT;
            InitDataGridView();
            m_bll = new clsListCPABLL();
            SetSecurity();
            btnSearch.GotFocus += new EventHandler(btnSearch_GotFocus);
       
            this.Activated += new EventHandler(frmCPAListCPA_Activated);
            this.Deactivate += new EventHandler(frmCPAListCPA_Deactivate);
            monthYearFrom.Focus();
            // add value to combobox

            cbbStatus.DataSource = clsGetDataCombobox.Instance().lstCPAStatus;
            cbbStatus.DisplayMember = clsCPAConstant.NAME;
            cbbStatus.ValueMember = clsCPAConstant.VALUE;
            cbbStatus.DropDownStyle = ComboBoxStyle.DropDownList;

            //dissable update and view button
            toolStripButtonUpdate.Visible = false;
            toolStripButtonView.Visible = false;
            this.SetDynamicSize();
            btnSave.Visible = false;
            
            m_From = DateTime.Now.Month.ToString("00") + "/" + DateTime.Now.Year.ToString();
            m_To = DateTime.Now.Month.ToString("00") + "/" + DateTime.Now.Year.ToString();
            monthYearFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            monthYearTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);



            rowChanges = new List<DataGridViewRow>();
            Search();


			SetFormStyle();
        }


       

        void btnSearch_GotFocus(object sender, EventArgs e)
        {
            isTabOnBtnSearch = true;
        }

        void frmCPAListCPA_Deactivate(object sender, EventArgs e)
        {
            m_CurrentRowIndex = m_CurRow;
        }

        void frmCPAListCPA_Activated(object sender, EventArgs e)
        {
            if (dtgCPAList.Rows.Count > 0)
            {
                dtgCPAList.Rows[m_CurrentRowIndex].Selected = true;
                m_CurRow = m_CurrentRowIndex;
            }
            if (UpdatingCPA != null && dtgCPAList.SelectedRows.Count > 0)
            {
                dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.DEPOSITS].Value = UpdatingCPA.GetDeposit();

                dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.TOTAL_PL].Value = UpdatingCPA.GetTotalProfit();

            }
        }

       

     
        /// <summary>
        /// init layout for datagirdview
        /// </summary>
        private void InitDataGridView()
        {
            dtgCPAList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgCPAList.RowHeadersVisible = false;
            dtgCPAList.GotFocus += new EventHandler(dtgCPAList_GotFocus);
            dtgCPAList.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dtgCPAList.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dtgCPAList.RowStateChanged += new DataGridViewRowStateChangedEventHandler(dtgCPAList_RowStateChanged);
            this.dtgCPAList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dtgCPAList.ColumnHeadersDefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
            dtgCPAList.DefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
            dtgCPAList.EnableHeadersVisualStyles = false;
            DataGridViewCheckBoxColumn check = new DataGridViewCheckBoxColumn();
            check.HeaderText = clsCPAConstant.NOT_SHOW_IN_REPORT;
            check.Name = clsCPAConstant.NOTSHOWREPORT;
            check.DataPropertyName = clsCPAConstant.NOTSHOWREPORT;
            check.Width = 120;
            check.SortMode = DataGridViewColumnSortMode.NotSortable;
            check.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            check.ReadOnly = true;
            check.DefaultCellStyle.BackColor = Color.White;
            
            dtgCPAList.Columns.Add(check);



            DataGridViewTextBoxColumn status = new DataGridViewTextBoxColumn();
            status.HeaderText = clsCPAConstant.STATUS;
            status.DataPropertyName = clsCPAConstant.STATUS;
            status.Name = clsCPAConstant.STATUS;
            status.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            status.ReadOnly = true;
            status.Width = 80;
            
            status.SortMode = DataGridViewColumnSortMode.NotSortable;
            status.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dtgCPAList.Columns.Add(status);

            DataGridViewTextBoxColumn customerCode = new DataGridViewTextBoxColumn();
            customerCode.HeaderText = clsCPAConstant.COL_CUSTOMER_CODE;
            customerCode.ReadOnly = true;
            customerCode.DataPropertyName = clsCPAConstant.CUSTOMERCODE;
            customerCode.Name = clsCPAConstant.CUSTOMERCODE;
            customerCode.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            customerCode.Width = 85;
            customerCode.SortMode = DataGridViewColumnSortMode.NotSortable;
            customerCode.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dtgCPAList.Columns.Add(customerCode);

            DataGridViewColumn customerFullName = new DataGridViewTextBoxColumn();
            customerFullName.HeaderText = clsCPAConstant.R_H_CUSTOMER_FULL_NAME;
            customerFullName.DataPropertyName = clsCPAConstant.CUSFULLNAME;
            customerFullName.Name = clsCPAConstant.CUSFULLNAME;
            customerFullName.ReadOnly = true;
            customerFullName.Width = 200;
            customerFullName.SortMode = DataGridViewColumnSortMode.NotSortable;
            customerFullName.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dtgCPAList.Columns.Add(customerFullName);

            DataGridViewColumn customerShortName = new DataGridViewTextBoxColumn();
            customerShortName.HeaderText = clsCPAConstant.CUSTOMER_SHORT_NAME;
            customerShortName.DataPropertyName = clsCPAConstant.CUSSHORTNAME;
            customerShortName.Name = clsCPAConstant.CUSSHORTNAME;
            customerShortName.ReadOnly = true;
            customerShortName.Width = 160;
            customerShortName.SortMode = DataGridViewColumnSortMode.NotSortable;
            customerShortName.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dtgCPAList.Columns.Add(customerShortName);

            DataGridViewColumn monthYear = new DataGridViewTextBoxColumn();
            monthYear.HeaderText = clsCPAConstant.MONTH_YEAR;
            monthYear.ReadOnly = true;
            monthYear.DataPropertyName = clsCPAConstant.MONTHYEAR;
            monthYear.Name = clsCPAConstant.MONTHYEAR;
            monthYear.Width = 90;
            monthYear.DefaultCellStyle.Format = "MMM yyyy";
            monthYear.SortMode = DataGridViewColumnSortMode.NotSortable;
            monthYear.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            monthYear.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dtgCPAList.Columns.Add(monthYear);

            DataGridViewColumn deposit = new DataGridViewTextBoxColumn();
            deposit.HeaderText = clsCPAConstant.DEPOSITS;
            deposit.Name = clsCPAConstant.DEPOSITS;
            deposit.ReadOnly = true;
            deposit.Width = 90;
            deposit.DataPropertyName = clsCPAConstant.DEPOSIT;
            deposit.DefaultCellStyle.Format = "#,0";
            deposit.SortMode = DataGridViewColumnSortMode.NotSortable;
            deposit.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            deposit.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dtgCPAList.Columns.Add(deposit);

            DataGridViewColumn totalPL = new DataGridViewTextBoxColumn();
            totalPL.ReadOnly = true;
            totalPL.HeaderText = clsCPAConstant.TOTAL_PL;
            totalPL.Name = clsCPAConstant.TOTAL_PL;
            totalPL.DataPropertyName = clsCPAConstant.TOTALPL;
            totalPL.DefaultCellStyle.Format = "#,0";
            totalPL.Width = 90;
            totalPL.SortMode = DataGridViewColumnSortMode.NotSortable;
            totalPL.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            totalPL.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dtgCPAList.Columns.Add(totalPL);

        }





        void dtgCPAList_GotFocus(object sender, EventArgs e)
        {
            try
            {
                if (isTabOnBtnSearch == true)
                {
                    isTabOnBtnSearch = false;
                    dtgCPAList.CurrentCell = dtgCPAList.Rows[0].Cells[0];
                }
            }
            catch (Exception ex)
            {
            }
        }
        /// <summary>
        /// convert from mmyyyy -> yyyymm
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        private string ConvertMonthYearToYearMonth(string input)
        {
            string result = "";
            result = input.Remove(0, 3);
            result += input.Remove(2);
            return result;
        }
        /// <summary>
        /// convert from mmm yyyy -> yyyymm
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        private string GetYearMonthString(string input)
        {
            string result = "";
            result = input.Remove(0, 5);
            switch (input.Remove(3))
            {
                case clsCPAConstant.JAN: result += clsCPAConstant.MONTH_01;
                    break;
                case clsCPAConstant.FEB: result += clsCPAConstant.MONTH_02;
                    break;
                case clsCPAConstant.MAR: result += clsCPAConstant.MONTH_03;
                    break;
                case clsCPAConstant.APR: result += clsCPAConstant.MONTH_04;
                    break;
                case clsCPAConstant.MAY: result += clsCPAConstant.MONTH_05;
                    break;
                case clsCPAConstant.JUN: result += clsCPAConstant.MONTH_06;
                    break;
                case clsCPAConstant.JUL: result += clsCPAConstant.MONTH_07;
                    break;
                case clsCPAConstant.AUG: result += clsCPAConstant.MONTH_08;
                    break;
                case clsCPAConstant.SEP: result += clsCPAConstant.MONTH_09;
                    break;
                case clsCPAConstant.OCT: result += clsCPAConstant.MONTH_10;
                    break;

                case clsCPAConstant.NOV: result += clsCPAConstant.MONTH_11;
                    break;

                case clsCPAConstant.DEC: result += clsCPAConstant.MONTH_12;
                    break;


            }
            return result;
        }




        /// <summary>
        /// click save action
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {        
            try
            {
                if (rowChanges.Count > 0) // have changed value or not
                {

                    frmPhoenixMessage frm= new frmPhoenixMessage((int)CommonValue.MessageType.Confirm,
                                                            COMMON.Properties.Settings.Default.CONF_ACTION,new string[]{clsCPAConstant.ACT_UPDATE,"report status"});
                    if (frm.ShowDialog() == DialogResult.Yes)
                    {

                            SaveData();
                    
                    }
                }
            }
            catch (Exception ex)
            {
                this.ForceClose = true; ;
                try
                {
                    m_bll.RollBack();
                }
                catch(Exception )
                {
                }
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }


        }

        /// <summary>
        /// Save changed data
        /// </summary>
        private void SaveData()
        {

            if (rowChanges.Count > 0)
            {

                m_bll = new clsListCPABLL();
                ArrayList arrLstParams = new ArrayList();
                for (int i = 0; i < rowChanges.Count; i++)
                {

                    arrLstParams.Add(new string[] {((DateTime)rowChanges[i].Cells[clsCPAConstant.MONTHYEAR].Value).ToString("yyyyMM"),
							rowChanges[i].Cells[clsCPAConstant.CUSTOMERCODE].Value.ToString(),
							 ((bool) rowChanges[i].Cells[clsCPAConstant.NOTSHOWREPORT].Value).ToString()});
                    DataRow[] rows = m_Data.Select("CustomerID =" + (string)rowChanges[i].Cells["CustomerID"].Value + " and YearMonth =" + ((DateTime)rowChanges[i].Cells["YearMonth"].Value).ToString("yyyyMM"));
                    rows[0]["ReportStatus"] = rowChanges[i].Cells[clsCPAConstant.NOTSHOWREPORT].Value;
                        
                    //save ok? => save log
                }

                int result = m_bll.UpdateTransaction(arrLstParams);
                if (result >= 1)
                {
                    

                    //save  history
                 //   clsSaveLog.Save(history);
                    m_bll.Commit();
                    dtOldTable = m_Data;
                    iRowChanges.Clear();
                    btnSave.Visible = false;
                    rowChanges.Clear();
                    clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, COMMON.Properties.Settings.Default.INFO_ACTION_SUCCESS, new string[] { clsCPAConstant.ACT_UPDATING, "report status" });
                }
                else
                {
                    try
                    {
                        m_bll.RollBack();
                    }
                    catch (Exception)
                    {
                    }
                    clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, COMMON.Properties.Settings.Default.INFO_ACTION_FAIL, new string[] { clsCPAConstant.SAVE_ACTION, "report status" });
                }
              }


        }
        /// <summary>
        /// Search action click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            btnSave.Visible = false;
            try
            {
                m_From = monthYearFrom.Text;
                m_To = monthYearTo.Text;
                rowChanges.Clear();
                Search();
                if (m_Data.Rows.Count != 0 && this.Visible == true)
                {
                    List<string> cpas = clsFinalizeCPABus.CheckLackingCPA(clsCommonFunctions.GetMonthYearFromInputToDatabase(m_From), clsCommonFunctions.GetMonthYearFromInputToDatabase(m_To));
                    if (cpas.Count > 0)
                        clsMesageCollection.ShowCPANotImportYet(cpas);
                }
            }
            catch (Exception ex)
            {
                this.ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
        }
        /// <summary>
        /// Search data by condition on UI
        /// </summary>
        private void Search()
        {
            //clear data in datagrid
            dtgCPAList.Rows.Clear();
            //clear all row changed value before
            iRowChanges.Clear();
            // parce month year to string

            string from = clsCommonFunctions.GetMonthYearFromInputToDatabase(m_From);

            string to = clsCommonFunctions.GetMonthYearFromInputToDatabase(m_To);

            //get data table
            m_bll = new clsListCPABLL();
            m_Data = m_bll.GetTransactionData(from, to, tbCustomerCode.Text, tbCustomerFullName.Text, tbCustomerShortName.Text, (string)cbbStatus.SelectedValue);

        
            List<clsCPACustomerDTO> lstData = new List<clsCPACustomerDTO>();
            for (int i = 0; i < m_Data.Rows.Count; i++)
            {
                lstData.Add(new clsCPACustomerDTO(m_Data.Rows[i]));
            }

            //  dtgCPAList.DataSource = m_Data;
            if (m_Data.Rows.Count == 0 && this.Visible == true) clsMesageCollection.MessageNoTransactions();

            for (int i = 0; i < lstData.Count; i++)
            {
                string cpaStatus = "";
                if (lstData[i].CPAStatus == 1) cpaStatus = clsCPACommonMessage.STATUS_FINALIZE;
                else cpaStatus = clsCPACommonMessage.STATUS_NOTFINALIZE;
                dtgCPAList.Rows.Add(lstData[i].ReportStatus, cpaStatus, lstData[i].CustomerID, lstData[i].CustomerName, lstData[i].ShortName, new DateTime(int.Parse(lstData[i].YearMonth.Remove(4)),int.Parse(lstData[i].YearMonth.Remove(0,4)),1),
                    lstData[i].GetDeposit(), lstData[i].GetTotalProfit());
                //dtgCPAList.Rows[i].Cells[MONTHYEAR].Value = clsCommonFunctions.GetMonthYearShowOnDataGrid((string)dtgCPAList.Rows[i].Cells[MONTHYEAR].Value);

            }


            dtOldTable = m_Data.Copy();
            dtgCPAList.AllowUserToAddRows = false;
            //}
        }
        /// <summary>
        /// collect changed data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgCPAList_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                DataRow[] rows = m_Data.Select("CustomerID =" + (string)dtgCPAList.Rows[e.RowIndex].Cells["CustomerID"].Value + "and YearMonth =" + ((DateTime)dtgCPAList.Rows[e.RowIndex].Cells["YearMonth"].Value).ToString("yyyyMM"));
                
                if ((bool)dtgCPAList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != (bool)rows[0]["ReportStatus"])
                {
                    iRowChanges.Add(e.RowIndex);
                    rowChanges.Add(dtgCPAList.Rows[e.RowIndex]);
                    
                }
                else
                {
                    if (iRowChanges.Contains(e.RowIndex))
                        iRowChanges.Remove(e.RowIndex);
                    if(rowChanges.Contains(dtgCPAList.Rows[e.RowIndex]))
                    {
                        rowChanges.Remove(dtgCPAList.Rows[e.RowIndex]);
                    }
                }

            }
            if (iRowChanges.Count > 0)
                btnSave.Visible = true;
            else
                btnSave.Visible = false;
        }

        /// <summary>
        /// form close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {

            this.Close();
        }
        /// <summary>
        /// open view screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButtonView_Click(object sender, EventArgs e)
        {
            try
            {

                if (dtgCPAList.SelectedRows.Count > 0)
                {

                    frmViewCustomerTransaction frm = new frmViewCustomerTransaction(dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.CUSTOMERCODE].Value.ToString(),
                            dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.CUSFULLNAME].Value.ToString(),
                            ((DateTime)dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.MONTHYEAR].Value).ToString("yyyyMM"));

                    frm.ShowDialog();

                }
            }
            catch (Exception ex)
            {
                this.ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
        }
        /// <summary>
        /// open update screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButtonUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgCPAList.SelectedRows.Count > 0)
                {
                    m_CurrentRowIndex = m_CurRow;
                    string[] searchConditions = new string[3];
                    searchConditions[0] = dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.CUSTOMERCODE].Value.ToString();
                    searchConditions[1] = dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.CUSFULLNAME].Value.ToString();
                    searchConditions[2] = ((DateTime)dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.MONTHYEAR].Value).ToString("yyyyMM");
                    frmUpdateCustomerTransaction frm = new frmUpdateCustomerTransaction(searchConditions);
                    frm.MdiParent = this.MdiParent;
                    frm.Show();
                }
            }
            catch (Exception ex)
            {
                this.ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }

        }
        /// <summary>
        /// enable or disable button view and update base on data selected in datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void dtgCPAList_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            if (dtgCPAList.SelectedRows.Count == 1)
            {
                if ((string)dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.STATUS].Value != clsCPACommonMessage.STATUS_FINALIZE && (string)dtgCPAList.SelectedRows[0].Cells[clsCPAConstant.STATUS].Value != "1")
                    toolStripButtonUpdate.Visible = true;
                else
                    toolStripButtonView.Visible = true;
            }
            else
            {
                toolStripButtonUpdate.Visible = false;
                toolStripButtonView.Visible = false;
            }


        }
        /// <summary>
        /// elect a row when click a cell
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgCPAList_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.RowIndex == -1 && e.ColumnIndex != -1)
            {
                
                dtgCPAList.Columns[e.ColumnIndex].SortMode = DataGridViewColumnSortMode.Automatic;
                for (int i = 0; i < dtgCPAList.Columns.Count; i++)
                {
                    if (i != e.ColumnIndex)
                    {
                        dtgCPAList.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                }
            }

        }
        /// <summary>
        /// select a row when click a cell
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgCPAList_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
                dtgCPAList.Rows[e.RowIndex].Selected = true;
            
        }
        /// <summary>
        /// check save data before form closing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmCPAListCPA_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (ForceClose == false)
            {
                if (iRowChanges.Count > 0)
                {

                    DialogResult result = clsCommonFunctions.ShowYesNoCancelDialog(clsCPACommonMessage.DO_YOU_WANT_SAVE);
                    if (result == DialogResult.Yes)
                    {
                        try
                        {
                            SaveData();
                        }
                        catch (Exception ex)
                        {
                            clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
                        }
                    }
                    if (result == DialogResult.Cancel)
                    {
                        e.Cancel = true;

                    }

                }
            }
        }


        /// <summary>
        /// click in cell content
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgCPAList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 && e.RowIndex != -1)
            {
                dtgCPAList.Rows[e.RowIndex].Cells[0].Value = !(bool)dtgCPAList.Rows[e.RowIndex].Cells[0].Value;
            }
        }


        /// <summary>
        /// get index of row when enter to a row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void dtgCPAList_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            m_CurRow = e.RowIndex;
        }


        /// <summary>
        /// key down on datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgCPAList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 9) // tab
            {
                if (dtgCPAList.Rows.Count > m_CurRow + 1)
                {
                    m_CurRow = m_CurRow + 1;
                    dtgCPAList.CurrentCell = dtgCPAList.Rows[m_CurRow].Cells[0];
                    dtgCPAList.Rows[m_CurRow].Selected = true;
                }
                if (m_CurRow == dtgCPAList.Rows.Count - 1)
                {
                    btnClose.Focus();
                }
            }
            if (e.KeyValue == 32) //space
            {
                if (dtgCPAList.SelectedRows.Count > 0)
                {
                    for (int i = 0; i < dtgCPAList.SelectedRows.Count; i++)
                    {
                        if (!(dtgCPAList.SelectedRows[i].Cells[0].RowIndex == dtgCPAList.CurrentCell.RowIndex && dtgCPAList.CurrentCell.ColumnIndex == 0))
                            dtgCPAList.SelectedRows[i].Cells[0].Value = !(bool)dtgCPAList.SelectedRows[dtgCPAList.SelectedRows.Count - 1].Cells[0].Value;
                        if (dtgCPAList.CurrentCell.ColumnIndex == 0)
                        {
                            if (!(dtgCPAList.SelectedRows[i].Cells[0].RowIndex == dtgCPAList.CurrentCell.RowIndex && dtgCPAList.CurrentCell.ColumnIndex == 0))
                            dtgCPAList.SelectedRows[i].Cells[0].Value = !(bool)dtgCPAList.SelectedRows[0].Cells[0].Value;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// proccess key event
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Alt | Keys.U))
            {
                if (toolStripButtonUpdate.Visible == true)
                {

                    toolStripButtonUpdate_Click(new object(), new EventArgs());
                }
                
            }
            if(keyData == (Keys.Alt | Keys.S))
            {
                if(btnSave.Visible == true)
                    btnSave_Click(new object(), new EventArgs());
            }
            if (keyData == (Keys.Alt | Keys.V))
            {
                if (toolStripButtonView.Visible == true)
                {
                    toolStripButtonView_Click(new object(), new EventArgs());
                }

            }
            return base.ProcessCmdKey(ref msg, keyData);
        }





    }
}