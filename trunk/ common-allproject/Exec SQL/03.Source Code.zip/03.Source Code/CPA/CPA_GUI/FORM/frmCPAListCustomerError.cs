﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to defineList Customer Error Screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms; 
using System.Collections;
using Phoenix.Cpa.Bus; 
using Phoenix.Cpa.Dto;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Functions;
namespace Phoenix.Cpa.Gui.Forms
{
    /// <summary>
    /// This form use to view customer error
    /// Phong: in charge at 2/2013
    /// </summary>
	public partial class frmListCustomerError : MasterForm
	{
		clsCustomerErrorBus m_CusBus = null;
		string m_MonthYearCond = "";
		string m_ErrTypeCond = "";
		CheckBox m_CheckBoxHeader;
		private bool m_CheckAll = false;
		string m_AppName = clsCPAConstant.LIST_CUSTOMER_ERROR;
        string m_UserName = clsUserInfo.UserNo.ToString();
		int m_selectedrowIndex = 0;
		int m_selectedcolumnIndex = 0;
		private List<clsCPACustomerErrorDTO> m_lstData;
        private bool isClickByCheckBoxHeader = false;
        private bool isClickbyCell = false;
		private List<int> lstSelectionIndex;
        private List<string> m_IdErrors;
        DataTable m_datas;
        List<DataGridViewRow> rowsChange;

		public frmListCustomerError(string yearMonth, List<string> idError)
		{
			InitializeComponent();
            SetSecurity();

			lstSelectionIndex = new List<int>();
			m_lstData = new List<clsCPACustomerErrorDTO>();
            rowsChange = new List<DataGridViewRow>();
			try
			{
				m_CusBus = new clsCustomerErrorBus();
				LoadErrorTypeList();
				LoadMonthYearList();
                m_IdErrors = idError;
				cbbMonthYear.SelectedValue = yearMonth;
                SearchErrCus(m_IdErrors);
                SetFormStyle();
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

		/// <summary>
		/// Load Form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void frmListCustomerError_Load(object sender, EventArgs e)
		{
			try
			{

				Rectangle rect = this.dtgCustomerErrorList.GetCellDisplayRectangle(0, -1, true);
				m_CheckBoxHeader = new CheckBox();
				m_CheckBoxHeader.BackColor = Color.Transparent;
				m_CheckBoxHeader.Size = new Size(18, 18);
				// Change the location of the CheckBox to make it stay on the header

				m_CheckBoxHeader.Location = new Point(rect.Right / 2 - 5, rect.Top / 2 + 3);
				m_CheckBoxHeader.CheckedChanged += new EventHandler(ckBox_CheckedChanged);
				//Add the CheckBox into the DataGridView

				this.dtgCustomerErrorList.Controls.Add(m_CheckBoxHeader);
				dtgCustomerErrorList.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
				dtgCustomerErrorList.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
				//format datagridview
				dtgCustomerErrorList.ColumnHeadersDefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
				//dtgCustomerErrorList.DefaultCellStyle.SelectionBackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
				//dtgCustomerErrorList.DefaultCellStyle.SelectionForeColor = Color.Black;
				dtgCustomerErrorList.DefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
				dtgCustomerErrorList.EnableHeadersVisualStyles = false;
				dtgCustomerErrorList.Columns[2].Width = 140;
				dtgCustomerErrorList.Columns[0].DefaultCellStyle.SelectionBackColor = Color.SteelBlue;
				dtgCustomerErrorList.Columns[0].DefaultCellStyle.BackColor = Color.White;
                dtgCustomerErrorList.GotFocus += new EventHandler(dtgCustomerErrorList_GotFocus);
                dtgCustomerErrorList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

				
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

        void dtgCustomerErrorList_GotFocus(object sender, EventArgs e)
        {
            try
            {
                dtgCustomerErrorList.CurrentCell = dtgCustomerErrorList.Rows[0].Cells[0];
            }
            catch (Exception ex)
            {
            }
        }

		/// <summary>
		/// Load Year Month list
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void LoadMonthYearList()
		{
			try
			{
				cbbMonthYear.DataSource = null;
				cbbMonthYear.Items.Clear();
				ArrayList arrMonthYear = m_CusBus.GetMonthYearList();
				if (arrMonthYear.Count == 0)
					return;
				cbbMonthYear.DataSource = arrMonthYear;
				cbbMonthYear.DisplayMember = clsCPAConstant.DISPLAY;
				cbbMonthYear.ValueMember = clsCPAConstant.VALUE;
				cbbMonthYear.DropDownStyle = ComboBoxStyle.DropDownList;
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

		/// <summary>
		/// Load Error Type list
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void LoadErrorTypeList()
		{
			try
			{
				cbbErrorType.DataSource = clsGetDataCombobox.Instance().LstErrorType;
				cbbErrorType.DisplayMember = clsCPAConstant.VALUE;
				cbbErrorType.ValueMember = clsCPAConstant.VALUE;
				cbbErrorType.DropDownStyle = ComboBoxStyle.DropDownList;
			}
			catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

		/// <summary>
		/// Delete error customer
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void deleteErrCus()
		{

            m_CusBus = new clsCustomerErrorBus();
				List<clsCPACustomerErrorDTO> lstError = new List<clsCPACustomerErrorDTO>();
                for (int i = 0; i < rowsChange.Count; i++)
				{

					clsCPACustomerErrorDTO temp = new clsCPACustomerErrorDTO();
                    temp.YearMonth = ((DateTime)rowsChange[i].Cells["clMonthYear"].Value).ToString("yyyyMM");
                    temp.CustomerID = rowsChange[i].Cells["clCustomerCode"].Value.ToString();
					lstError.Add(temp);
				}
				int intResult = m_CusBus.DeleteCustomerError(lstError);
                if (intResult >= 1)
                {
                   
                    m_CusBus.Commit();
                    clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, COMMON.Properties.Settings.Default.INFO_ACTION_SUCCESS, new string[] { clsCPAConstant.ACT_DELETING, "customer errors" });
                    lstSelectionIndex.Clear();
                    rowsChange.Clear();
                    m_CheckBoxHeader.Checked = false;
                    SearchErrCus(m_IdErrors);
                }
                else
                {
                    clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, COMMON.Properties.Settings.Default.INFO_ACTION_FAIL, new string[] { clsCPAConstant.ACT_DELETING, "customer errors" });
                }

			
		}

		
		

		/// <summary>
		/// Search error customer
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond

		private void SearchErrCus(List<string> idError)
		{
           
			
				dtgCustomerErrorList.Rows.Clear();

				if (cbbMonthYear.SelectedItem == null)
					m_MonthYearCond = "";
				else
					m_MonthYearCond = cbbMonthYear.SelectedValue.ToString();

				if (cbbErrorType.SelectedItem == null)
					m_ErrTypeCond = "";
				else
					m_ErrTypeCond = cbbErrorType.SelectedValue.ToString();
                m_CusBus = new clsCustomerErrorBus();
				m_datas = m_CusBus.GetListCustomerError(m_MonthYearCond, m_ErrTypeCond);
				List<clsCPACustomerErrorDTO> lst = new List<clsCPACustomerErrorDTO>();
                for (int i = 0; i < m_datas.Rows.Count; i++)
				{
                    lst.Add(new clsCPACustomerErrorDTO(m_datas.Rows[i]));
				}
				m_lstData = lst;
				if (idError.Count == 0)
				{
					for (int i = 0; i < lst.Count; i++)
					{

						dtgCustomerErrorList.Rows.Add(false, lst[i].CustomerID, lst[i].CustomerName,
						new DateTime(int.Parse(lst[i].YearMonth.Remove(4)),int.Parse(lst[i].YearMonth.Remove(0,4)),1), lst[i].ErrorType, lst[i].OfficerID, lst[i].CreatedBy);
					}
				}
				else
				{

					for (int i = 0; i < lst.Count; i++)
					{

						if (idError.Contains(lst[i].CustomerID))
						{
							idError.Remove(lst[i].CustomerID);
							dtgCustomerErrorList.Rows.Add(false, lst[i].CustomerID, lst[i].CustomerName,
						clsCommonFunctions.GetMonthYearShowOnDataGrid(lst[i].YearMonth), lst[i].ErrorType, lst[i].OfficerID, lst[i].CreatedBy);
						}
					}
				}
                if (lst.Count == 0 && this.Visible == true) clsMesageCollection.MessageNoTransactions();

			
		}


		/// <summary>
		/// Convert month value from combobox to datagridview
		/// </summary>
		/// <param name="strMonthYearNumber"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private string convertMonthYearText(string strMonthYearNumber)//11/2012
		{
			string strResult = "";
			
				if (strMonthYearNumber != "")
				{
					string strMonthName = "";
					int iMonthCount = strMonthYearNumber.Length - 4;
					string month = "";
					string year = "";
					if (strMonthYearNumber.Length == 5)
					{
						month = strMonthYearNumber[0].ToString();
						year = strMonthYearNumber.Substring(1, 4);
					}
					if (strMonthYearNumber.Length == 6)
					{
						month = strMonthYearNumber[0].ToString() + strMonthYearNumber[1].ToString();
						year = strMonthYearNumber.Substring(2, 4);
					}
					switch (int.Parse(month))
					{
						case 1: strMonthName = clsCPAConstant.JAN; break;
						case 2: strMonthName = clsCPAConstant.FEB; break;
						case 3: strMonthName = clsCPAConstant.MAR; break;
						case 4: strMonthName = clsCPAConstant.APR; break;
						case 5: strMonthName = clsCPAConstant.MAY; break;
						case 6: strMonthName = clsCPAConstant.JUN; break;
						case 7: strMonthName = clsCPAConstant.JUL; break;
						case 8: strMonthName = clsCPAConstant.AUG; break;
						case 9: strMonthName = clsCPAConstant.SEP; break;
						case 10: strMonthName = clsCPAConstant.OCT; break;
						case 11: strMonthName = clsCPAConstant.NOV; break;
						case 12: strMonthName = clsCPAConstant.DEC; break;
						default: break;
					}
					strResult = strMonthName + " " + year;
				}
			
			return strResult;
		}

		/// <summary>
		/// Convert month value from datagridview to number
		/// </summary>
		/// <param name="strMonthYearNumber"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private string convertMonthYearToCode(string strMonthYearNumber)//Nov 2012
		{
			string strResult = "";
			
				if (strMonthYearNumber != "")
				{
					string strMonthName = "";
					int monthCount = strMonthYearNumber.Length - 4;
					string month = "";
					string strYear = "";
					if (strMonthYearNumber.Length > 4)
					{
						month = strMonthYearNumber.Substring(0, 3);
						strYear = strMonthYearNumber.Substring(4, 4);
					}
					switch (month)
					{
						case clsCPAConstant.JAN: strMonthName = clsCPAConstant.MONTH_01; break;
						case clsCPAConstant.FEB: strMonthName = clsCPAConstant.MONTH_02; break;
						case clsCPAConstant.MAR: strMonthName = clsCPAConstant.MONTH_03; break;
						case clsCPAConstant.APR: strMonthName = clsCPAConstant.MONTH_04; break;
						case clsCPAConstant.MAY: strMonthName = clsCPAConstant.MONTH_05; break;
						case clsCPAConstant.JUN: strMonthName = clsCPAConstant.MONTH_06; break;
						case clsCPAConstant.JUL: strMonthName = clsCPAConstant.MONTH_07; break;
						case clsCPAConstant.AUG: strMonthName = clsCPAConstant.MONTH_08; break;
						case clsCPAConstant.SEP: strMonthName = clsCPAConstant.MONTH_09; break;
						case clsCPAConstant.OCT: strMonthName = clsCPAConstant.MONTH_10; break;
						case clsCPAConstant.NOV: strMonthName = clsCPAConstant.MONTH_11; break;
						case clsCPAConstant.DEC: strMonthName = clsCPAConstant.MONTH_12; break;
						default: break;
					}
					strResult = strMonthName + "" + strYear;
				}
			
			return strResult;
		}

		/// <summary>
		/// ckBox_CheckedChanged
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		void ckBox_CheckedChanged(object sender, EventArgs e)
		{
            if (isClickbyCell == false)
            {
                isClickByCheckBoxHeader = true;
                m_CheckAll = !m_CheckAll;
                for (int i = 0; i < this.dtgCustomerErrorList.RowCount; i++)
                {
                    this.dtgCustomerErrorList[0, i].Value = m_CheckAll;
                    if(!rowsChange.Contains(dtgCustomerErrorList.Rows[i]))
                    {
                        rowsChange.Add(dtgCustomerErrorList.Rows[i]);
                    }
                }
                if (m_CheckAll == false)
                {

                    lstSelectionIndex.Clear();
                    rowsChange.Clear();
                }
                else
                {
                    lstSelectionIndex.Clear();
                    for (int i = 0; i < this.dtgCustomerErrorList.RowCount; i++)
                        lstSelectionIndex.Add(i);
                }
                isClickByCheckBoxHeader = false;
            }
		}

		/// <summary>
		/// btnDelete_Click
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnDelete_Click(object sender, EventArgs e)
		{
			try
			{
				if (rowsChange.Count > 0)
				{
                    
                    
                    DialogResult dlgResult = clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                                                          COMMON.Properties.Settings.Default.CONF_ACTION, new string[] { clsCPAConstant.ACT_DELETE, "customer errors" });
					if (dlgResult == DialogResult.No || dlgResult == DialogResult.Cancel)
						return;
					else
					{
						deleteErrCus();
					}
				}
				else
				{
                    clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsCPACommonMessage.SELECT_LEAST_ONE_TO_DELETE);
				}
			}
            catch (Exception ex)
            {
                ForceClose = true;
                try
                {
                    m_CusBus.RollBack();
                }
                catch(Exception )
                {
                }
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
             clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

		/// <summary>
		/// btnSearch_Click
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnSearch_Click(object sender, EventArgs e)
        {
            
            m_CheckBoxHeader.Checked = false;
            try
            {
                rowsChange.Clear();
                SearchErrCus(m_IdErrors);
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
            }
		}

		/// <summary>
		/// dtgCustomerErrorList_CellMouseClick
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void dtgCustomerErrorList_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{

			if (e.ColumnIndex == 0 && e.RowIndex >= 0)
			{
				if ((bool) dtgCustomerErrorList[0, e.RowIndex].Value == true)
					dtgCustomerErrorList[0, e.RowIndex].Value = false;
				else
					dtgCustomerErrorList[0, e.RowIndex].Value = true;
			}

		}





		/// <summary>
		/// Change value of the checkbox when tab on this header row by space bar
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void dtgCustomerErrorList_KeyDown(object sender, KeyEventArgs e)
		{
            if (e.KeyValue == 9)
            {
                
               // if (mRowCur == dtgCustomerErrorList.Rows.Count - 1) mRowCur = 0;
                if (dtgCustomerErrorList.Rows.Count > mRowCur + 1)
                {
                    dtgCustomerErrorList.CurrentCell = dtgCustomerErrorList.Rows[mRowCur].Cells[6];
                    dtgCustomerErrorList.Rows[mRowCur].Selected = true;
                }
                if (mRowCur == dtgCustomerErrorList.Rows.Count - 1)
                {
                    btnDelete.Focus();
                    
                }
            }
			try
			{
				if (e.KeyCode == Keys.Space && m_selectedrowIndex >= 0 && m_selectedcolumnIndex == 0)
					dtgCustomerErrorList[m_selectedcolumnIndex, m_selectedrowIndex].Value = !(bool.Parse(dtgCustomerErrorList[m_selectedcolumnIndex, m_selectedrowIndex].Value.ToString()));
			}
			catch (Exception ex) {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                 Environment.NewLine +
                 ex.TargetSite,this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
		}

		/// <summary>
		/// dtgCustomerErrorList_CellEnter
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void dtgCustomerErrorList_CellEnter(object sender, DataGridViewCellEventArgs e)
		{
			m_selectedcolumnIndex = e.ColumnIndex;
			m_selectedrowIndex = e.RowIndex;
		}

		/// <summary>
		/// Close this form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}


		private void dtgCustomerErrorList_CellValueChanged(object sender, DataGridViewCellEventArgs e)
		{
            isClickbyCell = true;
            if (isClickByCheckBoxHeader == false)
            {
                if (e.ColumnIndex == 0)
                {
                    
                    if ((bool)dtgCustomerErrorList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value == true)
                    {
                        lstSelectionIndex.Add(e.RowIndex);
                        rowsChange.Add(dtgCustomerErrorList.Rows[e.RowIndex]);
                    }
                    else
                    {
                        if (lstSelectionIndex.Contains(e.RowIndex)) lstSelectionIndex.Remove(e.RowIndex);
                        if (rowsChange.Contains(dtgCustomerErrorList.Rows[e.RowIndex]))
                            rowsChange.Remove(dtgCustomerErrorList.Rows[e.RowIndex]);
                    }
                    if (lstSelectionIndex.Count == m_lstData.Count)
                    {
                        m_CheckBoxHeader.Checked = true;
                        m_CheckAll = true;
                    }
                    else
                    {
                        m_CheckBoxHeader.Checked = false;
                        m_CheckAll = false;
                    }
                }
            }
            isClickbyCell = false;
		}

		private void frmListCustomerError_FormClosing(object sender, FormClosingEventArgs e)
		{
            if (ForceClose == false)
            {
                if (lstSelectionIndex.Count > 0)
                {
                   
                    DialogResult dlgResult = clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsCPACommonMessage.DO_YOU_WANT_TO_DELETE);
                    if (dlgResult == DialogResult.Yes)
                    {
                        deleteErrCus();
                    }
                    if (dlgResult == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                    }
                }
            }
		}
        int mRowCur = 0;
        private void dtgCustomerErrorList_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            mRowCur = e.RowIndex;
        }

        private void dtgCustomerErrorList_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex == -1 && e.ColumnIndex != -1)
            {
                if (e.ColumnIndex != 0)
                    dtgCustomerErrorList.Columns[e.ColumnIndex].SortMode = DataGridViewColumnSortMode.Automatic;
                for (int i = 0; i < dtgCustomerErrorList.Columns.Count; i++)
                {
                    if (i != e.ColumnIndex)
                    {
                        dtgCustomerErrorList.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                }
            }
        }

       
	}
}