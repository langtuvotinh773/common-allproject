﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Profiability Report
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using CrystalDecisions.Shared;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Common;
using CPA.CPA_GUI.REPORT;
using System.Windows.Forms;
namespace Phoenix.Cpa.Gui.Forms
{

    /// <summary>
    /// Phong: Create at 2/2013
    /// </summary>
    public partial class frmReportForACustomer : MasterForm
    {
        public bool Show = true; //has data or not


        /// <summary>
        /// load data to report
        /// </summary>
        /// <param name="yearmonth"></param>
        /// <param name="customerCode"></param>
        /// <param name="customerName"></param>
        public frmReportForACustomer(string yearmonth, string customerCode, string customerName)
        {
            InitializeComponent();
            //Yen Phan
        
            this.Text = clsCPAConstant.REPORT_FOR_A_CUSTOMER;
            DataSetOfReportCustomer dataset = new DataSetOfReportCustomer();

            ParameterFields myParams = new ParameterFields();
            ParameterField myParam1 = new ParameterField();
            ParameterField myParam2 = new ParameterField();
            ParameterField myParam3 = new ParameterField();
            ParameterDiscreteValue myDiscreteValue1 = new ParameterDiscreteValue();

            // Set the ParameterFieldName to the name of the parameter
            // created in the Field Explorer
            myParam1.ParameterFieldName = clsCPAConstant.REPORT_FOR_A_CUSTOMER_PARAM_NAME_CONST1;
            myDiscreteValue1.Value = 365 * 3;
            myParam1.CurrentValues.Add(myDiscreteValue1);
            myParams.Add(myParam1);

            // Set the ParameterFieldName to the name of the parameter
            // created in the Field Explorer
            ParameterDiscreteValue myDiscreteValue2 = new ParameterDiscreteValue();
            myParam2.ParameterFieldName = clsCPAConstant.REPORT_FOR_A_CUSTOMER_PARAM_NAME_CONST2;
            myDiscreteValue2.Value = 920; //orther quaters
            if (yearmonth.Remove(0, 4) == "03")  // quater 1
                myDiscreteValue2.Value = 900;
            if (yearmonth.Remove(0, 4) == "06") // quater 2
                myDiscreteValue2.Value = 910;
            myParam2.CurrentValues.Add(myDiscreteValue2);
            myParams.Add(myParam2);



            // Set the ParameterFieldName to the name of the parameter
            // created in the Field Explorer
            ParameterDiscreteValue myDiscreteValue3 = new ParameterDiscreteValue();
            myParam3.ParameterFieldName = clsCPAConstant.REPORT_FOR_A_CUSTOMER_PARAM_NAME_CONST3;
            myDiscreteValue3.Value = 10;
            myParam3.CurrentValues.Add(myDiscreteValue3);
            myParams.Add(myParam3);





            // Set the ParameterFieldName to the name of the parameter
            // created in the Field Explorer
            ParameterDiscreteValue myDiscreteValue6 = new ParameterDiscreteValue();
            ParameterField myParam6 = new ParameterField();
            int quarter = (int.Parse(yearmonth.Remove(0, 4)) - 1) / 3 + 1;
            string quaterString = "";
            switch (quarter)
            {
                case 1: quaterString = clsCPAConstant.QUATER_STRING_01; break;
                case 2: quaterString = clsCPAConstant.QUATER_STRING_02; break;
                case 3: quaterString = clsCPAConstant.QUATER_STRING_03; break;
                case 4: quaterString = clsCPAConstant.QUATER_STRING_04; break;
            }
            quaterString += yearmonth.Remove(4);

            //name report
            myParam6.ParameterFieldName = clsCPAConstant.REPORT_FOR_A_CUSTOMER_PARAM_NAME_CONST6;
            myDiscreteValue6.Value = clsCPAConstant.REPORT_FOR_A_CUSTOMER_PARAM_NAME_06 + quaterString;
            myParam6.CurrentValues.Add(myDiscreteValue6);
            myParams.Add(myParam6);

            // Assign the params collection to the report viewer
            crystalReportViewer1.ParameterFieldInfo = myParams;


            clsReportBLL bll = new clsReportBLL();
            List<int> indexs = new List<int>();
            int index = 0;
            string currentID = "";
            DataTable data = bll.GetListCPAinQuarter(yearmonth, customerCode, customerName);
           
            DataTable dataFormat = data.Clone();

            if (data.Rows.Count > 0)
            {
                for (int j = 2; j < 68; j++)
                {
                    dataFormat.Columns[j].DataType = typeof(double);
                }
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    if ((bool)data.Rows[i]["ReportStatus"] == false && (byte)data.Rows[i]["CPA_Status"] == 1)//only import CPA show in report and finalized
                        dataFormat.ImportRow(data.Rows[i]);
                }
                dataFormat.Rows.Add();


                for (int i = 0; i < dataFormat.Rows.Count - 1; i++)
                {

                    if ((string)dataFormat.Rows[i]["CustomerID"] == currentID) // sum value of one customer in to 1 row (1st row of this customer in list)
                    {
                        for (int j = 2; j < 68; j++)
                        {
                            if (dataFormat.Rows[i][j].GetType() == typeof(DBNull))
                                dataFormat.Rows[i][j] = 0;
                            dataFormat.Rows[index][j] = (double)dataFormat.Rows[index][j] + (double)dataFormat.Rows[i][j];
                        }
                    }
                    else
                    {
                        currentID = (string)dataFormat.Rows[i]["CustomerID"];
                        indexs.Add(i);//store index of row which value =  sum of all row of 1 customer
                        index = i;
                        for (int j = 2; j < 68; j++)
                        {
                            if (dataFormat.Rows[i][j].GetType() == typeof(DBNull))
                                dataFormat.Rows[i][j] = 0;

                        }
                    }
                }



                for (int i = 0; i < indexs.Count; i++) // loop indexs list( list store all index of "Sum Row"
                {

                    for (int j = 2; j < 68; j++)
                    {
                        dataFormat.Rows[indexs[i]][j] = (double)dataFormat.Rows[indexs[i]][j] / 3; // average value
                        dataFormat.Rows[indexs[i]][j] = Math.Round((double)dataFormat.Rows[indexs[i]][j], 0);//rounding value
                    }
                    //add to dataset
                    dataset.DataTable1.Rows.Add((double)dataFormat.Rows[i][2],
                        (double)dataFormat.Rows[indexs[i]][3],
                        (double)dataFormat.Rows[indexs[i]][4],
                        (double)dataFormat.Rows[indexs[i]][5], (double)dataFormat.Rows[indexs[i]][6],
                       (double)dataFormat.Rows[indexs[i]][7], (double)dataFormat.Rows[indexs[i]][8],
                        (double)dataFormat.Rows[indexs[i]][9], (double)dataFormat.Rows[indexs[i]][10], (double)dataFormat.Rows[indexs[i]][11],
             (double)dataFormat.Rows[indexs[i]][12], (double)dataFormat.Rows[indexs[i]][13],
              (double)dataFormat.Rows[indexs[i]][14], (double)dataFormat.Rows[indexs[i]][15],
              (double)dataFormat.Rows[indexs[i]][16], (double)dataFormat.Rows[indexs[i]][17],
             (double)dataFormat.Rows[indexs[i]][18], (double)dataFormat.Rows[indexs[i]][19],
              (double)dataFormat.Rows[indexs[i]][20], (double)dataFormat.Rows[indexs[i]][21],
              (double)dataFormat.Rows[indexs[i]][22], (double)dataFormat.Rows[indexs[i]][23],
              (double)dataFormat.Rows[indexs[i]][24], (double)dataFormat.Rows[indexs[i]][25],
             (double)dataFormat.Rows[indexs[i]][26], (double)dataFormat.Rows[indexs[i]][27],
              (double)dataFormat.Rows[indexs[i]][28], (double)dataFormat.Rows[indexs[i]][29],
              (double)dataFormat.Rows[indexs[i]][30], (double)dataFormat.Rows[indexs[i]][31],
              (double)dataFormat.Rows[indexs[i]][32], (double)dataFormat.Rows[indexs[i]][33],
              (double)dataFormat.Rows[indexs[i]][34], (double)dataFormat.Rows[indexs[i]][35],
             (double)dataFormat.Rows[indexs[i]][36], (double)dataFormat.Rows[indexs[i]][37],
              (double)dataFormat.Rows[indexs[i]][38], (double)dataFormat.Rows[indexs[i]][39],
              (double)dataFormat.Rows[indexs[i]][40], (double)dataFormat.Rows[indexs[i]][41],
              (double)dataFormat.Rows[indexs[i]][42], (double)dataFormat.Rows[indexs[i]][43],
              (double)dataFormat.Rows[indexs[i]][44], (double)dataFormat.Rows[indexs[i]][45],
              (double)dataFormat.Rows[indexs[i]][46], (double)dataFormat.Rows[indexs[i]][47],
              (double)dataFormat.Rows[indexs[i]][48], (double)dataFormat.Rows[indexs[i]][49],
              (double)dataFormat.Rows[indexs[i]][50], (double)dataFormat.Rows[indexs[i]][51],
              (double)dataFormat.Rows[indexs[i]][52], (double)dataFormat.Rows[indexs[i]][53],
              (double)dataFormat.Rows[indexs[i]][54], (double)dataFormat.Rows[indexs[i]][55],
              (double)dataFormat.Rows[indexs[i]][56], (double)dataFormat.Rows[indexs[i]][57],
              (double)dataFormat.Rows[indexs[i]][58], (double)dataFormat.Rows[indexs[i]][59],
              (double)dataFormat.Rows[indexs[i]][60], (double)dataFormat.Rows[indexs[i]][61],
              (double)dataFormat.Rows[indexs[i]][62], (double)dataFormat.Rows[indexs[i]][63],
              (double)dataFormat.Rows[indexs[i]][64], (double)dataFormat.Rows[indexs[i]][65],
             (double)dataFormat.Rows[indexs[i]][66], (double)dataFormat.Rows[indexs[i]][67], (string)dataFormat.Rows[indexs[i]]["CustomerID"], (string)dataFormat.Rows[indexs[i]]["Name"]);

                }
               
                CrystalReport41.SetDataSource(dataset);
                
            }
            else
            {
                this.Show = false;
                clsMesageCollection.MessageNoTransactions();
            }
        }
    }
}