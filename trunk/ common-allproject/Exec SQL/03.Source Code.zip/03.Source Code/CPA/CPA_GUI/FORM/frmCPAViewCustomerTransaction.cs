﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define View CPA Screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Phoenix.Cpa.Bus; 
using Phoenix.Cpa.Dto;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Functions;
namespace Phoenix.Cpa.Gui.Forms
{
    /// <summary>
    /// View customer Transaction 
    /// Phong: Create at 2/2013
    /// </summary>
    public partial class frmViewCustomerTransaction : MasterForm
    {
		
        private string m_strCustomerID;
        private string m_strYearMonth;
        public frmViewCustomerTransaction(string customerID , string customerFullName, string yearMonth)
        {
            InitializeComponent();
            SetSecurity();

            txtCustomerCode.Text = customerID;
            txtCustomerFullName.Text = customerFullName;
            GetData(customerID, yearMonth);
            StandardValueinDatagrid();
           // ckbFull.Checked = true;
            SetDynamicSize();
            m_strCustomerID = customerID;
            m_strYearMonth = yearMonth;
            //format datagridview
            SetFormStyle();
            dtgCustomerTransaction.ColumnHeadersDefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
            dtgCustomerTransaction.DefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
            dtgCustomerTransaction.EnableHeadersVisualStyles = false;
            ChangeView();
			
        }
        public void GetData(string customerID, string yearMonth)
        {

                clsViewListTransactionBLL bll = new clsViewListTransactionBLL();
                DataTable data = bll.GetData(customerID, yearMonth,"","");
                List<clsCPACustomerDTO> lstData = new List<clsCPACustomerDTO>();
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    lstData.Add(new clsCPACustomerDTO(data.Rows[i]));
                }
                addCol_DataGridView(yearMonth);
                addRow_DataGridView();
                AddDataToColumns(lstData);
            
        }
        
        private void frmViewCustomerDetail_Load(object sender, EventArgs e)
        {            
            
            
            Painting_RowNull();
            this.dtgCustomerTransaction.ReadOnly = true;
            this.dtgCustomerTransaction.Scroll += new ScrollEventHandler(dtgCustomerDetail_Scroll);
            this.dtgCustomerTransaction.CellPainting += new DataGridViewCellPaintingEventHandler(dtgCustomerDetail_CellPainting);            
        }

        /// <summary>
        /// get 12 month before input time 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        private List<string> GetList12Month(string input)
        {
            List<string> result = new List<string>();
            DateTime date = new DateTime(int.Parse(input.Remove(4)), int.Parse(input.Remove(0, 4)), 1);
            result.Add(date.ToString("yyyyMM"));
            for (int i = 0; i < 11; i++)
            {
                date = date.AddMonths(-1);
                result.Add(date.ToString("yyyyMM"));
            }
            return result;
        }
        
       
       
        /// <summary>
        /// fill data from database into grid
        /// </summary>
        /// <param name="data"></param>
        private void AddDataToColumns(List<clsCPACustomerDTO> lstData)
        {

            for (int i = 0; i < lstData.Count; i++)
            {
                if (lstData[i].CPAStatus != 0)
                {
                    dtgCustomerTransaction.Rows[1].Cells[(string)lstData[i].YearMonth].Value = lstData[i].STL_Overdraft_AVE.ToString();
                    dtgCustomerTransaction.Rows[2].Cells[(string)lstData[i].YearMonth].Value = lstData[i].STL_CommercialBill_AVE.ToString();
                    dtgCustomerTransaction.Rows[3].Cells[(string)lstData[i].YearMonth].Value = lstData[i].STL_Loan_AVE.ToString();

                    dtgCustomerTransaction.Rows[5].Cells[(string)lstData[i].YearMonth].Value = lstData[i].LTL_Fixed_AVE.ToString();
                    dtgCustomerTransaction.Rows[6].Cells[(string)lstData[i].YearMonth].Value = lstData[i].LTL_Floating_AVE.ToString();

                    dtgCustomerTransaction.Rows[7].Cells[(string)lstData[i].YearMonth].Value = lstData[i].BB_AVE.ToString();
                    dtgCustomerTransaction.Rows[9].Cells[(string)lstData[i].YearMonth].Value = lstData[i].BR_AVE.ToString();

                    dtgCustomerTransaction.Rows[10].Cells[(string)lstData[i].YearMonth].Value = lstData[i].OtherApp_AVE.ToString();
                    dtgCustomerTransaction.Rows[13].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Dep_Liquid_AVE.ToString();
                    dtgCustomerTransaction.Rows[14].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Dep_Fixed_AVE.ToString();
                    dtgCustomerTransaction.Rows[15].Cells[(string)lstData[i].YearMonth].Value = lstData[i].OtherSource_AVE.ToString();
                    dtgCustomerTransaction.Rows[17].Cells[(string)lstData[i].YearMonth].Value = lstData[i].ReserveReq_AVE.ToString();
                    dtgCustomerTransaction.Rows[22].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Guarantee_AVE.ToString();
                    dtgCustomerTransaction.Rows[23].Cells[(string)lstData[i].YearMonth].Value = lstData[i].CleanLC_AVE.ToString();
                    dtgCustomerTransaction.Rows[24].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Acceptance_AVE.ToString();
                    dtgCustomerTransaction.Rows[25].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Commitment_AVE.ToString();
                    dtgCustomerTransaction.Rows[26].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Others_AVE.ToString();

                    dtgCustomerTransaction.Rows[29].Cells[(string)lstData[i].YearMonth].Value = lstData[i].DocLC_TUR.ToString();
                    dtgCustomerTransaction.Rows[30].Cells[(string)lstData[i].YearMonth].Value = lstData[i].ExpBillHandling_TUR.ToString();
                    dtgCustomerTransaction.Rows[31].Cells[(string)lstData[i].YearMonth].Value = lstData[i].ImpBillHandling_TUR.ToString();
                    dtgCustomerTransaction.Rows[32].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Collecting_TUR.ToString();
                    dtgCustomerTransaction.Rows[33].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Payment_TUR.ToString();
                    dtgCustomerTransaction.Rows[34].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Remittance_TUR.ToString();
                    dtgCustomerTransaction.Rows[35].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Loan_TUR.ToString();
                    dtgCustomerTransaction.Rows[36].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Others01_TUR.ToString();

                    dtgCustomerTransaction.Rows[37].Cells[(string)lstData[i].YearMonth].Value = lstData[i].ForeignExchangePL_TUR.ToString();
                    dtgCustomerTransaction.Rows[38].Cells[(string)lstData[i].YearMonth].Value = lstData[i].Others02_TUR.ToString();

                    //dtgCustomerTransaction.Rows[1].Cells[i].Value = lstData[i][2];

                    // Short Tern Loan
           
                    dtgCustomerTransaction.Rows[0].Cells[lstData[i].YearMonth].Value = lstData[i].STL_Overdraft_AVE + lstData[i].STL_CommercialBill_AVE + lstData[i].STL_Loan_AVE;

                    // Long Tern Loan
          
                    dtgCustomerTransaction.Rows[4].Cells[lstData[i].YearMonth].Value = lstData[i].LTL_Fixed_AVE + (Int64)lstData[i].LTL_Floating_AVE;

                    //Total Application
               
                    dtgCustomerTransaction.Rows[11].Cells[lstData[i].YearMonth].Value = (Int64)dtgCustomerTransaction.Rows[0].Cells[lstData[i].YearMonth].Value +
                        (Int64)dtgCustomerTransaction.Rows[4].Cells[lstData[i].YearMonth].Value +
                        lstData[i].BB_AVE + (Int64)lstData[i].BR_AVE + (Int64)lstData[i].OtherApp_AVE;

                    //Deposits 
               
                    dtgCustomerTransaction.Rows[12].Cells[lstData[i].YearMonth].Value = lstData[i].Dep_Liquid_AVE + (Int64)lstData[i].Dep_Fixed_AVE;

                    //Total Source
            dtgCustomerTransaction.Rows[16].Cells[lstData[i].YearMonth].Value = (Int64)dtgCustomerTransaction.Rows[12].Cells[lstData[i].YearMonth].Value + (Int64)lstData[i].OtherSource_AVE;

                    //TOTAL
    
                    dtgCustomerTransaction.Rows[18].Cells[lstData[i].YearMonth].Value = (Int64)dtgCustomerTransaction.Rows[11].Cells[lstData[i].YearMonth].Value + (Int64)dtgCustomerTransaction.Rows[16].Cells[lstData[i].YearMonth].Value + (Int64)lstData[i].ReserveReq_AVE;

                    //Commission and Fees - non funds

                    dtgCustomerTransaction.Rows[21].Cells[lstData[i].YearMonth].Value = (Int64)lstData[i].Guarantee_AVE + (Int64)lstData[i].CleanLC_AVE + (Int64)lstData[i].Acceptance_AVE + (Int64)lstData[i].Commitment_AVE + (Int64)lstData[i].Others_AVE;

                    //Commission and Fees
             
                    dtgCustomerTransaction.Rows[28].Cells[lstData[i].YearMonth].Value = (Int64)lstData[i].DocLC_TUR + (Int64)lstData[i].ExpBillHandling_TUR + (Int64)lstData[i].ImpBillHandling_TUR + (Int64)lstData[i].Collecting_TUR + (Int64)lstData[i].Payment_TUR + (Int64)lstData[i].Remittance_TUR + (Int64)lstData[i].Loan_TUR +
                       (Int64)lstData[i].Others01_TUR;

                    //TOTAL
           
                    dtgCustomerTransaction.Rows[39].Cells[lstData[i].YearMonth].Value = (Int64)dtgCustomerTransaction.Rows[21].Cells[(string)lstData[i].YearMonth].Value + (Int64)dtgCustomerTransaction.Rows[28].Cells[(string)lstData[i].YearMonth].Value + (Int64)lstData[i].ForeignExchangePL_TUR + (Int64)lstData[i].Others02_TUR;
                }
            }
        }

        /// <summary>
        /// standard number value in datagridview
        /// </summary>
        private void StandardValueinDatagrid()
        {
            for (int i = 0; i < dtgCustomerTransaction.Rows.Count; i++)
            {
                for (int j = 0; j < dtgCustomerTransaction.Columns.Count; j++)
                {

                    if (dtgCustomerTransaction.Rows[i].Cells[j].Value != null && dtgCustomerTransaction.Rows[i].Cells[j].Value.GetType() != typeof(DBNull))
                            dtgCustomerTransaction.Rows[i].Cells[j].Value = clsCommonFunctions.ConvertToStandardNumber(Int64.Parse(dtgCustomerTransaction.Rows[i].Cells[j].Value.ToString()));
                   
                    
                }
            }
        }

        /// <summary>
        /// create columns
        /// </summary>
        /// <param name="yearMonth"></param>
        private void addCol_DataGridView(string yearMonth)
        {
          //  this.dtgCustomerTransaction.Columns.Clear();

            List<string> colNames = GetList12Month(yearMonth);
                for (int i = colNames.Count - 1; i >=0; i--)
                {
                    DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
                    col1.HeaderText = clsCommonFunctions.GetMonthYearShowOnDataGrid(colNames[i]);
                    col1.Name = colNames[i];
                    col1.Width = 80;
                    col1.SortMode = DataGridViewColumnSortMode.NotSortable;
                    col1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    col1.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    dtgCustomerTransaction.Columns.Add(col1);
                }
           
      
           
        }


        /// <summary>
        /// Create Rows
        /// </summary>
        private void addRow_DataGridView()
        {
            this.dtgCustomerTransaction.Rows.Clear();
            this.dtgCustomerTransaction.RowHeadersWidth = 170;
            dtgCustomerTransaction.RowHeadersDefaultCellStyle.BackColor = Color.FromArgb(224, 223, 227);
            this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
			this.dtgCustomerTransaction.Rows[0].HeaderCell.Value = clsCPAConstant.SHORT_TERN_LOAN;// "Short Tern Loan";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[1].HeaderCell.Value = "    " +clsCPAConstant.OVERDRAFT ;//Overdraft;
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
                this.dtgCustomerTransaction.Rows[2].HeaderCell.Value = "    "+clsCPAConstant.COMMERCIAL_BILL;//Commercial Bill;
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
                this.dtgCustomerTransaction.Rows[3].HeaderCell.Value = "    "+clsCPAConstant.LOAN;//Loan;
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
                this.dtgCustomerTransaction.Rows[4].HeaderCell.Value = clsCPAConstant.LONG_TERN_LOAN;//"Long Tern Loan";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[5].HeaderCell.Value = "    " + clsCPAConstant.FIXED;//Fixed;
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[6].HeaderCell.Value = "    " + clsCPAConstant.FLOATING;//Floating ;
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[7].HeaderCell.Value = clsCPAConstant.BB;// "B/B";

                this.dtgCustomerTransaction.Rows.Add();
                this.dtgCustomerTransaction.Rows[8].HeaderCell.Value = "";

                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[9].HeaderCell.Value = clsCPAConstant.BR;// "B/R";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[10].HeaderCell.Value = clsCPAConstant.OTHER_APPLICATION;// "Other Application";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[11].HeaderCell.Value = clsCPAConstant.TOTAL_APPLICATION;// "Total Application";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[12].HeaderCell.Value = clsCPAConstant.DEPOSITS;// "Deposits";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[13].HeaderCell.Value = "    " + clsCPAConstant.LIQUID;//Liquid ;
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[14].HeaderCell.Value = "    " + clsCPAConstant.FIXED;//Fixed ;
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[15].HeaderCell.Value = clsCPAConstant.OTHER_SOURCE;// "Other Source";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[16].HeaderCell.Value = clsCPAConstant.TOTAL_SOURCE;// "Total Source";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[17].HeaderCell.Value = clsCPAConstant.RESERVE_REQUIREMENT;// "Reserve Requirement";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[18].HeaderCell.Value = clsCPAConstant.TOTAL;// "TOTAL";
                this.dtgCustomerTransaction.Rows.Add();
                this.dtgCustomerTransaction.Rows[19].HeaderCell.Value = "";


                this.dtgCustomerTransaction.Rows.Add();
                this.dtgCustomerTransaction.Rows[20].HeaderCell.Value =clsCPAConstant.NON_FUNDS_TRANSACTIONS ;//"Non-Funds Transactions";

                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[21].HeaderCell.Value = clsCPAConstant.COMMISSION_AND_FEES;// "Commission and Fees";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[22].HeaderCell.Value = clsCPAConstant.GUARANTEE;// "Guarantee";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[23].HeaderCell.Value = clsCPAConstant.CLEAN_LC;// "Clean L/C";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[24].HeaderCell.Value = clsCPAConstant.ACCEPTANCE;// "Acceptance";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[25].HeaderCell.Value = clsCPAConstant.COMMITMENT;// "Commitment";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[26].HeaderCell.Value = clsCPAConstant.OTHERS;// "Others";

                this.dtgCustomerTransaction.Rows.Add();
                this.dtgCustomerTransaction.Rows[27].HeaderCell.Value = "";

                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[28].HeaderCell.Value = clsCPAConstant.COMMISSION_AND_FEES;// "Commission and Fees";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[29].HeaderCell.Value = clsCPAConstant.DOCUMENTARY_LC_OPEN;// "Documentary L/C Open";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[30].HeaderCell.Value = clsCPAConstant.EXP_BILL_HANDLING;// "Exp Bill Handling";
                this.dtgCustomerTransaction.Rows.Add("0","0","0","0","0","0","0","0","0","0","0","0");
				this.dtgCustomerTransaction.Rows[31].HeaderCell.Value = clsCPAConstant.IMP_BILL_HANDLING;// "Imp Bill Handling";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[32].HeaderCell.Value = clsCPAConstant.COLLECTING;// "Collecting";

                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[33].HeaderCell.Value = clsCPAConstant.PAYMENT;// "Payment";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[34].HeaderCell.Value = clsCPAConstant.REMITTANCE;// "Remittance";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[35].HeaderCell.Value = clsCPAConstant.LOAN;// "Loan";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[36].HeaderCell.Value = clsCPAConstant.OTHERS;// "Others";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[37].HeaderCell.Value = clsCPAConstant.FOREIGN_EXCHANGE_PL;// "Foreign Exchange P/L";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[38].HeaderCell.Value = clsCPAConstant.OTHERS;// "Others";
                this.dtgCustomerTransaction.Rows.Add("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0");
				this.dtgCustomerTransaction.Rows[39].HeaderCell.Value = clsCPAConstant.TOTAL;// "TOTAL";            
        }


        /// <summary>
        /// Draw blank row
        /// </summary>
        private void Painting_RowNull()
        {
            for (int i = 0; i < dtgCustomerTransaction.Rows.Count - 1; i++)
            {
                if (this.dtgCustomerTransaction.Rows[i].HeaderCell.Value.ToString().Equals("") || this.dtgCustomerTransaction.Rows[i].HeaderCell.Value.ToString().Equals("Non-Funds Transactions"))
                {
                    MergeCells(0, this.dtgCustomerTransaction.Columns.Count - 1, i, false);
                }
            }
            this.dtgCustomerTransaction.ReadOnly = true;
        }



        void dtgCustomerDetail_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            Painting_RowNull();        
        }

        void dtgCustomerDetail_Scroll(object sender, ScrollEventArgs e)
        {
            Painting_RowNull();
               
        }

        /// <summary>
        /// Change layout of datagridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void ckbFull_CheckedChanged(object sender, EventArgs e)
        {
            //addCol_DataGridView();
           // addRow_DataGridView();
            ChangeView();
            
            
            Painting_RowNull();
        }

        private void ChangeView()
        {
            if (ckbFull.Checked == false)
            {
				this.dtgCustomerTransaction.Rows[1].HeaderCell.Value = clsCPAConstant.ST_OVEDRAFT;// "S/T Ovedraft";
				this.dtgCustomerTransaction.Rows[2].HeaderCell.Value = clsCPAConstant.ST_COMMECIAL_BILL;// "S/T Commecial Bill";
				this.dtgCustomerTransaction.Rows[3].HeaderCell.Value = clsCPAConstant.ST_LOAN;// "S/T Loan";
				this.dtgCustomerTransaction.Rows[5].HeaderCell.Value = clsCPAConstant.LT_LOAN_FIXED;// "L/T Loan (Fixed)";
				this.dtgCustomerTransaction.Rows[6].HeaderCell.Value = clsCPAConstant.LT_LOAN_FLOATING;// "L/T Loan (Floating)";
				this.dtgCustomerTransaction.Rows[13].HeaderCell.Value = clsCPAConstant.DEPO_LIQUID;// "Depo (Liquid)";
				this.dtgCustomerTransaction.Rows[14].HeaderCell.Value = clsCPAConstant.DEPO_FIXED;// "Depo (Fixed)";
				this.dtgCustomerTransaction.Rows[7].HeaderCell.Value = clsCPAConstant.BILL_BOUGHT;// "Bill Bought";

                dtgCustomerTransaction.Rows[0].Visible = false;
                dtgCustomerTransaction.Rows[4].Visible = false;
                this.dtgCustomerTransaction.Rows[8].Visible = true;
                dtgCustomerTransaction.Rows[9].Visible = false;
                dtgCustomerTransaction.Rows[10].Visible = false;
                dtgCustomerTransaction.Rows[11].Visible = false;
                dtgCustomerTransaction.Rows[12].Visible = false;

                dtgCustomerTransaction.Rows[15].Visible = false;
                dtgCustomerTransaction.Rows[16].Visible = false;
                dtgCustomerTransaction.Rows[17].Visible = false;
                dtgCustomerTransaction.Rows[18].Visible = false;

                  dtgCustomerTransaction.Rows[19].Visible = false;
                dtgCustomerTransaction.Rows[20].Visible = false;

                dtgCustomerTransaction.Rows[21].Visible = false;
                dtgCustomerTransaction.Rows[23].Visible = false;
                dtgCustomerTransaction.Rows[25].Visible = false;
                dtgCustomerTransaction.Rows[26].Visible = false;
                dtgCustomerTransaction.Rows[28].Visible = false;

                dtgCustomerTransaction.Rows[35].Visible = false;
                dtgCustomerTransaction.Rows[36].Visible = false;
                dtgCustomerTransaction.Rows[39].Visible = false;
            }
            else
            {

				this.dtgCustomerTransaction.Rows[1].HeaderCell.Value = "    " + clsCPAConstant.OVERDRAFT;//Overdraft;
				this.dtgCustomerTransaction.Rows[2].HeaderCell.Value = "    " + clsCPAConstant.COMMERCIAL_BILL;//Commercial Bill;
				this.dtgCustomerTransaction.Rows[3].HeaderCell.Value = "    " + clsCPAConstant.LOAN;//Loan;
				this.dtgCustomerTransaction.Rows[5].HeaderCell.Value = "    " + clsCPAConstant.FIXED; //Fixed;
				this.dtgCustomerTransaction.Rows[6].HeaderCell.Value = "    " + clsCPAConstant.FLOATING;//Floating ;
				this.dtgCustomerTransaction.Rows[13].HeaderCell.Value = "    " + clsCPAConstant.LIQUID;//Liquid ;
				this.dtgCustomerTransaction.Rows[14].HeaderCell.Value = "    " + clsCPAConstant.FIXED;//Fixed ;
				this.dtgCustomerTransaction.Rows[7].HeaderCell.Value = clsCPAConstant.BB;// "B/B";
                dtgCustomerTransaction.Rows[0].Visible = true;
                dtgCustomerTransaction.Rows[4].Visible = true;
                dtgCustomerTransaction.Rows[9].Visible = true;
                dtgCustomerTransaction.Rows[10].Visible = true;
                dtgCustomerTransaction.Rows[11].Visible = true;
                dtgCustomerTransaction.Rows[12].Visible = true;
                this.dtgCustomerTransaction.Rows[8].Visible = false;

                dtgCustomerTransaction.Rows[15].Visible = true;
                dtgCustomerTransaction.Rows[16].Visible = true;
                dtgCustomerTransaction.Rows[17].Visible = true;
                dtgCustomerTransaction.Rows[18].Visible = true;

                  dtgCustomerTransaction.Rows[19].Visible = true;
                dtgCustomerTransaction.Rows[20].Visible = true;
                dtgCustomerTransaction.Rows[21].Visible = true;
                dtgCustomerTransaction.Rows[23].Visible = true;
                dtgCustomerTransaction.Rows[25].Visible = true;
                dtgCustomerTransaction.Rows[26].Visible = true;
                dtgCustomerTransaction.Rows[28].Visible = true;

                dtgCustomerTransaction.Rows[35].Visible = true;
                dtgCustomerTransaction.Rows[36].Visible = true;
                dtgCustomerTransaction.Rows[39].Visible = true;
            }
        }
        /// <summary>
        /// make style of datagrid
        /// </summary>
        /// <param name="dtg1"></param>
        private void SetColorForFirstColumn(DataGridView dtg1)
        {
            //To mau cho cot dau trong datagridview
            for (int i = 0; i < dtgCustomerTransaction.Rows.Count - 1; i++)
            {
                dtgCustomerTransaction.Rows[i].Cells[0].Style.BackColor = System.Drawing.Color.Silver;
                if (dtgCustomerTransaction.Rows[i].Cells[0].Value.Equals(""))
                {
                    dtgCustomerTransaction.Rows[i].Cells[0].Style.BackColor = System.Drawing.Color.White;
                }
                
            }
        }

        /// <summary>
        /// Merge Cells
        /// </summary>
        /// <param name="Col1"></param>
        /// <param name="Col2"></param>
        /// <param name="Row"></param>
        /// <param name="isSelected"></param>
        private void MergeCells(int Col1, int Col2, int Row, bool isSelected)
        {
            Graphics g = dtgCustomerTransaction.CreateGraphics();
            Pen gridPen = new Pen(dtgCustomerTransaction.GridColor);

            //Cells Rectangles
            Rectangle CellRectangle1 = dtgCustomerTransaction.GetCellDisplayRectangle(Col1, Row, true);
            Rectangle CellRectangle2 = dtgCustomerTransaction.GetCellDisplayRectangle(Col2, Row, true);

            int rectWidth = 0;
            string MergedRows = String.Empty;

            for (int i = Col1; i <= Col2; i++)
            {
                rectWidth += dtgCustomerTransaction.GetCellDisplayRectangle(i, Row, false).Width;
            }

            Rectangle newCell = new Rectangle(CellRectangle1.X, CellRectangle1.Y, rectWidth, CellRectangle1.Height);

            g.FillRectangle(new SolidBrush(isSelected ? dtgCustomerTransaction.DefaultCellStyle.SelectionBackColor : dtgCustomerTransaction.DefaultCellStyle.BackColor), newCell);

            g.DrawRectangle(gridPen, newCell);
        }



        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                frmReportForCustomerTransactions report = new frmReportForCustomerTransactions(m_strYearMonth, m_strCustomerID, "", "");
                report.Show();
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

   

       

      
    }
}
