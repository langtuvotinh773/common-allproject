﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Import CPA Screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Collections;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Dal;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Functions;
namespace Phoenix.Cpa.Gui.Forms
{

    /// <summary>
    /// This form use to inport CPA
    /// Phong: in charge at 2/2013
    /// </summary>
    public partial class frmImportEDPList : MasterForm
    {
        clsImportEDPListTransBLL importEDPListTransBLL = new clsImportEDPListTransBLL();
        clsDataAccessLayer m_DAL = null;
        List<string> m_CustomerIDs;
        string m_YearMonth = "";
        string m_user = clsUserInfo.UserNo.ToString();
        bool m_CheckingSuccess = false; //return true if all data import success and no error
        int m_RowPerUnit = 49;//number of line in import file per a CPA
        int m_MaxUnit = 100; //number of CPA want to insert at a time
        clsCustomerErrorBus bus;
        bool m_ReImport = true;//user want reimport or not
        public frmImportEDPList()
        {
            InitializeComponent();
			//Yen Phan
			SetFormStyle();
        }

	
        /// <summary>
        /// choose file to import
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBrower_Click(object sender, EventArgs e)
        {
            //Title OpenFileDialog
            openFileDialog1.Title = clsCPACommonMessage.IMPORT_EDP_LIST;
            //Filter files .txt
            openFileDialog1.Filter = clsCPAConstant.DIALOG_FILTER_TXT;
            //Show OpenFileDialog            
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtFileName.Text = openFileDialog1.FileName;
            }
        }

        string EOF = clsCPAConstant.END_OF_LIST;
        string office = clsCPAConstant.HO_CHI_MINH_CITY_BRANCH;
        string custCode = "";
        string line = "";
        string queryValues = "";
        string allQueryValues = "";
        ArrayList arrSQL = new ArrayList();

        // query string
        string colList =
                clsCPAConstant.RPT_COL_YEARMONTH + "," +
            clsCPAConstant.RPT_COL_CUSTOMERID + "," +
            clsCPAConstant.RPT_COL_STL_OVERDRAFT_AVE + "," +
            clsCPAConstant.RPT_COL_STL_OVERDRAFT_REC + "," +
            clsCPAConstant.RPT_COL_STL_OVERDRAFT_PAY + "," +
            clsCPAConstant.RPT_COL_STL_COMMERCIALBILL_AVE + "," +
            clsCPAConstant.RPT_COL_STL_COMMERCIALBILL_REC + "," +
            clsCPAConstant.RPT_COL_STL_COMMERCIALBILL_PAY + "," +
            clsCPAConstant.RPT_COL_STL_LOAN_AVE + "," +
            clsCPAConstant.RPT_COL_STL_LOAN_REC + "," +
            clsCPAConstant.RPT_COL_STL_LOAN_PAY + "," +
            clsCPAConstant.RPT_COL_LTL_FIXED_AVE + "," +
            clsCPAConstant.RPT_COL_LTL_FIXED_REC + "," +
            clsCPAConstant.RPT_COL_LTL_FIXED_PAY + "," +
            clsCPAConstant.RPT_COL_LTL_FLOATING_AVE + "," +
            clsCPAConstant.RPT_COL_LTL_FLOATING_REC + "," +
            clsCPAConstant.RPT_COL_LTL_FLOATING_PAY + "," +
            clsCPAConstant.RPT_COL_BB_AVE + "," +
            clsCPAConstant.RPT_COL_BB_REC + "," +
            clsCPAConstant.RPT_COL_BB_PAY + "," +
            clsCPAConstant.RPT_COL_BR_AVE + "," +
            clsCPAConstant.RPT_COL_BR_REC + "," +
            clsCPAConstant.RPT_COL_BR_PAY + "," +
            clsCPAConstant.RPT_COL_OTHERAPP_AVE + "," +
            clsCPAConstant.RPT_COL_OTHERAPP_REC + "," +
            clsCPAConstant.RPT_COL_OTHERAPP_PAY + "," +
            clsCPAConstant.RPT_COL_DEP_LIQUID_AVE + "," +
            clsCPAConstant.RPT_COL_DEP_LIQUID_REC + "," +
            clsCPAConstant.RPT_COL_DEP_LIQUID_PAY + "," +
            clsCPAConstant.RPT_COL_DEP_FIXED_AVE + "," +
            clsCPAConstant.RPT_COL_DEP_FIXED_REC + "," +
            clsCPAConstant.RPT_COL_DEP_FIXED_PAY + "," +
            clsCPAConstant.RPT_COL_OTHERSOURCE_AVE + "," +
            clsCPAConstant.RPT_COL_OTHERSOURCE_REC + "," +
            clsCPAConstant.RPT_COL_OTHERSOURCE_PAY + "," +
            clsCPAConstant.RPT_COL_RESERVEREQ_AVE + "," +
            clsCPAConstant.RPT_COL_RESERVEREQ_REC + "," +
            clsCPAConstant.RPT_COL_RESERVEREQ_PAY + "," +
            clsCPAConstant.RPT_COL_GUARANTEE_AVE + "," +
            clsCPAConstant.RPT_COL_GUARANTEE_INC + "," +
            clsCPAConstant.RPT_COL_CLEANLC_AVE + "," +
            clsCPAConstant.RPT_COL_CLEANLC_INC + "," +
            clsCPAConstant.RPT_COL_ACCEPTANCE_AVE + "," +
            clsCPAConstant.RPT_COL_ACCEPTANCE_INC + "," +
            clsCPAConstant.RPT_COL_COMMITMENT_AVE + "," +
            clsCPAConstant.RPT_COL_COMMITMENT_INC + "," +
            clsCPAConstant.RPT_COL_OTHERS_AVE + "," +
            clsCPAConstant.RPT_COL_OTHERS_INC + "," +
            clsCPAConstant.RPT_COL_DOCLC_TUR + "," +
            clsCPAConstant.RPT_COL_DOCLC_INC + "," +
            clsCPAConstant.RPT_COL_EXPBILLHANDLING_TUR + "," +
            clsCPAConstant.RPT_COL_EXPBILLHANDLING_INC + "," +
            clsCPAConstant.RPT_COL_IMPBILLHANDLING_TUR + "," +
            clsCPAConstant.RPT_COL_IMPBILLHANDLING_INC + "," +
            clsCPAConstant.RPT_COL_COLLECTING_TUR + "," +
            clsCPAConstant.RPT_COL_COLLECTING_INC + "," +
            clsCPAConstant.RPT_COL_PAYMENT_TUR + "," +
            clsCPAConstant.RPT_COL_PAYMENT_INC + "," +
            clsCPAConstant.RPT_COL_REMITTANCE_TUR + "," +
            clsCPAConstant.RPT_COL_REMITTANCE_INC + "," +
            clsCPAConstant.RPT_COL_LOAN_TUR + "," +
            clsCPAConstant.RPT_COL_LOAN_INC + "," +
            clsCPAConstant.RPT_COL_OTHERS01_TUR + "," +
            clsCPAConstant.RPT_COL_OTHERS01_INC + "," +
            clsCPAConstant.RPT_COL_FOREIGNEXCHANGEPL_TUR + "," +
            clsCPAConstant.RPT_COL_FOREIGNEXCHANGEPL_INC + "," +
            clsCPAConstant.RPT_COL_OTHERS02_TUR + "," +
            clsCPAConstant.RPT_COL_OTHERS02_INC + "," +
            clsCPAConstant.RPT_COL_REPORTSTATUS;

     
        int result = 0;

        /// <summary>
        /// Import Data
        /// </summary>
        private void ImportEDPList()
        {
            int NonCustomerUnit = 0;
            importEDPListTransBLL = new clsImportEDPListTransBLL();
            arrSQL = new ArrayList();
            m_DAL = new clsDataAccessLayer();
            bus = new clsCustomerErrorBus();
             custCode = "";
             line = "";
             queryValues = "";
             allQueryValues = "";
            string filePath = txtFileName.Text.ToString().Trim();
            
            if (filePath.Equals(""))
            {

                clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                                          clsCPACommonMessage.SELECT_FILE_TO_IMPORT);
                m_CheckingSuccess = false;
                m_ReImport = false;
                return;
            }

            string endFilePath = filePath.Substring(filePath.LastIndexOf("."));
            //Check type file is .txt
            if (!endFilePath.Equals(clsCPAConstant.END_OF_FILE_IMPORT))
            {


                clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                                         clsCPACommonMessage.TYPE_OF_FILE_MUST_BE_TXT);

                m_CheckingSuccess = false;
                m_ReImport = false;
                return;
            }
            //Check file exist
            if (!File.Exists(filePath))
            {

                clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                                         clsCPACommonMessage.FILE_DOES_NOT_EXIST);
            
                m_CheckingSuccess = false;
                m_ReImport = false;
                return;
            }

           
            

            //read file
            string[] allLines = new string[0];
            allLines = File.ReadAllLines(txtFileName.Text.ToString().Trim());
            m_YearMonth = "";
            int noLine = allLines.Length;

            if (noLine == 0)
            {
          
                clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                                          clsCPACommonMessage.FILE_IS_NULL);

                 m_ReImport = false;
                m_CheckingSuccess = false;
            }
            else
            {
                // delete tempplate table before import
                bus.DeleteTempTable();
                //read first line to get BRANCH
                int i = 0;
                

                line = allLines[2];
                string line_YearMonth = line.Trim();
                m_YearMonth = "";

                if (line_YearMonth.IndexOf("<<") > -1)
                {
                    m_YearMonth = line_YearMonth.Substring(line_YearMonth.IndexOf("<<") + 4, 4);
                    line_YearMonth = line_YearMonth.Substring(line_YearMonth.IndexOf("<<") + 4, 8);

                    DateTime getMonth = Convert.ToDateTime(line_YearMonth);

                    line_YearMonth = getMonth.Month.ToString("00");

                    m_YearMonth += line_YearMonth;

                  //  queryValues = "SELECT '" + m_YearMonth + "',";

                    int status = importEDPListTransBLL.CheckStatusCPA(m_YearMonth);
                    if (status == 1)  //CPA completed.
                    {
                        
                        clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                                       clsCPACommonMessage.CPA_COMPLETED);
                        m_CheckingSuccess = false;
                        m_ReImport = false;
                        return;
                    }
                    if (status == 0)
                    {
                      
                        DialogResult result = clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                                                         clsCPACommonMessage.CONFIRM_IMPORT_AGAIN);
                        if (result == DialogResult.Yes)
                        {
                            m_ReImport = true;

                        }
                        else
                        {
                            m_ReImport = false;
                            return;

                        }

                    }



                    //clsImportEDPListTransBLL bll = new clsImportEDPListTransBLL();
                    //bll.AddCPAMaster(m_YearMonth, m_user);

                }

                //Count row number
                int rowNum = 0;




                #region do while


                line = allLines[i];

                int CPANumber = allLines.Length / m_RowPerUnit;
                int CPARemain = CPANumber;
                do
                {
                    #region if
                    if (line.IndexOf(office) > -1)
                    {
                        //skip 2 row
                        i += 2;
                        int a = allLines.Length;
                        //get Year month
                        line = allLines[i];
                         line_YearMonth = line.Trim();
                        m_YearMonth = "";

                        if (line_YearMonth.IndexOf("<<") > -1)
                        {
                            m_YearMonth = line_YearMonth.Substring(line_YearMonth.IndexOf("<<") + 4, 4);
                            line_YearMonth = line_YearMonth.Substring(line_YearMonth.IndexOf("<<") + 4, 8);

                            DateTime getMonth = Convert.ToDateTime(line_YearMonth);
                           
                            line_YearMonth = getMonth.Month.ToString("00");
                            
                            m_YearMonth += line_YearMonth;

                            queryValues = "SELECT '" + m_YearMonth + "',";

                        }
                        //get Cust Name
                        i += 1;
                        line = allLines[i];
                        string custName = line.Substring(line.IndexOf(":") + 1);
                        //MessageBox.Show(custName);                                
                        //replace ' --> ''
                        custName = custName.Replace("'", "''");
                        //get Cust Code
                        i += 1;
                        line = allLines[i];
                        custCode = line.Trim();
                        if (custCode.IndexOf("-") > -1)
                        {
                            custCode = custCode.Substring(custCode.IndexOf("-") + 1, 8);
                            m_CustomerIDs.Add(custCode);
                        }
                        else
                        {
                            custCode = "";
                            //jump to Cust block, skip 42 row
                            rowNum++;
                            i += 42;
                            NonCustomerUnit = NonCustomerUnit + 1;
                        }
                        queryValues += "'" + custCode + "',";

                    }
                    #endregion End if
                    //read number
                    i += 1;
                    line = allLines[i];

                    if (!"".Equals(custCode))
                    {
                        string _No = line.Substring(32, 2);
                        switch (_No)
                        {
                            #region case of number
                            case "02":
                                queryValues += getFund(line, clsCPAConstant.STL_OVERDRAFT);
                                break;
                            case "03":
                                queryValues += getFund(line, clsCPAConstant.STL_COMMERCIALBILL);
                                break;
                            case "04":
                                queryValues += getFund(line, clsCPAConstant.STL_LOAN);
                                break;
                            case "06":
                                queryValues += getFund(line, clsCPAConstant.LTL_FIXED);
                                break;
                            case "07":
                                queryValues += getFund(line, clsCPAConstant.LTL_FLOATING);
                                break;
                            case "08":
                                queryValues += getFund(line, clsCPAConstant.BB);
                                break;
                            case "09":
                                queryValues += getFund(line, clsCPAConstant.BR);
                                break;
                            case "10":
                                queryValues += getFund(line, clsCPAConstant.OTHERAPP);
                                break;
                            case "13":
                                queryValues += getFund(line, clsCPAConstant.DEP_LIQUID);
                                break;
                            case "14":
                                queryValues += getFund(line, clsCPAConstant.DEP_FIXED);
                                break;
                            case "15":
                                queryValues += getFund(line, clsCPAConstant.OTHERSOURCE);
                                break;
                            case "17":
                                queryValues += getFund(line, clsCPAConstant.RESERVEREQ);
                                break;
                            case "20":
                                queryValues += getNonFund1(line, clsCPAConstant.GUARANTEE);
                                break;
                            case "21":
                                queryValues += getNonFund1(line, clsCPAConstant.CLEANLC);
                                break;
                            case "22":
                                queryValues += getNonFund1(line, clsCPAConstant.ACCEPTANCE);
                                break;
                            case "23":
                                queryValues += getNonFund1(line, clsCPAConstant.COMMITMENT);
                                break;
                            case "24":
                                queryValues += getNonFund1(line, clsCPAConstant.OTHERS);
                                break;
                            case "26":
                                queryValues += getNonFund2(line, clsCPAConstant.DOCLC);
                                break;
                            case "27":
                                queryValues += getNonFund2(line, clsCPAConstant.EXPBILLHANDLING);
                                break;
                            case "28":
                                queryValues += getNonFund2(line, clsCPAConstant.IMPBILLHANDLING);
                                break;
                            case "29":
                                queryValues += getNonFund2(line, clsCPAConstant.COLLECTING);
                                break;
                            case "30":
                                queryValues += getNonFund2(line, clsCPAConstant.PAYMENT);
                                break;
                            case "31":
                                queryValues += getNonFund2(line, clsCPAConstant.REMITTANCE);
                                break;
                            case "32":
                                queryValues += getNonFund2(line, clsCPAConstant.LOAN);
                                break;
                            case "33":
                                queryValues += getNonFund2(line, clsCPAConstant.OTHERS01);
                                break;
                            case "34":
                                queryValues += getNonFund2(line, clsCPAConstant.FOREIGNEXCHANGEPL);
                                break;
                            case "35":
                                queryValues += getNonFund2(line, clsCPAConstant.OTHERS02);

                                if (!"".Equals(queryValues))
                                {
                                    // Add status report for queryValues (default 1)
                                    queryValues += "1,";
                                    queryValues = queryValues.Substring(0, queryValues.Length - 1);
                                    // Add "UNION ALL" for queryValues
                                    queryValues += " UNION ALL ";
                                    allQueryValues += queryValues;

                                    rowNum += 1;
                                   
                                }
                                break;
                            #endregion
                        }//end switch                    
                    }//end if


                    // Phong change: if total row < 100, i must insert line by line and not return after insert becase it will break while loop
                    if (i == m_RowPerUnit * rowNum - 2 - NonCustomerUnit)
                    {
                        if (rowNum == CPANumber && allQueryValues != "")
                        {
                            #region Insert multi rows into table customer

                              allQueryValues = allQueryValues.Substring(0, allQueryValues.Length - 11);
                                string _sql = "INSERT INTO tblCPA_TempCustomer (" + colList + ") " + allQueryValues;

                                arrSQL.Add(_sql);

                                result = m_DAL.ExecuteTransaction(arrSQL);
                                if (result == 0) return;
                            _sql = "";
                            allQueryValues = "";
                            arrSQL.Clear();
                            CPARemain = 0;
                            #endregion

                        }
                        else
                        {
                            if (rowNum % m_MaxUnit == 0 && !"".Equals(allQueryValues))
                            {
                                #region Insert multi rows into table customer

                                allQueryValues = allQueryValues.Substring(0, allQueryValues.Length - 11);
                                string _sql = "INSERT INTO tblCPA_TempCustomer (" + colList + ") " + allQueryValues;

                                arrSQL.Add(_sql);
                               
                                    result = m_DAL.ExecuteTransaction(arrSQL);
                                    if (result == 0) return;
                               
                                _sql = "";
                                allQueryValues = "";
                                arrSQL.Clear();
                                CPARemain = CPARemain - m_MaxUnit;
                                #endregion
                            }
                        }

                    }

                } while (line.IndexOf(EOF) == -1 && i < allLines.Length - 1 && CPARemain > 0); // phong change, must check remain row is enough info for a customer completed
                #endregion

                if (allQueryValues != "")
                {
                    allQueryValues = allQueryValues.Substring(0, allQueryValues.Length - 11);
                    string _sql = "INSERT INTO tblCPA_TempCustomer (" + colList + ") " + allQueryValues;

                    arrSQL.Add(_sql);

                    result = m_DAL.ExecuteTransaction(arrSQL);
                }

                //Call store import
                clsDataAccessLayer DAL = new clsDataAccessLayer();
                SqlParameter[] parameters1 = new SqlParameter[0];
              
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@pYearMonth", m_YearMonth);
                parameters[1] = new SqlParameter("@pCreateBy", m_user);
     

                DAL.ExecuteNonQueryNonReply("dbo.spImportDataEDP", CommandType.StoredProcedure, parameters);

                m_CheckingSuccess = true;



            }
        }
        #region get fund
        string getFund(string line, string _col)
        {
            string _query = "";
            string _val = "";
            //average balance
            int _lenAvgBal = (line.Length < 36 + 14) ? 13 : 14;
            _val = getValue(line, 36, _lenAvgBal); //idx in string is 36 but column in text file is 37
      
            _query = _val + ",";

            //receivable interest
            int _lenRecInt = (line.Length < 63 + 14) ? 13 : 14;
            _val = getValue(line, 63, _lenRecInt); //idx in string is 63 but column in text file is 64
            _query += _val + ",";

            //payable interest
            int _lenPayInt = (line.Length < 90 + 14) ? 13 : 14;
            _val = getValue(line, 90, _lenPayInt); //idx in string is 90 but column in text file is 91
            _query += _val + ",";

            return _query;
        }
        #endregion

        #region get non fund
        string getNonFund1(string line, string _col)
        {
            string _query = "";
            string _val = "";
            //average balance
            int _lenAvgBal = (line.Length < 36 + 14) ? 13 : 14;
            _val = getValue(line, 36, _lenAvgBal); //idx in string is 36 but column in text file is 37
            _query = _val + ",";

            //income
            int _lenInc = (line.Length < 63 + 14) ? 13 : 14;
            _val = getValue(line, 63, _lenInc); //idx in string is 63 but column in text file is 64
            _query += _val + ",";

            return _query;
        }
        #endregion

        #region get non fund
        string getNonFund2(string line, string _col)
        {
            string _query = "";
            string _val = "";
            //average balance
            int _lenAvgBal = (line.Length < 36 + 14) ? 13 : 14;
            _val = getValue(line, 36, _lenAvgBal); //idx in string is 36 but column in text file is 37
            _query = _val + ",";

            //income
            int _lenInc = (line.Length < 63 + 14) ? 13 : 14;
            _val = getValue(line, 63, _lenInc); //idx in string is 63 but column in text file is 64
            _query += _val + ",";

            return _query;
        }
        #endregion

        #region get value
        string getValue(string line, int begin, int _len)
        {
            string _val = "";
            try
            {
                _val = line.Substring(begin, _len);
                _val = _val.Trim();
                _val = _val.Replace(",", "");
                //format minus number
                if (_val.EndsWith("-"))
                {
                    _val = "-" + _val.Substring(0, _val.Length - 1);
                }
                if ("".Equals(_val))
                {
                    _val = "0";
                }
            }
            catch (Exception)
            {
                _val = "0";
                //MessageBox.Show(ex.Message);
            }

            return _val;
        }
        #endregion
        /// <summary>
        /// process when import button clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnImport_Click(object sender, EventArgs e)
        {
            btnImport.Enabled = false;
          
            try
            {
               
                m_CheckingSuccess = false;
                List<string> idError = new List<string>();
                m_CustomerIDs = new List<string>();


                ImportEDPList();
                
                if (m_ReImport == true)
                {

                    if (m_CheckingSuccess == false)
                    {
                        clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                                                                  COMMON.Properties.Settings.Default.INFO_ACTION_FAIL, new string[] { clsCPAConstant.IMPORT_ACTION, clsCPAConstant.CPA_TEXT });
                        return;
                    }
                    // get list data error and check them
                    DataTable dataError = bus.GetListCustomerError(m_YearMonth, "");
                    

                    // if have error , show message and Customer error screen
                    if (dataError.Rows.Count > 0)
                    {
                        DialogResult result = clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                                                             clsCPACommonMessage.CAN_NOT_IMPORT);
                        if (result == DialogResult.Yes)
                        {
                            frmListCustomerError newFrm= new frmListCustomerError(m_YearMonth, idError);
                            newFrm.Show();
                        }
                    }
                    else
                    {
                        if (m_CheckingSuccess == true)
                        {
                            
                            clsMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                                                              COMMON.Properties.Settings.Default.INFO_ACTION_SUCCESS, new string[] { clsCPAConstant.IMPORT_ACTION, clsCPAConstant.CPA_TEXT });
                        }
                    }
                   
                }
            }
            catch (Exception ex)
            {
                this.ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite,this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }

            btnImport.Enabled = true;
          
        }
        /// <summary>
        /// close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}