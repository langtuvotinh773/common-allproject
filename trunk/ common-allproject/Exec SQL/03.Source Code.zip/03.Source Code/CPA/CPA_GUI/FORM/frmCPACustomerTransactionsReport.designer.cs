﻿using UserCtrl;
namespace Phoenix.Cpa.Gui.Forms
{
    partial class frmCustomerTransactionsReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMonthYear = new System.Windows.Forms.Label();
            this.lblJNJ = new System.Windows.Forms.Label();
            this.lblCustomerCode = new System.Windows.Forms.Label();
            this.lblCustomerFullName = new System.Windows.Forms.Label();
            this.txtCustomerCode = new System.Windows.Forms.TextBox();
            this.txtCustomerFullName = new System.Windows.Forms.TextBox();
            this.cbbJNJ = new System.Windows.Forms.ComboBox();
            this.btnExportReport = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtMonthYear = new UserCtrl.MonthYearCalendar();
            this.SuspendLayout();
            // 
            // lblMonthYear
            // 
            this.lblMonthYear.AutoSize = true;
            this.lblMonthYear.Location = new System.Drawing.Point(12, 9);
            this.lblMonthYear.Name = "lblMonthYear";
            this.lblMonthYear.Size = new System.Drawing.Size(64, 13);
            this.lblMonthYear.TabIndex = 0;
            this.lblMonthYear.Text = "Month/Year";
            // 
            // lblJNJ
            // 
            this.lblJNJ.AutoSize = true;
            this.lblJNJ.Location = new System.Drawing.Point(264, 9);
            this.lblJNJ.Name = "lblJNJ";
            this.lblJNJ.Size = new System.Drawing.Size(25, 13);
            this.lblJNJ.TabIndex = 0;
            this.lblJNJ.Text = "JNJ";
            // 
            // lblCustomerCode
            // 
            this.lblCustomerCode.AutoSize = true;
            this.lblCustomerCode.Location = new System.Drawing.Point(12, 31);
            this.lblCustomerCode.Name = "lblCustomerCode";
            this.lblCustomerCode.Size = new System.Drawing.Size(79, 13);
            this.lblCustomerCode.TabIndex = 0;
            this.lblCustomerCode.Text = "Customer Code";
            // 
            // lblCustomerFullName
            // 
            this.lblCustomerFullName.AutoSize = true;
            this.lblCustomerFullName.Location = new System.Drawing.Point(264, 31);
            this.lblCustomerFullName.Name = "lblCustomerFullName";
            this.lblCustomerFullName.Size = new System.Drawing.Size(101, 13);
            this.lblCustomerFullName.TabIndex = 0;
            this.lblCustomerFullName.Text = "Customer Full Name";
            // 
            // txtCustomerCode
            // 
            this.txtCustomerCode.Location = new System.Drawing.Point(102, 28);
            this.txtCustomerCode.Name = "txtCustomerCode";
            this.txtCustomerCode.Size = new System.Drawing.Size(116, 20);
            this.txtCustomerCode.TabIndex = 2;
            // 
            // txtCustomerFullName
            // 
            this.txtCustomerFullName.Location = new System.Drawing.Point(392, 28);
            this.txtCustomerFullName.Name = "txtCustomerFullName";
            this.txtCustomerFullName.Size = new System.Drawing.Size(304, 20);
            this.txtCustomerFullName.TabIndex = 3;
            // 
            // cbbJNJ
            // 
            this.cbbJNJ.FormattingEnabled = true;
            this.cbbJNJ.Location = new System.Drawing.Point(392, 6);
            this.cbbJNJ.Name = "cbbJNJ";
            this.cbbJNJ.Size = new System.Drawing.Size(136, 21);
            this.cbbJNJ.TabIndex = 1;
            // 
            // btnExportReport
            // 
            this.btnExportReport.Location = new System.Drawing.Point(489, 57);
            this.btnExportReport.Name = "btnExportReport";
            this.btnExportReport.Size = new System.Drawing.Size(100, 23);
            this.btnExportReport.TabIndex = 4;
            this.btnExportReport.Text = "&Export Report";
            this.btnExportReport.UseVisualStyleBackColor = true;
            this.btnExportReport.Click += new System.EventHandler(this.btnExportReport_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(595, 57);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 23);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtMonthYear
            // 
            this.txtMonthYear.CustomFormat = "MM/yyyy";
            this.txtMonthYear.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtMonthYear.Location = new System.Drawing.Point(102, 6);
            this.txtMonthYear.Name = "txtMonthYear";
            this.txtMonthYear.ShowUpDown = true;
            this.txtMonthYear.Size = new System.Drawing.Size(116, 20);
            this.txtMonthYear.TabIndex = 0;
            // 
            // frmCustomerTransactionsReport
            // 
            this.AcceptButton = this.btnExportReport;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(708, 92);
            this.Controls.Add(this.txtMonthYear);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnExportReport);
            this.Controls.Add(this.cbbJNJ);
            this.Controls.Add(this.txtCustomerFullName);
            this.Controls.Add(this.txtCustomerCode);
            this.Controls.Add(this.lblCustomerFullName);
            this.Controls.Add(this.lblCustomerCode);
            this.Controls.Add(this.lblJNJ);
            this.Controls.Add(this.lblMonthYear);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmCustomerTransactionsReport";
            this.Text = "Customer Transactions Report";
            this.Load += new System.EventHandler(this.frmCustomerTransactionsReport_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMonthYear;
        private System.Windows.Forms.Label lblJNJ;
        private System.Windows.Forms.Label lblCustomerCode;
		private System.Windows.Forms.Label lblCustomerFullName;
        private System.Windows.Forms.TextBox txtCustomerCode;
        private System.Windows.Forms.TextBox txtCustomerFullName;
        private System.Windows.Forms.ComboBox cbbJNJ;
        private System.Windows.Forms.Button btnExportReport;
        private System.Windows.Forms.Button btnClose;
        private MonthYearCalendar txtMonthYear;
    }
}