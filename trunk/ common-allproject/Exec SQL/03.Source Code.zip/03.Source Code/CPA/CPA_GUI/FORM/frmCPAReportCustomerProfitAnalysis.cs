﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to defineList Customer Profiability Report
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms; 
using CrystalDecisions.Shared;
using Phoenix.Cpa.Gui.Report;
using Phoenix.Cpa.Bus;
using Phoenix.Cpa.Dto;
using Phoenix.Cpa.Common;
using System.Data;
namespace Phoenix.Cpa.Gui.Forms
{

    /// <summary>
    /// Phong: Create at 2/2013
    /// </summary>
	public partial class frmReportCustomerProfitAnalysis : Form
	{
		public bool Show = true;
		public frmReportCustomerProfitAnalysis(string customerCode, string Name, string JNJ, DateTime time)
		{
			InitializeComponent();

            //get datatime now
            string yearMonth = time.Year.ToString() + time.Month.ToString("00");
			DateTime date = new DateTime(int.Parse(yearMonth.Remove(4)), int.Parse(yearMonth.Remove(0, 4)), 1);
			date = date.AddMonths(-1);
			string preMonth = date.Year.ToString() + date.Month.ToString("00");
			DtsCustomerProfitAnalysis data = new DtsCustomerProfitAnalysis();
			clsReportBLL bll = new clsReportBLL();
            
            //Get data from databse
            bll.GetListCPACustomerForReport(preMonth, yearMonth, customerCode, Name, "", "", JNJ, "", "");
           
			List<clsCPACustomerDTO> lst = bll.ListCPACustomer;
			if (lst.Count > 0)
			{

				for (int i = 0; i < lst.Count; i++)
				{
                    if (lst[i].YearMonth == preMonth) //if this is previous month (not current month)
                    {
                        if (i == lst.Count - 1) // if this is last object of list, just insert value of this object and value of current month  = 0
                        {
                            data.DataTable1.Rows.Add(lst[i].GetLoanBal(), 0, lst[i].GetDeposit(),
                                   0, lst[i].GetProfitOfLoan(), 0,
                                    lst[i].GetProfitDeposit(), 0, lst[i].GetCommissionFee(), 0, lst[i].ForeignExchangePL_INC,
                                    0, lst[i].GetTotalProfit(), 0, lst[i].CustomerName, lst[i].JNJ, lst[i].CustomerID);
                        }
                        if (i < lst.Count - 1) // if this is not end of list
                        {
                            if (lst[i + 1].YearMonth == yearMonth && lst[i + 1].CustomerID == lst[i].CustomerID) // if next object has same monthyeart => this is a pair, insert value of current month = object at index i + 1
                            {
                                data.DataTable1.Rows.Add(lst[i].GetLoanBal(), lst[i + 1].GetLoanBal(), lst[i].GetDeposit(), lst[i + 1].GetDeposit(),
                                   lst[i].GetProfitOfLoan(), lst[i + 1].GetProfitOfLoan(), lst[i].GetProfitDeposit(),
                                    lst[i + 1].GetProfitDeposit(), lst[i].GetCommissionFee(), lst[i + 1].GetCommissionFee(), lst[i].ForeignExchangePL_INC, lst[i + 1].ForeignExchangePL_INC,
                                    lst[i].GetTotalProfit(), lst[i + 1].GetTotalProfit(), lst[i].CustomerName, lst[i + 1].JNJ, lst[i].CustomerID);
                                i = i + 1; // increate index

                            }
                            else // if next object has not save monthyear => this is not a pair, insert value of current month = 0
                            {
                                data.DataTable1.Rows.Add(lst[i].GetLoanBal(), 0, lst[i].GetDeposit(),
                                   0, lst[i].GetProfitOfLoan(), 0,
                                    lst[i].GetProfitDeposit(), 0, lst[i].GetCommissionFee(), 0, lst[i].ForeignExchangePL_INC,
                                    0, lst[i].GetTotalProfit(), 0, lst[i].CustomerName, lst[i].JNJ, lst[i].CustomerID);
                            }
                        }
                       

                    }
                    else // this is current month, have same process with previous month
                    {
                        if (i == 0)
                        {
                            data.DataTable1.Rows.Add(0, lst[i].GetLoanBal(), 0, lst[i].GetDeposit(),
                                  0, lst[i].GetProfitOfLoan(), 0,
                                   lst[i].GetProfitDeposit(), 0, lst[i].GetCommissionFee(), 0, lst[i].ForeignExchangePL_INC,
                                   0, lst[i].GetTotalProfit(), lst[i].CustomerName, lst[i].JNJ, lst[i].CustomerID);
                        }
                        if (lst[i].YearMonth == yearMonth)
                        {
                            if (i > 0)
                            {
                                if (lst[i - 1].YearMonth == preMonth && lst[i - 1].CustomerID == lst[i].CustomerID)
                                {
                                    data.DataTable1.Rows.Add(lst[i - 1].GetLoanBal(), lst[i].GetLoanBal(), lst[i - 1].GetDeposit(), lst[i].GetDeposit(),
                                       lst[i - 1].GetProfitOfLoan(), lst[i].GetProfitOfLoan(), lst[i - 1].GetProfitDeposit(),
                                        lst[i].GetProfitDeposit(), lst[i - 1].GetCommissionFee(), lst[i].GetCommissionFee(), lst[i - 1].ForeignExchangePL_INC, lst[i].ForeignExchangePL_INC,
                                        lst[i - 1].GetTotalProfit(), lst[i].GetTotalProfit(), lst[i].CustomerName, lst[i].JNJ, lst[i].CustomerID);
                                    i = i + 1;
                                }
                                else
                                {
                                    data.DataTable1.Rows.Add(0, lst[i].GetLoanBal(), 0, lst[i].GetDeposit(),
                                       0, lst[i].GetProfitOfLoan(), 0,
                                        lst[i].GetProfitDeposit(), 0, lst[i].GetCommissionFee(), 0, lst[i].ForeignExchangePL_INC,
                                        0, lst[i].GetTotalProfit(), lst[i].CustomerName, lst[i].JNJ, lst[i].CustomerID);
                                }
                            }
                            
                        }
                    }

				}
                 data.DataTable1.DefaultView.Sort = "TotalPL_Cur DESC";
                DataTable table = data.DataTable1.DefaultView.ToTable();
				
               
				CrystalReport11.SetDataSource(table);
               
				ParameterFields myParams = new ParameterFields();
				ParameterDiscreteValue myDiscreteValue5 = new ParameterDiscreteValue();
				ParameterField myParam5 = new ParameterField();
				myParam5.ParameterFieldName = clsCPAConstant.CUSTOMER_PROFIABILITY_ANALYSIS_REPORT_PARAM_NAME;
				myDiscreteValue5.Value = clsCPAConstant.CUSTOMER_PROFIABILITY_ANALYSIS_REPORT;
				myParam5.CurrentValues.Add(myDiscreteValue5);
				myParams.Add(myParam5);

                ParameterDiscreteValue myDiscreteValue1 = new ParameterDiscreteValue();
                ParameterField myParam1 = new ParameterField();
                myParam1.ParameterFieldName = "time";
                myDiscreteValue1.Value = time.ToString("MMM-yyyy");
                myParam1.CurrentValues.Add(myDiscreteValue1);
                myParams.Add(myParam1);

				crystalReportViewer1.ParameterFieldInfo = myParams;
			}
			else
			{
				this.Show = false;
                clsMesageCollection.MessageNoTransactions();
			}

		}

	
	}
}