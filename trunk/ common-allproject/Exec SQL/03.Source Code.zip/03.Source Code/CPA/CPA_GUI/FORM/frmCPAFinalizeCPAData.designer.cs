﻿using UserCtrl;
namespace Phoenix.Cpa.Gui.Forms
{
    partial class frmFinalizeCPAData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblMonthYearFrom = new System.Windows.Forms.Label();
            this.lblComplete = new System.Windows.Forms.Label();
            this.ckbComplete = new System.Windows.Forms.CheckBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtgCompleteCPA = new System.Windows.Forms.DataGridView();
            this.clComplete = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.clMonthYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.cldMonthYearFrom = new UserCtrl.MonthYearCalendar();
            this.cldMonthYearTo = new UserCtrl.MonthYearCalendar();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCompleteCPA)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMonthYearFrom
            // 
            this.lblMonthYearFrom.AutoSize = true;
            this.lblMonthYearFrom.Location = new System.Drawing.Point(43, 25);
            this.lblMonthYearFrom.Name = "lblMonthYearFrom";
            this.lblMonthYearFrom.Size = new System.Drawing.Size(90, 13);
            this.lblMonthYearFrom.TabIndex = 9;
            this.lblMonthYearFrom.Text = "From Month/Year";
            // 
            // lblComplete
            // 
            this.lblComplete.AutoSize = true;
            this.lblComplete.Location = new System.Drawing.Point(73, 72);
            this.lblComplete.Name = "lblComplete";
            this.lblComplete.Size = new System.Drawing.Size(48, 13);
            this.lblComplete.TabIndex = 8;
            this.lblComplete.Text = "Finalized";
            // 
            // ckbComplete
            // 
            this.ckbComplete.AutoSize = true;
            this.ckbComplete.Location = new System.Drawing.Point(137, 72);
            this.ckbComplete.Name = "ckbComplete";
            this.ckbComplete.Size = new System.Drawing.Size(15, 14);
            this.ckbComplete.TabIndex = 2;
            this.ckbComplete.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(328, 31);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 23);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtgCompleteCPA
            // 
            this.dtgCompleteCPA.AllowUserToAddRows = false;
            this.dtgCompleteCPA.AllowUserToDeleteRows = false;
            this.dtgCompleteCPA.AllowUserToResizeColumns = false;
            this.dtgCompleteCPA.AllowUserToResizeRows = false;
            this.dtgCompleteCPA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgCompleteCPA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgCompleteCPA.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clComplete,
            this.clMonthYear});
            this.dtgCompleteCPA.Location = new System.Drawing.Point(12, 101);
            this.dtgCompleteCPA.Name = "dtgCompleteCPA";
            this.dtgCompleteCPA.ReadOnly = true;
            this.dtgCompleteCPA.RowHeadersVisible = false;
            this.dtgCompleteCPA.Size = new System.Drawing.Size(479, 338);
            this.dtgCompleteCPA.TabIndex = 4;
            this.dtgCompleteCPA.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCompleteCPA_CellValueChanged);
            this.dtgCompleteCPA.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgCompleteCPA_CellMouseClick);
            this.dtgCompleteCPA.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCompleteCPA_RowEnter);
         
            this.dtgCompleteCPA.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCompleteCPA_CellEndEdit);
         
            this.dtgCompleteCPA.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtgCompleteCPA_KeyDown);
            this.dtgCompleteCPA.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCompleteCPA_CellEnter);
            // 
            // clComplete
            // 
            this.clComplete.FillWeight = 50F;
            this.clComplete.HeaderText = "Finalize";
            this.clComplete.Name = "clComplete";
            this.clComplete.ReadOnly = true;
            // 
            // clMonthYear
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.clMonthYear.DefaultCellStyle = dataGridViewCellStyle7;
            this.clMonthYear.HeaderText = "Month Year";
            this.clMonthYear.Name = "clMonthYear";
            this.clMonthYear.ReadOnly = true;
            this.clMonthYear.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.clMonthYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(279, 445);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(390, 445);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 23);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewTextBoxColumn1.HeaderText = "Month/Year";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 182;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "To Month/Year";
            // 
            // cldMonthYearFrom
            // 
            this.cldMonthYearFrom.CustomFormat = "MM/yyyy";
            this.cldMonthYearFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.cldMonthYearFrom.Location = new System.Drawing.Point(137, 23);
            this.cldMonthYearFrom.Name = "cldMonthYearFrom";
            this.cldMonthYearFrom.ShowUpDown = true;
            this.cldMonthYearFrom.Size = new System.Drawing.Size(131, 20);
            this.cldMonthYearFrom.TabIndex = 0;
            // 
            // cldMonthYearTo
            // 
            this.cldMonthYearTo.CustomFormat = "MM/yyyy";
            this.cldMonthYearTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.cldMonthYearTo.Location = new System.Drawing.Point(137, 45);
            this.cldMonthYearTo.Name = "cldMonthYearTo";
            this.cldMonthYearTo.ShowUpDown = true;
            this.cldMonthYearTo.Size = new System.Drawing.Size(131, 20);
            this.cldMonthYearTo.TabIndex = 1;
            // 
            // frmFinalizeCPAData
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(502, 480);
            this.Controls.Add(this.cldMonthYearTo);
            this.Controls.Add(this.cldMonthYearFrom);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dtgCompleteCPA);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.ckbComplete);
            this.Controls.Add(this.lblComplete);
            this.Controls.Add(this.lblMonthYearFrom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmFinalizeCPAData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Finalize CPA Data";

            ((System.ComponentModel.ISupportInitialize)(this.dtgCompleteCPA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMonthYearFrom;
		private System.Windows.Forms.Label lblComplete;
        private System.Windows.Forms.CheckBox ckbComplete;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dtgCompleteCPA;
		private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DataGridViewCheckBoxColumn clComplete;
        private System.Windows.Forms.DataGridViewTextBoxColumn clMonthYear;
        private System.Windows.Forms.Label label1;
        private MonthYearCalendar cldMonthYearFrom;
        private MonthYearCalendar cldMonthYearTo;
    }
}