﻿using UserCtrl;
namespace Phoenix.Cpa.Gui.Forms
{
    partial class frmCPAListCPA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCPAListCPA));
            this.asd = new System.Windows.Forms.GroupBox();
            this.monthYearTo = new UserCtrl.MonthYearCalendar();
            this.monthYearFrom = new UserCtrl.MonthYearCalendar();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.tbCustomerShortName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbCustomerFullName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbCustomerCode = new System.Windows.Forms.TextBox();
            this.cbbStatus = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonView = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonUpdate = new System.Windows.Forms.ToolStripButton();
            this.btnSave = new System.Windows.Forms.ToolStripButton();
            this.btnClose = new System.Windows.Forms.Button();
            this.dtgCPAList = new UserCtrl.DisableDatagrid();
            this.asd.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCPAList)).BeginInit();
            this.SuspendLayout();
            // 
            // asd
            // 
            this.asd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.asd.Controls.Add(this.monthYearTo);
            this.asd.Controls.Add(this.monthYearFrom);
            this.asd.Controls.Add(this.btnSearch);
            this.asd.Controls.Add(this.label6);
            this.asd.Controls.Add(this.tbCustomerShortName);
            this.asd.Controls.Add(this.label5);
            this.asd.Controls.Add(this.label4);
            this.asd.Controls.Add(this.tbCustomerFullName);
            this.asd.Controls.Add(this.label3);
            this.asd.Controls.Add(this.label2);
            this.asd.Controls.Add(this.tbCustomerCode);
            this.asd.Controls.Add(this.cbbStatus);
            this.asd.Controls.Add(this.label1);
            this.asd.Location = new System.Drawing.Point(5, 28);
            this.asd.Name = "asd";
            this.asd.Size = new System.Drawing.Size(936, 95);
            this.asd.TabIndex = 0;
            this.asd.TabStop = false;
            // 
            // monthYearTo
            // 
            this.monthYearTo.CustomFormat = "MM/yyyy";
            this.monthYearTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.monthYearTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.monthYearTo.Location = new System.Drawing.Point(395, 16);
            this.monthYearTo.Name = "monthYearTo";
            this.monthYearTo.ShowUpDown = true;
            this.monthYearTo.Size = new System.Drawing.Size(100, 20);
            this.monthYearTo.TabIndex = 1;
            this.monthYearTo.Value = new System.DateTime(2013, 2, 5, 0, 0, 0, 0);
            // 
            // monthYearFrom
            // 
            this.monthYearFrom.CustomFormat = "MM/yyyy";
            this.monthYearFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.monthYearFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.monthYearFrom.Location = new System.Drawing.Point(121, 19);
            this.monthYearFrom.Name = "monthYearFrom";
            this.monthYearFrom.ShowUpDown = true;
            this.monthYearFrom.Size = new System.Drawing.Size(100, 20);
            this.monthYearFrom.TabIndex = 0;
            this.monthYearFrom.Value = new System.DateTime(2013, 2, 5, 0, 0, 0, 0);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(702, 57);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 23);
            this.btnSearch.TabIndex = 6;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(269, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 13);
            this.label6.TabIndex = 28;
            this.label6.Text = "Customer Short Name";
            // 
            // tbCustomerShortName
            // 
            this.tbCustomerShortName.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.tbCustomerShortName.Location = new System.Drawing.Point(395, 59);
            this.tbCustomerShortName.Name = "tbCustomerShortName";
            this.tbCustomerShortName.Size = new System.Drawing.Size(279, 20);
            this.tbCustomerShortName.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "Status";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(269, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "Customer Full Name";
            // 
            // tbCustomerFullName
            // 
            this.tbCustomerFullName.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.tbCustomerFullName.Location = new System.Drawing.Point(395, 38);
            this.tbCustomerFullName.Name = "tbCustomerFullName";
            this.tbCustomerFullName.Size = new System.Drawing.Size(279, 20);
            this.tbCustomerFullName.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(269, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 23;
            this.label3.Text = "To Month/Year";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Custoner Code";
            // 
            // tbCustomerCode
            // 
            this.tbCustomerCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.tbCustomerCode.Location = new System.Drawing.Point(121, 40);
            this.tbCustomerCode.Name = "tbCustomerCode";
            this.tbCustomerCode.Size = new System.Drawing.Size(100, 20);
            this.tbCustomerCode.TabIndex = 2;
            // 
            // cbbStatus
            // 
            this.cbbStatus.FormattingEnabled = true;
            this.cbbStatus.Location = new System.Drawing.Point(121, 61);
            this.cbbStatus.Name = "cbbStatus";
            this.cbbStatus.Size = new System.Drawing.Size(100, 21);
            this.cbbStatus.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "From Month/Year";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonView,
            this.toolStripButtonUpdate,
            this.btnSave});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(946, 25);
            this.toolStrip1.TabIndex = 17;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonView
            // 
            this.toolStripButtonView.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonView.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonView.Image")));
            this.toolStripButtonView.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonView.Name = "toolStripButtonView";
            this.toolStripButtonView.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonView.Text = "View (Atl + V)";
            this.toolStripButtonView.Click += new System.EventHandler(this.toolStripButtonView_Click);
            // 
            // toolStripButtonUpdate
            // 
            this.toolStripButtonUpdate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonUpdate.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonUpdate.Image")));
            this.toolStripButtonUpdate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonUpdate.Name = "toolStripButtonUpdate";
            this.toolStripButtonUpdate.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonUpdate.Text = "Modify (Atl + M)";
            this.toolStripButtonUpdate.Click += new System.EventHandler(this.toolStripButtonUpdate_Click);
            // 
            // btnSave
            // 
            this.btnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(23, 22);
            this.btnSave.Text = "Save (Atl + E )";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(841, 456);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 23);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dtgCPAList
            // 
            this.dtgCPAList.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dtgCPAList.AllowUserToAddRows = false;
            this.dtgCPAList.AllowUserToDeleteRows = false;
            this.dtgCPAList.AllowUserToResizeColumns = false;
            this.dtgCPAList.AllowUserToResizeRows = false;
            this.dtgCPAList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgCPAList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgCPAList.Location = new System.Drawing.Point(5, 129);
            this.dtgCPAList.Name = "dtgCPAList";
            this.dtgCPAList.Size = new System.Drawing.Size(936, 321);
            this.dtgCPAList.TabIndex = 1;
            this.dtgCPAList.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCPAList_CellValueChanged);
            this.dtgCPAList.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCPAList_RowEnter);
            this.dtgCPAList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCPAList_CellClick_1);
            this.dtgCPAList.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtgCPAList_KeyDown);
            this.dtgCPAList.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCPAList_CellEnter);
            this.dtgCPAList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCPAList_CellContentClick);
            // 
            // frmCPAListCPA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(946, 482);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.asd);
            this.Controls.Add(this.dtgCPAList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmCPAListCPA";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmCPAListCPA_FormClosing);
            this.asd.ResumeLayout(false);
            this.asd.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCPAList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DisableDatagrid dtgCPAList;
        private System.Windows.Forms.GroupBox asd;
        private MonthYearCalendar monthYearFrom;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbCustomerShortName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbCustomerFullName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbCustomerCode;
        private System.Windows.Forms.ComboBox cbbStatus;
        private System.Windows.Forms.Label label1;
        private MonthYearCalendar monthYearTo;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonView;
        private System.Windows.Forms.ToolStripButton toolStripButtonUpdate;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ToolStripButton btnSave;
    }
}