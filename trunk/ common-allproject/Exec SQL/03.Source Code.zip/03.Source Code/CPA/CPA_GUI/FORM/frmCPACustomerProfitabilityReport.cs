﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Customer Profiability Report Screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Popup;
namespace Phoenix.Cpa.Gui.Forms
{

    /// <summary>
    /// This form use to export Customer profitabity report
    /// Phong: in charge at 2/2013
    /// </summary>
    public partial class frmCustomerProfitabilityReport : MasterForm
    {
        string m_yearMonth = "";
        public frmCustomerProfitabilityReport()
        {
            InitializeComponent();

            // add data for combobox quarter
            List<string> quarter = new List<string>();
            quarter.Add(clsCPAConstant.QUARTER_01);
            quarter.Add(clsCPAConstant.QUARTER_02);
            quarter.Add(clsCPAConstant.QUARTER_03);
            quarter.Add(clsCPAConstant.QUARTER_04);
            cbbQuarter.DataSource = quarter;
            cbbQuarter.DropDownStyle = ComboBoxStyle.DropDownList;
            //Yen Phan
            SetFormStyle();
        }
       
        /// <summary>
        /// Print report
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtYear.Text == "")
                {
                    frmPhoenixMessage frm = new frmPhoenixMessage((int)CommonValue.MessageType.Error,
                                                           COMMON.Properties.Settings.Default.ERR_REQUIRED, new string[] { "Year" });
                    frm.ShowDialog();
                    return;
                }
                else
                {
                    
                    btnExport.Enabled = false;
                    m_yearMonth = txtYear.Text + clsCommonFunctions.FindEndMonthByQuater(int.Parse(cbbQuarter.Text));
                    Run();
                    Complete();
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT);
            }
            
        }


        private void Run()
        {
            frmReportForACustomer frm = new frmReportForACustomer(m_yearMonth, txtCustomerCode.Text.Trim(), txtCustomerFullName.Text.Trim());
            if (frm.Show == true)
                frm.Show();
            else
                frm.Close();
        }
        private void Complete()
        {
            btnExport.Enabled = true;
           
        }
        /// <summary>
        /// Check input value Year and Quarter
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private bool CheckYearQuarter()
        {
            try
            {
                if (txtYear.Text == "" || cbbQuarter.Text == "")
                    return false;
                int iYearInputByUser = int.Parse(txtYear.Text);
                int iQuarterInputByUser = int.Parse(cbbQuarter.Text);
                int iYearNow = DateTime.Today.Year;
                int iMonthNow = DateTime.Now.Month;

                if (iYearInputByUser > iYearNow ||
                    iYearInputByUser < 0 ||
                    iQuarterInputByUser > 4 ||
                    iQuarterInputByUser < 0)
                    return false;

                if (iYearInputByUser < iYearNow)
                    return true;

                int iDiff = iMonthNow % 3 > 0 ? 1 : 0;
                int iMaxQuarter = iMonthNow / 3 + iDiff;
                if (iQuarterInputByUser > iMaxQuarter)
                    return false;

                return true;
            }
            catch (Exception ex) { clsLogFile.LogException(ex.Message,clsCPAConstant.CPA_TEXT); }
            return false;
        }
        /// <summary>
        /// txtQuarter_KeyPress
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void txtQuarter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar.ToString() == "\b" || e.KeyChar.ToString() == " ")
            {
                e.Handled = false;
                return;
            }
            if (int.Parse(e.KeyChar.ToString()) == 0 || int.Parse(e.KeyChar.ToString()) > 4)
                e.Handled = true;
        }
        /// <summary>
        /// txtYear_KeyPress
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void txtYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        /// <summary>
        /// Close this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}