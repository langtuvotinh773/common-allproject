﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define CPA Master object
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// This Class use to store CPA Master infomation 
    /// </summary>
    public class clsCPAMasterDTO
    {
        private string _YearMonth;

        public string YearMonth
        {
            get { return _YearMonth; }
            set { _YearMonth = value; }
        }
        private int _CPA_Status;

        public int CPA_Status
        {
            get { return _CPA_Status; }
            set { _CPA_Status = value; }
        }
        private string _CreatedBy;

        public string CreatedBy
        {
            get { return _CreatedBy; }
            set { _CreatedBy = value; }
        }
        private DateTime _CreateDate;

        public DateTime CreateDate
        {
            get { return _CreateDate; }
            set { _CreateDate = value; }
        }
        
        
    }
}
