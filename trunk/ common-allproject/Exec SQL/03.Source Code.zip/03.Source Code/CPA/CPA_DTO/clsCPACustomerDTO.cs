﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define CPA Customer object
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Phoenix.Cpa.Dto
{

    /// <summary>
    /// This class use for create object CPA customermer 
    /// </summary>
	public class clsCPACustomerDTO
	{

		private string _YearMonth;

		public string YearMonth
		{
			get { return _YearMonth; }
			set { _YearMonth = value; }
		}
		private string _CustomerID;

		public string CustomerID
		{
			get { return _CustomerID; }
			set { _CustomerID = value; }
		}
		private Int64 _STL_Overdraft_AVE;

		public Int64 STL_Overdraft_AVE
		{
			get { return _STL_Overdraft_AVE; }
			set { _STL_Overdraft_AVE = value; }
		}
		private Int64 _STL_CommercialBill_AVE;

		public Int64 STL_CommercialBill_AVE
		{
			get { return _STL_CommercialBill_AVE; }
			set { _STL_CommercialBill_AVE = value; }
		}
		private Int64 _STL_Loan_AVE;

		public Int64 STL_Loan_AVE
		{
			get { return _STL_Loan_AVE; }
			set { _STL_Loan_AVE = value; }
		}
		private Int64 _STL_Overdraft_REC;

		public Int64 STL_Overdraft_REC
		{
			get { return _STL_Overdraft_REC; }
			set { _STL_Overdraft_REC = value; }
		}
		private Int64 _STL_CommercialBill_REC;

		public Int64 STL_CommercialBill_REC
		{
			get { return _STL_CommercialBill_REC; }
			set { _STL_CommercialBill_REC = value; }
		}
		private Int64 _STL_Loan_REC;

		public Int64 STL_Loan_REC
		{
			get { return _STL_Loan_REC; }
			set { _STL_Loan_REC = value; }
		}
		private Int64 _STL_Overdraft_PAY;

		public Int64 STL_Overdraft_PAY
		{
			get { return _STL_Overdraft_PAY; }
			set { _STL_Overdraft_PAY = value; }
		}
		private Int64 _STL_CommercialBill_PAY;

		public Int64 STL_CommercialBill_PAY
		{
			get { return _STL_CommercialBill_PAY; }
			set { _STL_CommercialBill_PAY = value; }
		}
		private Int64 _STL_Loan_PAY;

		public Int64 STL_Loan_PAY
		{
			get { return _STL_Loan_PAY; }
			set { _STL_Loan_PAY = value; }
		}
		private Int64 _LTL_Fixed_AVE;

		public Int64 LTL_Fixed_AVE
		{
			get { return _LTL_Fixed_AVE; }
			set { _LTL_Fixed_AVE = value; }
		}
		private Int64 _LTL_Floating_AVE;

		public Int64 LTL_Floating_AVE
		{
			get { return _LTL_Floating_AVE; }
			set { _LTL_Floating_AVE = value; }
		}
		private Int64 _LTL_Fixed_REC;

		public Int64 LTL_Fixed_REC
		{
			get { return _LTL_Fixed_REC; }
			set { _LTL_Fixed_REC = value; }
		}
		private Int64 _LTL_Floating_REC;

		public Int64 LTL_Floating_REC
		{
			get { return _LTL_Floating_REC; }
			set { _LTL_Floating_REC = value; }
		}
		private Int64 _LTL_Fixed_PAY;

		public Int64 LTL_Fixed_PAY
		{
			get { return _LTL_Fixed_PAY; }
			set { _LTL_Fixed_PAY = value; }
		}
		private Int64 _LTL_Floating_PAY;

		public Int64 LTL_Floating_PAY
		{
			get { return _LTL_Floating_PAY; }
			set { _LTL_Floating_PAY = value; }
		}
		private Int64 __BB_AVE;

		public Int64 BB_AVE
		{
			get { return __BB_AVE; }
			set { __BB_AVE = value; }
		}
		private Int64 _BR_AVE;

		public Int64 BR_AVE
		{
			get { return _BR_AVE; }
			set { _BR_AVE = value; }
		}
		private Int64 _BB_REC;

		public Int64 BB_REC
		{
			get { return _BB_REC; }
			set { _BB_REC = value; }
		}
		private Int64 _BR_REC;

		public Int64 BR_REC
		{
			get { return _BR_REC; }
			set { _BR_REC = value; }
		}
		private Int64 _BB_PAY;

		public Int64 BB_PAY
		{
			get { return _BB_PAY; }
			set { _BB_PAY = value; }
		}
		private Int64 _BR_PAY;

		public Int64 BR_PAY
		{
			get { return _BR_PAY; }
			set { _BR_PAY = value; }
		}
		private Int64 _OtherApp_AVE;

		public Int64 OtherApp_AVE
		{
			get { return _OtherApp_AVE; }
			set { _OtherApp_AVE = value; }
		}
		private Int64 _OtherApp_REC;

		public Int64 OtherApp_REC
		{
			get { return _OtherApp_REC; }
			set { _OtherApp_REC = value; }
		}
		private Int64 _OtherApp_PAY;

		public Int64 OtherApp_PAY
		{
			get { return _OtherApp_PAY; }
			set { _OtherApp_PAY = value; }
		}
		private Int64 _Dep_Liquid_AVE;

		public Int64 Dep_Liquid_AVE
		{
			get { return _Dep_Liquid_AVE; }
			set { _Dep_Liquid_AVE = value; }
		}
		private Int64 _Dep_Fixed_AVE;

		public Int64 Dep_Fixed_AVE
		{
			get { return _Dep_Fixed_AVE; }
			set { _Dep_Fixed_AVE = value; }
		}
		private Int64 _Dep_Liquid_REC;

		public Int64 Dep_Liquid_REC
		{
			get { return _Dep_Liquid_REC; }
			set { _Dep_Liquid_REC = value; }
		}
		private Int64 _Dep_Fixed_REC;

		public Int64 Dep_Fixed_REC
		{
			get { return _Dep_Fixed_REC; }
			set { _Dep_Fixed_REC = value; }
		}
		private Int64 _Dep_Liquid_PAY;

		public Int64 Dep_Liquid_PAY
		{
			get { return _Dep_Liquid_PAY; }
			set { _Dep_Liquid_PAY = value; }
		}
		private Int64 _Dep_Fixed_PAY;

		public Int64 Dep_Fixed_PAY
		{
			get { return _Dep_Fixed_PAY; }
			set { _Dep_Fixed_PAY = value; }
		}
		private Int64 _OtherSource_AVE;

		public Int64 OtherSource_AVE
		{
			get { return _OtherSource_AVE; }
			set { _OtherSource_AVE = value; }
		}
		private Int64 _OtherSource_REC;

		public Int64 OtherSource_REC
		{
			get { return _OtherSource_REC; }
			set { _OtherSource_REC = value; }
		}
		private Int64 _OtherSource_PAY;

		public Int64 OtherSource_PAY
		{
			get { return _OtherSource_PAY; }
			set { _OtherSource_PAY = value; }
		}
		private Int64 _ReserveReq_AVE;

		public Int64 ReserveReq_AVE
		{
			get { return _ReserveReq_AVE; }
			set { _ReserveReq_AVE = value; }
		}
		private Int64 _ReserveReq_REC;

		public Int64 ReserveReq_REC
		{
			get { return _ReserveReq_REC; }
			set { _ReserveReq_REC = value; }
		}
		private Int64 _ReserveReq_PAY;

		public Int64 ReserveReq_PAY
		{
			get { return _ReserveReq_PAY; }
			set { _ReserveReq_PAY = value; }
		}
		private Int64 _Guarantee_AVE;

		public Int64 Guarantee_AVE
		{
			get { return _Guarantee_AVE; }
			set { _Guarantee_AVE = value; }
		}
		private Int64 _CleanLC_AVE;

		public Int64 CleanLC_AVE
		{
			get { return _CleanLC_AVE; }
			set { _CleanLC_AVE = value; }
		}
		private Int64 _Acceptance_AVE;

		public Int64 Acceptance_AVE
		{
			get { return _Acceptance_AVE; }
			set { _Acceptance_AVE = value; }
		}
		private Int64 _Commitment_AVE;

		public Int64 Commitment_AVE
		{
			get { return _Commitment_AVE; }
			set { _Commitment_AVE = value; }
		}
		private Int64 _Others_AVE;

		public Int64 Others_AVE
		{
			get { return _Others_AVE; }
			set { _Others_AVE = value; }
		}
		private Int64 _Guarantee_INC;

		public Int64 Guarantee_INC
		{
			get { return _Guarantee_INC; }
			set { _Guarantee_INC = value; }
		}
		private Int64 _CleanLC_INC;

		public Int64 CleanLC_INC
		{
			get { return _CleanLC_INC; }
			set { _CleanLC_INC = value; }
		}
		private Int64 _Acceptance_INC;

		public Int64 Acceptance_INC
		{
			get { return _Acceptance_INC; }
			set { _Acceptance_INC = value; }
		}
		private Int64 _Commitment_INC;

		public Int64 Commitment_INC
		{
			get { return _Commitment_INC; }
			set { _Commitment_INC = value; }
		}
		private Int64 _Others_INC;

		public Int64 Others_INC
		{
			get { return _Others_INC; }
			set { _Others_INC = value; }
		}
		private Int64 _DocLC_TUR;

		public Int64 DocLC_TUR
		{
			get { return _DocLC_TUR; }
			set { _DocLC_TUR = value; }
		}
		private Int64 _ExpBillHandling_TUR;

		public Int64 ExpBillHandling_TUR
		{
			get { return _ExpBillHandling_TUR; }
			set { _ExpBillHandling_TUR = value; }
		}
		private Int64 _ImpBillHandling_TUR;

		public Int64 ImpBillHandling_TUR
		{
			get { return _ImpBillHandling_TUR; }
			set { _ImpBillHandling_TUR = value; }
		}
		private Int64 _Collecting_TUR;

		public Int64 Collecting_TUR
		{
			get { return _Collecting_TUR; }
			set { _Collecting_TUR = value; }
		}
		private Int64 _Payment_TUR;

		public Int64 Payment_TUR
		{
			get { return _Payment_TUR; }
			set { _Payment_TUR = value; }
		}
		private Int64 _Remittance_TUR;

		public Int64 Remittance_TUR
		{
			get { return _Remittance_TUR; }
			set { _Remittance_TUR = value; }
		}
		private Int64 _Loan_TUR;

		public Int64 Loan_TUR
		{
			get { return _Loan_TUR; }
			set { _Loan_TUR = value; }
		}
		private Int64 _Others01_TUR;

		public Int64 Others01_TUR
		{
			get { return _Others01_TUR; }
			set { _Others01_TUR = value; }
		}
		private Int64 _ForeignExchangePL_TUR;

		public Int64 ForeignExchangePL_TUR
		{
			get { return _ForeignExchangePL_TUR; }
			set { _ForeignExchangePL_TUR = value; }
		}
		private Int64 _Others02_TUR;

		public Int64 Others02_TUR
		{
			get { return _Others02_TUR; }
			set { _Others02_TUR = value; }
		}
		private Int64 _DocLC_INC;

		public Int64 DocLC_INC
		{
			get { return _DocLC_INC; }
			set { _DocLC_INC = value; }
		}
		private Int64 _ExpBillHandling_INC;

		public Int64 ExpBillHandling_INC
		{
			get { return _ExpBillHandling_INC; }
			set { _ExpBillHandling_INC = value; }
		}
		private Int64 _ImpBillHandling_INC;

		public Int64 ImpBillHandling_INC
		{
			get { return _ImpBillHandling_INC; }
			set { _ImpBillHandling_INC = value; }
		}
		private Int64 _Collecting_INC;

		public Int64 Collecting_INC
		{
			get { return _Collecting_INC; }
			set { _Collecting_INC = value; }
		}
		private Int64 _Payment_INC;

		public Int64 Payment_INC
		{
			get { return _Payment_INC; }
			set { _Payment_INC = value; }
		}
		private Int64 _Remittance_INC;

		public Int64 Remittance_INC
		{
			get { return _Remittance_INC; }
			set { _Remittance_INC = value; }
		}
		private Int64 _Loan_INC;

		public Int64 Loan_INC
		{
			get { return _Loan_INC; }
			set { _Loan_INC = value; }
		}
		private Int64 _Others01_INC;

		public Int64 Others01_INC
		{
			get { return _Others01_INC; }
			set { _Others01_INC = value; }
		}
		private Int64 _ForeignExchangePL_INC;

		public Int64 ForeignExchangePL_INC
		{
			get { return _ForeignExchangePL_INC; }
			set { _ForeignExchangePL_INC = value; }
		}
		private Int64 _Others02_INC;

		public Int64 Others02_INC
		{
			get { return _Others02_INC; }
			set { _Others02_INC = value; }
		}
		private bool _ReportStatus;

		public bool ReportStatus
		{
			get { return _ReportStatus; }
			set { _ReportStatus = value; }
		}

		private string _jnj;

		public string JNJ
		{
			get { return _jnj; }
			set { _jnj = value; }
		}

		private byte _CPAStatus;

		public byte CPAStatus
		{
			get { return _CPAStatus; }
			set { _CPAStatus = value; }
		}

		private string _CustomerName;

		public string CustomerName
		{
			get { return _CustomerName; }
			set { _CustomerName = value; }
		}
		private string _JPAcc;

		public string JPAcc
		{
			get { return _JPAcc; }
			set { _JPAcc = value; }
		}
		private string _VNAcc;

		public string VNAcc
		{
			get { return _VNAcc; }
			set { _VNAcc = value; }
		}

		private Int64 _Report_Value;
		public Int64 Report_Value
		{
			get { return _Report_Value; }
			set { _Report_Value = value; }
		}

		private string _team;

		public string Team
		{
			get { return _team; }
			set { _team = value; }
		}
		private long _CalItem;

		public long CalItem
		{
			get { return _CalItem; }
			set { _CalItem = value; }
		}
		private Int64 CheckNull(object input)
		{
			return input.GetType() == typeof(DBNull) ? 0 : (Int64) input;
		}
		private string _customerShortName;

		public string ShortName
		{
			get { return _customerShortName; }
			set { _customerShortName = value; }
		}

        private string shortJP;

        public string ShortJP
        {
            get { return shortJP; }
            set { shortJP = value; }
        }
        private string shortVN;

        public string ShortVN
        {
            get { return shortVN; }
            set { shortVN = value; }
        }

		public clsCPACustomerDTO()
		{
		}

		public clsCPACustomerDTO(DataRow row, bool NotShow)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			CPAStatus = (byte) row["CPA_Status"];
			CustomerName = ((string) row["Name"]).Trim();

            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			try
			{
				JPAcc = ((string) row["JPAcc"]).Trim();
			}
			catch (Exception)
			{
				JPAcc = "";
			}
			try
			{
				VNAcc = ((string) row["VNAcc"]).Trim();
			}
			catch (Exception)
			{
				VNAcc = "";
			}
			try
			{
				Team = ((string) row["Team"]).Trim();
			}
			catch (Exception)
			{
				Team = "";
			}
			try
			{
				_customerShortName = ((string) row["ShortName"]).Trim();
			}
			catch (Exception)
			{
				_customerShortName = "";
			}
			this.STL_Overdraft_AVE = 0;
			this.STL_CommercialBill_AVE = 0;
			this.STL_Loan_AVE = 0;
			this.STL_Overdraft_REC = 0;
			this.STL_CommercialBill_REC = 0;
			this.STL_Loan_REC = 0;
			this.STL_Overdraft_PAY = 0;
			this.STL_CommercialBill_PAY = 0;
			this.STL_Loan_PAY = 0;
			this.LTL_Fixed_AVE = 0;
			this.LTL_Floating_AVE = 0;
			this.LTL_Fixed_REC = 0;
			this.LTL_Floating_REC = 0;
			this.LTL_Fixed_PAY = 0;
			this.LTL_Floating_PAY = 0;
			this.BB_AVE = 0;
			this.BR_AVE = 0;
			this.BB_REC = 0;
			this.BR_REC = 0;
			this.BB_PAY = 0;
			this.BR_PAY = 0;
			this.OtherApp_AVE = 0;
			this.OtherApp_REC = 0;
			this.OtherApp_PAY = 0;
			this.Dep_Liquid_AVE = 0;
			this.Dep_Fixed_AVE = 0;
			this.Dep_Liquid_REC = 0;
			this.Dep_Fixed_REC = 0;
			this.Dep_Liquid_PAY = 0;
			this.Dep_Fixed_PAY = 0;
			this.OtherSource_AVE = 0;
			this.OtherSource_REC = 0;
			this.OtherSource_PAY = 0;
			this.ReserveReq_AVE = 0;
			this.ReserveReq_REC = 0;
			this.ReserveReq_PAY = 0;
			this.Guarantee_AVE = 0;
			this.CleanLC_AVE = 0;
			this.Acceptance_AVE = 0;
			this.Commitment_AVE = 0;
			this.Others_AVE = 0;
			this.Guarantee_INC = 0;
			this.CleanLC_INC = 0;
			this.Acceptance_INC = 0;
			this.Commitment_INC = 0;
			this.Others_INC = 0;
			this.DocLC_TUR = 0;
			this.ExpBillHandling_TUR = 0;
			this.ImpBillHandling_TUR = 0;
			this.Collecting_TUR = 0;
			this.Payment_TUR = 0;
			this.Remittance_TUR = 0;
			this.Loan_TUR = 0;
			this.Others01_TUR = 0;
			this.ForeignExchangePL_TUR = 0;
			this.Others02_TUR = 0;
			this.DocLC_INC = 0;
			this.ExpBillHandling_INC = 0;
			this.ImpBillHandling_INC = 0;
			this.Collecting_INC = 0;
			this.Payment_INC = 0;
			this.Remittance_INC = 0;
			this.Loan_INC = 0;
			this.Others01_INC = 0;
			this.ForeignExchangePL_INC = 0;
			this.Others02_INC = 0;
		}


		public clsCPACustomerDTO(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			CPAStatus = (byte) row["CPA_Status"];
			CustomerName = ((string) row["Name"]).Trim();
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			try
			{
				JPAcc = ((string) row["JPAcc"]).Trim();
			}
			catch (Exception)
			{
				JPAcc = "";
			}
			try
			{
				VNAcc = ((string) row["VNAcc"]).Trim();
			}
			catch (Exception)
			{
				VNAcc = "";
			}
			try
			{
				Team = ((string) row["Team"]).Trim();
			}
			catch (Exception)
			{
				Team = "";
			}
			try
			{
				_customerShortName = ((string) row["ShortName"]).Trim();
			}
			catch (Exception)
			{
				_customerShortName = "";
			}


			this.STL_Overdraft_AVE = CheckNull(row["STL_Overdraft_AVE"]);
			this.STL_CommercialBill_AVE = CheckNull(row["STL_CommercialBill_AVE"]);
			this.STL_Loan_AVE = CheckNull(row["STL_Loan_AVE"]);
			this.STL_Overdraft_REC = CheckNull(row["STL_Overdraft_REC"]);
			this.STL_CommercialBill_REC = CheckNull(row["STL_CommercialBill_REC"]);
			this.STL_Loan_REC = CheckNull(row["STL_Loan_REC"]);
			this.STL_Overdraft_PAY = CheckNull(row["STL_Overdraft_PAY"]);
			this.STL_CommercialBill_PAY = CheckNull(row["STL_CommercialBill_PAY"]);
			this.STL_Loan_PAY = CheckNull(row["STL_Loan_PAY"]);
			this.LTL_Fixed_AVE = CheckNull(row["LTL_Fixed_AVE"]);
			this.LTL_Floating_AVE = CheckNull(row["LTL_Floating_AVE"]);
			this.LTL_Fixed_REC = CheckNull(row["LTL_Fixed_REC"]);
			this.LTL_Floating_REC = CheckNull(row["LTL_Floating_REC"]);
			this.LTL_Fixed_PAY = CheckNull(row["LTL_Fixed_PAY"]);
			this.LTL_Floating_PAY = CheckNull(row["LTL_Floating_PAY"]);
			this.BB_AVE = CheckNull(row["BB_AVE"]);
			this.BR_AVE = CheckNull(row["BR_AVE"]);
			this.BB_REC = CheckNull(row["BB_REC"]);
			this.BR_REC = CheckNull(row["BR_REC"]);
			this.BB_PAY = CheckNull(row["BB_PAY"]);
			this.BR_PAY = CheckNull(row["BR_PAY"]);
			this.OtherApp_AVE = CheckNull(row["OtherApp_AVE"]);
			this.OtherApp_REC = CheckNull(row["OtherApp_REC"]);
			this.OtherApp_PAY = CheckNull(row["OtherApp_PAY"]);
			this.Dep_Liquid_AVE = CheckNull(row["Dep_Liquid_AVE"]);
			this.Dep_Fixed_AVE = CheckNull(row["Dep_Fixed_AVE"]);
			this.Dep_Liquid_REC = CheckNull(row["Dep_Liquid_REC"]);
			this.Dep_Fixed_REC = CheckNull(row["Dep_Fixed_REC"]);
			this.Dep_Liquid_PAY = CheckNull(row["Dep_Liquid_PAY"]);
			this.Dep_Fixed_PAY = CheckNull(row["Dep_Fixed_PAY"]);
			this.OtherSource_AVE = CheckNull(row["OtherSource_AVE"]);
			this.OtherSource_REC = CheckNull(row["OtherSource_REC"]);
			this.OtherSource_PAY = CheckNull(row["OtherSource_PAY"]);
			this.ReserveReq_AVE = CheckNull(row["ReserveReq_AVE"]);
			this.ReserveReq_REC = CheckNull(row["ReserveReq_REC"]);
			this.ReserveReq_PAY = CheckNull(row["ReserveReq_PAY"]);
			this.Guarantee_AVE = CheckNull(row["Guarantee_AVE"]);
			this.CleanLC_AVE = CheckNull(row["CleanLC_AVE"]);
			this.Acceptance_AVE = CheckNull(row["Acceptance_AVE"]);
			this.Commitment_AVE = CheckNull(row["Commitment_AVE"]);
			this.Others_AVE = CheckNull(row["Others_AVE"]);
			this.Guarantee_INC = CheckNull(row["Guarantee_INC"]);
			this.CleanLC_INC = CheckNull(row["CleanLC_INC"]);
			this.Acceptance_INC = CheckNull(row["Acceptance_INC"]);
			this.Commitment_INC = CheckNull(row["Commitment_INC"]);
			this.Others_INC = CheckNull(row["Others_INC"]);
			this.DocLC_TUR = CheckNull(row["DocLC_TUR"]);
			this.ExpBillHandling_TUR = CheckNull(row["ExpBillHandling_TUR"]);
			this.ImpBillHandling_TUR = CheckNull(row["ImpBillHandling_TUR"]);
			this.Collecting_TUR = CheckNull(row["Collecting_TUR"]);
			this.Payment_TUR = CheckNull(row["Payment_TUR"]);
			this.Remittance_TUR = CheckNull(row["Remittance_TUR"]);
			this.Loan_TUR = CheckNull(row["Loan_TUR"]);
			this.Others01_TUR = CheckNull(row["Others01_TUR"]);
			this.ForeignExchangePL_TUR = CheckNull(row["ForeignExchangePL_TUR"]);
			this.Others02_TUR = CheckNull(row["Others02_TUR"]);
			this.DocLC_INC = CheckNull(row["DocLC_INC"]);
			this.ExpBillHandling_INC = CheckNull(row["ExpBillHandling_INC"]);
			this.ImpBillHandling_INC = CheckNull(row["ImpBillHandling_INC"]);
			this.Collecting_INC = CheckNull(row["Collecting_INC"]);
			this.Payment_INC = CheckNull(row["Payment_INC"]);
			this.Remittance_INC = CheckNull(row["Remittance_INC"]);
			this.Loan_INC = CheckNull(row["Loan_INC"]);
			this.Others01_INC = CheckNull(row["Others01_INC"]);
			this.ForeignExchangePL_INC = CheckNull(row["ForeignExchangePL_INC"]);
			this.Others02_INC = CheckNull(row["Others02_INC"]);



		}



		/// <summary>
		/// Get CPACustomerDTO for report 09
		/// </summary>
		/// <param name="row"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		public clsCPACustomerDTO GetCPACustomerDTORerport09(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.CustomerName = ((string) row["Name"]).Trim();
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			try
			{
				JPAcc = ((string) row["JPAcc"]).Trim();
			}
			catch (Exception)
			{
				JPAcc = "";
			}
			try
			{
				VNAcc = ((string) row["VNAcc"]).Trim();
			}
			catch (Exception)
			{
				VNAcc = "";
			}
			try
			{
				Team = ((string) row["Team"]).Trim();
			}
			catch (Exception)
			{
				Team = "";
			}
			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			this.CPAStatus = (byte) row["CPA_Status"];
			this.Dep_Liquid_REC = CheckNull(row["Dep_Liquid_REC"]);
			this.Dep_Fixed_REC = CheckNull(row["Dep_Fixed_REC"]);
			this.Dep_Liquid_PAY = CheckNull(row["Dep_Liquid_PAY"]);
			this.Dep_Fixed_PAY = CheckNull(row["Dep_Fixed_PAY"]);
			return this;
		}

		/// <summary>
		/// Get CPACustomerDTO for report 10
		/// </summary>
		/// <param name="row"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		public clsCPACustomerDTO GetCPACustomerDTORerport10(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.CustomerName = ((string) row["Name"]).Trim();
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			try
			{
				JPAcc = ((string) row["JPAcc"]).Trim();
			}
			catch (Exception)
			{
				JPAcc = "";
			}
			try
			{
				VNAcc = ((string) row["VNAcc"]).Trim();
			}
			catch (Exception)
			{
				VNAcc = "";
			}
			try
			{
				Team = ((string) row["Team"]).Trim();
			}
			catch (Exception)
			{
				Team = "";
			}
			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			this.CPAStatus = (byte) row["CPA_Status"];
			this.STL_Overdraft_REC = CheckNull(row["STL_Overdraft_REC"]);
			this.STL_Overdraft_PAY = CheckNull(row["STL_Overdraft_PAY"]);
			this.STL_CommercialBill_REC = CheckNull(row["STL_CommercialBill_REC"]);
			this.STL_CommercialBill_PAY = CheckNull(row["STL_CommercialBill_PAY"]);
			this.STL_Loan_REC = CheckNull(row["STL_Loan_REC"]);
			this.STL_Loan_PAY = CheckNull(row["STL_Loan_PAY"]);
			this.LTL_Fixed_REC = CheckNull(row["LTL_Fixed_REC"]);
			this.LTL_Fixed_PAY = CheckNull(row["LTL_Fixed_PAY"]);
			this.LTL_Floating_REC = CheckNull(row["LTL_Floating_REC"]);
			this.LTL_Floating_PAY = CheckNull(row["LTL_Floating_PAY"]);
			return this;
		}

		/// <summary>
		/// Get top CPACustomerDTO for report 11        
		/// </summary>
		/// <param name="row"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		public clsCPACustomerDTO GetCPACustomerDTOTopRerport11(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.CustomerName = ((string) row["Name"]).Trim();
            this.ReportStatus = (bool)row["ReportStatus"];
			this.CPAStatus = this.CPAStatus = (byte) row["CPA_Status"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			this.Report_Value = CheckNull(row["REPORT_VALUE"]);
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
           
            try
            {
                JPAcc = ((string)row["JPAcc"]).Trim();
            }
            catch (Exception)
            {
                JPAcc = "";
            }
            try
            {
                VNAcc = ((string)row["VNAcc"]).Trim();
            }
            catch (Exception)
            {
                VNAcc = "";
            }
            try
            {
                Team = ((string)row["Team"]).Trim();
            }
            catch (Exception)
            {
                Team = "";
            }

			return this;
		}

		/// <summary>
		/// Get CPACustomerDTO for report 11
		/// </summary>
		/// <param name="row"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		public clsCPACustomerDTO GetCPACustomerDTORerport11(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.CustomerName = ((string) row["Name"]).Trim();
			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			this.CPAStatus = (byte) row["CPA_Status"];
			this.Dep_Liquid_AVE = CheckNull(row["Dep_Liquid_AVE"]);
			this.Dep_Fixed_AVE = CheckNull(row["Dep_Fixed_AVE"]);
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			return this;
		}

		/// <summary>
		/// Get CPACustomerDTO for report 12
		/// </summary>
		/// <param name="row"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond        
		public clsCPACustomerDTO GetCPACustomerDTORerport12(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.CustomerName = ((string) row["Name"]).Trim();
			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			this.CPAStatus = (byte) row["CPA_Status"];
			this.STL_Overdraft_AVE = CheckNull(row["STL_Overdraft_AVE"]);
			this.STL_CommercialBill_AVE = CheckNull(row["STL_CommercialBill_AVE"]);
			this.STL_Loan_AVE = CheckNull(row["STL_Loan_AVE"]);
			this.LTL_Fixed_AVE = CheckNull(row["LTL_Fixed_AVE"]);
			this.LTL_Floating_AVE = CheckNull(row["LTL_Floating_AVE"]);
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			return this;
		}

		/// <summary>
		/// Get CPACustomerDTO for report 13
		/// </summary>
		/// <param name="row"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		public clsCPACustomerDTO GetCPACustomerDTORerport13(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.CustomerName = ((string) row["Name"]).Trim();
			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			this.CPAStatus = (byte) row["CPA_Status"];
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];

			this.Guarantee_INC = CheckNull(row["Guarantee_INC"]);
			this.CleanLC_INC = CheckNull(row["CleanLC_INC"]);
			this.Acceptance_INC = CheckNull(row["Acceptance_INC"]);
			this.Commitment_INC = CheckNull(row["Commitment_INC"]);
			this.Others_INC = CheckNull(row["Others_INC"]);

			this.DocLC_INC = CheckNull(row["DocLC_INC"]);
			this.ExpBillHandling_INC = CheckNull(row["ExpBillHandling_INC"]);
			this.ImpBillHandling_INC = CheckNull(row["ImpBillHandling_INC"]);
			this.Collecting_INC = CheckNull(row["Collecting_INC"]);

			this.Payment_INC = CheckNull(row["Payment_INC"]);
			this.Remittance_INC = CheckNull(row["Remittance_INC"]);
			this.Loan_INC = CheckNull(row["Loan_INC"]);
			this.Others01_INC = CheckNull(row["Others01_INC"]);
			this.Others02_INC = CheckNull(row["Others02_INC"]);

			this.ForeignExchangePL_INC = CheckNull(row["ForeignExchangePL_INC"]);
			this.Dep_Liquid_REC = CheckNull(row["Dep_Liquid_REC"]);
			this.Dep_Liquid_PAY = CheckNull(row["Dep_Liquid_PAY"]);
			this.Dep_Fixed_REC = CheckNull(row["Dep_Fixed_REC"]);
			this.Dep_Fixed_PAY = CheckNull(row["Dep_Fixed_PAY"]);

			this.STL_Overdraft_REC = CheckNull(row["STL_Overdraft_REC"]);
			this.STL_Overdraft_PAY = CheckNull(row["STL_Overdraft_PAY"]);
			this.STL_CommercialBill_REC = CheckNull(row["STL_CommercialBill_REC"]);
			this.STL_CommercialBill_PAY = CheckNull(row["STL_CommercialBill_PAY"]);
			this.STL_Loan_REC = CheckNull(row["STL_Loan_REC"]);
			this.STL_Loan_PAY = CheckNull(row["STL_Loan_PAY"]);

			this.LTL_Fixed_REC = CheckNull(row["LTL_Fixed_REC"]);
			this.LTL_Fixed_PAY = CheckNull(row["LTL_Fixed_PAY"]);
			this.LTL_Floating_REC = CheckNull(row["LTL_Floating_REC"]);
			this.LTL_Floating_PAY = CheckNull(row["LTL_Floating_PAY"]);
			return this;
		}

		/// <summary>
		/// Get top CPACustomerDTO for report 03
		/// </summary>
		/// <param name="row"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		public clsCPACustomerDTO GetCPACustomerDTOTopRerport03(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.CustomerName = ((string) row["Name"]).Trim();
			this.CPAStatus = (byte) row["CPA_Status"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
            this.ReportStatus = (bool)row["ReportStatus"];
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			this.Report_Value = CheckNull(row["REPORT_VALUE"]);
			try
			{
				JPAcc = ((string) row["JPAcc"]).Trim();
			}
			catch (Exception)
			{
				JPAcc = "";
			}
			try
			{
				VNAcc = ((string) row["VNAcc"]).Trim();
			}
			catch (Exception)
			{
				VNAcc = "";
			}
			try
			{
				Team = ((string) row["Team"]).Trim();
			}
			catch (Exception)
			{
				Team = "";
			}
			return this;
		}

		/// <summary>
		/// Get CPACustomerDTO for report 03
		/// </summary>
		/// <param name="row"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		public clsCPACustomerDTO GetCPACustomerDTORerport03(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.CustomerName = ((string) row["Name"]).Trim();
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			//this.Team = (string)row["Team"];

			this.Team = row["Team"].GetType() == typeof(DBNull) ? "" : ((string) row["Team"]).Trim();
			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			this.CPAStatus = (byte) row["CPA_Status"];

			this.STL_Overdraft_REC = CheckNull(row["STL_Overdraft_REC"]);
			this.STL_Overdraft_PAY = CheckNull(row["STL_Overdraft_PAY"]);
			this.STL_CommercialBill_REC = CheckNull(row["STL_CommercialBill_REC"]);
			this.STL_CommercialBill_PAY = CheckNull(row["STL_CommercialBill_PAY"]);
			this.STL_Loan_REC = CheckNull(row["STL_Loan_REC"]);

			this.STL_Loan_PAY = CheckNull(row["STL_Loan_PAY"]);
			this.LTL_Fixed_REC = CheckNull(row["LTL_Fixed_REC"]);
			this.LTL_Fixed_PAY = CheckNull(row["LTL_Fixed_PAY"]);
			this.LTL_Floating_REC = CheckNull(row["LTL_Floating_REC"]);

			this.LTL_Floating_PAY = CheckNull(row["LTL_Floating_PAY"]);
			this.BB_REC = CheckNull(row["BB_REC"]);
			this.BB_PAY = CheckNull(row["BB_PAY"]);
			this.BR_REC = CheckNull(row["BR_REC"]);
			this.BR_PAY = CheckNull(row["BR_PAY"]);

			this.OtherApp_REC = CheckNull(row["OtherApp_REC"]);
			this.OtherApp_PAY = CheckNull(row["OtherApp_PAY"]);
			this.Dep_Liquid_REC = CheckNull(row["Dep_Liquid_REC"]);
			this.Dep_Liquid_PAY = CheckNull(row["Dep_Liquid_PAY"]);
			this.Dep_Fixed_REC = CheckNull(row["Dep_Fixed_REC"]);

			this.Dep_Fixed_PAY = CheckNull(row["Dep_Fixed_PAY"]);
			this.OtherSource_REC = CheckNull(row["OtherSource_REC"]);
			this.OtherSource_PAY = CheckNull(row["OtherSource_PAY"]);
			this.ReserveReq_REC = CheckNull(row["ReserveReq_REC"]);
			this.ReserveReq_PAY = CheckNull(row["ReserveReq_PAY"]);
			this.Guarantee_INC = CheckNull(row["Guarantee_INC"]);

			this.CleanLC_INC = CheckNull(row["CleanLC_INC"]);
			this.Acceptance_INC = CheckNull(row["Acceptance_INC"]);
			this.Commitment_INC = CheckNull(row["Commitment_INC"]);
			this.Others_INC = CheckNull(row["Others_INC"]);
			this.DocLC_INC = CheckNull(row["DocLC_INC"]);

			this.ExpBillHandling_INC = CheckNull(row["ExpBillHandling_INC"]);
			this.ImpBillHandling_INC = CheckNull(row["ImpBillHandling_INC"]);
			this.Collecting_INC = CheckNull(row["Collecting_INC"]);
			this.Payment_INC = CheckNull(row["Payment_INC"]);

			this.Remittance_INC = CheckNull(row["Remittance_INC"]);
			this.Loan_INC = CheckNull(row["Loan_INC"]);
			this.Others01_INC = CheckNull(row["Others01_INC"]);
			this.ForeignExchangePL_INC = CheckNull(row["ForeignExchangePL_INC"]);
			this.Others02_INC = CheckNull(row["Others02_INC"]);
			return this;
		}

		/// <summary>
		/// report 6
		/// </summary>
		/// <returns></returns>
		public Int64 GetCommissionFee()
		{
			return _Guarantee_INC + _CleanLC_INC + _Acceptance_INC + _Commitment_INC
					+ _Others_INC + _DocLC_INC + _ExpBillHandling_INC + _ImpBillHandling_INC
					+ _Collecting_INC + _Payment_INC + _Remittance_INC + _Loan_INC + _Others01_INC + _Others02_INC;
		}
		/// <summary>
		/// report 9
		/// </summary>
		/// <returns></returns>
		public Int64 GetProfitDeposit()
		{
			return (_Dep_Liquid_REC - _Dep_Liquid_PAY) + (_Dep_Fixed_REC - _Dep_Fixed_PAY);
		}
		/// <summary>
		/// report 10
		/// </summary>
		/// <returns></returns>
		public Int64 GetProfitOfLoan()
		{
			return (_STL_Overdraft_REC - _STL_Overdraft_PAY) +
			(_STL_CommercialBill_REC - _STL_CommercialBill_PAY) +
			(_STL_Loan_REC - _STL_Loan_PAY) +
			(_LTL_Fixed_REC - _LTL_Fixed_PAY) +
			(_LTL_Floating_REC - _LTL_Floating_PAY);
		}
		/// <summary>
		/// report 11
		/// </summary>
		/// <returns></returns>
		public Int64 GetTermsOfDepositAverageBalance()
		{
			return (_Dep_Liquid_AVE + _Dep_Fixed_AVE);
		}

		/// <summary>
		/// report 12
		/// </summary>
		/// <returns></returns>
		public Int64 GetTermsOfLoanAverageBalance()
		{
			return (_STL_Overdraft_AVE + _STL_CommercialBill_AVE + _STL_Loan_AVE + _LTL_Fixed_AVE + _LTL_Floating_AVE);
		}

		/// <summary>
		/// report 8 = 6+7+9+10
		/// </summary>
		/// <returns></returns>
		public Int64 GetTotalProfit()
		{
			return GetCommissionFee() + GetProfitDeposit() + GetProfitOfLoan() + _ForeignExchangePL_INC;
		}

		/// <summary>
		/// report 1,2 ,3
		/// </summary>
		/// <returns></returns>
		public Int64 GetCPaByAccount()
		{
			return (STL_Overdraft_REC - STL_Overdraft_PAY) + (STL_CommercialBill_REC - STL_CommercialBill_PAY)
			 + (STL_Loan_REC - STL_Loan_PAY)
			 + (LTL_Fixed_REC - LTL_Fixed_PAY) + (LTL_Floating_REC - LTL_Floating_PAY)
			 + (BB_REC - BB_PAY) + (BR_REC - BR_PAY) + (OtherApp_REC - OtherApp_PAY)
			 + (Dep_Liquid_REC - Dep_Liquid_PAY) + (Dep_Fixed_REC - Dep_Fixed_PAY)
			 + (OtherSource_REC - OtherSource_PAY)
			 + (ReserveReq_REC - ReserveReq_PAY)
			 + (Guarantee_INC + CleanLC_INC + Acceptance_INC + Commitment_INC + Others_INC)
			 + (DocLC_INC + ExpBillHandling_INC + ImpBillHandling_INC + Collecting_INC + Payment_INC + Remittance_INC + Loan_INC
			 + Others01_INC + ForeignExchangePL_INC + Others02_INC);

		}
		/// <summary>
		/// report 4
		/// </summary>
		/// <returns></returns>
		public Int64 GetDepositAverageBalance()
		{
			return _Dep_Liquid_AVE + _Dep_Fixed_AVE;
		}

		/// <summary>
		/// report 5
		/// </summary>
		/// <returns></returns>
		public Int64 GetLoanAverageBalance()
		{
			return _STL_Overdraft_AVE + _STL_CommercialBill_AVE + _STL_Loan_AVE + LTL_Fixed_AVE + _LTL_Floating_AVE;
		}

		/// <summary>
		/// report 15
		/// </summary>
		/// <returns></returns>
		public Int64 GetLoanBal()
		{
			return STL_Overdraft_AVE + STL_CommercialBill_AVE + STL_Loan_AVE + LTL_Fixed_AVE + LTL_Floating_AVE;
		}
		/// <summary>
		/// report 15
		/// </summary>
		/// <returns></returns>
		public Int64 GetDeposit()
		{
			return Dep_Liquid_AVE + Dep_Fixed_AVE;
		}
	}
}