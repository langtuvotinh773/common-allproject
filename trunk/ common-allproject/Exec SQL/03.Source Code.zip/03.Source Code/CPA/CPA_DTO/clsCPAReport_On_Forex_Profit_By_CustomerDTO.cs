﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-01-31 20:37:30 +0700 (Thu, 31 Jan 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for Report_On_Forex_Profit_By_Customer
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Config.Classes;
namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// This class use for create object CPA customermer in report
    /// </summary>
	public class clsCPAReport_On_Forex_Profit_By_CustomerDTO
	{
		clsCommonFunctions m_CommonFunction = new clsCommonFunctions();
		private string _YearMonth;

		public string YearMonth
		{
			get { return _YearMonth; }
			set { _YearMonth = value; }
		}
		private string _CustomerID;
		public string CustomerID
		{
			get { return _CustomerID; }
			set { _CustomerID = value; }
		}

		private bool _ReportStatus;

		public bool ReportStatus
		{
			get { return _ReportStatus; }
			set { _ReportStatus = value; }
		}

		private string _jnj;

		public string JNJ
		{
			get { return _jnj; }
			set { _jnj = value; }
		}

		private byte _CPAStatus;

		public byte CPAStatus
		{
			get { return _CPAStatus; }
			set { _CPAStatus = value; }
		}

		private string _CustomerName;

		public string CustomerName
		{
			get { return _CustomerName; }
			set { _CustomerName = value; }
		}
		private string _JPAcc;

		public string JPAcc
		{
			get { return _JPAcc; }
			set { _JPAcc = value; }
		}
		private string _VNAcc;

		public string VNAcc
		{
			get { return _VNAcc; }
			set { _VNAcc = value; }
		}

		private Int64 _Report_Value;
		public Int64 Report_Value
		{
			get { return _Report_Value; }
			set { _Report_Value = value; }
		}

		private string _team;

		public string Team
		{
			get { return _team; }
			set { _team = value; }
		}
		private long _CalItem;

		public long CalItem
		{
			get { return _CalItem; }
			set { _CalItem = value; }
		}
		private Int64 _ForeignExchangePL_INC;

		public Int64 ForeignExchangePL_INC
		{
			get { return _ForeignExchangePL_INC; }
			set { _ForeignExchangePL_INC = value; }
		}

        private string shortJP;

        public string ShortJP
        {
            get { return shortJP; }
            set { shortJP = value; }
        }
        private string shortVN;

        public string ShortVN
        {
            get { return shortVN; }
            set { shortVN = value; }
        }
		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsCPAReport_On_Forex_Profit_By_CustomerDTO() { }

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="row"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsCPAReport_On_Forex_Profit_By_CustomerDTO(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			this.ForeignExchangePL_INC = m_CommonFunction.CheckNullInt64(row["ForeignExchangePL_INC"]);

			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			CPAStatus = (byte) row["CPA_Status"];
			CustomerName = ((string) row["Name"]).Trim();
			try
			{
				JPAcc = ((string) row["JPAcc"]).Trim();
			}
			catch (Exception)
			{
				JPAcc = "";
			}
			try
			{
				VNAcc = ((string) row["VNAcc"]).Trim();
			}
			catch (Exception)
			{
				VNAcc = "";
			}
			try
			{
				Team = ((string) row["Team"]).Trim();
			}
			catch (Exception)
			{
				Team = "";
			}
		}
		/// <summary>
		/// report 7
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public Int64 Rpt07GetForeignExchangePLINC()
		{
			return _ForeignExchangePL_INC;
		}
	}
}