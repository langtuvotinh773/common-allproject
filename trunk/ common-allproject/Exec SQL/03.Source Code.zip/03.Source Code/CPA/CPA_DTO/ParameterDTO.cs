﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Parameter object
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// this class user for store Paramater infomation(Error type, JNJ, Module..)
    /// </summary>
    public class ParameterDTO
    {
        private string value;

        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public ParameterDTO()
        {
            value = "";
            name = "";
        }
        public ParameterDTO(DataRow row)
        {
            value = ((string)row["Value"]).Trim();
            name = ((string)row["Name"]).Trim();
        }
    }
}
