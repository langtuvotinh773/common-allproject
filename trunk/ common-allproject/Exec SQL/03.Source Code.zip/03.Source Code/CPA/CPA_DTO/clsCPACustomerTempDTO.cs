﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Temp CPA Customer object
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// this class use to create CPA Customer
    /// </summary>
    public class clsCPACustomerTempDTO
    {
        private string _YearMonth;

        public string YearMonth
        {
            get { return _YearMonth; }
            set { _YearMonth = value; }
        }
        private string _CustomerID;

        public string CustomerID
        {
            get { return _CustomerID; }
            set { _CustomerID = value; }
        }
        private int _STL_Overdraft_AVE;

        public int STL_Overdraft_AVE
        {
            get { return _STL_Overdraft_AVE; }
            set { _STL_Overdraft_AVE = value; }
        }
        private int _STL_CommercialBill_AVE;

        public int STL_CommercialBill_AVE
        {
            get { return _STL_CommercialBill_AVE; }
            set { _STL_CommercialBill_AVE = value; }
        }
        private int _STL_Loan_AVE;

        public int STL_Loan_AVE
        {
            get { return _STL_Loan_AVE; }
            set { _STL_Loan_AVE = value; }
        }
        private int _STL_Overdraft_REC;

        public int STL_Overdraft_REC
        {
            get { return _STL_Overdraft_REC; }
            set { _STL_Overdraft_REC = value; }
        }
        private int _STL_CommercialBill_REC;

        public int STL_CommercialBill_REC
        {
            get { return _STL_CommercialBill_REC; }
            set { _STL_CommercialBill_REC = value; }
        }
        private int _STL_Loan_REC;

        public int STL_Loan_REC
        {
            get { return _STL_Loan_REC; }
            set { _STL_Loan_REC = value; }
        }
        private int _STL_Overdraft_PAY;

        public int STL_Overdraft_PAY
        {
            get { return _STL_Overdraft_PAY; }
            set { _STL_Overdraft_PAY = value; }
        }
        private int _STL_CommercialBill_PAY;

        public int STL_CommercialBill_PAY
        {
            get { return _STL_CommercialBill_PAY; }
            set { _STL_CommercialBill_PAY = value; }
        }
        private int _STL_Loan_PAY;

        public int STL_Loan_PAY
        {
            get { return _STL_Loan_PAY; }
            set { _STL_Loan_PAY = value; }
        }
        private int _LTL_Fixed_AVE;

        public int LTL_Fixed_AVE
        {
            get { return _LTL_Fixed_AVE; }
            set { _LTL_Fixed_AVE = value; }
        }
        private int _LTL_Floating_AVE;

        public int LTL_Floating_AVE
        {
            get { return _LTL_Floating_AVE; }
            set { _LTL_Floating_AVE = value; }
        }
        private int _LTL_Fixed_REC;

        public int LTL_Fixed_REC
        {
            get { return _LTL_Fixed_REC; }
            set { _LTL_Fixed_REC = value; }
        }
        private int _LTL_Floating_REC;

        public int LTL_Floating_REC
        {
            get { return _LTL_Floating_REC; }
            set { _LTL_Floating_REC = value; }
        }
        private int _LTL_Fixed_PAY;

        public int LTL_Fixed_PAY
        {
            get { return _LTL_Fixed_PAY; }
            set { _LTL_Fixed_PAY = value; }
        }
        private int _LTL_Floating_PAY;

        public int LTL_Floating_PAY
        {
            get { return _LTL_Floating_PAY; }
            set { _LTL_Floating_PAY = value; }
        }
        private int __BB_AVE;

        public int _BB_AVE
        {
            get { return __BB_AVE; }
            set { __BB_AVE = value; }
        }
        private int _BR_AVE;

        public int BR_AVE
        {
            get { return _BR_AVE; }
            set { _BR_AVE = value; }
        }
        private int _BB_REC;

        public int BB_REC
        {
            get { return _BB_REC; }
            set { _BB_REC = value; }
        }
        private int _BR_REC;

        public int BR_REC
        {
            get { return _BR_REC; }
            set { _BR_REC = value; }
        }
        private int _BB_PAY;

        public int BB_PAY
        {
            get { return _BB_PAY; }
            set { _BB_PAY = value; }
        }
        private int _BR_PAY;

        public int BR_PAY
        {
            get { return _BR_PAY; }
            set { _BR_PAY = value; }
        }
        private int _OtherApp_AVE;

        public int OtherApp_AVE
        {
            get { return _OtherApp_AVE; }
            set { _OtherApp_AVE = value; }
        }
        private int _OtherApp_REC;

        public int OtherApp_REC
        {
            get { return _OtherApp_REC; }
            set { _OtherApp_REC = value; }
        }
        private int _OtherApp_PAY;

        public int OtherApp_PAY
        {
            get { return _OtherApp_PAY; }
            set { _OtherApp_PAY = value; }
        }
        private int _Dep_Liquid_AVE;

        public int Dep_Liquid_AVE
        {
            get { return _Dep_Liquid_AVE; }
            set { _Dep_Liquid_AVE = value; }
        }
        private int _Dep_Fixed_AVE;

        public int Dep_Fixed_AVE
        {
            get { return _Dep_Fixed_AVE; }
            set { _Dep_Fixed_AVE = value; }
        }
        private int _Dep_Liquid_REC;

        public int Dep_Liquid_REC
        {
            get { return _Dep_Liquid_REC; }
            set { _Dep_Liquid_REC = value; }
        }
        private int _Dep_Fixed_REC;

        public int Dep_Fixed_REC
        {
            get { return _Dep_Fixed_REC; }
            set { _Dep_Fixed_REC = value; }
        }
        private int _Dep_Liquid_PAY;

        public int Dep_Liquid_PAY
        {
            get { return _Dep_Liquid_PAY; }
            set { _Dep_Liquid_PAY = value; }
        }
        private int _Dep_Fixed_PAY;

        public int Dep_Fixed_PAY
        {
            get { return _Dep_Fixed_PAY; }
            set { _Dep_Fixed_PAY = value; }
        }
        private int _OtherSource_AVE;

        public int OtherSource_AVE
        {
            get { return _OtherSource_AVE; }
            set { _OtherSource_AVE = value; }
        }
        private int _OtherSource_REC;

        public int OtherSource_REC
        {
            get { return _OtherSource_REC; }
            set { _OtherSource_REC = value; }
        }
        private int _OtherSource_PAY;

        public int OtherSource_PAY
        {
            get { return _OtherSource_PAY; }
            set { _OtherSource_PAY = value; }
        }
        private int _ReserveReq_AVE;

        public int ReserveReq_AVE
        {
            get { return _ReserveReq_AVE; }
            set { _ReserveReq_AVE = value; }
        }
        private int _ReserveReq_REC;

        public int ReserveReq_REC
        {
            get { return _ReserveReq_REC; }
            set { _ReserveReq_REC = value; }
        }
        private int _ReserveReq_PAY;

        public int ReserveReq_PAY
        {
            get { return _ReserveReq_PAY; }
            set { _ReserveReq_PAY = value; }
        }
        private int _Guarantee_AVE;

        public int Guarantee_AVE
        {
            get { return _Guarantee_AVE; }
            set { _Guarantee_AVE = value; }
        }
        private int _CleanLC_AVE;

        public int CleanLC_AVE
        {
            get { return _CleanLC_AVE; }
            set { _CleanLC_AVE = value; }
        }
        private int _Acceptance_AVE;

        public int Acceptance_AVE
        {
            get { return _Acceptance_AVE; }
            set { _Acceptance_AVE = value; }
        }
        private int _Commitment_AVE;

        public int Commitment_AVE
        {
            get { return _Commitment_AVE; }
            set { _Commitment_AVE = value; }
        }
        private int _Others_AVE;

        public int Others_AVE
        {
            get { return _Others_AVE; }
            set { _Others_AVE = value; }
        }
        private int _Guarantee_INC;

        public int Guarantee_INC
        {
            get { return _Guarantee_INC; }
            set { _Guarantee_INC = value; }
        }
        private int _CleanLC_INC;

        public int CleanLC_INC
        {
            get { return _CleanLC_INC; }
            set { _CleanLC_INC = value; }
        }
        private int _Acceptance_INC;

        public int Acceptance_INC
        {
            get { return _Acceptance_INC; }
            set { _Acceptance_INC = value; }
        }
        private int _Commitment_INC;

        public int Commitment_INC
        {
            get { return _Commitment_INC; }
            set { _Commitment_INC = value; }
        }
        private int _Others_INC;

        public int Others_INC
        {
            get { return _Others_INC; }
            set { _Others_INC = value; }
        }
        private int _DocLC_TUR;

        public int DocLC_TUR
        {
            get { return _DocLC_TUR; }
            set { _DocLC_TUR = value; }
        }
        private int _ExpBillHandling_TUR;

        public int ExpBillHandling_TUR
        {
            get { return _ExpBillHandling_TUR; }
            set { _ExpBillHandling_TUR = value; }
        }
        private int _ImpBillHandling_TUR;

        public int ImpBillHandling_TUR
        {
            get { return _ImpBillHandling_TUR; }
            set { _ImpBillHandling_TUR = value; }
        }
        private int _Collecting_TUR;

        public int Collecting_TUR
        {
            get { return _Collecting_TUR; }
            set { _Collecting_TUR = value; }
        }
        private int _Payment_TUR;

        public int Payment_TUR
        {
            get { return _Payment_TUR; }
            set { _Payment_TUR = value; }
        }
        private int _Remittance_TUR;

        public int Remittance_TUR
        {
            get { return _Remittance_TUR; }
            set { _Remittance_TUR = value; }
        }
        private int _Loan_TUR;

        public int Loan_TUR
        {
            get { return _Loan_TUR; }
            set { _Loan_TUR = value; }
        }
        private int _Others01_TUR;

        public int Others01_TUR
        {
            get { return _Others01_TUR; }
            set { _Others01_TUR = value; }
        }
        private int _ForeignExchangePL_TUR;

        public int ForeignExchangePL_TUR
        {
            get { return _ForeignExchangePL_TUR; }
            set { _ForeignExchangePL_TUR = value; }
        }
        private int _Others02_TUR;

        public int Others02_TUR
        {
            get { return _Others02_TUR; }
            set { _Others02_TUR = value; }
        }
        private int _DocLC_INC;

        public int DocLC_INC
        {
            get { return _DocLC_INC; }
            set { _DocLC_INC = value; }
        }
        private int _ExpBillHandling_INC;

        public int ExpBillHandling_INC
        {
            get { return _ExpBillHandling_INC; }
            set { _ExpBillHandling_INC = value; }
        }
        private int _ImpBillHandling_INC;

        public int ImpBillHandling_INC
        {
            get { return _ImpBillHandling_INC; }
            set { _ImpBillHandling_INC = value; }
        }
        private int _Collecting_INC;

        public int Collecting_INC
        {
            get { return _Collecting_INC; }
            set { _Collecting_INC = value; }
        }
        private int _Payment_INC;

        public int Payment_INC
        {
            get { return _Payment_INC; }
            set { _Payment_INC = value; }
        }
        private int _Remittance_INC;

        public int Remittance_INC
        {
            get { return _Remittance_INC; }
            set { _Remittance_INC = value; }
        }
        private int _Loan_INC;

        public int Loan_INC
        {
            get { return _Loan_INC; }
            set { _Loan_INC = value; }
        }
        private int _Others01_INC;

        public int Others01_INC
        {
            get { return _Others01_INC; }
            set { _Others01_INC = value; }
        }
        private int _ForeignExchangePL_INC;

        public int ForeignExchangePL_INC
        {
            get { return _ForeignExchangePL_INC; }
            set { _ForeignExchangePL_INC = value; }
        }
        private int _Others02_INC;

        public int Others02_INC
        {
            get { return _Others02_INC; }
            set { _Others02_INC = value; }
        }
        private int _ReportStatus;

        public int ReportStatus
        {
            get { return _ReportStatus; }
            set { _ReportStatus = value; }
        }
    }
}
