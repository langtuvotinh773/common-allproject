﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define all Messages in CPA
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// This class use for store Customer Error infomation
    /// </summary>
    class clsCPACustomerErrorDTO
    {
        private string customerID;

        public string CustomerID
        {
            get { return customerID; }
            set { customerID = value; }
        }
        private string name;

        public string CustomerName
        {
            get { return name; }
            set { name = value; }
        }
        private string yearMonth;

        public string YearMonth
        {
            get { return yearMonth; }
            set { yearMonth = value; }
        }
        private string errorType;

        public string ErrorType
        {
            get { return errorType; }
            set { errorType = value; }
        }
        private string officerID;

        public string OfficerID
        {
            get { return officerID; }
            set { officerID = value; }
        }
        private string createdBy;

        public string CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }

        private string CheckNull(object input)
        {
            return input.GetType() == typeof(DBNull) ? "" : ((string)input).Trim();
        }
        public clsCPACustomerErrorDTO(DataRow row)
        {
            customerID = CheckNull(row["CustomerID"]);
            name = CheckNull(row["Name"]);
            yearMonth = CheckNull(row["YearMonth"]);
            createdBy = row["CreatedBy"] == DBNull.Value ? "" :((string)row["CreatedBy"]).ToString();
            errorType = row["Errortype"] == DBNull.Value ? "" :((byte)row["Errortype"]).ToString("00");
            officerID = row["OfficerID"] == DBNull.Value ? "" : ((string)row["OfficerID"]).ToString();
        }
        public clsCPACustomerErrorDTO()
        {
            customerID = "";
            name = "";
            yearMonth = "";
            createdBy = "";
            errorType = "";
            officerID = "";
        }
    }
}
