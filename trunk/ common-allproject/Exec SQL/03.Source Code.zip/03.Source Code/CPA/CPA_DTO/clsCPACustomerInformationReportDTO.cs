﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-02-25 20:37:30 +0700 (Mon, 25 Feb 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for report customer information
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// This class use for create object CPA customermer in report
    /// </summary>
	public class clsCPACustomerInformationReportDTO
	{
		private string _customerCode;
		public string CustomerCode
		{
			get { return _customerCode; }
			set { _customerCode = value; }
		}
		private string _customerName;
		public string CustomerName
		{
			get { return _customerName; }
			set { _customerName = value; }
		}
		private string _customerShortName;
		public string CustomerShortName
		{
			get { return _customerShortName; }
			set { _customerShortName = value; }
		}
		private string _sortingIndex;
		public string SortingIndex
		{
			get { return _sortingIndex; }
			set { _sortingIndex = value; }
		}

        private string _postal;

        public string Postal
        {
            get { return _postal; }
            set { _postal = value; }
        }
		private string _telephone;
		public string Telephone
		{
			get { return _telephone; }
			set { _telephone = value; }
		}
		private string _fax;
		public string Fax
		{
			get { return _fax; }
			set { _fax = value; }
		}
		private string _address;
		public string Address
		{
			get { return _address; }
			set { _address = value; }
		}
		private string _location;
		public string Location
		{
			get { return _location; }
			set { _location = value; }
		}
		private string _industryCode;
		public string IndustryCode
		{
			get { return _industryCode; }
			set { _industryCode = value; }
		}

        private bool _cpaList;

        public bool CpaList
        {
            get { return _cpaList; }
            set { _cpaList = value; }
        }


		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsCPACustomerInformationReportDTO()
		{
			this.CustomerCode = "";
			this.CustomerName = "";
			this.CustomerShortName = "";
			this.SortingIndex = "";
			this.Telephone = "";
			this.Fax = "";
			this.Address = "";
			this.Location = "";
			this.IndustryCode = ""; 
		}

		/// <summary>
		/// Get data for customer information DTO
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public void GetReportCustomerInformationDTO()
		{
			this.CustomerCode = "customer code";
			this.CustomerName = "customer name";
			this.CustomerShortName = "short name";
			this.SortingIndex = "sorting index";
			this.Telephone = "telephone";
			this.Fax = "fax";
			this.Address = "address";
			this.Location = "Location";
			this.IndustryCode = "12345"; 
		}

	 
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="strCustomerCode"></param>
		/// <param name="strCustomerName"></param>
		/// <param name="strCustomerShortName"></param>
		/// <param name="strSortingIndex"></param>
		/// <param name="strTelephone"></param>
		/// <param name="strFax"></param>
		/// <param name="strAddress"></param>
		/// <param name="strLocation"></param>
		/// <param name="strIndustryCode"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsCPACustomerInformationReportDTO(string strCustomerCode, string strCustomerName, string strCustomerShortName, string strSortingIndex, string strTelephone, string strFax, string strAddress, string strLocation, string strIndustryCode,string strPostal,bool cpaList)
		{
			this.CustomerCode = strCustomerCode;
			this.CustomerName = strCustomerName;
			this.CustomerShortName = strCustomerShortName;
			this.SortingIndex = strSortingIndex;
			this.Telephone = strTelephone;
			this.Fax = strFax;
			this.Address = strAddress;
			this.Location = strLocation;
			this.IndustryCode = strIndustryCode;
            _postal = strPostal;
            _cpaList = cpaList;
		}
		/// <summary>
		/// Fill data for Customer information report DTO
		/// </summary>
		/// <param name="strCustomerCode"></param>
		/// <param name="strCustomerName"></param>
		/// <param name="strCustomerShortName"></param>
		/// <param name="strSortingIndex"></param>
		/// <param name="strTelephone"></param>
		/// <param name="strFax"></param>
		/// <param name="strAddress"></param>
		/// <param name="strLocation"></param>
		/// <param name="strIndustryCode"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public void FillReportCustomerInformationDTO(string strCustomerCode, string strCustomerName, string strCustomerShortName, string strSortingIndex, string strTelephone, string strFax, string strAddress, string strLocation, string strIndustryCode)
		{
			this.CustomerCode = strCustomerCode;
			this.CustomerName = strCustomerName;
			this.CustomerShortName = strCustomerShortName;
			this.SortingIndex = strSortingIndex;
			this.Telephone = strTelephone;
			this.Fax = strFax;
			this.Address = strAddress;
			this.Location = strLocation;
			this.IndustryCode = strIndustryCode; 
		}
	}
}