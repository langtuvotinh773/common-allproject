﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define User DTO object
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Config.Classes;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// this class use to create User
    /// </summary>
    public class UserDTO
    {

        private string departmentID;

        public string DepartmentID
        {
            get { return departmentID; }
            set { departmentID = value; }
        }

        private string sectionID;

        public string SectionID
        {
            get { return sectionID; }
            set { sectionID = value; }
        }

        private string userID;

        public string UserID
        {
            get { return userID; }
            set { userID = value; }
        }
        private string userName;

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }
        private byte userType;

        public byte UserType
        {
            get { return userType; }
            set { userType = value; }
        }
        private string teamType;

        public string TeamType
        {
            get { return teamType; }
            set { teamType = value; }
        }


        public UserDTO()
        {
            departmentID = "";
            sectionID = "";
            userID = "";
            userName = "";
            userType =0;
        }

        public UserDTO(DataRow row)
        {
            try
            {
                departmentID = ((Int16)row["DepartmentID"]).ToString();
            }
            catch(Exception)
            {
            }
            try
            {
                sectionID = ((Int16)row["TeamID"]).ToString();
            }
            catch (Exception)
            {
                sectionID = "";
            }
            userID = ((Int16)row["UserNo"]).ToString();
            userName = ((string)row["FullName"]).Trim();
            try
            {
                teamType = ((short)row["TeamTypeID"]).ToString();
            }
            catch (Exception ex)
            {
                teamType = "";
            }
            userType = 3;
            if ((row["Officer"]).GetType() != typeof(DBNull) && (bool)row["Officer"] ==true )
                userType =(int)CommonValue.UserType.JPAcc;
            if ((row["Staff01"]).GetType() != typeof(DBNull) && (bool)row["Staff01"] == true) userType = (int)CommonValue.UserType.VNAcc;

            if ((row["Officer"]).GetType() != typeof(DBNull) && (bool)row["Officer"] == true && (row["Staff01"]).GetType() != typeof(DBNull) && (bool)row["Staff01"] == true)
                 userType = (int)CommonValue.UserType.All;
           

        }
    }
}
