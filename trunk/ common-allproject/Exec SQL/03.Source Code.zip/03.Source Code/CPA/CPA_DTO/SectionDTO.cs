﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Section object
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// this class user for store Team infomation
    /// </summary>
    public class SectionDTO
    {
        private string departmentID;

        public string DepartmentID
        {
            get { return departmentID; }
            set { departmentID = value; }
        }

        private string sectionID;

        public string SectionID
        {
            get { return sectionID; }
            set { sectionID = value; }
        }
        private string sectionName;

        public string SectionName
        {
            get { return sectionName; }
            set { sectionName = value; }
        }
        public SectionDTO()
        {
            departmentID = "";
            sectionID = "";
            sectionName = "";
        }
        public SectionDTO(DataRow row)
        {
            departmentID = ((Int16)row["DepartmentID"]).ToString();
            sectionID = ((Int16)row["TeamID"]).ToString();
            sectionName = ((string)row["TeamName"]).Trim();
        }
    }
}
