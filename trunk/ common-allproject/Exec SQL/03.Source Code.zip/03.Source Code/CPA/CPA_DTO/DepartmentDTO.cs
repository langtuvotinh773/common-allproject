﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define Department object
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// this class use to create Department
    /// </summary>
    public class DepartmentDTO
    {
        private string departmentID;

        public string DepartmentID
        {
            get { return departmentID; }
            set { departmentID = value; }
        }
        private string departmentName;

        public string DepartmentName
        {
            get { return departmentName; }
            set { departmentName = value; }
        }
        public DepartmentDTO()
        {
            departmentID = "";
            departmentName = "";
        }
        public DepartmentDTO(DataRow row)
        {
            departmentID = ((Int16)row["DepartmentID"]).ToString();
            departmentName = ((string)row["DepartmentName"]).ToString() ;
        }
    }
}
