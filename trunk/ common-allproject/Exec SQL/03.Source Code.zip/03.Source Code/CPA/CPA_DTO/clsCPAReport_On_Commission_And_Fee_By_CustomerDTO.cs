﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-01-31 20:37:30 +0700 (Thu, 31 Jan 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for Report_On_Commission_And_Fee_By_CustomerDTO
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Config.Classes;
namespace Phoenix.Cpa.Dto
{
    /// <summary>
    /// This class use for create object CPA customermer in report
    /// </summary>
	public class clsCPAReport_On_Commission_And_Fee_By_CustomerDTO
	{
		clsCommonFunctions m_CommonFunction = new clsCommonFunctions();
		private string _YearMonth;

		public string YearMonth
		{
			get { return _YearMonth; }
			set { _YearMonth = value; }
		}
		private string _CustomerID;
		public string CustomerID
		{
			get { return _CustomerID; }
			set { _CustomerID = value; }
		}

		private bool _ReportStatus;

		public bool ReportStatus
		{
			get { return _ReportStatus; }
			set { _ReportStatus = value; }
		}

		private string _jnj;

		public string JNJ
		{
			get { return _jnj; }
			set { _jnj = value; }
		}

		private byte _CPAStatus;

		public byte CPAStatus
		{
			get { return _CPAStatus; }
			set { _CPAStatus = value; }
		}

		private string _CustomerName;

		public string CustomerName
		{
			get { return _CustomerName; }
			set { _CustomerName = value; }
		}
		private string _JPAcc;

		public string JPAcc
		{
			get { return _JPAcc; }
			set { _JPAcc = value; }
		}
		private string _VNAcc;

		public string VNAcc
		{
			get { return _VNAcc; }
			set { _VNAcc = value; }
		}

		private Int64 _Report_Value;
		public Int64 Report_Value
		{
			get { return _Report_Value; }
			set { _Report_Value = value; }
		}

		private string _team;

		public string Team
		{
			get { return _team; }
			set { _team = value; }
		}
		private long _CalItem;

		public long CalItem
		{
			get { return _CalItem; }
			set { _CalItem = value; }
		}
		private Int64 _Guarantee_INC;

		public Int64 Guarantee_INC
		{
			get { return _Guarantee_INC; }
			set { _Guarantee_INC = value; }
		}
		private Int64 _CleanLC_INC;

		public Int64 CleanLC_INC
		{
			get { return _CleanLC_INC; }
			set { _CleanLC_INC = value; }
		}
		private Int64 _Acceptance_INC;

		public Int64 Acceptance_INC
		{
			get { return _Acceptance_INC; }
			set { _Acceptance_INC = value; }
		}
		private Int64 _Commitment_INC;

		public Int64 Commitment_INC
		{
			get { return _Commitment_INC; }
			set { _Commitment_INC = value; }
		}
		private Int64 _Others_INC;

		public Int64 Others_INC
		{
			get { return _Others_INC; }
			set { _Others_INC = value; }
		}
		private Int64 _DocLC_INC;

		public Int64 DocLC_INC
		{
			get { return _DocLC_INC; }
			set { _DocLC_INC = value; }
		}
		private Int64 _ExpBillHandling_INC;

		public Int64 ExpBillHandling_INC
		{
			get { return _ExpBillHandling_INC; }
			set { _ExpBillHandling_INC = value; }
		}
		private Int64 _ImpBillHandling_INC;

		public Int64 ImpBillHandling_INC
		{
			get { return _ImpBillHandling_INC; }
			set { _ImpBillHandling_INC = value; }
		}
		private Int64 _Collecting_INC;

		public Int64 Collecting_INC
		{
			get { return _Collecting_INC; }
			set { _Collecting_INC = value; }
		}
		private Int64 _Payment_INC;

		public Int64 Payment_INC
		{
			get { return _Payment_INC; }
			set { _Payment_INC = value; }
		}
		private Int64 _Remittance_INC;

		public Int64 Remittance_INC
		{
			get { return _Remittance_INC; }
			set { _Remittance_INC = value; }
		}
		private Int64 _Loan_INC;

		public Int64 Loan_INC
		{
			get { return _Loan_INC; }
			set { _Loan_INC = value; }
		}
		private Int64 _Others01_INC;

		public Int64 Others01_INC
		{
			get { return _Others01_INC; }
			set { _Others01_INC = value; }
		}
		private Int64 _Others02_INC;

		public Int64 Others02_INC
		{
			get { return _Others02_INC; }
			set { _Others02_INC = value; }
		}

        private string shortJP;

        public string ShortJP
        {
            get { return shortJP; }
            set { shortJP = value; }
        }
        private string shortVN;

        public string ShortVN
        {
            get { return shortVN; }
            set { shortVN = value; }
        }
		/// <summary>
		/// Constructor
		/// </summary>
		public clsCPAReport_On_Commission_And_Fee_By_CustomerDTO() { }

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="row"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsCPAReport_On_Commission_And_Fee_By_CustomerDTO(DataRow row)
		{
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();
			this.Guarantee_INC = m_CommonFunction.CheckNullInt64(row["Guarantee_INC"]);
			this.CleanLC_INC = m_CommonFunction.CheckNullInt64(row["CleanLC_INC"]);
			this.Acceptance_INC = m_CommonFunction.CheckNullInt64(row["Acceptance_INC"]);
			this.Commitment_INC = m_CommonFunction.CheckNullInt64(row["Commitment_INC"]);
			this.Others_INC = m_CommonFunction.CheckNullInt64(row["Others_INC"]);
			this.DocLC_INC = m_CommonFunction.CheckNullInt64(row["DocLC_INC"]);
			this.ExpBillHandling_INC = m_CommonFunction.CheckNullInt64(row["ExpBillHandling_INC"]);
			this.ImpBillHandling_INC = m_CommonFunction.CheckNullInt64(row["ImpBillHandling_INC"]);
			this.Collecting_INC = m_CommonFunction.CheckNullInt64(row["Collecting_INC"]);
			this.Payment_INC = m_CommonFunction.CheckNullInt64(row["Payment_INC"]);
			this.Remittance_INC = m_CommonFunction.CheckNullInt64(row["Remittance_INC"]);
			this.Loan_INC = m_CommonFunction.CheckNullInt64(row["Loan_INC"]);
			this.Others01_INC = m_CommonFunction.CheckNullInt64(row["Others01_INC"]);
			this.Others02_INC = m_CommonFunction.CheckNullInt64(row["Others02_INC"]);

			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			CPAStatus = (byte) row["CPA_Status"];
			CustomerName = ((string) row["Name"]).Trim();
			try
			{
				JPAcc = ((string) row["JPAcc"]).Trim();
			}
			catch (Exception)
			{
				JPAcc = "";
			}
			try
			{
				VNAcc = ((string) row["VNAcc"]).Trim();
			}
			catch (Exception)
			{
				VNAcc = "";
			}
			try
			{
				Team = ((string) row["Team"]).Trim();
			}
			catch (Exception)
			{
				Team = "";
			}
		}
		/// <summary>
		/// report 6
		/// </summary>
		/// <returns></returns>
		public Int64 Rpt06GetCommissionFee()
		{
			return _Guarantee_INC + _CleanLC_INC + _Acceptance_INC + _Commitment_INC
					+ _Others_INC + _DocLC_INC + _ExpBillHandling_INC + _ImpBillHandling_INC
					+ _Collecting_INC + _Payment_INC + _Remittance_INC + _Loan_INC + _Others01_INC + _Others02_INC;
		}
	}
}