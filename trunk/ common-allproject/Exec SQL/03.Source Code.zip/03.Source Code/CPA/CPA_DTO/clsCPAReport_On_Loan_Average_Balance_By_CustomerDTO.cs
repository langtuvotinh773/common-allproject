﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-01-31 20:37:30 +0700 (Thu, 31 Jan 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for Report_On_Loan_Average_Balance_By_Customer
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Config.Classes;
namespace Phoenix.Cpa.Dto
{
	public class clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO
	{
		clsCommonFunctions m_CommonFunction = new clsCommonFunctions();
		private string _YearMonth;

		public string YearMonth
		{
			get { return _YearMonth; }
			set { _YearMonth = value; }
		}
		private string _CustomerID;
		public string CustomerID
		{
			get { return _CustomerID; }
			set { _CustomerID = value; }
		}


		private bool _ReportStatus;

		public bool ReportStatus
		{
			get { return _ReportStatus; }
			set { _ReportStatus = value; }
		}

		private string _jnj;

		public string JNJ
		{
			get { return _jnj; }
			set { _jnj = value; }
		}

		private byte _CPAStatus;

		public byte CPAStatus
		{
			get { return _CPAStatus; }
			set { _CPAStatus = value; }
		}

		private string _CustomerName;

		public string CustomerName
		{
			get { return _CustomerName; }
			set { _CustomerName = value; }
		}
		private string _JPAcc;

		public string JPAcc
		{
			get { return _JPAcc; }
			set { _JPAcc = value; }
		}
		private string _VNAcc;

		public string VNAcc
		{
			get { return _VNAcc; }
			set { _VNAcc = value; }
		}

		private Int64 _Report_Value;
		public Int64 Report_Value
		{
			get { return _Report_Value; }
			set { _Report_Value = value; }
		}

		private string _team;

		public string Team
		{
			get { return _team; }
			set { _team = value; }
		}
		private long _CalItem;

		public long CalItem
		{
			get { return _CalItem; }
			set { _CalItem = value; }
		}
		private Int64 _Dep_Liquid_AVE;

		public Int64 Dep_Liquid_AVE
		{
			get { return _Dep_Liquid_AVE; }
			set { _Dep_Liquid_AVE = value; }
		}
		private Int64 _Dep_Fixed_AVE;

		public Int64 Dep_Fixed_AVE
		{
			get { return _Dep_Fixed_AVE; }
			set { _Dep_Fixed_AVE = value; }
		}
		private Int64 _STL_Overdraft_AVE;

		public Int64 STL_Overdraft_AVE
		{
			get { return _STL_Overdraft_AVE; }
			set { _STL_Overdraft_AVE = value; }
		}
		private Int64 _STL_CommercialBill_AVE;

		public Int64 STL_CommercialBill_AVE
		{
			get { return _STL_CommercialBill_AVE; }
			set { _STL_CommercialBill_AVE = value; }
		}
		private Int64 _STL_Loan_AVE;

		public Int64 STL_Loan_AVE
		{
			get { return _STL_Loan_AVE; }
			set { _STL_Loan_AVE = value; }
		}
		private Int64 _LTL_Fixed_AVE;

		public Int64 LTL_Fixed_AVE
		{
			get { return _LTL_Fixed_AVE; }
			set { _LTL_Fixed_AVE = value; }
		}
		private Int64 _LTL_Floating_AVE;

		public Int64 LTL_Floating_AVE
		{
			get { return _LTL_Floating_AVE; }
			set { _LTL_Floating_AVE = value; }
		}

        private string shortJP;

        public string ShortJP
        {
            get { return shortJP; }
            set { shortJP = value; }
        }
        private string shortVN;

        public string ShortVN
        {
            get { return shortVN; }
            set { shortVN = value; }
        }
		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO() { }

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="row"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO(DataRow row)
		{
			this.YearMonth = ((string) row["YearMonth"]).Trim();
			this.CustomerID = ((string) row["CustomerID"]).Trim();

			this.STL_Overdraft_AVE = m_CommonFunction.CheckNullInt64(row["STL_Overdraft_AVE"]);
			this.STL_CommercialBill_AVE = m_CommonFunction.CheckNullInt64(row["STL_CommercialBill_AVE"]);
			this.STL_Loan_AVE = m_CommonFunction.CheckNullInt64(row["STL_Loan_AVE"]);
			this.LTL_Fixed_AVE = m_CommonFunction.CheckNullInt64(row["LTL_Fixed_AVE"]);
			this.LTL_Floating_AVE = m_CommonFunction.CheckNullInt64(row["LTL_Floating_AVE"]);
            shortJP = row["ShortJP"] == DBNull.Value ? "" : (string)row["ShortJP"];
            shortVN = row["ShortVN"] == DBNull.Value ? "" : (string)row["ShortVN"];

			this.ReportStatus = (bool) row["ReportStatus"];
			this.JNJ = row["JNJ"].GetType() == typeof(DBNull) ? "" : ((string) row["JNJ"]).Trim();
			CPAStatus = (byte) row["CPA_Status"];
			CustomerName = ((string) row["Name"]).Trim();
			try
			{
				JPAcc = ((string) row["JPAcc"]).Trim();
			}
			catch (Exception)
			{
				JPAcc = "";
			}
			try
			{
				VNAcc = ((string) row["VNAcc"]).Trim();
			}
			catch (Exception)
			{
				VNAcc = "";
			}
			try
			{
				Team = ((string) row["Team"]).Trim();
			}
			catch (Exception)
			{
				Team = "";
			}
		}
		/// <summary>
		/// report 5
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public Int64 Rpt05GetLoanAverageBalance()
		{
			return _STL_Overdraft_AVE + _STL_CommercialBill_AVE + _STL_Loan_AVE + LTL_Fixed_AVE + _LTL_Floating_AVE;
		}
	}
}