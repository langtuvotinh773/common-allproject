﻿

/*
 * Author:  Phong Nguyen
 * Created: 3-Jan-2013
 * 
 * This class is used to get data for View customer transaction screen
 * 
 * 
 */

using System;

using System.Data.SqlClient;
using System.Data;
using Phoenix.Cpa.Dal;
using Phoenix.Cpa.Common;

namespace Phoenix.Cpa.Bus
{
    class clsViewListTransactionBLL
    {
        clsDataAccessLayer m_DAL = null;
        public clsViewListTransactionBLL()
        {
            m_DAL = new clsDataAccessLayer();
        }
        /// <summary>
        /// get data for view customer transaction screen
        /// </summary>
        /// <param name="customerID">Customer Code</param>
        /// <param name="yearMonth">year month of CPA</param>
        /// <param name="jnj">JNJ</param>
        /// <param name="customerName">customer full name</param>
        /// <returns></returns>
        public DataTable GetData(string customerID, string yearMonth,string jnj, string customerName)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@customerID", customerID);
            parameters[1] = new SqlParameter("@yearMonthTo", yearMonth);


            DateTime date = new DateTime(int.Parse(yearMonth.Remove(4)), int.Parse(yearMonth.Remove(0,4)),1);
            date = date.AddMonths(-11);
            string from = date.Year.ToString() + date.Month.ToString("00");
            parameters[2] = new SqlParameter("@yearMonthFrom", from);


            parameters[3] = new SqlParameter("@customerName", customerName);
            parameters[4] = new SqlParameter("@department", DBNull.Value);
            parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", jnj);
            parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetListCPACustomer", CommandType.StoredProcedure, parameters);

            return reader;
        }

        /// <summary>
        /// Get Data for report customer transaction
        /// </summary>
        /// <param name="customerID"></param>
        /// <param name="yearMonth"></param>
        /// <param name="jnj"></param>
        /// <param name="customerName"></param>
        /// <returns></returns>
        public DataTable GetDataForReport(string customerID, string yearMonth, string jnj, string customerName)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@customerID", customerID);
            parameters[1] = new SqlParameter("@yearMonthTo", yearMonth);


            DateTime date = new DateTime(int.Parse(yearMonth.Remove(4)), int.Parse(yearMonth.Remove(0, 4)), 1);
            date = date.AddMonths(-11);
            string from = date.Year.ToString() + date.Month.ToString("00");
            parameters[2] = new SqlParameter("@yearMonthFrom", from);


            parameters[3] = new SqlParameter("@customerName", customerName);
            parameters[4] = new SqlParameter("@department", DBNull.Value);
            parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", jnj);
            parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetListCPACustomerForPrintViewReport", CommandType.StoredProcedure, parameters);

            return reader;
        }
        /// <summary>
        /// get data use for view quick CPA screen
        /// </summary>
        /// <param name="customerID"></param>
        /// <param name="yearMonth"></param>
        /// <returns></returns>
        public DataTable GetQuickData(string customerID, string yearMonth)
        {
            SqlParameter[] parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("@customerID", customerID);
            parameters[1] = new SqlParameter("@yearMonthTo", yearMonth);
            DateTime date = new DateTime(int.Parse(yearMonth.Remove(4)), int.Parse(yearMonth.Remove(0, 4)), 1);
            date = date.AddMonths(-11);
            string from = date.Year.ToString() + date.Month.ToString("00");
            parameters[2] = new SqlParameter("@yearMonthFrom", from);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetListCPACustomer", CommandType.StoredProcedure, parameters);
            return reader;
        }
    }
}
