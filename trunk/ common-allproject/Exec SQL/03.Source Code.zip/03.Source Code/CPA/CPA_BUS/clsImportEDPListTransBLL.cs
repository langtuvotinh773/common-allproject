﻿
/*
 * Author:  Phong Nguyen
 * Created: 3-Jan-2013
 * 
 * This class is used to implement import CPA process
 * 
 * 
 */

using System.Data;
using System.Data.SqlClient;
using Phoenix.Cpa.Dal;

namespace Phoenix.Cpa.Bus
{
    class clsImportEDPListTransBLL
    {
        clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="ImportEDPListTransBLL" /> class.
        /// </summary>
        public clsImportEDPListTransBLL()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Check status CPA.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public int CheckStatusCPA(string yearMonth)
        {
            int status = -1;
            SqlParameter[] arr = { new SqlParameter("@yearmonth", SqlDbType.Char) };
            arr[0].Value = yearMonth;
            DataTable dt = new DataTable();
                dt = m_DAL.ExecuteDataReader("spCPA_GetCPAMaster", CommandType.StoredProcedure, arr);
                if (dt.Rows.Count == 0)
                {
                    return -1;
                }
                DataRow row = dt.Rows[0];
                status = int.Parse(row["CPA_Status"].ToString());
            return status;
        }
      
        

        
    }

}
