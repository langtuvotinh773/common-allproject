﻿/*
 * Author:  Quan Nguyen
 * Created: 2-Jan-2013
 * 
 * This class is used to implement business logic for  
 * Update Customer Transaction screen
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using Phoenix.Cpa.Dal;
using Phoenix.Cpa.Common;


namespace Phoenix.Cpa.Bus
{
    class clsUpdateCustomerTransBLL
    {
        public clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateCustomerTransBLL" /> class.
        /// </summary>
        public clsUpdateCustomerTransBLL()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Gets the transaction data.
        /// </summary>
        /// <param name="paramValue1">The param value1.</param>
        /// <param name="paramValue2">The param value2.</param>
        /// <param name="paramValue3">The param value3.</param>
        /// <returns></returns>
        public DataTable GetTransactionData(string paramValue1, string paramValue2)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@customerID", paramValue1);
            parameters[1] = new SqlParameter("@yearMonthFrom", paramValue2);
            parameters[2] = new SqlParameter("@yearMonthTo", paramValue2);
            parameters[3] = new SqlParameter("@customerName", "");
            parameters[4] = new SqlParameter("@department", DBNull.Value);
            parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", "");
            parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);

            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetListCPACustomer", CommandType.StoredProcedure, parameters);
            
            return reader;
        }

        /// <summary>
        /// Updates the transaction.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public int UpdateTransaction(DataTable data, string date, string custID)
        {
            if (data != null && data.Rows.Count > 0)
            {
                SqlParameter[] parameters = new SqlParameter[70];
                parameters[0] = new SqlParameter("@yearMonth", date);
                parameters[1] = new SqlParameter("@customerID", custID);
                int k = 0;
                int len = parameters.Length - 1;
                for (int i = 2; i < len; i++)
                {
                    k = i;
                    parameters[i] = new SqlParameter("@value" + (k - 2),data.Rows[0][k]);
                }
                object outParamName = "@rowCount";
                parameters[69] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
                parameters[69].Direction = ParameterDirection.Output;
                int row = m_DAL.ExecuteNonQuery("dbo.spCPA_UpdateCustomer", CommandType.StoredProcedure, parameters, outParamName);
                return row;
            }
            return 0;
        }
        /// <summary>
        /// commit transaction
        /// </summary>
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
        }
    }
}
