﻿/*
 * Author:  Yen Phan
 * Created: 3-Jan-2013
 * 
 * This class is used to implement business logic for  
 * Customer error list
 * 
 */
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using Phoenix.Cpa.Dal;
using Phoenix.Cpa.Dto;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Log.Com;
namespace Phoenix.Cpa.Bus
{
	/// <summary> Customer Error Bus layer class
	/// 
	/// </summary>
	/// <returns></returns>
	class clsCustomerErrorBus
	{
		clsDataAccessLayer m_DAO = null; // use to acccess to database
        private SqlTransaction Transaction; // get transaction when delete customer error
        private SqlConnection connection;// get connection when delete customer error
		/// <summary>
		/// Initializes a new instance of the <see cref="clsCustomerErrorBus" /> class.
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsCustomerErrorBus()
		{
			m_DAO = new clsDataAccessLayer();
            Transaction = m_DAO.m_transaction;
            connection = m_DAO.m_Connection; 
		}

        /// <summary>
        /// get list customer error
        /// </summary>
        /// <param name="yearMonth"></param>
        /// <param name="errType"></param>
        /// <returns></returns>
        public DataTable GetListCustomerError(string yearMonth, string errType)
        {
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@YearMonth", yearMonth);
            parameters[1] = new SqlParameter("@ErrorType", errType);



            DataTable reader = m_DAO.ExecuteDataReader("dbo.spCPA_GetListCuctomerError", CommandType.StoredProcedure, parameters);
            return reader;
        }

       
       /// <summary>
       /// delete template table before import
       /// </summary>
        public void DeleteTempTable()
        {
            SqlParameter[] parameters1 = new SqlParameter[0];
            m_DAO.ExecuteNonQueryNonReply("dbo.spCPA_ClearTempTable", CommandType.StoredProcedure, parameters1);
        }





		/// <summary> Gets error type list.
		/// Yen Phan
		/// </summary>
		/// <returns></returns>
		public ArrayList GetMonthYearList()
		{
			m_DAO.SetCommand("spCPA_GetListYearMonth", CommandType.StoredProcedure);
			SqlDataReader reader = m_DAO.ExecuteDataReader();
			int colCount = 1;
			ArrayList arrDataSetResult = new ArrayList();
			string[] data = new string[colCount];
            arrDataSetResult.Add(new clsYearMonth("",""));
			if (reader != null)
			{
				while (reader.Read())
					arrDataSetResult.Add(new clsYearMonth(reader[0].ToString(), clsCommonFunctions.GetMonthYearShowOnDataGrid(reader[0].ToString())));
			}

			reader.Close();
			return arrDataSetResult;
		}





		/// <summary>Delete Customer Error
		/// Yen Phan
		/// </summary>
		/// <param name="data">The data.</param>
		/// <returns></returns>
		public int DeleteCustomerError(List<clsCPACustomerErrorDTO> lst)
		{
			int row = 0;
			
                List<SqlParameter[]> lstParams = new List<SqlParameter[]>();
                for (int i = 0; i < lst.Count; i++)
                {
                    SqlParameter[] parameters = new SqlParameter[2];
                    parameters[0] = new SqlParameter("@yearMonth", lst[i].YearMonth);
                    parameters[1] = new SqlParameter("@customerID", lst[i].CustomerID);
                    lstParams.Add(parameters);

                    clsCPALogBase log = new clsCPALogBase();
                    log.Key = lst[i].YearMonth + " " + lst[i].CustomerID;
                    log.UserID = clsUserInfo.UserNo.ToString();
                    log.ApplicationName = "Customer Error";
                    log.Action = (int)CommonValue.ActionType.Delete;


                    log.WirteLog(m_DAO);

                }
                
              row =   m_DAO.ExecuteNonQuery("dbo.spCPA_DeleteCustomerError", CommandType.StoredProcedure, lstParams);

              Transaction = m_DAO.m_transaction;
              connection = m_DAO.m_Connection; 
			    
			return row;
		}
        /// <summary>
        /// Commit transaction
        /// </summary>
        public void Commit()
        {
            Transaction.Commit();
            if (m_DAO.m_Connection.State == ConnectionState.Open)
                m_DAO.m_Connection.Close();
        }
        /// <summary>
        /// RollBack Transaction
        /// </summary>
        public void RollBack()
        {
            Transaction.Rollback();
            if (m_DAO.m_Connection.State == ConnectionState.Open)
                m_DAO.m_Connection.Close();
        }

  
	}
	class clsYearMonth
	{
		private string m_Display;
		private string m_Value;
		public clsYearMonth(string Value, string Display)
		{
			m_Display = Display;
			m_Value = Value;
		}
		public string Display
		{
			get { return m_Display; }
		}
		public string Value
		{
			get { return m_Value; }
		}
	}
	class clsErrType
	{
		private string m_Display;
		private string m_Value;
		public clsErrType(string Value, string Display)
		{
			m_Display = Display;
			m_Value = Value;
		}
		public string Display
		{
			get { return m_Display; }
		}
		public string Value
		{
			get { return m_Value; }
		}
	}
 
}