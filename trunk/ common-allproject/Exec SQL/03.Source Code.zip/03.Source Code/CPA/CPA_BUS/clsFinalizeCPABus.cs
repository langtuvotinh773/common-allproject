﻿/*
 * Author:  Yen Phan
 * Created: 7-Jan-2013
 * 
 * This class is used to implement business logic for  
 * Finalize CPA list
 * 
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using System.Collections;
using Phoenix.Cpa.Dal;
using Config.Classes;
using Phoenix.Cpa.Common;
using Phoenix.Common.Log.Com;


namespace Phoenix.Cpa.Bus
{
	/// <summary> Finalize CPA Bus layer class
	/// 
	/// </summary>
	/// <returns></returns>
	public class clsFinalizeCPABus
	{
		clsDataAccessLayer m_DAO = null;
        public SqlTransaction Transaction;
        public SqlConnection connection;
		/// <summary>Initializes a new instance of the <see cref="clsFinalizeCPABus" /> class.
		/// Yen Phan
		/// </summary>
		public clsFinalizeCPABus()
		{
			m_DAO = new clsDataAccessLayer();
            Transaction = m_DAO.m_transaction;
            connection = m_DAO.m_Connection;
		}

		/// <summary>Gets Finalize CPA dataset.
		/// Yen Phan
		/// </summary>
		/// <param name="paramValue1">parYearMonth</param>
		/// <param name="paramValue2">parComplete</param>
		/// <returns></returns>
		public ArrayList GetFinalizeCPADs(string from,string to, string parComplete)
		{
			m_DAO.SetCommand("spCPA_GetListFinalize", CommandType.StoredProcedure);
			m_DAO.AddParameter("@YearMonthFrom", from);
            m_DAO.AddParameter("@YearMonthTo", to);
            m_DAO.AddParameter("@CPAStatus", parComplete);
			SqlDataReader reader = m_DAO.ExecuteDataReader();
			int colCount = 2;
			ArrayList dataSetResult = new ArrayList();
			
			if (reader != null)
			{
               
				while (reader.Read())
				{
                    string[] data = new string[colCount];
					for (int i = 0; i < colCount; i++)
						data[i] = reader.GetSqlValue(i) + "";
					dataSetResult.Add(data);
				}
			}
			reader.Close();
			return dataSetResult;
		}

		/// <summary>Update Finalize CPA List
		/// Yen Phan
		/// </summary>
		/// <param name="data">The data.</param>
		/// <returns></returns>
		public int UpdateFinalizeCPA(ArrayList finalizeCPADs)
		{
		    
			int row = 0;
			if (finalizeCPADs != null && finalizeCPADs.Count > 0)
			{
				//m_DAO.SetCommand("spCPA_UpdateCPAStatus", CommandType.StoredProcedure);
                List<SqlParameter[]> lstParams = new List<SqlParameter[]>();
				for (int i = 0; i < finalizeCPADs.Count; i++)
				{
                    string[] data = (string[])finalizeCPADs[i];
                    SqlParameter[] parameters = new SqlParameter[3];
                    parameters[0] = new SqlParameter("@YearMonth", data[1]);
                    parameters[1] = new SqlParameter("@CPAStatus", byte.Parse(data[0]));
                    int a = 0;
                    parameters[2] = new SqlParameter("@count", a);
                    parameters[2].Direction = ParameterDirection.InputOutput;

                    lstParams.Add(parameters);
                    clsCPALogBase log = new clsCPALogBase();
                    log.Key = data[1].ToString();
                    log.UserID = clsUserInfo.UserNo.ToString();
                    log.ApplicationName =  "Finalized CPA Data";
                    log.Action = (int)CommonValue.ActionType.Update;
                    log.LstLogInformation.Add(new clsCPALogInformation
                    {

                        FieldName = clsCPAConstant.COL_COMPLETE,
                        OldValue = data[0] == "0" ? "1" : "0",
                        NewValue =data[0]
                    });

                    log.WirteLog(m_DAO);
				}
                
                row += m_DAO.ExecuteNonQuery("dbo.spCPA_UpdateCPAStatus", CommandType.StoredProcedure, lstParams);
                Transaction = m_DAO.m_transaction;
                connection = m_DAO.m_Connection;
               // Transaction.Commit();
			}
			return row;
		}

        /// <summary>
        /// Commit transaction
        /// </summary>
        public void Commit()
        {
            Transaction.Commit();
            if (m_DAO.m_Connection.State == ConnectionState.Open)
                m_DAO.m_Connection.Close();
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        public void RollBack()
        {
            Transaction.Rollback();
            if (m_DAO.m_Connection.State == ConnectionState.Open)
                m_DAO.m_Connection.Close();
        }
        /// <summary>
        /// get list CPA not import yet
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public static List<string> CheckLackingCPA(string from, string to)
        {
            List<string> results = new List<string>();

            SqlParameter[] parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("@YearMonthFrom", from);
            parameters[1] = new SqlParameter("@YearMonthTo", to);
            parameters[2] = new SqlParameter("@CPAStatus", DBNull.Value);
            clsDataAccessLayer DAO = new clsDataAccessLayer();
            DataTable reader = DAO.ExecuteDataReader("dbo.spCPA_GetListFinalize", CommandType.StoredProcedure, parameters);
            results = clsCommonFunctions.GetListMonthYear(from, to);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                if(results.Contains((string)reader.Rows[i]["YearMonth"]))
                    results.Remove((string)reader.Rows[i]["YearMonth"]);
            }

            return results;
        }
            
	}
}
