﻿
/*
 * Author: Phong Nguyen
 * Created: 3-Jan-2013
 * 
 * This class is used to get and store data use in all combobox
 * 
 */
using System;
using System.Collections.Generic;
using Phoenix.Cpa.Dto;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Cpa.Dal;
using Phoenix.Common.MasterData.Com;
using Config.Classes;



namespace Phoenix.Cpa.Bus
{
    /// <summary>
    /// this class use to get data in combobox
    /// </summary>
    public class clsGetDataCombobox
    {
        private clsDataAccessLayer m_DAL = null;
        private string CPAType = "1"; // team type of CPA

        private static clsGetDataCombobox m_Style;
        private List<DepartmentDTO> lstDepartment;

        public List<DepartmentDTO> LstDepartment
        {
            get { return lstDepartment; }
            set { lstDepartment = value; }
        }
        private List<SectionDTO> lstSection;

        public List<SectionDTO> LstSection
        {
            get { return lstSection; }
            set { lstSection = value; }
        }
        private List<UserDTO> lstUser;

        public List<UserDTO> LstUser
        {
            get { return lstUser; }
            set { lstUser = value; }
        }

        private List<UserDTO> jpAcc;

        public List<UserDTO> JPAcc
        {
            get { return jpAcc; }
            set { jpAcc = value; }
        }
        private List<UserDTO> vnAcc;

        public List<UserDTO> VNAcc
        {
            get { return vnAcc; }
            set { vnAcc = value; }
        }

        private List<ParameterDTO> jnj;

        public List<ParameterDTO> lstJNJ
        {
            get { return jnj; }
            set { jnj = value; }
        }
        private List<ParameterDTO> cpaStatus;

        public List<ParameterDTO> lstCPAStatus
        {
            get { return cpaStatus; }
            set { cpaStatus = value; }
        }

        private List<ParameterDTO> errorType;

        public List<ParameterDTO> LstErrorType
        {
            get { return errorType; }
            set { errorType = value; }
        }


       
        public static clsGetDataCombobox Instance()
        {
            if (m_Style == null)
            {
                m_Style = new clsGetDataCombobox();
            }
            
            return m_Style;
        }
        /// <summary>
        /// get all data for combobox
        /// </summary>
        public void LoadData()
        {
            LoadDepartment();
            LoadTeam("");
            LoadUser("","");
            LoadCPAStatus();
            LoadJNJ();
            LoadErrorType();
        }
        /// <summary>
        /// Get data for department combobox
        /// </summary>
        public void LoadDepartment()
        {
            if (m_DAL == null) m_DAL = new clsDataAccessLayer();
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@teamType", CPAType);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetDepartment", CommandType.StoredProcedure, parameters);
            if (reader != null)
            {
                lstDepartment = new List<DepartmentDTO>();
                DepartmentDTO blank = new DepartmentDTO();
                lstDepartment.Add(blank);
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    lstDepartment.Add(new DepartmentDTO(reader.Rows[i]));
                }
            }
            
        }
        /// <summary>
        /// load data for team combobox
        /// </summary>
        public void LoadTeam(string departmentID)
        {
            if (m_DAL == null) m_DAL = new clsDataAccessLayer();
           
            SqlParameter[] parameters = new SqlParameter[2];
            if (departmentID == "")
                parameters[0] = new SqlParameter("@departmentID", DBNull.Value);
            else parameters[0] = new SqlParameter("@departmentID", departmentID);
            parameters[1] = new SqlParameter("@teamType", CPAType);

           // parameters[0] = new SqlParameter();
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetTeam", CommandType.StoredProcedure, parameters);
            if (reader != null)
            {
                lstSection = new List<SectionDTO>();
                SectionDTO blank = new SectionDTO();
                lstSection.Add(blank);
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    lstSection.Add(new SectionDTO(reader.Rows[i]));
                }
            }
        }
        /// <summary>
        /// load data for JPAccount and VNAccount combobox
        /// </summary>
        public void LoadUser(string department,string team)
        {
            if (m_DAL == null) m_DAL = new clsDataAccessLayer();
            SqlParameter[] parameters = new SqlParameter[4];
            if (department == "")
                parameters[0] = new SqlParameter("@departmentID", DBNull.Value);
            else parameters[0] = new SqlParameter("@departmentID", department);
            if (team == "")
                parameters[1] = new SqlParameter("@teamID", DBNull.Value);
            else parameters[1] = new SqlParameter("@teamID", team);
            parameters[2] = new SqlParameter("@userNo", DBNull.Value);
            parameters[3] = new SqlParameter("@teamType", DBNull.Value);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetUser", CommandType.StoredProcedure, parameters);
            if (reader != null)
            {
                lstUser = new List<UserDTO>();
                vnAcc = new List<UserDTO>();
                jpAcc = new List<UserDTO>();
                UserDTO blank = new UserDTO();
                lstUser.Add(blank);
                vnAcc.Add(blank);
                jpAcc.Add(blank);
                string strJPacc = "";
                string strVNacc = "";
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    UserDTO temp = new UserDTO(reader.Rows[i]);
                    lstUser.Add(temp);
                   
                    if (temp.UserType == (int)CommonValue.UserType.JPAcc || temp.UserType == (int)CommonValue.UserType.All)
                    {
                        if(temp.UserID != strJPacc)
                        jpAcc.Add(temp);
                        strJPacc = temp.UserID;
                    }
                    
                    if ((temp.UserType == (int)CommonValue.UserType.VNAcc || temp.UserType == (int)CommonValue.UserType.All) && temp.TeamType == CPAType)
                    {
                        if(temp.UserID != strVNacc)
                        vnAcc.Add(temp);
                        strVNacc = temp.UserID;
                    }
                }
            }
        }


        /// <summary>
        /// load data for JNJ combobox
        /// </summary>
        public void LoadJNJ()
        {
            if (m_DAL == null) m_DAL = new clsDataAccessLayer();
            SqlParameter[] parameters = new SqlParameter[2];

             parameters[0] = new SqlParameter("@module","CPA");
             parameters[1] = new SqlParameter("@type", "003");
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetParameters", CommandType.StoredProcedure, parameters);
            if (reader != null)
            {
                jnj = new List<ParameterDTO>();
                ParameterDTO blank = new ParameterDTO();
                jnj.Add(blank);
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    jnj.Add(new ParameterDTO(reader.Rows[i]));
                }
            }
        }

        /// <summary>
        /// load data for CPA Status combobox
        /// </summary>
        public void LoadCPAStatus()
        {
            if (m_DAL == null) m_DAL = new clsDataAccessLayer();
            SqlParameter[] parameters = new SqlParameter[2];

            parameters[0] = new SqlParameter("@module", "CPA");
            parameters[1] = new SqlParameter("@type", "002");
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetParameters", CommandType.StoredProcedure, parameters);
            if (reader != null)
            {
                cpaStatus = new List<ParameterDTO>();
                ParameterDTO blank = new ParameterDTO();
                cpaStatus.Add(blank);
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    cpaStatus.Add(new ParameterDTO(reader.Rows[i]));
                }
            }
        }

        /// <summary>
        /// Load data for Error Type combobox
        /// 
        /// </summary>
        public void LoadErrorType()
        {
            if (m_DAL == null) m_DAL = new clsDataAccessLayer();
            SqlParameter[] parameters = new SqlParameter[2];

            parameters[0] = new SqlParameter("@module", "CPA");
            parameters[1] = new SqlParameter("@type", "001");
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetParameters", CommandType.StoredProcedure, parameters);
            if (reader != null)
            {
                errorType = new List<ParameterDTO>();
                ParameterDTO blank = new ParameterDTO();
                errorType.Add(blank);
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    errorType.Add(new ParameterDTO(reader.Rows[i]));
                }
            }
        }

    }
}
