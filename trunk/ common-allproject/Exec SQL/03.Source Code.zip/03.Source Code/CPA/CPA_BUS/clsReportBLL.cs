﻿

/*
 * Author:  Phong Nguyen
 * Created: 3-Jan-2013
 * 
 * This class is used to get data for all report
 * 
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Cpa.Dal;
using Phoenix.Cpa.Dto;
using Phoenix.Cpa.Common;


namespace Phoenix.Cpa.Bus
{
     public class clsReportBLL
    {
        clsDataAccessLayer m_DAL = null;
        public List<clsCPACustomerDTO> ListCPACustomer;
        public clsReportBLL()
        {
            m_DAL = new clsDataAccessLayer();
            ListCPACustomer = new List<clsCPACustomerDTO>();
        }

         /// <summary>
         /// Get list CPA
         /// </summary>
         /// <param name="from">datetime from</param>
         /// <param name="to">datetime to</param>
         /// <param name="customerID">customer ID</param>
         /// <param name="cusName">customer full name</param>
         /// <param name="departmentName">department ID</param>
         /// <param name="teamName">sectionID</param>
         /// <param name="JNJ">JNJ</param>
         /// <param name="VNAcc">VN Account user ID</param>
         /// <param name="JPAcc">JP Account user ID</param>
        public void GetListCPACustomer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc,string JPAcc)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);

            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetListCPACustomer", CommandType.StoredProcedure, parameters);
           
            ListCPACustomer = new List<clsCPACustomerDTO>();
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                if ((bool)reader.Rows[i]["ReportStatus"] == true || (byte)reader.Rows[i]["CPA_Status"] != 1)
                {
                    ListCPACustomer.Add(new clsCPACustomerDTO(reader.Rows[i],true));

                }
                else
                {

                    ListCPACustomer.Add(new clsCPACustomerDTO(reader.Rows[i]));
                }
            }
        }



         /// <summary>
         /// Get list CPA customer for report
         /// </summary>
         /// <param name="from"></param>
         /// <param name="to"></param>
         /// <param name="customerID"></param>
         /// <param name="cusName"></param>
         /// <param name="departmentName"></param>
         /// <param name="teamName"></param>
         /// <param name="JNJ"></param>
         /// <param name="VNAcc"></param>
         /// <param name="JPAcc"></param>
        public void GetListCPACustomerForReport(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);

            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetListCPACustomerForPrintViewReport", CommandType.StoredProcedure, parameters);

            ListCPACustomer = new List<clsCPACustomerDTO>();
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                if ((bool)reader.Rows[i]["ReportStatus"] == true || (byte)reader.Rows[i]["CPA_Status"] != 1)
                {
                    ListCPACustomer.Add(new clsCPACustomerDTO(reader.Rows[i], true));

                }
                else
                {

                    ListCPACustomer.Add(new clsCPACustomerDTO(reader.Rows[i]));
                }
            }
        }

		
		/// <summary>
		/// Get datatable for report 04
		/// </summary>
		/// <param name="from"></param>
		/// <param name="to"></param>
		/// <param name="customerID"></param>
		/// <param name="cusName"></param>
		/// <param name="departmentName"></param>
		/// <param name="teamName"></param>
		/// <param name="JNJ"></param>
		/// <param name="VNAcc"></param>
		/// <param name="JPAcc"></param>
		/// <param name="iRow"></param>
		/// <param name="lstCustomer"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond 
		public DataTable GetListCPAReportOnDepositAverageBalanceByCustomer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc, ref int iRow, ref List<clsCPAReport_On_Deposit_Average_Balance_By_CustomerDTO> lstCustomer, string realFrom)
		{
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if(VNAcc != "")
            parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_Deposit_Average_Balance_By_Customer", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
			iRow = reader.AsEnumerable().GroupBy(r => r.Field<string>("CustomerID")).Count();

			reader.Columns.Add("CalItem");
            

			lstCustomer = new List<clsCPAReport_On_Deposit_Average_Balance_By_CustomerDTO>();
			clsCPAReport_On_Deposit_Average_Balance_By_CustomerDTO dto = new clsCPAReport_On_Deposit_Average_Balance_By_CustomerDTO();
			for (int i = 0; i < reader.Rows.Count; i++)
			{
				dto = new clsCPAReport_On_Deposit_Average_Balance_By_CustomerDTO(reader.Rows[i]);
				dto.CalItem = dto.Rpt04GetCPaByAccount();
				lstCustomer.Add(dto);
				reader.Rows[i][reader.Columns.Count - 1] = dto.CalItem;
			}
			return reader;
		}
        /// <summary>
        /// re check list CPA
        /// </summary>
        /// <param name="realFrom"></param>
        /// <param name="reader"></param>
        private static void ReCheckReader(string realFrom, DataTable reader)
        {
            if (reader.Rows.Count > 0)
            {
                string cusID = (string)reader.Rows[reader.Rows.Count - 1]["CustomerID"];
                int del = -1;
                for (int i = reader.Rows.Count - 1; i >= 0; i--)
                {
                    if ((string)reader.Rows[i]["CustomerID"] != cusID)
                    {
                        del = -1;
                        cusID = (string)reader.Rows[i]["CustomerID"];
                    }

                    if ((string)reader.Rows[i]["CustomerID"] == cusID && del == 1)
                    {
                        reader.Rows.RemoveAt(i);
                    }
                    if (del == -1)
                    {
                        if (int.Parse((string)reader.Rows[i]["YearMonth"]) < int.Parse(realFrom))
                        {
                            reader.Rows.RemoveAt(i);
                            del = 1;

                        }
                        else del = 0;
                    }

                }
            }
        }
         /// <summary>
         /// recheck list CPA of top
         /// </summary>
         /// <param name="realFrom"></param>
         /// <param name="reader"></param>

        private static void ReCheckReaderTop(string realFrom, DataTable reader)
        {
            if (reader.Rows.Count > 0)
            {
                string cusID = (string)reader.Rows[reader.Rows.Count - 1]["CustomerID"];
                int del = -1;
                for (int i = reader.Rows.Count - 1; i >= 0; i--)
                {
                    if ((string)reader.Rows[i]["CustomerID"] != cusID)
                    {
                        del = -1;
                        cusID = (string)reader.Rows[i]["CustomerID"];
                    }

                    if ((string)reader.Rows[i]["CustomerID"] == cusID && del == 1)
                    {
                        reader.Rows[i]["REPORT_VALUE"] = 0;
                    }
                    if (del == -1)
                    {
                        if (int.Parse((string)reader.Rows[i]["YearMonth"]) < int.Parse(realFrom))
                        {
                            reader.Rows[i]["REPORT_VALUE"] = 0;
                            
                            del = 1;

                        }
                        else del = 0;
                    }

                }
            }
        }
		/// <summary>
		/// Get datatable for report 05
		/// </summary>
		/// <param name="from"></param>
		/// <param name="to"></param>
		/// <param name="customerID"></param>
		/// <param name="cusName"></param>
		/// <param name="departmentName"></param>
		/// <param name="teamName"></param>
		/// <param name="JNJ"></param>
		/// <param name="VNAcc"></param>
		/// <param name="JPAcc"></param>
		/// <param name="iRow"></param>
		/// <param name="lstCustomer"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond 
		public DataTable GetListCPAReportOnLoanAverageBalanceByCustomer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc, ref int iRow, ref List<clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO> lstCustomer, string realFrom)
		{
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);

            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);

			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_Loan_Average_Balance_By_Customer", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
			iRow = reader.AsEnumerable().GroupBy(r => r.Field<string>("CustomerID")).Count();

			reader.Columns.Add("CalItem");

			lstCustomer = new List<clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO>();
			clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO dto = new clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO();
			for (int i = 0; i < reader.Rows.Count; i++)
			{
				dto = new clsCPAReport_On_Loan_Average_Balance_By_CustomerDTO(reader.Rows[i]);
				dto.CalItem = dto.Rpt05GetLoanAverageBalance();
				lstCustomer.Add(dto);
				reader.Rows[i][reader.Columns.Count - 1] = dto.CalItem;
			}
			return reader;
		}
		/// <summary>
        /// Get datatable for  Report_On_Forex_Profit_By_Customer
		/// </summary>
		/// <param name="from"></param>
		/// <param name="to"></param>
		/// <param name="customerID"></param>
		/// <param name="cusName"></param>
		/// <param name="departmentName"></param>
		/// <param name="teamName"></param>
		/// <param name="JNJ"></param>
		/// <param name="VNAcc"></param>
		/// <param name="JPAcc"></param>
		/// <param name="iRow"></param>
		/// <param name="lstCustomer"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond 
		public DataTable GetListCPAReportCommissionAndFeeByCustomer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc, ref int iRow, ref List<clsCPAReport_On_Commission_And_Fee_By_CustomerDTO> lstCustomer)
		{
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);



			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_Commission_And_Fee_By_Customer", CommandType.StoredProcedure, parameters);

			iRow = reader.AsEnumerable().GroupBy(r => r.Field<string>("CustomerID")).Count();

			reader.Columns.Add("CalItem");

			lstCustomer = new List<clsCPAReport_On_Commission_And_Fee_By_CustomerDTO>();
			clsCPAReport_On_Commission_And_Fee_By_CustomerDTO dto = new clsCPAReport_On_Commission_And_Fee_By_CustomerDTO();
			for (int i = 0; i < reader.Rows.Count; i++)
			{
				dto = new clsCPAReport_On_Commission_And_Fee_By_CustomerDTO(reader.Rows[i]);
				dto.CalItem = dto.Rpt06GetCommissionFee();
				lstCustomer.Add(dto);
				reader.Rows[i][reader.Columns.Count - 1] = dto.CalItem;
			}
			return reader;
		}
		/// <summary>
        /// Get datatable for Report_On_Forex_Profit_By_Customer
		/// </summary>
		/// <param name="from"></param>
		/// <param name="to"></param>
		/// <param name="customerID"></param>
		/// <param name="cusName"></param>
		/// <param name="departmentName"></param>
		/// <param name="teamName"></param>
		/// <param name="JNJ"></param>
		/// <param name="VNAcc"></param>
		/// <param name="JPAcc"></param>
		/// <param name="iRow"></param>
		/// <param name="lstCustomer"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond 
		public DataTable GetListCPAReportOnForexProfitByCustomer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc, ref int iRow, ref List<clsCPAReport_On_Forex_Profit_By_CustomerDTO> lstCustomer)
		{
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);



			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_Forex_Profit_By_Customer", CommandType.StoredProcedure, parameters);

			iRow = reader.AsEnumerable().GroupBy(r => r.Field<string>("CustomerID")).Count();

			reader.Columns.Add("CalItem");

			lstCustomer = new List<clsCPAReport_On_Forex_Profit_By_CustomerDTO>();
			clsCPAReport_On_Forex_Profit_By_CustomerDTO dto = new clsCPAReport_On_Forex_Profit_By_CustomerDTO();
			for (int i = 0; i < reader.Rows.Count; i++)
			{
				dto = new clsCPAReport_On_Forex_Profit_By_CustomerDTO(reader.Rows[i]);
				dto.CalItem = dto.Rpt07GetForeignExchangePLINC();
				lstCustomer.Add(dto);
				reader.Rows[i][reader.Columns.Count - 1] = dto.CalItem;
			}
			return reader;
		}
		/// <summary>
        /// Get datatable for Report_On_Total_Profit_By_Customer
		/// </summary>
		/// <param name="from"></param>
		/// <param name="to"></param>
		/// <param name="customerID"></param>
		/// <param name="cusName"></param>
		/// <param name="departmentName"></param>
		/// <param name="teamName"></param>
		/// <param name="JNJ"></param>
		/// <param name="VNAcc"></param>
		/// <param name="JPAcc"></param>
		/// <param name="iRow"></param>
		/// <param name="lstCustomer"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond 
        public DataTable GetListCPAReportOnTotalProfitByCustomer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc, ref int iRow, ref List<clsCPAReport_On_Total_Profit_By_CustomerDTO> lstCustomer, string realFrom)
		{
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);



			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_Total_Profit_By_Customer", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
			iRow = reader.AsEnumerable().GroupBy(r => r.Field<string>("CustomerID")).Count();

			reader.Columns.Add("CalItem");

			lstCustomer = new List<clsCPAReport_On_Total_Profit_By_CustomerDTO>();
			clsCPAReport_On_Total_Profit_By_CustomerDTO dto = new clsCPAReport_On_Total_Profit_By_CustomerDTO();
			for (int i = 0; i < reader.Rows.Count; i++)
			{
				dto = new clsCPAReport_On_Total_Profit_By_CustomerDTO(reader.Rows[i]);
				dto.CalItem = dto.Rpt08GetTotalProfit();
				lstCustomer.Add(dto);
				reader.Rows[i][reader.Columns.Count - 1] = dto.CalItem;
			}
			return reader;
		}
		/// <summary>
        /// Get datatabe for Report_On_CPA_By_Account_Officer
		/// </summary>
		/// <param name="from"></param>
		/// <param name="to"></param>
		/// <param name="customerID"></param>
		/// <param name="cusName"></param>
		/// <param name="departmentName"></param>
		/// <param name="teamName"></param>
		/// <param name="JNJ"></param>
		/// <param name="VNAcc"></param>
		/// <param name="JPAcc"></param>
		/// <param name="iRow"></param>
		/// <param name="lstCustomer"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond 
        public DataTable GetListCPAReportOnCPAByAccountOfficer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc, ref int iRow, ref List<clsCPAReport_On_CPA_By_Account_OfficerDTO> lstCustomer,string realFrom)
		{
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_CPA_By_Account_Officer", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
			iRow = reader.AsEnumerable().GroupBy(r => r.Field<string>("CustomerID")).Count();

			reader.Columns.Add("CalItem");

			lstCustomer = new List<clsCPAReport_On_CPA_By_Account_OfficerDTO>();
			clsCPAReport_On_CPA_By_Account_OfficerDTO dto = new clsCPAReport_On_CPA_By_Account_OfficerDTO();
			for (int i = 0; i < reader.Rows.Count; i++)
			{
				dto = new clsCPAReport_On_CPA_By_Account_OfficerDTO(reader.Rows[i]);
				dto.CalItem = dto.GetCPaByAccountRpr01();
				lstCustomer.Add(dto);
				reader.Rows[i][reader.Columns.Count - 1] =dto.CalItem;
			}
			return reader;
		}
		 

		/// <summary>
		/// Get server datetime
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond 
		public string GetServerDate()
		{
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetServerDate", CommandType.StoredProcedure);
			return "_" + ((DateTime) reader.Rows[0][0]).ToString("yyyyMMdd");
		}


        /// <summary>
        /// Get list CPA in Quarter
        /// </summary>
        /// <param name="yearMonth"></param>
        /// <param name="customerID"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond 
        public DataTable GetListCPAinQuarter(string yearMonth, string customerID,string customerName)
        {
            SqlParameter[] parameters = new SqlParameter[10];
       
            parameters[1] = new SqlParameter("@yearMonthTo", yearMonth);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", customerName);
                   parameters[4] = new SqlParameter("@department", DBNull.Value);
            parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", "");
            parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);

            DateTime date = new DateTime(int.Parse(yearMonth.Remove(4)), int.Parse(yearMonth.Remove(0, 4)), 1);
            date = date.AddMonths(-2);
            string preMonth = date.Year.ToString() + date.Month.ToString("00");

            parameters[0] = new SqlParameter("@yearMonthFrom", preMonth);

            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetListCPACustomerForPrintViewReport", CommandType.StoredProcedure, parameters);
            return reader;
        }

        /// <summary>
        /// Get list Current And Pre CPA
        /// </summary>
        /// <param name="yearMonth"></param>
        /// <param name="customerID"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond 
        public DataTable GetListCurrentAndPreCPA(string yearMonth , string customerID)
        {
            DateTime date = new DateTime(int.Parse(yearMonth.Remove(4)), int.Parse(yearMonth.Remove(0, 4)), 1);
            date = date.AddMonths(-1);//previous month
            string preMonth = date.Year.ToString() + date.Month.ToString("00");
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", preMonth);
            parameters[1] = new SqlParameter("@yearMonthTo", yearMonth);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", "");
            parameters[4] = new SqlParameter("@department", DBNull.Value);
            parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", "");
            parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


            return m_DAL.ExecuteDataReader("dbo.spCPA_GetListCPACustomer", CommandType.StoredProcedure, parameters);

        }

        /// <summary>
        /// Get List CPACustomerDTo for Report_On_Deposit_Profit_By_Customer
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="customerID"></param>
        /// <param name="cusName"></param>
        /// <param name="departmentName"></param>
        /// <param name="teamName"></param>
        /// <param name="JNJ"></param>
        /// <param name="VNAcc"></param>
        /// <param name="JPAcc"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListCPAReportOnDepositProfitByCustomer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc,string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_Deposit_Profit_By_Customer", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTORerport09(reader.Rows[i])));
            }
            return ListCPACustomer;
        }

        /// <summary>
        /// Get List CPACustomerDTo for Report_On_Loan_Profit_By_Customer
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="customerID"></param>
        /// <param name="cusName"></param>
        /// <param name="departmentName"></param>
        /// <param name="teamName"></param>
        /// <param name="JNJ"></param>
        /// <param name="VNAcc"></param>
        /// <param name="JPAcc"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListCPAReportOnLoanProfitByCustomer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc, string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_Loan_Profit_By_Customer", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTORerport10(reader.Rows[i])));
            }
            return ListCPACustomer;
        }

        /// <summary>
        /// Get top List CPACustomerDTo for Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="JNJ"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListTopCPAReportOnTopCustomerInTermDepositAverageBalance(string from, string to, string JNJ, int top,string cusId,string cusName,string dep,string team,string jp,string vn,string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[11];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@jnj", JNJ);
            parameters[3] = new SqlParameter("@top", top);
            parameters[4] = new SqlParameter("@customerID", cusId);
            parameters[5] = new SqlParameter("@customerName", cusName);
            if(dep != "")
            parameters[6] = new SqlParameter("@department", dep);
            else parameters[6] = new SqlParameter("@department", DBNull.Value);
            if (team != "")
                parameters[7] = new SqlParameter("@team", team);
            else parameters[7] = new SqlParameter("@team", DBNull.Value);
            if (jp != "")
                parameters[8] = new SqlParameter("@jpAcc", jp);
            else parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            if (vn != "")
                parameters[10] = new SqlParameter("@vnAcc", vn);
            else parameters[10] = new SqlParameter("@vnAcc", DBNull.Value);

            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);

			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetTop_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance", CommandType.StoredProcedure, parameters);
            ReCheckReaderTop(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTOTopRerport11(reader.Rows[i])));
            }
            return ListCPACustomer;
        }

        /// <summary>
        /// Get List CPACustomerDTo for Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="customerID"></param>
        /// <param name="cusName"></param>
        /// <param name="departmentName"></param>
        /// <param name="teamName"></param>
        /// <param name="JNJ"></param>
        /// <param name="VNAcc"></param>
        /// <param name="JPAcc"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListCPAReportTopCustomerInTermOfDepositAverageBalance(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc,string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_Top_50_Customers_In_Terms_Of_Deposit_Average_Balance", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTORerport11(reader.Rows[i])));
            }
            return ListCPACustomer;
        }

        /// <summary>
        /// Get top List CPACustomerDTo for report Top_50_Customers_In_Terms_Of_Loan_Average_Balance
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="JNJ"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListTopCPAReportOnTopCustomerInTermOfLoanAverageBalance(string from, string to, string JNJ, int top, string cusId, string cusName, string dep, string team, string jp, string vn,string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[11];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@jnj", JNJ);
            parameters[3] = new SqlParameter("@top", top);
            parameters[4] = new SqlParameter("@customerID", cusId);

            parameters[5] = new SqlParameter("@customerName", cusName);
            if (dep != "")
                parameters[6] = new SqlParameter("@department", dep);
            else parameters[6] = new SqlParameter("@department", DBNull.Value);
            if (team != "")
                parameters[7] = new SqlParameter("@team", team);
            else parameters[7] = new SqlParameter("@team", DBNull.Value);
            if (jp != "")
                parameters[8] = new SqlParameter("@jpAcc", jp);
            else parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            if (vn != "")
                parameters[9] = new SqlParameter("@vnAcc", vn);
            else parameters[9] = new SqlParameter("@vnAcc", DBNull.Value);

            parameters[10] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);

			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetTop_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance", CommandType.StoredProcedure, parameters);
            ReCheckReaderTop(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTOTopRerport11(reader.Rows[i])));
            }
            return ListCPACustomer;
        }

        /// <summary>
        /// Get List CPACustomerDTo for report Top_50_Customers_In_Terms_Of_Loan_Average_Balance
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="customerID"></param>
        /// <param name="cusName"></param>
        /// <param name="departmentName"></param>
        /// <param name="teamName"></param>
        /// <param name="JNJ"></param>
        /// <param name="VNAcc"></param>
        /// <param name="JPAcc"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListCPAReportOnTopCustomerInTermOfLoanAverageBalance(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc,string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);

            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);

			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_Top_50_Customers_In_Terms_Of_Loan_Average_Balance", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTORerport12(reader.Rows[i])));
            }
            return ListCPACustomer;
        }

        /// <summary>
        /// Get top list CPACustomer for report Top_50_Customers_In_Terms_Of_Total_Profit
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="JNJ"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListTopCPAReportOnTopCustomerInTermOfTotalProfit(string from, string to, string JNJ, int top, string cusId, string cusName, string dep, string team, string jp, string vn,string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[11];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@jnj", JNJ);
            parameters[3] = new SqlParameter("@top", top);

            parameters[4] = new SqlParameter("@customerID", cusId);
            parameters[5] = new SqlParameter("@customerName", cusName);
            if (dep != "")
                parameters[6] = new SqlParameter("@department", dep);
            else parameters[6] = new SqlParameter("@department", DBNull.Value);
            if (team != "")
                parameters[7] = new SqlParameter("@team", team);
            else parameters[7] = new SqlParameter("@team", DBNull.Value);
            if (jp != "")
                parameters[8] = new SqlParameter("@jpAcc", jp);
            else parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            if (vn != "")
                parameters[9] = new SqlParameter("@vnAcc", vn);
            else parameters[9] = new SqlParameter("@vnAcc", DBNull.Value);
            parameters[10] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetTop_Top_50_Customers_In_Terms_Of_Total_Profit", CommandType.StoredProcedure, parameters);
            ReCheckReaderTop(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTOTopRerport11(reader.Rows[i])));
            }
            return ListCPACustomer;
        }

        /// <summary>
        /// Get list CPACustomer for report Top_50_Customers_In_Terms_Of_Total_Profit
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="customerID"></param>
        /// <param name="cusName"></param>
        /// <param name="departmentName"></param>
        /// <param name="teamName"></param>
        /// <param name="JNJ"></param>
        /// <param name="VNAcc"></param>
        /// <param name="JPAcc"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListCPAReportOnTopCustomerInTermOfTotalProfit(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc,string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);


			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Top_50_Customers_In_Terms_Of_Total_Profit", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTORerport13(reader.Rows[i])));
            }
            return ListCPACustomer;
        }

        /// <summary>
        /// Get top list CPACustomer for Report_On_CPA_By_Account_Officer_Top_20_Customers
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="JNJ"></param>
        /// <param name="top"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListTopCPACustomerReport_On_CPA_By_Account_Officer_Top_20_Customers(string from, string to, string JNJ, int top, string cusId, string cusName, string dep, string team, string jp, string vn,string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[11];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@top", top);
            parameters[3] = new SqlParameter("@customerID", cusId);
            parameters[4] = new SqlParameter("@customerName", cusName);
            if (dep != "")
                parameters[5] = new SqlParameter("@department", dep);
            else parameters[5] = new SqlParameter("@department", DBNull.Value);
            if (team != "")
                parameters[6] = new SqlParameter("@team", team);
            else parameters[6] = new SqlParameter("@team", DBNull.Value);
            if (jp != "")
                parameters[7] = new SqlParameter("@jpAcc", jp);
            else parameters[7] = new SqlParameter("@jpAcc", DBNull.Value);
            if (vn != "")
                parameters[8] = new SqlParameter("@vnAcc", vn);
            else parameters[8] = new SqlParameter("@vnAcc", DBNull.Value);
            parameters[9] = new SqlParameter("@jnj", JNJ);

            parameters[10] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetTop_Report_On_CPA_By_Account_Officer_Top_20_Customers", CommandType.StoredProcedure, parameters);
            ReCheckReaderTop(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTOTopRerport03(reader.Rows[i])));
            }
            return ListCPACustomer;
        }

        /// <summary>
        /// Get list CPACustomer for Report_On_CPA_By_Account_Officer_Top_20_Customers
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="customerID"></param>
        /// <param name="cusName"></param>
        /// <param name="departmentName"></param>
        /// <param name="teamName"></param>
        /// <param name="JNJ"></param>
        /// <param name="VNAcc"></param>
        /// <param name="JPAcc"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public List<clsCPACustomerDTO> GetListCPAReportOnCPAbyAccountOfficerTop20Customer(string from, string to, string customerID, string cusName, string departmentName, string teamName, string JNJ, string VNAcc, string JPAcc,string realFrom)
        {
            SqlParameter[] parameters = new SqlParameter[10];
            parameters[0] = new SqlParameter("@yearMonthFrom", from);
            parameters[1] = new SqlParameter("@yearMonthTo", to);
            parameters[2] = new SqlParameter("@customerID", customerID);
            parameters[3] = new SqlParameter("@customerName", cusName);
            if (departmentName != "")
                parameters[4] = new SqlParameter("@department", departmentName);
            else
                parameters[4] = new SqlParameter("@department", DBNull.Value);
            if (teamName != "")
                parameters[5] = new SqlParameter("@team", teamName);
            else
                parameters[5] = new SqlParameter("@team", DBNull.Value);
            parameters[6] = new SqlParameter("@jnj", JNJ);
            if (VNAcc != "")
                parameters[7] = new SqlParameter("@vnAcc", VNAcc);
            else
                parameters[7] = new SqlParameter("@vnAcc", DBNull.Value);
            if (JPAcc != "")
                parameters[8] = new SqlParameter("@jpAcc", JPAcc);
            else
                parameters[8] = new SqlParameter("@jpAcc", DBNull.Value);

            parameters[9] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);
			DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_Report_On_CPA_By_Account_Officer_Top_20_Customers", CommandType.StoredProcedure, parameters);
            ReCheckReader(realFrom, reader);
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                ListCPACustomer.Add((new clsCPACustomerDTO().GetCPACustomerDTORerport03(reader.Rows[i])));
            }
            return ListCPACustomer;
        }
    }
}
