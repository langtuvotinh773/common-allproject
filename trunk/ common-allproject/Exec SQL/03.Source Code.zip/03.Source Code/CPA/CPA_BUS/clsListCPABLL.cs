﻿
/*
 * Author:  Phong Nguyen
 * Created: 3-Jan-2013
 * 
 * This class is used to process data in List CPA Screen
 * 
 * 
 */

using System.Collections.Generic;

using System.Data.SqlClient;
using System.Data;
using Phoenix.Cpa.Dal;
using System.Collections;
using Phoenix.Cpa.Common;
using Config.Classes;
using Phoenix.Common.Log.Com;

namespace Phoenix.Cpa.Bus
{
    class clsListCPABLL
    {
        clsDataAccessLayer m_DAL = null; // data access class
        public SqlTransaction Transaction;// current transaction
        public SqlConnection conection;// current connection
        public clsListCPABLL()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// get data for List CPA screen
        /// </summary>
        /// <param name="from">datatime from</param>
        /// <param name="to">datetime to</param>
        /// <param name="cusID">customerID</param>
        /// <param name="cusFullName">customer Full Name</param>
        /// <param name="cusShortName">customer Short Name</param>
        /// <param name="status">CPA status</param>
        /// <returns></returns>
        public DataTable GetTransactionData(string from, string to, string cusID, string cusFullName, string cusShortName, string status)
        {
            SqlParameter[] parameters = new SqlParameter[7];
            parameters[0] = new SqlParameter("@from",from);
            parameters[1] = new SqlParameter("@to", to);
            parameters[2] = new SqlParameter("@customerID", cusID);
            parameters[3] = new SqlParameter("@customerFullName", cusFullName);
            parameters[4] = new SqlParameter("@customerShortName", cusShortName);
            parameters[5] = new SqlParameter("@status", status);
            parameters[6] = new SqlParameter("@teamType", clsCPAConstant.TEAMTYPE);

            DataTable reader = m_DAL.ExecuteDataReader("dbo.spCPA_GetListCPA", CommandType.StoredProcedure, parameters);
            return reader;
        }

        /// <summary>
        /// update report status for CPAs
        /// </summary>
        /// <param name="lstData">list data need to update</param>
        /// <returns></returns>
        public int UpdateTransaction(ArrayList lstData)
        {
            List<SqlParameter[]> lstParam = new List<SqlParameter[]>();
            for (int i = 0; i < lstData.Count; i++)
            {
                string[] dataRow = (string[])lstData[i];
                
                SqlParameter[] parameters = new SqlParameter[4];
                parameters[0] = new SqlParameter("@yearMonth", dataRow[0]);
                parameters[1] = new SqlParameter("@customerID", dataRow[1]);
                parameters[2] = new SqlParameter("@status", bool.Parse(dataRow[2]));
                int a = 20;

                parameters[3] = new SqlParameter("@Count", a);
                parameters[3].Direction = ParameterDirection.InputOutput;
                lstParam.Add(parameters);
                clsCPALogBase log = new clsCPALogBase();
                log.Key = dataRow[0] + " " + dataRow[1];
                log.UserID = clsUserInfo.UserNo.ToString();
                log.ApplicationName = "List CPA";
                log.Action = (int)CommonValue.ActionType.Update;
                log.LstLogInformation.Add(new clsCPALogInformation
                {

                    FieldName = "Report Status",
                    OldValue = (!bool.Parse(dataRow[2])).ToString(),
                    NewValue = bool.Parse(dataRow[2]).ToString()
                });

                log.WirteLog(m_DAL);

            }
        
            int row = m_DAL.ExecuteNonQuery("dbo.spCPA_UpdateListCPA", CommandType.StoredProcedure, lstParam);
            Transaction = m_DAL.m_transaction;
            conection = m_DAL.m_Connection;
          
            return row;
        }

        /// <summary>
        /// commit transaction
        /// </summary>
        public void Commit()
        {
            Transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        public void RollBack()
        {
            Transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
        }
    }
}
