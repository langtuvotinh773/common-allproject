﻿
/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define all Messages in CPA
 * for CPA module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phoenix.Cpa.Common
{
	public class clsCPACommonMessage
	{
		#region Status Messages

		public static readonly string NO_TRANSACTION_FOUND = "No transaction found";
		public static readonly string STATUS_FINALIZE = "Finalized";
		public static readonly string STATUS_NOTFINALIZE = "Not Finalized";


		#endregion
		public const string IMPORT_EDP_LIST = "Import EDP List";
        public const string FILE_DOES_NOT_EXIST = "File is not found";
		public const string TYPE_OF_FILE_MUST_BE_TXT = "File type is invalid";
        public const string SELECT_FILE_TO_IMPORT = "You must select file to import";
        public const string FILE_IS_NULL = "File is empty";
        public const string CPA_COMPLETED = "This CPA has finalized, you can not import";

		#region IMPORT EDP LIST
        public const string CONFIRM_IMPORT_AGAIN = "This CPA was already imported, do you want to reimport ?";
	
       
        public const string CAN_NOT_IMPORT = " There is error data in import data, do you want to process error data?";
		public const string SELECT_LEAST_ONE_TO_DELETE = "You must select at least one customer error to delete !";
       public const string DO_YOU_WANT_TO_DELETE = "Do you want to delete selected customer error ?";
		#endregion

		#region ERROR
		public const string ERROR_INPUT_MONTH_YEAR = "Invalid month year input!";
		#endregion 
		#region Confirmation

        public static string DO_YOU_WANT_SAVE = "Do you want to save change?";

		#endregion
	}
}
