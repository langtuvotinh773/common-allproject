﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define all Constants in CPA
 * for CPA module.
 */
using System.Drawing;
namespace Phoenix.Cpa.Common
{
	public class clsCPAConstant
	{
		#region COMMON
        //public static Color BG_FORM = System.Drawing.ColorTranslator.FromHtml("#E0DFE3");
        //public static Color BG_BUTTON= System.Drawing.ColorTranslator.FromHtml("#F6F7FD");
		#endregion
		#region ERROR TYPE
		public const string ERROR_TYPE_01 = "Customer account is closed all in Phoenix system.";
		public const string ERROR_TYPE_02 = "CPA list is mismatch (Exist in Phoenix but not Exist in SMILE";
		public const string ERROR_TYPE_03 = "CPA list is mismatch (not Exist in Phoenix but Exist in SMILE";
		public const string ERROR_TYPE_04 = "Customer is not Exist Phoenix";
        public const string TEAMTYPE = "1";
		#endregion

		#region DATE TIME
		public const int DAY_IN_YEAR = 365;
		public const int MONTH_PER_YEAR = 12;
		public const int MONTH_PER_QUARTER = 3;
		#endregion

        //Message new
        public const string CPA_TEXT = "CPA";
        public const string FINALIZE_TEXT = "finalized status";
        public const string SAVE_ACTION = "Save";

        public const string ACT_DELETE = "delete";
        public const string ACT_DELETING = "Delete";
        public const string ACT_UPDATE = "modify";
        public const string ACT_UPDATING = "Modifying";
        public const string IMPORT_ACTION = "Import";

		#region frmCPAListCPA

        
		public const string NOTSHOWREPORT = "ReportStatus";
		public const string CPA_STATUS = "CPA_Status";
		public const string CUSTOMERCODE = "CustomerID";

		public const string CUSFULLNAME = "Name";
		public const string CUSSHORTNAME = "ShortName";
		public const string MONTHYEAR = "YearMonth";
		public const string DEPOSIT = "Deposit";
		public const string TOTALPL = "TotalPL";
		public const string VIEWFUNTION = "viewFuntion";
		public const string UPDATEFUNTION = "updateFuntion";

		public const string JAN = "Jan";
		public const string FEB = "Feb";
		public const string MAR = "Mar";
		public const string APR = "Apr";
		public const string MAY = "May";
		public const string JUN = "Jun";
		public const string JUL = "Jul";
		public const string AUG = "Aug";
		public const string SEP = "Sep";
		public const string OCT = "Oct";
		public const string NOV = "Nov";
		public const string DEC = "Dec";

		public const string MONTH_01 = "01";
		public const string MONTH_02 = "02";
		public const string MONTH_03 = "03";
		public const string MONTH_04 = "04";
		public const string MONTH_05 = "05";
		public const string MONTH_06 = "06";
		public const string MONTH_07 = "07";
		public const string MONTH_08 = "08";
		public const string MONTH_09 = "09";
		public const string MONTH_10 = "10";
		public const string MONTH_11 = "11";
		public const string MONTH_12 = "12";

		public const string QUARTER_01 = "1";
		public const string QUARTER_02 = "2";
		public const string QUARTER_03 = "3";
		public const string QUARTER_04 = "4";

		#endregion

		#region REPORT
		#region COLOR
		public static int REPORT_BORDER_COLOR = System.Drawing.Color.Black.ToArgb();
		#endregion
		#region COLUMN LIST
		public const string RPT_COL_YEARMONTH = "YearMonth";
		public const string RPT_COL_CUSTOMERID = "CustomerID";
		public const string RPT_COL_STL_OVERDRAFT_AVE = "STL_Overdraft_AVE";
		public const string RPT_COL_STL_OVERDRAFT_REC = "[STL_Overdraft_REC]";
		public const string RPT_COL_STL_OVERDRAFT_PAY = "[STL_Overdraft_PAY]";
		public const string RPT_COL_STL_COMMERCIALBILL_AVE = "STL_CommercialBill_AVE";
		public const string RPT_COL_STL_COMMERCIALBILL_REC = "[STL_CommercialBill_REC]";
		public const string RPT_COL_STL_COMMERCIALBILL_PAY = "[STL_CommercialBill_PAY]";
		public const string RPT_COL_STL_LOAN_AVE = "STL_Loan_AVE";
		public const string RPT_COL_STL_LOAN_REC = "[STL_Loan_REC]";
		public const string RPT_COL_STL_LOAN_PAY = "[STL_Loan_PAY]";
		public const string RPT_COL_LTL_FIXED_AVE = "LTL_Fixed_AVE";
		public const string RPT_COL_LTL_FIXED_REC = "[LTL_Fixed_REC]";
		public const string RPT_COL_LTL_FIXED_PAY = "[LTL_Fixed_PAY]";
		public const string RPT_COL_LTL_FLOATING_AVE = "LTL_Floating_AVE";
		public const string RPT_COL_LTL_FLOATING_REC = "[LTL_Floating_REC]";
		public const string RPT_COL_LTL_FLOATING_PAY = "[LTL_Floating_PAY]";
		public const string RPT_COL_BB_AVE = "BB_AVE";
		public const string RPT_COL_BB_REC = "[BB_REC]";
		public const string RPT_COL_BB_PAY = "[BB_PAY]";
		public const string RPT_COL_BR_AVE = "BR_AVE";
		public const string RPT_COL_BR_REC = "[BR_REC]";
		public const string RPT_COL_BR_PAY = "[BR_PAY]";
		public const string RPT_COL_OTHERAPP_AVE = "OtherApp_AVE";
		public const string RPT_COL_OTHERAPP_REC = "[OtherApp_REC]";
		public const string RPT_COL_OTHERAPP_PAY = "[OtherApp_PAY]";
		public const string RPT_COL_DEP_LIQUID_AVE = "Dep_Liquid_AVE";
		public const string RPT_COL_DEP_LIQUID_REC = "[Dep_Liquid_REC]";
		public const string RPT_COL_DEP_LIQUID_PAY = "[Dep_Liquid_PAY]";
		public const string RPT_COL_DEP_FIXED_AVE = "Dep_Fixed_AVE";
		public const string RPT_COL_DEP_FIXED_REC = "[Dep_Fixed_REC]";
		public const string RPT_COL_DEP_FIXED_PAY = "[Dep_Fixed_PAY]";
		public const string RPT_COL_OTHERSOURCE_AVE = "OtherSource_AVE";
		public const string RPT_COL_OTHERSOURCE_REC = "[OtherSource_REC]";
		public const string RPT_COL_OTHERSOURCE_PAY = "[OtherSource_PAY]";
		public const string RPT_COL_RESERVEREQ_AVE = "ReserveReq_AVE";
		public const string RPT_COL_RESERVEREQ_REC = "[ReserveReq_REC]";
		public const string RPT_COL_RESERVEREQ_PAY = "[ReserveReq_PAY]";
		public const string RPT_COL_GUARANTEE_AVE = "Guarantee_AVE";
		public const string RPT_COL_GUARANTEE_INC = "[Guarantee_INC]";
		public const string RPT_COL_CLEANLC_AVE = "CleanLC_AVE";
		public const string RPT_COL_CLEANLC_INC = "[CleanLC_INC]";
		public const string RPT_COL_ACCEPTANCE_AVE = "Acceptance_AVE";
		public const string RPT_COL_ACCEPTANCE_INC = "[Acceptance_INC]";
		public const string RPT_COL_COMMITMENT_AVE = "Commitment_AVE";
		public const string RPT_COL_COMMITMENT_INC = "[Commitment_INC]";
		public const string RPT_COL_OTHERS_AVE = "Others_AVE";
		public const string RPT_COL_OTHERS_INC = "[Others_INC]";
		public const string RPT_COL_DOCLC_TUR = "DocLC_TUR";
		public const string RPT_COL_DOCLC_INC = "[DocLC_INC]";
		public const string RPT_COL_EXPBILLHANDLING_TUR = "ExpBillHandling_TUR";
		public const string RPT_COL_EXPBILLHANDLING_INC = "[ExpBillHandling_INC]";
		public const string RPT_COL_IMPBILLHANDLING_TUR = "ImpBillHandling_TUR";
		public const string RPT_COL_IMPBILLHANDLING_INC = "[ImpBillHandling_INC]";
		public const string RPT_COL_COLLECTING_TUR = "Collecting_TUR";
		public const string RPT_COL_COLLECTING_INC = "[Collecting_INC]";
		public const string RPT_COL_PAYMENT_TUR = "Payment_TUR";
		public const string RPT_COL_PAYMENT_INC = "[Payment_INC]";
		public const string RPT_COL_REMITTANCE_TUR = "Remittance_TUR";
		public const string RPT_COL_REMITTANCE_INC = "[Remittance_INC]";
		public const string RPT_COL_LOAN_TUR = "Loan_TUR";
		public const string RPT_COL_LOAN_INC = "[Loan_INC]";
		public const string RPT_COL_OTHERS01_TUR = "Others01_TUR";
		public const string RPT_COL_OTHERS01_INC = "[Others01_INC]";
		public const string RPT_COL_FOREIGNEXCHANGEPL_TUR = "ForeignExchangePL_TUR";
		public const string RPT_COL_FOREIGNEXCHANGEPL_INC = "[ForeignExchangePL_INC]";
		public const string RPT_COL_OTHERS02_TUR = "Others02_TUR";
		public const string RPT_COL_OTHERS02_INC = "[Others02_INC]";
		public const string RPT_COL_REPORTSTATUS = "ReportStatus";
		#endregion
		#endregion

		#region IMPORT_EDP_LIST
		public const string STL_OVERDRAFT = "STL_Overdraft";
		public const string STL_COMMERCIALBILL = "STL_CommercialBill";
		public const string STL_LOAN = "STL_Loan";
		public const string LTL_FIXED = "LTL_Fixed";
		public const string LTL_FLOATING = "LTL_Floating";
		public const string BB = "BB";
		public const string BR = "BR";
		public const string OTHERAPP = "OtherApp";
		public const string DEP_LIQUID = "Dep_Liquid";
		public const string DEP_FIXED = "Dep_Fixed";
		public const string OTHERSOURCE = "OtherSource";
		public const string RESERVEREQ = "ReserveReq";
		public const string CLEANLC = "CleanLC";
		public const string DOCLC = "DocLC";
		public const string EXPBILLHANDLING = "ExpBillHandling";
		public const string IMPBILLHANDLING = "ImpBillHandling";
		public const string PAYMENT = "Payment";
		public const string REMITTANCE = "Remittance";
		public const string LOAN = "Loan";
		public const string OTHERS01 = "Others01";
		public const string FOREIGNEXCHANGEPL = "ForeignExchangePL";
		public const string OTHERS02 = "Others02";

		#endregion

		#region REPORT LIST
		public const string R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER = "REPORT ON CPA BY ACCOUNT OFFICER";
		public const string R_L_REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS = "REPORT ON CPA BY ACCOUNT OFFICER - TOP ";
		public const string R_L_REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER = "REPORT ON DEPOSIT AVERAGE BALANCE BY CUSTOMER";
		public const string R_L_REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER = "REPORT ON LOAN AVERAGE BALANCE BY CUSTOMER";
		public const string R_L_REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER = "REPORT ON COMMISSION AND FEE BY CUSTOMER";
		public const string R_L_REPORT_ON_FOREX_PROFIT_BY_CUSTOMER = "REPORT ON FOREX PROFIT  BY CUSTOMER";
		public const string R_L_REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER = "REPORT ON TOTAL PROFIT BY CUSTOMER";
		public const string R_L_REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER = "REPORT ON DEPOSIT PROFIT  BY CUSTOMER";
		public const string R_L_REPORT_ON_LOAN_PROFIT_BY_CUSTOMER = "REPORT ON  LOAN PROFIT BY CUSTOMER";
		public const string R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE = " CUSTOMERS IN TERMS OF DEPOSIT AVERAGE BALANCE";
		public const string R_L_REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE = " CUSTOMERS IN TERMS OF LOAN AVERAGE BALANCE";
		public const string R_L_TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT = " CUSTOMERS IN TERMS OF TOTAL PROFIT";																		 
		public const string R_L_CUSTOMER_INFORMATION = "CUSTOMER INFORMATION";
		#endregion



		#region CPA FOR CBD ROW HEADER NAME
		public const string DEPOSIT_AVERAGE_BALANCE = "Deposit Average Balance";
		public const string LOAN_AVERAGE_BALANCE = "Loan Average Balance";
		public const string PROFIT_OF_COMMISSION_AND_FEE = "Profit of commission and fee";
		public const string PROFIT_OF_FOREX = "Profit of forex";
		public const string TOTAL_PROFIT = "Total profit";
		public const string PROFIT_OF_DEPOSIT = "Profit of deposit";
		public const string PROFIT_OF_LOAN = "Profit of Loan";

		#endregion

		#region frmCPAListCPA
		public const string FORM_TEXT = "List CPA";
		public const string NOT_SHOW_IN_REPORT = "Not Show In Report";
		public const string STATUS = "Status";
		public const string CUSTOMER_SHORT_NAME = "Customer Short Name";
		public const string MONTH_YEAR = "Month Year";
		public const string TOTAL_PL = "Total P/L";
		#endregion

		#region Finalize CPA Data
		public const string FINALIZE_CPA_DATA = "Finalize CPA Data";
		public const string END_OF_LIST = "*** END OF LIST ***";
		public const string HO_CHI_MINH_CITY_BRANCH = "HO CHI MINH CITY BRANCH";
		#region DIALOG FILTER
		public const string DIALOG_FILTER_TXT = "txt Files|*.txt";
		#endregion
		#region IMPORT EDP LIST
		public const string END_OF_FILE_IMPORT = ".txt";
		#endregion
		#endregion

		#region LIST CUSTOMER ERROR
		public const string LIST_CUSTOMER_ERROR = "List Customer Error";
		#endregion

		#region COMBOBOX DATA
		public const string NAME = "Name";
		public const string VALUE = "Value";
		public const string DISPLAY = "Display";
		public const string DEPARTMENT_NAME = "DepartmentName";
		public const string DEPARTMENT_ID = "DepartmentID";
		public const string SECTION_NAME = "SectionName";
		public const string SECTION_ID = "SectionID";
		public const string USER_NAME = "UserName";
		public const string USER_ID = "UserID";
		#endregion

		#region REPORT
        public const string CUSTOMER_PROFIABILITY_ANALYSIS_REPORT = "Customer Profitability Analysis Report";
        public const string CUSTOMER_PROFIABILITY_ANALYSIS_REPORT_PARAM_NAME = "nameReport";
        public const string REPORT_FOR_A_CUSTOMER = "Report for a customer";
        public const string REPORT_FOR_A_CUSTOMER_PARAM_NAME_CONST1 = "constand01";
        public const string REPORT_FOR_A_CUSTOMER_PARAM_NAME_CONST2 = "constand02";
        public const string REPORT_FOR_A_CUSTOMER_PARAM_NAME_CONST3 = "constand03";
        public const string QUATER_STRING_01 = "1st Quarter/";
        public const string QUATER_STRING_02 = "2nd Quarter/";
        public const string QUATER_STRING_03 = "3rd Quarter/";
        public const string QUATER_STRING_04 = "4th Quarter/";
        public const string REPORT_FOR_A_CUSTOMER_PARAM_NAME_CONST6 = "timeString";
        public const string REPORT_FOR_A_CUSTOMER_PARAM_NAME_06 = "Customer Profitability - ";
        public const string REPORT_FOR_CUSTOMER_TRANSACTIONS_PARAM_04_NAME = "time";
   
        public const string REPORT_FOR_CUSTOMER_TRANSACTIONS_PARAM_05_NAME = "customerName";

        public const string REPORT_FOR_CUSTOMER_TRANSACTIONS_PARAM_14_NAME = "month";
        public const string PROJECT_NAME_CPA = "CPA";
        public const string INPUT_VNACC_REQUIRE = "Please choose a VN Account officer";
		#region REPORT PROFIT
		public const string JAPAN_ACCOUNT = "JPAcc";
		public const string VN_ACCOUNT = "VNAcc";
		public const string TEAM = "Team";
		#endregion

		#region REPORT CUSTOMER TRANSACTION
		public const string SHORT_TERN_LOAN = "Short Term Loan";
		public const string OVERDRAFT = "Overdraft";
		public const string COMMERCIAL_BILL = "Commercial Bill";
		public const string LONG_TERN_LOAN = "Long Term Loan";
		public const string FIXED = "Fixed";
		public const string FLOATING = "Floating";
		public const string B_B = "B/B";
		public const string B_R = "B/R";
		public const string OTHER_APPLICATION = "Other Application";
		public const string TOTAL_APPLICATION = "Total Application";
		public const string DEPOSITS = "Deposits";
		public const string LIQUID = "Liquid";
		public const string OTHER_SOURCE = "Other Source";
		public const string TOTAL_SOURCE = "Total Source";
		public const string RESERVE_REQUIREMENT = "Reserve Requirement";
		public const string TOTAL = "TOTAL";
		public const string NON_FUNDS_TRANSACTIONS = "Non-Funds Transactions";
		public const string COMMISSION_AND_FEES = "Commission and Fees";
		public const string GUARANTEE = "Guarantee";
		public const string CLEAN_LC = "Clean L/C";
		public const string ACCEPTANCE = "Acceptance";
		public const string COMMITMENT = "Commitment";
		public const string OTHERS = "Others";
		public const string DOCUMENTARY_LC_OPEN = "Documentary L/C Open";
		public const string EXP_BILL_HANDLING = "Exp Bill Handling";
		public const string IMP_BILL_HANDLING = "Imp Bill Handling";
		public const string COLLECTING = "Collecting";
		public const string FOREIGN_EXCHANGE_PL = "Foreign Exchange P/L";

		public const string ST_OVEDRAFT = "S/T Ovedraft";
		public const string ST_COMMECIAL_BILL = "S/T Commercial Bill";
		public const string ST_LOAN = "S/T Loan";
		public const string LT_LOAN_FIXED = "L/T Loan (Fixed)";
		public const string LT_LOAN_FLOATING = "L/T Loan (Floating)";
		public const string DEPO_LIQUID = "Depo (Liquid)";
		public const string DEPO_FIXED = "Depo (Fixed)";
		public const string BILL_BOUGHT = "Bill Bought";
		#endregion

		#region REPORT TITLE
        public const string REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TITLE = " REPORT ON CPA BY ACCOUNT OFFICER";
        public const string REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER_INC_DES = "Change";


		#endregion

		#region REPORT HEADER

        ////R_01(All-VN)
        public const string R_H_CODE = "Code";
        public const string R_H_NAME = "Name";
        public const string R_H_TEAM = "Team";
        public const string R_H_JNJ = "JNJ";
        public const string R_JP_ACCOUNT_OFFICER = "JP Account Officer";
        public const string R_VN_ACCOUNT_OFFICER = "VN Account Officer";

        public const string R_01_BY_ACOUNT_OFFICER = "By Acount Officer";
        public const string R_COL_CHANGE = "Change";
      

		//R_02(All-VN)
		public const string R_H_SUM_OFFICER1 = "Sum officer1";
		public const string R_H_SUM_OFFICER2 = "Sum officer2";
		public const string R_H_SUM_OFFICER3 = "Sum officer3";
		public const string R_H_SUM_STAFF1 = "Sum Staff1";
		public const string R_H_SUM_STAFF2 = "Sum Staff2";
		public const string R_H_SUM_STAFF3 = "Sum Staff3";
		public const string R_H_SUM_STAFF4 = "Sum Staff4";
		public const string R_H_GOUP_TEAM1 = "Goup Team1";
		public const string R_H_GOUP_TEAM2 = "Goup Team2";
		public const string R_H_GOUP_TEAM3 = "Goup Team3";

		public const string R_H_TOTAL = "Total";
		public const string R_H_AVERAGE = "Average";
		public const string R_H_FROM_TO = "From Date:  {0}    To Date:  {1}";
		public const string R_TOTAL_TOP = "Total Top {0}";
		public const string R_TOTAL_RATE = "Rate (Total top {0}/ Total) %";
		//R_01_02
		public const string R_H_FROM_QUARTER = "From Quarter";
		public const string R_H_TO_QUARTER = "To Quarter";
		public const string R_H_DEPARTMENT = "Department";
		public const string R_H_CUSTOMER_FULL_NAME = "Customer Full Name";
		public const string R_H_DATE = "Date";

		#endregion

		#endregion

		#region TEMPLATE NAME
		public const string REPORT_ON_CPA_BY_ACCOUNT_OFFICER = "REPORT ON CPA BY ACCOUNT OFFICER.xls";
		public const string REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS = "REPORT ON CPA BY ACCOUNT OFFICER - TOP 20 CUSTOMERS.xls";
		public const string REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER = "REPORT ON DEPOSIT AVERAGE BALANCE BY CUSTOMER.xls";
		public const string REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER = "REPORT ON LOAN AVERAGE BALANCE BY CUSTOMER.xls";
		public const string REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER = "REPORT ON COMMISSION AND FEE BY CUSTOMER.xls";
		public const string REPORT_ON_FOREX_PROFIT_BY_CUSTOMER = "REPORT ON FOREX PROFIT BY CUSTOMER.xls";
		public const string REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER = "REPORT ON TOTAL PROFIT BY CUSTOMER.xls";
		public const string REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER = "REPORT ON DEPOSIT PROFIT BY CUSTOMER.xls";
		public const string REPORT_ON_LOAN_PROFIT_BY_CUSTOMER = "REPORT ON LOAN PROFIT BY CUSTOMER.xls";
		public const string REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE = "REPORT ON TOP 50 CUSTOMERS IN TERMS OF DEPOSIT AVERAGE BALANCE.xls";
		public const string REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE = "REPORT ON TOP 50 CUSTOMERS IN TERMS OF LOAN AVERAGE BALANCE.xls";
		public const string TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT = "TOP 50 CUSTOMERS IN TERMS OF TOTAL PROFIT.xls";
		public const string CUSTOMER_INFORMATION_TEMPLATE = "CUSTOMER INFORMATION.xls";

		#endregion


		#region CUSTOMER ERROR COLUMN NAME
		public const string COL_CUSTOMER_CODE = "Customer Code";
		public const string COL_CUSTOMER_NAME = "Customer Name";
		public const string COL_MONTH_YEAR = "Month/Year";
		public const string COL_ERROR_TYPE = "Error Type";
		public const string COL_ACCOUNT_OFFICER = "Account_Officer";
		public const string COL_IMPORTED_BY = "Imported by";
		public const string COL_COMPLETE = "Finalized";
		#endregion

		public const int DATAGRID_NUM_OF_ROW = 10;
		public const string FONT_EXCEL_REPORT = "Arial";
		public const int TITLE_SIZE = 12;
		public const int HEADER_SIZE = 10;
		public const int CELL_SIZE = 8;



		#region CUSTOMER INFORMATION REPORT
		public const string CUSTOMER_INFORMATION_REPORT_TEXT_STYLE = ":";
		
		public const string REPORT_CUSTOMER_REPORT_NAME = "Report Name";
		public const string REPORT_CUSTOMER_CUSTOMER_INFORMATION = "Customer Information";
		public const string REPORT_CUSTOMER_REPORT_LOCATION = "Report Location";
		public const string REPORT_CUSTOMER_CALLED_FROM = "Called from [Corporate Customer Data] Screen";
		public const string REPORT_CUSTOMER_REPORT_PURPOSE = "Report Purpose";
		public const string REPORT_CUSTOMER_USED_FOR = "Used for exporting [Customer Information]";
		public const string REPORT_CUSTOMER_REPORT_FORMAT = "Report Format";
		public const string REPORT_CUSTOMER_REPORT_TYPE = "Report Type";
		public const string REPORT_CUSTOMER_EXCEL_FILE = "Excel File";
		public const string REPORT_CUSTOMER_PREVIEW_MODE = "Preview mode";
		public const string REPORT_CUSTOMER_NO = "No";
		public const string REPORT_CUSTOMER_SIZE = "Size";
		public const string REPORT_CUSTOMER_N_A = "N/A";
		public const string REPORT_CUSTOMER_ORIENTATION = "Orientation";
		public const string REPORT_CUSTOMER_FLY = "Fly";
		public const string REPORT_CUSTOMER_FONT_TYPE = "Font type";
		public const string REPORT_CUSTOMER_ARIAL = "Arial";
		public const string REPORT_CUSTOMER_FONT_SIZE = "Font size";
		public const string REPORT_CUSTOMER_8_PT = "8 pt";
		public const string REPORT_CUSTOMER_FORMAT_NUMBER = "Format number";
		public const string REPORT_CUSTOMER_FORMAT_NUMBER_STYLE = "###,###,###.##";


					
					
					
					
					
				
				


		#endregion
	}
}