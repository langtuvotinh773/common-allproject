﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: htkhiem $
 * $Date: 2013-01-08 20:37:30 +0700 (Mon, 08 Jan 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to provide function to write history
 * for LG module.
 */
using System;
using System.Collections.Generic;
using System.Xml;
using System.Data.SqlClient;
using Phoenix.Common.MasterData.Com;
using Phoenix.Cpa.Dal;
using Config.Classes;


namespace Phoenix.Cpa.Common
{
    /// <summary>
    /// Summary description for LogBase
    /// </summary>
    public class clsCPALogBase
    {
        #region Global Variables
        //+ User ID
        private string userID = String.Empty;
        //+ Application Name
        private string applicationName = String.Empty;
        //+ Key
        private string key = String.Empty;
        //+ Action
        //-> 1: Insert
        //-> 2: Update
        //-> 3: Delete
        private int action = 0;
        //+ Module
        //-> 1: COM
        //-> 2: MD
        //-> 3: CPA
        //-> 4: ...
        private string module = clsCPAConstant.PROJECT_NAME_CPA;
        //+ List of [Log Information]
        private List<clsCPALogInformation> lstLogInformation = new List<clsCPALogInformation>();
        #endregion

        #region Properties
        //+ User ID
        public string UserID
        {
            get
            {
                return userID;
            }
            set
            {
                userID = value;
            }
        }
        //+ Application Name
        public string ApplicationName
        {
            get
            {
                return applicationName;
            }
            set
            {
                applicationName = value;
            }
        }
        //+ Key
        public string Key
        {
            get
            {
                return key;
            }
            set
            {
                key = value;
            }
        }
        //+ Action
        //-> 1: Insert
        //-> 2: Update
        //-> 3: Delete
        public int Action
        {
            get
            {
                return action;
            }
            set
            {
                action = value;
            }
        }
        //+ Module
        //-> 1: COM
        //-> 2: MD
        //-> 3: CPA
        //-> 4: ...
        public string Module
        {
            get
            {
                return module;
            }
            set
            {
                module = value;
            }
        }
        //+ List of [Log Information]
        public List<clsCPALogInformation> LstLogInformation
        {
            get
            {
                return lstLogInformation;
            }
            set
            {
                lstLogInformation = value;
            }
        }
        #endregion

        #region Member Method
        /// <summary>
        /// Wirte Log
        /// </summary>
        /// <param name="m_DAL"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        public void WirteLog(clsDataAccessLayer objDAL)
        {
            #region Declaration
            string content = String.Empty;
            #endregion

            #region Build Content Structure
            XmlDocument xml = new XmlDocument();
            XmlElement root = xml.CreateElement("LogContent");
            root.SetAttribute("Key", this.Key);
            xml.AppendChild(root);

            foreach (clsCPALogInformation logInfo in this.lstLogInformation)
            {
                //+ Field
                XmlElement child = xml.CreateElement("Field");
                //+ Set Attribute [Name]
                child.SetAttribute("Name", logInfo.FieldName);
                //+ Log For Updating
                if (this.Action == (int)CommonValue.ActionType.Update)
                {
                    //+ Old Value
                    XmlElement oldValueNode = xml.CreateElement("OldValue");
                    oldValueNode.InnerText = logInfo.OldValue;
                    child.AppendChild(oldValueNode);
                    //+ New Value
                    XmlElement newValueNode = xml.CreateElement("NewValue");
                    newValueNode.InnerText = logInfo.NewValue;
                    child.AppendChild(newValueNode);
                }
                //+ Log For Inserting
                else
                {
                    //+ Value
                    XmlElement newValueNode = xml.CreateElement("Value");
                    newValueNode.InnerText = logInfo.NewValue;
                    child.AppendChild(newValueNode);
                }

                //+ Append Child
                root.AppendChild(child);
            }
            content = xml.OuterXml;
            #endregion

            #region Write Log
            SqlParameter[] parameters = new SqlParameter[5];
            parameters[0] = new SqlParameter("@user", this.UserID);
            parameters[1] = new SqlParameter("@appName", this.ApplicationName);
            parameters[2] = new SqlParameter("@content", content);
            parameters[3] = new SqlParameter("@action", this.Action);
            parameters[4] = new SqlParameter("@module", this.Module);

            objDAL.ExecuteNonQueryNonReplyWithTransaction("spCPA_InsertHistory", System.Data.CommandType.StoredProcedure, parameters);
            #endregion
        }
        #endregion
    }

    /// <summary>
    /// Summary description for clsLGLogInformation
    /// </summary>
    public class clsCPALogInformation
    {
        #region Global Variables
        //+ Field Name
        string fieldName = String.Empty;
        //+ Old Value
        string oldValue = String.Empty;
        //+ New Value
        string newValue = String.Empty;
        #endregion

        #region Properties
        //+ Field Name
        public string FieldName
        {
            get
            {
                return fieldName;
            }
            set
            {
                                fieldName = value;
            }
        }
        //+ Old Value
        public string OldValue
        {
            get
            {
                return oldValue;
            }
            set
            {
                oldValue = value;
            }
        }
        //+ New Value
        public string NewValue
        {
            get
            {
                return newValue;
            }
            set
            {
                newValue = value;
            }
        }



        #endregion
    }
}
