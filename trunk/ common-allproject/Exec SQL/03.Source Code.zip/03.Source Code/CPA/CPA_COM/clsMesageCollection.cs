﻿

/*
 * Author:  Phong Nguyen
 * Created: 3-Jan-2013
 * 
 * This class is used to Call Message dialog
 * 
 * 
 */

using System.Collections.Generic;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Popup;

namespace Phoenix.Cpa.Common
{
    public class clsMesageCollection
    {

        /// <summary>
        /// Show message no transaction found
        /// </summary>
        public static void MessageNoTransactions()
        {

            frmPhoenixMessage frm = new frmPhoenixMessage((int)CommonValue.MessageType.Infomaition,
                                                    "No transaction found");
            frm.ShowDialog();
         
        }
        /// <summary>
        /// show missing CPA list
        /// </summary>
        /// <param name="cpas"></param>
        public static void ShowCPANotImportYet(List<string> cpas)
        {
            string msgContent = "";
            for (int i = 0; i < cpas.Count; i++)
            {
                msgContent += clsCommonFunctions.GetMonthYearShowOnDataGrid(cpas[i]);
                if (i < cpas.Count - 1)
                {
                    msgContent += ", ";
                }
            }
            frmPhoenixMessage frm = new frmPhoenixMessage((int)CommonValue.MessageType.Infomaition,
                                                      "CPA on " + msgContent + " have not been imported yet !");
            frm.ShowDialog();
            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="format"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public static DialogResult ShowMessage(int type,string format,string[] param)
        {
            frmPhoenixMessage frmMsg = new frmPhoenixMessage(type,
                                                          format, param);
          return  frmMsg.ShowDialog();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        internal static DialogResult ShowMessage(int type, string msg)
        {
            frmPhoenixMessage frmMsg = new frmPhoenixMessage(type,
                                                          msg);
            return frmMsg.ShowDialog();
        }
    }
}
