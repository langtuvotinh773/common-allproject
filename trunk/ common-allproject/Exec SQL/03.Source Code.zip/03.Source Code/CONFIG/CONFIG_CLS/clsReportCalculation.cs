﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Config.Classes
{
    public static class clsReportCalculation
    {
        /// <summary>
        /// report 6
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static Int64 GetCommissionFee(DataRow row)
        {
            return (Int64)row["Guarantee_INC"] + (Int64)row["CleanLC_INC"] + (Int64)row["Acceptance_INC"] + (Int64)row["Commitment_INC"]
                    + (Int64)row["Others_INC"] + (Int64)row["DocLC_INC"] + (Int64)row["ExpBillHandling_INC"] + (Int64)row["ImpBillHandling_INC"] + (Int64)row["Collecting_INC"] 
                    + (Int64)row["Payment_INC"] + (Int64)row["Remittance_INC"] 
                    + (Int64)row["Loan_INC"] + (Int64)row["Others01_INC"] + (Int64)row["Others02_INC"];

        }
        /// <summary>
        /// report 9
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static Int64 GetProfitDeposit(DataRow row)
        {
            return ((Int64)row["(Dep_Liquid_REC"] - (Int64)row["Dep_Liquid_PAY)"] + ((Int64)row["(Dep_Fixed_REC"]) - (Int64)row["Dep_Fixed_PAY)"]);
        }

        /// <summary>
        /// report 10
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static Int64 GetProfitOfLoan(DataRow row)
        {
            return ((Int64)row["STL_Overdraft_REC"] - (Int64)row["STL_Overdraft_PAY"]) +
            ((Int64)row["STL_CommercialBill_REC"] - (Int64)row["STL_CommercialBill_PAY"]) +
            ((Int64)row["STL_Loan_REC"] - (Int64)row["STL_Loan_PAY"]) +
            ((Int64)row["LTL_Fixed_REC"] - (Int64)row["LTL_Fixed_PAY"]) +
            ((Int64)row["LTL_Floating_REC"] - (Int64)row["LTL_Floating_PAY"]);
        }
        /// <summary>
        /// report 7
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static Int64 GetProfitOfDeposit(DataRow row)
        {
            return (Int64)row["ForeignExchangePL_INC"];
        }

        /// <summary>
        /// repost 8 = 6+7+9+10
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static Int64 GetTotalProfit(DataRow row)
        {
            return GetCommissionFee(row) + GetProfitDeposit(row) + GetProfitOfLoan(row) + GetProfitOfDeposit(row);
        }
    }
}
