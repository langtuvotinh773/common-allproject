﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-01-09 20:37:30 +0700 (Mon, 09 Jan 2013) $
 * $Revision: 4177 $ 
 * ========================================================
 * This class is used to monitor thread of some screen
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.ComponentModel;
namespace Config.Classes
{
	/// <summary>
	/// Run task in background
	/// </summary>
	public class CWorker
	{
		public delegate void Run();
		public delegate void Completed();

		protected BackgroundWorker _bw;
        public BackgroundWorker Worker
        {
            get { return _bw; }
            set { _bw = value;}
        }
		public Run _run;
		public Completed _completed;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="runfunction"></param>
		/// <param name="completedFuntion"></param>
		public CWorker(Run runfunction, Completed completedFuntion)
		{
			_run = runfunction;
			_completed = completedFuntion;
			_bw = new BackgroundWorker();
			_bw.DoWork += new DoWorkEventHandler(Bw_DoWork);
			_bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(Bw_DoCompleted);
			_bw.WorkerSupportsCancellation = true;
		}

		/// <summary>
		/// Start a worker
		/// </summary>
		public void Start()
		{
			_bw.RunWorkerAsync();
		}

		/// <summary>
		/// Worker do work
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void Bw_DoWork(object sender, DoWorkEventArgs e)
		{
			if (_run != null)
				_run();
		}

		/// <summary>
		/// Worker Complete
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void Bw_DoCompleted(Object sender, RunWorkerCompletedEventArgs e)
		{
			if (_completed != null)
				_completed();
		}

		/// <summary>
		/// Stop a thread
		/// </summary>
		public void Stop()
		{
			_bw.CancelAsync();
		}

		/// <summary>
		/// Check a thread is busy
		/// </summary>
		public bool IsBusy
		{
			get
			{
				return _bw.IsBusy;
			}
		}
	}
}