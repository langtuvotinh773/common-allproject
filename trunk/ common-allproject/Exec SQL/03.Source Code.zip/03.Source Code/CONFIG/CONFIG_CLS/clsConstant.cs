﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-01-03 20:37:30 +0700 (Mon, 03 Jan 2013) $
 * $Revision: 3614 $ 
 * ========================================================
 * This class is used to provide common string
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Config.Classes
{
	/// <summary> Define constant number in project
	/// 
	/// </summary>
	public class clsConstant
	{
		public const int DATAGRID_NUM_OF_ROW = 10;
		public const string FONT_EXCEL_REPORT = "Arial";
		public const int TITLE_SIZE = 12;
		public const int HEADER_SIZE = 10;
		public const int CELL_SIZE = 8;
		public static int DEFAULT_COLOR_CELL_EXCEL = System.Drawing.ColorTranslator.FromHtml("#C0C0C0").ToArgb();
		public static System.Drawing.Color WAITING_FOR_CLOSING = System.Drawing.ColorTranslator.FromHtml("#808000");	
       

	}
}