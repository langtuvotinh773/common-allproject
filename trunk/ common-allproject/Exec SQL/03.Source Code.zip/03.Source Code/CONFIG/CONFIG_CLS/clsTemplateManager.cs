﻿/**
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;

namespace Config.Classes
{
    /// <summary>
    /// This class use to create and copy templates report
    /// </summary>
    public class clsTemplateManager
    {
        public clsTemplateManager()
        {
        }

        private static clsTemplateManager manager;
        public static clsTemplateManager Instance()
        {
            if (manager == null) manager = new clsTemplateManager();
            return manager;
        }
        public string FilePath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Template");
        public void CreateDirectory()
        {
            String appData = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Template");
            FilePath = appData;
            try
            {
                System.IO.Directory.Delete(appData, true);
            }
            catch (Exception ex)
            {
            }
            System.IO.Directory.CreateDirectory(appData);


        }
        /// <summary>
        /// Create template before expoer report
        /// </summary>
        /// <param name="path"></param>
        /// <param name="name"></param>
        public void CreateFile(string path, string name, string serverDate)
        {
            String appData = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Template");
            FilePath = appData;
            try
            {
                System.IO.Directory.Delete(appData, true);
            }
            catch (Exception ex)
            {
            }
            try
            {
                System.IO.Directory.CreateDirectory(appData);
            }
            catch (Exception ex)
            {
            }

            string strFilePath = path;
            string fileName = name;



            string newFileName = fileName.Remove(fileName.Length - 4, 4) + "_" + serverDate + "_" + ".xls";
            try
            {                
                if (File.Exists(appData + "\\" + newFileName))
                {
                    File.Delete(appData + "\\" + newFileName);
                }
                System.IO.File.Copy(strFilePath + "\\" + fileName, appData + "\\" + newFileName);
            }
            catch (Exception ex)
            {
            }
        }

        //2013.05.15 ADD vlhcnhung S [Function to Create file excel temporary with new file name is not same template's name]
        /// <summary>
        /// Create template before expoer report
        /// </summary>
        /// <param name="strPath"></param>
        /// <param name="strNameTemplate">Name of excel template</param>
        /// <param name="strNewNameFile">New Name for excel. New Name does not contain server date</param>
        /// <param name="strServerDate"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public void CreateFile(string strPath, string strNameTemplate, string strNewFileName, string strServerDate)
        {
            String appData = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Template");
            FilePath = appData;
            try
            {
                System.IO.Directory.Delete(appData, true);
            }
            catch (Exception ex)
            {
            }
            try
            {
                System.IO.Directory.CreateDirectory(appData);
            }
            catch (Exception ex)
            {
            }

            string strFilePath = strPath;
            string fileName = strNameTemplate;

            string newFileName = strNewFileName + "_" + strServerDate + "_" + ".xls";
            try
            {
                if (File.Exists(appData + "\\" + newFileName))
                {
                    File.Delete(appData + "\\" + newFileName);
                }
                System.IO.File.Copy(strFilePath + "\\" + fileName, appData + "\\" + newFileName);
            }
            catch (Exception ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
        }
        //2013.05.15 ADD vlhcnhung E [Function to Create file excel temporary with new file name is not same template's name]

    }
}
