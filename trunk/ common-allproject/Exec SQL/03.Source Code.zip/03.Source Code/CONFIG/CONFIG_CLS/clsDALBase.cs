﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Config.Classes
{
    public class clsDALBase
    {
        private SqlConnection m_Connection;
        private SqlCommand m_Command;
        private SqlDataAdapter m_Adapter;
        private string m_ConnStr;

        /// <summary>
        /// Initializes a new instance of the <see cref="CPADataAccessLayer" /> class.
        /// </summary>
        public clsDALBase()
        {
            m_ConnStr = clsFunction.GetDBConnectionStr();
            this.m_Connection = new SqlConnection(m_ConnStr);
            this.m_Command = new SqlCommand();
            this.m_Adapter = new SqlDataAdapter();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CPADataAccessLayer" /> class.
        /// </summary>
        public clsDALBase(string connString)
        {
            this.m_Connection = new SqlConnection(connString);
            this.m_Command = new SqlCommand();
            this.m_Adapter = new SqlDataAdapter();
        }

        /// <summary>
        /// Fills the specified table.
        /// </summary>
        /// <param name="table">The table.</param>
        public void FillDataTable(SqlCommand cmd, DataTable table)
        {
            try
            {
                if (m_Adapter != null)
                {
                    m_Adapter.SelectCommand = cmd;
                    m_Adapter.Fill(table);
                }
            }
            catch (SqlException ex)
            {
                //string error = ex.Message;
                //clsFunction.ShowErrorDialog(error);
                //clsLogFile.LogException(error);
            }
        }

        /// <summary>
        /// Fills the specified dataset.
        /// </summary>
        /// <param name="dataset">The dataset.</param>
        public void FillDataSet(SqlCommand cmd, DataSet ds)
        {
            if (m_Adapter != null)
            {
                m_Adapter.SelectCommand = cmd;
                m_Adapter.Fill(ds);
            }
            //try
            //{
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
        }

        /// <summary>
        /// Fills the specified table.
        /// </summary>
        /// <param name="table">The table.</param>
        public void Fill(DataTable table)
        {
            try
            {
                if (m_Adapter != null)
                {
                    this.m_Adapter.Fill(table);
                }
            }
            catch (SqlException ex)
            {
                //string error = ex.Message;
                //clsFunction.ShowErrorDialog(error);
                //clsLogFile.LogException(error);
            }
        }

        /// <summary>
        /// Fills the specified dataset.
        /// </summary>
        /// <param name="dataset">The dataset.</param>
        public void Fill(DataSet dataset)
        {
            try
            {
                if (m_Adapter != null)
                {
                    this.m_Adapter.Fill(dataset);
                }
            }
            catch (SqlException ex)
            {
                //string error = ex.Message;
                //clsFunction.ShowErrorDialog(error);
                //clsLogFile.LogException(error);
            }
        }

        /// <summary>
        /// Sets the command.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        public void SetCommand(string query, CommandType commandType)
        {
            this.m_Command.Parameters.Clear();
            this.m_Command.Connection = this.m_Connection;
            this.m_Command.CommandType = commandType;
            this.m_Command.CommandText = query;

            this.m_Adapter.SelectCommand = this.m_Command;
        }

        /// <summary>
        /// Adds the parameter.
        /// </summary>
        /// <param name="paramter">The paramter.</param>
        public void AddParameter(SqlParameter paramter)
        {
            this.m_Command.Parameters.Add(paramter);
        }

        /// <summary>
        /// Adds the parameter.
        /// </summary>
        /// <param name="paramatername">The paramater name.</param>
        /// <param name="parametervalue">The parameter value.</param>
        public void AddParameter(string paramatername, object parametervalue)
        {
            this.m_Command.Parameters.AddWithValue(paramatername, parametervalue);
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <returns></returns>
        public int ExecuteNonQuery()
        {
            //int row = 0;
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();

            int row = this.m_Command.ExecuteNonQuery();

            if (this.m_Connection.State == ConnectionState.Open)
                this.m_Connection.Close();
            return row;
            
            //try
            //{
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
            //return 0;
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <returns></returns>
        public int ExecuteNonQuery(string query, CommandType commandType)
        {
            SetCommand(query, commandType);
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();

            int row = this.m_Command.ExecuteNonQuery();

            if (this.m_Connection.State == ConnectionState.Open)
                this.m_Connection.Close();

            //try
            //{
                
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}

            return row;
        }

        public int ExecuteNonQuery(string query, CommandType commandType, SqlParameter parameter)
        {
            SetCommand(query, commandType);
            AddParameter(parameter);
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();

            int row = this.m_Command.ExecuteNonQuery();

            if (this.m_Connection.State == ConnectionState.Open)
                this.m_Connection.Close();

            return row;

            //try
            //{
                
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
            //return 0;
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public int ExecuteNonQuery(string query, CommandType commandType, SqlParameter[] parameters)
        {
            SetCommand(query, commandType);
            foreach (SqlParameter param in parameters)
            {
                AddParameter(param);
            }
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();

            int row = this.m_Command.ExecuteNonQuery();
            //int row = Convert.ToInt32(m_Command.Parameters["@Count"].Value);

            if (this.m_Connection.State == ConnectionState.Open)
                this.m_Connection.Close();

            return row;

            //try
            //{
                
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
            //return 0;
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="outputParamName">Name of the output param.</param>
        /// <returns>The affected row that stored procedure returns</returns>
        public int ExecuteNonQuery(string query, CommandType commandType, SqlParameter[] parameters, object outputParamName)
        {
            SetCommand(query, commandType);
            foreach (SqlParameter param in parameters)
            {
                AddParameter(param);
            }
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();

            this.m_Command.ExecuteNonQuery();
            int row = Convert.ToInt32(m_Command.Parameters[outputParamName.ToString()].Value);

            if (this.m_Connection.State == ConnectionState.Open)
                this.m_Connection.Close();

            return row;

            //try
            //{
                
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
            //return 0;
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="outParamName">Name of the out param.</param>
        /// <returns></returns>
        public string ExecuteNonQuery(string query, CommandType commandType, SqlParameter[] parameters , string outParamName)
        {
            string result = "";

            SetCommand(query, commandType);
            foreach (SqlParameter param in parameters)
            {
                AddParameter(param);
            }
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();

            this.m_Command.ExecuteNonQuery();

            result = m_Command.Parameters[outParamName].Value.ToString();

            if (this.m_Connection.State == ConnectionState.Open)
                this.m_Connection.Close();

            return result;

            //try
            //{
                
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
            //return result;
        }

        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <returns></returns>
        public DataTable ExecuteDataReader(string query, CommandType commandType)
        {
            DataTable table = new DataTable();
            if (m_Adapter != null)
            {
                SetCommand(query, commandType);
                this.m_Adapter.SelectCommand = m_Command;
                this.m_Adapter.Fill(table);
            }
            else
            {
                this.m_Adapter = new SqlDataAdapter();
                this.m_Adapter.SelectCommand = m_Command;
                this.m_Adapter.Fill(table);
            }
            m_Adapter.Dispose();
            //try
            //{
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
            return table;
        }

        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public DataTable ExecuteDataReader(string query, CommandType commandType, SqlParameter parameter)
        {
            DataTable table = new DataTable();
            SetCommand(query, commandType);
            m_Command.Parameters.Add(parameter);
            if (m_Adapter != null)
            {
                this.m_Adapter.SelectCommand = m_Command;
                this.m_Adapter.Fill(table);
            }
            else
            {
                this.m_Adapter = new SqlDataAdapter();
                this.m_Adapter.SelectCommand = m_Command;
                this.m_Adapter.Fill(table);
            }
            m_Adapter.Dispose();
            //try
            //{
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
            return table;
        }

        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public DataTable ExecuteDataReader(string query, CommandType commandType, SqlParameter[] parameters)
        {
            DataTable table = new DataTable();
            SetCommand(query, commandType);
            foreach (SqlParameter param in parameters)
            {
                m_Command.Parameters.Add(param);
            }
            if (m_Adapter != null)
            {
                this.m_Adapter.SelectCommand = m_Command;
                this.m_Adapter.Fill(table);
            }
            else
            {
                this.m_Adapter = new SqlDataAdapter();
                this.m_Adapter.SelectCommand = m_Command;
                this.m_Adapter.Fill(table);
            }
            m_Adapter.Dispose();
            
            //try
            //{
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
            return table;
        }

        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <returns></returns>
        public SqlDataReader ExecuteDataReader()
        {
            //SqlDataReader reader = null;
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();

            SqlDataReader reader = this.m_Command.ExecuteReader(CommandBehavior.CloseConnection);

            //try
            //{
            //    //if (this.m_Connection.State == ConnectionState.Open)
            //    //    this.m_Connection.Close();
            //}
            //catch (SqlException ex)
            //{
            //    //string error = ex.Message;
            //    //clsFunction.ShowErrorDialog(error);
            //    //clsLogFile.LogException(error);
            //}
            return reader;
        }

        /// <summary>
        /// Executes the transaction.
        /// </summary>
        /// <returns></returns>
        public int ExecuteTransaction(ArrayList arrSQL)
        {
            int row = 0;
            //SqlConnection connect = new SqlConnection(CONNECTION_STRING);
            //connect.Open();
            if (this.m_Connection.State == ConnectionState.Closed)
                this.m_Connection.Open();
            SqlTransaction transaction = this.m_Connection.BeginTransaction();
            try
            {
              
                for (int i = 0; i < arrSQL.Count; i++)
                {
                    
                    SetCommand(arrSQL[i].ToString(), CommandType.Text);
                    this.m_Command.Transaction = transaction;
                    this.m_Command.ExecuteNonQuery();
                    //SqlCommand command = new SqlCommand(arrSQL[i].ToString(), connect);
                    //command.Transaction = transaction;                    
                    //command.ExecuteNonQuery();
                }
                transaction.Commit();
                row = 1;
                //connect.Close();   
                if (this.m_Connection.State == ConnectionState.Open)
                    this.m_Connection.Close();
            }
            catch (SqlException ex)
            {
                transaction.Rollback();
                //string error = ex.Message;
                //clsFunction.ShowErrorDialog(error);
                //clsLogFile.LogException(error);
            }

            return row;
        }
    }
}