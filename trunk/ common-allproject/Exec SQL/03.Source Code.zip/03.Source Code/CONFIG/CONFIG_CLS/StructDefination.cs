﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Config.Classes
{

    /// <summary>
    /// Use for make histoyry object which need to insert into tbl_CPAHistory table
    /// </summary>
    public struct History
    {
        public string UserName; //name of user
        public string ApplicationName; // 
        public string PrimaryKey;
        List<DetailHistory> ListDetails;
        public int Action; // 
        public void AddDetail(DetailHistory input)
        {
            if( ListDetails == null) ListDetails = new List<DetailHistory>();
            ListDetails.Add(input);
        }
        public string ToString()
        {
            string result = "";
            if (ListDetails == null)
            {
                return result;
            }
            for (int i = 0; i < ListDetails.Count; i++)
            {
                result += ListDetails[i].ToString();
                if(i != ListDetails.Count - 1) result += "\n";
            }
            return result;
        }



    }
    public struct DetailHistory
    {
        public string FieldName;
        public string OldValue;
        public string NewValue;
        public string ToString()
        {
            return FieldName + " " + "Old: " + OldValue + ", New: " + NewValue;
        }
    }

    
}
