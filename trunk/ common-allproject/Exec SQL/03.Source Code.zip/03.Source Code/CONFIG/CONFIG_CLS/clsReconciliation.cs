﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace Config.Classes
{
    public class clsReconciliation
    {
        private string m_ExcelFileName = null;
        private DataTable m_SaveTable = null;
        private DataTable m_PhoenixTable = null;
        private DataTable m_SmileTable = null;

        public clsReconciliation()
        {
            m_PhoenixTable = new DataTable();
            m_SmileTable = new DataTable();
            string[] ColNames = new string[] { 
                "CCY", "GLCode", "TDNo", "CIFCode", "TotalAmt", "ValueDate",
                "MaturityDate", "IR", "IS", "DebitProceedAC", "MaturityAC", 
                "InterestAC", "CollateralTD"
            };
            foreach (string colName in ColNames)
            {
                m_PhoenixTable.Columns.Add(colName, typeof(System.String));
                m_SmileTable.Columns.Add(colName, typeof(System.String));
            }
        }

        public clsReconciliation(string excelFileName)
        {
            m_ExcelFileName = excelFileName;
            m_SaveTable = new DataTable();

            //m_SaveTable.Columns.Add("No", typeof(System.String));
            m_SaveTable.Columns.Add("PTDNo", typeof(System.String));
            m_SaveTable.Columns.Add("PCIFCode", typeof(System.String));
            m_SaveTable.Columns.Add("PGLCode", typeof(System.String));
            m_SaveTable.Columns.Add("PCCY", typeof(System.String));
            m_SaveTable.Columns.Add("PValueDate", typeof(System.String));
            m_SaveTable.Columns.Add("PMaturityDate", typeof(System.String));
            m_SaveTable.Columns.Add("PTotalAmt", typeof(System.String));
            m_SaveTable.Columns.Add("PIR", typeof(System.String));
            m_SaveTable.Columns.Add("PIS", typeof(System.String));
            m_SaveTable.Columns.Add("PDebitProceedAC", typeof(System.String));
            m_SaveTable.Columns.Add("PMaturityAC", typeof(System.String));
            m_SaveTable.Columns.Add("PInterestAC", typeof(System.String));
            m_SaveTable.Columns.Add("PCollateralTD", typeof(System.String));
            m_SaveTable.Columns.Add("STDNo", typeof(System.String));
            m_SaveTable.Columns.Add("SCIFCode", typeof(System.String));
            m_SaveTable.Columns.Add("SGLCode", typeof(System.String));
            m_SaveTable.Columns.Add("SCCY", typeof(System.String));
            m_SaveTable.Columns.Add("SValueDate", typeof(System.String));
            m_SaveTable.Columns.Add("SMaturityDate", typeof(System.String));
            m_SaveTable.Columns.Add("STotalAmt", typeof(System.String));
            m_SaveTable.Columns.Add("SIR", typeof(System.String));
            m_SaveTable.Columns.Add("SIS", typeof(System.String));
            m_SaveTable.Columns.Add("SDebitProceedAC", typeof(System.String));
            m_SaveTable.Columns.Add("SMaturityAC", typeof(System.String));
            m_SaveTable.Columns.Add("SInterestAC", typeof(System.String));
            m_SaveTable.Columns.Add("SCollateralTD", typeof(System.String));
            m_SaveTable.Columns.Add("Key", typeof(System.String));
        }

        public DataTable ReadExcelFile(string sheetName, string[] columnsToReads, string[] aliases)
        {
            string connStr = String.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=Yes';", m_ExcelFileName);
      //      string connStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + m_ExcelFileName + ";Extended Properties='Excel 8.0;HDR=YES'";
            if (columnsToReads.Length != aliases.Length) return null;
            DataTable dtData = new DataTable();
            dtData.Columns.Add("TDNo", typeof(System.String));
            dtData.Columns.Add("CIFCode", typeof(System.String));
            dtData.Columns.Add("GLCode", typeof(System.String));
            dtData.Columns.Add("CCY", typeof(System.String));
            dtData.Columns.Add("ValueDate", typeof(System.String));
            dtData.Columns.Add("MaturityDate", typeof(System.String));
            dtData.Columns.Add("TotalAmt", typeof(System.String));
            dtData.Columns.Add("IR", typeof(System.String));
            dtData.Columns.Add("IS", typeof(System.String));
            dtData.Columns.Add("DebitProceedAC", typeof(System.String));
            dtData.Columns.Add("MaturityAC", typeof(System.String));
            dtData.Columns.Add("InterestAC", typeof(System.String));
            dtData.Columns.Add("CollateralTD", typeof(System.String));
            using (OleDbConnection dbCon = new OleDbConnection(connStr))
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < columnsToReads.Length; i++)
                {
                    sb.Append(columnsToReads[i] + " AS " + aliases[i] + ", ");
                }
                string cmd = String.Format("SELECT " + sb.Remove(sb.ToString().LastIndexOf(','), 1).ToString() + "FROM [{0}$]", sheetName);
                OleDbCommand dbCmd = new OleDbCommand(cmd, dbCon);
                dbCon.Open();
                OleDbDataReader reader = dbCmd.ExecuteReader();
                while (reader.Read())
                {
                    string[] values = new string[]{
                         reader.GetDouble(1).ToString(), 
                        reader.GetString(3), reader.GetDouble(4).ToString(), reader.GetDouble(5).ToString(), 
                        reader.GetDouble(6).ToString(), reader.GetDouble(7).ToString(), reader.GetDouble(8).ToString()
                        //reader.GetDouble(9).ToString(), reader.GetDouble(10).ToString(), reader.GetDouble(11).ToString(), reader.GetString(12)
                    };
                    dtData.Rows.Add(values);
                }
                reader.Close();
                //using (OleDbDataAdapter da = new OleDbDataAdapter(cmd, dbCon))
                //{
                //    da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                //    da.Fill(dtData);
                //}
            }
            // Try to set primary key for table from Excel file
            //try
            //{
            //    dtData.PrimaryKey = new DataColumn[] { dtData.Columns["TDNo"] };
            //}
            //catch (DataException)
            //{
            //    clsFunction.ShowWarningDialog("An error occured while set primary key");
            //}

            return dtData;
        }

        public DataTable MergeExcelTables(DataTable table1, DataTable table2)
        {
            return null;
        }

        public DataTable GetTableDetail()
        {
            return m_SaveTable;
        }

        public DateTime GetFDOUTPTime()
        {
            DateTime dt = new DateTime();
            try
            {
                dt = File.GetCreationTime(m_ExcelFileName);
            }
            catch (Exception)
            {
            }
            return dt;
        }

        public bool CheckDataIsValidOrNot(DataTable smile)
        {
            return true;
        }

        public void ReconcileData(DataGridView dtgPhoenix, DataTable phoenix, DataGridView dtgSmile, DataTable smile, ref int match, ref int mismatch)
        {
            int j = 0;
            int original = 0;

            m_PhoenixTable = phoenix.Clone();
            m_SmileTable = smile.Clone();

            dtgPhoenix.Rows.Clear();
            dtgSmile.Rows.Clear();

            #region Check first loop
            // Loop through phoenix table
            for (int i = 0; i < phoenix.Rows.Count; i++)
            {
                // Indicate whether or not add a new row to DataGrid
                original = smile.Rows.Count;
                j = 0;
                // For one record, compare with each record in smile table
                #region Check second loop
                while (j < smile.Rows.Count)
                {
                    if ((smile.Rows.Count > 0 && phoenix.Rows.Count > 0) && phoenix.Rows[i].ItemArray.SequenceEqual(smile.Rows[j].ItemArray))
                    {
                        // Records is match, remove them from both datatables
                        phoenix.Rows.RemoveAt(i);
                        smile.Rows.RemoveAt(j);
                        ++match;
                    }
                    else
                    {
                        if (smile.Rows.Count == 0 || phoenix.Rows.Count == 0)
                        {
                            ++j;
                            continue;
                        }
                        if (phoenix.Rows[i]["TDNo"].Equals(smile.Rows[j]["TDNo"]))
                        {
                            // Records is NOT match, add them to gridviews
                            dtgPhoenix.Rows.Add(new DataGridViewRow());
                            dtgSmile.Rows.Add(new DataGridViewRow());

                            List<string> prow = new List<string>();
                            List<string> srow = new List<string>();

                            for (int k = 0; k < phoenix.Columns.Count; k++)
                            {
                                if (phoenix.Rows[i][k].ToString().Equals(smile.Rows[j][k].ToString()))
                                {
                                    dtgPhoenix.Rows[dtgPhoenix.Rows.Count - 1].Cells[k].Value = phoenix.Rows[i][k];
                                    dtgSmile.Rows[dtgSmile.Rows.Count - 1].Cells[k].Value = smile.Rows[j][k];

                                    prow.Add(phoenix.Rows[i][k].ToString());
                                    srow.Add(String.Empty);
                                }
                                else
                                {
                                    dtgPhoenix.Rows[dtgPhoenix.Rows.Count - 1].Cells[k].Value = phoenix.Rows[i][k];
                                    dtgSmile.Rows[dtgSmile.Rows.Count - 1].Cells[k].Value = smile.Rows[j][k];
                                    dtgPhoenix.Rows[dtgSmile.Rows.Count - 1].Cells[k].Style.BackColor = Color.Red;
                                    dtgSmile.Rows[dtgSmile.Rows.Count - 1].Cells[k].Style.BackColor = Color.Red;

                                    prow.Add(phoenix.Rows[i][k].ToString());
                                    srow.Add(smile.Rows[j][k].ToString());
                                }
                            }
                            // Insert values into save table
                            DataRow row = m_SaveTable.NewRow();
                            prow.AddRange(srow);
                            row.ItemArray = prow.ToArray();
                            m_SaveTable.Rows.Add(row);

                            // After that, remove checked record in Smile table
                            smile.Rows.RemoveAt(j);
                        }
                        else
                            ++j;
                    }
                }
                #endregion 

                if (original == smile.Rows.Count)
                {
                    // Add record to phoenix gridview
                    dtgPhoenix.Rows.Add(phoenix.Rows[i].ItemArray);
                    DataGridViewRow emptyRow = new DataGridViewRow();
                    emptyRow.DefaultCellStyle.BackColor = Color.LightGray;
                    dtgSmile.Rows.Add(emptyRow);

                    List<object> list = new List<object>();
                    list.AddRange(phoenix.Rows[i].ItemArray.ToArray());
                    list.AddRange(new string[]{ "", "", "", "", "", "", "", "", "", "", "", "", "", "S" });
                    m_SaveTable.Rows.Add(list.ToArray());
                }
            }
            #endregion

            // Add remaining rows in smile table
            for (int i = 0; i < smile.Rows.Count; i++)
            {
                // Add record to smile gridview
                dtgSmile.Rows.Add(smile.Rows[i].ItemArray);
                DataGridViewRow emptyRow = new DataGridViewRow();
                emptyRow.DefaultCellStyle.BackColor = Color.LightGray;
                dtgPhoenix.Rows.Add(emptyRow);

                List<object> list = new List<object>();
                list.AddRange(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "" });
                list.AddRange(smile.Rows[i].ItemArray.ToArray());
                list.Add("P");
                m_SaveTable.Rows.Add(list.ToArray());
            }

            mismatch = m_SaveTable.Rows.Count;
        }

        public bool CheckValueEachColumn(DataTable table, DataRow prow, DataRow srow, string pCol, string sCol, string gvCol, int rowIndex)
        {
            prow[gvCol] = table.Rows[rowIndex][pCol];
            if (table.Rows[rowIndex][sCol].Equals(String.Empty) || table.Rows[rowIndex][sCol] is DBNull)
            {
                srow[gvCol] = prow[gvCol];
                return false;
            }
            else
            {
                srow[gvCol] = table.Rows[rowIndex][sCol];
                return true;
            }
        }

        public void FilterData(DataGridView dtgPhoenix, DataGridView dtgSmile, DataTable detail, string filter)
        {
            DataTable filteredTable = new DataTable();
            DataRow[] rows = detail.Select(filter);
            if (rows.Length > 0) filteredTable = rows.CopyToDataTable();
            
            dtgPhoenix.Rows.Clear();
            dtgSmile.Rows.Clear();

            for (int i = 0; i < filteredTable.Rows.Count; i++)
            {
                if (filteredTable.Rows[i]["Key"].Equals(String.Empty) || filteredTable.Rows[i]["Key"] is DBNull)
                {
                    DataRow prow = m_PhoenixTable.NewRow();
                    DataRow srow = m_SmileTable.NewRow();

                    bool FillTDNoColor = CheckValueEachColumn(filteredTable, prow, srow, "PTDNo", "STDNo", "TDNo", i);
                    bool FillCIFColor = CheckValueEachColumn(filteredTable, prow, srow, "PCIFCode", "SCIFCode", "CIFCode", i);
                    bool FillGLColor = CheckValueEachColumn(filteredTable, prow, srow, "PGLCode", "SGLCode", "GLCode", i);
                    bool FillCCYColor = CheckValueEachColumn(filteredTable, prow, srow, "PCCY", "SCCY", "CCY", i);
                    bool FillVDColor = CheckValueEachColumn(filteredTable, prow, srow, "PValueDate", "SValueDate", "ValueDate", i);
                    bool FillMDColor = CheckValueEachColumn(filteredTable, prow, srow, "PMaturityDate", "SMaturityDate", "MaturityDate", i);
                    bool FillTAColor = CheckValueEachColumn(filteredTable, prow, srow, "PTotalAmt", "STotalAmt", "TotalAmt", i);
                    bool FillIRColor = CheckValueEachColumn(filteredTable, prow, srow, "PIR", "SIR", "IR", i);
                    bool FillISColor = CheckValueEachColumn(filteredTable, prow, srow, "PIS", "SIS", "IS", i);
                    bool FillDPACColor = CheckValueEachColumn(filteredTable, prow, srow, "PDebitProceedAC", "SDebitProceedAC", "DebitProceedAC", i);
                    bool FillMACColor = CheckValueEachColumn(filteredTable, prow, srow, "PMaturityAC", "SMaturityAC", "MaturityAC", i);
                    bool FillIACColor = CheckValueEachColumn(filteredTable, prow, srow, "PInterestAC", "SInterestAC", "InterestAC", i);
                    bool FillCTDColor = CheckValueEachColumn(filteredTable, prow, srow, "PCollateralTD", "SCollateralTD", "CollateralTD", i);

                    dtgPhoenix.Rows.Add(prow.ItemArray);
                    dtgSmile.Rows.Add(srow.ItemArray);

                    if (FillTDNoColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PTDNoColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["STDNoColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillCIFColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PCIFCodeColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SCIFCodeColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillGLColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PGLCodeColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SGLCodeColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillCCYColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PCCYColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SCCYColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillVDColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PValueDateColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SValueDateColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillMDColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PMaturityDateColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SMaturityDateColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillTAColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PTotalAmtColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["STotalAmtColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillIRColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PIRColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SIRColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillISColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PISColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SISColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillDPACColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PDebitProceedACColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SDebitProceedACColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillMACColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PMaturityACColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SMaturityACColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillIACColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PInterestACColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SInterestACColumn"].Style.BackColor = Color.Red;
                    }
                    if (FillCTDColor)
                    {
                        dtgPhoenix.Rows[i].Cells["PCollateralTDColumn"].Style.BackColor = Color.Red;
                        dtgSmile.Rows[i].Cells["SCollateralTDColumn"].Style.BackColor = Color.Red;
                    }
                }
                else if (filteredTable.Rows[i]["Key"].Equals("P"))
                {
                    DataRow prow = m_PhoenixTable.NewRow();
                    DataRow srow = m_SmileTable.NewRow();
                    List<object> list = new List<object>();
                    for (int j = 0; j < filteredTable.Columns.Count - 1; j++)
                    {
                        list.Add(filteredTable.Rows[i][j]);
                    }
                    for (int k = 0; k < 13; k++)
                    {
                        prow[k] = list[k];
                    }
                    for (int l = 0; l < 13; l++)
                    {
                        srow[l] = list[l + 13];
                    }
                    dtgPhoenix.Rows.Add(prow.ItemArray);
                    dtgSmile.Rows.Add(srow.ItemArray);
                    dtgPhoenix.Rows[dtgPhoenix.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightGray;
                }
                else
                {
                    DataRow prow = m_PhoenixTable.NewRow();
                    DataRow srow = m_SmileTable.NewRow();
                    List<object> list = new List<object>();
                    for (int j = 0; j < filteredTable.Columns.Count - 2; j++)
                    {
                        list.Add(filteredTable.Rows[i][j]);
                    }
                    for (int k = 0; k < (list.Count - 1) / 2; k++)
                    {
                        prow[k] = list[k];
                    }
                    for (int k = 0; k < 13; k++)
                    {
                        srow[k] = list[k + 12];
                    }
                    dtgPhoenix.Rows.Add(prow.ItemArray);
                    dtgSmile.Rows.Add(srow.ItemArray);
                    dtgSmile.Rows[dtgSmile.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightGray;
                }
            }
        }
    }
}