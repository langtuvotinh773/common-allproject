﻿/*
 * Author:  Quan Nguyen
 * Created: 2-Jan-2013
 * 
 * This class is used to provide common functions
 * for CPA module.
 */

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Globalization;
using System.Collections;
namespace Config.Classes
{
    /// <summary>
    /// This class hold all common funtions
    /// </summary>
	public class clsCommonFunctions
	{
		#region TextBox Validation

		/// <summary>
		/// Sets the text length of text box.
		/// </summary>
		/// <param name="tb">The tb.</param>
		/// <param name="len">The len.</param>
		public static void SetTextLengthOfTextBox(TextBox tb, int len)
		{
			tb.MaxLength = len;
		}

		/// <summary>
		/// Sets the text length of text box.
		/// </summary>
		/// <param name="parent">The parent.</param>
		/// <param name="len">The len.</param>
		public static void SetTextLengthOfTextBox(Form parent, int len)
		{
			foreach (TextBox ctrl in parent.Controls)
			{
				ctrl.MaxLength = len;
			}
		}

		/// <summary>
		/// Disables the past to text box.
		/// </summary>
		public static void DisablePastToTextBox()
		{
			Clipboard.Clear();
		}

		/// <summary>
		/// Validates the numbers on text box.
		/// </summary>
		/// <param name="e">The <see cref="KeyPressEventArgs" /> instance containing the event data.</param>
		public static void ValidateNumbersOnTextBox(KeyPressEventArgs e , TextBox tb)
		{
            e.Handled = (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) && !(e.KeyChar == 44) ;
            if (e.KeyChar == 22 || e.KeyChar == 3) 
                e.Handled = false;

            if (e.KeyChar == 45)
            {
                if (tb.Text.Length > 0) e.Handled = true;
                else e.Handled = false;
                if (tb.SelectedText.Length == tb.Text.Length) e.Handled = false;
            }
                

		}

		#endregion

		#region Dialog Helper

       


		/// <summary>
		/// Shows the warning dialog.
		/// </summary>
		/// <param name="message">The message.</param>
		/// <returns></returns>
		public static DialogResult ShowWarningDialog(string message)
		{
			return MessageBox.Show(message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}



        public static void ShowCPANotImportYet(List<string> cpas)
        {
            string msgContent = "";
            for (int i = 0; i < cpas.Count; i++)
            {
                msgContent += clsCommonFunctions.GetMonthYearShowOnDataGrid(cpas[i]);
                if (i < cpas.Count - 1)
                {
                    msgContent += ", ";
                }
            }
          
             MessageBox.Show("CPA on "+ msgContent + " have not been imported yet !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
		/// <summary>
		/// Shows the error dialog.
		/// </summary>
		/// <param name="message">The message.</param>
		/// <returns></returns>
		public static DialogResult ShowErrorDialog(string message)
		{
			return MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}

        public static void MessageNoTransactions()
        {
            MessageBox.Show("No transaction found", "Message");
        }

		/// <summary>
		/// Shows the info dialog.
		/// </summary>
		/// <param name="message">The message.</param>
		/// <returns></returns>
		public static DialogResult ShowInfoDialog(string message)
		{
			return MessageBox.Show(message, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		/// <summary>
		/// Shows the chosing dialog.
		/// </summary>
		/// <param name="message">The message.</param>
		/// <returns></returns>
		public static DialogResult ShowYesNoCancelDialog(string message)
		{
			return MessageBox.Show(message, "Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
		}

		/// <summary> 
		/// Shows the yes/no dialog.
		/// </summary>
		/// <param name="message">The message.</param>
		/// <returns></returns>
		public static DialogResult ShowYesNoDialog(string message)
		{
			return MessageBox.Show(message, "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
		}


		/// <summary>
		/// Show save excel file dialog
		/// </summary>
		/// <returns></returns>
		public static DialogResult ShowSaveExcelDialog(ref string strFileName)
		{
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.FileName = strFileName;
			saveFileDialog.Filter = "Excel 95,97,2003(*.xls)|*.xls|Excel 2007-2010(*.xlsx)|*.xlsx";
			saveFileDialog.Title = clsCommonString.SAVE_REPORT_TITLE;
			saveFileDialog.OverwritePrompt = true;
			strFileName = saveFileDialog.FileName;
			DialogResult result = saveFileDialog.ShowDialog();
			strFileName = saveFileDialog.FileName;
			return result;
		}

		#endregion

		#region Converter

		/// <summary>
		/// Converts the month year to format mm/yyyy
		/// </summary>
		/// <param name="yyyymm">The yyyymm.</param>
		/// <returns></returns>
		public static string ConvertMonthYear(string yyyymm)
		{
			if (yyyymm.Length == 6)
			{
				string year = yyyymm.Substring(0, 4);
				string mm = yyyymm.Substring(4, 2);

				return mm + "/" + year;
			}
			return "";
		}

		/// <summary>
		/// convert number (int64) to a format string
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public static string ConvertToStandardNumber(Int64 input)
		{
			return input.ToString("#,0", CultureInfo.InvariantCulture);
		}

		/// <summary>
		/// get list month year from start month to end month
		/// </summary>
		/// <param name="startMonth"></param>
		/// <param name="endMonth"></param>
		/// <returns></returns>

		public static List<string> GetListMonthYearForExportToExcel(string startMonth, string endMonth, bool needQuaterColumn)
		{
			List<string> result = new List<string>();
			DateTime startDay = new DateTime(int.Parse(startMonth.Remove(4)), int.Parse(startMonth.Remove(0, 4)), 1);
			DateTime endDay = new DateTime(int.Parse(endMonth.Remove(4)), int.Parse(endMonth.Remove(0, 4)), 1);
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * 12 + month;

			result.Add(GetMonthYearShowOnExcel(startDay.ToString("yyyyMM")));
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);

				string temp = startDay.ToString("yyyyMM");
				result.Add(GetMonthYearShowOnExcel(temp));
				if (needQuaterColumn == true)
				{
					if (startDay.Month == 3 || startDay.Month == 6 || startDay.Month == 9 || startDay.Month == 12)
					{
						DateTime date = startDay.AddMonths(-2);
						string a = (GetMonthYearShowOnExcel(date.ToString("yyyyMM"))).Remove(3);
						result.Add("Total " + a + "~" + (GetMonthYearShowOnExcel(temp)).Remove(4, 1));
						result.Add("Average " + a + "~" + (GetMonthYearShowOnExcel(temp)).Remove(4, 1));
						if (startDay.Month == 3)
						{
							result.Add("Total " + (startDay.Year - 1).ToString());
							result.Add("Average " + (startDay.Year - 1).ToString());
						}

					}
				}
			}

			return result;
		}
        public static List<string> GetListMonthYear(string startMonth, string endMonth)
        {
            List<string> result = new List<string>();
            DateTime startDay = new DateTime(int.Parse(startMonth.Remove(4)), int.Parse(startMonth.Remove(0, 4)), 1);
            DateTime endDay = new DateTime(int.Parse(endMonth.Remove(4)), int.Parse(endMonth.Remove(0, 4)), 1);
            int year = endDay.Year - startDay.Year;
            int month = endDay.Month - startDay.Month;
            int totalMonth = year * 12 + month;

            result.Add(startDay.ToString("yyyyMM"));
            for (int i = 0; i < totalMonth; i++)
            {
                startDay = startDay.AddMonths(1);

                string temp = startDay.ToString("yyyyMM");
                result.Add(temp);
                
            }

            return result;
        }
		/// <summary>
		/// get list month year from start month to end month
		/// </summary>
		/// <param name="startMonth"></param>
		/// <param name="endMonth"></param>
		/// <returns></returns>
		public static List<string> GetListMonthYearForExportToExcelWithYear(string startMonth, string endMonth, bool needQuaterColumn)
		{
			List<string> result = new List<string>();
			DateTime startDay = new DateTime(int.Parse(startMonth.Remove(4)), int.Parse(startMonth.Remove(0, 4)), 1);
			DateTime endDay = new DateTime(int.Parse(endMonth.Remove(4)), int.Parse(endMonth.Remove(0, 4)), 1);
			int year = endDay.Year - startDay.Year;
			int month = endDay.Month - startDay.Month;
			int totalMonth = year * 12 + month;

			result.Add(GetMonthYearShowOnExcel(startDay.ToString("yyyyMM")));
			for (int i = 0; i < totalMonth; i++)
			{
				startDay = startDay.AddMonths(1);

				string temp = startDay.ToString("yyyyMM");
				result.Add(GetMonthYearShowOnExcel(temp));
				if (needQuaterColumn == true)
				{
					if (startDay.Month == 12)
					{
						result.Add(startDay.Year.ToString());
					}
				}
			}

			return result;
		}

		/// <summary>Find start month by quarter 
		/// </summary>
		/// <param name="iQuarter"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static string FindStartMonthByQuater(int iQuarter)
		{
			return ((iQuarter - 1) * 3 + 1).ToString("00");
		}

		/// <summary>
		/// Find end month by quarter
		/// </summary>
		/// <param name="iQuarter"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static string FindEndMonthByQuater(int iQuarter)
		{
			return (iQuarter * 3).ToString("00");
		}


        public static int FindQuarterByMonth(int month)
        {
            return (month - 1) / 3 + 1;
        }

		/// <summary>
		/// Find start month by quarter 
		/// </summary>
		/// <param name="strQuarter">MM/yyyy</param>
		/// <returns>yyyyMM</returns>
		public static string FindStartMonthByQuater(string strQuarter)
		{
			int iQuarter = (int.Parse(strQuarter.Substring(0, strQuarter.Length - 5)) - 1) * 3 + 1;
			string strYear = strQuarter.Substring(strQuarter.Length - 5 + 1, 4);
			if (iQuarter > 9)
			{
				return strYear + "0" + iQuarter;
			}
			else
			{
				return strYear + "0" + iQuarter;
			}
		}

		/// <summary>
		/// Find end month by quarter 
		/// </summary>
		/// <param name="iQuarter">MM/yyyy</param>
		/// <returns>yyyyMM</returns>
		public static string FindEndMonthByQuater(string strQuarter)
		{
			int iQuarter = int.Parse(strQuarter.Substring(0, strQuarter.Length - 5)) * 3;
			string strYear = strQuarter.Substring(strQuarter.Length - 5 + 1, 4);
			if (iQuarter > 9)
			{
				return strYear + "0" + iQuarter;
			}
			else
			{
				return strYear + "0" + iQuarter;
			}
		}

		/// <summary>
		/// convert string MMyyyy to mmm - yyyy
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public static string GetMonthYearShowOnExcelFromTo(string input)
		{
			int outNumber;
			if (!int.TryParse(input, out outNumber))
				return input;
			string result = "";
			DateTime date = new DateTime(int.Parse(input.Remove(4)), int.Parse(input.Remove(0, 4)), 1);

			result = date.ToString("Y", CultureInfo.CreateSpecificCulture("en-US"));
			result = result.Remove(3, result.Length - 8);
			return result;//.Replace(" ", "-");
		}

		/// <summary>
		/// convert string MMyyyy to mmm - yyyy
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public static string GetMonthYearShowOnExcel(string input)
		{
			int outNumber;
			if (!int.TryParse(input, out outNumber))
				return input;
			string result = "";
			DateTime date = new DateTime(int.Parse(input.Remove(4)), int.Parse(input.Remove(0, 4)), 1);
			//Yen fix header name 06-03-2013
			result = date.ToShortDateString();
			return result;
			//result = date.ToString("Y", CultureInfo.CreateSpecificCulture("en-US"));
			//result = result.Remove(3, result.Length - 8);
			//return result.Replace(" ", "-");
		}
		/// <summary>
		/// convert string MMyyyy to mmm yyyy
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public static string GetMonthYearShowOnDataGrid(string input)
		{
			string result = "";
			DateTime date = new DateTime(int.Parse(input.Remove(4)), int.Parse(input.Remove(0, 4)), 1);
			result = date.ToString("Y", CultureInfo.CreateSpecificCulture("en-US"));
			result = result.Remove(3, result.Length - 8);
			return result.Insert(3, " ");
		}
		/// <summary>
		/// convert from mm/yyyy -> yyyymm
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public static string GetMonthYearFromInputToDatabase(string input)
		{
			string result = "";
			result = input.Remove(0, 3);
			result += input.Remove(2);
			return result;
		}

		/// <summary>
		/// mmm yyyy -> yyyyMM
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public static string GetYearMonthFromDatagridToDatabase(string input)
		{
			string result = "";
			result = input.Remove(0, 5);
			switch (input.Remove(3))
			{
				case "Jan": result += "01";
					break;
				case "Feb": result += "02";
					break;
				case "Mar": result += "03";
					break;
				case "Apr": result += "04";
					break;
				case "May": result += "05";
					break;
				case "Jun": result += "06";
					break;
				case "Jul": result += "07";
					break;
				case "Aug": result += "08";
					break;
				case "Sep": result += "09";
					break;
				case "Oct": result += "10";
					break;

				case "Nov": result += "11";
					break;

				case "Dec": result += "12";
					break;
			}
			return result;
		}
		/// <summary>
		/// Get matrix from list
		/// </summary>
		/// <param name="lstStringInput"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static object[,] GetMatrixFromList(List<string> lstStringInput)
		{
			object[,] arrResult = new object[1, lstStringInput.Count];
			for (int i = 0; i < lstStringInput.Count; i++)
				arrResult[0, i] = GetMonthYearShowOnExcel(lstStringInput[i]);
			return arrResult;
		}

		/// <summary>
		/// Convert string to datetime with format
		/// </summary>
		/// <param name="strDate"></param>
		/// <param name="strFormat"></param>
		/// <returns></returns>
		public static DateTime ConvertDateTimeWithFortmat(string strDate, string strFormat)
		{
			DateTime date = DateTime.ParseExact(strDate, strFormat, CultureInfo.InvariantCulture);
			return date;
		}
		/// <summary>
		/// Set date time format for datetime value
		/// </summary>
		/// <param name="dt"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static string GetDateTimeFormat(DateTime dt)
		{
			return string.Format("{0:d-MMM-yy}", dt);
		}
		#endregion

		#region excel function

		/// <summary>
		/// Return column name in excel file belongs to the index of this column
		/// </summary>
		/// <param name="columnNumber"></param>
		/// <returns>Column name</returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static string GetExcelColumnName(int columnNumber)
		{
			int dividend = columnNumber;
			string columnName = String.Empty;
			int modulo;

			while (dividend > 0)
			{
				modulo = (dividend - 1) % 26;
				columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
				dividend = (int) ((dividend - modulo) / 26);
			}

			return columnName;
		}
		#endregion

		/// <summary>
		/// Set check state for all checkbox in datagridview
		/// </summary>
		/// <param name="bValue"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static void SetAllCheck(DataGridView dtgv, bool bValue)
		{
			if (dtgv.Rows.Count > 0)
				for (int i = 0; i < dtgv.Rows.Count; i++)
					dtgv[0, i].Value = bValue.ToString();
		}
		/// <summary>
		/// Check if all checkbox is checked or not
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static bool AllCheck(DataGridView dtgv)
		{
			if (dtgv.Rows.Count > 0)
				for (int i = 0; i < dtgv.Rows.Count; i++)
					if (bool.Parse(dtgv[0, i].Value.ToString()) == false)
						return false;
			return true;
		}

		/// <summary>
		/// Check if all checkbox is not check or not
		/// </summary>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static bool AllNoCheck(DataGridView dtgv)
		{
			if (dtgv.Rows.Count > 0)
				for (int i = 0; i < dtgv.Rows.Count; i++)
					if (bool.Parse(dtgv[0, i].Value.ToString()) == true)
						return false;
			return true;
		}

		/// <summary>
		/// Number input only
		/// </summary>
		/// <param name="e"></param>		
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static void NumerInputOnly(KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
				e.Handled = true;
		}
	 
		/// <summary>
		/// Set state of all checkbox of a datagridview to checked
		/// </summary>
		/// <param name="e"></param>		
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static void SetAllCheckState(DataGridView dtgv, DataGridViewCellMouseEventArgs e)
		{

			if (e.RowIndex == -1 && e.ColumnIndex == 0)
			{
				if (clsCommonFunctions.AllCheck(dtgv) == false)
					clsCommonFunctions.SetAllCheck(dtgv, true);
				else
					clsCommonFunctions.SetAllCheck(dtgv, false);
			}
		}
		/// <summary>
		/// Set state of all checkbox of a datagridview to checked
		/// </summary>
		/// <param name="e"></param>		
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static void SetCheckState(DataGridView dtgv, DataGridViewCellMouseEventArgs e)
		{
			if (e.RowIndex >=0 && e.ColumnIndex == 0)
			{
				clsCommonFunctions.SetAllCheck(dtgv, false);
				dtgv[0, e.RowIndex].Value = (!bool.Parse(dtgv[0, e.RowIndex].Value.ToString())).ToString();
			}
		}
		/// <summary>
		/// Set state of all checkbox of a datagridview to not-checked
		/// </summary>
		/// <param name="e"></param>		
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public static void SetAllCheckState(DataGridView dtgv, int iRowIndex, int iColIndex)
		{

			//MessageBox.Show("" + e.RowIndex + ", " + e.ColumnIndex);
			if (iRowIndex == -1 && iColIndex == 0)
			{
				if (clsCommonFunctions.AllCheck(dtgv) == false)
					clsCommonFunctions.SetAllCheck(dtgv, true);
				else
					clsCommonFunctions.SetAllCheck(dtgv, false);
			}
		}




		/// <summary>
		/// Function trust function as a parameter
		/// </summary>
		/// <param name="method"></param>
		/// <param name="args"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		static object InvokeMethod(Delegate method, params object[] args)
		{
			return method.DynamicInvoke(args);
		}

		/// <summary>
		/// Fill combobox data
		/// </summary>
		/// <param name="methodName"></param>
		/// <param name="cbb"></param>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public bool FillComboboxData(Func<ArrayList> methodName, ComboBox cbb)
		{
			try
			{
				cbb.DataSource = null;
				cbb.Items.Clear();
				ArrayList arrOL = new ArrayList();
				arrOL = (ArrayList) InvokeMethod(new Func<ArrayList>(methodName));
				if (arrOL.Count == 0)
					return false;
				cbb.DataSource = arrOL;
				cbb.DisplayMember = "Display";
				cbb.ValueMember = "Value";
			}
			catch (Exception e)
			{
				MessageBox.Show(e.Message);
				//clsLogFile.LogException(ex.Message); 
			}
			cbb.SelectedIndex = 0;
			return true;
		}

		/// <summary>
		/// Get year from YYYYMM string
		/// </summary>
		/// <param name="strDateTime"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public int GetYear(string strDateTime)
		{
			int iYear = 0;
			if (strDateTime.Trim().Length != 6)
				return iYear;
			iYear = int.Parse(strDateTime.Substring(0, 4));
			return iYear;
		}
		/// <summary>
		/// Get year from YYYYMM string
		/// </summary>
		/// <param name="strDateTime"></param>
		/// <returns></returns>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public int GetMonth(string strDateTime)
		{
			int iMonth = 0;
			if (strDateTime.Trim().Length != 6)
				return iMonth;
			iMonth = int.Parse(strDateTime.Substring(4, 2));
			return iMonth;
		}

		public Int64 CheckNullInt64(object input)
		{
			return input.GetType() == typeof(DBNull) ? 0 : (Int64) input;
		}
	}
}