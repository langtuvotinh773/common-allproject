﻿/*
 * Author:  Quan Nguyen
 * Created: 2-Jan-2013
 * 
 * This class is used to provide common message statements
 * for CPA module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Config.Classes
{
	public class clsCommonMessages
	{


		#region ERROR
		public const string ERROR_INPUT_DATETIME = "Invalid quarter or year";
		public const string ERROR_INPUT_QUATER = "Invalid date quarter";
		public const string ERROR_CHECK_DATETIME = "Please check quarter and year";
		public const string ERROR_INPUT_MONTH_YEAR = "Invalid month year input!";
		#endregion

		#region EXCEL
		public const string ERROR_EXCEL_APP = "EXCEL could not be started.";
		public const string ERROR_EXCEL_WORKSHEET = "Could not create worksheet.";
		public const string ERROR_EXCEL_RANGE = "Could not get a range.";
		public const string TEMPLATE_DOES_NOT_EXIST = "Template file does not exist";
		#endregion

		#region Exceptions

		public static readonly string IMPORT_DATA_ERROR = "There is error data in import data, do you want to process error data?";
		public static readonly string LIST_NO_RESULT = "No transaction found!";

		#endregion

		#region Status Messages

		public static readonly string IMPORT_SUCCESSFULL = "Imported successful !";
		public static readonly string SAVE_SUCCESSFULL = "Saved successful !";
		public static readonly string DELETE_SUCCESSFULL = "Deleted successful !";
		public static readonly string IMPORT_UNSUCCESSFULL = "Imported unsuccessful !";
		public static readonly string SAVE_UNSUCCESSFULL = "Saved unsuccessfully!";
		public static readonly string DELETE_UNSUCCESSFULL = "Deleted unsuccessful !";
		public static readonly string NO_TRANSACTION_FOUND = "No transaction found!";
		public static readonly string STATUS_FINALIZE = "Finalized";
		public static readonly string STATUS_NOTFINALIZE = "Not Finalized";


		#endregion

		#region Confirmations

		public static readonly string CONFIRM_DELETE = "Are you sure you want to delete error data?";
		public static readonly string CONFIRM_SAVE = "Are you sure you want to save?";
		public static string DATA_SAVE_SUCCESSFUL = "Data was saved successfully!";
        public static string DATA_DELETE_SUCCESSFUL = "Data was deleted successfully!";
		public static string CONFIRM_SAVE_OL = "Do you want to save changes of OL?";
        public static string CONFIRM_SAVE_REPAYMENT = "Do you want to save changes of repayment?";
		public static readonly string DO_YOU_WANT_TO_SAVE_CHANGES = "Do you want to save changes?";

		#endregion

		#region Warnings

		public static readonly string CHOOSE_ITEM_TO_DELETE = "Please choose any item to delete!";
        public static readonly string CHOOSE_ITEM_TO_UPDATE = "Please choose any item to update!";
        public static readonly string CHOOSE_ONE_ITEM_TO_UPDATE = "You can only choose one item to update!";
		public static readonly string THERE_IS_NO_CHANGE = "There is no change!";
		public static readonly string TEXTBOX_OVER_TEN = "Length of value must be equal or less than 10 digits";
		public const string ALREADY_OPENED = "This file is already opened!";
		public const string LACK_INFO_INPUT = "Lack of input information!";
		public const string CREATE_OL_SUCCESS = "Create Offshore Loan successfully!";
		#endregion

		#region OL
		public static readonly string REPAYMENT_SAVE_SUCCESS = "Repayment was updated sucessfully";
        public static readonly string DO_YOU_WANT_PROCESS_DATA = "Do you want to process selected data?";
		#endregion

	
	}
}