﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-01-08 20:37:30 +0700 (Mon, 08 Jan 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to provide function to create an excel file
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Diagnostics;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using Microsoft.Office.Interop.Excel;
namespace Config.Classes
{
    /// <summary>
    /// This class define function processing export data to excel file
    /// </summary>
    public class ExcelBase
    {

        /// <summary>
        /// Please add this reference to your solution		
        /// Add Microsoft.Office.Interop.Excel reference, its default path is:
        /// Visual Studio Tools for Office\ PIA\Office12\Microsoft.Office.Interop.Excel.dll 
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private Microsoft.Office.Interop.Excel.Application app = null;
        private Microsoft.Office.Interop.Excel.Workbook workbook = null;
        private Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
        public Microsoft.Office.Interop.Excel.Worksheet Worksheet
        {
            get { return worksheet; }
            set { worksheet = value; }
        }
        private Microsoft.Office.Interop.Excel.Range workSheet_range = null;
        private string m_FilePath;
        private string m_TemplateName;
        private string m_TemplatePath = "";
        private string m_ProjectName = "";
        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="strFilePath"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public ExcelBase(string strFilePath, string strTemplateName, string strProjectName, ref bool isOpened, string serverDate)
        {
            if (IsOpened(strFilePath))
            {
                isOpened = true;
                return;
            }
            m_ProjectName = strProjectName;
            m_TemplateName = strTemplateName;
            m_FilePath = strFilePath;
            CreateDoc(true, serverDate);
        }
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="strFilePath"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public ExcelBase(string strFullFilePath, string strProjectName, string serverDate)
        {
            m_FilePath = strFullFilePath;
            m_ProjectName = strProjectName;
            CreateDoc(false, serverDate);
        }

        /// <summary>
        /// Check if this file is opened or not
        /// </summary>
        /// <param name="strFileName"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond		
        private bool IsOpened(string strFileName)
        {
            FileStream stream = null;
            FileInfo file = new FileInfo(strFileName);
            if (!File.Exists(strFileName))
                return false;
            try
            {
                stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException e)
            {
                //the file is unavailable because it is:
                //still being written to
                //or being processed by another thread
                //or does not exist (has already been processed)            
                clsCommonFunctions.ShowWarningDialog(clsCommonMessages.ALREADY_OPENED);
                clsLogFile.LogException(e.Message);
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }

            //file is not locked
            return false;
        }
        /// <summary>
        /// Save the generated excel file
        /// </summary>
        /// <param name="strFilePath"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void SaveFile()
        {
            //try
            //{
                worksheet.Columns.AutoFit();
                app.Visible = true;

                //workbook.Saved = true;
                // workbook.SaveCopyAs(m_FilePath);
                ReleaseExcel();
            //}
            //catch (Exception e)
            //{
            //    clsCommonFunctions.ShowWarningDialog(clsCommonMessages.ALREADY_OPENED);
            //    clsLogFile.LogException(e.Message);
            //}
        }
        /// <summary>
        /// Save the generated excel file
        /// </summary>
        /// <param name="strFilePath"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void SaveFile(double dColumnWith)
        {
            //try
            //{
                ((Excel.Range)worksheet.Columns).ColumnWidth = dColumnWith;
                app.Visible = true;
                //workbook.Saved = true;

                //workbook.SaveCopyAs(m_FilePath);
                ReleaseExcel();
            //}
            //catch (Exception e)
            //{
            //    clsCommonFunctions.ShowWarningDialog(clsCommonMessages.ALREADY_OPENED);
            //    clsLogFile.LogException(e.Message);
            //}
        }

        /// <summary>
        /// Save the generated excel file
        /// </summary>
        /// <param name="strFilePath"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void SaveFile(bool isOpen)
        {
            //try
            //{
                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                if (isOpen)
                {
                    app.Visible = true;
                }
                

                //workbook.Saved = true;
                // workbook.SaveCopyAs(m_FilePath);
                if (!isOpen)
                {
                    ReleaseExcel(isOpen);
                }
            //}
            //catch (Exception e)
            //{
            //    clsCommonFunctions.ShowWarningDialog(clsCommonMessages.ALREADY_OPENED);
            //    clsLogFile.LogException(e.Message);
            //}
        }

        /// <summary>
        /// Release excel object
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void ReleaseExcel()
        {

            //int hWnd = app.Application.Hwnd;
            //uint processID;

            ReleaseObject(worksheet);
            ReleaseObject(workbook);
            ReleaseObject(app);
            Marshal.ReleaseComObject(app);
            //GetWindowThreadProcessId((IntPtr)hWnd, out processID);
            //Process[] procs = Process.GetProcessesByName("EXCEL");
            //foreach (Process p in procs)
            //{
            //    if (p.Id == processID)
            //        p.Kill();
            //}
        }

        /// <summary>
        /// Release excel object
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void ReleaseExcel(bool isOpen)
        {

            int hWnd = app.Application.Hwnd;
            uint processID;

            ReleaseObject(worksheet);
            ReleaseObject(workbook);
            ReleaseObject(app);
            Marshal.ReleaseComObject(app);
            if (!isOpen)
            {
                GetWindowThreadProcessId((IntPtr)hWnd, out processID);
                Process[] procs = Process.GetProcessesByName("EXCEL");
                foreach (Process p in procs)
                {
                    if (p.Id == processID)
                        p.Kill();
                }
            }

        }

        /// <summary>
        /// Release excel object
        /// </summary>
        /// <param name="application"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public static void ReleaseExcel(Microsoft.Office.Interop.Excel.Application application)
        {
            application.Quit();

            int hWnd = application.Application.Hwnd;
            uint processID;

            System.Runtime.InteropServices.Marshal.ReleaseComObject(application);

            GetWindowThreadProcessId((IntPtr)hWnd, out processID);
            Process[] procs = Process.GetProcessesByName("EXCEL");
            foreach (Process p in procs)
            {
                if (p.Id == processID)
                    p.Kill();
            }
        }

        /// <summary>
        /// Release Excel Object
        /// </summary>
        /// <param name="obj"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                clsLogFile.LogException(ex.Message);
            }
            finally
            {
                GC.Collect();
            }
        }

        /// <summary>
        /// Initialize File
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void CreateDoc(bool isTemplate, string serverDate)
        {
            //try
            //{
                app = new Microsoft.Office.Interop.Excel.Application();
                //app.ScreenUpdating = false;
                app.ErrorCheckingOptions.NumberAsText = false;

                string path = AppDomain.CurrentDomain.BaseDirectory + m_ProjectName + "_GUI\\REPORT\\TEMPLATE\\";
                clsTemplateManager.Instance().CreateFile(path, m_TemplateName, serverDate);
                string strFilePath = "";
                if (isTemplate)
                    strFilePath = clsTemplateManager.Instance().FilePath + "\\" + m_TemplateName.Remove(m_TemplateName.Length - 4, 4) + "_" + serverDate + "_" + ".xls";
                else
                    strFilePath = m_FilePath;


                if (!File.Exists(strFilePath))
                    CreateExcel(strFilePath);
                else
                {
                    //  object _missingValue = System.Reflection.Missing.Value;
                    ////  workbook = app.Workbooks.Open(strFilePath, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue);
                    //  workbook = app.Workbooks.Open(strFilePath, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue, _missingValue);
                    //  app.cop
                    workbook = app.Workbooks.Add(strFilePath);
                   
                    //workbook. = m_TemplateName.Remove(m_TemplateName.Length - 4, 4) + "_" + serverDate;
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[1];
                    //object lastSheet = (workbook.Worksheets.Count > 0 ? workbook.Worksheets.get_Item(workbook.Worksheets.Count) : Type.Missing);

                    //worksheet= wor kbook.Worksheets.Add(Type.Missing, lastSheet, Type.Missing, Excel.XlSheetType.xlWorksheet) as Excel.Worksheet;
                    //object misValue = System.Reflection.Missing.Value;
                    //workbook.SaveAs("123123", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, true, misValue, Excel.XlSaveAsAccessMode.xlExclusive, XlSaveConflictResolution.xlOtherSessionChanges, misValue, misValue, misValue, misValue);

                    //workbook
                }
                //	app.Visible = true;

            //}
            //catch (Exception e)
            //{
            //    clsCommonFunctions.ShowErrorDialog(clsCommonMessages.TEMPLATE_DOES_NOT_EXIST);
            //    clsLogFile.LogException(e.Message);
            //}
            //finally
            //{

            //}

        }


        /// <summary>
        /// Create excel file
        /// </summary>
        /// <param name="strTemplateFilePath"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void CreateExcel(string strTemplateFilePath)
        {
            object misValue = System.Reflection.Missing.Value;
            app = new Excel.ApplicationClass();
            workbook = app.Workbooks.Add(misValue);
            worksheet = (Excel.Worksheet)workbook.Worksheets.get_Item(1);
            FormatTemplate(m_TemplateName);

            m_TemplatePath = strTemplateFilePath;
        }

        /// <summary>
        /// Create formated template file in case the there is no template file
        /// </summary>
        /// <param name="strTemplateName"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate(string strTemplateName)
        {
            app.StandardFont = clsConstant.FONT_EXCEL_REPORT;
            app.StandardFontSize = clsConstant.CELL_SIZE;
            worksheet.Cells.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
            switch (strTemplateName)
            {
                case clsCommonString.REPORT_ON_CPA_BY_ACCOUNT_OFFICER:
                    FormatTemplate0102();
                    break;
                case clsCommonString.REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS:
                    FormatTemplate03();
                    break;
                case clsCommonString.REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER:
                    FormatTemplate04();
                    break;
                case clsCommonString.REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER:
                    FormatTemplate05();
                    break;
                case clsCommonString.REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER:
                    FormatTemplate06();
                    break;
                case clsCommonString.REPORT_ON_FOREX_PROFIT_BY_CUSTOMER:
                    FormatTemplate07();
                    break;
                case clsCommonString.REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER:
                    FormatTemplate08();
                    break;
                case clsCommonString.REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER:
                    FormatTemplate09();
                    break;
                case clsCommonString.REPORT_ON_LOAN_PROFIT_BY_CUSTOMER:
                    FormatTemplate10();
                    break;
                case clsCommonString.REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE:
                    FormatTemplate11();
                    break;
                case clsCommonString.REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE:
                    FormatTemplate12();
                    break;
                case clsCommonString.TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT:
                    FormatTemplate13();
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Create format template file for R_01(All-VN)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate0102()
        {
            worksheet.Cells.NumberFormat = "0,00";

            //row header	
            workSheet_range = GetRange(1, 4, 5, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 4, 2, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 16, 1, 16);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Input value info
            workSheet_range = GetRange(1, 6, 1, 14);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;


            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
        }
        /// <summary>
        /// Create format template file for R_01(All-VN)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate03()
        { }
        /// <summary>
        /// Create format template file for R_02(All-VN)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate02()
        {
            worksheet.Cells.NumberFormat = "0,000";

            //row header
            workSheet_range = GetRange(2, 5, 2, 5);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            workSheet_range = GetRange(5, 4, 5, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;

            //column header
            workSheet_range = GetRange(1, 4, 1, 4);
            workSheet_range.EntireRow.Font.Bold = true;
        }

        /// <summary>
        /// Create format template file for R_04(Deposit Ave Bal)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate04()
        {
            worksheet.Cells.NumberFormat = "0.00";

            //row header	
            workSheet_range = GetRange(1, 4, 5, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 4, 2, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 4, 1, 4);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 2, 11, 2);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>
        /// Create format template file for R_05(Loan Ave Bal)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate05()
        {

            //row header	
            workSheet_range = GetRange(1, 4, 5, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 4, 2, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 4, 1, 4);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 2, 11, 2);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>
        /// Create format template file for R_06(Commission and Fee)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate06()
        {
            worksheet.Cells.NumberFormat = "0.00";

            //row header	
            workSheet_range = GetRange(1, 4, 5, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 4, 2, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 4, 1, 4);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 2, 11, 2);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>
        /// Create format template file for R_07(Forex Profit)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate07()
        {
            worksheet.Cells.NumberFormat = "0.00";

            //row header	
            workSheet_range = GetRange(1, 4, 5, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 4, 2, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 4, 1, 4);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 2, 11, 2);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>
        /// Create format template file for R_08(Total Profit)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate08()
        {
            worksheet.Cells.NumberFormat = "0.00";

            //row header	
            workSheet_range = GetRange(1, 4, 5, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 4, 2, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 4, 1, 4);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 2, 11, 2);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>
        /// Create format template file for R_09(Interest_ Deposit)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate09()
        {
            worksheet.Cells.NumberFormat = "0.00";

            //row header	
            workSheet_range = GetRange(1, 4, 5, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 4, 2, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 4, 1, 4);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 1, 11, 1);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>
        /// Create format template file for R_10(Interest_ Loan)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate10()
        {
            worksheet.Cells.NumberFormat = "0.00";

            //row header	
            workSheet_range = GetRange(1, 4, 5, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 4, 2, 4);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 4, 1, 4);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 1, 11, 1);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>
        /// Create format template file for R_11(Deposit Ave Bal)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate11()
        {
            worksheet.Cells.NumberFormat = "0.00";

            //row header	
            workSheet_range = GetRange(1, 5, 3, 5);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 5, 2, 5);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 5, 1, 5);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 1, 11, 1);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            workSheet_range = GetRange(1, 4, 11, 4);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>
        /// Create format template file for R_12(Loan Ave Bal)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate12()
        {
            worksheet.Cells.NumberFormat = "0.00";

            //row header	
            workSheet_range = GetRange(1, 5, 3, 5);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 5, 2, 5);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 5, 1, 5);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 1, 11, 1);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            workSheet_range = GetRange(1, 4, 11, 4);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>
        /// Create format template file for R_13(Total Profit)
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void FormatTemplate13()
        {
            worksheet.Cells.NumberFormat = "0.00";

            //row header	
            workSheet_range = GetRange(1, 5, 3, 5);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //column 2
            workSheet_range = GetRange(2, 5, 2, 5);
            workSheet_range.EntireColumn.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            //column header
            workSheet_range = GetRange(1, 5, 1, 5);
            workSheet_range.EntireRow.Font.Size = clsConstant.HEADER_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            //Title
            workSheet_range = GetRange(1, 2, 1, 2);
            workSheet_range.EntireRow.Font.Size = clsConstant.TITLE_SIZE;
            workSheet_range.EntireRow.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            workSheet_range.EntireRow.Font.Bold = true;
            workSheet_range = GetRange(3, 1, 11, 1);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            workSheet_range = GetRange(1, 4, 11, 4);
            workSheet_range.Merge(Type.Missing);
            workSheet_range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        /// <summary>Get a group of cell belongs to the index of column(start & end)  and row(start & end)
        /// Yen Phan
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="iColEnd"></param>
        /// <param name="iRowEnd"></param>
        /// <returns>Return a group of cell</returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public Excel.Range GetRange(int iColStart, int iRowStart, int iColEnd, int iRowEnd)
        {
            Excel.Range excRange = null;
            object m = Type.Missing;
            string errorMessage = string.Empty;
            try
            {
                // Set the range to fill.
                string strCellStart = clsCommonFunctions.GetExcelColumnName(iColStart) + iRowStart;
                string strCellEnd = clsCommonFunctions.GetExcelColumnName(iColEnd) + iRowEnd;
                excRange = worksheet.get_Range(strCellStart, strCellEnd);//"A1", "E100");
            }
            catch (Exception e) { clsLogFile.LogException(e.Message); }
            return excRange;
        }

        /// <summary>Write log error
        /// Yen Phan
        /// </summary>
        /// <param name="strErrMess"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        private void WriteLog(string strErrMess)
        {
            clsLogFile.LogException(strErrMess);
            throw new Exception(strErrMess);
        }
        /// <summary>
        /// Export data to a range in excel
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="iColEnd"></param>
        /// <param name="iRowEnd"></param>
        /// <param name="data"></param>
        /// <returns>Return a group of cell</returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public Excel.Range ExportRange(int iColStart, int iRowStart, int iColEnd, int iRowEnd, int[,] data)
        {
            try
            {
                if (app == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_APP);
                if (worksheet == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_WORKSHEET);
                Excel.Range excRange = GetRange(iColStart, iRowStart, iColEnd, iRowEnd);
                if (excRange == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_RANGE);

                // Save all data to the worksheet.
                excRange.set_Value(Microsoft.Office.Interop.Excel.XlRangeValueDataType.xlRangeValueDefault, (object)data);

                Excel.Borders borders = excRange.Borders;
                excRange.Borders.Color = System.Drawing.Color.Black.ToArgb();
                if (excRange.Rows.Count > 1)
                    borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle = Excel.XlLineStyle.xlLineStyleNone;

                borders = null;

                return excRange;
            }
            catch (Exception e)
            {
                clsCommonFunctions.ShowErrorDialog(e.Message);
                clsLogFile.LogException(e.Message);
            }

            return null;
        }
        public Excel.Range ExportRange(int iColStart, int iRowStart, int iColEnd, int iRowEnd, string[] data)
        {
            try
            {
                if (app == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_APP);
                if (worksheet == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_WORKSHEET);
                Excel.Range excRange = GetRange(iColStart, iRowStart, iColEnd, iRowEnd);
                if (excRange == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_RANGE);

                // Save all data to the worksheet.

                excRange.set_Value(Microsoft.Office.Interop.Excel.XlRangeValueDataType.xlRangeValueDefault, (object)data);
                Excel.Borders borders = excRange.Borders;
                excRange.Borders.Color = System.Drawing.Color.Black.ToArgb();
                if (excRange.Rows.Count > 1)
                    borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle = Excel.XlLineStyle.xlLineStyleNone;

                borders = null;

                return excRange;
            }
            catch (Exception e)
            {
                clsCommonFunctions.ShowErrorDialog(e.Message);
                clsLogFile.LogException(e.Message);
            }

            return null;
        }
        /// <summary>
        /// Export range
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="iColEnd"></param>
        /// <param name="iRowEnd"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public Excel.Range ExportRange(int iColStart, int iRowStart, int iColEnd, int iRowEnd, object[,] data)
        {
            try
            {
                if (app == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_APP);
                if (worksheet == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_WORKSHEET);
                Excel.Range excRange = GetRange(iColStart, iRowStart, iColEnd, iRowEnd);
                if (excRange == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_RANGE);
               // data[0, 6] = "";
                excRange.set_Value(Microsoft.Office.Interop.Excel.XlRangeValueDataType.xlRangeValueDefault, (object)data);

                Excel.Borders borders = excRange.Borders;
                excRange.Borders.Color = System.Drawing.Color.Black.ToArgb();
                if (excRange.Rows.Count > 1)
                {
                    borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle = Excel.XlLineStyle.xlContinuous;
                    borders[Excel.XlBordersIndex.xlInsideHorizontal].Weight = Excel.XlBorderWeight.xlHairline;
                }
                borders = null;
                return excRange;
            }
            catch (Exception e)
            {
                clsCommonFunctions.ShowErrorDialog(e.Message);
                clsLogFile.LogException(e.Message);
            }
            return null;
        }
        /// <summary>
        /// Export data to a range in excel
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="iColEnd"></param>
        /// <param name="iRowEnd"></param>
        /// <param name="data"></param>
        /// <returns>Return a group of cell</returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public Excel.Range ExportRange(int iColStart, int iRowStart, int iColEnd, int iRowEnd, string[,] data)
        {
            try
            {
                if (app == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_APP);
                if (worksheet == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_WORKSHEET);
                Excel.Range excRange = GetRange(iColStart, iRowStart, iColEnd, iRowEnd);
                if (excRange == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_RANGE);
                System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
                excRange.set_Value(Microsoft.Office.Interop.Excel.XlRangeValueDataType.xlRangeValueDefault, data);

                Excel.Borders borders = excRange.Borders;
                excRange.Borders.Color = System.Drawing.Color.Black.ToArgb();
                if (excRange.Rows.Count >= 2)
                {
                    borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle = Excel.XlLineStyle.xlContinuous;
                    borders[Excel.XlBordersIndex.xlInsideHorizontal].Weight = Excel.XlBorderWeight.xlHairline;
                }
                borders = null;
                return excRange;
            }
            catch (Exception e)
            {
                clsCommonFunctions.ShowErrorDialog(e.Message);
                clsLogFile.LogException(e.Message);
            }
            return null;
        }
        /// <summary>
        /// Export data to a range in excel
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="iColEnd"></param>
        /// <param name="iRowEnd"></param>
        /// <param name="data"></param>
        /// <returns>Return a group of cell</returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public Excel.Range ExportRangeMergeCell(int iColStart, int iRowStart, int iColEnd, int iRowEnd, string[,] data)
        {
            try
            {
                if (app == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_APP);
                if (worksheet == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_WORKSHEET);
                Excel.Range excRange = GetRange(iColStart, iRowStart, iColEnd, iRowEnd);
                if (excRange == null)
                    WriteLog(clsCommonMessages.ERROR_EXCEL_RANGE);

                excRange.set_Value(Microsoft.Office.Interop.Excel.XlRangeValueDataType.xlRangeValueDefault, (object)data);
                excRange.Borders.Color = System.Drawing.Color.Black.ToArgb();
                return excRange;
            }
            catch (Exception e)
            {
                clsCommonFunctions.ShowErrorDialog(e.Message);
                clsLogFile.LogException(e.Message);
            }
            return null;
        }

        //public void SetLineStyle(int iColStart, int iRowStart, int iColEnd, int iRowEnd)
        //{
        //    Excel.Range excelRange = GetRange(iColStart, iRowStart, iColEnd, iRowEnd);
        //    Excel.Borders borders = excelRange.Borders;
        //    excelRange.Borders.Color = System.Drawing.Color.Black.ToArgb();
        //    if (excelRange.Rows.Count > 2)
        //    {
        //        borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle = Excel.XlLineStyle.xlContinuous;
        //        borders[Excel.XlBordersIndex.xlInsideHorizontal].Weight = Excel.XlBorderWeight.xlHairline;
        //    }
        //    borders = null;
        //}

        /// <summary>
        /// Set text for a cell in excel file
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="strText"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void InsertText(int iColStart, int iRowStart, string strText)
        {
            try
            {
                worksheet.Cells[iRowStart, iColStart] = strText;
            }
            catch (Exception e) { clsLogFile.LogException(e.Message); };
        }        

        /// <summary>
        /// Set text for a cell in excel file
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="strText"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void InsertText(int iColStart, int iRowStart, string strText, int iColor)
        {
            try
            {
                worksheet.Cells[iRowStart, iColStart] = strText;
               // ((Excel.Range)worksheet.Cells[iRowStart, iColStart]).Borders.Color = iColor;
                ((Excel.Range)worksheet.Cells[iRowStart, iColStart]).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
            }
            catch (Exception e) { clsLogFile.LogException(e.Message); };
        }

        /// <summary>
        /// Set Picture For Cell
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="imgObj"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        [STAThread]
        public void InsertPicture(int iColStart, int iRowStart, string imgPath, double imgWidth, double imgHeight)
        {
            try
            {
                object misValue = System.Reflection.Missing.Value;
                Excel.Range rangeObj = (Excel.Range)worksheet.Cells[iRowStart, iColStart];
                Excel.Pictures imgObjCollection = worksheet.Pictures(misValue) as Excel.Pictures;
                Excel.Picture imgObj = null;
                imgObj = imgObjCollection.Insert(imgPath, misValue);
                imgObj.Left = Convert.ToDouble(rangeObj.Left) + (Convert.ToDouble(rangeObj.Width) - imgWidth) / 2;
                imgObj.Top = Convert.ToDouble(rangeObj.Top);
                imgObj.Width = imgWidth;
                imgObj.Height = imgHeight;
            }
            catch (Exception e) 
            { 
                clsLogFile.LogException(e.Message); 
            };
        }

        /// <summary>
        /// Delete columns
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iColCount"></param>
        /// <param name="iRowStart"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void DeleteColumns(int iColStart, int iColCount, int iRowStart)
        {
            worksheet.get_Range(iColCount + (iColCount + 1).ToString(), iColCount + iColStart).Delete(Type.Missing);
            for (int i = 0; i < iColCount; i++)
                ((Excel.Range)worksheet.Columns[Type.Missing, iColStart + i]).Delete(Excel.XlDeleteShiftDirection.xlShiftUp);
        }


        public void MergeCellTitle(int iColStart, int iRowStart, int iColCount, int iRowCount)
        {
            Excel.Range range = worksheet.get_Range(worksheet.Cells[iRowStart, iColStart], worksheet.Cells[iRowStart + iRowCount - 1, iColStart + iColCount - 1]);
            range.Merge(true);
        }
        public void MergeCell(int iColStart, int iRowStart, int iColCount, int iRowCount,Excel.XlHAlign a)
        {
            Excel.Range range = worksheet.get_Range(worksheet.Cells[iRowStart, iColStart], worksheet.Cells[iRowStart + iRowCount - 1, iColStart + iColCount - 1]);
            range.Merge(true);
            range.Borders.LineStyle = XlLineStyle.xlContinuous;
          
            range.HorizontalAlignment = a;
        }
        /// <summary>
        /// Set text for a cell in excel file
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="strText"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public void InsertTextWithMerge(int iColStart, int iRowStart, string strText, int colCount)
        {
            try
            {
                Excel.Range range = worksheet.get_Range(worksheet.Cells[iRowStart, iColStart], worksheet.Cells[iRowStart, iColStart + colCount - 1]);
                range.Merge(true);
               // range.Borders.LineStyle = XlLineStyle.xlContinuous;

              
 

                worksheet.Cells[iRowStart, iColStart] = strText;

            }
            catch (Exception e) { clsLogFile.LogException(e.Message); };
        }
        public ExcelBase() { }
        public void test()
        {
            Excel.ApplicationClass excel = new Excel.ApplicationClass();

            excel.Visible = true;
        }

        /// <summary>
        /// Format number in range
        /// String format style: "#,##0.00_"
        /// </summary>
        /// <param name="iColStart"></param>
        /// <param name="iRowStart"></param>
        /// <param name="iColEnd"></param>
        /// <param name="iRowEnd"></param>
        /// <param name="data"></param>
        /// <returns>none</returns>
        /// @cond
        /// Author: Nguyen Danh Tho
        /// @endcond
        public void FormatNumber(int iColStart, int iRowStart, int iColEnd, int iRowEnd, string format)
        {
            Excel.Range excRange = GetRange(iColStart, iRowStart, iColEnd, iRowEnd);
            excRange.NumberFormatLocal = format;
        } 
        /// <summary>
        /// Insert new row
        /// </summary>
        /// <param name="iRowStart"></param>
        /// <param name="iRowCount"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
		public void InsertRows(int iRowStart, int iRowCount)
		{
            for (int i = iRowStart; i < iRowStart + iRowCount; i++)
            {
                InsertANewRow(i);
            }
		}

        /// <summary>
        /// Insert a new row
        /// </summary>
        /// <param name="iRowStart"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        private void InsertANewRow(int iRowStart)
        {                
            ((Range)worksheet.Rows[iRowStart,Type.Missing]).Insert(Type.Missing, XlInsertFormatOrigin.xlFormatFromLeftOrAbove);            
        }

        /// <summary>
        /// Save the generated excel file
        /// </summary>
        /// <param name="strFilePath"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public void SaveFileNotAutoFitColumns()
        {
            try
            {
                //worksheet.Columns.AutoFit();
                //worksheet.Rows.AutoFit();
                app.Visible = true;

                //workbook.Saved = true;
                // workbook.SaveCopyAs(m_FilePath);
                ReleaseExcel();
            }
            catch (Exception e)
            {
                clsCommonFunctions.ShowWarningDialog(clsCommonMessages.ALREADY_OPENED);
                clsLogFile.LogException(e.Message);
            }
        }
        public void SaveFileNotAutoFitColumns(bool isOpen)
        {
            try
            {
                worksheet.Rows.AutoFit();
                if (isOpen)
                {
                    app.Visible = true;
                }
                if (!isOpen)
                {
                    ReleaseExcel(isOpen);
                }
            }
            catch (Exception e)
            {
                clsCommonFunctions.ShowWarningDialog(clsCommonMessages.ALREADY_OPENED);
                clsLogFile.LogException(e.Message);
            }
        }

        //2013.05.15 ADD vlhcnhung S [Create Excel Base with new file name is not same template's name]
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="strFilePath"></param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public ExcelBase(string strFilePath, string strTemplateName, string strProjectName, string strNewFileName, ref bool isOpened, string serverDate)
        {
            if (IsOpened(strFilePath))
            {
                isOpened = true;
                return;
            }
            m_ProjectName = strProjectName;
            m_TemplateName = strTemplateName;
            m_FilePath = strFilePath;            
            CreateDoc(true, serverDate, strNewFileName);
        }

        /// <summary>
        /// Initialize File
        /// </summary>
        /// <param name="isTemplate"></param>
        /// <param name="serverDate"></param>
        /// <param name="strNewFileName">New File Name</param>
        /// @cond
        /// Author: vlhcnhung
        /// @endcond
        public void CreateDoc(bool isTemplate, string serverDate, string strNewFileName)
        {
            try
            {
                app = new Microsoft.Office.Interop.Excel.Application();
                //app.ScreenUpdating = false;
                app.ErrorCheckingOptions.NumberAsText = false;

                string path = AppDomain.CurrentDomain.BaseDirectory + m_ProjectName + "_GUI\\REPORT\\TEMPLATE\\";
                clsTemplateManager.Instance().CreateFile(path, m_TemplateName, strNewFileName, serverDate);
                string strFilePath = "";
                if (isTemplate)
                    strFilePath = clsTemplateManager.Instance().FilePath + "\\" + strNewFileName + "_" + serverDate + "_" + ".xls";
                else
                    strFilePath = m_FilePath;


                if (!File.Exists(strFilePath))
                    CreateExcel(strFilePath);
                else
                {
                    workbook = app.Workbooks.Add(strFilePath);
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[1];
                }           
            }
            catch (Exception ex)
            {
                throw new System.ArgumentException(ex.Message);
            }
            finally
            {

            }
        }
        //2013.05.15 ADD vlhcnhung E [Create Excel Base with new file name is not same template's name]

    }
}