﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-01-09 20:37:30 +0700 (Mon, 09 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to provide common string
 * for CPA module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Config.Classes
{
	/// <summary>Define common string used in this project
	/// 
	/// </summary>
	public class clsCommonString
	{
	

		#region SAVE DIALOG
		public const string SAVE_REPORT_TITLE = "Save As...";

		#endregion

		#region CUSTOMER ERROR COLUMN NAME
		public const string COL_CUSTOMER_CODE = "Customer Code";
		public const string COL_CUSTOMER_NAME = "Customer Name";
		public const string COL_MONTH_YEAR = "Month/Year";
		public const string COL_ERROR_TYPE = "Error Type";
		public const string COL_ACCOUNT_OFFICER = "Account_Officer";
		public const string COL_IMPORTED_BY = "Imported by";
		public const string COL_COMPLETE = "Finalized";
		#endregion 

		#region TEMPLATE NAME
		public const string REPORT_ON_CPA_BY_ACCOUNT_OFFICER = "REPORT ON CPA BY ACCOUNT OFFICER.xls";
		public const string REPORT_ON_CPA_BY_ACCOUNT_OFFICER_TOP_20_CUSTOMERS = "REPORT ON CPA BY ACCOUNT OFFICER - TOP 20 CUSTOMERS.xls";
		public const string REPORT_ON_DEPOSIT_AVERAGE_BALANCE_BY_CUSTOMER = "REPORT ON DEPOSIT AVERAGE BALANCE BY CUSTOMER.xls";
		public const string REPORT_ON_LOAN_AVERAGE_BALANCE_BY_CUSTOMER = "REPORT ON LOAN AVERAGE BALANCE BY CUSTOMER.xls";
		public const string REPORT_ON_COMMISSION_AND_FEE_BY_CUSTOMER = "REPORT ON COMMISSION AND FEE BY CUSTOMER.xls";
		public const string REPORT_ON_FOREX_PROFIT_BY_CUSTOMER = "REPORT ON FOREX PROFIT BY CUSTOMER.xls";
		public const string REPORT_ON_TOTAL_PROFIT_BY_CUSTOMER = "REPORT ON TOTAL PROFIT BY CUSTOMER.xls";
		public const string REPORT_ON_DEPOSIT_PROFIT_BY_CUSTOMER = "REPORT ON DEPOSIT PROFIT BY CUSTOMER.xls";
		public const string REPORT_ON_LOAN_PROFIT_BY_CUSTOMER = "REPORT ON LOAN PROFIT BY CUSTOMER.xls";
		public const string REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_DEPOSIT_AVERAGE_BALANCE = "REPORT ON TOP 50 CUSTOMERS IN TERMS OF DEPOSIT AVERAGE BALANCE.xls";
		public const string REPORT_ON_TOP_50_CUSTOMERS_IN_TERMS_OF_LOAN_AVERAGE_BALANCE = "REPORT ON TOP 50 CUSTOMERS IN TERMS OF LOAN AVERAGE BALANCE.xls";
		public const string TOP_50_CUSTOMERS_IN_TERMS_OF_TOTAL_PROFIT = "TOP 50 CUSTOMERS IN TERMS OF TOTAL PROFIT.xls";


		#endregion

		#region OL
		#region FILTER
		public const string FILTER_ACCESS = "Access Files|*.mdb";
		public const string FILTER_EXCEL = "xls Files|*.xls";
		#endregion
		#region STATUS
		public const string APPROVED = "Approved";
		public const string WAITING_FOR_APPROVAL = "Waiting for Approval";
		public const string RETURNED = "Returned";
		#endregion

        #region OL Status
        public const string TRANSFERRED= "Transferred";
        #endregion

        #region OL Type
        public const string SHORT_TERM_VALUE = "1";
        public const string LONG_TERM_VALUE = "2";
        #endregion

        #region MESSAGE
        public const string MARK_OL_FINISH_CONFIRM = "Are you sure you want to mark finish OL?";
		public const string CLOSE_OL_SUCCESSFULLY = "OL was closed successfully";
        public const string CLOSE_OL_UNSUCCESSFULLY = "OL was closed unsuccessfully";
        public const string CANNOT_VIEW_SBV_FILE = "Can not view SBV file";
		#endregion
		#region COMBOBOX ITEM
		public const string SHORT_TERM = "Short Term";
		public const string LONG_TERM = "Long Term";
		#endregion
		#region FORM NAME
		public const string LIST_OF_OUTSTANDING_OL = "List OL";
		public const string OL_LIST_OFFSHORE_LOAN_HISTORY = "List OL History";
		public const string CREATE_NEW_OL = "Create New OL";
		public const string UPDATE_OL = "Update OL";
		public const string TRANSFER_TO_LONG_TERM = "Transfer to long term";
		#endregion
		

		#region REPORT
		#endregion

		
		#endregion

		#region LG
		#region FORM NAME
		public const string OVERDUE_COLLECTION_SCHEDULE = "Overdue Collection Schedule";
		public const string LG_FEE_COLLECTION_SCHEDULE = "LG Fee Collection Schedule";
		#endregion

		#region COLUMN NAME
		public const string COL_RELATED_SUB_CODE_NAME = "colRelatedSubCode";
		#endregion
		#endregion
		#region OL
		public const string R_OL_COL_NO = "No.";
		public const string R_OL_COL_CUS_CODE = "Customer Code";
		public const string R_OL_COL_CUS_NAME = "Customer Name";
		public const string R_OL_COL_CCY = "CCY";
		public const string R_OL_COL_NUMBER_ST = "Number of ST";
		public const string R_OL_COL_PRICIPLE_ST = "Principal Amount (ST)";
		public const string R_OL_COL_NUMBER_LT = "Number of LT";
		public const string R_OL_COL_PRICIPLE_LT = "Principal Amount (LT)";

		#region COLUMN NAME
		public const string COL_ORDERID_NAME = "colOrderID";
		public const string COL_NO_NAME = "colNo";
		public const string COL_CUSTOMER_CODE_NAME = "colCustomerCode";
        public const string COL_CUSTOMER_NAME_NAME = "colCustomerName";
		public const string COL_ACCOUNT_NO_NAME = "colAccountNo";
		public const string COL_PRICIPAL_NAME = "colPrincipal";
		public const string COL_LOADREF_NAME = "colLoanRef";
        public const string COL_LOANREFREPAYMENT_NAME = "colLoanRefRepayment";
		public const string COL_INPUT_DATE_NAME = "colInputDate";
		public const string COL_END_DATE_NAME = "colEndDate";
		public const string COL_BEGIN_DATE_NAME = "colBeginDate";
        public const string COL_MATURITY_DATE_NAME = "colMaturityDate";
        public const string COL_OL_STATUS = "colOLStatus";
        public const string COL_STATUS = "colStatus";
        public const string COL_SMILE_REF = "colSmileRef";
        public const string COL_OL_CLASSIFICATION = "colOLClassification";
        public const string COL_BANK_REF = "colBankRef";
        public const string COL_LENDER = "colLender";
        public const string COL_CCY = "colCcy";
        public const string COL_BALANCE = "colBalance";
        public const string COL_TOTAL_PAID = "colTotalPaid";
        public const string COL_NOTE = "colNote";
		public const string COL_REPAYMENT_REF_NAME = "colRepaymentRef";
		public const string COL_INTEREST_RATE_TYPE = "colInterestRateType";
		public const string COL_INTEREST_AMOUNT = "colInterestAmount";
        public const string COL_OL_TYPE_NAME = "colOLType";
        public const string COL_NUM_EDIT_NAME = "colNumEdit";
        public const string COL_IS_LAST_NAME = "colIsLast";
        public const string COL_SBV_FILE_NAME = "colSBVFile";
        public const string COL_OL_TYPE_REPAYMENT_NAME = "colOLTypeRepayment";
        public const string COL_NUM_EDIT_REPAYMENT_NAME = "colNumEditRepayment";
		public const string LIST_OF_PENDING_FOR_APPROVE = "List Of Pending For Approve";
		public const string CORRECT = "Correct Offshore Loan";
		public const string AMEND = "Amend Offshore Loan";

        public const string FORMAT_DATE = "{0:yyyy/MM/dd}";

        public const string FORMAT_DATE_YYYYMMDD = "yyyy/MM/dd";
		#endregion
		#endregion
	}
}