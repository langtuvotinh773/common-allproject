﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using log4net;

namespace Config.Classes
{
    public sealed class clsLogHelper : ILogService
    {
        readonly ILog _logger;

        static clsLogHelper()
        {
            log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo("REVOLUTION.exe.config"));
        }

        public clsLogHelper(Type type)
        {
            _logger = LogManager.GetLogger(type);
        }

        public void Fatal(string errorMessage)
        {
            if (_logger.IsFatalEnabled)
                _logger.Fatal(errorMessage);
        }

        public void Error(string errorMessage)
        {
            if (_logger.IsErrorEnabled)
                _logger.Error(errorMessage);
        }

        public void Warn(string message)
        {
            if (_logger.IsWarnEnabled)
                _logger.Warn(message);
        }

        public void Info(string message)
        {
            if (_logger.IsInfoEnabled)
                _logger.Info(message);
        }

        public void Debug(string message)
        {
            if (_logger.IsDebugEnabled)
                _logger.Debug(message);
        }

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="message">The message.</param>
        public void LogException(object message)
        {
            // Format filename and write log file
            string FileName = DateTime.Now.ToString("yyyyMMdd");
            log4net.GlobalContext.Properties["FileName"] = FileName;
            log4net.Config.XmlConfigurator.Configure();
            _logger.Error(message);
            // Delete empty log file (if any)
            string emptyFile = @"ErrorLogs\Log_(null).csv";
            if (File.Exists(emptyFile))
            {
                File.Delete(emptyFile);
            }
        }

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="exception">The exception.</param>
        public void LogException(object message, Exception exception)
        {
            // Format filename and write log file
            string FileName = DateTime.Now.ToString("yyyyMMdd-HHmmss");
            log4net.GlobalContext.Properties["FileName"] = FileName;
            log4net.Config.XmlConfigurator.Configure();
            _logger.Error(message, exception);
            // Delete empty log file (if any)
            string emptyFile = @"ErrorLogs\Log_(null).log";
            if (File.Exists(emptyFile))
            {
                File.Delete(emptyFile);
            }
        }
    }
}
