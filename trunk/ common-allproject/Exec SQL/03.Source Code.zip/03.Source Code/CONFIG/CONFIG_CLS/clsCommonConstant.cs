﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
namespace Config.Classes
{
	public static class clsCommonConstant
	{	
		public static string LOAN_PREMATURE_TRE_1 = "LOANPREMATURETRE1";
		public static string LOAN_PREMATURE_TRE_2 = "LOANPREMATURETRE2";
		public static string LOAN_PREMATURE_TRE_3 = "LOANPREMATURETRE3";
		public static string MULTI_TRANSACTION = "Multi transaction";
		public static string MULTI_INTEREST_PAYMENT = "Multi Interest Payment";
		public static string BUTTON = "Button";
		public static string CHECKBOX = "Checkbox";
		public static string CHECK = "Check";
		public static ArrayList INFO_01_LOAN_PRE = new ArrayList(new string[] { "???", "5101000", "Tran Van A", "FXAT0001", "STL", "current date", "11/12/2012", "11/12/2013", "Individual Rate", "0.5", "Detail", "300", "", "", "" });
		public static ArrayList INFO_02_LOAN_PRE = new ArrayList(new string[] { "Created", "5101001", "Tran Van B", "FXAT0002", "LTL", "current date", "11/12/2012", "11/12/2013", "Board Rate", "0.5", "Detail", "500", "", "", "" });
		public static ArrayList INFO_03_LOAN_PRE = new ArrayList(new string[] { "", "5101002", "Tran Van C", "FXAT0003", "TD", "current date", "11/12/2012", "11/12/2013", "Individual Rate", "0.5", "Detail", "500", "", "", "" });
		public static ArrayList INFO_LOAN_PRE = new ArrayList();
		public static ArrayList ARR_TITLE_LOAN_PRE = new ArrayList(new string[] { "Action", "Status", "CIF", "Customer Name", "FXAT Code", "Transaction Type", "Trading Date", "Value Date", "Maturity Date", "Board Rate", "IS", "Multi Transaction", "Amount", "Multi Interest Payment", "Include Margin Cost", "ExcludeMarginCost", "Remark1" });
		public static ArrayList ARR_TITLE_NAME_LOAN_PRE = new ArrayList(new string[] { "Action", "Status", "CIF", "CustomerName", "FXATCode", "TransactionType", "TradingDate", "ValueDate", "MaturityDate", "BoardRate", "IS", "Multi Transaction", "Amount", "MultiInterestPayment", "IncludeMarginCost", "Exclude Margin Cost", "Remark1" });
		public static ArrayList INFO_01_PRINT_DOWN = new ArrayList(new string[] { "Agreed", "5101000", "Tran Van A", "FXAT0001", "STL", "current date", "11/12/2012", "11/12/2013", "Individual Rate", "0.5", "Detail", "300", "", "" });
		public static ArrayList INFO_02_PRINT_DOWN = new ArrayList(new string[] { "Acknowledged", "5101001", "Tran Van B", "FXAT0002", "LTL", "current date", "11/12/2012", "11/12/2013", "Board Rate", "0.5", "Detail", "500", "", "" });
		public static ArrayList INFO_03_PRINT_DOWN = new ArrayList(new string[] { "Agreed", "5101002", "Tran Van C", "FXAT0003", "TD", "current date", "11/12/2012", "11/12/2013", "Individual Rate", "0.5", "Detail", "500", "", "" });
		public static ArrayList ARR_TITLE_NAME_PRINT_DOWN = new ArrayList(new string[] { "Ckeck", "Status", "CIF", "CustomerName", "FXATCode", "TransactionType", "TradingDate", "ValueDate", "MaturityDate", "BoardRate", "IS", "Multi Transaction", "Amount", "Remark1", "Remark2" });
		public static ArrayList INFO_01_LOAN_IS = new ArrayList(new string[] { "Created", "5101000", "Tran Van A", "FXAT0001", "STL", "current date", "11/12/2012", "11/12/2013", "Individual Rate", "0.5", "Detail", "300", "Detail", "", "" });
		public static ArrayList INFO_02_LOAN_IS = new ArrayList(new string[] { "Created", "5101001", "Tran Van B", "FXAT0002", "LTL", "current date", "11/12/2012", "11/12/2013", "Board Rate", "0.5", "Detail", "500", "Detail", "", "" });
		public static ArrayList INFO_03_LOAN_IS = new ArrayList(new string[] { "Created", "5101002", "Tran Van C", "FXAT0003", "TD", "current date", "11/12/2012", "11/12/2013", "Individual Rate", "0.5", "Detail", "500", "Detail", "", "" });
		public static ArrayList ARR_TITLE_LOAN_IS = new ArrayList(new string[] { "Action", "Status", "CIF", "Customer Name", "FXAT Code", "Transaction Type", "Trading Date", "Value Date", "Maturity Date", "Board Rate", "IS", "Multi Transaction", "Amount", "Multi Interest Payment", "Remark 1", "Remark2" });
		public static ArrayList ARR_TITLE_NAME_LOAN_IS = new ArrayList(new string[] { "Action", "Status", "CIF", "CustomerName", "FXATCode", "TransactionType", "TradingDate", "ValueDate", "MaturityDate", "BoardRate", "IS", "Multi Transaction", "Amount", "MultiInterestPayment", "Remark1", "Remark2" });
	}
}
