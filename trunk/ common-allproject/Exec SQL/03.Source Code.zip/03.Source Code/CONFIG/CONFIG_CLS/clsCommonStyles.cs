﻿/*
 * Author:  Quan Nguyen
 * Created: 8-Jan-2013
 * Updated: 10-Jan-2013
 * 
 * This class is used to provide common styles
 * for controls.
 */

using System.Drawing;
using System.Windows.Forms;

namespace Config.Classes
{
    public class clsCommonStyles
    {
        #region Member variables
        private static clsCommonStyles m_Style;

        private Color m_ReadOnlyTextBoxBG;
        private Color m_DefaultTextBoxBG;
        private Color m_LabelBG;
        private Color m_ButtonBG;
        private Color m_ListViewHeaderBG;
        private Color m_FormBG;
        private Color m_DGVColumnHeaderBG;
        private Color m_DGVReadOnlyColumnBG;
        private Color m_DGVRowHeaderBG;

        private DataGridViewCellStyle m_DGVColumnHeaderDefaultStyle;
        private DataGridViewCellStyle m_DGVRowsDefaultCellStyle;
        private DataGridViewCellStyle m_DGVAlternatingRowsDefaultCellStyle;

        #endregion

        #region Properties
        /// <summary>
        /// Gets the background color for read only text box
        /// </summary>
        /// <value>
        /// The read only text box BG.
        /// </value>
        public Color ReadOnlyTextBoxBG 
        {
            get { return m_ReadOnlyTextBoxBG = SystemColors.Control; } 
        }

        /// <summary>
        /// Gets the background color for read only text box
        /// </summary>
        /// <value>
        /// The Default text box BG.
        /// </value>
        public Color DefaultTextBoxBG
        {
            get { return m_DefaultTextBoxBG = SystemColors.Window; }
        }


        /// <summary>
        /// Gets the background color for label
        /// </summary>
        /// <value>
        /// The label BG.
        /// </value>
        public Color LabelBG
        {
			get { return m_LabelBG = System.Drawing.ColorTranslator.FromHtml("#E0DFE3"); ; }
        }

        /// <summary>
        /// Gets the background color for button
        /// </summary>
        /// <value>
        /// The button BG.
        /// </value>
        public Color ButtonBG
        {
            get { return m_ButtonBG = Color.FromArgb(246, 247, 253); }
        }

        /// <summary>
        /// Gets the background color for list view header
        /// </summary>
        /// <value>
        /// The list view header BG.
        /// </value>
        public Color ListViewHeaderBG
        {
            get { return m_ListViewHeaderBG = Color.FromArgb(246, 247, 253); }
        }

        /// <summary>
        /// Gets the background color for form
        /// </summary>
        /// <value>
        /// The form BG.
        /// </value>
        public Color FormBG
        {
            get { return m_FormBG = Color.FromArgb(224, 223, 227); }
        }

        /// <summary>
        /// Gets the background color for header row of datagrid
        /// </summary>
        /// <value>
        /// The header row color of datagrid.
        /// </value>
        public Color DGVColumnHeaderBG
        {
            get { return m_DGVColumnHeaderBG = Color.FromArgb(111, 195, 237); }
        }

        /// <summary>
        /// Gets the background color for disabled column of datagrid
        /// </summary>
        /// <value>
        /// The disabled column color of datagrid.
        /// </value>
        public Color DGVReadOnlyColumnBG
        {
            get { return m_DGVReadOnlyColumnBG = Color.FromArgb(229, 225, 198); }
        }

        /// <summary>
        /// Gets the DGV row header BG.
        /// </summary>
        /// <value>
        /// The DGV row header BG.
        /// </value>
        public Color DGVRowHeaderBG
        {
            get
            {
                return m_DGVRowHeaderBG = Color.FromArgb(231, 238, 243);
            }
        }

        /// <summary>
        /// Gets the DGV column header default cell style.
        /// </summary>
        /// <value>
        /// The DGV column header default cell style.
        /// </value>
        public DataGridViewCellStyle DGVColumnHeaderDefaultCellStyle
        {
            get 
            {
                m_DGVColumnHeaderDefaultStyle = CreateDGVCellStyle(Color.FromArgb(111, 195, 237));
                return m_DGVColumnHeaderDefaultStyle;
            }
        }

        /// <summary>
        /// Gets the DGV rows default cell style.
        /// </summary>
        /// <value>
        /// The DGV rows default cell style.
        /// </value>
        public DataGridViewCellStyle DGVRowsDefaultCellStyle
        {
            get
            {
                m_DGVRowsDefaultCellStyle = CreateDGVCellStyle(Color.White);
                return m_DGVRowsDefaultCellStyle;
            }
        }

        /// <summary>
        /// Gets the DGV alternating rows default cell style.
        /// </summary>
        /// <value>
        /// The DGV alternating rows default cell style.
        /// </value>
        public DataGridViewCellStyle DGVAlternatingRowsDefaultCellStyle
        {
            get
            {
                m_DGVAlternatingRowsDefaultCellStyle = CreateDGVCellStyle(System.Drawing.ColorTranslator.FromHtml(System.Configuration.ConfigurationSettings.AppSettings["AlternatingColor"].ToString()));
                return m_DGVAlternatingRowsDefaultCellStyle;
            }
        }

        /// <summary>
        /// Gets the DGV Selected Row
        /// </summary>
        /// <value>
        /// DGVSelectionBackColor
        /// </value>
        public Color DGVSelectionBackColor
        {
            get
            {
                return Color.SteelBlue;
            }
        }
        #endregion

        #region Singleton method
        /// <summary>
        /// Instances this instance.
        /// </summary>
        /// <returns></returns>
        public static clsCommonStyles Instance()
        {
            if (m_Style == null)
            {
                m_Style = new clsCommonStyles();
            }
            return m_Style;
        }

        /// <summary>
        /// Creates the GV cell style.
        /// </summary>
        /// <param name="bgColor">Color of the bg.</param>
        /// <returns></returns>
        private static DataGridViewCellStyle CreateDGVCellStyle(Color bgColor)
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            style.BackColor = bgColor;
            return style;
        }
        #endregion
    }
}