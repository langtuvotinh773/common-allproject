﻿/*
 * Author:  Quan Nguyen
 * Created: 7-Jan-2013
 * 
 * This class is used to write error log for each exception
 * for CPA module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using log4net;
using DataEncryption;

namespace Config.Classes
{
    public class clsLogFile : ILogService
    {
        private static ILog _logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static string userName = Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["UserLog"].ToString());
        private static string password = Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["LogPassword"].ToString());
        private static string logPath = Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["LogPath"].ToString());
        private static string logDomain = Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["LogDomain"].ToString());

        public clsLogFile()
        {
            //log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo("REVOLUTION.exe.config"));
        }

        public clsLogFile(Type type)
        {
            //_logger = LogManager.GetLogger(type);
        }

        public void Fatal(string errorMessage)
        {
            if (_logger.IsFatalEnabled)
                _logger.Fatal(errorMessage);
        }

        public void Error(string errorMessage)
        {
            if (_logger.IsErrorEnabled)
                _logger.Error(errorMessage);
        }

        public void Warn(string message)
        {
            if (_logger.IsWarnEnabled)
                _logger.Warn(message);
        }

        public void Info(string message)
        {
            if (_logger.IsInfoEnabled)
                _logger.Info(message);
        }

        public void Debug(string message)
        {
            if (_logger.IsDebugEnabled)
                _logger.Debug(message);
        }

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="message">The message.</param>
        public static void LogException(object message)
        {

            using (new CNetworkAuth(userName, logDomain, password))
            {
                log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo("REVOLUTION.exe.config"));
                // Format filename and write log file
                string FileName = DateTime.Now.ToString("yyyyMMdd");
                log4net.GlobalContext.Properties["FileName"] = FileName;
                log4net.Config.XmlConfigurator.Configure();
                _logger.Error(message);
            }
        }

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="exception">The exception.</param>
        public static void LogException(object message, Exception exception)
        {


            log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo("REVOLUTION.exe.config"));
            
            // Format filename and write log file
            string FileName = DateTime.Now.ToString("yyyyMMdd-HHmmss");
            log4net.GlobalContext.Properties["FileName"] = FileName;
            log4net.Config.XmlConfigurator.Configure();
            _logger.Error(message, exception);

        }

        /// <summary>
        /// Log with module
        /// </summary>
        /// <param name="message"></param>
        /// <param name="Module"></param>
        public static void LogException(object message, string Module)
        {

            using (new CNetworkAuth(userName, logDomain, password))
            {
                log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo("REVOLUTION.exe.config"));
                // Format filename and write log file
                string FileName = DateTime.Now.ToString("yyyyMMdd");

                log4net.GlobalContext.Properties["Module"] = Module;
                log4net.GlobalContext.Properties["FileName"] = FileName;
                log4net.GlobalContext.Properties["UserName"] = clsUserInfo.FullName;
                log4net.Config.XmlConfigurator.Configure();
                _logger.Error(message);

            }
        }
    }
}