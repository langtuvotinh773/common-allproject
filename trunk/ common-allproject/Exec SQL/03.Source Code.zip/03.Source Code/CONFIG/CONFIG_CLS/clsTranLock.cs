﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Config.Classes
{
    public class clsTranLock
    {
        private bool m_isLocked = false;
        private int m_LockedBy = -1;
        private int m_DealNo = -1;
        private DateTime m_LockedAt = new DateTime();
        private DateTime m_CurrentSrvTime = new DateTime();

        private const int EXPIRE_TIME = 5;

        public string LockedUserName { get; set; }

        public clsTranLock(clsLockDto dto)
        {
            if (dto.LockedUserName != null)
            {
                m_isLocked = dto.IsLocked;
                m_LockedBy = dto.LockedBy;
                m_LockedAt = dto.LockedAt;
                m_CurrentSrvTime = dto.CurrentServerTime;
                LockedUserName = dto.LockedUserName;    
            }
        }

        private bool IsLockExpired()
        {
            TimeSpan ts = m_CurrentSrvTime.Subtract(m_LockedAt);
            if (ts.Minutes >= 5)
                return true;
            return false;
        }

        public bool CanOpenEditForm()
        {
            if (!m_isLocked)
                return true;
            if (m_isLocked && m_LockedBy == clsUserInfo.UserNo)
                return true;
            if (m_isLocked && m_LockedBy != clsUserInfo.UserNo && IsLockExpired())
                return true;
            return false;
        }

        public clsLockDto GetLockInfo()
        {
            clsLockDto dto = new clsLockDto();
            dto.IsLocked = true;
            dto.LockedBy = clsUserInfo.UserNo;
            dto.LockedAt = DateTime.Now;

            return dto;
        }

        public clsLockDto GetLockInfoAfterTakeAction()
        {
            clsLockDto dto = new clsLockDto();
            dto.IsLocked = false;
            dto.LockedBy = clsUserInfo.UserNo;
            dto.LockedAt = DateTime.Now;

            return dto;
        }

        /// <summary>
        /// Determines whether this instance [can take action].
        /// OK = 0, DataChanged = 1, LockedByOther = -1
        /// </summary>
        /// <returns></returns>
        public int CanTakeAction()
        {
            if (!m_isLocked && m_LockedBy == clsUserInfo.UserNo)
                return 0;
            if (m_isLocked && m_LockedBy == clsUserInfo.UserNo)
                return 0;
            if (m_isLocked && m_LockedBy != clsUserInfo.UserNo && IsLockExpired())
                return 0;
            if (!m_isLocked && m_LockedBy != clsUserInfo.UserNo)
                return 1;
            return -1;
        }
    }

    public class clsLockDto
    {
        public bool IsLocked { get; set; }
        public int LockedBy { get; set; }
        public DateTime LockedAt { get; set; }
        public DateTime CurrentServerTime { get; set; }

        public string LockedUserName { get; set; }
    }
}