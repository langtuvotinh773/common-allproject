﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define common value
 * of Master data module.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Config.Classes
{
	public class CommonValue
	{
		/// <summary>
		/// Action Type
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public enum ActionType : int
		{
            None = 0,
			New = 1,
			Update = 2,
			Delete = 3
		}

		/// <summary>
		/// User Type
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public enum UserType : int
		{
			All = 0,
			JPAcc = 1,
			VNAcc = 2
		}

		/// <summary>
		/// Message Type
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public enum MessageType : int
		{
			Confirm = 0,
			Error = 1,
			Infomaition = 2,
            YesNoConfirm = 3
		}
		//public enum CalculateType : int
		//{

		//}

		public enum LGType : int
		{
			Proper = 1,
			Counter = 2
		}
		public enum LGAction : byte
		{
			NewEntry = 1,
			Correct = 2,
			AmendUpdate = 3,
			Amend = 4,
			CloseTecnique = 5,
			Termination = 6
		}
		/// <summary>
		/// Quotation status
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public enum QuotationStatus : byte
		{
			New = 1,
			WaitForApprove = 2,
			Approved = 3,
			Withdrawn = 4,
			Returned = 5,
			Suspended = 6,
			Obsolete = 7
		}

		/// <summary>
		/// Quotation action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public enum QuotationAction : byte
		{
			Request_to_approve = 1,
			Withdraw = 2,
			Update_free_text = 3,
			Return_Daily_Quotation = 4,
			Approve_Daily_Quotation = 5,
			Revise_Daily_Quotation = 6,
			Preview_Quotation_template = 7,
			Print_Quotation_template = 8,
			Export_Quotation_template_to_excel = 9,
			Inquiry_Quotation_history = 10,
			Import = 11,
			View_Detail = 12,
			Freeze_Daily_Quotation = 13
		}

		/// <summary>
		/// Ceiling / Floor action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public enum CeilingFloorAction : byte
		{
			Create = 1,
			Modify = 2,
			Delete = 3
		}
		/// <summary>
		/// Threshold action
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public enum ThresholdAction: byte
		{
			Create = 1,
			Modify = 2,
			Delete = 3
		}
        /// <summary>
        /// Cut-off Time action
        /// </summary>
        /// @cond
        /// Author: pqkhai
        /// @endcond
        public enum CutoffTimeAction : byte
        {
            Create = 1,
            Modify = 2,
            Delete = 3
        }
		/// <summary>
		/// Quotation Role
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		public enum QuotationRole : byte
		{
			Approver = 1,
			Maker = 2
		}
		/// <summary>
		/// Transaction type
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
        public enum TransactionType : int
        {
            DEPOSIT = 1,
            LOAN = 2,
            FX = 3
        }
        public enum FileType : int
        {
            Excel = 1,
            Macro = 2
        }

        /// <summary>
        /// Import transaction log type: external or not
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public enum ImportTransactionLogType : byte
        {
            ManageTransactionLog = 1,
            ManageExternalLog = 2
        }

 
       
	}
}