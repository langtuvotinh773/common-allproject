﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Config.Classes
{
    public class clsUserInfo
    {
        public static int UserNo;
        public static string UserName;
        public static string FullName;
        public static int DepartmentId;
        public static List<string> DepartmentName;
    }
}
