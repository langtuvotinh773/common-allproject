﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
namespace Config.Classes
{
	public static class clsCommonData
	{
		public static ArrayList arrGLCode = new ArrayList(new string[] { "5141000", "5142000", "5143000" });
		public static ArrayList arrTdTitle = new ArrayList(new string[] { "Transaction No", "CIF", "Customer Name", "Transaction Type", "Value Date", "Final Maturity Date", "CCY", "Amount", "IR", "IS", "Multi Transaction", "Multi Interest Payment", "Status", "Spoken To", "Time", "Remark", "Action", });
		public static ArrayList arrDPDTitle = new ArrayList(new string[] { "Transaction No", "CIF", "Customer Name", "TD No", "Transaction Type", "CCY", "Amount", "Value Date", "Maturity Date", "Board Rate", "IR", "IS", "Multi Transaction", "Multi Interest Payment", "Status" });
		public static ArrayList arrDPDInfo1 = new ArrayList(new string[] { "", "5101000", "Tran Van A", "123456-00", "ST TD", "", "300", "", "", "", "0.6", "0.5", "false", "false", "Created" });
		public static ArrayList arrDPDInfo2 = new ArrayList(new string[] { "", "5101001", "Tran Van B", "123457-00", "LT TD", "", "500", "", "", "", "0.6", "0.5", "false", "false", "Wait IS from TRE" });
		public static ArrayList arrDPDInfo3 = new ArrayList(new string[] { "", "5101002", "Tran Van C", "123458-00", "Loan CI", "", "500", "", "", "", "0.6", "0.5", "false", "false", "IS Quoted" });
		public static ArrayList arrDPDInfo4 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "IS Quoted" });
		public static ArrayList arrDPDInfo5 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "IS Quoted" });
		public static ArrayList arrDPDInfo6 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "Done" });
		public static ArrayList arrDPDInfo7 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "Acknolwedged" });
		public static ArrayList arrDPDInfo8 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "Requested to cancel" });
		public static ArrayList arrDPDInfo9 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "Agreed to cancel" });
		public static ArrayList arrDPDInfo10 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "Cancelled" });
		public static ArrayList arrDPDDetailTitle = new ArrayList(new string[] { "No.", "Start", "End" });
		public static ArrayList arrDPDDetailInfo1 = new ArrayList(new string[] { "1st", "", "" });
		public static ArrayList arrDPDDetailInfo2 = new ArrayList(new string[] { "2st", "", "" });
		public static ArrayList arrDPDDetailInfo3 = new ArrayList(new string[] { "3st", "", "" });
		public static ArrayList arrInfoTD01 = new ArrayList(new string[] { "10001", "5101000", "Tran Van A", "STL", "", "", "", "300", "", "", "false", "false", "Created", "Tran Thi C", "11/12/2012 10:10", "", "Request I/S" });
		public static ArrayList arrInfoTD02 = new ArrayList(new string[] { "10002", "5101001", "Tran Van B", "TD", "", "", "", "500", "", "", "false", "false", "Wait IS from TRE", "Tran Thi C", "11/12/2012 10:10", "", "Withdraw" });
		public static ArrayList arrInfoTD03 = new ArrayList(new string[] { "10003", "5101002", "Tran Van C", "LTL", "", "", "", "500", "0.6", "0.5", "false", "false", "IS Quoted", "Tran Thi C", "11/12/2012 10:10", "", "Done" });
		public static ArrayList arrInfoTD04 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "Done", "", "", "", "Copy" });
		public static ArrayList arrInfoTD05 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "Acknolwedged", "", "", "", "Request To Cancel" });
		public static ArrayList arrInfoTD06 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "Requested to cancel", "", "", "", "Done Cancellation" });
		public static ArrayList arrInfoTD07 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "Agreed to cancel", "", "", "", "View Detail" });
		public static ArrayList arrInfoTD08 = new ArrayList(new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "Cancelled", "", "", "", "" });

		public static ArrayList arrDPDIODInputTitle = new ArrayList(new string[] { "Buying Amount", "Selling Amount" });
		public static ArrayList arrDPDIODInputInfo1 = new ArrayList(new string[] { "10", "" });
		public static ArrayList arrDPDIODInputInfo2 = new ArrayList(new string[] { "5", "" });
		public static ArrayList arrDPDIODInputInfo3 = new ArrayList(new string[] { "", "" });
		public static ArrayList arrDPDIODInputInfo4 = new ArrayList(new string[] { "", "" });

		public static ArrayList arrTREClerkFXSTPTitle = new ArrayList(new string[] { "TRANS. NO", "CIF CODE", "CUST. NAME", "FXAT CODE", "DR ACC", "SETTLEMENT DEPT.", "VALUE", "MATURITY", "BANK BUY-SELL", "BUYING AMT", "SELLING AMT", "Fixed 2 CCY", "IS", "ER", "PRIORITY", "MULTI-TRANS", "STATUS", "INDICATOR", "REMARK", "CONTRACT NO", "ACTIONS" });
		public static ArrayList arrTREClerkFXSTPInfo01 = new ArrayList(new string[] { "", "", "", "", "", "DPD", "TODAY", "", "", "", "", "s", "0.5", "0.8", "URGENT", "", "DONE", "APPLICATION TO FOLLOW", "", "N/A", "AGREE, NOT AGREE, VIEW FX DETAIL" });
		public static ArrayList arrTREClerkFXSTPInfo02 = new ArrayList(new string[] { "", "", "", "", "", "DPD", "TODAY", "", "", "", "", "No", "0.5", "0.8", "URGENT", "", "DONE", "ROUGH FIGURE", "", "N/A", "AGREE, NOT AGREE, VIEW FX DETAIL" });
		public static ArrayList arrTREClerkFXSTPInfo03 = new ArrayList(new string[] { "", "", "", "", "", "DPD", "TODAY", "", "", "", "", "Yes", "0.5", "0.8", "URGENT", "", "DONE", "AMT UPDATED", "", "N/A", "AGREE, NOT AGREE, VIEW FX DETAIL" });
		public static ArrayList arrTREClerkFXSTPInfo04 = new ArrayList(new string[] { "", "", "", "", "", "DPD", "TODAY", "", "", "", "", "Yes", "0.5", "0.8", "URGENT", "", "REQUESTED FOR CANCELLATION", "", "", "N/A", "REPLY PROFIT/LOSS, VIEW FX DETAIL" });
		public static ArrayList arrTREClerkFXSTPInfo05 = new ArrayList(new string[] { "", "", "", "", "", "DPD", "TODAY", "", "", "", "", "Yes", "0.5", "0.8", "URGENT", "", "CANCELLATION DONE", "", "", "N/A", "AGREE FOR CANCELLATION, VIEW FX DETAIL" });
		public static ArrayList arrTREClerkFXSTPInfo06 = new ArrayList(new string[] { "", "", "", "", "", "CBD", "<>TODAY", "", "", "", "", "Yes", "0.5", "0.8", "URGENT", "", "CANCELLED", "", "", "N/A", "" });
		public static ArrayList arrTREClerkFXSTPInfo07 = new ArrayList(new string[] { "", "", "", "", "", "CBD", "<>TODAY", "", "", "", "", "Yes", "0.5", "0.8", "URGENT", "", "RETURNED (BY TLAD)", "", "", "N/A", "UPDATE CONTRACT NO, VIEW FX DETAIL" });

		public static ArrayList arrTREClerkFXSTPDoneTitle = new ArrayList(new string[] { "NO", "TRANS. NO", "CIF CODE", "CUST. NAME", "FXAT CODE", "DR ACC", "SETTLEMENT DEPT.", "VALUE", "MATURITY", "BANK BUY-SELL", "BUYING AMT", "SELLING AMT", "Fixed 2 CCY", "IS", "ER", "PRIORITY", "MULTI-TRANS", "STATUS", "FX-CONFIRMATION", "INDICATOR", "REMARK", "CONTRACT NO", "ACTIONS" });
		public static ArrayList arrTREClerkFXSTPDoneInfo01 = new ArrayList(new string[] { "", "", "", "", "", "", "DPD", "", "", "", "", "", "Yes", "0.5", "0.8", "TOP URGENT", "", "NO", "AGREED", "", "", "", "PRINT DEALING SHEET, DOWNLOAD FXAT MACRO, VIEW FX DETAIL, UPDATE CONTRACT NO" });
		public static ArrayList arrTREClerkFXSTPDoneInfo02 = new ArrayList(new string[] { "", "", "", "", "", "", "CBD", "", "", "", "", "", "No", "0.5", "0.8", "URGENT", "", "NO", "AGREED", "", "", "", "PRINT DEALING SHEET, DOWNLOAD FXAT MACRO, VIEW FX DETAIL, UPDATE CONTRACT NO" });
		public static ArrayList arrTREClerkFXSTPDoneInfo03 = new ArrayList(new string[] { "", "", "", "", "", "", "DPD", "", "", "", "", "", "Yes", "", "", "URGENT", "", "YES", "APPROVED (BY TRE SUPERVISOR)", "", "", "YES", "PRINT DEALING SHEET, VIEW FX DETAIL" });
		public static ArrayList arrTREClerkFXSTPDoneInfo04 = new ArrayList(new string[] { "", "", "", "", "", "", "IOD", "", "", "", "", "", "No", "", "", "NORMAL", "", "YES", "APPROVED (BY TLAD)", "", "", "YES", "PRINT DEALING SHEET, VIEW FX DETAIL" });
	};
}