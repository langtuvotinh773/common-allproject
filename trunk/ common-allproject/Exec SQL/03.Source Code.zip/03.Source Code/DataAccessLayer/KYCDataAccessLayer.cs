using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;
using DataEncryption;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class KYCDataAccessClass
	{
		//variables for DataBase
		public static OleDbConnection _connection = null;
		public static SqlConnection _sqlConnection = null;
		public static string _sConnectStr = "";				
		public static string _path = "";
        public static string _typeDB = "";
        //SQL Server
        public static string _id = "";
        public static string _pwd = "";
        public static string _db = "";
		
		//
		public static int _database;
		private enum _databaseType {
			OleDb,
			Sql,
		};

		#region constructor to load settings from file xml
        public static void getDataFromXML()
        {
            //can't find DataBase.config
            if (!File.Exists(@"./settings/DataBaseKYC.config"))
            {
                _typeDB = "SQLServer";
                _path = "150.40.1.17";
                _id = "admin";
                _pwd = "admin123";
                //_db = "KYC_HCM_DB_Actimize";

                writeDataBaseXML();
                getDataFromXML();               
            }

            DataSet _ds = new DataSet();
            _ds.ReadXml(@"./settings/DataBaseKYC.config");
            DataRow _row = _ds.Tables["database"].Rows[0];
            _typeDB = _row["typeDB"].ToString();
            _typeDB = Encryption.decrypt(_typeDB);
            _path = _row["path"].ToString();
            _path = Encryption.decrypt(_path);
        }
        
        public static void loadDataBaseSettings()
		{
			//load settings
			try
			{
                getDataFromXML();

                if ("Access".Equals(_typeDB))//Access
                {
                    if (File.Exists(_path))
                    {
                        if (Path.GetExtension(_path) == ".mdb")
                        {
                            _sConnectStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data source=" + _path;
                            _database = (int)_databaseType.OleDb;
                        }
                    }
                    else
                    {
                        MessageBox.Show("DatabaseKYC configuration is wrong!");
                        return;
                    }
                }
                else if ("SQLServer".Equals(_typeDB))
                {
                    DataSet _ds = new DataSet();
                    _ds.ReadXml(@"./settings/DataBaseKYC.config");
                    DataRow _row = _ds.Tables["database"].Rows[0];

                    _id = _row["uid"].ToString();
                    _id = Encryption.decrypt(_id);
                    _pwd = _row["pwd"].ToString();
                    _pwd = Encryption.decrypt(_pwd);
                    _db = _row["name"].ToString();
                    _db = Encryption.decrypt(_db);
                    if (_path.Trim() != "")//SQL
                    {
                        //_sConnectStr = "Server=" + _path + ";uid=" + _id + ";pwd=" + _pwd + ";database=" + _db;

                        _sConnectStr = "User ID=" + _id + ";Data Source=" + _path +
                        ";Password=" + _pwd + ";Initial Catalog=" + _db + ";Persist Security Info=True;Packet Size=4096";
                        _database = (int)_databaseType.Sql;
                    }
                }			
			}
			catch(Exception ex)
			{
                MessageBox.Show(ex.Message);
			}				
		}
		#endregion

		#region write settings into xml file
		//DataBase settings file
		public static void writeDataBaseXML()
		{
            _typeDB = Encryption.encrypt(_typeDB);
            _path = Encryption.encrypt(_path);
            _id = Encryption.encrypt(_id);
            _pwd = Encryption.encrypt(_pwd);
            _db = Encryption.encrypt(_db);
            try
			{
				// Error reading config file. Create and save new file.
				string xmlFrag = "<?xml version=\"1.0\" standalone=\"yes\"?>\n" +
					"<configuration>\n" +
                    "   <database typeDB=\"" + _typeDB + "\" path=\"" + _path + "\" uid=\"" + _id + "\" pwd=\"" + _pwd + "\" name=\"" + _db + "\" />\n" +
					"</configuration>";
				//create folder settings
				Directory.CreateDirectory("settings");
				StreamWriter writer = new StreamWriter(@"./settings/DataBaseKYC.config");
				writer.WriteLine (xmlFrag);
				writer.Flush();
				writer.Close();
			}
			catch
			{
				MessageBox.Show("Can't create DataBaseKYC.config");
			}			
		}
		//overload version
		public static void writeDataBaseXML(string _type, string _ip,string _uid,string _pwd,string _name)
		{           
            
            try
			{
				// Error reading config file. Create and save new file.
				string xmlFrag = "<?xml version=\"1.0\" standalone=\"yes\"?>\n" +
					"<configuration>\n" +
                    "   <database typeDB=\"" + _type + "\" path=\"" + _ip + "\" uid=\"" + _uid + "\" pwd=\"" + _pwd + "\" name=\"" + _name + "\" />\n" +
					"</configuration>";
				//create folder settings
				Directory.CreateDirectory("settings");
				StreamWriter writer = new StreamWriter(@"./settings/DataBaseKYC.config");
				writer.WriteLine (xmlFrag);
				writer.Flush();
				writer.Close();
			}
			catch
			{
				MessageBox.Show("Can't create DataBaseKYC.config");
			}			
		}		
		#endregion

		#region common method for accessing databse
		//create connection to DataBase
		public static void makeConnection()
		{				
			if (_database == (int)_databaseType.OleDb)
			{
				if (_connection == null)
				{
					_connection = new OleDbConnection(_sConnectStr);
				}				
			}
			else if (_database == (int)_databaseType.Sql)
			{
				if (_sqlConnection == null)
				{
					_sqlConnection = new SqlConnection(_sConnectStr);
				}				
			}
		}//end makeConnection
		//this method takes query string as argument and returns an dataset		
		public static DataSet datasetQuery(string theQuery)
		{
			makeConnection();
			//declare ds object of DataSet class
			DataSet ds=new DataSet();
			if (_database == (int)_databaseType.OleDb)
			{
				try
				{
					if (_connection.State == ConnectionState.Closed)
					{
						//open connection
						_connection.Open();
					}					
					//declare command object and pass theQuery,connection as arguments
					OleDbCommand command=new OleDbCommand(theQuery,_connection);
					//declare da object of SqlDataAdapter class
					OleDbDataAdapter da=new OleDbDataAdapter();
					da.SelectCommand=command;				
					//execute query and fill into the DataSet
					da.Fill(ds);
				}
				catch (OleDbException e)
				{
					MessageBox.Show(e.Message);	
				}
				finally
				{
					_connection.Close();
				}
			}
			else if (_database == (int)_databaseType.Sql)
			{
				try
				{
					if (_sqlConnection.State == ConnectionState.Closed)
					{
						//open connection
						_sqlConnection.Open();
					}					
					//declare command object and pass theQuery,connection as arguments
					SqlCommand command=new SqlCommand(theQuery,_sqlConnection);
					//declare da object of SqlDataAdapter class
					SqlDataAdapter da=new SqlDataAdapter();
					da.SelectCommand=command;				
					//execute query and fill into the DataSet
					da.Fill(ds);
				}
				catch (SqlException e)
				{
					MessageBox.Show(e.Message);	
				}
				finally
				{
					_sqlConnection.Close();
				}
			}
			//return dataset value
			return ds;
		}//end datasetQuery
		//this method get the Query as parameter 
		//and return integer (no of rows are modified)
		//use in Select,Insert,Update to DataBase
		public static int sqlOperation(string theSQL)
		{
			makeConnection();
			int row = 0;
			if (_database == (int)_databaseType.OleDb)
			{
				try
				{
					if (_connection.State == ConnectionState.Closed)
					{
						//open connection
						_connection.Open();
					}
					OleDbCommand command=new OleDbCommand(theSQL,_connection);
					row=command.ExecuteNonQuery();
				}
				catch (OleDbException e)			
				{
					MessageBox.Show(e.Message);
				}
				finally
				{
					_connection.Close();
				}			
			}
			else if (_database == (int)_databaseType.Sql)
			{
				try
				{
					if (_sqlConnection.State == ConnectionState.Closed)
					{
						//open connection
						_sqlConnection.Open();
					}
					SqlCommand command=new SqlCommand(theSQL,_sqlConnection);
					row=command.ExecuteNonQuery();
				}
				catch (SqlException e)			
				{
					MessageBox.Show(e.Message);
				}
				finally
				{
					_sqlConnection.Close();
				}			
			}			
			return row;
		}//end sqlOperation		
		//this method use for OledbDataReader
		public static OleDbDataReader dataReaderOleDB(string theSQL)
		{
			//make connection to database
			makeConnection();
			//declare DataReader
			OleDbDataReader reader = null;
			try
			{
				if (_connection.State == ConnectionState.Closed)
				{
					//open connection
					_connection.Open();
				}
				//declare and initialize command object
				OleDbCommand command=new OleDbCommand(theSQL,_connection);
				//result variable is returned for the function
				//we must close the connection when using SqlDataReader for executing query
				reader=command.ExecuteReader();
			}
			catch (OleDbException e)
			{
				MessageBox.Show(e.Message);
			}
			return reader;
		}//end query
		//this method use for SqlDataReader
		public static SqlDataReader dataReaderSQL(string theSQL)
		{
			//make connection to database
			makeConnection();			
			//declare DataReader
			SqlDataReader reader = null;
			try
			{
				if (_sqlConnection.State == ConnectionState.Closed)
				{
					//open connection
					_sqlConnection.Open();
				}
				//declare and initialize command object
				SqlCommand command=new SqlCommand(theSQL,_sqlConnection);
				//result variable is returned for the function
				//we must close the connection when using SqlDataReader for executing query
				reader=command.ExecuteReader();
			}
			catch (SqlException e)
			{
				MessageBox.Show(e.Message);
			}	
			return reader;		
		}//end query		
		#endregion

	}//end class
}
