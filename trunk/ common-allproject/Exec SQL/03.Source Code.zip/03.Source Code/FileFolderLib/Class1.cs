﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


namespace FileFolderLib
{
    public class GetFolderPathOrFilePath
    {

        public static string BrowserFolder()
        {
            try
            {
                string folderPath = "";
                FolderBrowserDialog a1 = new FolderBrowserDialog();
                if (a1.ShowDialog() == DialogResult.OK)
                {

                    folderPath = a1.SelectedPath;

                }
                return folderPath;


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static string BrowserFilePath(string folderPath, string filter)
        {
            try
            {

                string filePath = "";
                OpenFileDialog a1 = new OpenFileDialog();
                a1.Filter = filter;
                if (Directory.Exists(folderPath) == true)
                {
                    a1.InitialDirectory = folderPath;
                }
                if (a1.ShowDialog() == DialogResult.OK)
                {
                    filePath = a1.FileName;
                }
                return filePath;


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

    }
}
