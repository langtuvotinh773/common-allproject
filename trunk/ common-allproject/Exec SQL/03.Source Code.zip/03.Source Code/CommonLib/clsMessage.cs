﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CommonLib
{
    public class clsMessage
    {
        public static void ShowError(String content)
        {
            MessageBox.Show(content, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        public static void ShowWarning(String content)
        {
            MessageBox.Show(content, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        public static void ShowInformation(String content)
        {
            MessageBox.Show(content, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public static DialogResult ShowQuestion(String content)
        {
            return MessageBox.Show(content, "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
        }
    }
}
