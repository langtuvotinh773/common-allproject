﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CommonLib
{
    public class CommonClass
    {
        #region change symbol , to .
        public static string changeSymbolComma(string _str)
        {
            return _str.Replace(',', '.');
        }
        #endregion

        #region validate bad symbols
        static char[] _arrSymbols = {'\'','"','!','#','$','%','^','&',
										'(',')','-','+','=','|',';',':','<','>',
										'?','~','`','{','}','[',']','@'};
        public static int validateBadSymbols(string _str)
        {
            if (_str.IndexOfAny(_arrSymbols) != -1)
            {
                return 1;
            }
            return 0;
        }

        public static int validateBadSymbolsOnTextBox(System.Windows.Forms.Control _frmControl)
        {
            foreach (Control txt in _frmControl.Controls)
            {
                if (txt.GetType() == typeof(System.Windows.Forms.TextBox))
                {
                    if (validateBadSymbols(txt.Text.Trim()) == 1)
                    {
                        string _strSymbols = "";
                        for (int i = 0; i < _arrSymbols.Length; i++)
                        {
                            _strSymbols += _arrSymbols[i].ToString();
                        }
                        MessageBox.Show("Cannot input below characters : " + _strSymbols);
                        return 1;
                    }
                }
            }
            return 0;
        }

        //new version
        static char[] _arrSymbols1 = { '\'' };
        public static int validateBadSymbolsStr(string _str)
        {
            if (_str.IndexOfAny(_arrSymbols1) != -1)
            {
                return 1;
            }
            return 0;
        }

        public static int validateBadSymbols(System.Windows.Forms.Control _frmControl)
        {
            foreach (Control txt in _frmControl.Controls)
            {
                if (txt.GetType() == typeof(System.Windows.Forms.TextBox))
                {
                    if (validateBadSymbolsStr(txt.Text.Trim()) == 1)
                    {
                        string _strSymbols = "";
                        for (int i = 0; i < _arrSymbols1.Length; i++)
                        {
                            _strSymbols += _arrSymbols1[i].ToString();
                        }
                        MessageBox.Show("Cannot input below characters : " + _strSymbols);
                        return 1;
                    }
                }
            }

            foreach (Control cb in _frmControl.Controls)
            {
                if (cb.GetType() == typeof(System.Windows.Forms.ComboBox))
                {
                    if (validateBadSymbolsStr(cb.Text.Trim()) == 1)
                    {
                        string _strSymbols = "";
                        for (int i = 0; i < _arrSymbols1.Length; i++)
                        {
                            _strSymbols += _arrSymbols1[i].ToString();
                        }
                        MessageBox.Show("Cannot input below characters : " + _strSymbols);
                        return 1;
                    }
                }
            }

            #region on group
            foreach (Control grp in _frmControl.Controls)
            {

                foreach (Control txt in grp.Controls)
                {
                    if (txt.GetType() == typeof(System.Windows.Forms.TextBox))
                    {
                        if (validateBadSymbolsStr(txt.Text.Trim()) == 1)
                        {
                            string _strSymbols = "";
                            for (int i = 0; i < _arrSymbols1.Length; i++)
                            {
                                _strSymbols += _arrSymbols1[i].ToString();
                            }
                            MessageBox.Show("Cannot input below characters : " + _strSymbols);
                            return 1;
                        }
                    }
                }

                foreach (Control cb in grp.Controls)
                {
                    if (cb.GetType() == typeof(System.Windows.Forms.ComboBox))
                    {
                        if (validateBadSymbolsStr(cb.Text.Trim()) == 1)
                        {
                            string _strSymbols = "";
                            for (int i = 0; i < _arrSymbols1.Length; i++)
                            {
                                _strSymbols += _arrSymbols1[i].ToString();
                            }
                            MessageBox.Show("Cannot input below characters : " + _strSymbols);
                            return 1;
                        }
                    }
                }

            }
            #endregion

            return 0;
        }
        #endregion

        #region change symbol ' to ''
        public static string changeSymbolQuote(string _str)
        {
            return _str.Replace("'", "''");
        }

        public static void changeSymbolQuoteOnForm(System.Windows.Forms.Control _frmControl)
        {
            foreach (Control txt in _frmControl.Controls)
            {
                if (txt.GetType() == typeof(System.Windows.Forms.TextBox))
                {
                    txt.Text = txt.Text.Replace("'", "''");
                }
            }
        }
        #endregion

        #region auto complete
        public static void AutoComplete(ComboBox cb, System.Windows.Forms.KeyPressEventArgs e)
        {
            AutoComplete(cb, e, false);
        }

        public static void AutoComplete(ComboBox cb, System.Windows.Forms.KeyPressEventArgs e, bool blnLimitToList)
        {
            string strFindStr = "";

            if (e.KeyChar == (char)8)
            {
                if (cb.SelectionStart <= 1)
                {
                    cb.Text = "";
                    return;
                }

                if (cb.SelectionLength == 0)
                    strFindStr = cb.Text.Substring(0, cb.Text.Length - 1);
                else
                    strFindStr = cb.Text.Substring(0, cb.SelectionStart - 1);
            }
            else
            {
                if (cb.SelectionLength == 0)
                    strFindStr = cb.Text + e.KeyChar;
                else
                    strFindStr = cb.Text.Substring(0, cb.SelectionStart) + e.KeyChar;
            }

            int intIdx = -1;

            // Search the string in the ComboBox list.

            intIdx = cb.FindString(strFindStr);

            if (intIdx != -1)
            {
                cb.SelectedText = "";
                cb.SelectedIndex = intIdx;
                cb.SelectionStart = strFindStr.Length;
                cb.SelectionLength = cb.Text.Length;
                e.Handled = true;
            }
            else
            {
                e.Handled = blnLimitToList;
            }
        }
        #endregion
    }
}