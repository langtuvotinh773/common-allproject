﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using DataAccessLayer;

namespace CommonLib
{
    public static class FlagAction
    {
        public static String _INSERT = "INSERT";
        public static String _UPDATE = "UPDATE";
        public static String _DELETE = "DELETE";
    }
    public class clsIrrLogAction
    {
        public static void insertLog(String UserName,String Screen, String RecordID, String Action, String Data)
        {
            String _query = "insert into IrrLogAction([UserName],[Date],[Screen],[RecordID],[Action],[Data]) values('" + Utility.GetInsertStrFromStr(UserName) + "','" + DateTime.Now + "','" + Utility.GetInsertStrFromStr(Screen) + "','" + Utility.GetInsertStrFromStr(RecordID) + "','" + Utility.GetInsertStrFromStr(Action) + "','" + Utility.GetInsertStrFromStr(Data) + "')";
            DataAccessClass.sqlOperation(_query);
        }
    }
}
