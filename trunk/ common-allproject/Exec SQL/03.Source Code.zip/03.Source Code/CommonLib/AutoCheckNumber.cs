﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
namespace CommonLib
{
    public partial class AutoCheckNumber : TextBox
    {
        private String _TEXT = "";

        public AutoCheckNumber()
        {
            InitializeComponent();
        }

        [DefaultValue("0.00"), Description(""), Browsable(true),
         DesignerSerializationVisibility(DesignerSerializationVisibility.Visible),
         Category("AutoCheckNumber"), Bindable(true)]
        public override string Text
        {
            get { return base.Text; }
            set
            {
                try
                {
                    if (value == "")
                    {
                        value = "0";
                    }
                    double _dou = double.Parse(value);
                    if (_dou == 0)
                        _TEXT = "0";
                    else
                        _TEXT = _dou.ToString("#,#.00", CultureInfo.InvariantCulture);
                    base.Text = _TEXT;
                }
                catch (System.Exception ex)
                {
                }
            }
        }

        protected override void OnLeave( EventArgs e)
        {
            string _str = this.Text.Trim();
            if ("".Equals(_str))
            { 
                _str = "0";
            }
            try
            {
                double _dou = double.Parse(_str);
                if (_dou == 0)
                    this.Text = "0";
                else
                    this.Text = _dou.ToString("#,#.00", CultureInfo.InvariantCulture);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Wrong number format");
                this.Focus();
            }
            base.OnLeave(e);

        }
    }
}
