﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using DataAccessLayer;
using CommonLib;
//using BTMU_HCM_Lib;
using System.Data;
using System.Windows.Forms;
namespace CommonLib
{
    public class Utility
    {
        public static void enableButtonAfterCheckRigh(Button button)
        {
            object allowUpdate = button.Tag;
            if (allowUpdate != null && (bool)allowUpdate)
            {
                button.Enabled = true;
            }
        }
        public static String convertYYMMDDToNormalDateFormat(String data)
        {
            int year = int.Parse("20" + data.Substring(0, 2));
            int month = int.Parse(data.Substring(2, 2));
            int day = int.Parse(data.Substring(4, 2));
            DateTime date = new DateTime(year, month, day);
            return date.ToString("dd-MMM-yyyy");
        }
        public static Decimal getTruncatAmountBaseOnCcy(String Ccy, Decimal Amount)
        {
            switch (Ccy)
            {
                case "VND":
                    return Amount / (decimal)1000000;
                default:
                    return Amount / (decimal)1000;
            }
        }
        public static String getFirstCharacter(String data)
        {
            if (data.Length > 0)
                return data.Substring(0, 1);
            return "";
        }
        public static string GetInsertStrFromStrForUnicodeStrInSQL(string strInsert)
        {
            strInsert = strInsert.Replace("'", "''");
            //strInsert = "N'" + strInsert + "'";
            strInsert = strInsert.Trim();
            return strInsert;

        }
        public static string GetInsertStrFromStr(string strInsert)
        {
            strInsert = strInsert.Replace("'", "''");
            //strInsert = "'" + strInsert + "'";
            strInsert = strInsert.Trim();
            return strInsert;

        }
        public static String GetDateTimeStringforSQL(string strInsert)
        {
            if (strInsert == "" || strInsert == "NULL")
                return "NULL";

            return "'" + strInsert + "'";
        }
        public static Boolean contactCharacter(String _id)
        {
            for (int i = 0; i < _id.Length; i++)
            {
                if (_id[i] > '9' || _id[i] < '0')
                    return true;
            }
            return false;
        }
        public static String getReplaceData(String _code)
        {
            String result = "Replace(dbo.replaceSeparateString(" + _code + "),'" + DefineValue.SEPARATECHARACTER_CHARGE + DefineValue.SEPARATECHARACTER_CHARGE + "','"
                + DefineValue.SEPARATECHARACTER_CHARGE + "')";
            result = "Replace(" + result + ",'" + DefineValue.SEPARATECHARACTER_CHARGE + DefineValue.SEPARATECHARACTER_CHARGE + "','"
                + DefineValue.SEPARATECHARACTER_CHARGE + "')";
            result = "Replace(" + result + ",'" + DefineValue.SEPARATECHARACTER_CHARGE + "','\n\n') as " + _code;
            
            return result;
        }

        public static void separateChargeType(String sr, ref String dpdCharge, ref String iodCharge, ref String fxCharge, ref String otherCharge)
        {
            String[] arr = sr.Split(new String[] { DefineValue.SEPARATECHARACTER_CHARGE }, StringSplitOptions.None);
            if (arr.Length >= 1)
                dpdCharge = arr[0];
            if (arr.Length >= 2)
                iodCharge = arr[1];
            if (arr.Length >= 3)
                fxCharge = arr[2];
            if (arr.Length >= 4)
                otherCharge = arr[3];
        }
        public static String combineChargeType(String dpdCharge, String iodCharge, String fxCharge, String otherCharge)
        {
            String strResult = "";
            strResult = dpdCharge;
            strResult += DefineValue.SEPARATECHARACTER_CHARGE;
            strResult += iodCharge;
            strResult += DefineValue.SEPARATECHARACTER_CHARGE;
            strResult += fxCharge;
            strResult += DefineValue.SEPARATECHARACTER_CHARGE;
            strResult += otherCharge;

            return strResult;
        }
        public static String addQuotationMarks(String source)
        {
            if (source == "NULL")
            {
                return source;
            }
            else {
                return "'" + source + "'";
            }

        }
        public static String convertNULLToBlank(String source)
        {
            if (source == "NULL")
            {
                return "";
            }
            return source;
        }
        
        #region variables
        public static Excel.Application oXL;
        public static Excel.Workbooks oWBs;
        public static Excel._Workbook oWB;
        public static Excel._Worksheet oSheet;

        public static string _query = "";
        public static DataSet _ds = null;
        public static DataRow[] _dr = null;
        public static DataRow _row = null;
        #endregion
        #region open Excel
        public static void openExcel(string _path, string _sheet)
        {
            try
            {
                //Start Excel and get Application object.
                oXL = new Excel.Application();
                //default is true
                oXL.Visible = true;

                //open Excel file
                oWBs = oXL.Workbooks;
                _path = Application.StartupPath + _path;
                oWB = oWBs.Open(_path,
                                            0,
                                            true,
                                            5,
                                            "",
                                            "",
                                            true,
                                            Excel.XlPlatform.xlWindows,
                                            "\t",
                                            false,
                                            false,
                                            0,
                                            true,
                                            1,
                                            0);

                //Make sure Excel is visible and give the user control
                //of Microsoft Excel's lifetime.
                //default is true
                oXL.Visible = true;
                //default is true
                oXL.UserControl = true;

                //open worksheet
                oSheet = (Excel._Worksheet)oWB.Sheets[_sheet];
            }
            catch (Exception theException)
            {
                String errorMessage;
                errorMessage = "Error: ";
                errorMessage = String.Concat(errorMessage, theException.Message);
                errorMessage = String.Concat(errorMessage, " Line: ");
                errorMessage = String.Concat(errorMessage, theException.Source);

                MessageBox.Show(errorMessage, "Error");
            }
        }
        #endregion
        #region export to Excel
        public static void writeDataToCell(String _data, int rIdx, int cIdx)
        {
            oSheet.Cells[rIdx, cIdx] = _data;
        }
        public static void exportToExcel(DataSet _ds, int rIdx, int cIdx)
        {
            foreach (DataRow row in _ds.Tables[0].Rows)
            {
                rIdx++;
                cIdx = 1;
                foreach (DataColumn col in _ds.Tables[0].Columns)
                {
                    oSheet.Cells[rIdx, cIdx] = row[col.ColumnName].ToString().Trim();
                    cIdx++;
                }
            }
        }
        #endregion
    }
    public class DefineValue
    {
        public static String SEPARATECHARACTER_CHARGE = "#hts#";
    }
    public class clsConvert
    {
        public static String convertToDateTimeString(String data)
        {
            if (data.Length != 8)
            {
                return null;
            }

            DateTime date = new DateTime(int.Parse(data.Substring(0,4)),int.Parse(data.Substring(4,2)), int.Parse(data.Substring(6,2)));
            return date.ToString("dd/MMM/yyyy");

        }

        public static String convertToCurrencyAccount(String data)
        {
            if (data.Length != 6)
            {
                return ("000000" + data).Substring(data.Length, 6);
            }
            return data;
        }
    }
    public enum StateAction { 
        INSERT,
        UPDATE,
        DELETE,
        NOTHING
    }
}
