﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: HTKhiem $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $

 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define businness logic of List/Create/Update Report For Non Resident App

 * for LG module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Cpa.Bus
{
    class clsLGReportForNonResidentAppBus
    {
        clsDataAccessLayer m_DAL = null;
        clsLGBus m_LGBus = new clsLGBus();

        #region Properties
        public clsDataAccessLayer DAL
        {
            get
            {
                return m_DAL;
            }
        }
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public clsLGReportForNonResidentAppBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Get List Exchange Rate For Creating
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond  
        public void GetListExchangeRateForCreating(ref clsLGCUReportForNonResidentAppDTO dto)
        {
            //Exec
            m_DAL.SetCommand("dbo.spLG_GetListExchangeRateByYearMonth", CommandType.StoredProcedure);
            //Parameters
            m_DAL.AddParameter("@yearMonthFr", dto.MonthYear.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH));
            m_DAL.AddParameter("@yearMonthTo", DBNull.Value);

            SqlDataReader reader = m_DAL.ExecuteDataReader();
            if (reader != null)
            {
                //Load Data
                while (reader.Read())
                {
                    ExchangeRateInformation objExchangeRateInfo = new ExchangeRateInformation();

                    objExchangeRateInfo.TransCurrency = reader["TransCurrency"].ToString();

                    dto.LstExchangeRateInformation.Add(objExchangeRateInfo);
                }
            }
            reader.Close();
        }

        /// <summary>
        /// Get List Exchange RateForUpdating
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond  
        public void GetListExchangeRateForUpdating(ref clsLGCUReportForNonResidentAppDTO dto)
        {
            //Exec
            m_DAL.SetCommand("dbo.spLG_GetListExchangeRateByYearMonth", CommandType.StoredProcedure);
            //Parameters
            m_DAL.AddParameter("@yearMonthFr", dto.MonthYear.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH));
            m_DAL.AddParameter("@yearMonthTo", DBNull.Value);

            SqlDataReader reader = m_DAL.ExecuteDataReader();
            if (reader != null)
            {
                //Load Data
                while (reader.Read())
                {
                    ExchangeRateInformation objExchangeRateInfo = new ExchangeRateInformation();

                    objExchangeRateInfo.TransCurrency = reader["TransCurrency"].ToString();

                    objExchangeRateInfo.ExchangeRate = decimal.Parse(reader["ExchangeRate"] == DBNull.Value ? "0" : reader["ExchangeRate"].ToString());                    

                    //- Used to regconize "Update" OR "Create New"
                    //+ String.Empty: Create New
                    //+ Different from [String.Empty] AND different itself: Update
                    objExchangeRateInfo.OldExchangeRate = reader["ExchangeRate"] == DBNull.Value ? String.Empty : (reader["TransCurrency"].ToString().Equals(clsLGConstant.LG_CURRENCY_JPY) ? decimal.Parse(reader["ExchangeRate"].ToString()).ToString(clsLGConstant.FORMAT_NUMBER_N) : decimal.Parse(reader["ExchangeRate"].ToString()).ToString(clsLGConstant.FORMAT_NUMBER_N5));

                    dto.LstExchangeRateInformation.Add(objExchangeRateInfo);
                }
            }
            reader.Close();
        }

        /// <summary>
        /// Check existing data
        /// </summary>
        /// <param name="customerCode"></param>>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public bool CheckExistingTransCurrency(string yearMonth)
        {
            int rowCount = 0;

            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@yearMonth", yearMonth);
            object outParamName = "@rowCount";
            parameters[1] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
            parameters[1].Direction = ParameterDirection.Output;

            rowCount = m_DAL.ExecuteNonQuery("dbo.spLG_CheckExistingTransCurrency", CommandType.StoredProcedure, parameters, outParamName);

            if (rowCount != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Insert ExchangeRate
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public int InsertExchangeRate(clsLGCUReportForNonResidentAppDTO dto)
        {
            int rowCount = 0;
            List<SqlParameter[]> lstParameter = new List<SqlParameter[]>();

            //Clear All Exchange Rate
            ClearAllExchangeRate(dto.MonthYear.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH));
            //Insert Exchange Rate
            foreach (ExchangeRateInformation objExchangeRateInfo in dto.LstExchangeRateInformation)
            {
                SqlParameter[] parameters = new SqlParameter[6];
                parameters[0] = new SqlParameter("@yearMonth", dto.MonthYear.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH));
                parameters[1] = new SqlParameter("@ccy", objExchangeRateInfo.TransCurrency);
                parameters[2] = new SqlParameter("@exchangeRate", objExchangeRateInfo.ExchangeRate);
                parameters[3] = new SqlParameter("@lockStatus", objExchangeRateInfo.LockStatus);
                //Created By: User login
                parameters[4] = new SqlParameter("@createdBy", dto.CreatedBy);

                object outParamName = "@rowCount";
                parameters[5] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
                parameters[5].Direction = ParameterDirection.Output;

                lstParameter.Add(parameters);
            }
            rowCount = m_DAL.ExecuteNonQueryWithTransaction("dbo.spLG_InsertExchangeRate", CommandType.StoredProcedure, lstParameter);

            return rowCount;
        }

        /// <summary>
        /// Delete List SBV File
        /// </summary>
        /// <param name="loanRef"></param>

        /// <param name="olType"></param>
        /// <param name="numEdit"></param>        

        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond        
        public int ClearAllExchangeRate(string yearMonth)
        {
            int rowCount = 0;

            SqlParameter[] parameter = new SqlParameter[2];

            parameter[0] = new SqlParameter("@yearMonth", yearMonth);
            object outParamName = "@rowCount";
            parameter[1] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
            parameter[1].Direction = ParameterDirection.Output;

            rowCount = m_DAL.ExecuteNonQueryWithTransaction("dbo.spLG_ClearExchangeRateByYearMonth", CommandType.StoredProcedure, parameter);

            return rowCount;

        }

        /// <summary>
        /// Get List Exchange Rate For Creating
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond  
        public void GetListExchangeRateForListing(ref clsLGListReportForNonResidentAppDTO dto)
        {
            //Exec
            m_DAL.SetCommand("dbo.spLG_GetListExchangeRateByYearMonth", CommandType.StoredProcedure);
            //Parameters
            m_DAL.AddParameter("@yearMonthFr", dto.MonthYearFr.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH));
            m_DAL.AddParameter("@yearMonthTo", dto.MonthYearTo.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH));

            SqlDataReader reader = m_DAL.ExecuteDataReader();
            if (reader != null)
            {
                //Load Data
                while (reader.Read())
                {
                    NonResidentAppInformation objNonResidentAppInfo = new NonResidentAppInformation();

                    objNonResidentAppInfo.MonthYear = DateTime.Parse(reader["ExchangeRateDate"].ToString());
                    objNonResidentAppInfo.LockStatus = reader["LockStatus"].ToString();

                    dto.LstNonResidentAppInformation.Add(objNonResidentAppInfo);
                }
            }
            reader.Close();
        }

        /// <summary>
        /// Get Exchange Rate For Reporting
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond  
        public void GetListExchangeRateForReporting(ref NonResidentAppInformation objNonResidentAppInfo)
        {
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@yearMonth", objNonResidentAppInfo.MonthYear.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH));                            
            //Exec
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetExchangeRateReport", CommandType.StoredProcedure, parameters);
            if (reader != null)
            {
                //Load Data                
                ExchangeRateForReporting objExchangeRateForReporting = new ExchangeRateForReporting();

                objExchangeRateForReporting.CompanyName = m_LGBus.GetCompanyName();
                objExchangeRateForReporting.PrintedDate = objNonResidentAppInfo.MonthYear;
                objExchangeRateForReporting.Within_Sum_VND = decimal.Parse(reader.Rows[0]["Sum_VND"].ToString()).ToString(clsLGConstant.FORMAT_DECIMAL);
                objExchangeRateForReporting.Within_Sum_USD = decimal.Parse(reader.Rows[0]["Sum_USD"].ToString()).ToString(clsLGConstant.FORMAT_DECIMAL);
                objExchangeRateForReporting.End_Sum_VND = decimal.Parse(reader.Rows[1]["Sum_VND"].ToString()).ToString(clsLGConstant.FORMAT_DECIMAL);
                objExchangeRateForReporting.End_Sum_USD = decimal.Parse(reader.Rows[1]["Sum_USD"].ToString()).ToString(clsLGConstant.FORMAT_DECIMAL);

                objNonResidentAppInfo.LstExchangeRateForReporting.Add(objExchangeRateForReporting);                
            }            
        } 

        /// <summary>
        /// Insert ExchangeRate
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public int UpdateExchangeRate(NonResidentAppInformation objNonResidentAppInfo)
        {
            int rowCount = 0;                     
            
            SqlParameter[] parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("@yearMonth", objNonResidentAppInfo.MonthYear.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH));
            parameters[1] = new SqlParameter("@lockStatus", objNonResidentAppInfo.LockStatus);                

            object outParamName = "@rowCount";
            parameters[2] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
            parameters[2].Direction = ParameterDirection.Output;

            rowCount = m_DAL.ExecuteNonQueryWithTransaction("dbo.spLG_UpdateExchangeRate", CommandType.StoredProcedure, parameters);

            return rowCount;
        }

        /// <summary>
        /// Commit transaction
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// Rollback transaction
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }
    }
}