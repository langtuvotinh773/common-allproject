﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-20 09:30:00 +0700 (Wed, 20 Mar 2013) $
 * $Revision: 11501 $ 
 * ========================================================
 * This class is used to management beneficiary
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
    public class clsLGBeneficiaryBus
    {
        //used to process data from database
        private clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public clsLGBeneficiaryBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Insert Beneficiary
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public int InsertBeneficiary(clsLGBeneficiaryDTO dto)
        {
            int row = 0;

            SqlParameter[] parameters = new SqlParameter[6];
            //set parameters for insert beneficiary
            parameters[0] = new SqlParameter("@beneficiaryName", dto.BeneficiaryName);
            parameters[1] = new SqlParameter("@beneficiaryAddress", dto.BeneficiaryAddress);
            parameters[2] = new SqlParameter("@beneficiaryNational", dto.BeneficiaryNational);
            parameters[3] = new SqlParameter("@beneficiaryTel", dto.BeneficiaryTel);
            parameters[4] = new SqlParameter("@beneficiaryFax", dto.BeneficiaryFax);
            parameters[5] = new SqlParameter("@createdBy", dto.CreatedBy);
            //insert beneficiary with parameters
            row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spLG_InsertBeneficiary", CommandType.StoredProcedure, parameters);

            return row;
        }

        /// <summary>
        /// Update Beneficiary
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public int UpdateBeneficiary(clsLGBeneficiaryDTO dto)
        {
            int row = 0;

            SqlParameter[] parameters = new SqlParameter[8];
            //set parameters
            parameters[0] = new SqlParameter("@seqBeneficiary", dto.SeqBeneficiary);
            parameters[1] = new SqlParameter("@beneficiaryCode", dto.BeneficiaryCode);
            parameters[2] = new SqlParameter("@beneficiaryName", dto.BeneficiaryName);            
            parameters[3] = new SqlParameter("@beneficiaryAddress", dto.BeneficiaryAddress);
            parameters[4] = new SqlParameter("@beneficiaryNational", dto.BeneficiaryNational);
            parameters[5] = new SqlParameter("@beneficiaryTel", dto.BeneficiaryTel);
            parameters[6] = new SqlParameter("@beneficiaryFax", dto.BeneficiaryFax);
            parameters[7] = new SqlParameter("@createdBy", dto.CreatedBy);
            //update beneficiary with parameters
            row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spLG_UpdateBeneficiary", CommandType.StoredProcedure, parameters);

            return row;
        }

        /// <summary>
        /// Get Beneficiary by BeneficiaryCode
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public clsLGBeneficiaryDTO GetBeneficiary(int seq)
        {
            clsLGBeneficiaryDTO dto = new clsLGBeneficiaryDTO();
            SqlParameter[] parameters = new SqlParameter[6];
            //set parameters
            parameters[0] = new SqlParameter("@seqBeneficiary", seq);
            parameters[1] = new SqlParameter("@beneficiaryCode", String.Empty);
            parameters[2] = new SqlParameter("@beneficiaryName", String.Empty);
            parameters[3] = new SqlParameter("@beneficiaryAddress", String.Empty);
            parameters[4] = new SqlParameter("@beneficiaryNational", String.Empty);
            parameters[5] = new SqlParameter("@beneficiaryTel", String.Empty);
            //get beneficiary with parameters
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetListBeneficiary", CommandType.StoredProcedure, parameters);
            if (reader.Rows.Count > 0)
            {
                dto = dto.GetBeneficiaryForUpdate(reader.Rows[0]);
            }
            else
            {
                dto = null;
            }
            return dto;
        }

        /// <summary>
        /// Get Beneficiary by BeneficiaryCode
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public List<clsLGBeneficiaryDTO> GetListBeneficiary(clsLGBeneficiaryDTO dto)
        {
            List<clsLGBeneficiaryDTO> lst = new List<clsLGBeneficiaryDTO>();

            SqlParameter[] parameters = new SqlParameter[6];
            //set parameters
            parameters[0] = new SqlParameter("@seqBeneficiary", DBNull.Value);
            parameters[1] = new SqlParameter("@beneficiaryCode", dto.BeneficiaryCode);
            parameters[2] = new SqlParameter("@beneficiaryName", dto.BeneficiaryName);
            parameters[3] = new SqlParameter("@beneficiaryAddress", dto.BeneficiaryAddress);
            parameters[4] = new SqlParameter("@beneficiaryNational", dto.BeneficiaryNational);
            parameters[5] = new SqlParameter("@beneficiaryTel", dto.BeneficiaryTel);
            //get list beneficiary with parameters
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetListBeneficiary", CommandType.StoredProcedure, parameters);
            if (reader.Rows.Count > 0)
            {
                for (int i = 0; i < reader.Rows.Count;i++ )
                {
                    lst.Add(new clsLGBeneficiaryDTO().GetBeneficiaryForSearch(reader.Rows[i]));
                }                
            }
            return lst;
        }

        /// <summary>
        /// Delete Beneficiary
        /// </summary>
        /// <param name="lst"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public int DeleteBeneficiary(List<clsLGBeneficiaryDTO> lst)
        {
            int row = 0;
            
            List<SqlParameter[]> lstParams = new List<SqlParameter[]>();
            //set list parameters
            for (int i = 0; i < lst.Count; i++)
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@seqBeneficiary", lst[i].SeqBeneficiary);
                
                lstParams.Add(parameters);
            }
            //delete beneficiary with list parameter
            row = m_DAL.ExecuteNonQueryDeleteWithTransaction("dbo.spLG_DeleteBeneficiary", CommandType.StoredProcedure, lstParams);
            
            return row;
        }


        /// <summary>
        /// Write log history of beneficiary
        /// </summary>
        /// <param name="logBase"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void WriteLog(clsLGLogBase logBase)
        {
            logBase.WirteLog(this.m_DAL);
        }

        /// <summary>
        /// commit transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }
    }
}
