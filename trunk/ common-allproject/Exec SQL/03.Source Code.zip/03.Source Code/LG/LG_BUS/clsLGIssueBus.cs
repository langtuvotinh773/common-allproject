﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-23 9:37:30 +0700 (Sun, 23 mar 2013) $
 * $Revision: 11465 $ 
 * ========================================================
 * This class is used to get data from database for combobox on Issues screen
 * in LG module.
 */
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
    public class clsLGIssueBus
    {
        clsDataAccessLayer m_DAL = new clsDataAccessLayer();
        public clsLGIssueBus()
        {
           
        }
        /// <summary>
        /// Get list account base on customer code
        /// </summary>
        /// <param name="customerCode"></param>
        /// <returns></returns>
        public  List<clsLGAccountInfoDTO> GetListAccount(string customerCode)
        {
            List<clsLGAccountInfoDTO> lst = new List<clsLGAccountInfoDTO>();
            SqlParameter[] parameters = new SqlParameter[1];

            parameters[0] = new SqlParameter("@customerCode", customerCode);
            // parameters[1] = new SqlParameter("@type", "001");
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetAccountByCustomer", CommandType.StoredProcedure, parameters);
            lst.Add(new clsLGAccountInfoDTO());
            for (int i = 0; i < reader.Rows.Count; i++)
            {
                clsLGAccountInfoDTO temp = new clsLGAccountInfoDTO(reader.Rows[i]);
                lst.Add(temp);
            }
            return lst;
        }

        



    }
}
