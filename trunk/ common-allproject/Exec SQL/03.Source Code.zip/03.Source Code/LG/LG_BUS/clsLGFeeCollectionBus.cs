﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-20 09:30:00 +0700 (Wed, 20 Mar 2013) $
 * $Revision: 11501 $ 
 * ========================================================
 * This class is used to management applicant
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Com;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
    public class clsLGFeeCollectionBus
    {
        //used to process data from database
        private clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public clsLGFeeCollectionBus()
        {
            m_DAL = new clsDataAccessLayer();
        }


        /// <summary>
        /// Get list fee collection by search conditions
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public List<clsLGFeeCollectionDTO> GetListFeeCollection(DateTime receivedDateFrom, DateTime receivedDateTo, DateTime valueDateFrom, DateTime valueDateTo,
            DateTime actualClaimedDateFrom, DateTime actualClaimedDateTo, string customerCode, string customerName,
            string lGNo, string gLCode, string currency, string guaranteeType, string feeType)
        {
            List<clsLGFeeCollectionDTO> lst = new List<clsLGFeeCollectionDTO>();

            SqlParameter[] parameters = new SqlParameter[13];
            //set parameters
            if (receivedDateFrom == clsLGConstant.MIN_DATE_SERVER)
            {
                parameters[0] = new SqlParameter("@receivedDateFrom", DBNull.Value);
            }
            else
            {
                parameters[0] = new SqlParameter("@receivedDateFrom", receivedDateFrom);
            }
            if (receivedDateTo == clsLGConstant.MAX_DATE_SERVER)
            {
                parameters[1] = new SqlParameter("@receivedDateTo", DBNull.Value);
            }
            else
            {
                parameters[1] = new SqlParameter("@receivedDateTo", receivedDateTo);
            }
            parameters[2] = new SqlParameter("@valuedDateFrom", valueDateFrom);
            parameters[3] = new SqlParameter("@valuedDateTo", valueDateTo);
            if (actualClaimedDateFrom == clsLGConstant.MIN_DATE_SERVER)
            {
                parameters[4] = new SqlParameter("@actualClaimedDateFrom", DBNull.Value);
            }
            else
            {
                parameters[4] = new SqlParameter("@actualClaimedDateFrom", actualClaimedDateFrom);
            }
            if (actualClaimedDateTo == clsLGConstant.MAX_DATE_SERVER)
            {
                parameters[5] = new SqlParameter("@actualClaimedDateTo", DBNull.Value);
            }
            else
            {
                parameters[5] = new SqlParameter("@actualClaimedDateTo", actualClaimedDateTo);
            }
            //replace '%' = '[%]' when search like data
            parameters[6] = new SqlParameter("@customerCode", customerCode.Replace("%", "[%]"));
            parameters[7] = new SqlParameter("@customerName", customerName.Replace("%", "[%]"));
            parameters[8] = new SqlParameter("@lGNo", lGNo.Replace("%", "[%]"));
            parameters[9] = new SqlParameter("@gLCode", String.IsNullOrEmpty(gLCode) ? DBNull.Value : (object)gLCode);
            parameters[10] = new SqlParameter("@currency", String.IsNullOrEmpty(currency) ? DBNull.Value : (object)currency);
            parameters[11] = new SqlParameter("@guaranteeType", String.IsNullOrEmpty(guaranteeType) ? DBNull.Value : (object)guaranteeType);
            parameters[12] = new SqlParameter("@feeType", feeType.Equals(String.Empty) ? "" : feeType);
            //get data from database
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetListFeeCollection", CommandType.StoredProcedure, parameters);
            if (reader.Rows.Count > 0)
            {
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    //add data to list fee collection
                    lst.Add(new clsLGFeeCollectionDTO().GetFeeCollectionForSearch(reader.Rows[i]));
                }
            }
            return lst;
        }

        /// <summary>
        /// commit transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }
    }
}
