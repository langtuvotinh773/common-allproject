﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: HTKhiem $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $

 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define businness logic of Listing LG History

 * for LG module.
 */
using System;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Com;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
    class clsLGListLGHistoryBus
    {        
        clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public clsLGListLGHistoryBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Get List Exchange Rate For Creating
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond  
        public void GetListLGHistory(ref clsLGListLGHistoryDTO dto)
        {
            //Exec
            m_DAL.SetCommand("dbo.spLG_GetListLGHistory", CommandType.StoredProcedure);
            //Parameters            
            //+ LG No
            if (dto.LGNo.Equals(String.Empty))
            {
                m_DAL.AddParameter("@lgNo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@lgNo", dto.LGNo.Replace("%", "[%]"));
            }
            //+ Customer Code
            if (dto.CustomerCode.Equals(String.Empty))
            {
                m_DAL.AddParameter("@customerCode", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@customerCode", dto.CustomerCode.Replace("%", "[%]"));
            }            
            //+ Customer Name
            if (dto.CustomerName.Equals(String.Empty))
            {
                m_DAL.AddParameter("@customerName", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@customerName", dto.CustomerName.Replace("%", "[%]"));
            }            
            //+ Security
            if (dto.Security.Equals(String.Empty))
            {
                m_DAL.AddParameter("@security", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@security", dto.Security);
            }
            //+ Booking purpose
            //2013.05.09 UPD HTK S Change [Booking Purpose] From CheckBox To ComboBox
            //m_DAL.AddParameter("@bookingPurpose", dto.BookingPurpose);
            if (dto.BookingPurpose.Equals(String.Empty))
            {
                m_DAL.AddParameter("@bookingPurpose", DBNull.Value);
            }
            else if (dto.BookingPurpose.Equals("Booking Purpose"))
            {
                m_DAL.AddParameter("@bookingPurpose", true);
            }
            else
            {
                m_DAL.AddParameter("@bookingPurpose", false);
            }
            //2013.05.09 UPD HTK S Change [Booking Purpose] From CheckBox To ComboBox
            //+ GL Code
            if (dto.GLCode.Equals(String.Empty))
            {
                m_DAL.AddParameter("@glCode", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@glCode", dto.GLCode);
            }            
            //+ Currency
            if (dto.Currency.Equals(String.Empty))
            {
                m_DAL.AddParameter("@currency", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@currency", dto.Currency);
            }          
            //+ Claim            
            if (dto.Claim.Equals(String.Empty))
            {
                m_DAL.AddParameter("@claim", DBNull.Value);
            }
            else if (dto.Claim.Equals("Claim"))
            {
                m_DAL.AddParameter("@claim", true);
            }
            else
            {
                m_DAL.AddParameter("@claim", false);
            } 
            //+ Input Date From
            if (dto.InputDateFrom.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@inputDateFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@inputDateFrom", dto.InputDateFrom);
            }            
            //+ Input Date To
            if (dto.InputDateTo.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@inputDateTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@inputDateTo", dto.InputDateTo);
            }
            //+ Guarantee Type
            if (dto.GuaranteeType.Equals(String.Empty))
            {
                m_DAL.AddParameter("@guaranteeType", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@guaranteeType", dto.GuaranteeType);
            }            
            //+ Value Date From
            if (dto.ValueDateFrom.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@valueDateFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@valueDateFrom", dto.ValueDateFrom);
            }            
            //+ Value Date To
            if(dto.ValueDateTo.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@valueDateTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@valueDateTo", dto.ValueDateTo);
            }            
            //+ Expire Date From
            if (dto.ExpireDateFrom.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@expireDateFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@expireDateFrom", dto.ExpireDateFrom);
            }            
            //+ Expire Date To
            if (dto.ExpireDateTo.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@expireDateTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@expireDateTo", dto.ExpireDateTo);
            }            
            //+ Amount From
            if (dto.AmountFrom.Equals(String.Empty))
            {
                m_DAL.AddParameter("@amountFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@amountFrom", decimal.Parse(dto.AmountFrom));
            }            
            //+ Amount To
            if (dto.AmountTo.Equals(String.Empty))
            {   
                m_DAL.AddParameter("@amountTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@amountTo", decimal.Parse(dto.AmountTo));
            }            

            SqlDataReader reader = m_DAL.ExecuteDataReader();
            if (reader != null)
            {
                //Load Data
                while (reader.Read())
                {
                    LGHistoryInformation objLGHistoryInfo = new LGHistoryInformation();

                    //+ Sequence
                    objLGHistoryInfo.SeqLG = reader["SeqLG"] == DBNull.Value ? String.Empty : reader["SeqLG"].ToString();
                    //+ LG No
                    objLGHistoryInfo.LGNo = reader["LGNo"] == DBNull.Value ? String.Empty : reader["LGNo"].ToString();
                    //+ Mng Code
                    objLGHistoryInfo.MngCode = reader["MngCode"] == DBNull.Value ? String.Empty : reader["MngCode"].ToString();
                    //+ Previous LG No
                    objLGHistoryInfo.PreviousLGNo = reader["PreviousLGNo"] == DBNull.Value ? String.Empty : reader["PreviousLGNo"].ToString();
                    //+ Type
                    objLGHistoryInfo.Type = reader["LGStatus"] == DBNull.Value ? String.Empty : reader["LGStatus"].ToString();
                    //+ Input Date
                    objLGHistoryInfo.InputDate = DateTime.Parse(reader["InputDate"] == DBNull.Value ? DateTime.MinValue.ToString() : reader["InputDate"].ToString());
                    //+ Value Date
                    objLGHistoryInfo.ValueDate = DateTime.Parse(reader["ValueDate"] == DBNull.Value ? DateTime.MinValue.ToString() : reader["ValueDate"].ToString());
                    //+ Back Value
                    objLGHistoryInfo.BackValue = reader["BackValue"] == DBNull.Value ? String.Empty : reader["BackValue"].ToString();
                    //+ Customer Code
                    objLGHistoryInfo.CustomerCode = reader["CustomerCode"] == DBNull.Value ? String.Empty : reader["CustomerCode"].ToString();
                    //+ Customer Name
                    objLGHistoryInfo.CustomerName = reader["CustomerName"] == DBNull.Value ? String.Empty : reader["CustomerName"].ToString();
                    //+ GL Code
                    objLGHistoryInfo.GLCode = reader["GLCode"] == DBNull.Value ? String.Empty : reader["GLCode"].ToString();
                    //+ Claim
                    objLGHistoryInfo.Claim = reader["Claim"] == DBNull.Value ? String.Empty : reader["Claim"].ToString();
                    //+ Fee Rate
                    objLGHistoryInfo.FeeRate = decimal.Parse(reader["LGRate"] == DBNull.Value ? "0" : reader["LGRate"].ToString());
                    //+ Min
                    objLGHistoryInfo.Min = decimal.Parse(reader["MinRateAmount"] == DBNull.Value ? "0" : reader["MinRateAmount"].ToString());
                    //+ Min CCY
                    objLGHistoryInfo.MinCCY = reader["MinRateCurrency"] == DBNull.Value ? String.Empty : reader["MinRateCurrency"].ToString();
                    //+ Expiry Date
                    objLGHistoryInfo.ExpiryDate = DateTime.Parse(reader["ExpireDate"] == DBNull.Value ? DateTime.MinValue.ToString() : reader["ExpireDate"].ToString());
                    //+ Guarantee Type
                    objLGHistoryInfo.GuaranteeType = reader["GuaranteeType"] == DBNull.Value ? String.Empty : reader["GuaranteeType"].ToString();
                    //+ Beneficiary Name
                    objLGHistoryInfo.BeneficiaryName = reader["BeneficiaryName"] == DBNull.Value ? String.Empty : reader["BeneficiaryName"].ToString();
                    //+ CCY
                    objLGHistoryInfo.TransCurrency = reader["TransCurrency"] == DBNull.Value ? String.Empty : reader["TransCurrency"].ToString();
                    //+ Charge Account
                    objLGHistoryInfo.ChargeAccount = reader["ChargeAccount"] == DBNull.Value ? String.Empty : reader["ChargeAccount"].ToString();
                    //+ Guarantee Amount
                    objLGHistoryInfo.GuaranteeAmount = decimal.Parse(reader["GuaranteeAmount"] == DBNull.Value ? "0" : reader["GuaranteeAmount"].ToString());
                    //+ Fee
                    objLGHistoryInfo.Fee = decimal.Parse(reader["Fee"] == DBNull.Value ? "0" : reader["Fee"].ToString());
                    //+ Fee Currency
                    objLGHistoryInfo.FeeCurrency = reader["FeeCurrency"] == DBNull.Value ? String.Empty : reader["FeeCurrency"].ToString();
                    //+ MultiTimesFee
                    objLGHistoryInfo.MultiTimesFee = reader["MultiTimesFee"] == DBNull.Value ? String.Empty : reader["MultiTimesFee"].ToString();
                    //+ Overdue Fee
                    objLGHistoryInfo.OverdueFee = decimal.Parse(reader["OverdueFee"] == DBNull.Value ? "0" : reader["OverdueFee"].ToString());
                    //+ Overdue Fee Currency
                    objLGHistoryInfo.OverdueFeeCurrency = reader["OverdueFeeCurrency"] == DBNull.Value ? String.Empty : reader["OverdueFeeCurrency"].ToString();
                    //+ Overdue Claim Fee
                    objLGHistoryInfo.OverdueClaimFee = decimal.Parse(reader["OverdueClaimFee"] == DBNull.Value ? "0" : reader["OverdueClaimFee"].ToString());
                    //+ Overdue Claim Fee Currency
                    objLGHistoryInfo.OverdueClaimFeeCurrency = reader["OverdueClaimFeeCurrency"] == DBNull.Value ? String.Empty : reader["OverdueClaimFeeCurrency"].ToString();
                    //+ Report To SBV
                    objLGHistoryInfo.ReportToSBV = reader["ReportToSBV"] == DBNull.Value ? String.Empty : reader["ReportToSBV"].ToString();
                    objLGHistoryInfo.AmendUpdatedFeeCurrency = reader["AmendUpdateFeeCCY"] == DBNull.Value ? String.Empty : reader["AmendUpdateFeeCCY"].ToString();
                    objLGHistoryInfo.AmendUpdatedFee = reader["AmendUpdateFee"] == DBNull.Value ? 0 : (decimal)reader["AmendUpdateFee"];
                    objLGHistoryInfo.TerminateDate = reader["UpdatedDate"] == DBNull.Value ? DateTime.MinValue : (DateTime)reader["UpdatedDate"];
                    dto.LstLGHistoryInformation.Add(objLGHistoryInfo);
                }
            }
            reader.Close();
        }

        /// <summary>
        /// Get Max Number Printed
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond  
        public string GetMaxNumberPrinted(string lgType)
        {
            SqlParameter[] parameters = new SqlParameter[1];
            //Parameters            
            //+ LG Type  
            parameters[0] = new SqlParameter("@lgType", lgType);           
            //Exec            
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetMaxNumberPrintedForReportControlingBook", CommandType.StoredProcedure, parameters);
        
            return decimal.Parse(reader.Rows[0]["MAX_SEQ"].ToString()).ToString(clsLGConstant.FORMAT_NUMBER_N);
        }

        /// <summary>
        /// Get Total Printed
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond  
        public string GetTotalOfRowsNeedToPrint(string lgType)
        {
            SqlParameter[] parameters = new SqlParameter[1];
            //Parameters            
            //+ LG Type  
            parameters[0] = new SqlParameter("@lgType", lgType);
            //Exec            
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetTotalOfRowsForReportControlingBook", CommandType.StoredProcedure, parameters);

            return decimal.Parse(reader.Rows[0]["TotalOfRows"].ToString()).ToString(clsLGConstant.FORMAT_NUMBER_N);
        } 
       
        /// <summary>
        /// Commit transaction
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// Rollback transaction
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }
    }
}