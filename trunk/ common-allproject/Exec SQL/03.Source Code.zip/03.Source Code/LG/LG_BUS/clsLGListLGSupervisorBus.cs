﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: HTKhiem $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $

 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define businness logic of Listing LG Supervisor

 * for LG module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
    class clsLGListLGSupervisorBus
    {        
        clsDataAccessLayer m_DAL = null;

        #region Properties
        public clsDataAccessLayer DAL
        {
            get
            {
                return m_DAL;
            }
        }
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public clsLGListLGSupervisorBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Get List Exchange Rate For Creating
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond  
        public void GetListLGSupervisor(ref clsLGListLGSupervisorDTO dto)
        {
            //Exec
            m_DAL.SetCommand("dbo.spLG_GetListLGSupervisor", CommandType.StoredProcedure);
            //Parameters            
            //Seaching Type: 0: General Search 
            //+ 1: General Search
            //+ 2: Overdue And Expire Within 7 Days (Current Date  - Expire Date >= -7)
            //+ 3: Charge Schedule (Having data in [Fee Collection Schedule] Table & ReceivedDate IS NULL)         
            m_DAL.AddParameter("@searchingType", dto.SearchingType);
            //+ LG No
            if (dto.LGNo.Equals(String.Empty))
            {
                m_DAL.AddParameter("@lgNo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@lgNo", dto.LGNo.Replace("%", "[%]"));
            }
            //+ Customer Code
            if (dto.CustomerCode.Equals(String.Empty))
            {
                m_DAL.AddParameter("@customerCode", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@customerCode", dto.CustomerCode.Replace("%", "[%]"));
            }            
            //+ Customer Name
            if (dto.CustomerName.Equals(String.Empty))
            {
                m_DAL.AddParameter("@customerName", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@customerName", dto.CustomerName.Replace("%", "[%]"));
            }            
            //+ Security
            if (dto.Security.Equals(String.Empty))
            {
                m_DAL.AddParameter("@security", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@security", dto.Security);
            }
            //+ Booking purpose
            //2013.05.09 UPD HTK S Change [Booking Purpose] From CheckBox To ComboBox
            //m_DAL.AddParameter("@bookingPurpose", dto.BookingPurpose);
            if (dto.BookingPurpose.Equals(String.Empty))
            {
                m_DAL.AddParameter("@bookingPurpose", DBNull.Value);
            }
            else if (dto.BookingPurpose.Equals("Booking Purpose"))
            {
                m_DAL.AddParameter("@bookingPurpose", true);
            }
            else
            {
                m_DAL.AddParameter("@bookingPurpose", false);
            }
            //2013.05.09 UPD HTK S Change [Booking Purpose] From CheckBox To ComboBox
            //+ GL Code
            if (dto.GLCode.Equals(String.Empty))
            {
                m_DAL.AddParameter("@glCode", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@glCode", dto.GLCode);
            }            
            //+ Currency
            if (dto.Currency.Equals(String.Empty))
            {
                m_DAL.AddParameter("@currency", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@currency", dto.Currency);
            }
            //+ Claim            
            if (dto.Claim.Equals(String.Empty))
            {
                m_DAL.AddParameter("@claim", DBNull.Value);
            }
            else if (dto.Claim.Equals("Claim"))
            {
                m_DAL.AddParameter("@claim", true);
            }
            else
            {
                m_DAL.AddParameter("@claim", false);
            } 
            //+ Input Date From
            if (dto.InputDateFrom.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@inputDateFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@inputDateFrom", dto.InputDateFrom);
            }            
            //+ Input Date To
            if (dto.InputDateTo.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@inputDateTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@inputDateTo", dto.InputDateTo);
            }
            //+ Guarantee Type
            if (dto.GuaranteeType.Equals(String.Empty))
            {
                m_DAL.AddParameter("@guaranteeType", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@guaranteeType", dto.GuaranteeType);
            }            
            //+ Value Date From
            if (dto.ValueDateFrom.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@valueDateFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@valueDateFrom", dto.ValueDateFrom);
            }            
            //+ Value Date To
            if(dto.ValueDateTo.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@valueDateTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@valueDateTo", dto.ValueDateTo);
            }            
            //+ Expire Date From
            if (dto.ExpireDateFrom.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@expireDateFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@expireDateFrom", dto.ExpireDateFrom);
            }            
            //+ Expire Date To
            if (dto.ExpireDateTo.Equals(DateTime.MinValue))
            {
                m_DAL.AddParameter("@expireDateTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@expireDateTo", dto.ExpireDateTo);
            }            
            //+ Amount From
            if (dto.AmountFrom.Equals(String.Empty))
            {
                m_DAL.AddParameter("@amountFrom", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@amountFrom", decimal.Parse(dto.AmountFrom));
            }            
            //+ Amount To
            if (dto.AmountTo.Equals(String.Empty))
            {   
                m_DAL.AddParameter("@amountTo", DBNull.Value);
            }
            else
            {
                m_DAL.AddParameter("@amountTo", decimal.Parse(dto.AmountTo));
            }            

            SqlDataReader reader = m_DAL.ExecuteDataReader();
            if (reader != null)
            {
                //Load Data
                while (reader.Read())
                {
                    LGSupervisorInformation objLGSupervisorInfo = new LGSupervisorInformation();

                    //+ Sequence
                    objLGSupervisorInfo.SeqLG = reader["SeqLG"] == DBNull.Value ? String.Empty : reader["SeqLG"].ToString();
                    //+ LG No
                    objLGSupervisorInfo.LGNo = reader["LGNo"] == DBNull.Value ? String.Empty : reader["LGNo"].ToString();
                    //+ Previous LG No
                    objLGSupervisorInfo.PreviousLGNo = reader["PreviousLGNo"] == DBNull.Value ? String.Empty : reader["PreviousLGNo"].ToString();
                    //+ Type
                    objLGSupervisorInfo.Type = reader["LGStatus"] == DBNull.Value ? String.Empty : reader["LGStatus"].ToString();
                    //+ Input Date
                    objLGSupervisorInfo.InputDate = DateTime.Parse(reader["InputDate"] == DBNull.Value ? DateTime.MinValue.ToString() : reader["InputDate"].ToString());
                    //+ Value Date
                    objLGSupervisorInfo.ValueDate = DateTime.Parse(reader["ValueDate"] == DBNull.Value ? DateTime.MinValue.ToString() : reader["ValueDate"].ToString());
                    //+ Back Value
                    objLGSupervisorInfo.BackValue = reader["BackValue"] == DBNull.Value ? String.Empty : reader["BackValue"].ToString();
                    //+ Customer Code
                    objLGSupervisorInfo.CustomerCode = reader["CustomerCode"] == DBNull.Value ? String.Empty : reader["CustomerCode"].ToString();
                    //+ Customer Name
                    objLGSupervisorInfo.CustomerName = reader["CustomerName"] == DBNull.Value ? String.Empty : reader["CustomerName"].ToString();
                    //+ GL Code
                    objLGSupervisorInfo.GLCode = reader["GLCode"] == DBNull.Value ? String.Empty : reader["GLCode"].ToString();
                    //+ Claim
                    objLGSupervisorInfo.Claim = reader["Claim"] == DBNull.Value ? String.Empty : reader["Claim"].ToString();
                    //+ Fee Rate
                    objLGSupervisorInfo.FeeRate = decimal.Parse(reader["LGRate"] == DBNull.Value ? "0" : reader["LGRate"].ToString());
                    //+ Min
                    objLGSupervisorInfo.Min = decimal.Parse(reader["MinRateAmount"] == DBNull.Value ? "0" : reader["MinRateAmount"].ToString());
                    //+ Min CCY
                    objLGSupervisorInfo.MinCCY = reader["MinRateCurrency"] == DBNull.Value ? String.Empty : reader["MinRateCurrency"].ToString();
                    //+ Expiry Date
                    objLGSupervisorInfo.ExpiryDate = DateTime.Parse(reader["ExpireDate"] == DBNull.Value ? DateTime.MinValue.ToString() : reader["ExpireDate"].ToString());
                    //+ Guarantee Type
                    objLGSupervisorInfo.GuaranteeType = reader["GuaranteeType"] == DBNull.Value ? String.Empty : reader["GuaranteeType"].ToString();
                    //+ Beneficiary Name
                    objLGSupervisorInfo.BeneficiaryName = reader["BeneficiaryName"] == DBNull.Value ? String.Empty : reader["BeneficiaryName"].ToString();
                    //+ CCY
                    objLGSupervisorInfo.TransCurrency = reader["TransCurrency"] == DBNull.Value ? String.Empty : reader["TransCurrency"].ToString();
                    //+ Charge Account
                    objLGSupervisorInfo.ChargeAccount = reader["ChargeAccount"] == DBNull.Value ? String.Empty : reader["ChargeAccount"].ToString();
                    //+ Guarantee Amount
                    objLGSupervisorInfo.GuaranteeAmount = decimal.Parse(reader["GuaranteeAmount"] == DBNull.Value ? "0" : reader["GuaranteeAmount"].ToString());
                    //+ Fee
                    objLGSupervisorInfo.Fee = decimal.Parse(reader["Fee"] == DBNull.Value ? "0" : reader["Fee"].ToString());
                    //+ Fee Currency
                    objLGSupervisorInfo.FeeCurrency = reader["FeeCurrency"] == DBNull.Value ? String.Empty : reader["FeeCurrency"].ToString();
                    //+ MultiTimesFee
                    objLGSupervisorInfo.MultiTimesFee = reader["MultiTimesFee"] == DBNull.Value ? String.Empty : reader["MultiTimesFee"].ToString();
                    //+ Overdue Fee
                    objLGSupervisorInfo.OverdueFee = decimal.Parse(reader["OverdueFee"] == DBNull.Value ? "0" : reader["OverdueFee"].ToString());
                    //+ Overdue Fee Currency
                    objLGSupervisorInfo.OverdueFeeCurrency = reader["OverdueFeeCurrency"] == DBNull.Value ? String.Empty : reader["OverdueFeeCurrency"].ToString();
                    //+ Overdue Claim Fee
                    objLGSupervisorInfo.OverdueClaimFee = decimal.Parse(reader["OverdueClaimFee"] == DBNull.Value ? "0" : reader["OverdueClaimFee"].ToString());
                    //+ Overdue Claim Fee Currency
                    objLGSupervisorInfo.OverdueClaimFeeCurrency = reader["OverdueClaimFeeCurrency"] == DBNull.Value ? String.Empty : reader["OverdueClaimFeeCurrency"].ToString();
                    //+ Report To SBV
                    objLGSupervisorInfo.ReportToSBV = reader["ReportToSBV"] == DBNull.Value ? String.Empty : reader["ReportToSBV"].ToString();
                    //2013.05.09 ADD HTK S Smile Interface
                    //+ Exported (Smile)
                    objLGSupervisorInfo.ExportedSmile = reader["ExportedSmile"] == DBNull.Value ? String.Empty : reader["ExportedSmile"].ToString();
                    //+ Remark
                    objLGSupervisorInfo.Remark = reader["Remark"] == DBNull.Value ? String.Empty : reader["Remark"].ToString();
                    //2013.05.09 ADD HTK E Smile Interface

                    dto.LstLGSupervisorInformation.Add(objLGSupervisorInfo);
                }
            }
            reader.Close();
        }

        /// <summary>
        /// Return List LG Supervisor
        /// </summary>
        /// <param name="objLGSupervisorInfo"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public int ReturnListLGSupervisor(List<LGSupervisorInformation> lstLGSupervisorInfo)
        {
            int rowCount = 0;
            List<SqlParameter[]> lstParameter = new List<SqlParameter[]>();
            foreach (LGSupervisorInformation objLGSupervisorInfo in lstLGSupervisorInfo)
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@lgNo", objLGSupervisorInfo.LGNo);

                object outParamName = "@rowCount";
                parameters[1] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
                parameters[1].Direction = ParameterDirection.Output;

                lstParameter.Add(parameters);
            }

            rowCount = m_DAL.ExecuteNonQueryWithTransaction("dbo.spLG_ReturnListLGSupervisor", CommandType.StoredProcedure, lstParameter);

            return rowCount;
        }
       
        /// <summary>
        /// Commit transaction
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// Rollback transaction
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }
    }
}