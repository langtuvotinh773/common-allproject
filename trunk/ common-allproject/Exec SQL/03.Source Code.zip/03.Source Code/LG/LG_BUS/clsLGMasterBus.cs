﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-23 9:37:30 +0700 (Sun, 23 mar 2013) $
 * $Revision: 11465 $ 
 * ========================================================
 * This class is used to get data from database for LG infomation
 * in LG module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;
using Phoenix.Common.MasterData.Com;

namespace Phoenix.Lg.Bus
{
   public class clsLGMasterBus
    {
       static clsDataAccessLayer m_Dal = new clsDataAccessLayer();
       public clsLGMasterBus()
       {

       }

       /// <summary>
       /// Get LG master by SeqLG number
       /// </summary>
       /// <param name="seqLG">SeqLG</param>
       /// <returns></returns>
       public static clsLGMasterDTO GetLGMaster(string seqLG)
       {
           SqlParameter[] parameters = new SqlParameter[1];

           parameters[0] = new SqlParameter("@lgNo", seqLG);     
           DataTable reader = m_Dal.ExecuteDataReader("dbo.spLG_GetLGMaster", CommandType.StoredProcedure, parameters);
           clsLGMasterDTO result = new clsLGMasterDTO(reader.Rows[0]);
           return result;
       }
       public static void UpdatePassword()
       {
           SqlParameter[] parameters = new SqlParameter[0];


           DataTable reader = m_Dal.ExecuteDataReader("dbo.spALL_GetUserPassword", CommandType.StoredProcedure, parameters);

           for (int i = 0; i < reader.Rows.Count; i++)
           {
               string oldPass = (string)reader.Rows[i]["Password"];
               Int16 userNo = (Int16)reader.Rows[i]["UserNo"];
              string newPass = DataEncryption.Encryption.decrypt(oldPass);
              string md5Pass = clsMDFunction.GetMD5HashData("BTMU");
              parameters = new SqlParameter[2];
              parameters[0] = new SqlParameter("@userNo", userNo);
              parameters[1] = new SqlParameter("@password", md5Pass);
              m_Dal.ExecuteDataReader("dbo.spALL_UpdatePassword", CommandType.StoredProcedure, parameters);
           }
       }
       public static clsLGMasterDTO GetLGMasterBefore(string seqLG)
       {
           SqlParameter[] parameters = new SqlParameter[1];

           parameters[0] = new SqlParameter("@lgNo", seqLG);
           DataTable reader = m_Dal.ExecuteDataReader("dbo.spLG_GetLGMasterBefore", CommandType.StoredProcedure, parameters);
           clsLGMasterDTO result = new clsLGMasterDTO(reader.Rows[0]);
           return result;
       }
       /// <summary>
       /// Get LG Detail by SeqLG number
       /// </summary>
       /// <param name="seqLG">SeqLG</param>
       /// <returns></returns>
       public static List<clsLGDetailDTO> GetLGDetail(Int64 seqLG)
       {
           List<clsLGDetailDTO> lst = new List<clsLGDetailDTO>();
           SqlParameter[] parameters = new SqlParameter[1];

           parameters[0] = new SqlParameter("@seqLG", seqLG);
           DataTable reader = m_Dal.ExecuteDataReader("dbo.spLG_GetLGDetail", CommandType.StoredProcedure, parameters);
           for (int i = 0; i < reader.Rows.Count; i++)
           {
               lst.Add(new clsLGDetailDTO(reader.Rows[i]));
           }
           return lst;
       }

       /// <summary>
       /// Ge Fee collection schedule by SeqLG number
       /// </summary>
       /// <param name="seqLG">SeqLG</param>
       /// <returns></returns>
       public static List<clsLGFeeScheduleDTO> GetFeeCollection(Int64 seqLG)
       {
           List<clsLGFeeScheduleDTO> lst = new List<clsLGFeeScheduleDTO>();
           SqlParameter[] parameters = new SqlParameter[1];

           parameters[0] = new SqlParameter("@seqLG", seqLG);        
           DataTable reader = m_Dal.ExecuteDataReader("dbo.spLG_GetFeeSchedule", CommandType.StoredProcedure, parameters);
           for (int i = 0; i < reader.Rows.Count; i++)
           {
               lst.Add(new clsLGFeeScheduleDTO(reader.Rows[i]));
           }
           return lst;
       }


       public static LG GetLGBefore(string lgNo)
       {
           LG result = new LG();
           result.Master = GetLGMasterBefore(lgNo); // get LG Master  by LgNo
           List<clsLGDetailDTO> lstDetail = GetLGDetail(result.Master.SeqLG); // get LG detail by Seq
           List<clsLGFeeScheduleDTO> lstFee = GetFeeCollection(result.Master.SeqLG); // List Fee by Seq
           List<clsLGFeeScheduleDTO> lstOverdue = GetOverdueCollection(result.Master.SeqLG); //Get Overdue by Seq
           List<LGDetail> details = new List<LGDetail>();
           for (int i = 0; i < lstDetail.Count; i++)
           {
               LGDetail detail = new LGDetail();
               detail.SubCode = lstDetail[i].SubCode;
               detail.Detail = lstDetail[i];
               List<clsLGFeeScheduleDTO> fees = new List<clsLGFeeScheduleDTO>();
               for (int j = 0; j < lstFee.Count; j++)
               {
                   if (lstFee[j].SubID == lstDetail[i].SubCode)
                       fees.Add(lstFee[j]);
               }

               List<clsLGFeeScheduleDTO> overdue = new List<clsLGFeeScheduleDTO>();
               for (int j = 0; j < lstOverdue.Count; j++)
               {
                   if (lstOverdue[j].SubID == lstDetail[i].SubCode)
                       overdue.Add(lstOverdue[j]);
               }
               detail.LstOverduleSchedule = overdue;
               detail.LstFeeSchedule = fees;
               details.Add(detail);
           }
           result.LstDetail = details;
           return result;

       }
       /// <summary>
       /// Get a LG : LG Master + LG Detail + Fee collection
       /// </summary>
       /// <param name="lgNo">SeqLG</param>
       /// <returns></returns>
       public static LG GetLG(string lgNo)
       {
           LG result = new LG();
           result.Master = GetLGMaster(lgNo); // get LG Master  by LgNo
           List<clsLGDetailDTO> lstDetail = GetLGDetail(result.Master.SeqLG); // get LG detail by Seq
           List<clsLGFeeScheduleDTO> lstFee = GetFeeCollection(result.Master.SeqLG); // List Fee by Seq
           List<clsLGFeeScheduleDTO> lstOverdue = GetOverdueCollection(result.Master.SeqLG); //Get Overdue by Seq
           List<LGDetail> details = new List<LGDetail>();
           for (int i = 0; i < lstDetail.Count; i++)
           {
               LGDetail detail = new LGDetail();
               detail.SubCode = lstDetail[i].SubCode;
               detail.Detail = lstDetail[i];
               List<clsLGFeeScheduleDTO> fees = new List<clsLGFeeScheduleDTO>();
               for (int j = 0; j < lstFee.Count; j++)
               {
                   if (lstFee[j].SubID == lstDetail[i].SubCode)
                       fees.Add(lstFee[j]);
               }

               List<clsLGFeeScheduleDTO> overdue = new List<clsLGFeeScheduleDTO>();
               for (int j = 0; j < lstOverdue.Count; j++)
               {
                   if (lstOverdue[j].SubID == lstDetail[i].SubCode)
                       overdue.Add(lstOverdue[j]);
               }
               detail.LstOverduleSchedule = overdue;
               detail.LstFeeSchedule = fees;
               details.Add(detail);
           }
           result.LstDetail = details;
           return result;

       }
       /// <summary>
       /// Get a LG : LG Master, LG Detail, Overdue collection
       /// </summary>
       /// <param name="lgNo"></param>
       /// <returns></returns>
       public static LG GetLGOverdue(string lgNo)
       {
           LG result = new LG();
           result.Master = GetLGMaster(lgNo);
           List<clsLGDetailDTO> lstDetail = GetLGDetail(result.Master.SeqLG);
           List<clsLGFeeScheduleDTO> lstOverdue = GetOverdueCollection(result.Master.SeqLG);
           List<LGDetail> details = new List<LGDetail>();
           for (int i = 0; i < lstDetail.Count; i++)
           {
               LGDetail detail = new LGDetail();
               detail.SubCode = lstDetail[i].SubCode;
               detail.Detail = lstDetail[i];
               List<clsLGFeeScheduleDTO> overdue = new List<clsLGFeeScheduleDTO>();
               for (int j = 0; j < lstOverdue.Count; j++)
               {
                   if (lstOverdue[j].SubID == lstDetail[i].SubCode)
                       overdue.Add(lstOverdue[j]);
               }
               detail.LstFeeSchedule = overdue;
               details.Add(detail);
           }
           result.LstDetail = details;
           return result;

       }
       /// <summary>
       /// Get Overdue collection schedule
       /// </summary>
       /// <param name="seqLG"></param>
       /// <returns></returns>
       public static List<clsLGFeeScheduleDTO> GetOverdueCollection(Int64 seqLG)
       {
           List<clsLGFeeScheduleDTO> lst = new List<clsLGFeeScheduleDTO>();
           SqlParameter[] parameters = new SqlParameter[1];

           parameters[0] = new SqlParameter("@seqLG", seqLG);     
           DataTable reader = m_Dal.ExecuteDataReader("dbo.spLG_GetFeeOverdue", CommandType.StoredProcedure, parameters);
           for (int i = 0; i < reader.Rows.Count; i++)
           {
               lst.Add(new clsLGFeeScheduleDTO(reader.Rows[i]));
           }
           return lst;
       }

       public static void DeleteLGImportFail(string LgCode)
       {
           SqlParameter[] parameters = new SqlParameter[1];

           parameters[0] = new SqlParameter("@lgCode", LgCode);
           m_Dal.ExecuteNonQuery("dbo.spLG_DeleteLGTerminateFail", CommandType.StoredProcedure, parameters);
       }

       public static AmendFee GetAmentFee(string lgSeq)
       {
           SqlParameter[] parameters = new SqlParameter[1];

           parameters[0] = new SqlParameter("@seq", lgSeq);
           DataTable reader = m_Dal.ExecuteDataReader("dbo.spLG_GetAmendFee", CommandType.StoredProcedure, parameters);
           AmendFee result = new AmendFee();
           if(reader.Rows.Count > 0)
              result = new AmendFee(reader.Rows[0]);
           return result;  
       }
    }
   public class AmendFee
   {
       public decimal FlatFee;
       public decimal ExchangeRate;
       public string Account;
       public string CCY;
       public decimal Fee;
       public AmendFee()
       {
           FlatFee = 0;
           ExchangeRate = 0;
           Account = "";
           CCY = "";
           Fee = 0;
       }
       public AmendFee(DataRow row)
       {
           FlatFee = row["FlatFee"] == DBNull.Value ? 0 : (decimal)row["FlatFee"];
           ExchangeRate = row["ExchangeRate"] == DBNull.Value ? 0 : (decimal)row["ExchangeRate"];
           Account = row["ChargeAccount"] == DBNull.Value ? "" : (string)row["ChargeAccount"];
           CCY = row["ChargeAccountCCY"] == DBNull.Value ? "" : (string)row["ChargeAccountCCY"];
           Fee = row["AmendUpdateFee"] == DBNull.Value ? 0 : (decimal)row["AmendUpdateFee"]; 
       }
   }
   public class LG : ICloneable
   {
       public clsLGMasterDTO Master; // Info Of LG Master
       public List<LGDetail> LstDetail; // List Detail of LG master
       public LG()
       {
       }

       #region ICloneable Members

       public object Clone()
       {
           return (LG)this.MemberwiseClone();
       }

       #endregion
   }
   public class LGDetail : ICloneable
   {
       private string subCode; // Subcode of LG detail(use for combobox)
       public string SubCode
       {
           get { return subCode; }
           set { subCode = value; }
       }
       private clsLGDetailDTO detail; // Info of LG detail
       public clsLGDetailDTO Detail
       {
           get { return detail; }
           set { detail = value; }
       }
       List<clsLGFeeScheduleDTO> lstFeeSchedule;
       public List<clsLGFeeScheduleDTO> LstFeeSchedule // List Fee of Lg Detail
       {
           get { return lstFeeSchedule; }
           set { lstFeeSchedule = value; }
       }

       List<clsLGFeeScheduleDTO> lstOverduleSchedule;

       public List<clsLGFeeScheduleDTO> LstOverduleSchedule // List overdue of Lg Detail
       {
           get { return lstOverduleSchedule; }
           set { lstOverduleSchedule = value; }
       }
       
     public LGDetail()
     {
     }

     #region ICloneable Members

     public object Clone()
     {
         return (LGDetail)this.MemberwiseClone();
     }

     #endregion
   }
}
