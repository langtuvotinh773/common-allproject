﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-20 09:30:00 +0700 (Wed, 20 Mar 2013) $
 * $Revision: 11501 $ 
 * ========================================================
 * This class is used to management monitoring and alert
 * for LG module.
 */

using System.Data;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
    public class clsLGMonitoringAndAlertBus
    {
        //used to process data from database
        private clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public clsLGMonitoringAndAlertBus()
        {
            m_DAL = new clsDataAccessLayer();
        }



        /// <summary>
        /// Check existing Overdue Claim Date > Current Date
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public bool CheckExistingOverdueClaimDate()
        {
            clsLGMonitoringAndAlertDTO dto = new clsLGMonitoringAndAlertDTO();
            //get data from database
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_CheckExistingOverdueClaimDate", CommandType.StoredProcedure);
            if (reader.Rows.Count > 0)
            {
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    dto = new clsLGMonitoringAndAlertDTO().GetMornitoringAndAlert(reader.Rows[i]);
                }
            }
            /*
             * if Count > 0 exist Claim Date > Current date
             * else don't exist Claim Date > Current date
             */            
            if (dto.Count > 0)
            {
                return true;
            }
            return false;
        }      
    }
}
