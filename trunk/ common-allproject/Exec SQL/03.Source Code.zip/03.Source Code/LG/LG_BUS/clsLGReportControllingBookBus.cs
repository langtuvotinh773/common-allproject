﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: HTKhiem $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $

 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define businness logic of [Report Controlling Book] Screen

 * for LG module.
 */
using System;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Dal;

namespace Phoenix.Cpa.Bus
{
    class clsLGReportControllingBookBus
    {        
        clsDataAccessLayer m_DAL = null;

        #region Properties
        public clsDataAccessLayer DAL
        {
            get
            {
                return m_DAL;
            }
        }
        #endregion
        
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public clsLGReportControllingBookBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Get List Exchange Rate For Creating
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond  
        public DataTable GetDataForReportControlingBook(string lgType, string sequenceForm, string sequenceTo)
        {            
            SqlParameter[] parameters = new SqlParameter[3];
            //Parameters            
            //+ LG Type  
            parameters[0] = new SqlParameter("@lgType", lgType);
            //+ From
            if (sequenceForm.Equals(String.Empty))
            {
                parameters[1] = new SqlParameter("@sequenceFrom", DBNull.Value);
            }
            else
            {
                parameters[1] = new SqlParameter("@sequenceFrom", Convert.ToInt64(decimal.Parse(sequenceForm)));
            }            
            //+ To
            if (sequenceTo.Equals(String.Empty))
            {
                parameters[2] = new SqlParameter("@sequenceTo", DBNull.Value);
            }
            else
            {
                parameters[2] = new SqlParameter("@sequenceTo", Convert.ToInt64(decimal.Parse(sequenceTo)));
            }            
            //Exec
            //+ Get Data
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetDataForReportControlingBook", CommandType.StoredProcedure, parameters);
            //+ Update Data For Report Controling Book
            m_DAL.ExecuteNonQueryWithTransaction("dbo.spLG_UpdateDataForReportControlingBook", CommandType.StoredProcedure, parameters);
                        
            return reader;
        }        
       
        /// <summary>
        /// Commit transaction
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// Rollback transaction
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }
    }
}