﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-20 09:30:00 +0700 (Wed, 20 Mar 2013) $
 * $Revision: 11501 $ 
 * ========================================================
 * This class is used to management List Claim
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Config.Classes;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
    public class clsLGListClaimBus
    {
        //used to process data from database
        private clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public clsLGListClaimBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Get list claim
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond 
        public List<clsLGClaimDTO> GetListClaimed(int iSeqLG)
        {
            List<clsLGClaimDTO> lst = new List<clsLGClaimDTO>();
            SqlParameter[] parameters = new SqlParameter[1];
            //set parameter
            parameters[0] = new SqlParameter("@seqLG", iSeqLG);
            //get list claim
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetListClaimed", CommandType.StoredProcedure, parameters);

            if (reader.Rows.Count > 0)
            {
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    //add claim to list claim
                    lst.Add(new clsLGClaimDTO().GetLGClaim(reader.Rows[i]));
                }
            }
            return lst;
        }

        /// <summary>
        /// Save list claim
        /// </summary>
        /// <param name="lst"></param>
        /// <param name="seqLG"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond 
        public int SaveListClaim(List<clsLGClaimDTO> lst, int seqLG)
        {
            int row = 0;
            int rowInsert = 0;
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@seqLG", seqLG);
            //Delete list claim with seqLG
            row = m_DAL.ExecuteNonQueryWithTransaction("dbo.spLG_DeleteClaimed", CommandType.StoredProcedure, parameters);

            List<SqlParameter[]> lstParams = new List<SqlParameter[]>();

            for (int i = 0; i < lst.Count; i++)
            {
                //set parameters for save list claim
                parameters = new SqlParameter[9];
                parameters[0] = new SqlParameter("@seqLG", lst[i].SeqLG);
                parameters[1] = new SqlParameter("@subCode", lst[i].SubCode);
                parameters[2] = new SqlParameter("@claimedDate", lst[i].ClaimedDate);
                if (lst[i].ClaimedPaymentDate == null)
                {
                    parameters[3] = new SqlParameter("@claimedPaymentDate", DBNull.Value);
                }
                else
                {
                    parameters[3] = new SqlParameter("@claimedPaymentDate", lst[i].ClaimedPaymentDate);
                }

                parameters[4] = new SqlParameter("@currency", lst[i].ClaimedCCY);
                parameters[5] = new SqlParameter("@amount", lst[i].ClaimedAmount);
                parameters[6] = new SqlParameter("@paid", lst[i].Paid == true ? 1 : 0);
                parameters[7] = new SqlParameter("@remark", lst[i].Remark);
                parameters[8] = new SqlParameter("@createdID", clsUserInfo.UserNo);
                lstParams.Add(parameters);
            }
            //insert list claim
            rowInsert = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spLG_InsertClaimed", CommandType.StoredProcedure, lstParams);
            if (rowInsert == -1)
            {
                return rowInsert;
            }

            row += rowInsert;

            return row;
        }

        /// <summary>
        /// Write log history of Claim
        /// </summary>
        /// <param name="logBase"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void WriteLog(clsLGLogBase logBase)
        {
            logBase.WirteLog(this.m_DAL);
        }

        /// <summary>
        /// commit transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }
    }
}
