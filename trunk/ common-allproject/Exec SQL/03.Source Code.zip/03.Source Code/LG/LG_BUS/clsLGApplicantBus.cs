﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-20 09:30:00 +0700 (Wed, 20 Mar 2013) $
 * $Revision: 11501 $ 
 * ========================================================
 * This class is used to management applicant
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
    public class clsLGApplicantBus
    {
        //used to process data from database
        private clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public clsLGApplicantBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Insert Applicant
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public int InsertApplicant(clsLGApplicantDTO dto)
        {
            int row = 0;

            SqlParameter[] parameters = new SqlParameter[6];
            //set parameters
            parameters[0] = new SqlParameter("@applicantName", dto.ApplicantName);
            parameters[1] = new SqlParameter("@applicantAddress", dto.ApplicantAddress);
            parameters[2] = new SqlParameter("@applicantNational", dto.ApplicantNational);
            parameters[3] = new SqlParameter("@applicantTel", dto.ApplicantTel);
            parameters[4] = new SqlParameter("@applicantFax", dto.ApplicantFax);
            parameters[5] = new SqlParameter("@createdBy", dto.CreatedBy);
            //insert applicant with parameters
            row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spLG_InsertApplicant", CommandType.StoredProcedure, parameters);

            return row;
        }

        /// <summary>
        /// Update Applicant
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public int UpdateApplicant(clsLGApplicantDTO dto)
        {
            int row = 0;

            SqlParameter[] parameters = new SqlParameter[8];
            //set parameters
            parameters[0] = new SqlParameter("@seqApplicant", dto.SeqApplicant);
            parameters[1] = new SqlParameter("@applicantCode", dto.ApplicantCode);
            parameters[2] = new SqlParameter("@applicantName", dto.ApplicantName);
            parameters[3] = new SqlParameter("@applicantAddress", dto.ApplicantAddress);
            parameters[4] = new SqlParameter("@applicantNational", dto.ApplicantNational);
            parameters[5] = new SqlParameter("@applicantTel", dto.ApplicantTel);
            parameters[6] = new SqlParameter("@applicantFax", dto.ApplicantFax);
            parameters[7] = new SqlParameter("@createdBy", dto.CreatedBy);
            //update applicant with parameters
            row = m_DAL.ExecuteNonQueryWithTransactionReturnValue("dbo.spLG_UpdateApplicant", CommandType.StoredProcedure, parameters);

            return row;
        }

        /// <summary>
        /// Get Applicant by ApplicantCode
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public clsLGApplicantDTO GetApplicant(int seq)
        {
            clsLGApplicantDTO dto = new clsLGApplicantDTO();
            SqlParameter[] parameters = new SqlParameter[6];
            //set parameters
            parameters[0] = new SqlParameter("@seqApplicant", seq);
            parameters[1] = new SqlParameter("@applicantCode", String.Empty);
            parameters[2] = new SqlParameter("@applicantName", String.Empty);
            parameters[3] = new SqlParameter("@applicantAddress", String.Empty);
            parameters[4] = new SqlParameter("@applicantNational", String.Empty);
            parameters[5] = new SqlParameter("@applicantTel", String.Empty);
            //get applicant with parameters
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetListApplicant", CommandType.StoredProcedure, parameters);
            if (reader.Rows.Count > 0)
            {
                dto = dto.GetApplicantForUpdate(reader.Rows[0]);
            }
            else
            {
                dto = null;
            }
            return dto;
        }

        /// <summary>
        /// Get Applicant by ApplicantCode
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public List<clsLGApplicantDTO> GetListApplicant(clsLGApplicantDTO dto)
        {
            List<clsLGApplicantDTO> lst = new List<clsLGApplicantDTO>();

            SqlParameter[] parameters = new SqlParameter[6];
            //set parameters
            parameters[0] = new SqlParameter("@seqApplicant", DBNull.Value);
            parameters[1] = new SqlParameter("@applicantCode", dto.ApplicantCode);
            parameters[2] = new SqlParameter("@applicantName", dto.ApplicantName);
            parameters[3] = new SqlParameter("@applicantAddress", dto.ApplicantAddress);
            parameters[4] = new SqlParameter("@applicantNational", dto.ApplicantNational);
            parameters[5] = new SqlParameter("@applicantTel", dto.ApplicantTel);
            //get list applicant with parameters
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetListApplicant", CommandType.StoredProcedure, parameters);
            if (reader.Rows.Count > 0)
            {
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    lst.Add(new clsLGApplicantDTO().GetApplicantForSearch(reader.Rows[i]));
                }
            }
            return lst;
        }

        /// <summary>
        /// Delete Applicant
        /// </summary>
        /// <param name="lst"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public int DeleteApplicant(List<clsLGApplicantDTO> lst)
        {
            int row = 0;

            List<SqlParameter[]> lstParams = new List<SqlParameter[]>();
            //get list parameter for delete applicant
            for (int i = 0; i < lst.Count; i++)
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@seqApplicant", lst[i].SeqApplicant);

                lstParams.Add(parameters);
            }
            //delete applicant with list parameter
            row = m_DAL.ExecuteNonQueryDeleteWithTransaction("dbo.spLG_DeleteApplicant", CommandType.StoredProcedure, lstParams);

            return row;
        }

        /// <summary>
        /// Write log history of applicant
        /// </summary>
        /// <param name="logBase"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void WriteLog(clsLGLogBase logBase)
        {
            logBase.WirteLog(this.m_DAL);
        }

        /// <summary>
        /// commit transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void Commit()
        {
            m_DAL.m_transaction.Commit();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }

        /// <summary>
        /// rollback transaction
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public void RollBack()
        {
            m_DAL.m_transaction.Rollback();
            if (m_DAL.m_Connection.State == ConnectionState.Open)
                m_DAL.m_Connection.Close();
            m_DAL.m_transaction = null;
        }
    }
}
