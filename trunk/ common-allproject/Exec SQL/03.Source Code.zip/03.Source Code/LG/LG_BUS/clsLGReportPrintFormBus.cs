﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-20 09:30:00 +0700 (Wed, 20 Mar 2013) $
 * $Revision: 11501 $ 
 * ========================================================
 * This class is used to management applicant
 * for LG module.
 */

using System.Data;
using System.Data.SqlClient;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
    public class clsLGReportPrintFormBus
    {
        //used to process data from database
        private clsDataAccessLayer m_DAL = null;

        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public clsLGReportPrintFormBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        /// <summary>
        /// Get LG information for report LETTER OF GUARANTEE - NEW ENTRY and LETTER OF GUARANTEE-TERMINATION
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsLGReportLetterOfGuaranteeDTO GetLGReportLetterOfGuarantee(int seqLG, string lgNo)
        {
            clsLGReportLetterOfGuaranteeDTO lgInfo = new clsLGReportLetterOfGuaranteeDTO();

            SqlParameter[] parameters = new SqlParameter[2];

            parameters[0] = new SqlParameter("@lgNo", lgNo);
            parameters[1] = new SqlParameter("@seqLG", seqLG);
            //get data from database
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetLGInfoForReport", CommandType.StoredProcedure, parameters);
            if (reader.Rows.Count > 0)
            {                
                lgInfo = new clsLGReportLetterOfGuaranteeDTO().GetLGReportLetterOfGuarantee(reader.Rows[0]);
            }
            return lgInfo;
        }

        /// <summary>
        /// Get Applicant by ApplicantCode
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        /// @cond
        /// Author: phuong lap co
        /// @endcond
        public clsLGReportPrintFormDTO ReportWordPrintForm(string lGNo, string subCode, string typePrintForm, int seqLG)
        {
            clsLGReportPrintFormDTO dto = new clsLGReportPrintFormDTO();

            SqlParameter[] parameters = new SqlParameter[4];
            //set parameters
            parameters[0] = new SqlParameter("@lGCode", lGNo);
            parameters[1] = new SqlParameter("@subCode", subCode);
            parameters[2] = new SqlParameter("@typePrintForm", typePrintForm);
            parameters[3] = new SqlParameter("@seqLG", seqLG);
            //get data from database
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_Report_PrintForm", CommandType.StoredProcedure, parameters);
            //Incase: Export Report SBV

            if (reader.Rows.Count > 0)
            {
                for (int i = 0; i < reader.Rows.Count; i++)
                {
                    if (typePrintForm.Equals("9"))
                    {
                        //get dto for report SBV File
                        dto = new clsLGReportPrintFormDTO().GetReportPrintFormDtoForReportSBV(reader.Rows[i]);
                    }
                    else
                    {
                        //get dto for report is different report SBV File
                        dto = new clsLGReportPrintFormDTO().GetReportPrintFormDto(reader.Rows[i]);
                    }
                }
            }
            else
            {
                dto = null;
            }

            return dto;
        }

        /// <summary>
        /// Write log history of print report
        /// </summary>
        /// <param name="logBase"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void WriteLog(clsLGLogBase logBase)
        {
            this.m_DAL = new clsDataAccessLayer();
            this.m_DAL.m_Connection.Open();
            //write log data when export report SBV file into database
            logBase.WirteLog(this.m_DAL);
            this.m_DAL.m_transaction.Commit();
            this.m_DAL.m_Connection.Close();
        }

    }
}
