﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-01-21 09:30:00 +0700 (Mon, 21 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used as common function for current project
 * for LG module.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Lg.Com;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Gui.Forms;

namespace Phoenix.Lg.Bus
{
    public class clsLGBus
    {
        #region variables
        private clsDataAccessLayer m_DAL = null;
        #endregion


        /// <summary>
        /// Initializes a new instance of the <see cref="clsCustomerErrorBus" /> class.
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public clsLGBus()
        {
            m_DAL = new clsDataAccessLayer();
        }

        #region Get Parameters by Module,Type
        /// <summary>
        /// Get LG Type list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListLGType()
        {
            return GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_LG_TYPE);
        }

        /// <summary>
        /// Get LG Status list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListLGStatus()
        {
            return GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_LG_STATUS);
        }

        /// <summary>
        /// Get LG Security list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public ArrayList GetListLGSecurity()
        {
            return GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_LG_SECURITY);
        }

        /// <summary>
        /// Get Company Name for reporting
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public string GetCompanyName()
        {
            return ((CbbObject)GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_COMPNAY_NAME)[1]).Display;
        }

        /// <summary>
        /// Get GL Type list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListGLType()
        {
            ArrayList arrSourceList = new ArrayList();
            ArrayList arrNewList = new ArrayList();
            arrSourceList = GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_GL_TYPE);
            foreach (CbbObject item in arrSourceList)
            {
                arrNewList.Add(new CbbObject(item.Value, item.Value));
            }
            return arrNewList;
        }

        /// <summary>
        /// Get Guarantee Type list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListGuaranteeType()
        {
            ArrayList arrSourceList = new ArrayList();
            ArrayList arrNewList = new ArrayList();
            arrSourceList = GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_GUARANTEE_TYPE);
            foreach (CbbObject item in arrSourceList)
            {
                arrNewList.Add(new CbbObject(item.Value, item.Value));
            }
            return arrNewList;
        }

        /// <summary>
        /// Get Calculate Type list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListCalculateType()
        {
            return GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_CALCULATE_TYPE);
        }

        /// <summary>
        /// Get In case of Proper LG list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListIncaseOfProperLG()
        {
            return GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_IN_CASE_OF_PROPER_LG);
        }

        /// <summary>
        /// Get In case of Counter LG list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListIncaseOfCounterLG()
        {
            return GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_IN_CASE_OF_COUNTER_LG);
        }

        /// <summary>
        /// Get Currency list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListCurrency()
        {
            m_DAL.SetCommand("dbo.spLG_GetListCurrency", CommandType.StoredProcedure);
            m_DAL.AddParameter("@ccy", DBNull.Value);
            m_DAL.AddParameter("@ccyType", clsLGConstant.LG_MODULE);
            SqlDataReader reader = m_DAL.ExecuteDataReader();
            ArrayList dataSetResult = new ArrayList();
            //Add blank item as default
            dataSetResult.Add(new CbbObject(String.Empty, String.Empty));
            if (reader != null)
            {
                while (reader.Read())
                {
                    dataSetResult.Add(new CbbObject(reader["CurCode"].ToString().Trim(), reader["CurCode"].ToString().Trim()));
                }
            }
            reader.Close();
            return dataSetResult;
        }

        /// <summary>
        /// Get Fee Type list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListFeeType()
        {
            return GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_FEE_TYPE);
        }

        /// <summary>
        /// Get Print Form list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListPrintForm()
        {
            return GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_PRINT_FORM);
        }

        /// <summary>
        /// Get Print Form list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListFromToSBVFile()
        {
            return GetParameter(clsLGConstant.LG_MODULE, clsLGConstant.LG_FORM_TO_SBV_FILE);
        }
        #endregion        

        /// <summary>
        /// Get List Parameter
        /// </summary>
        /// <param name="module"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetParameter(string module, string type)
        {
            m_DAL.SetCommand("dbo.spLG_GetParameters", CommandType.StoredProcedure);
            m_DAL.AddParameter("@module", module);
            m_DAL.AddParameter("@type", type);
            SqlDataReader reader = m_DAL.ExecuteDataReader();
            ArrayList dataSetResult = new ArrayList();
            //Add blank item as default
            dataSetResult.Add(new CbbObject(String.Empty, String.Empty));
            if (reader != null)
            {
                while (reader.Read())
                {
                    dataSetResult.Add(new CbbObject(reader["Value"].ToString().Trim(), reader["Name"].ToString().Trim()));
                }
            }
            reader.Close();
            return dataSetResult;
        }


        /// <summary>
        /// Get List Beneficiary For Combobox
        /// </summary>
        /// <param name="cbo"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void GetListBeneficiaryForCombobox(ComboBox cbo)
        {
            cbo.DropDownStyle = ComboBoxStyle.DropDown;
            clsLGCommonFunction.FillComboboxData(this.GetListBeneficiaryName, cbo);                        
            cbo.KeyDown += new KeyEventHandler(cboBeneficiary_KeyDown);
            cbo.KeyPress += new KeyPressEventHandler(cbo_KeyPress);
        }

        /// <summary>
        /// Get List Beneficiary For Combobox Reload Data
        /// </summary>
        /// <param name="cbo"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void GetListBeneficiaryForComboboxReload(ComboBox cbo)
        {
            cbo.DropDownStyle = ComboBoxStyle.DropDown;
            clsLGCommonFunction.FillComboboxData(this.GetListBeneficiaryName, cbo);            
        }

        /// <summary>
        /// Get List Beneficiary Name
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListBeneficiaryName()
        {
            SqlParameter parameters = new SqlParameter("@beneficiaryName", String.Empty);
            m_DAL.SetCommand("dbo.spLG_GetListBeneficiaryByName", CommandType.StoredProcedure);
            m_DAL.AddParameter(parameters);
            SqlDataReader reader = m_DAL.ExecuteDataReader();
            ArrayList dataSetResult = new ArrayList();
            //Add blank item as default
            dataSetResult.Add(new CbbObject(String.Empty, String.Empty));
            if (reader != null)
            {
                while (reader.Read())
                {
                    dataSetResult.Add(new CbbObject(reader["SeqBeneficiary"].ToString(), reader["BeneficiaryName"].ToString()));
                }
            }
            reader.Close();
            return dataSetResult;
        }


        /// <summary>
        /// Event Key Press
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void cbo_KeyPress(object sender, KeyPressEventArgs e)
        {
            clsCommonClass.AutoComplete((ComboBox)sender, e);
        }

        /// <summary>
        /// Event Key Down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void cboBeneficiary_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.PageDown)
            {
                ComboBox cbb = (ComboBox)sender;
                object cbbValue = cbb.SelectedValue;
                //2013.05.02 UPD HTK S Fix Feedback 20130502
                //String _FN = cbb.Text.Substring(0, ((ComboBox)sender).SelectionStart);
                String _FN = cbb.Text.Substring(0, ((ComboBox)sender).Text.Trim().Length);
                //2013.05.02 UPD HTK S Fix Feedback 20130502 
                DataTable _dt = this.GetListBeneficiaryByName(_FN);                
                frmLGSearchData frm = new frmLGSearchData(_dt, clsLGConstant.LG_NAME_FORM_SEARCH_BENEFICIARY);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    if (frm.selectedRow != null)
                    {
                        cbb.SelectedValue = frm.selectedRow.Cells[2].Value.ToString().Trim();
                    }
                }
                else
                {
                    if (cbbValue != null)
                    {
                        cbb.SelectedValue = cbbValue;
                    }
                }
                e.Handled = true;
                cbb.Focus();
                cbb.SelectAll();
            }
        }

        /// <summary>
        /// Get List Beneficiary By Name
        /// </summary>
        /// <param name="customerCode"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public DataTable GetListBeneficiaryByName(string name)
        {
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@beneficiaryName", name);
            DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetListBeneficiaryByName", CommandType.StoredProcedure, parameters);
            reader.DefaultView.Sort = "BeneficiaryCode ASC";
            reader.Columns[0].ColumnName = "Beneficiary Code";
            reader.Columns[1].ColumnName = "Beneficiary Name";
            reader.Columns[2].ColumnName = "SeqBeneficiary";
            return reader;
        }

        /// <summary>
        /// Get List Applicant For Combobox
        /// </summary>
        /// <param name="cbo"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void GetListApplicantForCombobox(ComboBox cbo)
        {
            cbo.DropDownStyle = ComboBoxStyle.DropDown;
            clsLGCommonFunction.FillComboboxData(this.GetListApplicantName, cbo);
            //cbo.KeyDown += new KeyEventHandler(cboApplicant_KeyDown);
            cbo.KeyPress += new KeyPressEventHandler(cbo_KeyPress);
        }


        public void GetListApplicantForComboboxReLoad(ComboBox cbo)
        {
            cbo.DropDownStyle = ComboBoxStyle.DropDown;
            clsLGCommonFunction.FillComboboxData(this.GetListApplicantName, cbo);
            //cbo.KeyDown += new KeyEventHandler(cboApplicant_KeyDown);
           // cbo.KeyPress += new KeyPressEventHandler(cbo_KeyPress);
        }
        /// <summary>
        /// Get List Applicant Name
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public ArrayList GetListApplicantName()
        {
            SqlParameter parameters = new SqlParameter("@applicantName", String.Empty);
            m_DAL.SetCommand("dbo.spLG_GetListApplicantByName", CommandType.StoredProcedure);
            m_DAL.AddParameter(parameters);
            SqlDataReader reader = m_DAL.ExecuteDataReader();
            ArrayList dataSetResult = new ArrayList();
            //Add blank item as default
            dataSetResult.Add(new CbbObject(String.Empty, String.Empty));
            if (reader != null)
            {
                while (reader.Read())
                {
                    dataSetResult.Add(new CbbObject(reader["SeqApplicant"].ToString(), reader["ApplicantName"].ToString()));
                }
            }
            reader.Close();
            return dataSetResult;
        }

        /// <summary>
        /// Delete List LG
        /// </summary>
        /// <param name="objLGStaffInfo"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public int DeleteListLG(List<string> lstLGNo, clsDataAccessLayer objDAL)
        {
            int rowCount = 0;
            List<SqlParameter[]> lstParameter = new List<SqlParameter[]>();
            foreach (string objLGNo in lstLGNo)
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@lgNo", objLGNo);

                object outParamName = "@rowCount";
                parameters[1] = new SqlParameter(outParamName.ToString(), SqlDbType.Int);
                parameters[1].Direction = ParameterDirection.Output;

                lstParameter.Add(parameters);
            }

            rowCount = objDAL.ExecuteNonQueryWithTransaction("dbo.spLG_DeleteListLGStaff", CommandType.StoredProcedure, lstParameter);

            return rowCount;
        }
    }

    /// <summary>
    /// Object class to display item on combobox
    /// </summary>
    /// @cond
    /// Author: Phan Tran Hoang Yen
    /// @endcond
    public class CbbObject
    {
        private string m_Display;
        private string m_Value;
        public CbbObject(string Value, string Display)
        {
            m_Display = Display;
            m_Value = Value;
        }
        public string Display
        {
            get { return m_Display; }
        }
        public string Value
        {
            get { return m_Value; }
        }
    }
}
