﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-23 9:37:30 +0700 (Sun, 23 mar 2013) $
 * $Revision: 11465 $ 
 * ========================================================
 * This class is used to get data from database for combobox
 * in LG module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Config.Classes;
using Phoenix.Lg.Com;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Bus
{
   public class clsLGCommonBus
    {
       private clsDataAccessLayer m_DAL = null;
       private List<ParameterDTO> lstLGCategory;

       private List<string> mainCCY;

       public List<string> MainCCYList
       {
           get { return mainCCY; }
           set { mainCCY = value; }
       }

       internal List<ParameterDTO> LstLGCategory
       {
           get { return lstLGCategory; }
           set { lstLGCategory = value; }
       }

       private static clsLGCommonBus instance;
       public static clsLGCommonBus Instance()
       {
               if (instance == null)
               {
                   instance = new clsLGCommonBus();
                   instance.GetMainCCY();
               }
               return instance;
           
       }

       public clsLGCommonBus()
       {
           m_DAL = new clsDataAccessLayer();
           if (lstLGCategory == null)
           {
               lstLGCategory = new List<ParameterDTO>();
               GetListLGCategory();
           }
       }

       /// <summary>
       /// Get list LG type
       /// </summary>
       public void GetListLGCategory()
       {
           SqlParameter[] parameters = new SqlParameter[2];

           parameters[0] = new SqlParameter("@module", "LG");
           parameters[1] = new SqlParameter("@type", "001");
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetParameters", CommandType.StoredProcedure, parameters);
           if (reader.Rows.Count > 0)
           {
               //lstLGCategory.Add(new ParameterDTO());
               for (int i = 0; i < reader.Rows.Count; i++)
               {
                   ParameterDTO temp = new ParameterDTO(reader.Rows[i]);
                   lstLGCategory.Add(temp);
               }
           }
       }
       /// <summary>
       /// get list guaranteee type
       /// </summary>
       /// <returns></returns>
       public List<ParameterDTO> GetListLGGuarantee()
       {
           List<ParameterDTO> lst = new List<ParameterDTO>();
           SqlParameter[] parameters = new SqlParameter[2];

           
           parameters[0] = new SqlParameter("@module", "LG");
           parameters[1] = new SqlParameter("@type", "003");
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetParameters", CommandType.StoredProcedure, parameters);
           if (reader.Rows.Count > 0)
           {
               lst.Add(new ParameterDTO());
               for (int i = 0; i < reader.Rows.Count; i++)
               {
                   ParameterDTO temp = new ParameterDTO(reader.Rows[i]);
                   temp.Name = temp.Value + " : " + temp.Name;
                   lst.Add(temp);
               }
           }
           return lst;
       }
       /// <summary>
       /// get list calculate type
       /// </summary>
       /// <returns></returns>
       public List<ParameterDTO> GetListLGCalculateType()
       {
           List<ParameterDTO> lst = new List<ParameterDTO>();
           SqlParameter[] parameters = new SqlParameter[2];

       
           parameters[0] = new SqlParameter("@module", "LG"); 
           parameters[1] = new SqlParameter("@type", "004");
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetParameters", CommandType.StoredProcedure, parameters);
           if (reader.Rows.Count > 0)
           {
               lst.Add(new ParameterDTO());
               for (int i = 0; i < reader.Rows.Count; i++)
               {
                   ParameterDTO temp = new ParameterDTO(reader.Rows[i]);
                   temp.Name = temp.Value + " : " + temp.Name;
                   lst.Add(temp);
               }
           }
           return lst;
       }

       /// <summary>
       /// get list condition of terminate
       /// </summary>
       /// <param name="LGType">LG type</param>
       /// <returns></returns>
       public List<ParameterDTO> GetListLGConditionOfTerminate(string LGType)
       {
           List<ParameterDTO> lst = new List<ParameterDTO>();
           SqlParameter[] parameters = new SqlParameter[2];
           
           string type = "005";
           if (LGType == CommonValue.LGType.Counter.ToString())
           {
               type = "006";
           }
           parameters[0] = new SqlParameter("@module", "LG");
           parameters[1] = new SqlParameter("@type", type);
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetParameters", CommandType.StoredProcedure, parameters);
           if (reader.Rows.Count > 0)
           {
               lst.Add(new ParameterDTO());
               for (int i = 0; i < reader.Rows.Count; i++)
               {
                   ParameterDTO temp = new ParameterDTO(reader.Rows[i]);
                   temp.Name = temp.Value + " : " + temp.Name;
                   lst.Add(temp);
               }
           }
           return lst;
       }


       public List<ParameterDTO> GetListRepresentation()
       {
           List<ParameterDTO> lst = new List<ParameterDTO>();
           SqlParameter[] parameters = new SqlParameter[2];

           
           parameters[0] = new SqlParameter("@module", "LG");
           parameters[1] = new SqlParameter("@type", "014");
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetParameters", CommandType.StoredProcedure, parameters);
           if (reader.Rows.Count > 0)
           {
             //  lst.Add(new ParameterDTO());
               for (int i = 0; i < reader.Rows.Count; i++)
               {
                   ParameterDTO temp = new ParameterDTO(reader.Rows[i]);
                  // temp.Name = temp.Value + " : " + temp.Name;
                   lst.Add(temp);
               }
           }
           return lst;
       }
       /// <summary>
       /// get list CCY
       /// </summary>
       /// <returns></returns>
       public List<ParameterDTO> GetListCurrency()
       {
           List<ParameterDTO> lst = new List<ParameterDTO>();
           SqlParameter[] parameters = new SqlParameter[2];

           parameters[0] = new SqlParameter("@ccy", DBNull.Value);
           parameters[1] = new SqlParameter("@ccyType", "LG");
           lst.Add(new ParameterDTO("", ""));
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetListCurrency", CommandType.StoredProcedure, parameters);
           for (int i = 0; i < reader.Rows.Count; i++)
           {
               lst.Add(new ParameterDTO((string)reader.Rows[i]["CurCode"],(string)reader.Rows[i]["CurCode"]));
           }
           
           

           return lst;
       }

       /// <summary>
       /// get list customer by LG type
       /// </summary>
       /// <param name="LGType">Lg type</param>
       /// <returns></returns>
       public List<clsLGCustomerDTO> GetListCustomerByLGType(string LGType)
       {
           List<clsLGCustomerDTO> lst = new List<clsLGCustomerDTO>();
           SqlParameter[] parameters = new SqlParameter[1];

           parameters[0] = new SqlParameter("@LGType", LGType);
          // parameters[1] = new SqlParameter("@type", "001");
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetListCustomerCodeByLGType", CommandType.StoredProcedure, parameters);
           if (reader.Rows.Count > 0)
           {
               lst.Add(new clsLGCustomerDTO());
               
               for (int i = 0; i < reader.Rows.Count; i++)
               {
                   clsLGCustomerDTO temp = new clsLGCustomerDTO(reader.Rows[i]);
                   lst.Add(temp);
               }
           }
           return lst;
       }


       /// <summary>
       /// get server date
       /// </summary>
       /// <returns></returns>
       public DateTime GetServerDate()
       {
           SqlParameter[] parameters = new SqlParameter[0];
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetServerDate", CommandType.StoredProcedure, parameters);
         return  (DateTime)reader.Rows[0][0];       
       }

      
       /// <summary>
       /// check  datetime is banking date or not
       /// </summary>
       /// <param name="date">date input</param>
       /// <param name="CCY">Currency</param>
       /// <returns>true = date is bankingdate
       ///  false = date is not bankingdate</returns>
       public bool CheckBankingDate(DateTime date, string CCY)
       {
           SqlParameter[] parameters = new SqlParameter[2];

           parameters[0] = new SqlParameter("@date", date);
           parameters[1] = new SqlParameter("@ccy", clsLGConstant.MAIN_CCY);
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_CheckBankingDate", CommandType.StoredProcedure, parameters);
           if (reader.Rows.Count > 0)
           {
               return true;
           }
           m_DAL.ClearParameter();
           parameters = new SqlParameter[2];
           if (CCY == null) CCY = "";
           parameters[0] = new SqlParameter("@date", date);
           parameters[1] = new SqlParameter("@ccy", CCY);
           DataTable reader2 = m_DAL.ExecuteDataReader("dbo.spLG_CheckBankingDate", CommandType.StoredProcedure, parameters);
           if (reader2.Rows.Count > 0)
           {
               return true;
           }
           return false;
       }
       /// <summary>
       /// Get rate of currency pair
       /// </summary>
       /// <param name="date"></param>
       /// <param name="cyyPair"></param>
       /// <returns></returns>
       public decimal GetRate(DateTime date, string cyyPair)
       {
           decimal result = -1;
           SqlParameter[] parameters = new SqlParameter[2];

           parameters[0] = new SqlParameter("@date", date);
           parameters[1] = new SqlParameter("@ccyPair", cyyPair);
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetRate", CommandType.StoredProcedure, parameters);

           if (reader.Rows.Count > 0)
           {
               string rate = (string)reader.Rows[0][0];
               result = decimal.Parse(rate);
           }


           return result;
       }
       /// <summary>
       /// list parameter about CCY : VND, JPY.... Which have no decimal place 
       /// </summary>
       public void GetMainCCY()
       {
           List<ParameterDTO> lst = new List<ParameterDTO>();
           SqlParameter[] parameters = new SqlParameter[2];
           mainCCY = new List<string>();

           parameters[0] = new SqlParameter("@module", "LG");
           parameters[1] = new SqlParameter("@type", "012");
           DataTable reader = m_DAL.ExecuteDataReader("dbo.spLG_GetParameters", CommandType.StoredProcedure, parameters);
           if (reader.Rows.Count > 0)
           {
               
               for (int i = 0; i < reader.Rows.Count; i++)
               {
                 ParameterDTO para =   new ParameterDTO(reader.Rows[i]);
                 mainCCY.Add(para.Value);  
               }
           }
           
       }

    }
}
