﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: htkhiem $
 * $Date: 2013-01-08 20:37:30 +0700 (Mon, 08 Jan 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to provide function to create word file
 * for LG module.
 */
using System;
using System.Collections;
using System.IO;
using Microsoft.Office.Interop.Word;
using Word = Microsoft.Office.Interop.Word;

namespace Phoenix.Lg.Common
{
    /// <summary>
    /// Summary description for WordBase
    /// </summary>
    public class clsLGWordBase
    {
        #region Member Functions
      //  private SaveFileDialog saveDialog;

        object wordApp;
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        public clsLGWordBase() { }

        /// <summary>
        /// Function to create a word document.
        /// </summary>
        /// <param name="fileName">Name of word</param>
        /// <param name="wordApplication">Word application</param>
        /// <param name="isReadonly">open mode</param>
        /// <returns>If word document exist, return word doc object
        /// else return null</returns>		
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        public object CreateWordDoc(object fileName, object wordApplication, bool isReadonly, string projectName, string templateName, DateTime CurrentDate)
        {
            Word.Document wordDoc = null;
            Word.Application wordApp = null;
            string path = AppDomain.CurrentDomain.BaseDirectory + projectName + "_GUI\\REPORT\\TEMPLATE\\";

            CreateTemplate(ref path, templateName.ToString(), fileName.ToString(), CurrentDate.ToString("yyyyMMddHHmmssFF"));

            string newFileName = fileName.ToString().Remove(fileName.ToString().Length - 4, 4) + "_" + CurrentDate.ToString("yyyyMMdd") + ".doc";
            fileName = fileName.ToString().Remove(fileName.ToString().Length - 4, 4) + "_" + CurrentDate.ToString("yyyyMMddHHmmssFF") + ".doc";

            fileName = System.IO.Path.Combine(path, fileName.ToString());

            if (wordApplication != null)
            {
                wordApp = wordApplication as Word.ApplicationClass;
            }
            if (File.Exists(fileName.ToString()) && wordApp != null)
            {
                object readOnly = isReadonly;
                object isVisible = false;
                object missing = System.Reflection.Missing.Value;
                DirectoryInfo drInfo = new DirectoryInfo((new FileInfo(fileName.ToString())).Directory.FullName);

                wordDoc = wordApp.Documents.Add(ref fileName, ref missing, ref missing, ref isVisible);
                wordDoc.Activate();

                //+ Title for [Title] Bar
                wordApp.Caption = newFileName;

                //+ Title for [Save] Dialog
                System.Type dlgType = typeof(Word.Dialog);
                Word.Dialog dlg = wordApp.Dialogs[Microsoft.Office.Interop.Word.WdWordDialog.wdDialogFileSummaryInfo];
                // Set the appropriate property of the dialog box.
                char[] ReservedChars = { '-', '_', '/', ':', '*', '?', '"', '<', '>', '|', '\'', '#', '@', '$', '%', '^' };
                foreach (char strChar in ReservedChars)
                {
                    newFileName = newFileName.Replace(strChar.ToString(), " ");
                }
                dlgType.InvokeMember("Title", System.Reflection.BindingFlags.SetProperty | System.Reflection.BindingFlags.Instance,
                            null, dlg, new object[] { newFileName }, null);
                dlg.Execute();

                foreach (FileInfo fileInfo in drInfo.GetFiles())
                {
                    if (!IsFileLocked(fileInfo))
                    {
                        fileInfo.Delete();
                    }                        
                }
            }
            return wordDoc;
        }

        /// <summary>
        /// Create template before expoer report
        /// </summary>
        /// <param name="path"></param>
        /// <param name="name"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        public void CreateTemplate(ref string path, string templateName, string fileName, string serverDate)
        {
            //String appData = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Template");
            String appData = System.IO.Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "Template");

            try
            {
                if (!System.IO.Directory.Exists(appData))
                {
                    System.IO.Directory.CreateDirectory(appData);
                }
            }
            catch (Exception ex) { }

            string strFilePath = path;

            fileName = fileName.Remove(fileName.Length - 4, 4) + "_" + serverDate + ".doc";

            try
            {
                if (!System.IO.File.Exists(appData + "\\" + fileName))
                {
                    System.IO.File.Copy(strFilePath + "\\" + templateName, appData + "\\" + fileName);
                    path = appData;
                }
            }
            catch (Exception ex) { }
        }

        /// <summary>
        /// Function to create a word application
        /// </summary>
        /// <returns>Returns a word application</returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        public object CreateWordApplication()
        {
            Word.Application wordApp = new Word.ApplicationClass();
            return wordApp;
        }

        /// <summary>
        /// Function to close a word document.
        /// </summary>
        /// <param name="wordDocument">Document Object to close</param>
        /// <param name="canSaveChange">Need to save changes or not</param>
        /// <returns>True if successfully closed.</returns>		
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        public bool CloseWordDoc(object wordDocument, bool canSaveChange)
        {
            bool isSuccess = false;
            if (wordDocument != null)
            {
                object missing = System.Reflection.Missing.Value;
                object saveChanges = null;
                if (canSaveChange)
                {
                    saveChanges = Word.WdSaveOptions.wdSaveChanges;
                }
                else
                {
                    saveChanges = Word.WdSaveOptions.wdDoNotSaveChanges;
                }
                Word.Document wordDoc = wordDocument as Word.Document;
                ((_Document)wordDoc).Close(ref saveChanges, ref missing, ref missing);
                isSuccess = true;
            }
            return isSuccess;
        }

        /// <summary>
        /// Function to close word application
        /// </summary>
        /// <param name="wordApplication">Word application to close</param>
        /// <returns>True if successfully closed</returns>		
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        public bool CloseWordApp(object wordApplication)
        {
            bool isSuccess = false;
            if (wordApplication != null)
            {
                object missing = System.Reflection.Missing.Value;
                object saveChanges = Word.WdSaveOptions.wdSaveChanges;
                Word.Application wordApp =
                    wordApplication as Word.ApplicationClass;
                ((_Application)wordApp).Quit(ref saveChanges, ref missing, ref missing);
                isSuccess = true;
            }
            return isSuccess;
        }

        /// <summary>
        /// Function to find and replace a given text.
        /// </summary>
        /// <param name="wordDoc">Word Document</param>
        /// <param name="findText">Text for finding</param>
        /// <param name="replaceText">Text for replacing</param>
        /// <param name="wordApplication">Word Application</param>
        /// <returns>True if successfully replaced.</returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        public bool FindReplace(object wordDoc, object wordApplication, string findText, string replaceText)
        {
            bool isSuccess = false;
            do
            {
                if (wordDoc == null)
                {
                    break;
                }
                if (wordApplication == null)
                {
                    break;
                }
                //Prevent replacing Empty Text
                //if (replaceText.Trim().Length == 0)
                //{
                //    break;
                //}
                //if (findText.Trim().Length == 0)
                //{
                //    break;
                //}
                Word.Application wordApp =
                    wordApplication as Word.ApplicationClass;
                Word.Document wordDocument = wordDoc as Word.Document;                

                //Replace Text in [Content] Section
                ReplaceRange(wordDocument.Content,
                    wordDocument, wordApp, findText, replaceText);

                //Replace Text in [Comment] Section
                //foreach (Word.Comment comment in wordDocument.Comments)
                //{
                //    ReplaceRange(comment.Range,
                //        wordDocument, wordApp, findText, replaceText);
                //}

                //Replace Text in [Header] Section
                //foreach (Word.HeaderFooter header in
                //    wordDocument.Sections.Last.Headers)
                //{
                //    ReplaceRange(header.Range,
                //        wordDocument, wordApp, findText, replaceText);
                //}

                //Replace Text in [Footer] Section
                //foreach (Word.HeaderFooter footer in
                //    wordDocument.Sections.Last.Footers)
                //{
                //    ReplaceRange(footer.Range,
                //        wordDocument, wordApp, findText, replaceText);
                //}
                
                foreach (Word.Shape shp in wordDocument.Shapes)
                {
                    if (shp.TextFrame.HasText < 0)
                    {
                        ReplaceRange(shp.TextFrame.TextRange,
                            wordDocument, wordApp, findText, replaceText);
                    }
                }
                isSuccess = true;
            }
            while (false);
            return isSuccess;
        }

        /// <summary>
        /// Function to find and replace a given List.
        /// </summary>
        /// <param name="wordDoc">Word Document</param>
        /// <param name="wordApplication">Word Application</param>
        /// <param name="htData">List of values</param>
        /// <returns>True if successfully replaced.</returns>
        public bool FindReplace(object wordDoc, object wordApplication, Hashtable htData)
        {
            wordApp = wordApplication;
            bool isSuccess = false;
            ((Word.Application)wordApp).ScreenUpdating = false;
            ((Word.Application)wordApp).ActiveWindow.ActivePane.View.Type = WdViewType.wdPrintView;
            foreach (DictionaryEntry entry in htData)
            {                
                isSuccess = FindReplace(wordDoc, wordApp, entry.Key.ToString(), entry.Value.ToString());
            }
            ((Word.Application)wordApp).ScreenUpdating = true;
            ((Word.Application)wordApp).Visible = true;
            return isSuccess;
        }

        /// <summary>
        /// Replace a word with in a range.
        /// </summary>
        /// <param name="range">Range to replace</param>
        /// <param name="wordDocument">Document to replace</param>
        /// <param name="wordApp">Word Application</param>
        /// <param name="findText">Text to find</param>
        /// <param name="replaceText">Text to replace</param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond 
        private void ReplaceRange(Word.Range range, Word.Document wordDocument, Word.Application wordApp, object findText, object replaceText)
        {
            object missing = System.Reflection.Missing.Value;
            wordDocument.Activate();
            object item = Word.WdGoToItem.wdGoToPage;
            object whichItem = Word.WdGoToDirection.wdGoToFirst;
            object forward = true;
            wordDocument.GoTo(ref item, ref whichItem,
                ref missing, ref missing);
            object replaceAll = Word.WdReplace.wdReplaceAll;
            object matchAllWord = true;
            range.Find.ClearFormatting();
            range.Find.Replacement.ClearFormatting();
            range.Find.Execute(ref findText, ref missing, ref matchAllWord,
                ref missing, ref missing, ref missing, ref forward,
                ref missing, ref missing, ref replaceText, ref replaceAll,
                ref missing, ref missing, ref missing, ref missing);
        }

        /// <summary>
        /// This function is used to check specified file being used or not
        /// </summary>
        /// <param name="file">FileInfo of required file</param>
        /// <returns>If that specified file is being processed 
        /// or not found is return true</returns>
        public static Boolean IsFileLocked(FileInfo file)
        {
            FileStream stream = null;

            try
            {                
                stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
            }
            catch (IOException)
            {                
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }
            
            return false;
        }
        #endregion
    }

    /// <summary>
    /// C# Word Automation: Solve “The RPC server is unavailable. (Exception from HRESULT: 0x800706BA)”
    /// </summary>
    public class clsLGDocumentExporter
    {
        static ApplicationClass _word_application;

        public static ApplicationClass AppClass
        {
            get
            {

                if (_word_application == null)
                {
                    _word_application = new ApplicationClass();
                    _word_application.ApplicationEvents2_Event_Quit += new ApplicationEvents2_QuitEventHandler(_word_application_ApplicationEvents2_Event_Quit);
                }
                return _word_application;
            }
        }

        static void _word_application_ApplicationEvents2_Event_Quit()
        {
            _word_application = null;
        }
    }
}