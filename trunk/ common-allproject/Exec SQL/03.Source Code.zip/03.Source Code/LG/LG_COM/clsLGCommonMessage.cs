﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define common message
 * for LG module.
 */

namespace Phoenix.Lg.Com
{
	public class clsLGCommonMessage
	{
		#region LG Message List
		public static readonly string CONFIRM_ACTION = "Are you sure to {0} {1}?";		
        public static readonly string CONFIRM_DETELE = "Are you sure you want to delete {0} {1}?";
		public static readonly string CONFIRM_SAVE_CHANGES = "Do you want to save changes?";
        public static readonly string CONFIRM_SELECTED_ROWS = "Do you want to process selected data?";        

		public static readonly string ERROR_ACTION_FAIL = "{0} {1} is fail.";
		public static readonly string INFOR_ACTION_SUCCESS = "{0} {1} is successful.";
                
        public static readonly string ERROR_CAN_NOT_DELETE = "Can not delete {0} {1}.";
        public static readonly string ERROR_CLAIM_WAS_PAYMENT = "This claim already was payment, you cannot remove.";
		public static readonly string ERROR_IS_EXISTED = "{0} is existed, please input another {1}.";
		public static readonly string ERROR_IS_DELETE = "[{0}] is deleted by another user.";
        public static readonly string INFOR_CHOOSE_VALUE_COMBOBOX = "Please choose a value from {0} combobox.";

        public static readonly string ERROR_FIELD_IS_NULL = "Please input {0}.";
        public static readonly string ERROR_COMPARE_FIELD = "{0} must be less than or equal {1}.";
		public static readonly string FIELD_REQUIRED = "{0} is required.";
		public static readonly string FIELD_EXISTED = "{0} existed.";
		public static readonly string FIELD_NOT_EXISTED = "{0} not existed.";      

        public static readonly string PLEASE_INPUT = "Please input {0}";        

        public static readonly string EXPRIREDATE_GREATER_VALUEDATE = "Expire Date should be greater than or equal Value Date.";
        public static readonly string LGRATE_LESS_THAN = "LG Rate should be less than or equal 2";
        public static readonly string LGRATE_GREATE_THAN = "LG Rate should be great than or equal 0";
        public static readonly string LG_SUCCESS = "LG No {0} was saved successfully!";
        public static readonly string DO_YOU_WANT_SAVE = "Do you want to save changes?";
        public static string CANNOT_CREATE_FEE_SCHEDULE = "Can not create Fee Schedule Collection, because one or more LG Detail already have Date of actual collection.";
        public static string BENEFICIARY_NOT_EXIST = " again.Selected Beneficiary does not exist";
        public static string EXPIREDATE_IS_NOT_BANKING_DATE = "Expire Date must be banking date.";
        public static string VALUEDATE_IS_NOT_BANKING_DATE = "Value Date must be banking date.";
        public static string CHANGE_CUSTOMER_CONFIRM = "Do you want to change customer?";
        public static string APPLICANT_NOT_EXIST = " again. Selected Applicant does not exist";
        public static string RECIEVE_CURRENT = "Receive Date must be smaller or equal current date.";
        public static string ACTUAL_CLAIM = "Actual Claim Date must be greater or equal Claim Date.";
        public static string CLAIM_BANKING = "Claim Date must be banking date.";
        public static string CANNOT_GET_RATE = "Can not get suitable Exchange Rate.";
        public static string NO_TRANS_FOUND = "No transaction found";
        public static string FILE_NOT_INVALID = "File data is invalid.";
        public static string OVERDULE_WAS_REPAYMENTED = "This overdue collection schedule already was payment, you cannot remove.";
        public static string FEE_WAS_REPAYMENT = "This fee collection schedule already was payment, you cannot remove.";    
        #endregion
	}
}