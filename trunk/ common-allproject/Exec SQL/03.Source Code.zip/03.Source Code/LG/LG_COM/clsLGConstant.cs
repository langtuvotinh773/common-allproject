﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to define constant
 * for LG module.
 */
using System;

namespace Phoenix.Lg.Com
{
    public class clsLGConstant
    {
        #region FORM NAME
        public const string OVERDUE_COLLECTION_SCHEDULE = "Overdue Collection Schedule";
        public const string LG_FEE_COLLECTION_SCHEDULE = "LG Fee Collection Schedule";
        #endregion


        #region FIELD LENGTH

        #region CREATE APPLICANT MAX LENGHT
        public const int LENGTH_APPLICANT_CODE = 6;
        public const int LENGTH_APPLICANT_NAME = 200;
        public const int LENGTH_APPLICANT_ADDRESS = 200;
        public const int LENGTH_APPLICANT_NATIONAL = 200;
        public const int LENGTH_APPLICANT_TEL = 50;
        public const int LENGTH_APPLICANT_FAX = 50;
        public const int LENGTH_CREATED_BY = 20;
        #endregion

        #region CREATE BENEFICIARY MAX LENGHT
        public const int LENGTH_BENEFICIARY_ADDRESS = 200;
        public const int LENGTH_BENEFICIARY_CODE = 6;
        public const int LENGTH_BENEFICIARY_FAX = 50;
        public const int LENGTH_BENEFICIARY_NAME = 200;
        public const int LENGTH_BENEFICIARY_NATIONAL = 200;
        public const int LENGTH_BENEFICIARY_TEL = 50;
        #endregion

        #region AMEND, UDPATE, CORRECT, TERMINATE
        public const int LENGTH_GL_CODE = 8;
        public const int LENGTH_LG_RATE = 7;
        public const int LENGTH_CONTRACT_INFORMATION = 200;
        public const int LENGTH_REPRESENTATION_1 = 100;
        public const int LENGTH_REPRESENTATION_2 = 100;
        public const int LENGTH_REPRESENTATION_3 = 100;
        public const int LENGTH_REMARK = 500;
        #endregion

        #region OVERDUE COLLECTION FEE
        public const int LENGTH_CUSTOMER_NAME = 80;
        public const int LENGTH_CUSTOMER_CODE = 8;
        public const int LENGTH_LG_CODE = 9;

        #endregion

        #endregion

        #region CURRENCY
        public const string LG_CURRENCY_VND = "VND";
        public const string LG_CURRENCY_USD = "USD";
        public const string LG_CURRENCY_JPY = "JPY";        
        #endregion

        public const string LG_CALCULATE_TYPE3 = "313";
        public const string LG_CALCULATE_TYPE2 = "213";
        public const string LG_CALCULATE_TYPE1 = "113";

        public const string LG_COUNTER_ACCOUNT = "310-1000-000019";

        #region ACTION NAME
        public const string ACTION_CREATE = "Create";
        public const string ACTION_UPDATE = "Update";
        public const string ACTION_DELETE = "Delete";
        public const string ACTION_SAVE = "save";
        public const string ACTION_LOCK = "Lock";
        public const string ACTION_UNLOCK = "Unlock";
        public const string ACTION_RETURN = "Return";
        public const string ACTION_SAVING = "Saving";
        public const string ACTION_CREATING = "Creating";        
        #endregion

        #region Field Name
        public const string BENEFICIARY_NAME = "Beneficiary";
        public const string APPLICANT_NAME = "Applicant";

        public const string EXCHANGE_RATE_NAME = "Exchange Rate";
        public const string LG_STAFF_NAME = "LG Code";
        public const string LG_SUPERVISOR_NAME = "LG Code";
        public const string CONDITON_TERMINATE = "Condition Of Terminate";
        public const string OVERDUE_FEE = "Overdue Fee";
        public const string OVERDUE_CURRENCY = "Overdue Currency";
        public const string CLAIM_NAME = "Claim";
        public const string LG_CLAIM_NAME = "LG Claim";
        public const string LG_NumReportSBV = "NumReportSBV";
        
        #endregion

        #region FORMAT DATETIME
        public const string LG_FORMAT_YEAR_MONTH = "yyyyMM";
        public const string LG_FORMAT_YEAR_MONTH_DAY = "{0:yyyy/MM/dd}";
        public const string LG_FORMAT_MONTH_YEAR = "MMyyyy";
        public const string LG_FORMAT_STANDARD = "MM/yyyy";
        public const string LG_FORMAT_YYYYMMDD = "yyyy/MM/dd";
        public const string LG_FORMAT_YYYY_MM_DD = "yyyyMMdd";
        public const string LG_FORMAT_MMM_yy = "MMM-yy";
        public const string LG_FORMAT_DDMMMYY = "dd-MMM-yy";
        public const string LG_FORMAT_DAY = "dd";
        public const string LG_FORMAT_MONTH = "MM";
        public const string LG_FORMAT_MONTH_NAME = "MMMM";
        public const string LG_FORMAT_YEAR = "yyyy";
        #endregion

        #region MASTER VALUE
        public const string LG_CATEGORY_PROPER = "253-1000";
        public const string LG_CATEGORY_COUNTER = "257-1000";
        public const string MAIN_CCY = "VND";
        #endregion


        #region Name Main Form
        public const string MAIN_FORM_NAME = "MainForm";
        #endregion

        #region Reported Company Name for Non Resident Applicant
        #endregion

        #region PARAMETER TYPE
        public const string LG_MODULE = "LG";
        public const string LG_LG_TYPE = "001";
        public const string LG_GL_TYPE = "002";
        public const string LG_GUARANTEE_TYPE = "003";
        public const string LG_CALCULATE_TYPE = "004";
        public const string LG_IN_CASE_OF_PROPER_LG = "005";
        public const string LG_IN_CASE_OF_COUNTER_LG = "006";
        public const string LG_FEE_TYPE = "007";
        public const string LG_LG_SECURITY = "008";
        public const string LG_PRINT_FORM = "009";
        public const string LG_LG_STATUS = "010";
        public const string LG_COMPNAY_NAME = "011";
        public const string LG_FORM_TO_SBV_FILE = "013";
        //2013.05.02 ADD HTK S Fix Feedback 20130514 
        public const string LG_PRINT_FORM_MIN_LABEL = "MIN ({0})";
        //2013.05.02 ADD HTK E Fix Feedback 20130514 
        #endregion

        #region NAME FORM SEARCH PAGE DOWN
        public const string LG_NAME_FORM_SEARCH_BENEFICIARY = "Beneficiary";
        public const string LG_NAME_FORM_SEARCH_APPLICANT = "Applicant";
        #endregion

        #region REPORT FILE NAME
        public const string LG_REPORT_LETTER_OF_GUARANTEE_NEW_ENTRY = "LETTER OF GUARANTEE - NEW ENTRY";
        public const string LG_REPORT_LETTER_OF_GUARANTEE_TERMINATION = "LETTER OF GUARANTEE - TERMINATION";
        public const string LG_REPORT_LIST_LG_STAFF = "LIST LG STAFF";
        public const string LG_REPORT_LIST_LG_SUPERVISOR = "LIST LG SUPERVISOR";        
        #endregion

        #region REPORT FILE TEMPLATE
        public const string LG_REPORT_LETTER_OF_GUARANTEE_NEW_ENTRY_TEMPLATE = "LETTER OF GUARANTEE - NEW ENTRY.xls";
        public const string LG_REPORT_LETTER_OF_GUARANTEE_TERMINATION_TEMPLATE = "LETTER OF GUARANTEE - TERMINATION.xls";
        public const string LG_REPORT_LIST_LG_STAFF_TEMPLATE = "List LG Staff.xls";
        public const string LG_REPORT_LIST_LG_SUPERVISOR_TEMPLATE = "List LG Supervisor.xls";
        #endregion

        #region FORMAT NUMBER
        public static string FORMAT_NUMBER_ON_DATAGRID = "#,###.#####";
        public static string FORMAT_NUMBER_N5 = "N5";
        public static string FORMAT_NUMBER_N2 = "N2";
        public static string FORMAT_NUMBER_N = "N0";
        public const string FORMAT_DECIMAL = "#,0.00000";
        public const string FORMAT_EXCEL_2_DECIMAL = "#,##0.00";
        public const string FORMAT_EXCEL_0_DECIMAL = "#,##0 ";
        public static int NUMBERDECIMAL = 5;
        #endregion

        #region GUARANTEE TYPE VALUE
        public static string GUARANTEE_VALUE_BB = "651";
        public static string GUARANTEE_VALUE_PB = "741";
        public static string GUARANTEE_VALUE_RF = "771";
        public static string GUARANTEE_VALUE_CB = "781";
        #endregion

        #region GUARANTEE TYPE NAME
        public static string GUARANTEE_NAME_BB = "BB";
        public static string GUARANTEE_NAME_PB = "PB";
        public static string GUARANTEE_NAME_RF = "RF";
        public static string GUARANTEE_NAME_CB = "CB";
        #endregion

        #region MIN MAX DATETIME SERVER
        public static DateTime MIN_DATE_SERVER = new DateTime(1753, 1, 1, 0, 0, 0);
        public static DateTime MAX_DATE_SERVER = DateTime.MaxValue;
        #endregion

        #region DAY WEEK
        public const string DAY_WEEK_EN_MON = "Monday";
        public const string DAY_WEEK_EN_TUE = "Tuesday";
        public const string DAY_WEEK_EN_WED = "Wednesday";
        public const string DAY_WEEK_EN_THU = "Thursday";
        public const string DAY_WEEK_EN_FRI = "Friday";
        public const string DAY_WEEK_EN_SAT = "Saturday";
        public const string DAY_WEEK_EN_SUN = "Sunday";

        public const string DAY_WEEK_VN_MON = "Thứ hai";
        public const string DAY_WEEK_VN_TUE = "Thứ ba";
        public const string DAY_WEEK_VN_WED = "Thứ tư";
        public const string DAY_WEEK_VN_THU = "Thứ năm";
        public const string DAY_WEEK_VN_FRI = "Thứ sáu";
        public const string DAY_WEEK_VN_SAT = "Thứ bảy";
        public const string DAY_WEEK_VN_SUN = "Chủ nhật";
        #endregion

        #region Used for Reporting Controlling Book
        public const string LG_LG_STATUS_NEW = "1-New";
        public const string LG_LG_STATUS_CORRECT = "2-Cor";
        public const string LG_LG_STATUS_AMEND_UPDATE = "3-Udp";
        public const string LG_LG_STATUS_AMEND = "4-Amd";

        public const string LG_REPORT_TITLE = "GUARANTEE CONTROLLING BOOK";
        public const string LG_REPORT_LG_TYPE_PROPER = "(PROPER L/G)";
        public const string LG_REPORT_LG_TYPE_COUNTER = "(COUNTER L/G)";
        public const int LG_REPORT_NUMBER_OF_ROWS_PER_PAGES = 10;
        #endregion

        #region Parameter value report SBV file
        public const string LG_REPORT_SBV_NAMEBTMUBANK = "1";
        public const string LG_REPORT_SBV_ADDRESSBTMUBANK = "2";
        public const string LG_REPORT_SBV_TELBTMUBANK = "3";
        public const string LG_REPORT_SBV_FAXBTMUBANK = "4";
        public const string LG_REPORT_SBV_NUMBER = "5";
        public const string LG_REPORT_SBV_CONSTDATE = "6";
        #endregion

        //2013.05.09 ADD HTK S Smile Interface
        #region Used to export smile interface
        public const string SMILE_INTERFACE_STATUS_NOT_YET = "Not Yet";
        public const string SMILE_INTERFACE_STATUS_SUCCESSFUL = "Successful";
        public const string SMILE_INTERFACE_STATUS_FAILED = "Failed";
        #endregion
        //2013.05.09 ADD HTK E Smile Interface
    }
}