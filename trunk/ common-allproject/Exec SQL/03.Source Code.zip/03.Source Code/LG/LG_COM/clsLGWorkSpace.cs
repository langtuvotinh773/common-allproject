﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: htkhiem $
 * $Date: 2013-01-08 20:37:30 +0700 (Mon, 08 Jan 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to provide function to create word file
 * for LG module.
 */
using Phoenix.Lg.Gui.Forms;

namespace Phoenix.Lg.Common
{
    public class clsLGWorkSpace
    {
        private static clsLGWorkSpace workspace;

        public static clsLGWorkSpace Instance()
        {
            if (workspace == null) workspace = new clsLGWorkSpace();
            return workspace;
        }


        private frmLGIssue frmIssue;

        public frmLGIssue FrmIssue
        {
            get { return frmIssue; }
            set { frmIssue = value; }
        }



    }
}
