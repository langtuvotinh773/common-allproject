﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define common function
 * for LG module.
 */
using System;
using System.Collections;
using System.Reflection;
using System.Windows.Forms;
using Phoenix.Lg.Bus;

namespace Phoenix.Lg.Com
{
    public static class clsLGCommonFunction
    {
        /// <summary>
        /// Instances this instance.
        /// </summary>
        /// <returns></returns>
        //public CCommonFunction()
        //{ }
        public static void DoubleBuffered(this DataGridView dgv, bool setting)
        {
            Type dgvType = dgv.GetType();
            PropertyInfo pi = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
            pi.SetValue(dgv, setting, null);
        }

        /// <summary>
        /// Function trust function as a parameter
        /// </summary>
        /// <param name="method"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        static object InvokeMethod(Delegate method, params object[] args)
        {
            return method.DynamicInvoke(args);
        }

        /// <summary>
        /// Fill combobox data
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="cbb"></param>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public static void FillComboboxData(Func<ArrayList> methodName, ComboBox cbb)
        {
            cbb.DataSource = null;
            cbb.Items.Clear();
            ArrayList arrDataForCombobox = new ArrayList();
            arrDataForCombobox = (ArrayList)InvokeMethod(new Func<ArrayList>(methodName));
            if (arrDataForCombobox.Count == 0)
                return;
            cbb.DataSource = arrDataForCombobox;
            cbb.DisplayMember = "Display";
            cbb.ValueMember = "Value";

        }

        /// <summary>
        /// Fill combobox data
        /// </summary>
        /// <param name="arrList"></param>
        /// <param name="cbb"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public static void FillComboboxData(ArrayList arrList, ComboBox cbb)
        {
            cbb.DataSource = null;
            cbb.Items.Clear();
            if (arrList.Count == 0)
                return;
            cbb.DataSource = arrList;
            cbb.DisplayMember = "Display";
            cbb.ValueMember = "Value";

        }

        /// <summary>
        /// Get Display in array list
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Nguyen Danh Tho
        /// @endcond
        public static string GetDisplay(ArrayList arr, string value)
        {
            foreach (CbbObject obj in arr)
            {
                if (obj.Value.ToString().Trim() == value)
                {
                    return obj.Display.ToString().Trim();
                }
            }
            return "";
        }

        /// <summary>
        /// Get Week Day VN
        /// </summary>
        /// <param name="weekDay"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public static string GetWeekDayVN(string weekDay)
        {
            switch (weekDay)
            {
                case clsLGConstant.DAY_WEEK_EN_MON:
                    return clsLGConstant.DAY_WEEK_VN_MON;
                    
                case clsLGConstant.DAY_WEEK_EN_TUE:
                    return clsLGConstant.DAY_WEEK_VN_TUE;
                    
                case clsLGConstant.DAY_WEEK_EN_WED:
                    return clsLGConstant.DAY_WEEK_VN_WED;
                    
                case clsLGConstant.DAY_WEEK_EN_THU:
                    return clsLGConstant.DAY_WEEK_VN_THU;
                    
                case clsLGConstant.DAY_WEEK_EN_FRI:
                    return clsLGConstant.DAY_WEEK_VN_FRI;
                    
                case clsLGConstant.DAY_WEEK_EN_SAT:
                    return clsLGConstant.DAY_WEEK_VN_SAT;
                    
                case clsLGConstant.DAY_WEEK_EN_SUN:
                    return clsLGConstant.DAY_WEEK_VN_SUN;
                default:
                    break;
            }
            return "";
        }
    }
}