﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-13 20:37:30 +0700 (Wed, 13 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for setting common form style
 * of LG module.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Phoenix.Lg.Com;
using Config.Classes;
using System.Collections;
using Phoenix.Common.Popup;
using Phoenix.Lg.Dto;
using Phoenix.Common.Security.Com;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGMaster : Form
    {
        public delegate void InvokeDelegate();
        public List<clsLGFeeScheduleDTO> LstFeeSchedule; // List Fee schedule use for Issue and Correct
        public string m_LGType = "";// LG Type use for Issue, Amend update correc...

        public bool IsFeeChange = false;
        public bool ForceClose = false;
        Size oldSize = new Size(0, 0); // use for process event maximize and minimize
        Point oldPos = new Point(0, 0);
        // For Security Checking
        public clsSEAuthorizer _security = null;
        /// <summary>
        /// Constructor of master form
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public frmLGMaster()
        {
            InitializeComponent();
            SetFormStyleCommon();            
        }

        bool currentState = false;
        /// <summary>
        /// process special event
        /// </summary>
        /// <param name="m"></param>
        protected override void WndProc(ref Message m)
        {
            if (this.Parent != null)
            {
                if (m.Msg == 0x0112) // WM_SYSCOMMAND
                {
                    if (m.WParam == new IntPtr(0xF032))
                    {
                        m.WParam = new IntPtr(0xF030);
                    }
                    if (m.WParam == new IntPtr(0xF030)) // SC_MINIMIZE
                    {
                        if (currentState == false)
                        {
                            //save size and location
                            oldSize = this.Size;
                            oldPos = this.Location;


                            m.WParam = new IntPtr(0xF120); // normal windown
                            this.Size = this.Parent.ClientSize;
                            this.Location = new Point(0, 0);
                            currentState = true;
                        }
                        else
                        {
                            m.WParam = new IntPtr(0xF120);
                            this.Size = oldSize;
                            this.Location = oldPos;
                            currentState = false;
                        }


                    }

                    if (m.WParam == new IntPtr(0xF012))
                    {
                        if (this.Parent != null)
                        {
                            if (this.Size == this.Parent.ClientSize)
                            {
                                return;
                            }
                        }
                    }
                    //  Console.WriteLine(m.ToString());
                    m.Result = new IntPtr(0);
                }
            }
            base.WndProc(ref m);
        }
        /// <summary>
        /// Set common style for all forms in LG project
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public void SetFormStyleCommon()
        {
            this.BackColor = clsCommonStyles.Instance().FormBG;
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            SetFormStyleCommon(this);
        }
        /// <summary>
        /// Set common style for all controls in LG project
        /// </summary>
        /// <param name="controls"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public virtual void SetFormStyleCommon(Control controls)
        {
            foreach (Control c in controls.Controls)
            {
                if (c is Label)
                    c.BackColor = clsCommonStyles.Instance().LabelBG;
                else if (c is DataGridView)
                {
                    DataGridView grid = (DataGridView)c;
                    
                    grid.AllowUserToOrderColumns = false;
                    grid.AllowUserToResizeColumns = false;
                    grid.AllowUserToResizeRows = false;
                    grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                    grid.EnableHeadersVisualStyles = false;
                    grid.AlternatingRowsDefaultCellStyle = clsCommonStyles.Instance().DGVAlternatingRowsDefaultCellStyle;
                    grid.ColumnHeadersDefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVColumnHeaderBG;
                    grid.CellClick += new DataGridViewCellEventHandler(grid_CellClick);
                    grid.DefaultCellStyle.SelectionBackColor = clsCommonStyles.Instance().DGVSelectionBackColor; //clsCommonStyles.Instance().DGVReadOnlyColumnBG;		
                    grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    if (grid.ReadOnly == true)
                    {
                        grid.StandardTab = true;
                        grid.DefaultCellStyle.BackColor = Config.Classes.clsCommonStyles.Instance().DGVReadOnlyColumnBG;
                    }
                    else
                    {
                        //grid.SelectionMode = DataGridViewSelectionMode.CellSelect ;
                        grid.StandardTab = false;
                    }
                    for (int i = 0; i < grid.Columns.Count; i++)
                    {
                        if (grid.Columns[i].ReadOnly == true)
                        {
                            grid.Columns[i].DefaultCellStyle.BackColor = Config.Classes.clsCommonStyles.Instance().DGVReadOnlyColumnBG;
                        }
                        grid.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                    clsLGCommonFunction.DoubleBuffered(grid, true);
                }
                else if (c is Button)
                    c.BackColor = clsCommonStyles.Instance().ButtonBG;
                else if (c is GroupBox)
                    SetFormStyleCommon(c);
				else if (c is UserCtrl.DisableTextBox)
				{
                    c.BackColor = clsCommonStyles.Instance().ReadOnlyTextBoxBG;
					c.ForeColor = Color.Black;
				}
				else if (c is TextBox)
					c.ImeMode = ImeMode.Disable;
				else if (c is ComboBox)
					((ComboBox) c).DropDownStyle = ComboBoxStyle.DropDownList;
            }
        }

       

        

        /// <summary>
        /// Gridview header cell click event (sort and align header content to be center)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public void grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView grid = (DataGridView)sender;
			if (e.RowIndex == -1 && e.ColumnIndex != -1)
			{
				DataGridViewCheckBoxColumn column = grid.Columns[e.ColumnIndex] as DataGridViewCheckBoxColumn;
				if (column == null)
				{
					grid.Columns[e.ColumnIndex].SortMode = DataGridViewColumnSortMode.Automatic;
				}				
				for (int i = 0; i < grid.Columns.Count; i++)
					if (i != e.ColumnIndex)
					{
						grid.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;						
					}
			}
        }

        /// <summary>
        /// Set format for number belong to selcted currency value
        /// </summary>
        /// <param name="combobox"></param>
        /// <param name="textbox"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public void SetCurrencyFormat(ComboBox combobox, UserCtrl.NumberOnlyTextBoxIsEmpty textbox)
        {
            try
            {
                //Set properties for TextBox
                if (combobox.Text.Equals(clsLGConstant.LG_CURRENCY_VND) || combobox.Text.Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    if (textbox.Text.Trim() != "")
                    //Do not allow to input decimal
                    {
                        textbox.NeedDecimal = false;
                        textbox.StringFormat = "#,0";
                        textbox.Refresh();
                    }
                }
                else
                {
                    if (textbox.Text.Trim() != "")
                    {
                        textbox.NeedDecimal = true;
                        textbox.StringFormat = "#,0.0000";
                        textbox.Refresh();
                    }
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Call a delegate function
        /// </summary>
        /// <param name="method"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        object InvokeMethod(Delegate method, params object[] args)
        {
            return method.DynamicInvoke(args);
        }

        /// <summary>
        /// Page Up and Page Down key event on combobox
        /// </summary>
        /// <param name="e"></param>
        /// <param name="methodNamePageUp"></param>
        /// <param name="methodNamePageDown"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public void PageUpDownOnCombobox(KeyEventArgs e, Func<DataTable> methodNamePageUp, Func<DataTable> methodNamePageDown)
        {
            if (e.KeyCode == Keys.PageDown)
            {                
                DataTable _dt = (DataTable)InvokeMethod(new Func<DataTable>(methodNamePageDown));
                frmSearchData frm = new frmSearchData(_dt);
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
            }
            else if (e.KeyCode == Keys.PageUp)
            {             
                DataTable _dt = (DataTable)InvokeMethod(new Func<DataTable>(methodNamePageUp));
                frmSearchData frm = new frmSearchData(_dt);
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
            }
        }

        /// <summary>
        /// Fill combobox data
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="cbb"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public void FillComboboxData(Func<ArrayList> methodName, ComboBox cbb)
        {
            try
            {
                cbb.DataSource = null;
                cbb.Items.Clear();
                ArrayList arrResult = new ArrayList();
                arrResult = (ArrayList)InvokeMethod(new Func<ArrayList>(methodName));
                if (arrResult.Count == 0)
                    return;
                cbb.DataSource = arrResult;
                cbb.DisplayMember = "Display";
                cbb.ValueMember = "Value";
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                //clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE); 
            }
        }

		/// Confirm = 0,
		/// Error = 1,
		/// Infomaition =2
		/// <summary>
		/// 
		/// </summary>
		/// <param name="type">Confirm 0, Error 1, Information 2 </param>
		/// <param name="format"></param>
		/// <param name="param"></param>
		/// <returns></returns>
		public static DialogResult ShowMessage(int type, string format, string[] param)
		{
			frmPhoenixMessage frmMsg = new frmPhoenixMessage(type,
														  format, param);
			return frmMsg.ShowDialog();
		}

        /// <summary>
        /// Count Number Of Comlumns On Grid
        /// </summary>
        /// <param name="grid"></param>
        /// <returns></returns>
        public int CountNumberOfComlumnsOnGrid(DataGridView grid)
        {
            int countColumnsOnGrid = 0;
            foreach (DataGridViewColumn col in grid.Columns)
            {
                if (col.Visible == true)
                {
                    countColumnsOnGrid++;
                }
            }
            return countColumnsOnGrid;
        }

        /// <summary>
        /// frmLGMaster_Load & CloseTheForm Used to resole
        /// [When this screen has already openned. If click again,this screen will be focused. (don't open more)]
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmLGMaster_Load(object sender, EventArgs e)
        {
            int numberOfFormOpening = 0;

            foreach (Form OpenForm in Application.OpenForms)
            {
                if (OpenForm.GetType() == this.GetType().UnderlyingSystemType)
                {
                    numberOfFormOpening++;
                    if (numberOfFormOpening > 1)
                    {
                        if (!OpenForm.Modal)
                        {
                            if (!DesignMode)
                            {
                                this.BeginInvoke(new InvokeDelegate(CloseTheForm));
                            }                            
                            OpenForm.Activate();
                            Application.OpenForms[OpenForm.Name].BringToFront();
                        }
                        else
                        {
                            Application.OpenForms[OpenForm.Name].DialogResult = DialogResult.None;
                            Application.OpenForms[OpenForm.Name].Close();
                        }
                        return;
                    }
                }
            }          
        }

        /// <summary>
        /// frmLGMaster_Load & CloseTheForm Used to resole
        /// [When this screen has already openned. If click again,this screen will be focused. (don't open more)]
        /// </summary>
        private void CloseTheForm()
        {
            this.Close();
        }
    }
}