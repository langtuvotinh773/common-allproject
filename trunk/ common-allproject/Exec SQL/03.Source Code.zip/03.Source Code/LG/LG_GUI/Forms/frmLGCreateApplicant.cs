﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-22 16:00:00 +0700 (Fri, 22 Mar 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to create applicant
 * for LG module.
 */

using System;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGCreateApplicant : frmLGMaster
    {
        #region Variables
        private clsLGApplicantDTO m_clsLGApplicantDTO;
        private clsLGApplicantBus m_clsLGApplicantBus;
        public string NewApplicant = "";
        #endregion

        #region Contructor
        /// <summary>
        /// Initializes a new instance of the <see cref="frmFinalizeCPAData" /> class to create applicant 
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmLGCreateApplicant()
        {
            InitializeComponent();
            base.SetFormStyleCommon();
            SetFormStyle();
            m_clsLGApplicantDTO = new clsLGApplicantDTO();
            m_clsLGApplicantBus = new clsLGApplicantBus();
            _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            _security.CheckAuthorizationOnScreen(this);
        }

        #endregion

        #region Event Functions

        /// <summary>
        /// Event btnSave applicant to database
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //show message confirm
                DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                    String.Format(clsLGCommonMessage.CONFIRM_ACTION, clsLGConstant.ACTION_SAVE, clsLGConstant.APPLICANT_NAME));
                if (result == DialogResult.Yes)
                {
                    //insert data
                    SaveData();
                }
                else if (result == DialogResult.No)
                {
                    //close form
                    frmLGCreateApplicant_FormClosing(null, null);
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_clsLGApplicantBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Event btnClose form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Event frorm closing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void frmLGCreateApplicant_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    //[When this screen has already openned. If click again,this screen will be focused. (don't open more)]
                    // => refer form 'frmLGMaster' .Go to function 'frmLGMaster_Load'
                    if (e.CloseReason == CloseReason.UserClosing && btnSave.Tag != null && (bool)btnSave.Tag == true)
                    {
                        //check value on form is changed
                        if (IsChangeValueOnForm())
                        {
                            DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                                clsLGCommonMessage.CONFIRM_SAVE_CHANGES);
                            if (result == DialogResult.Yes)
                            {
                                //save data on form
                                if (!SaveData())
                                {
                                    e.Cancel = true;
                                }
                            }
                            else if (result == DialogResult.No)
                            {
                                e.Cancel = false;
                            }
                            else if (result == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                        }
                    }
                }
                else
                {
                    //close form
                    this.FormClosing -= new FormClosingEventHandler(frmLGCreateApplicant_FormClosing);
                    this.Close();
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        #endregion

        #region Private Functions

        /// <summary>
        /// Set form style
        /// </summary>
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void SetFormStyle()
        {
            //set max length for textbox on form
            #region MAX LENGTH
            txtApplicantAddress.MaxLength = clsLGConstant.LENGTH_APPLICANT_ADDRESS;
            txtApplicantCode.MaxLength = clsLGConstant.LENGTH_APPLICANT_CODE;
            txtApplicantFax.MaxLength = clsLGConstant.LENGTH_APPLICANT_FAX;
            txtApplicantName.MaxLength = clsLGConstant.LENGTH_APPLICANT_NAME;
            txtApplicantNational.MaxLength = clsLGConstant.LENGTH_APPLICANT_NATIONAL;
            txtApplicantTel.MaxLength = clsLGConstant.LENGTH_APPLICANT_TEL;
            #endregion
        }

        /// <summary>
        /// Get Data on Form
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataValue()
        {
            //get data on form 
            m_clsLGApplicantDTO.ApplicantName = txtApplicantName.Text.Trim();
            NewApplicant = m_clsLGApplicantDTO.ApplicantName;
            m_clsLGApplicantDTO.ApplicantAddress = txtApplicantAddress.Text.Trim();
            m_clsLGApplicantDTO.ApplicantNational = txtApplicantNational.Text.Trim();
            m_clsLGApplicantDTO.ApplicantTel = txtApplicantTel.Text.Trim();
            m_clsLGApplicantDTO.ApplicantFax = txtApplicantFax.Text.Trim();
            m_clsLGApplicantDTO.CreatedBy = clsUserInfo.UserNo;
        }

        /// <summary>
        /// Check Data Input On Form
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsCheckDataInputOnForm()
        {
            //check Applicant Name is null or empty
            if (String.IsNullOrEmpty(txtApplicantName.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblApplicantName.Text));
                txtApplicantName.Focus();
                return false;
            }
            //check Applicant Address is null or empty
            if (String.IsNullOrEmpty(txtApplicantAddress.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblApplicantAddress.Text));
                txtApplicantAddress.Focus();
                return false;
            }
            //check Applicant Nationality is null or empty
            if (String.IsNullOrEmpty(txtApplicantNational.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblApplicantNationality.Text));
                txtApplicantNational.Focus();
                return false;
            }
            //check Applicant Tel is null or empty
            if (String.IsNullOrEmpty(txtApplicantTel.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblApplicantTel.Text));
                txtApplicantTel.Focus();
                return false;
            }
            //check Applicant Fax is null or empty
            if (String.IsNullOrEmpty(txtApplicantFax.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblApplicantFax.Text));
                txtApplicantFax.Focus();
                return false;
            }
            return true;
        }

        /// <summary>
        /// Save Data on Form
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool SaveData()
        {
            //check data on form
            if (!IsCheckDataInputOnForm())
            {
                return false;
            }
            //get data for insert Applicant
            GetDataValue();
            //used to check data input database
            int returnValue = m_clsLGApplicantBus.InsertApplicant(m_clsLGApplicantDTO);
            if (returnValue == 1)
            {
                //write log history
                WriteLog(m_clsLGApplicantDTO);
                //commit data
                m_clsLGApplicantBus.Commit();
                this.DialogResult = DialogResult.OK;
                //show message after save data is success
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                    String.Format(clsLGCommonMessage.INFOR_ACTION_SUCCESS, clsLGConstant.ACTION_CREATING, clsLGConstant.APPLICANT_NAME));
                frmLGCreateApplicant_FormClosing(null, null);
            }
            else if (returnValue == -1)
            {
                //rollback data
                m_clsLGApplicantBus.RollBack();
                //show message after save data failed
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_IS_EXISTED, txtApplicantName.Text.Trim(), lblApplicantName.Text));
                return false;
            }
            else
            {
                //rollback data
                m_clsLGApplicantBus.RollBack();
                //show message after save data failed
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_ACTION_FAIL, clsLGConstant.ACTION_CREATING, clsLGConstant.APPLICANT_NAME));
                return false;
            }
            return true;
        }

        /// <summary>
        /// Write log history
        /// </summary>
        /// <param name="applicantDto"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLog(clsLGApplicantDTO applicantDto)
        {
            clsLGLogBase logBase = new clsLGLogBase();
            //header history
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Key = applicantDto.ApplicantName;
            //+ Inserting Log 
            logBase.Action = (int)CommonValue.ActionType.New;
            //add information of log history
            logBase.LstLogInformation.Add(
                new clsLGLogInformation
                {
                    //add Applicant Address to insert history
                    FieldName = lblApplicantAddress.Text,
                    OldValue = String.Empty,
                    NewValue = applicantDto.ApplicantAddress
                });

            logBase.LstLogInformation.Add(
                new clsLGLogInformation
                {
                    //add Applicant Nationality to insert history
                    FieldName = lblApplicantNationality.Text,
                    OldValue = String.Empty,
                    NewValue = applicantDto.ApplicantNational
                });

            logBase.LstLogInformation.Add(
                new clsLGLogInformation
                {
                    //add Applicant Tel to insert history
                    FieldName = lblApplicantTel.Text,
                    OldValue = String.Empty,
                    NewValue = applicantDto.ApplicantTel
                });

            logBase.LstLogInformation.Add(
                new clsLGLogInformation
                {
                    //add Applicant Fax to insert history
                    FieldName = lblApplicantFax.Text,
                    OldValue = String.Empty,
                    NewValue = applicantDto.ApplicantFax
                });
            //write log data
            m_clsLGApplicantBus.WriteLog(logBase);
        }

        /// <summary>
        /// Check data is changed on form
        /// Return true data is changed
        /// Return false data is not changed
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsChangeValueOnForm()
        {
            //check data is changed on form
            if (m_clsLGApplicantDTO.ApplicantName != txtApplicantName.Text.Trim() ||
                m_clsLGApplicantDTO.ApplicantAddress != txtApplicantAddress.Text.Trim() ||
                m_clsLGApplicantDTO.ApplicantNational != txtApplicantNational.Text.Trim() ||
                m_clsLGApplicantDTO.ApplicantTel != txtApplicantTel.Text.Trim() ||
                m_clsLGApplicantDTO.ApplicantFax != txtApplicantFax.Text.Trim())
            {
                return true;
            }
            return false;
        }
        #endregion



    }
}