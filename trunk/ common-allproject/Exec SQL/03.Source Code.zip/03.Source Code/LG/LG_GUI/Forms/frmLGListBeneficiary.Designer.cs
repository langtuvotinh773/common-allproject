﻿namespace Phoenix.Lg.Gui.Forms
{
    partial class frmLGListBeneficiary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLGListBeneficiary));
            this.lblBeneficiaryCode = new System.Windows.Forms.Label();
            this.txtBeneficiaryCode = new System.Windows.Forms.TextBox();
            this.txtBeneficiaryName = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryName = new System.Windows.Forms.Label();
            this.txtBeneficiaryAddress = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryAddress = new System.Windows.Forms.Label();
            this.txtBeneficiaryNational = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryNational = new System.Windows.Forms.Label();
            this.txtBeneficiaryTel = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryTel = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtgBeneficiaryList = new System.Windows.Forms.DataGridView();
            this.colCheck = new UserCtrl.DataGridViewDisableCheckBoxColumn();
            this.colBeneficiaryCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBeneficiaryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBeneficiaryAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBeneficiaryNational = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBeneficiaryTel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBeneficiaryFax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNoChange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSeqBeneficiary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbUpdateBeneficiary = new System.Windows.Forms.ToolStripButton();
            this.tsbDeleteBeneficiary = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgBeneficiaryList)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBeneficiaryCode
            // 
            this.lblBeneficiaryCode.AutoSize = true;
            this.lblBeneficiaryCode.Location = new System.Drawing.Point(9, 22);
            this.lblBeneficiaryCode.Name = "lblBeneficiaryCode";
            this.lblBeneficiaryCode.Size = new System.Drawing.Size(87, 13);
            this.lblBeneficiaryCode.TabIndex = 0;
            this.lblBeneficiaryCode.Text = "Beneficiary Code";
            // 
            // txtBeneficiaryCode
            // 
            this.txtBeneficiaryCode.Location = new System.Drawing.Point(130, 19);
            this.txtBeneficiaryCode.Name = "txtBeneficiaryCode";
            this.txtBeneficiaryCode.Size = new System.Drawing.Size(320, 20);
            this.txtBeneficiaryCode.TabIndex = 0;
            // 
            // txtBeneficiaryName
            // 
            this.txtBeneficiaryName.Location = new System.Drawing.Point(632, 19);
            this.txtBeneficiaryName.Name = "txtBeneficiaryName";
            this.txtBeneficiaryName.Size = new System.Drawing.Size(320, 20);
            this.txtBeneficiaryName.TabIndex = 1;
            // 
            // lblBeneficiaryName
            // 
            this.lblBeneficiaryName.AutoSize = true;
            this.lblBeneficiaryName.Location = new System.Drawing.Point(518, 22);
            this.lblBeneficiaryName.Name = "lblBeneficiaryName";
            this.lblBeneficiaryName.Size = new System.Drawing.Size(90, 13);
            this.lblBeneficiaryName.TabIndex = 2;
            this.lblBeneficiaryName.Text = "Beneficiary Name";
            // 
            // txtBeneficiaryAddress
            // 
            this.txtBeneficiaryAddress.Location = new System.Drawing.Point(130, 40);
            this.txtBeneficiaryAddress.Name = "txtBeneficiaryAddress";
            this.txtBeneficiaryAddress.Size = new System.Drawing.Size(320, 20);
            this.txtBeneficiaryAddress.TabIndex = 2;
            // 
            // lblBeneficiaryAddress
            // 
            this.lblBeneficiaryAddress.AutoSize = true;
            this.lblBeneficiaryAddress.Location = new System.Drawing.Point(9, 43);
            this.lblBeneficiaryAddress.Name = "lblBeneficiaryAddress";
            this.lblBeneficiaryAddress.Size = new System.Drawing.Size(100, 13);
            this.lblBeneficiaryAddress.TabIndex = 4;
            this.lblBeneficiaryAddress.Text = "Beneficiary Address";
            // 
            // txtBeneficiaryNational
            // 
            this.txtBeneficiaryNational.Location = new System.Drawing.Point(632, 40);
            this.txtBeneficiaryNational.Name = "txtBeneficiaryNational";
            this.txtBeneficiaryNational.Size = new System.Drawing.Size(320, 20);
            this.txtBeneficiaryNational.TabIndex = 3;
            // 
            // lblBeneficiaryNational
            // 
            this.lblBeneficiaryNational.AutoSize = true;
            this.lblBeneficiaryNational.Location = new System.Drawing.Point(518, 43);
            this.lblBeneficiaryNational.Name = "lblBeneficiaryNational";
            this.lblBeneficiaryNational.Size = new System.Drawing.Size(111, 13);
            this.lblBeneficiaryNational.TabIndex = 6;
            this.lblBeneficiaryNational.Text = "Beneficiary Nationality";
            // 
            // txtBeneficiaryTel
            // 
            this.txtBeneficiaryTel.Location = new System.Drawing.Point(130, 61);
            this.txtBeneficiaryTel.Name = "txtBeneficiaryTel";
            this.txtBeneficiaryTel.Size = new System.Drawing.Size(320, 20);
            this.txtBeneficiaryTel.TabIndex = 4;
            // 
            // lblBeneficiaryTel
            // 
            this.lblBeneficiaryTel.AutoSize = true;
            this.lblBeneficiaryTel.Location = new System.Drawing.Point(9, 64);
            this.lblBeneficiaryTel.Name = "lblBeneficiaryTel";
            this.lblBeneficiaryTel.Size = new System.Drawing.Size(77, 13);
            this.lblBeneficiaryTel.TabIndex = 8;
            this.lblBeneficiaryTel.Text = "Beneficiary Tel";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(878, 66);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtgBeneficiaryList
            // 
            this.dtgBeneficiaryList.AllowUserToAddRows = false;
            this.dtgBeneficiaryList.AllowUserToDeleteRows = false;
            this.dtgBeneficiaryList.AllowUserToResizeColumns = false;
            this.dtgBeneficiaryList.AllowUserToResizeRows = false;
            this.dtgBeneficiaryList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgBeneficiaryList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgBeneficiaryList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(195)))), ((int)(((byte)(237)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgBeneficiaryList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgBeneficiaryList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgBeneficiaryList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCheck,
            this.colBeneficiaryCode,
            this.colBeneficiaryName,
            this.colBeneficiaryAddress,
            this.colBeneficiaryNational,
            this.colBeneficiaryTel,
            this.colBeneficiaryFax,
            this.colNoChange,
            this.colSeqBeneficiary});
            this.dtgBeneficiaryList.Location = new System.Drawing.Point(8, 129);
            this.dtgBeneficiaryList.MultiSelect = false;
            this.dtgBeneficiaryList.Name = "dtgBeneficiaryList";
            this.dtgBeneficiaryList.ReadOnly = true;
            this.dtgBeneficiaryList.RowHeadersVisible = false;
            this.dtgBeneficiaryList.Size = new System.Drawing.Size(953, 281);
            this.dtgBeneficiaryList.TabIndex = 1;
            this.dtgBeneficiaryList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgBeneficiaryList_CellClick);
            this.dtgBeneficiaryList.SelectionChanged += new System.EventHandler(this.dtgBeneficiaryList_SelectionChanged);
            // 
            // colCheck
            // 
            this.colCheck.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colCheck.FillWeight = 2.658677F;
            this.colCheck.HeaderText = "";
            this.colCheck.MinimumWidth = 30;
            this.colCheck.Name = "colCheck";
            this.colCheck.ReadOnly = true;
            this.colCheck.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCheck.Width = 30;
            // 
            // colBeneficiaryCode
            // 
            this.colBeneficiaryCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colBeneficiaryCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.colBeneficiaryCode.FillWeight = 9.511076F;
            this.colBeneficiaryCode.HeaderText = "Beneficiary Code";
            this.colBeneficiaryCode.MinimumWidth = 120;
            this.colBeneficiaryCode.Name = "colBeneficiaryCode";
            this.colBeneficiaryCode.ReadOnly = true;
            this.colBeneficiaryCode.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colBeneficiaryCode.Width = 120;
            // 
            // colBeneficiaryName
            // 
            this.colBeneficiaryName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colBeneficiaryName.DefaultCellStyle = dataGridViewCellStyle3;
            this.colBeneficiaryName.FillWeight = 43.28232F;
            this.colBeneficiaryName.HeaderText = "Beneficiary Name";
            this.colBeneficiaryName.MinimumWidth = 200;
            this.colBeneficiaryName.Name = "colBeneficiaryName";
            this.colBeneficiaryName.ReadOnly = true;
            this.colBeneficiaryName.Width = 200;
            // 
            // colBeneficiaryAddress
            // 
            this.colBeneficiaryAddress.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colBeneficiaryAddress.DefaultCellStyle = dataGridViewCellStyle4;
            this.colBeneficiaryAddress.FillWeight = 144.3929F;
            this.colBeneficiaryAddress.HeaderText = "Beneficiary Address";
            this.colBeneficiaryAddress.MinimumWidth = 200;
            this.colBeneficiaryAddress.Name = "colBeneficiaryAddress";
            this.colBeneficiaryAddress.ReadOnly = true;
            this.colBeneficiaryAddress.Width = 200;
            // 
            // colBeneficiaryNational
            // 
            this.colBeneficiaryNational.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colBeneficiaryNational.DefaultCellStyle = dataGridViewCellStyle5;
            this.colBeneficiaryNational.FillWeight = 482.5078F;
            this.colBeneficiaryNational.HeaderText = "Beneficiary Nationality";
            this.colBeneficiaryNational.MinimumWidth = 200;
            this.colBeneficiaryNational.Name = "colBeneficiaryNational";
            this.colBeneficiaryNational.ReadOnly = true;
            this.colBeneficiaryNational.Width = 200;
            // 
            // colBeneficiaryTel
            // 
            this.colBeneficiaryTel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colBeneficiaryTel.DefaultCellStyle = dataGridViewCellStyle6;
            this.colBeneficiaryTel.FillWeight = 13.03005F;
            this.colBeneficiaryTel.HeaderText = "Beneficiary Tel";
            this.colBeneficiaryTel.MinimumWidth = 100;
            this.colBeneficiaryTel.Name = "colBeneficiaryTel";
            this.colBeneficiaryTel.ReadOnly = true;
            this.colBeneficiaryTel.Width = 102;
            // 
            // colBeneficiaryFax
            // 
            this.colBeneficiaryFax.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colBeneficiaryFax.DefaultCellStyle = dataGridViewCellStyle7;
            this.colBeneficiaryFax.FillWeight = 4.617166F;
            this.colBeneficiaryFax.HeaderText = "Beneficiary Fax";
            this.colBeneficiaryFax.MinimumWidth = 100;
            this.colBeneficiaryFax.Name = "colBeneficiaryFax";
            this.colBeneficiaryFax.ReadOnly = true;
            // 
            // colNoChange
            // 
            this.colNoChange.HeaderText = "NoChange";
            this.colNoChange.Name = "colNoChange";
            this.colNoChange.ReadOnly = true;
            this.colNoChange.Visible = false;
            this.colNoChange.Width = 83;
            // 
            // colSeqBeneficiary
            // 
            this.colSeqBeneficiary.HeaderText = "SeqBeneficiary";
            this.colSeqBeneficiary.Name = "colSeqBeneficiary";
            this.colSeqBeneficiary.ReadOnly = true;
            this.colSeqBeneficiary.Visible = false;
            this.colSeqBeneficiary.Width = 103;
            // 
            // btnCreate
            // 
            this.btnCreate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCreate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCreate.Location = new System.Drawing.Point(805, 416);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 23);
            this.btnCreate.TabIndex = 2;
            this.btnCreate.Text = "C&reate";
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(886, 416);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbUpdateBeneficiary,
            this.tsbDeleteBeneficiary});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(970, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.TabStop = true;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbUpdateBeneficiary
            // 
            this.tsbUpdateBeneficiary.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbUpdateBeneficiary.Image = ((System.Drawing.Image)(resources.GetObject("tsbUpdateBeneficiary.Image")));
            this.tsbUpdateBeneficiary.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUpdateBeneficiary.Name = "tsbUpdateBeneficiary";
            this.tsbUpdateBeneficiary.Size = new System.Drawing.Size(23, 22);
            this.tsbUpdateBeneficiary.Text = "Modify (Alt + U)";
            this.tsbUpdateBeneficiary.Click += new System.EventHandler(this.tsbUpdateBeneficiary_Click);
            // 
            // tsbDeleteBeneficiary
            // 
            this.tsbDeleteBeneficiary.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteBeneficiary.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteBeneficiary.Image")));
            this.tsbDeleteBeneficiary.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDeleteBeneficiary.Name = "tsbDeleteBeneficiary";
            this.tsbDeleteBeneficiary.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteBeneficiary.Text = "Delete (Alt + D)";
            this.tsbDeleteBeneficiary.Click += new System.EventHandler(this.tsbDeleteBeneficiary_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.txtBeneficiaryCode);
            this.groupBox1.Controls.Add(this.lblBeneficiaryCode);
            this.groupBox1.Controls.Add(this.lblBeneficiaryName);
            this.groupBox1.Controls.Add(this.txtBeneficiaryName);
            this.groupBox1.Controls.Add(this.lblBeneficiaryAddress);
            this.groupBox1.Controls.Add(this.txtBeneficiaryAddress);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.lblBeneficiaryNational);
            this.groupBox1.Controls.Add(this.txtBeneficiaryTel);
            this.groupBox1.Controls.Add(this.txtBeneficiaryNational);
            this.groupBox1.Controls.Add(this.lblBeneficiaryTel);
            this.groupBox1.Location = new System.Drawing.Point(5, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(960, 95);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn1.FillWeight = 9.511076F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Beneficiary Code";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 43.28232F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Beneficiary Name";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 120;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 120;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 144.3929F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Address";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 482.5078F;
            this.dataGridViewTextBoxColumn4.HeaderText = "National";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 153;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.FillWeight = 13.03005F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Tel";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.FillWeight = 4.617166F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Fax";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // frmLGListBeneficiary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(970, 451);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.dtgBeneficiaryList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "frmLGListBeneficiary";
            this.Text = "List Beneficiary";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGListBeneficiary_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dtgBeneficiaryList)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBeneficiaryCode;
        private System.Windows.Forms.TextBox txtBeneficiaryCode;
        private System.Windows.Forms.TextBox txtBeneficiaryName;
        private System.Windows.Forms.Label lblBeneficiaryName;
        private System.Windows.Forms.TextBox txtBeneficiaryAddress;
        private System.Windows.Forms.Label lblBeneficiaryAddress;
        private System.Windows.Forms.TextBox txtBeneficiaryNational;
        private System.Windows.Forms.Label lblBeneficiaryNational;
        private System.Windows.Forms.TextBox txtBeneficiaryTel;
        private System.Windows.Forms.Label lblBeneficiaryTel;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dtgBeneficiaryList;
		private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbUpdateBeneficiary;
		private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.ToolStripButton tsbDeleteBeneficiary;
        private UserCtrl.DataGridViewDisableCheckBoxColumn colCheck;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBeneficiaryCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBeneficiaryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBeneficiaryAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBeneficiaryNational;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBeneficiaryTel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBeneficiaryFax;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNoChange;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSeqBeneficiary;
    }
}