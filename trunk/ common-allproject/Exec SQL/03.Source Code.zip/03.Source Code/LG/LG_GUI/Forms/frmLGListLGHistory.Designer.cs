﻿namespace Phoenix.Lg.Gui.Forms
{
    partial class frmLGListLGHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLGListLGHistory));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtgLGList = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblLGNo = new System.Windows.Forms.Label();
            this.txtLGNo = new System.Windows.Forms.TextBox();
            this.lblCustomerCode = new System.Windows.Forms.Label();
            this.txtCustomerCode = new System.Windows.Forms.TextBox();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.lblSecurity = new System.Windows.Forms.Label();
            this.cbbSecurity = new System.Windows.Forms.ComboBox();
            this.cbbGLCode = new System.Windows.Forms.ComboBox();
            this.lblGLCode = new System.Windows.Forms.Label();
            this.cbbCurrency = new System.Windows.Forms.ComboBox();
            this.lblCurrency = new System.Windows.Forms.Label();
            this.lblInputDate = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cbbGuaranteeType = new System.Windows.Forms.ComboBox();
            this.lblGuaranteeType = new System.Windows.Forms.Label();
            this.lblValueDate = new System.Windows.Forms.Label();
            this.lblExpireDate = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ckbTemination = new System.Windows.Forms.CheckBox();
            this.ckbCloseTechnique = new System.Windows.Forms.CheckBox();
            this.ckbAmend = new System.Windows.Forms.CheckBox();
            this.ckbAmendUpdate = new System.Windows.Forms.CheckBox();
            this.ckbCorrect = new System.Windows.Forms.CheckBox();
            this.ckbNewEntry = new System.Windows.Forms.CheckBox();
            this.cbbLGType = new System.Windows.Forms.ComboBox();
            this.lblLGCategory = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtMaxNumberPrinted = new Phoenix.Lg.UserControl.DisableTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSequenceToCounter = new UserCtrl.NumberOnlyTextBox();
            this.txtSequenceFromCounter = new UserCtrl.NumberOnlyTextBox();
            this.btnExportToControllingBook = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbPrintForm = new System.Windows.Forms.ToolStripButton();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtAmountTo = new UserCtrl.NumberOnlyTextBox();
            this.txtAmountFrom = new UserCtrl.NumberOnlyTextBox();
            this.dtpExpireDateTo = new UserCtrl.BlankCalendar();
            this.dtpExpireDateFrom = new UserCtrl.BlankCalendar();
            this.dtpValueDateTo = new UserCtrl.BlankCalendar();
            this.dtpValueDateFrom = new UserCtrl.BlankCalendar();
            this.dtpInputDateTo = new UserCtrl.BlankCalendar();
            this.dtpInputDateFrom = new UserCtrl.BlankCalendar();
            this.cbbClaim = new System.Windows.Forms.ComboBox();
            this.lblClaim = new System.Windows.Forms.Label();
            this.cbbBookingPurpose = new System.Windows.Forms.ComboBox();
            this.lblBookingPurpose = new System.Windows.Forms.Label();
            this.colSeqLG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLGNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPreviousLGNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMngCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colReportToSBV = new System.Windows.Forms.DataGridViewImageColumn();
            this.colInputDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colValueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colUpdatedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBackValue = new System.Windows.Forms.DataGridViewImageColumn();
            this.colCustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGLCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colClaim = new System.Windows.Forms.DataGridViewImageColumn();
            this.colGuaranteeAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTransCurrency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colExpiryDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGuaranteeType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBeneficiaryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colChargeAccount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFeeRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMinCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFeeCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOverdueFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOverdueFeeCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOverdueClaimFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOverdueClaimFeeCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAmendUpdatedFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAmendUpdatedFeeCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMultiTimesFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgLGList)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(938, 147);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(94, 23);
            this.btnSearch.TabIndex = 18;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtgLGList
            // 
            this.dtgLGList.AllowUserToAddRows = false;
            this.dtgLGList.AllowUserToDeleteRows = false;
            this.dtgLGList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgLGList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgLGList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgLGList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgLGList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgLGList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSeqLG,
            this.colLGNo,
            this.colPreviousLGNo,
            this.colMngCode,
            this.colType,
            this.colReportToSBV,
            this.colInputDate,
            this.colValueDate,
            this.colUpdatedDate,
            this.colBackValue,
            this.colCustomerCode,
            this.colCustomerName,
            this.colGLCode,
            this.colClaim,
            this.colGuaranteeAmount,
            this.colTransCurrency,
            this.colExpiryDate,
            this.colGuaranteeType,
            this.colBeneficiaryName,
            this.colChargeAccount,
            this.colFeeRate,
            this.colMin,
            this.colMinCCY,
            this.colFee,
            this.colFeeCCY,
            this.colOverdueFee,
            this.colOverdueFeeCCY,
            this.colOverdueClaimFee,
            this.colOverdueClaimFeeCCY,
            this.colAmendUpdatedFee,
            this.colAmendUpdatedFeeCCY,
            this.colMultiTimesFee});
            this.dtgLGList.EnableHeadersVisualStyles = false;
            this.dtgLGList.Location = new System.Drawing.Point(9, 173);
            this.dtgLGList.MultiSelect = false;
            this.dtgLGList.Name = "dtgLGList";
            this.dtgLGList.ReadOnly = true;
            this.dtgLGList.RowHeadersVisible = false;
            this.dtgLGList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgLGList.Size = new System.Drawing.Size(1024, 350);
            this.dtgLGList.TabIndex = 19;
            this.dtgLGList.SelectionChanged += new System.EventHandler(this.dtgLGList_SelectionChanged);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(938, 543);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(94, 23);
            this.btnClose.TabIndex = 23;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblLGNo
            // 
            this.lblLGNo.AutoSize = true;
            this.lblLGNo.Location = new System.Drawing.Point(9, 39);
            this.lblLGNo.Name = "lblLGNo";
            this.lblLGNo.Size = new System.Drawing.Size(38, 13);
            this.lblLGNo.TabIndex = 22;
            this.lblLGNo.Text = "LG No";
            // 
            // txtLGNo
            // 
            this.txtLGNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtLGNo.Location = new System.Drawing.Point(73, 35);
            this.txtLGNo.MaxLength = 9;
            this.txtLGNo.Name = "txtLGNo";
            this.txtLGNo.Size = new System.Drawing.Size(114, 20);
            this.txtLGNo.TabIndex = 0;
            // 
            // lblCustomerCode
            // 
            this.lblCustomerCode.AutoSize = true;
            this.lblCustomerCode.Location = new System.Drawing.Point(208, 39);
            this.lblCustomerCode.Name = "lblCustomerCode";
            this.lblCustomerCode.Size = new System.Drawing.Size(79, 13);
            this.lblCustomerCode.TabIndex = 24;
            this.lblCustomerCode.Text = "Customer Code";
            // 
            // txtCustomerCode
            // 
            this.txtCustomerCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCustomerCode.Location = new System.Drawing.Point(307, 35);
            this.txtCustomerCode.MaxLength = 8;
            this.txtCustomerCode.Name = "txtCustomerCode";
            this.txtCustomerCode.Size = new System.Drawing.Size(136, 20);
            this.txtCustomerCode.TabIndex = 1;
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(453, 39);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(82, 13);
            this.lblCustomerName.TabIndex = 26;
            this.lblCustomerName.Text = "Customer Name";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCustomerName.Location = new System.Drawing.Point(540, 35);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(493, 20);
            this.txtCustomerName.TabIndex = 2;
            // 
            // lblSecurity
            // 
            this.lblSecurity.AutoSize = true;
            this.lblSecurity.Location = new System.Drawing.Point(9, 60);
            this.lblSecurity.Name = "lblSecurity";
            this.lblSecurity.Size = new System.Drawing.Size(45, 13);
            this.lblSecurity.TabIndex = 28;
            this.lblSecurity.Text = "Security";
            // 
            // cbbSecurity
            // 
            this.cbbSecurity.FormattingEnabled = true;
            this.cbbSecurity.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbSecurity.Location = new System.Drawing.Point(73, 56);
            this.cbbSecurity.Name = "cbbSecurity";
            this.cbbSecurity.Size = new System.Drawing.Size(114, 21);
            this.cbbSecurity.TabIndex = 3;
            // 
            // cbbGLCode
            // 
            this.cbbGLCode.FormattingEnabled = true;
            this.cbbGLCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbGLCode.Location = new System.Drawing.Point(540, 56);
            this.cbbGLCode.Name = "cbbGLCode";
            this.cbbGLCode.Size = new System.Drawing.Size(114, 21);
            this.cbbGLCode.TabIndex = 5;
            // 
            // lblGLCode
            // 
            this.lblGLCode.AutoSize = true;
            this.lblGLCode.Location = new System.Drawing.Point(453, 60);
            this.lblGLCode.Name = "lblGLCode";
            this.lblGLCode.Size = new System.Drawing.Size(49, 13);
            this.lblGLCode.TabIndex = 32;
            this.lblGLCode.Text = "GL Code";
            // 
            // cbbCurrency
            // 
            this.cbbCurrency.FormattingEnabled = true;
            this.cbbCurrency.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbCurrency.Location = new System.Drawing.Point(700, 56);
            this.cbbCurrency.Name = "cbbCurrency";
            this.cbbCurrency.Size = new System.Drawing.Size(80, 21);
            this.cbbCurrency.TabIndex = 6;
            this.cbbCurrency.SelectedIndexChanged += new System.EventHandler(this.cbbCurrency_SelectedIndexChanged);
            // 
            // lblCurrency
            // 
            this.lblCurrency.AutoSize = true;
            this.lblCurrency.Location = new System.Drawing.Point(665, 60);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(28, 13);
            this.lblCurrency.TabIndex = 34;
            this.lblCurrency.Text = "CCY";
            // 
            // lblInputDate
            // 
            this.lblInputDate.AutoSize = true;
            this.lblInputDate.Location = new System.Drawing.Point(9, 82);
            this.lblInputDate.Name = "lblInputDate";
            this.lblInputDate.Size = new System.Drawing.Size(57, 13);
            this.lblInputDate.TabIndex = 38;
            this.lblInputDate.Text = "Input Date";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(190, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 13);
            this.label9.TabIndex = 40;
            this.label9.Text = "~";
            // 
            // cbbGuaranteeType
            // 
            this.cbbGuaranteeType.FormattingEnabled = true;
            this.cbbGuaranteeType.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbGuaranteeType.Location = new System.Drawing.Point(441, 78);
            this.cbbGuaranteeType.Name = "cbbGuaranteeType";
            this.cbbGuaranteeType.Size = new System.Drawing.Size(114, 21);
            this.cbbGuaranteeType.TabIndex = 10;
            // 
            // lblGuaranteeType
            // 
            this.lblGuaranteeType.AutoSize = true;
            this.lblGuaranteeType.Location = new System.Drawing.Point(347, 82);
            this.lblGuaranteeType.Name = "lblGuaranteeType";
            this.lblGuaranteeType.Size = new System.Drawing.Size(84, 13);
            this.lblGuaranteeType.TabIndex = 41;
            this.lblGuaranteeType.Text = "Guarantee Type";
            // 
            // lblValueDate
            // 
            this.lblValueDate.AutoSize = true;
            this.lblValueDate.Location = new System.Drawing.Point(9, 104);
            this.lblValueDate.Name = "lblValueDate";
            this.lblValueDate.Size = new System.Drawing.Size(60, 13);
            this.lblValueDate.TabIndex = 44;
            this.lblValueDate.Text = "Value Date";
            // 
            // lblExpireDate
            // 
            this.lblExpireDate.AutoSize = true;
            this.lblExpireDate.Location = new System.Drawing.Point(347, 104);
            this.lblExpireDate.Name = "lblExpireDate";
            this.lblExpireDate.Size = new System.Drawing.Size(61, 13);
            this.lblExpireDate.TabIndex = 47;
            this.lblExpireDate.Text = "Expiry Date";
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(700, 104);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(43, 13);
            this.lblAmount.TabIndex = 49;
            this.lblAmount.Text = "Amount";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(883, 104);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 13);
            this.label14.TabIndex = 51;
            this.label14.Text = "~";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(190, 104);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 13);
            this.label15.TabIndex = 53;
            this.label15.Text = "~";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(558, 104);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 13);
            this.label16.TabIndex = 54;
            this.label16.Text = "~";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ckbTemination);
            this.groupBox1.Controls.Add(this.ckbCloseTechnique);
            this.groupBox1.Controls.Add(this.ckbAmend);
            this.groupBox1.Controls.Add(this.ckbAmendUpdate);
            this.groupBox1.Controls.Add(this.ckbCorrect);
            this.groupBox1.Controls.Add(this.ckbNewEntry);
            this.groupBox1.Location = new System.Drawing.Point(9, 123);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(591, 47);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Type";
            // 
            // ckbTemination
            // 
            this.ckbTemination.AutoSize = true;
            this.ckbTemination.Checked = true;
            this.ckbTemination.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbTemination.Location = new System.Drawing.Point(499, 18);
            this.ckbTemination.Name = "ckbTemination";
            this.ckbTemination.Size = new System.Drawing.Size(78, 17);
            this.ckbTemination.TabIndex = 5;
            this.ckbTemination.Text = "Temination";
            this.ckbTemination.UseVisualStyleBackColor = true;
            // 
            // ckbCloseTechnique
            // 
            this.ckbCloseTechnique.AutoSize = true;
            this.ckbCloseTechnique.Checked = true;
            this.ckbCloseTechnique.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbCloseTechnique.Location = new System.Drawing.Point(382, 18);
            this.ckbCloseTechnique.Name = "ckbCloseTechnique";
            this.ckbCloseTechnique.Size = new System.Drawing.Size(102, 17);
            this.ckbCloseTechnique.TabIndex = 4;
            this.ckbCloseTechnique.Text = "Close technique";
            this.ckbCloseTechnique.UseVisualStyleBackColor = true;
            // 
            // ckbAmend
            // 
            this.ckbAmend.AutoSize = true;
            this.ckbAmend.Checked = true;
            this.ckbAmend.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbAmend.Location = new System.Drawing.Point(306, 18);
            this.ckbAmend.Name = "ckbAmend";
            this.ckbAmend.Size = new System.Drawing.Size(59, 17);
            this.ckbAmend.TabIndex = 3;
            this.ckbAmend.Text = "Amend";
            this.ckbAmend.UseVisualStyleBackColor = true;
            // 
            // ckbAmendUpdate
            // 
            this.ckbAmendUpdate.AutoSize = true;
            this.ckbAmendUpdate.Checked = true;
            this.ckbAmendUpdate.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbAmendUpdate.Location = new System.Drawing.Point(184, 18);
            this.ckbAmendUpdate.Name = "ckbAmendUpdate";
            this.ckbAmendUpdate.Size = new System.Drawing.Size(101, 17);
            this.ckbAmendUpdate.TabIndex = 2;
            this.ckbAmendUpdate.Text = "Amend (update)";
            this.ckbAmendUpdate.UseVisualStyleBackColor = true;
            // 
            // ckbCorrect
            // 
            this.ckbCorrect.AutoSize = true;
            this.ckbCorrect.Checked = true;
            this.ckbCorrect.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbCorrect.Location = new System.Drawing.Point(99, 18);
            this.ckbCorrect.Name = "ckbCorrect";
            this.ckbCorrect.Size = new System.Drawing.Size(60, 17);
            this.ckbCorrect.TabIndex = 1;
            this.ckbCorrect.Text = "Correct";
            this.ckbCorrect.UseVisualStyleBackColor = true;
            // 
            // ckbNewEntry
            // 
            this.ckbNewEntry.AutoSize = true;
            this.ckbNewEntry.Checked = true;
            this.ckbNewEntry.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbNewEntry.Location = new System.Drawing.Point(12, 18);
            this.ckbNewEntry.Name = "ckbNewEntry";
            this.ckbNewEntry.Size = new System.Drawing.Size(74, 17);
            this.ckbNewEntry.TabIndex = 0;
            this.ckbNewEntry.Text = "New entry";
            this.ckbNewEntry.UseVisualStyleBackColor = true;
            // 
            // cbbLGType
            // 
            this.cbbLGType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cbbLGType.FormattingEnabled = true;
            this.cbbLGType.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbLGType.Location = new System.Drawing.Point(152, 544);
            this.cbbLGType.Name = "cbbLGType";
            this.cbbLGType.Size = new System.Drawing.Size(114, 21);
            this.cbbLGType.TabIndex = 20;
            this.cbbLGType.SelectedIndexChanged += new System.EventHandler(this.cbbLGType_SelectedIndexChanged);
            // 
            // lblLGCategory
            // 
            this.lblLGCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLGCategory.AutoSize = true;
            this.lblLGCategory.Location = new System.Drawing.Point(97, 548);
            this.lblLGCategory.Name = "lblLGCategory";
            this.lblLGCategory.Size = new System.Drawing.Size(48, 13);
            this.lblLGCategory.TabIndex = 78;
            this.lblLGCategory.Text = "LG Type";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.txtMaxNumberPrinted);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtSequenceToCounter);
            this.groupBox3.Controls.Add(this.txtSequenceFromCounter);
            this.groupBox3.Location = new System.Drawing.Point(282, 531);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(443, 38);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            // 
            // txtMaxNumberPrinted
            // 
            this.txtMaxNumberPrinted.BackColor = System.Drawing.SystemColors.Control;
            this.txtMaxNumberPrinted.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtMaxNumberPrinted.ForeColor = System.Drawing.Color.Black;
            this.txtMaxNumberPrinted.Location = new System.Drawing.Point(98, 13);
            this.txtMaxNumberPrinted.Name = "txtMaxNumberPrinted";
            this.txtMaxNumberPrinted.Size = new System.Drawing.Size(76, 20);
            this.txtMaxNumberPrinted.TabIndex = 1;
            this.txtMaxNumberPrinted.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Latest Number ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(187, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Sequence";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(332, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "~";
            // 
            // txtSequenceToCounter
            // 
            this.txtSequenceToCounter.CustomDecimal = 0;
            this.txtSequenceToCounter.CustomLenght = 11;
            this.txtSequenceToCounter.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSequenceToCounter.Location = new System.Drawing.Point(352, 13);
            this.txtSequenceToCounter.Name = "txtSequenceToCounter";
            this.txtSequenceToCounter.NeedDecimal = true;
            this.txtSequenceToCounter.Size = new System.Drawing.Size(76, 20);
            this.txtSequenceToCounter.StringFormat = "#,0.####";
            this.txtSequenceToCounter.TabIndex = 5;
            // 
            // txtSequenceFromCounter
            // 
            this.txtSequenceFromCounter.CustomDecimal = 0;
            this.txtSequenceFromCounter.CustomLenght = 11;
            this.txtSequenceFromCounter.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSequenceFromCounter.Location = new System.Drawing.Point(249, 13);
            this.txtSequenceFromCounter.Name = "txtSequenceFromCounter";
            this.txtSequenceFromCounter.NeedDecimal = true;
            this.txtSequenceFromCounter.Size = new System.Drawing.Size(76, 20);
            this.txtSequenceFromCounter.StringFormat = "#,0.####";
            this.txtSequenceFromCounter.TabIndex = 3;
            // 
            // btnExportToControllingBook
            // 
            this.btnExportToControllingBook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportToControllingBook.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnExportToControllingBook.Location = new System.Drawing.Point(741, 543);
            this.btnExportToControllingBook.Name = "btnExportToControllingBook";
            this.btnExportToControllingBook.Size = new System.Drawing.Size(187, 23);
            this.btnExportToControllingBook.TabIndex = 22;
            this.btnExportToControllingBook.Text = "&Export To Controlling Book";
            this.btnExportToControllingBook.UseVisualStyleBackColor = false;
            this.btnExportToControllingBook.Click += new System.EventHandler(this.btnExportToControllingBook_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbPrintForm});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1041, 25);
            this.toolStrip1.TabIndex = 24;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbPrintForm
            // 
            this.tsbPrintForm.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPrintForm.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrintForm.Image")));
            this.tsbPrintForm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrintForm.Name = "tsbPrintForm";
            this.tsbPrintForm.Size = new System.Drawing.Size(23, 22);
            this.tsbPrintForm.Text = "Print Form (Alt + P)";
            this.tsbPrintForm.Click += new System.EventHandler(this.tsbPrintForm_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "SeqLG";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridViewTextBoxColumn1.FillWeight = 101.1236F;
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "LG No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            this.dataGridViewTextBoxColumn1.Width = 63;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "LGNo";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle30;
            this.dataGridViewTextBoxColumn2.FillWeight = 130.3745F;
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "Previous LG No";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 107;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "PreviousLGNo";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridViewTextBoxColumn3.FillWeight = 109.0775F;
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "Type";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 56;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "MngCode";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridViewTextBoxColumn4.FillWeight = 83.79958F;
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "Input Date";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 50;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 82;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "ReportToSBV";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridViewTextBoxColumn5.FillWeight = 90.08809F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Value Date";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 85;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "InputDate";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.Format = "yyyy/MM/dd";
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewTextBoxColumn6.FillWeight = 85.53667F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Back Value";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 87;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ValueDate";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewTextBoxColumn7.FillWeight = 90.08809F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Customer Code";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 104;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "CustomerCode";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridViewTextBoxColumn8.HeaderText = "Customer Name";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 107;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "CustomerName";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle37;
            this.dataGridViewTextBoxColumn9.HeaderText = "GL Code";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 200;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 200;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "GLCode";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle38;
            this.dataGridViewTextBoxColumn10.HeaderText = "Fee Rate(%)";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 90;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Claim";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle39;
            this.dataGridViewTextBoxColumn11.HeaderText = "Min";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 49;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn12.DataPropertyName = "GuaranteeAmount";
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle40.Format = "N2";
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle40;
            this.dataGridViewTextBoxColumn12.HeaderText = "Min CCY";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "TransCurrency";
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle41;
            this.dataGridViewTextBoxColumn13.HeaderText = "Expiry Date";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 86;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "ExpiryDate";
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle42;
            this.dataGridViewTextBoxColumn14.HeaderText = "Guarantee Type";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 109;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "GuaranteeType";
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle43;
            this.dataGridViewTextBoxColumn15.HeaderText = "Beneficiary";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 84;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "BeneficiaryName";
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn16.DefaultCellStyle = dataGridViewCellStyle44;
            this.dataGridViewTextBoxColumn16.HeaderText = "CCY";
            this.dataGridViewTextBoxColumn16.MinimumWidth = 200;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 200;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn17.DataPropertyName = "ChargeAccount";
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn17.DefaultCellStyle = dataGridViewCellStyle45;
            this.dataGridViewTextBoxColumn17.HeaderText = "Charge Account";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn18.DataPropertyName = "FeeRate";
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn18.DefaultCellStyle = dataGridViewCellStyle46;
            this.dataGridViewTextBoxColumn18.HeaderText = "Guarantee Amount";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Min";
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle47;
            this.dataGridViewTextBoxColumn19.HeaderText = "Fee";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "MinCCY";
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn20.DefaultCellStyle = dataGridViewCellStyle48;
            this.dataGridViewTextBoxColumn20.HeaderText = "Overdue Fee";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 94;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Fee";
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle49.Format = "N2";
            this.dataGridViewTextBoxColumn21.DefaultCellStyle = dataGridViewCellStyle49;
            this.dataGridViewTextBoxColumn21.HeaderText = "Overdue Claim Fee";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn22.DataPropertyName = "OverdueFee";
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle50.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn22.DefaultCellStyle = dataGridViewCellStyle50;
            this.dataGridViewTextBoxColumn22.HeaderText = "Report to SBV";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn23.DataPropertyName = "OverdueClaimFee";
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle51.Format = "N2";
            this.dataGridViewTextBoxColumn23.DefaultCellStyle = dataGridViewCellStyle51;
            this.dataGridViewTextBoxColumn23.HeaderText = "Overdue Claim Fee";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            // 
            // txtAmountTo
            // 
            this.txtAmountTo.CustomDecimal = 5;
            this.txtAmountTo.CustomLenght = 17;
            this.txtAmountTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtAmountTo.Location = new System.Drawing.Point(898, 100);
            this.txtAmountTo.Name = "txtAmountTo";
            this.txtAmountTo.NeedDecimal = true;
            this.txtAmountTo.Size = new System.Drawing.Size(134, 20);
            this.txtAmountTo.StringFormat = "#,0.####";
            this.txtAmountTo.TabIndex = 16;
            // 
            // txtAmountFrom
            // 
            this.txtAmountFrom.CustomDecimal = 5;
            this.txtAmountFrom.CustomLenght = 17;
            this.txtAmountFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtAmountFrom.Location = new System.Drawing.Point(748, 100);
            this.txtAmountFrom.Name = "txtAmountFrom";
            this.txtAmountFrom.NeedDecimal = true;
            this.txtAmountFrom.Size = new System.Drawing.Size(134, 20);
            this.txtAmountFrom.StringFormat = "#,0.####";
            this.txtAmountFrom.TabIndex = 15;
            // 
            // dtpExpireDateTo
            // 
            this.dtpExpireDateTo.CustomFormat = "yyyy/MM/dd";
            this.dtpExpireDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpExpireDateTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpExpireDateTo.Location = new System.Drawing.Point(575, 100);
            this.dtpExpireDateTo.Name = "dtpExpireDateTo";
            this.dtpExpireDateTo.Size = new System.Drawing.Size(114, 20);
            this.dtpExpireDateTo.TabIndex = 14;
            this.dtpExpireDateTo.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // dtpExpireDateFrom
            // 
            this.dtpExpireDateFrom.CustomFormat = "yyyy/MM/dd";
            this.dtpExpireDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpExpireDateFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpExpireDateFrom.Location = new System.Drawing.Point(441, 100);
            this.dtpExpireDateFrom.Name = "dtpExpireDateFrom";
            this.dtpExpireDateFrom.Size = new System.Drawing.Size(114, 20);
            this.dtpExpireDateFrom.TabIndex = 13;
            this.dtpExpireDateFrom.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // dtpValueDateTo
            // 
            this.dtpValueDateTo.CustomFormat = "yyyy/MM/dd";
            this.dtpValueDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpValueDateTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpValueDateTo.Location = new System.Drawing.Point(207, 100);
            this.dtpValueDateTo.Name = "dtpValueDateTo";
            this.dtpValueDateTo.Size = new System.Drawing.Size(114, 20);
            this.dtpValueDateTo.TabIndex = 12;
            this.dtpValueDateTo.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // dtpValueDateFrom
            // 
            this.dtpValueDateFrom.CustomFormat = "yyyy/MM/dd";
            this.dtpValueDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpValueDateFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpValueDateFrom.Location = new System.Drawing.Point(73, 100);
            this.dtpValueDateFrom.Name = "dtpValueDateFrom";
            this.dtpValueDateFrom.Size = new System.Drawing.Size(114, 20);
            this.dtpValueDateFrom.TabIndex = 11;
            this.dtpValueDateFrom.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // dtpInputDateTo
            // 
            this.dtpInputDateTo.CustomFormat = "yyyy/MM/dd";
            this.dtpInputDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInputDateTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpInputDateTo.Location = new System.Drawing.Point(207, 78);
            this.dtpInputDateTo.Name = "dtpInputDateTo";
            this.dtpInputDateTo.Size = new System.Drawing.Size(114, 20);
            this.dtpInputDateTo.TabIndex = 9;
            this.dtpInputDateTo.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // dtpInputDateFrom
            // 
            this.dtpInputDateFrom.CustomFormat = "yyyy/MM/dd";
            this.dtpInputDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInputDateFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpInputDateFrom.Location = new System.Drawing.Point(73, 78);
            this.dtpInputDateFrom.Name = "dtpInputDateFrom";
            this.dtpInputDateFrom.Size = new System.Drawing.Size(114, 20);
            this.dtpInputDateFrom.TabIndex = 8;
            this.dtpInputDateFrom.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // cbbClaim
            // 
            this.cbbClaim.FormattingEnabled = true;
            this.cbbClaim.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbClaim.Items.AddRange(new object[] {
            "",
            "Claim",
            "Not Claim"});
            this.cbbClaim.Location = new System.Drawing.Point(838, 56);
            this.cbbClaim.Name = "cbbClaim";
            this.cbbClaim.Size = new System.Drawing.Size(134, 21);
            this.cbbClaim.TabIndex = 7;
            // 
            // lblClaim
            // 
            this.lblClaim.AutoSize = true;
            this.lblClaim.Location = new System.Drawing.Point(790, 60);
            this.lblClaim.Name = "lblClaim";
            this.lblClaim.Size = new System.Drawing.Size(32, 13);
            this.lblClaim.TabIndex = 80;
            this.lblClaim.Text = "Claim";
            // 
            // cbbBookingPurpose
            // 
            this.cbbBookingPurpose.FormattingEnabled = true;
            this.cbbBookingPurpose.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbBookingPurpose.Items.AddRange(new object[] {
            "",
            "Booking Purpose",
            "Not Booking Purpose"});
            this.cbbBookingPurpose.Location = new System.Drawing.Point(307, 56);
            this.cbbBookingPurpose.Name = "cbbBookingPurpose";
            this.cbbBookingPurpose.Size = new System.Drawing.Size(136, 21);
            this.cbbBookingPurpose.TabIndex = 4;
            // 
            // lblBookingPurpose
            // 
            this.lblBookingPurpose.AutoSize = true;
            this.lblBookingPurpose.Location = new System.Drawing.Point(208, 60);
            this.lblBookingPurpose.Name = "lblBookingPurpose";
            this.lblBookingPurpose.Size = new System.Drawing.Size(88, 13);
            this.lblBookingPurpose.TabIndex = 86;
            this.lblBookingPurpose.Text = "Booking Purpose";
            // 
            // colSeqLG
            // 
            this.colSeqLG.DataPropertyName = "SeqLG";
            this.colSeqLG.Frozen = true;
            this.colSeqLG.HeaderText = "SeqLG";
            this.colSeqLG.Name = "colSeqLG";
            this.colSeqLG.ReadOnly = true;
            this.colSeqLG.Visible = false;
            this.colSeqLG.Width = 65;
            // 
            // colLGNo
            // 
            this.colLGNo.DataPropertyName = "LGNo";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colLGNo.DefaultCellStyle = dataGridViewCellStyle2;
            this.colLGNo.FillWeight = 101.1236F;
            this.colLGNo.Frozen = true;
            this.colLGNo.HeaderText = "LG No";
            this.colLGNo.Name = "colLGNo";
            this.colLGNo.ReadOnly = true;
            this.colLGNo.Width = 63;
            // 
            // colPreviousLGNo
            // 
            this.colPreviousLGNo.DataPropertyName = "PreviousLGNo";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colPreviousLGNo.DefaultCellStyle = dataGridViewCellStyle3;
            this.colPreviousLGNo.FillWeight = 130.3745F;
            this.colPreviousLGNo.Frozen = true;
            this.colPreviousLGNo.HeaderText = "Previous LG No";
            this.colPreviousLGNo.Name = "colPreviousLGNo";
            this.colPreviousLGNo.ReadOnly = true;
            this.colPreviousLGNo.Width = 107;
            // 
            // colMngCode
            // 
            this.colMngCode.DataPropertyName = "MngCode";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colMngCode.DefaultCellStyle = dataGridViewCellStyle4;
            this.colMngCode.Frozen = true;
            this.colMngCode.HeaderText = "Mng Code";
            this.colMngCode.MinimumWidth = 50;
            this.colMngCode.Name = "colMngCode";
            this.colMngCode.ReadOnly = true;
            this.colMngCode.Width = 81;
            // 
            // colType
            // 
            this.colType.DataPropertyName = "Type";
            this.colType.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.colType.DropDownWidth = 100;
            this.colType.FillWeight = 109.0775F;
            this.colType.Frozen = true;
            this.colType.HeaderText = "Type";
            this.colType.MaxDropDownItems = 100;
            this.colType.MinimumWidth = 100;
            this.colType.Name = "colType";
            this.colType.ReadOnly = true;
            this.colType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colReportToSBV
            // 
            this.colReportToSBV.DataPropertyName = "ReportToSBV";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle5.NullValue")));
            this.colReportToSBV.DefaultCellStyle = dataGridViewCellStyle5;
            this.colReportToSBV.HeaderText = "Report to SBV";
            this.colReportToSBV.Name = "colReportToSBV";
            this.colReportToSBV.ReadOnly = true;
            this.colReportToSBV.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colReportToSBV.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colInputDate
            // 
            this.colInputDate.DataPropertyName = "InputDate";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Format = "yyyy/MM/dd";
            this.colInputDate.DefaultCellStyle = dataGridViewCellStyle6;
            this.colInputDate.FillWeight = 83.79958F;
            this.colInputDate.HeaderText = "Input Date";
            this.colInputDate.Name = "colInputDate";
            this.colInputDate.ReadOnly = true;
            this.colInputDate.Width = 82;
            // 
            // colValueDate
            // 
            this.colValueDate.DataPropertyName = "ValueDate";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "yyyy/MM/dd";
            this.colValueDate.DefaultCellStyle = dataGridViewCellStyle7;
            this.colValueDate.FillWeight = 90.08809F;
            this.colValueDate.HeaderText = "Value Date";
            this.colValueDate.Name = "colValueDate";
            this.colValueDate.ReadOnly = true;
            this.colValueDate.Width = 85;
            // 
            // colUpdatedDate
            // 
            dataGridViewCellStyle8.Format = "yyyy/MM/dd";
            this.colUpdatedDate.DefaultCellStyle = dataGridViewCellStyle8;
            this.colUpdatedDate.HeaderText = "TerminateDate";
            this.colUpdatedDate.Name = "colUpdatedDate";
            this.colUpdatedDate.ReadOnly = true;
            this.colUpdatedDate.Width = 102;
            // 
            // colBackValue
            // 
            this.colBackValue.DataPropertyName = "BackValue";
            this.colBackValue.FillWeight = 85.53667F;
            this.colBackValue.HeaderText = "Back Value";
            this.colBackValue.Name = "colBackValue";
            this.colBackValue.ReadOnly = true;
            this.colBackValue.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colBackValue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colBackValue.Width = 87;
            // 
            // colCustomerCode
            // 
            this.colCustomerCode.DataPropertyName = "CustomerCode";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCustomerCode.DefaultCellStyle = dataGridViewCellStyle9;
            this.colCustomerCode.HeaderText = "Customer Code";
            this.colCustomerCode.Name = "colCustomerCode";
            this.colCustomerCode.ReadOnly = true;
            this.colCustomerCode.Width = 104;
            // 
            // colCustomerName
            // 
            this.colCustomerName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colCustomerName.DataPropertyName = "CustomerName";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colCustomerName.DefaultCellStyle = dataGridViewCellStyle10;
            this.colCustomerName.HeaderText = "Customer Name";
            this.colCustomerName.MinimumWidth = 200;
            this.colCustomerName.Name = "colCustomerName";
            this.colCustomerName.ReadOnly = true;
            this.colCustomerName.Width = 200;
            // 
            // colGLCode
            // 
            this.colGLCode.DataPropertyName = "GLCode";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colGLCode.DefaultCellStyle = dataGridViewCellStyle11;
            this.colGLCode.HeaderText = "GL Code";
            this.colGLCode.Name = "colGLCode";
            this.colGLCode.ReadOnly = true;
            this.colGLCode.Width = 74;
            // 
            // colClaim
            // 
            this.colClaim.DataPropertyName = "Claim";
            this.colClaim.HeaderText = "Claim";
            this.colClaim.Name = "colClaim";
            this.colClaim.ReadOnly = true;
            this.colClaim.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colClaim.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colClaim.Width = 57;
            // 
            // colGuaranteeAmount
            // 
            this.colGuaranteeAmount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colGuaranteeAmount.DataPropertyName = "GuaranteeAmount";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle12.Format = "N2";
            this.colGuaranteeAmount.DefaultCellStyle = dataGridViewCellStyle12;
            this.colGuaranteeAmount.HeaderText = "Amount";
            this.colGuaranteeAmount.Name = "colGuaranteeAmount";
            this.colGuaranteeAmount.ReadOnly = true;
            this.colGuaranteeAmount.Width = 68;
            // 
            // colTransCurrency
            // 
            this.colTransCurrency.DataPropertyName = "TransCurrency";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colTransCurrency.DefaultCellStyle = dataGridViewCellStyle13;
            this.colTransCurrency.HeaderText = "CCY";
            this.colTransCurrency.Name = "colTransCurrency";
            this.colTransCurrency.ReadOnly = true;
            this.colTransCurrency.Width = 53;
            // 
            // colExpiryDate
            // 
            this.colExpiryDate.DataPropertyName = "ExpiryDate";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Format = "yyyy/MM/dd";
            this.colExpiryDate.DefaultCellStyle = dataGridViewCellStyle14;
            this.colExpiryDate.HeaderText = "Expiry Date";
            this.colExpiryDate.Name = "colExpiryDate";
            this.colExpiryDate.ReadOnly = true;
            this.colExpiryDate.Width = 86;
            // 
            // colGuaranteeType
            // 
            this.colGuaranteeType.DataPropertyName = "GuaranteeType";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colGuaranteeType.DefaultCellStyle = dataGridViewCellStyle15;
            this.colGuaranteeType.HeaderText = "Guarantee Type";
            this.colGuaranteeType.Name = "colGuaranteeType";
            this.colGuaranteeType.ReadOnly = true;
            this.colGuaranteeType.Width = 109;
            // 
            // colBeneficiaryName
            // 
            this.colBeneficiaryName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colBeneficiaryName.DataPropertyName = "BeneficiaryName";
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colBeneficiaryName.DefaultCellStyle = dataGridViewCellStyle16;
            this.colBeneficiaryName.HeaderText = "Beneficiary Name";
            this.colBeneficiaryName.MinimumWidth = 200;
            this.colBeneficiaryName.Name = "colBeneficiaryName";
            this.colBeneficiaryName.ReadOnly = true;
            this.colBeneficiaryName.Width = 200;
            // 
            // colChargeAccount
            // 
            this.colChargeAccount.DataPropertyName = "ChargeAccount";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colChargeAccount.DefaultCellStyle = dataGridViewCellStyle17;
            this.colChargeAccount.HeaderText = "Charge Account";
            this.colChargeAccount.MinimumWidth = 125;
            this.colChargeAccount.Name = "colChargeAccount";
            this.colChargeAccount.ReadOnly = true;
            this.colChargeAccount.Width = 125;
            // 
            // colFeeRate
            // 
            this.colFeeRate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colFeeRate.DataPropertyName = "FeeRate";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle18.Format = "N5";
            this.colFeeRate.DefaultCellStyle = dataGridViewCellStyle18;
            this.colFeeRate.HeaderText = "LG Rate (%)";
            this.colFeeRate.Name = "colFeeRate";
            this.colFeeRate.ReadOnly = true;
            this.colFeeRate.Width = 89;
            // 
            // colMin
            // 
            this.colMin.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colMin.DataPropertyName = "Min";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle19.Format = "N2";
            this.colMin.DefaultCellStyle = dataGridViewCellStyle19;
            this.colMin.HeaderText = "Min";
            this.colMin.Name = "colMin";
            this.colMin.ReadOnly = true;
            this.colMin.Width = 49;
            // 
            // colMinCCY
            // 
            this.colMinCCY.DataPropertyName = "MinCCY";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colMinCCY.DefaultCellStyle = dataGridViewCellStyle20;
            this.colMinCCY.HeaderText = "Min CCY";
            this.colMinCCY.Name = "colMinCCY";
            this.colMinCCY.ReadOnly = true;
            this.colMinCCY.Width = 73;
            // 
            // colFee
            // 
            this.colFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colFee.DataPropertyName = "Fee";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle21.Format = "N2";
            this.colFee.DefaultCellStyle = dataGridViewCellStyle21;
            this.colFee.HeaderText = "Issuing Fee";
            this.colFee.Name = "colFee";
            this.colFee.ReadOnly = true;
            this.colFee.Width = 86;
            // 
            // colFeeCCY
            // 
            this.colFeeCCY.DataPropertyName = "FeeCurrency";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colFeeCCY.DefaultCellStyle = dataGridViewCellStyle22;
            this.colFeeCCY.HeaderText = "Issuing Fee CCY";
            this.colFeeCCY.Name = "colFeeCCY";
            this.colFeeCCY.ReadOnly = true;
            this.colFeeCCY.Width = 110;
            // 
            // colOverdueFee
            // 
            this.colOverdueFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colOverdueFee.DataPropertyName = "OverdueFee";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle23.Format = "N2";
            this.colOverdueFee.DefaultCellStyle = dataGridViewCellStyle23;
            this.colOverdueFee.HeaderText = "Overdue Fee";
            this.colOverdueFee.Name = "colOverdueFee";
            this.colOverdueFee.ReadOnly = true;
            this.colOverdueFee.Width = 94;
            // 
            // colOverdueFeeCCY
            // 
            this.colOverdueFeeCCY.DataPropertyName = "OverdueFeeCurrency";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colOverdueFeeCCY.DefaultCellStyle = dataGridViewCellStyle24;
            this.colOverdueFeeCCY.HeaderText = "Overdue Fee CCY";
            this.colOverdueFeeCCY.Name = "colOverdueFeeCCY";
            this.colOverdueFeeCCY.ReadOnly = true;
            this.colOverdueFeeCCY.Width = 118;
            // 
            // colOverdueClaimFee
            // 
            this.colOverdueClaimFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colOverdueClaimFee.DataPropertyName = "OverdueClaimFee";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle25.Format = "N2";
            this.colOverdueClaimFee.DefaultCellStyle = dataGridViewCellStyle25;
            this.colOverdueClaimFee.HeaderText = "Overdue Claim Fee";
            this.colOverdueClaimFee.Name = "colOverdueClaimFee";
            this.colOverdueClaimFee.ReadOnly = true;
            this.colOverdueClaimFee.Width = 122;
            // 
            // colOverdueClaimFeeCCY
            // 
            this.colOverdueClaimFeeCCY.DataPropertyName = "OverdueClaimFeeCurrency";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colOverdueClaimFeeCCY.DefaultCellStyle = dataGridViewCellStyle26;
            this.colOverdueClaimFeeCCY.HeaderText = "Overdue Claim Fee CCY";
            this.colOverdueClaimFeeCCY.Name = "colOverdueClaimFeeCCY";
            this.colOverdueClaimFeeCCY.ReadOnly = true;
            this.colOverdueClaimFeeCCY.Width = 146;
            // 
            // colAmendUpdatedFee
            // 
            this.colAmendUpdatedFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle27.Format = "N2";
            this.colAmendUpdatedFee.DefaultCellStyle = dataGridViewCellStyle27;
            this.colAmendUpdatedFee.HeaderText = "Amend (Updated) Fee";
            this.colAmendUpdatedFee.Name = "colAmendUpdatedFee";
            this.colAmendUpdatedFee.ReadOnly = true;
            this.colAmendUpdatedFee.Width = 136;
            // 
            // colAmendUpdatedFeeCCY
            // 
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colAmendUpdatedFeeCCY.DefaultCellStyle = dataGridViewCellStyle28;
            this.colAmendUpdatedFeeCCY.HeaderText = "Amend (Updated) Fee CCY";
            this.colAmendUpdatedFeeCCY.Name = "colAmendUpdatedFeeCCY";
            this.colAmendUpdatedFeeCCY.ReadOnly = true;
            this.colAmendUpdatedFeeCCY.Width = 160;
            // 
            // colMultiTimesFee
            // 
            this.colMultiTimesFee.HeaderText = "Multi-Times Fee";
            this.colMultiTimesFee.Name = "colMultiTimesFee";
            this.colMultiTimesFee.ReadOnly = true;
            this.colMultiTimesFee.Visible = false;
            this.colMultiTimesFee.Width = 106;
            // 
            // frmLGListLGHistory
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1041, 572);
            this.Controls.Add(this.cbbBookingPurpose);
            this.Controls.Add(this.lblBookingPurpose);
            this.Controls.Add(this.cbbClaim);
            this.Controls.Add(this.lblClaim);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.cbbLGType);
            this.Controls.Add(this.lblLGCategory);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnExportToControllingBook);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtAmountTo);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtAmountFrom);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.dtpExpireDateTo);
            this.Controls.Add(this.lblExpireDate);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dtpExpireDateFrom);
            this.Controls.Add(this.dtpValueDateTo);
            this.Controls.Add(this.lblValueDate);
            this.Controls.Add(this.dtpValueDateFrom);
            this.Controls.Add(this.cbbGuaranteeType);
            this.Controls.Add(this.lblGuaranteeType);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dtpInputDateTo);
            this.Controls.Add(this.lblInputDate);
            this.Controls.Add(this.dtpInputDateFrom);
            this.Controls.Add(this.cbbCurrency);
            this.Controls.Add(this.lblCurrency);
            this.Controls.Add(this.cbbGLCode);
            this.Controls.Add(this.lblGLCode);
            this.Controls.Add(this.cbbSecurity);
            this.Controls.Add(this.lblSecurity);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.lblCustomerCode);
            this.Controls.Add(this.txtCustomerCode);
            this.Controls.Add(this.lblLGNo);
            this.Controls.Add(this.txtLGNo);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.dtgLGList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = true;
            this.Name = "frmLGListLGHistory";
            this.Text = "List LG History";
            ((System.ComponentModel.ISupportInitialize)(this.dtgLGList)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dtgLGList;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblLGNo;
        private System.Windows.Forms.TextBox txtLGNo;
        private System.Windows.Forms.Label lblCustomerCode;
        private System.Windows.Forms.TextBox txtCustomerCode;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label lblSecurity;
        private System.Windows.Forms.ComboBox cbbSecurity;
        private System.Windows.Forms.ComboBox cbbGLCode;
        private System.Windows.Forms.Label lblGLCode;
        private System.Windows.Forms.ComboBox cbbCurrency;
        private System.Windows.Forms.Label lblCurrency;
        private UserCtrl.BlankCalendar dtpInputDateFrom;
        private System.Windows.Forms.Label lblInputDate;
        private UserCtrl.BlankCalendar dtpInputDateTo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbbGuaranteeType;
        private System.Windows.Forms.Label lblGuaranteeType;
        private UserCtrl.BlankCalendar dtpValueDateTo;
        private System.Windows.Forms.Label lblValueDate;
        private UserCtrl.BlankCalendar dtpValueDateFrom;
        private UserCtrl.BlankCalendar dtpExpireDateTo;
        private System.Windows.Forms.Label lblExpireDate;
        private UserCtrl.BlankCalendar dtpExpireDateFrom;
        private System.Windows.Forms.Label lblAmount;
        private UserCtrl.NumberOnlyTextBox txtAmountFrom;
        private System.Windows.Forms.Label label14;
        private UserCtrl.NumberOnlyTextBox txtAmountTo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox ckbTemination;
        private System.Windows.Forms.CheckBox ckbCloseTechnique;
        private System.Windows.Forms.CheckBox ckbAmend;
        private System.Windows.Forms.CheckBox ckbAmendUpdate;
        private System.Windows.Forms.CheckBox ckbCorrect;
        private System.Windows.Forms.CheckBox ckbNewEntry;
        private System.Windows.Forms.ComboBox cbbLGType;
        private System.Windows.Forms.Label lblLGCategory;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnExportToControllingBook;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbPrintForm;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.ComboBox cbbClaim;
        private System.Windows.Forms.Label lblClaim;
        private UserCtrl.NumberOnlyTextBox txtSequenceToCounter;
        private UserCtrl.NumberOnlyTextBox txtSequenceFromCounter;
        private Phoenix.Lg.UserControl.DisableTextBox txtMaxNumberPrinted;
        private System.Windows.Forms.ComboBox cbbBookingPurpose;
        private System.Windows.Forms.Label lblBookingPurpose;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSeqLG;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLGNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPreviousLGNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMngCode;
        private System.Windows.Forms.DataGridViewComboBoxColumn colType;
        private System.Windows.Forms.DataGridViewImageColumn colReportToSBV;
        private System.Windows.Forms.DataGridViewTextBoxColumn colInputDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colValueDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUpdatedDate;
        private System.Windows.Forms.DataGridViewImageColumn colBackValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGLCode;
        private System.Windows.Forms.DataGridViewImageColumn colClaim;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGuaranteeAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTransCurrency;
        private System.Windows.Forms.DataGridViewTextBoxColumn colExpiryDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGuaranteeType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBeneficiaryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colChargeAccount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFeeRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMin;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMinCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFeeCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOverdueFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOverdueFeeCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOverdueClaimFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOverdueClaimFeeCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAmendUpdatedFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAmendUpdatedFeeCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMultiTimesFee;
    }
}