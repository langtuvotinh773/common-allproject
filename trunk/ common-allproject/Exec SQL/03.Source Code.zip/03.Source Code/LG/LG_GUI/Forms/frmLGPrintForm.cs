﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-01-21 09:30:00 +0700 (Mon, 21 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to management print form
 * for LG module.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Smile.Gui;
using Phoenix.Common.Smile.Obj;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGPrintForm : frmLGMaster
    {
        #region Variables
        private clsLGBus m_LGBus = null;
        //used to contain list parameter Print Type 
        private ArrayList m_arrPrintType;
        private ExcelBase m_ExcelBase;
        private string m_ProjectName = "LG";
        private CWorker m_worker;
        private bool m_isNoTransaction = false;
        private ArrayList m_arrLGStatus;
        private ArrayList m_arrFromToSBVFile;
        //private int m_SeqLG;
        //private string m_LGCode = string.Empty;
        //private string m_SubCode = string.Empty;
        //private string m_LGNo = string.Empty;
        private clsLGPrintFormDTO m_LGPrintFormDto;

        //Export to word
        private object _wordApplication = null;
        private object _wordDocument = null;
        private clsLGWordBase wordBase = new clsLGWordBase();
        private clsLGReportPrintFormDTO m_ReportPrintFormDto;
        private clsLGReportPrintFormBus m_ReportPrintFormBus;

        // Quan Add 20130509 --------------------->
        public List<object> MacroList { get; set; }
        public bool AllowImportSmile { get; set; }
        public clsErrorLogDto SmileLogInfo { get; set; }
        // <---------------------------------------

        #region REPORT WORD NAME
        private object LG_BID_BOND_FINAL_VN_FILE_NAME = "BB-Vietnamese.doc";
        private string LG_BID_BOND_FINAL_VN_TEMPLATE = "BB-Vietnamese.doc";

        private object LG_BID_BOND_FINAL_BILLINGUAL_FILE_NAME = "BB-billingual-3 signatures.doc";
        private string LG_BID_BOND_FINAL_BILLINGUAL_TEMPLATE = "BB-billingual-3 signatures.doc";

        private object LG_BID_BOND_FINAL_ENG_FILE_NAME = "BB- English.doc";
        private string LG_BID_BOND_FINAL_ENG_TEMPLATE = "BB- English.doc";

        private object LG_PERFORMANCE_BOND_FORM_BILLINGAL_FILE_NAME = "PB-billingual-3 signatures.doc";
        private string LG_PERFORMANCE_BOND_FORM_BILLINGAL_TEMPLATE = "PB-billingual-3 signatures.doc";

        private object LG_PERFORMANCE_GUARANTEE_FINAL_FILE_NAME = "PB- English.doc";
        private string LG_PERFORMANCE_GUARANTEE_FINAL_TEMPLATE = "PB- English.doc";

        private object LG_PERFORMANCE_GUARANTEE_FINAL_VN_FILE_NAME = "PB- VNese.doc";
        private string LG_PERFORMANCE_GUARANTEE_FINAL_VN_TEMPLATE = "PB- VNese.doc";

        private string LG_REPORT_NAME_BENEFICIARY = "[#NAMEBENEFICIARY]";
        private string LG_REPORT_ADDRESS_BENEFICIARY = "[#ADDRESSBENEFICIARY]";
        private string LG_REPORT_NAME_APPLICANT = "[#NAMEAPPLICANT]";
        private string LG_REPORT_CURRENCY = "[#CURRENCY]";
        private string LG_REPORT_TRANS_AMOUNT = "[#TRANSAMOUNT]";
        private string LG_REPORT_DAY_VALUE_DATE = "[#DAYVALUEDATE]";
        private string LG_REPORT_MONTH_VALUE_DATE = "[#MONTHVALUEDATE]";
        private string LG_REPORT_MONTH_NAME_VALUE_DATE = "[#MONTHNAMEVALUEDATE]";
        private string LG_REPORT_YEAR_VALUE_DATE = "[#YEARVALUEDATE]";

        private string LG_REPORT_EXPIRE_DATE = "[#EXPIREDATE]";
        private string LG_EMPTY_EXPIRE_VALUE = "[...]";
        private string LG_STATUS_CLOSE = "CLOSE";
        private string LG_STATUS_NEW = "NEW";    

        private string LG_REPORT_DAY_EXPIRE_DATE = "[#DAYEXPIREDATE]";
        private string LG_REPORT_MONTH_EXPIRE_DATE = "[#MONTHEXPIREDATE]";
        private string LG_REPORT_YEAR_EXPIRE_DATE = "[#YEAREXPIREDATE]";
        private string LG_REPORT_REPRESEN1 = "[#REPRESEN1]";
        private string LG_REPORT_REPRESEN2 = "[#REPRESEN2]";
        private string LG_REPORT_REPRESEN3 = "[#REPRESEN3]";
        private string LG_REPORT_LGNO = "[#LGNO]";

        //2013.05.22 ADD HTK S Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7
        private string LG_REPORT_CONTRACT_INFORMATION = "[#CONTRACTINFORMATION]";
        private string LG_REPORT_CUSTOMER_NAME = "[#CUSTOMERNAME]"; 
        //2013.05.22 ADD HTK E Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7
        #endregion

        #region PARAMETER REPORT FROM 1 TO SBV
        private object LG_REPORT_SBV_FILE_NAME = "FORM 1 TO SBV.doc";
        private string LG_REPORT_SBV_TEMPLATE = "FORM 1 TO SBV.doc";
        private string LG_REPORT_SBV_NUMBER = "[#NUMBER]";
        private string LG_REPORT_SBV_CONSTDATE = "[#CONSTDATE]";
        private string LG_REPORT_SBV_NAMEBTMUBANK = "[#NAMEBTMUBANK]";
        private string LG_REPORT_SBV_ADDRESSBTMUBANK = "[#ADDRESSBTMUBANK]";
        private string LG_REPORT_SBV_TELBTMUBANK = "[#TELBTMUBANK]";
        private string LG_REPORT_SBV_FAXBTMUBANK = "[#FAXBTMUBANK]";

        private string LG_REPORT_SBV_APPLICANT_NAME = "[#APPLICANTNAME]";
        private string LG_REPORT_SBV_APPLICANT_ADDRESS = "[#APPLICANTADDRESS]";
        private string LG_REPORT_SBV_APPLICANT_NATION = "[#APPLICANTNATION]";
        private string LG_REPORT_SBV_APPLICANT_TEL = "[#APPLICANTTEL]";
        private string LG_REPORT_SBV_APPLICANT_FAX = "[#APPLICANTFAX]";

        private string LG_REPORT_SBV_BENEFICIARY_NAME = "[#BENEFICIARYNAME]";
        private string LG_REPORT_SBV_BENEFICIARY_ADDRESS = "[#BENEFICIARYADDRESS]";
        private string LG_REPORT_SBV_BENEFICIARY_NATION = "[#BENEFICIARYNATION]";
        private string LG_REPORT_SBV_BENEFICIARY_TEL = "[#BENEFICIARYTEL]";
        private string LG_REPORT_SBV_BENEFICIARY_FAX = "[#BENEFICIARYFAX]";
        private string LG_REPORT_SBV_CUSTOMERNAME = "[#CUSTOMERNAME]";
        private string LG_REPORT_SBV_CUSTOMERADDRESS = "[#CUSTOMERADDRESS]";
        private string LG_REPORT_SBV_GUARANTEE_TYPE_NAME = "[#GUARANTEETYPENAME]";
        private string LG_REPORT_SBV_CONTRACT_INFORMATION = "[#CONTRACTINFORMATION]";
        private string LG_REPORT_SBV_VALUE_DATE = "[#VALUEDATE]";
        private string LG_REPORT_SBV_TRANS_AMOUNT = "[#TRANSAMOUNT]";
        private string LG_REPORT_SBV_CURRENCY = "[#CURRENCY]";
        private string LG_REPORT_SBV_EXPIRE_DATE = "[#EXPIREDATE]";

        private string LG_REPORT_SBV_LG_REF = "[#LGREF]";
        private string LG_REPORT_SBV_STATUS = "[#STATUS]";
        private string LG_REPORT_SBV_WEEKDAY = "[#WEEKDAY]";
        private string LG_REPORT_SBV_CURRENTDAY = "[#CURRENTDAY]";
        private string LG_REPORT_SBV_CURRENTMONTH = "[#CURRENTMONTH]";
        private string LG_REPORT_SBV_CURRENTYEAR = "[#CURRENTYEAR]";
        #endregion
        #endregion

        #region Contructor
        /// <summary>
        /// Contructor
        /// </summary>
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmLGPrintForm()
        {
            try
            {
                InitializeComponent();
                base.SetFormStyleCommon();
				_security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Contructor
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmLGPrintForm(int seqLG, ArrayList arrLGNo, string lGStatus, string lGType, string guaranteeType)
        {
            try
            {
                InitializeComponent();
                base.SetFormStyleCommon();
                //Initialize Common bus
                m_LGBus = new clsLGBus();
                //Initialize DTO for Report Form
                m_ReportPrintFormDto = new clsLGReportPrintFormDTO();
                //Initialize Bus for Report Form
                m_ReportPrintFormBus = new clsLGReportPrintFormBus();
                //Initialize List Print Type
                m_arrPrintType = new ArrayList();
                //Initialize List LG Status
                m_arrLGStatus = new ArrayList();
                //Initialize List From To SBV File
                m_arrFromToSBVFile = new ArrayList();
                //Initialize PrintFormDto
                m_LGPrintFormDto = new clsLGPrintFormDTO();
                //set data for PrintFormDto
                m_LGPrintFormDto.SeqLG = seqLG;
                m_LGPrintFormDto.ArrLGNo = arrLGNo;
                m_LGPrintFormDto.LGStatus = lGStatus;
                m_LGPrintFormDto.LGType = lGType;
                m_LGPrintFormDto.GuaranteeType = guaranteeType;
                //Get List LG Status
                ArrayList arrLGStatusTemp = m_LGBus.GetListLGStatus();
                m_arrLGStatus = ChangeStatusDisplay(arrLGStatusTemp);
                //Get List From To SBV File
                m_arrFromToSBVFile = m_LGBus.GetListFromToSBVFile();
                //set parameter for Print Type combobox
                SetParameterComboboxPrintType(lGStatus, lGType, guaranteeType);
                //set data display on form
                SetDataOnForm();
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        #endregion

        #region Event Functions
        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Print Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                switch (cbbType.SelectedValue.ToString())
                {
                    /* Print: New Entry
                     */
                    case "1":
                        ExportExcel(clsLGConstant.LG_REPORT_LETTER_OF_GUARANTEE_NEW_ENTRY, clsLGConstant.LG_REPORT_LETTER_OF_GUARANTEE_NEW_ENTRY_TEMPLATE);
                        break;

                    /* Print: Termination
                    */
                    case "2":
                        ExportExcel(clsLGConstant.LG_REPORT_LETTER_OF_GUARANTEE_TERMINATION, clsLGConstant.LG_REPORT_LETTER_OF_GUARANTEE_TERMINATION_TEMPLATE);
                        break;

                    /* Print: bid bond EN
                    */
                    case "3":
                        ExportWord(cbbType.SelectedValue.ToString());
                        break;

                    /* Print: bid bond VN
                    */
                    case "4":
                        ExportWord(cbbType.SelectedValue.ToString());
                        break;

                    /* Print: bid bond bilingual
                    */
                    case "5":
                        ExportWord(cbbType.SelectedValue.ToString());
                        break;

                    /* Print: performance VN
                    */
                    case "6":
                        ExportWord(cbbType.SelectedValue.ToString());
                        break;

                    /* Print: performance EN
                    */
                    case "7":
                        ExportWord(cbbType.SelectedValue.ToString());
                        break;

                    /* Print: performance bilingual
                    */
                    case "8":
                        ExportWord(cbbType.SelectedValue.ToString());
                        break;

                    /* Print: form 1 to SBV
                    */
                    case "9":
                        ExportWord(cbbType.SelectedValue.ToString());
                        this.DialogResult = System.Windows.Forms.DialogResult.OK;
                        break;
                    case "":
                        clsLGMesageCollection.ShowMessage(2, String.Format(clsLGCommonMessage.INFOR_CHOOSE_VALUE_COMBOBOX, lblType.Text));
                        break;
                    default:
                        break;
                }                
            }
            catch (System.Exception ex)
            {                
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Handles the FormClosed event of the frmLGPrintForm control.
        /// </summary>
        private void frmLGPrintForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Start SMILE Interface
            if (AllowImportSmile)
            {
                frmAllSmileConfirmation frmConfirm = new frmAllSmileConfirmation(MacroList);
                frmConfirm.Tag = Tag;
                frmConfirm.ErrorLogInfo = SmileLogInfo;
                frmConfirm.StartPosition = FormStartPosition.CenterScreen;
                frmConfirm.ShowDialog();
            }
        }
        #endregion

        #region Private Functions
        
        /// <summary>
        /// Set data display on form
        /// </summary>
        /// <param name="arrLGNo"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void SetDataOnForm()
        {
            for (int i = 0; i < m_LGPrintFormDto.ArrLGNo.Count; i++)
            {
                if (i == 0)
                {
                    txtLGNo.Text += m_LGPrintFormDto.ArrLGNo[i].ToString();
                }
                else
                {
                    txtLGNo.Text += ", " + m_LGPrintFormDto.ArrLGNo[i].ToString();
                }
            }
        }

        /// <summary>
        /// Set data display on form
        /// </summary>
        /// <param name="arrLGNo"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private ArrayList ChangeStatusDisplay(ArrayList arr)
        {
            ArrayList newStatusArray = new ArrayList();
            foreach (CbbObject obj in arr)
            {
                if (obj.Value.ToString().Trim() == "1" || obj.Value.ToString().Trim() == "2")
                {
                    newStatusArray.Add(new CbbObject(obj.Value, LG_STATUS_NEW));
                }
                else if (obj.Value.ToString().Trim() == "6")
                {
                    newStatusArray.Add(new CbbObject(obj.Value, LG_STATUS_CLOSE));
                }
                else
                {
                    newStatusArray.Add(new CbbObject(obj.Value, obj.Display));
                }
            }
            return newStatusArray;
        }

        /// <summary>
        /// Set Parameter Combobox PrintType
        /// </summary>
        /// <param name="dto"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond

        /// <summary>
        /// Set Parameter for PrintType Combobox
        /// </summary>
        /// <param name="lGStatus"></param>
        /// <param name="lGType"></param>
        /// <param name="guaranteeType"></param>
        private void SetParameterComboboxPrintType(string lGStatus, string lGType, string guaranteeType)
        {
            //get list Print Type Parameters
            ArrayList arr = m_LGBus.GetListPrintForm();
            switch (lGStatus)
            {
                /* LGStatus = 1 ('New Entry')
                 * In case status of LG is New Entry, type print form is
                 * + New Entry
                 */
                case "1":
                    /* LGType = 2 ('Counter')
                     * - In case LG is Counter type, user can select more forms to print out: 
                     *   + Form 1 to SBV
                     */
                    if (lGType.Equals("2"))
                    {
                        for (int i = 0; i < arr.Count; i++)
                        {
                            CbbObject obj = (CbbObject)arr[i];
                            if (obj.Value.Equals(string.Empty) || obj.Value.Equals("1") || obj.Value.Equals("9"))
                            {
                                m_arrPrintType.Add(arr[i]);
                            }
                        }
                    }
                    /* LGType = 1 ('Proper')
                     * - In case LG is Proper type
                     *  + Guarantee Type = 651(Bid Bond) user can select more forms to print out:
                     *      Bid bond English
                     *      Bid bond VietNam
                     *      Billingual forms.
                     *  + Guarantee Type = 741(Performance Bond) user can select more forms to print out:
                     *      Performance bond English
                     *      Performance bond VietNamese
                     *      Billingual forms.
                     */
                    else
                    {
                        for (int i = 0; i < arr.Count; i++)
                        {
                            CbbObject obj = (CbbObject)arr[i];
                            if (obj.Value.Equals(string.Empty) || obj.Value.Equals("1"))
                            {
                                m_arrPrintType.Add(arr[i]);
                            }
                            //651(Bid Bond)
                            if (guaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_BB))
                            {
                                if (obj.Value.Equals("3") || obj.Value.Equals("4") || obj.Value.Equals("5"))
                                {
                                    m_arrPrintType.Add(arr[i]);
                                }
                            }
                            //741(Performance Bond)
                            else if (guaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_PB))
                            {
                                if (obj.Value.Equals("6") || obj.Value.Equals("7") || obj.Value.Equals("8"))
                                {
                                    m_arrPrintType.Add(arr[i]);
                                }
                            }
                        }
                    }
                    break;

                /* LGStatus = 2 ('Correct')
                *  In case status of LG is Terminate, type print form is
                * + Termination
                */
                case "2":
                    /* LGType = 2 ('Counter')
                     * - In case LG is Counter type, user can select more forms to print out: 
                     *   + Form 1 to SBV
                     */
                    if (lGType.Equals("2"))
                    {
                        for (int i = 0; i < arr.Count; i++)
                        {
                            CbbObject obj = (CbbObject)arr[i];
                            if (obj.Value.Equals(string.Empty) || obj.Value.Equals("1") || obj.Value.Equals("9"))
                            {
                                m_arrPrintType.Add(arr[i]);
                            }
                        }
                    }
                    /* LGType = 1 ('Proper')
                     * - In case LG is Proper type
                     *  + Guarantee Type = 651(Bid Bond) user can select more forms to print out:
                     *      Bid bond English
                     *      Bid bond VietNam
                     *      Billingual forms.
                     *  + Guarantee Type = 741(Performance Bond) user can select more forms to print out:
                     *      Performance bond English
                     *      Performance bond VietNamese
                     *      Billingual forms.
                     */
                    else
                    {
                        for (int i = 0; i < arr.Count; i++)
                        {
                            CbbObject obj = (CbbObject)arr[i];
                            if (obj.Value.Equals(string.Empty) || obj.Value.Equals("1"))
                            {
                                m_arrPrintType.Add(arr[i]);
                            }
                            //651(Bid Bond)
                            if (guaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_BB))
                            {
                                if (obj.Value.Equals("3") || obj.Value.Equals("4") || obj.Value.Equals("5"))
                                {
                                    m_arrPrintType.Add(arr[i]);
                                }
                            }
                            //741(Performance Bond)
                            else if (guaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_PB))
                            {
                                if (obj.Value.Equals("6") || obj.Value.Equals("7") || obj.Value.Equals("8"))
                                {
                                    m_arrPrintType.Add(arr[i]);
                                }
                            }
                        }
                    }
                    break;

                /* LGStatus = 3 ('Amend Update')
                *  In case status of LG is Terminate, type print form is
                * + Termination
                */
                case "3":
                    for (int i = 0; i < arr.Count; i++)
                    {
                        CbbObject obj = (CbbObject)arr[i];
                        if (obj.Value.Equals(string.Empty) || obj.Value.Equals("1"))
                        {
                            m_arrPrintType.Add(arr[i]);
                        }
                    }
                    break;

                /* LGStatus = 4 ('Amend')
                *  In case status of LG is Terminate, type print form is
                * + Termination
                */
                case "4":
                    for (int i = 0; i < arr.Count; i++)
                    {
                        CbbObject obj = (CbbObject)arr[i];
                        if (obj.Value.Equals(string.Empty) || obj.Value.Equals("1"))
                        {
                            m_arrPrintType.Add(arr[i]);
                        }
                    }
                    break;

                /* LGStatus = 6 ('Temination')
                *  In case status of LG is Terminate, type print form is
                * + Termination
                */
                case "6":
                    for (int i = 0; i < arr.Count; i++)
                    {
                        CbbObject obj = (CbbObject)arr[i];
                        if (obj.Value.Equals(string.Empty) || obj.Value.Equals("2"))
                        {
                            m_arrPrintType.Add(arr[i]);
                        }
                    }
                    break;
                default:
                    break;
            }
            
            //Remove Empty Item
            if (m_arrPrintType.Count > 0)
            {
                m_arrPrintType.RemoveAt(0);
            }            
            //fill data into combobox Type            
            clsLGCommonFunction.FillComboboxData(m_arrPrintType, cbbType);            
        }

        #region Export report LETTER OF GUARANTEE - NEW ENTRY and LETTER OF GUARANTEE-TERMINATION
        /// <summary>
        /// Export report LETTER OF GUARANTEE - NEW ENTRY and LETTER OF GUARANTEE-TERMINATION
        /// </summary>
        /// @cond
        /// Author: Nguyen Danh Tho
        /// @endcond
        private void ExportExcel(string fileName, string template)
        {
            //Initialize list report form
            List<clsLGReportLetterOfGuaranteeDTO> lst = new List<clsLGReportLetterOfGuaranteeDTO>();
            //get date from server
            DateTime serverDate = clsLGCommonBus.Instance().GetServerDate();
            m_isNoTransaction = false;
            btnPrint.Enabled = false;
            for (int i = 0; i < m_LGPrintFormDto.ArrLGNo.Count; i++)
            {
                clsLGReportLetterOfGuaranteeDTO obj = new clsLGReportLetterOfGuaranteeDTO();
                //get dto from database
                obj = m_ReportPrintFormBus.GetLGReportLetterOfGuarantee(m_LGPrintFormDto.SeqLG, m_LGPrintFormDto.ArrLGNo[i].ToString());
                obj.LGNo = m_LGPrintFormDto.ArrLGNo[i].ToString();
                //check it is exist
                if (obj.Row == 0)
                {
                    m_isNoTransaction = true;
                    clsLGMesageCollection.MessageNoTransactions();
                    break;
                }
                lst.Add(obj);
            }

            if (m_isNoTransaction == false)
            {
                for (int i = 0; i < lst.Count; i++)
                {
                    bool isOpened = false;
                    m_ExcelBase = new ExcelBase(fileName, template, m_ProjectName, ref isOpened, String.Concat(lst[i].LGNo, "_", serverDate.ToString("yyyyMMdd")));
                    if (isOpened)
                    {
                        continue;
                    }
                    switch (fileName)
                    {
                        case clsLGConstant.LG_REPORT_LETTER_OF_GUARANTEE_NEW_ENTRY:
                            //export excel Letter Of Guarantee Entry
                            ExportReportLetterOfGuaranteeNewEntry(lst[i]);
                            Complete();                            
                            break;
                        case clsLGConstant.LG_REPORT_LETTER_OF_GUARANTEE_TERMINATION:
                            //export excel Letter Of Guarantee Termination
                            ExportReportLetterOfGuaranteeTermination(lst[i]);
                            Complete();                            
                            break;
                    }
                }
            }
            btnPrint.Enabled = true;
        }
        #endregion

        #region Export Report LETTER OF GUARANTEE - NEW ENTRY
        /// <summary>
        /// Export Report LETTER OF GUARANTEE - NEW ENTRY
        /// </summary>
        /// @cond
        /// Author: Nguyen Danh Tho
        /// @endcond
        private void ExportReportLetterOfGuaranteeNewEntry(clsLGReportLetterOfGuaranteeDTO obj)
        {
            //insert data to report Letter Of Guarantee New Entry
            m_ExcelBase.InsertText(2, 1, clsLGConstant.LG_REPORT_LETTER_OF_GUARANTEE_NEW_ENTRY);
            m_ExcelBase.InsertText(2, 4, obj.InputDate);
            m_ExcelBase.InsertText(4, 4, obj.ValueDate);
            m_ExcelBase.InsertText(11, 2, obj.LGNo);
            m_ExcelBase.InsertText(4, 6, clsLGCommonFunction.GetDisplay(m_arrLGStatus, obj.Kind));
            m_ExcelBase.InsertText(2, 10, obj.CustomerCode);
            m_ExcelBase.InsertText(4, 10, obj.CustomerName);
            m_ExcelBase.InsertText(2, 13, obj.Currency);
            m_ExcelBase.InsertText(4, 13, obj.GLCode);
            m_ExcelBase.InsertText(6, 13, obj.LGNo);
            if (obj.Currency == clsLGConstant.LG_CURRENCY_VND || obj.Currency == clsLGConstant.LG_CURRENCY_JPY)
            {
                m_ExcelBase.InsertText(8, 13, obj.GuaranteeAmount.ToString(clsLGConstant.FORMAT_NUMBER_N));
            }
            else
            {
                m_ExcelBase.InsertText(8, 13, obj.GuaranteeAmount.ToString(clsLGConstant.FORMAT_NUMBER_N2));
            }
            m_ExcelBase.InsertText(2, 16, obj.ExpireDate);
            m_ExcelBase.InsertText(8, 15, obj.GuaranteeType);
            m_ExcelBase.InsertText(4, 18, obj.BeneficiaryName);
            m_ExcelBase.InsertText(2, 27, obj.Acc);
            m_ExcelBase.InsertText(4, 27, obj.Rate.ToString(clsLGConstant.FORMAT_NUMBER_N5));
            //2013.05.02 ADD HTK S Fix Feedback 20130514 
            m_ExcelBase.InsertText(6, 26, String.Format(clsLGConstant.LG_PRINT_FORM_MIN_LABEL, obj.MinCurrency));
            //2013.05.02 ADD HTK E Fix Feedback 20130514 
            if (obj.MinCurrency == clsLGConstant.LG_CURRENCY_VND || obj.MinCurrency == clsLGConstant.LG_CURRENCY_JPY)
            {
                m_ExcelBase.InsertText(6, 27, obj.Min.ToString(clsLGConstant.FORMAT_NUMBER_N));
            }
            else
            {
                m_ExcelBase.InsertText(6, 27, obj.Min.ToString(clsLGConstant.FORMAT_NUMBER_N2));
            }
            //2013.05.02 UPD HTK S Fix Feedback 20130514 
            //if (obj.FeeCurrency == clsLGConstant.LG_CURRENCY_VND || obj.FeeCurrency == clsLGConstant.LG_CURRENCY_JPY)
            //{
            //    m_ExcelBase.InsertText(8, 27, obj.Fee.ToString(clsLGConstant.FORMAT_NUMBER_N));
            //}
            //else
            //{
            //    m_ExcelBase.InsertText(8, 27, obj.Fee.ToString(clsLGConstant.FORMAT_NUMBER_N2));
            //}
            if (obj.FeeCurrency == clsLGConstant.LG_CURRENCY_VND || obj.FeeCurrency == clsLGConstant.LG_CURRENCY_JPY)
            {
                m_ExcelBase.InsertText(8, 27, obj.FeeCurrency + obj.Fee.ToString(clsLGConstant.FORMAT_NUMBER_N));
            }
            else
            {
                m_ExcelBase.InsertText(8, 27, obj.FeeCurrency + obj.Fee.ToString(clsLGConstant.FORMAT_NUMBER_N2));
            }
            //2013.05.02 UPD HTK E Fix Feedback 20130514 
        }
        #endregion

        #region Export Report LETTER OF GUARANTEE - TERMINATION
        /// <summary>
        /// Export Report LETTER OF GUARANTEE - TERMINATION
        /// </summary>
        /// @cond
        /// Author: Nguyen Danh Tho
        /// @endcond
        private void ExportReportLetterOfGuaranteeTermination(clsLGReportLetterOfGuaranteeDTO obj)
        {
            //insert data to report Letter Of Guarantee Termination
            m_ExcelBase.InsertText(2, 1, clsLGConstant.LG_REPORT_LETTER_OF_GUARANTEE_TERMINATION);
            m_ExcelBase.InsertText(2, 4, obj.UpdateDate);
            m_ExcelBase.InsertText(4, 4, obj.UpdateDate);
            m_ExcelBase.InsertText(11, 2, obj.LGNo);
            m_ExcelBase.InsertText(4, 6, clsLGCommonFunction.GetDisplay(m_arrLGStatus, obj.Kind));
            m_ExcelBase.InsertText(2, 10, obj.CustomerCode);
            m_ExcelBase.InsertText(4, 10, obj.CustomerName);
            m_ExcelBase.InsertText(2, 13, obj.Currency);
            m_ExcelBase.InsertText(4, 13, obj.GLCode);
            m_ExcelBase.InsertText(6, 13, obj.LGNo);
            
            if (obj.Currency == clsLGConstant.LG_CURRENCY_VND || obj.Currency == clsLGConstant.LG_CURRENCY_JPY)
            {
                m_ExcelBase.InsertText(8, 13, obj.GuaranteeAmount.ToString(clsLGConstant.FORMAT_NUMBER_N));
            }
            else
            {
                m_ExcelBase.InsertText(8, 13, obj.GuaranteeAmount.ToString(clsLGConstant.FORMAT_NUMBER_N2));
            }
            m_ExcelBase.InsertText(2, 16, obj.ExpireDate);
            m_ExcelBase.InsertText(8, 15, obj.GuaranteeType);
            m_ExcelBase.InsertText(4, 18, obj.BeneficiaryName);
        }
        #endregion

        #region COMPLETE EXPORT EXCEL
        /// <summary>
        /// Handling when completed a thread
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void Complete()
        {
            if (m_isNoTransaction == true)
            {
                m_ExcelBase.SaveFile(false);
            }
            else
            {
                m_ExcelBase.SaveFile(true);
            }
            if (m_worker != null)
                m_worker.Stop();
        }
        #endregion

        /// <summary>
        /// Export Word by Print Type
        /// </summary>
        /// <param name="typePrintForm"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ExportWord(string typePrintForm)
        {
            List<clsLGReportPrintFormDTO> lst = new List<clsLGReportPrintFormDTO>();
            for (int i = 0; i < m_LGPrintFormDto.ArrLGNo.Count; i++)
            {
                string[] arr = m_LGPrintFormDto.ArrLGNo[i].ToString().Split('-');
                //get data for report print form
                m_ReportPrintFormDto = m_ReportPrintFormBus.ReportWordPrintForm(arr[0], arr[1], cbbType.SelectedValue.ToString(), m_LGPrintFormDto.SeqLG);
                if (m_ReportPrintFormDto == null)
                {
                    clsLGMesageCollection.MessageNoTransactions();
                    return;
                }
                lst.Add(m_ReportPrintFormDto);
            }

            if (lst.Count > 0)
            {
                //write log history after export report SBV FILE
                if (cbbType.SelectedValue.ToString().Equals("9"))
                {
                    WriteLog(lst[0]);                    
                }
                for (int i = 0; i < lst.Count; i++)
                {
                    //get server date
                    DateTime serverDate = clsLGCommonBus.Instance().GetServerDate();
                    switch (cbbType.SelectedValue.ToString())
                    {
                        /* Print: bid bond EN
                        */
                        case "3":
                            ExportToWordBidBondFinalEng(lst[i], serverDate);
                            break;

                        /* Print: bid bond VN
                        */
                        case "4":
                            ExportToWordBidBondFinalVN(lst[i], serverDate);
                            break;

                        /* Print: bid bond bilingual
                        */
                        case "5":
                            ExportToWordBidBondFinalBillingual(lst[i], serverDate);
                            break;

                        /* Print: performance VN
                        */
                        case "6":
                            ExportToWordPerformanceGuaranteeFinalVN(lst[i], serverDate);
                            break;

                        /* Print: performance EN
                        */
                        case "7":
                            ExportToWordPerformanceGuaranteeFinal(lst[i], serverDate);
                            break;

                        /* Print: performance bilingual
                        */
                        case "8":
                            ExportToWordPerformanceBondFromBillingal(lst[i], serverDate);
                            break;

                        /* Print: form 1 to SBV
                        */
                        case "9":
                            ExportToWordForm1ToSBV(lst[i], serverDate);

                            break;
                    }
                }
                
            }
        }

        /// <summary>
        /// Write Log History after export report SBV File
        /// </summary>
        /// <param name="reportDto"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLog(clsLGReportPrintFormDTO reportDto)
        {
            clsLGLogBase logBase = new clsLGLogBase();
            //header history
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Key = reportDto.LGCode;
            //+ Updating Log 
            logBase.Action = (int)CommonValue.ActionType.Update;
            logBase.LstLogInformation.Add(new clsLGLogInformation
            {
                FieldName = clsLGConstant.LG_NumReportSBV,
                OldValue = (reportDto.NumReportSBV - 1).ToString(),
                NewValue = reportDto.NumReportSBV.ToString()
            });
            m_ReportPrintFormBus.WriteLog(logBase);
        }

        /// <summary>
        /// Export BID BOND FINAL ENG 14.06.05
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ExportToWordBidBondFinalEng(clsLGReportPrintFormDTO dto, DateTime serverDate)
        {
            //Declaration
            Hashtable htData = new Hashtable();

            _wordApplication = clsLGDocumentExporter.AppClass;

            _wordDocument = wordBase.CreateWordDoc(LG_BID_BOND_FINAL_ENG_FILE_NAME,
                _wordApplication, false, m_ProjectName, LG_BID_BOND_FINAL_ENG_TEMPLATE, serverDate);

            //Add Value             
            htData.Add(LG_REPORT_NAME_BENEFICIARY, dto.BeneficiaryName);
            htData.Add(LG_REPORT_ADDRESS_BENEFICIARY, dto.BeneficiaryAddress);
            //2013.05.02 UPD HTK S Fix Feedback 20130514 
            //htData.Add(LG_REPORT_LGNO, dto.LGNo);
            htData.Add(LG_REPORT_LGNO, dto.LGCode);
            //2013.05.02 UPD HTK E Fix Feedback 20130514 
            htData.Add(LG_REPORT_NAME_APPLICANT, dto.ApplicantName);
            //2013.05.02 UPD HTK S Fix Feedback 20130429 
            //htData.Add(LG_REPORT_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));
            htData.Add(LG_REPORT_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));
            //2013.05.02 UPD HTK S Fix Feedback 20130429 
            htData.Add(LG_REPORT_CURRENCY, dto.TransCurrency);
            htData.Add(LG_REPORT_TRANS_AMOUNT, dto.TransAmountFormat);
            htData.Add(LG_REPORT_DAY_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_MONTH_NAME_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_MONTH_NAME));
            htData.Add(LG_REPORT_YEAR_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            htData.Add(LG_REPORT_REPRESEN1, dto.Representation1);
            htData.Add(LG_REPORT_REPRESEN2, dto.Representation2);
            htData.Add(LG_REPORT_REPRESEN3, dto.Representation3);

            //2013.05.22 ADD HTK S Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7
            htData.Add(LG_REPORT_CONTRACT_INFORMATION, dto.ContractInformation);
            htData.Add(LG_REPORT_CUSTOMER_NAME, dto.CustomerName);
            //2013.05.22 ADD HTK E Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7

            if (_wordApplication != null && _wordDocument != null)
            {
                wordBase.FindReplace(_wordDocument, _wordApplication, htData);
            }
        }

        /// <summary>
        /// Export BID BOND FINAL 14.06.05.VN
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ExportToWordBidBondFinalVN(clsLGReportPrintFormDTO dto, DateTime serverDate)
        {
            //Declaration
            Hashtable htData = new Hashtable();

            _wordApplication = clsLGDocumentExporter.AppClass;

            _wordDocument = wordBase.CreateWordDoc(LG_BID_BOND_FINAL_VN_FILE_NAME,
                _wordApplication, false, m_ProjectName, LG_BID_BOND_FINAL_VN_TEMPLATE, serverDate);

            //Add Value                    
            htData.Add(LG_REPORT_NAME_BENEFICIARY, dto.BeneficiaryName);
            //2013.05.02 UPD HTK S Fix Feedback 20130514 
            //htData.Add(LG_REPORT_LGNO, dto.LGNo);
            htData.Add(LG_REPORT_LGNO, dto.LGCode);
            //2013.05.02 UPD HTK E Fix Feedback 20130514 
            //2013.05.02 UPD HTK S Fix Feedback 20130429 
            //htData.Add(LG_REPORT_DAY_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            //htData.Add(LG_REPORT_MONTH_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            //htData.Add(LG_REPORT_YEAR_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            htData.Add(LG_REPORT_DAY_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_MONTH_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            htData.Add(LG_REPORT_YEAR_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            //2013.05.02 UPD HTK E Fix Feedback 20130429 
            htData.Add(LG_REPORT_CURRENCY, dto.TransCurrency);
            htData.Add(LG_REPORT_TRANS_AMOUNT, dto.TransAmountFormat);
            htData.Add(LG_REPORT_DAY_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_MONTH_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            htData.Add(LG_REPORT_YEAR_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            htData.Add(LG_REPORT_REPRESEN1, dto.Representation1);
            htData.Add(LG_REPORT_REPRESEN2, dto.Representation2);
            htData.Add(LG_REPORT_REPRESEN3, dto.Representation3);

            //2013.05.22 ADD HTK S Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7           
            htData.Add(LG_REPORT_CONTRACT_INFORMATION, dto.ContractInformation);
            htData.Add(LG_REPORT_CUSTOMER_NAME, dto.CustomerName);
            //2013.05.22 ADD HTK E Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7

            if (_wordApplication != null && _wordDocument != null)
            {
                wordBase.FindReplace(_wordDocument, _wordApplication, htData);
            }
        }

        /// <summary>
        /// Export BID BOND FINAL BILLINGUAL 14.06.05
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ExportToWordBidBondFinalBillingual(clsLGReportPrintFormDTO dto, DateTime serverDate)
        {
            //Declaration
            Hashtable htData = new Hashtable();

            _wordApplication = clsLGDocumentExporter.AppClass;

            _wordDocument = wordBase.CreateWordDoc(LG_BID_BOND_FINAL_BILLINGUAL_FILE_NAME,
                _wordApplication, false, m_ProjectName, LG_BID_BOND_FINAL_BILLINGUAL_TEMPLATE, serverDate);

            //Add Value
            htData.Add(LG_REPORT_NAME_BENEFICIARY, dto.BeneficiaryName);
            //2013.05.02 UPD HTK S Fix Feedback 20130514 
            //htData.Add(LG_REPORT_LGNO, dto.LGNo);
            htData.Add(LG_REPORT_LGNO, dto.LGCode);
            //2013.05.02 UPD HTK E Fix Feedback 20130514 
            htData.Add(LG_REPORT_NAME_APPLICANT, dto.ApplicantName);
            //2013.05.02 UPD HTK S Fix Feedback 20130429 
            //htData.Add(LG_REPORT_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));
            //htData.Add(LG_REPORT_DAY_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            //htData.Add(LG_REPORT_MONTH_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            //htData.Add(LG_REPORT_YEAR_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            htData.Add(LG_REPORT_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));
            htData.Add(LG_REPORT_DAY_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_MONTH_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            htData.Add(LG_REPORT_YEAR_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            //2013.05.02 UPD HTK S Fix Feedback 20130429 
            htData.Add(LG_REPORT_CURRENCY, dto.TransCurrency);
            htData.Add(LG_REPORT_TRANS_AMOUNT, dto.TransAmountFormat);
            htData.Add(LG_REPORT_DAY_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_MONTH_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            htData.Add(LG_REPORT_MONTH_NAME_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_MONTH_NAME));
            htData.Add(LG_REPORT_YEAR_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            htData.Add(LG_REPORT_REPRESEN1, dto.Representation1);
            htData.Add(LG_REPORT_REPRESEN2, dto.Representation2);
            htData.Add(LG_REPORT_REPRESEN3, dto.Representation3);

            //2013.05.22 ADD HTK S Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7
            htData.Add(LG_REPORT_CONTRACT_INFORMATION, dto.ContractInformation);
            htData.Add(LG_REPORT_CUSTOMER_NAME, dto.CustomerName);
            //2013.05.22 ADD HTK E Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7

            if (_wordApplication != null && _wordDocument != null)
            {
                wordBase.FindReplace(_wordDocument, _wordApplication, htData);
            }
        }

        /// <summary>
        /// Export PERFORMANCE GUARANTEE FINAL VN
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ExportToWordPerformanceGuaranteeFinalVN(clsLGReportPrintFormDTO dto, DateTime serverDate)
        {
            //Declaration            
            Hashtable htData = new Hashtable();

            _wordApplication = clsLGDocumentExporter.AppClass;

            _wordDocument = wordBase.CreateWordDoc(LG_PERFORMANCE_GUARANTEE_FINAL_VN_FILE_NAME,
                _wordApplication, false, m_ProjectName, LG_PERFORMANCE_GUARANTEE_FINAL_VN_TEMPLATE, serverDate);

            //Add Value
            htData.Add(LG_REPORT_NAME_BENEFICIARY, dto.BeneficiaryName);
            //2013.05.02 UPD HTK S Fix Feedback 20130514 
            //htData.Add(LG_REPORT_LGNO, dto.LGNo);
            htData.Add(LG_REPORT_LGNO, dto.LGCode);
            //2013.05.02 UPD HTK E Fix Feedback 20130514 
            htData.Add(LG_REPORT_CURRENCY, dto.TransCurrency);
            htData.Add(LG_REPORT_TRANS_AMOUNT, dto.TransAmountFormat);
            
            //2013.05.02 UPD HTK S Fix Feedback 20130429 
            //htData.Add(LG_REPORT_DAY_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            //htData.Add(LG_REPORT_MONTH_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            //htData.Add(LG_REPORT_YEAR_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            htData.Add(LG_REPORT_DAY_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_MONTH_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            htData.Add(LG_REPORT_YEAR_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            //2013.05.02 UPD HTK E Fix Feedback 20130429 
            htData.Add(LG_REPORT_DAY_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_MONTH_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            htData.Add(LG_REPORT_YEAR_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            htData.Add(LG_REPORT_REPRESEN1, dto.Representation1);
            htData.Add(LG_REPORT_REPRESEN2, dto.Representation2);
            htData.Add(LG_REPORT_REPRESEN3, dto.Representation3);

            //2013.05.22 ADD HTK S Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7            
            htData.Add(LG_REPORT_CONTRACT_INFORMATION, dto.ContractInformation);
            htData.Add(LG_REPORT_CUSTOMER_NAME, dto.CustomerName);
            //2013.05.22 ADD HTK E Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7

            if (_wordApplication != null && _wordDocument != null)
            {
                wordBase.FindReplace(_wordDocument, _wordApplication, htData);
            }
        }

        /// <summary>
        /// Export PERFORMANCE GUARANTEE FINAL 02.06.05
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ExportToWordPerformanceGuaranteeFinal(clsLGReportPrintFormDTO dto, DateTime serverDate)
        {
            //Declaration            
            Hashtable htData = new Hashtable();

            _wordApplication = clsLGDocumentExporter.AppClass;

            _wordDocument = wordBase.CreateWordDoc(LG_PERFORMANCE_GUARANTEE_FINAL_FILE_NAME,
                _wordApplication, false, m_ProjectName, LG_PERFORMANCE_GUARANTEE_FINAL_TEMPLATE, serverDate);

            //Add Value
            htData.Add(LG_REPORT_NAME_BENEFICIARY, dto.BeneficiaryName);
            htData.Add(LG_REPORT_ADDRESS_BENEFICIARY, dto.BeneficiaryAddress);
            //2013.05.02 UPD HTK S Fix Feedback 20130514 
            //htData.Add(LG_REPORT_LGNO, dto.LGNo);
            htData.Add(LG_REPORT_LGNO, dto.LGCode);
            //2013.05.02 UPD HTK E Fix Feedback 20130514 
            htData.Add(LG_REPORT_CURRENCY, dto.TransCurrency);
            htData.Add(LG_REPORT_TRANS_AMOUNT, dto.TransAmountFormat);
            //2013.05.02 UPD HTK S Fix Feedback 20130429 
            //htData.Add(LG_REPORT_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));
            htData.Add(LG_REPORT_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));
            //2013.05.02 UPD HTK E Fix Feedback 20130429 
            htData.Add(LG_REPORT_DAY_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_MONTH_NAME_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_MONTH_NAME));
            htData.Add(LG_REPORT_YEAR_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            htData.Add(LG_REPORT_REPRESEN1, dto.Representation1);
            htData.Add(LG_REPORT_REPRESEN2, dto.Representation2);
            htData.Add(LG_REPORT_REPRESEN3, dto.Representation3);

            //2013.05.22 ADD HTK S Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7            
            htData.Add(LG_REPORT_CONTRACT_INFORMATION, dto.ContractInformation);
            htData.Add(LG_REPORT_CUSTOMER_NAME, dto.CustomerName);
            //2013.05.22 ADD HTK E Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7

            if (_wordApplication != null && _wordDocument != null)
            {
                wordBase.FindReplace(_wordDocument, _wordApplication, htData);
            }
        }

        /// <summary>
        /// Export PERFORMANCE BOND FORM - BILLINGAL
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ExportToWordPerformanceBondFromBillingal(clsLGReportPrintFormDTO dto, DateTime serverDate)
        {
            //Declaration            
            Hashtable htData = new Hashtable();

            _wordApplication = clsLGDocumentExporter.AppClass;

            _wordDocument = wordBase.CreateWordDoc(LG_PERFORMANCE_BOND_FORM_BILLINGAL_FILE_NAME,
                _wordApplication, false, m_ProjectName, LG_PERFORMANCE_BOND_FORM_BILLINGAL_TEMPLATE, serverDate);

            //Add Value   
            //2013.05.02 UPD HTK S Fix Feedback 20130514 
            //htData.Add(LG_REPORT_LGNO, dto.LGNo);
            htData.Add(LG_REPORT_LGNO, dto.LGCode);
            //2013.05.02 UPD HTK E Fix Feedback 20130514 
            htData.Add(LG_REPORT_CURRENCY, dto.TransCurrency);
            htData.Add(LG_REPORT_TRANS_AMOUNT, dto.TransAmountFormat);
            //2013.05.02 UPD HTK S Fix Feedback 20130429 
            //htData.Add(LG_REPORT_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));
            htData.Add(LG_REPORT_EXPIRE_DATE, dto.ExpireDate.Equals(DateTime.MinValue) ? LG_EMPTY_EXPIRE_VALUE : dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));
            //2013.05.02 UPD HTK E Fix Feedback 20130429 
            htData.Add(LG_REPORT_DAY_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_MONTH_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            htData.Add(LG_REPORT_YEAR_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_YEAR));
            htData.Add(LG_REPORT_REPRESEN1, dto.Representation1);
            htData.Add(LG_REPORT_REPRESEN2, dto.Representation2);
            htData.Add(LG_REPORT_REPRESEN3, dto.Representation3);

            //2013.05.22 ADD HTK S Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7            
            htData.Add(LG_REPORT_CONTRACT_INFORMATION, dto.ContractInformation);
            htData.Add(LG_REPORT_CUSTOMER_NAME, dto.CustomerName);
            htData.Add(LG_REPORT_NAME_BENEFICIARY, dto.BeneficiaryName);
            //2013.05.22 ADD HTK E Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7

            if (_wordApplication != null && _wordDocument != null)
            {
                wordBase.FindReplace(_wordDocument, _wordApplication, htData);
            }
        }

        /// <summary>
        /// Export FORM 1 TO SBV
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ExportToWordForm1ToSBV(clsLGReportPrintFormDTO dto, DateTime serverDate)
        {
            //Declaration            
            Hashtable htData = new Hashtable();

            _wordApplication = clsLGDocumentExporter.AppClass;

            _wordDocument = wordBase.CreateWordDoc(LG_REPORT_SBV_FILE_NAME,
                _wordApplication, false, m_ProjectName, LG_REPORT_SBV_TEMPLATE, serverDate);

            //Add Value    
            //2013.05.02 UPD HTK S Fix Feedback 20130514 
            //htData.Add(LG_REPORT_SBV_LG_REF, dto.LGNo);
            htData.Add(LG_REPORT_SBV_LG_REF, dto.LGCode);
            //2013.05.02 UPD HTK E Fix Feedback 20130514 
            htData.Add(LG_REPORT_SBV_STATUS, clsLGCommonFunction.GetDisplay(m_arrLGStatus, dto.LGStatus.ToString()));
            htData.Add(LG_REPORT_SBV_WEEKDAY, clsLGCommonFunction.GetWeekDayVN(serverDate.DayOfWeek.ToString()));
            htData.Add(LG_REPORT_SBV_CURRENTDAY, serverDate.ToString(clsLGConstant.LG_FORMAT_DAY));
            htData.Add(LG_REPORT_SBV_CURRENTMONTH, serverDate.ToString(clsLGConstant.LG_FORMAT_MONTH));
            htData.Add(LG_REPORT_SBV_CURRENTYEAR, serverDate.ToString(clsLGConstant.LG_FORMAT_YEAR));

            htData.Add(LG_REPORT_SBV_NAMEBTMUBANK, clsLGCommonFunction.GetDisplay(m_arrFromToSBVFile, clsLGConstant.LG_REPORT_SBV_NAMEBTMUBANK));
            htData.Add(LG_REPORT_SBV_ADDRESSBTMUBANK, clsLGCommonFunction.GetDisplay(m_arrFromToSBVFile, clsLGConstant.LG_REPORT_SBV_ADDRESSBTMUBANK));
            htData.Add(LG_REPORT_SBV_TELBTMUBANK, clsLGCommonFunction.GetDisplay(m_arrFromToSBVFile, clsLGConstant.LG_REPORT_SBV_TELBTMUBANK));
            htData.Add(LG_REPORT_SBV_FAXBTMUBANK, clsLGCommonFunction.GetDisplay(m_arrFromToSBVFile, clsLGConstant.LG_REPORT_SBV_FAXBTMUBANK));
            htData.Add(LG_REPORT_SBV_NUMBER, clsLGCommonFunction.GetDisplay(m_arrFromToSBVFile, clsLGConstant.LG_REPORT_SBV_NUMBER));
            htData.Add(LG_REPORT_SBV_CONSTDATE, clsLGCommonFunction.GetDisplay(m_arrFromToSBVFile, clsLGConstant.LG_REPORT_SBV_CONSTDATE));

            htData.Add(LG_REPORT_REPRESEN1, dto.Representation1);
            htData.Add(LG_REPORT_REPRESEN2, dto.Representation2);
            htData.Add(LG_REPORT_REPRESEN3, dto.Representation3);

            htData.Add(LG_REPORT_SBV_APPLICANT_NAME, dto.ApplicantName);
            htData.Add(LG_REPORT_SBV_APPLICANT_ADDRESS, dto.ApplicantAddress);
            htData.Add(LG_REPORT_SBV_APPLICANT_NATION, dto.ApplicantNational);
            htData.Add(LG_REPORT_SBV_APPLICANT_TEL, dto.ApplicantTel);
            htData.Add(LG_REPORT_SBV_APPLICANT_FAX, dto.ApplicantFax);
            htData.Add(LG_REPORT_SBV_BENEFICIARY_NAME, dto.BeneficiaryName);
            htData.Add(LG_REPORT_SBV_BENEFICIARY_ADDRESS, dto.BeneficiaryAddress);
            htData.Add(LG_REPORT_SBV_BENEFICIARY_NATION, dto.BeneficiaryNational);
            htData.Add(LG_REPORT_SBV_BENEFICIARY_TEL, dto.BeneficiaryTel);
            htData.Add(LG_REPORT_SBV_BENEFICIARY_FAX, dto.BeneficiaryFax);
            htData.Add(LG_REPORT_SBV_CUSTOMERNAME, dto.CustomerName);
            htData.Add(LG_REPORT_SBV_CUSTOMERADDRESS, dto.CustomerAddress);
            htData.Add(LG_REPORT_SBV_GUARANTEE_TYPE_NAME, dto.GuaranteeTypeName);
            htData.Add(LG_REPORT_SBV_CONTRACT_INFORMATION, dto.ContractInformation);
            htData.Add(LG_REPORT_SBV_VALUE_DATE, dto.ValueDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));
            htData.Add(LG_REPORT_SBV_TRANS_AMOUNT, dto.TransAmountFormat);
            htData.Add(LG_REPORT_SBV_CURRENCY, dto.TransCurrency);
            htData.Add(LG_REPORT_SBV_EXPIRE_DATE, dto.ExpireDate.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD));

            if (_wordApplication != null && _wordDocument != null)
            {
                wordBase.FindReplace(_wordDocument, _wordApplication, htData);
            }
        }
        #endregion
    }
}