﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: htkhiem $
 * $Date: 2013-01-16 14:30:00 +0700 (Wed, 16 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to management list LG staff
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Gui;
using Phoenix.Common.Smile.Obj;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Gui.Forms
{
	public partial class frmLGListLGStaff : frmLGMaster
    {
        #region Global Variable
        //DTO & BUS
        clsLGBus m_LGBus = new clsLGBus();
        private clsLGListLGStaffDTO lgListLGStaffDto = new clsLGListLGStaffDTO();
        private clsLGListLGStaffBus lgListLGStaffBus = new clsLGListLGStaffBus();
        //Server Current Date
        DateTime serverCurrentDate = new DateTime();
        //Used for show/hidden [Delete] button
        private List<int> lstSelectedRows = new List<int>();        
        // For Security Checking
        clsSEAuthorizer _security = null;
        //For List LG Staff   
        //+ [colCheck] Column
        private const string m_colCheck = "colCheck";
        //+ [colSeqLG] Column
        private const string m_colSeqLG = "colSeqLG";
        //+ [colLGNo] Column
        private const string m_colLGNo = "colLGNo";
        //+ [colPreviousLGNo] Column
        private const string m_colPreviousLGNo = "colPreviousLGNo";
        //+ [colType] Column
        private const string m_colType = "colType";
        //+ [colInputDate] Column
        private const string m_colInputDate = "colInputDate";
        //+ [colValueDate] Column
        private const string m_colValueDate = "colValueDate";
        //+ [colBackValue] Column
        private const string m_colBackValue = "colBackValue";
        //+ [colCustomerCode] Column
        private const string m_colCustomerCode = "colCustomerCode";
        //+ [colCustomerName] Column
        private const string m_colCustomerName = "colCustomerName";
        //+ [colGLCode] Column
        private const string m_colGLCode = "colGLCode";
        //+ [colClaim] Column
        private const string m_colClaim = "colClaim";
        //+ [colFeeRate] Column
        private const string m_colFeeRate = "colFeeRate";
        //+ [colMin] Column
        private const string m_colMin = "colMin";
        //+ [colMinCCY] Column
        private const string m_colMinCCY = "colMinCCY";
        //+ [colExpiryDate] Column
        private const string m_colExpiryDate = "colExpiryDate";
        //+ [colGuaranteeType] Column
        private const string m_colGuaranteeType = "colGuaranteeType";
        //+ [colBeneficiaryName] Column
        private const string m_colBeneficiaryName = "colBeneficiaryName";
        //+ [colTransCurrency] Column
        private const string m_colTransCurrency = "colTransCurrency";
        //+ [colChargeAccount] Column
        private const string m_colChargeAccount = "colChargeAccount";
        //+ [colGuaranteeAmount] Column
        private const string m_colGuaranteeAmount = "colGuaranteeAmount";
        //+ [colFee] Column
        private const string m_colFee = "colFee";
        //+ [colFeeCCY] Column
        private const string m_colFeeCurrency = "colFeeCCY";
        //+ [colMultiTimesFee] Column
        private const string m_colMultiTimesFee = "colMultiTimesFee";
        //+ [colOverdueFee] Column
        private const string m_colOverdueFee = "colOverdueFee";
        //+ [colOverdueFeeCCY] Column
        private const string m_colOverdueFeeCurrency = "colOverdueFeeCCY";
        //+ [colOverdueClaimFee] Column
        private const string m_colOverdueClaimFee = "colOverdueClaimFee";
        //+ [colOverdueClaimFeeCCY] Column
        private const string m_colOverdueClaimFeeCurrency = "colOverdueClaimFeeCCY";
        //+ [colReportToSBV] Column
        private const string m_colReportToSBV = "colReportToSBV";
        //+ [colLGReturn] Column
        private const string m_colLGReturn = "colLGReturn";
        //2013.05.09 ADD HTK S Smile Interface
        //+ [Exported (Smile)] Column
        private const string m_colExportedSmile = "colExportedSmile";
        //+ [Remark] Column
        private const string m_colRemark = "colRemark";
        //2013.05.09 ADD HTK E Smile Interface

        //Check Image        
        private System.Drawing.Image imgCheck = new Bitmap((System.Drawing.Image)Properties.Resources.ResourceManager.GetObject("Check"), new Size(16, 16));

        //Used to Export Excel
        //+ Used to release process
        private CWorker m_worker;  
        //+ Used to create Excel object
        private ExcelBase m_ExcelBase;
        //+ Excel File Name
        private string m_FileName = string.Empty;
        //+ Excel Template File Name
        private string m_TemplateName = string.Empty;
        //+ Project Name
        private string m_ProjectName = clsLGConstant.LG_MODULE;
        //+ Date for exporting
        private string m_FormatReportDate = clsLGConstant.LG_FORMAT_YYYY_MM_DD;
        //+ Flag inform about existing data or not
        private bool m_isNoTransaction;
        //+ Numbers of columns for reporting
        private int m_iColCount = 28;
        //+ Numbers of Rows for reporting
        private int m_iRowCount;
        //+ Array of data for reporting
        private object[,] m_arrData;

        //Used for 'Monitoring and Alert'
        private int m_SearchTypeForm = 0;

        // Quan add 20130518 ------------------->
        private frmAllSmileViewLog m_frmLog = null;
        // <-------------------------------------
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond        
        public frmLGListLGStaff()
        {            
            try
            {
                InitializeComponent();

                // Check authorization
                _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);

                //Set Fom Style
                base.SetFormStyleCommon();
                base.MaximizeBox = true;
                //Not generate columns
                dtgLGList.AutoGenerateColumns = false;
                m_LGBus = new clsLGBus();
                //Fill data to comboboxes
                FillAllComboboxes();
                //Intialize
                Init();
            }
            catch (Exception ex)
            {             
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond        
        public frmLGListLGStaff(int searchTypeForm)
        {
            try
            {
                InitializeComponent();

                // Check authorization
                //_security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                //_security.CheckAuthorizationOnScreen(this);

                //Set Fom Style
                base.SetFormStyleCommon();
                base.MaximizeBox = true;
                //Not generate columns
                dtgLGList.AutoGenerateColumns = false;
                m_LGBus = new clsLGBus();
                //Fill data to comboboxes
                FillAllComboboxes();
                //Intialize
                Init();
                m_SearchTypeForm = searchTypeForm;
                //Search data
                Search();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }            
        }
        #endregion

        #region Member Method
        /// <summary>
        /// Fill All Comboboxes
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void FillAllComboboxes()
        {
            //[LG Security] Combobox
            clsLGCommonFunction.FillComboboxData(m_LGBus.GetListLGSecurity, cbbSecurity);
            //[GL Code] Combobox
            clsLGCommonFunction.FillComboboxData(m_LGBus.GetListGLType, cbbGLCode);
            //[Currency] Combobox
            clsLGCommonFunction.FillComboboxData(m_LGBus.GetListCurrency, cbbCurrency);
            //[Guarantee Type] Combobox
            clsLGCommonFunction.FillComboboxData(m_LGBus.GetListGuaranteeType, cbbGuaranteeType);

            //[Type] Combobox for Grid
            DataGridViewComboBoxColumn classificationColumn = (DataGridViewComboBoxColumn)dtgLGList.Columns[m_colType];
            classificationColumn.DataSource = m_LGBus.GetListLGStatus();
            classificationColumn.DisplayMember = "Display";
            classificationColumn.ValueMember = "Value";
        }

        /// <summary>
        /// Init
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void Init()
        {
            //Get Server Current Date
            serverCurrentDate = clsLGCommonBus.Instance().GetServerDate();
            //Numeric Controls
            txtAmountFrom.Text = String.Empty;
            txtAmountTo.Text = String.Empty;
            //DateTime Picker
            //+ For [Input Date]
            dtpInputDateFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            dtpInputDateTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            dtpInputDateFrom.Text = String.Empty;
            dtpInputDateTo.Text = String.Empty;
            //+ For [Value Date]
            dtpValueDateFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            dtpValueDateTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            dtpValueDateFrom.Text = String.Empty;
            dtpValueDateTo.Text = String.Empty;
            //+ For [Expire Date]
            dtpExpireDateFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            dtpExpireDateTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            dtpExpireDateFrom.Text = String.Empty;
            dtpExpireDateTo.Text = String.Empty;
            //Show/Hidden toolstrip
            ShowHiddenToolStrip();
            tsbDelete.Visible = false;
        }

        /// <summary>
        /// Show Hidden Tool Strip
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void ShowHiddenToolStrip()
        {
            int index;
            bool isMultiTimesFee = false;
            //Has at least one row chosen
            if (dtgLGList.Rows.Count > 0 && dtgLGList.SelectedRows.Count > 0)
            {
                index = dtgLGList.Rows.IndexOf(dtgLGList.SelectedRows[0]);
                //Invisable toolstrip [tsbDisplayFeeCollection] for following cases:
                //+ New Entry: Fee existed in [Detail] Table
                isMultiTimesFee = (dtgLGList.Rows[index].Cells[m_colMultiTimesFee].Value.ToString() == "0" ? false : true);
                //+ In case [Record selected] is not returned (LGReturn = 0): Hide icon Correct
                //+ In case [Record selected] is returned (LGReturn = 1): Unhide icon Correct 
                tsbCorrection.Visible = !dtgLGList.Rows[index].Cells[m_colLGReturn].Value.ToString().Equals("0");
                tsbAmendUpdate.Visible = true;
                //2013.05.09 ADD HTK S Fix change request [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.013
                //tsbAmend.Visible = true;
                //tsbTerminate.Visible = true;
                tsbAmend.Visible = !dtgLGList.Rows[index].Cells[m_colExportedSmile].Value.ToString().Equals(clsLGConstant.SMILE_INTERFACE_STATUS_FAILED);
                tsbTerminate.Visible = !dtgLGList.Rows[index].Cells[m_colExportedSmile].Value.ToString().Equals(clsLGConstant.SMILE_INTERFACE_STATUS_FAILED);
                //2013.05.09 ADD HTK E Fix change request [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.013
                tsbDisplayClaim.Visible = true;
                //+ In case [Record selected] has Expiry date >= Current date: Hide icon
                //+ In case [Record selected] has Expiry date < Current date: Unhide icon                 
                tsbDisplayOverdue.Visible = (DateTime.Parse(dtgLGList.Rows[index].Cells[m_colExpiryDate].Value.ToString())).Date < serverCurrentDate.Date;
                tsbDisplayFeeCollection.Visible = isMultiTimesFee ? true : false;
                tsbPrintForm.Visible = true;
                //2013.05.09 ADD HTK S Smile Interface
                //+ Show toolstrip [Export To Smile] for cases [Not Yet] OR [Failed]
                tsbExportToSmile.Visible = (dtgLGList.Rows[index].Cells[m_colExportedSmile].Value.ToString().Equals(clsLGConstant.SMILE_INTERFACE_STATUS_NOT_YET) 
                                                || dtgLGList.Rows[index].Cells[m_colExportedSmile].Value.ToString().Equals(clsLGConstant.SMILE_INTERFACE_STATUS_FAILED));
                //+ Show toolstrip [Show Log Smile] for cases [Successful] OR [Failed]
                tsbShowSmileLog.Visible = (dtgLGList.Rows[index].Cells[m_colExportedSmile].Value.ToString().Equals(clsLGConstant.SMILE_INTERFACE_STATUS_SUCCESSFUL)
                                                || dtgLGList.Rows[index].Cells[m_colExportedSmile].Value.ToString().Equals(clsLGConstant.SMILE_INTERFACE_STATUS_FAILED));
                //2013.05.09 ADD HTK E Smile Interface
            }
            //Has no row chosen, Unhide following toolstripbuttons
            else
            {
                tsbCorrection.Visible = false;
                tsbAmendUpdate.Visible = false;
                tsbAmend.Visible = false;
                tsbTerminate.Visible = false;
                tsbDisplayClaim.Visible = false;
                tsbDisplayOverdue.Visible = false;
                tsbDisplayFeeCollection.Visible = false;
                tsbPrintForm.Visible = false;
                tsbDelete.Visible = false;
                //2013.05.09 ADD HTK S Smile Interface
                tsbExportToSmile.Visible = false;
                tsbShowSmileLog.Visible = false;
                //2013.05.09 ADD HTK E Smile Interface
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void Search()
        {
            //Declaration
            lgListLGStaffDto = new clsLGListLGStaffDTO();
            List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
            DataGridViewRow row = new DataGridViewRow();
            lstSelectedRows = new List<int>();
            dtgLGList.Rows.Clear();
            //Default Cell Style
            dtgLGList.Columns[m_colBackValue].DefaultCellStyle.NullValue = null;
            dtgLGList.Columns[m_colClaim].DefaultCellStyle.NullValue = null;
            dtgLGList.Columns[m_colReportToSBV].DefaultCellStyle.NullValue = null;
            //Assign value from inputting

            //Seaching Type: 0: General Search 
            //+ 1: General Search
            //+ 2: Overdue And Expire Within 7 Days (Current Date  - Expire Date >= -7)
            //+ 3: Charge Schedule (Having data in [Fee Collection Schedule] Table & ReceivedDate IS NULL) 
            //+ 4: Add Overdue charge schedule check box (similar to Issuing charge schedule box) Condition Searching
            if (radGeneralSearch.Checked)
            {
                lgListLGStaffDto.SearchingType = 1;
            }
            else if (radOverdueExpire.Checked)
            {
                lgListLGStaffDto.SearchingType = 2;
            }
            else if (radChargeSchedule.Checked)
            {
                lgListLGStaffDto.SearchingType = 3;
            }
            //2013.05.20 ADD HTK S Fix change request No.004 at [Phoenix-LG-BugsTrackingList-ver_2 2.xls]
            else
            {
                lgListLGStaffDto.SearchingType = 4;
            }
            //2013.05.20 ADD HTK E Fix change request No.004 at [Phoenix-LG-BugsTrackingList-ver_2 2.xls]
            //incase search data is called from screen 'Monitoring and Alert'
            if (m_SearchTypeForm == 5)
            {
                lgListLGStaffDto.SearchingType = m_SearchTypeForm;
                m_SearchTypeForm = 0;
            }
            //+ LG No
            lgListLGStaffDto.LGNo = txtLGNo.Text.Trim();
            //+ Customer Code
            lgListLGStaffDto.CustomerCode = txtCustomerCode.Text.Trim();
            //+ Customer Name
            lgListLGStaffDto.CustomerName = txtCustomerName.Text.Trim();
            //+ Security
            lgListLGStaffDto.Security = cbbSecurity.SelectedValue.ToString();
            //+ Booking purpose
            //2013.05.09 UPD HTK S Change [Booking Purpose] From CheckBox To ComboBox
            //lgListLGStaffDto.BookingPurpose = ckbBookingPurpose.Checked.ToString();
            lgListLGStaffDto.BookingPurpose = cbbBookingPurpose.Text;
            //2013.05.09 UPD HTK E Change [Booking Purpose] From CheckBox To ComboBox
            //+ GL Code
            lgListLGStaffDto.GLCode = cbbGLCode.Text.Trim();
            //+ Currency
            lgListLGStaffDto.Currency = cbbCurrency.Text.Trim();
            //+ Claim
            lgListLGStaffDto.Claim = cbbClaim.Text;
            //+ Input Date From
            lgListLGStaffDto.InputDateFrom = dtpInputDateFrom.Text.Equals(String.Empty) ? DateTime.MinValue : dtpInputDateFrom.Value;
            //+ Input Date To
            lgListLGStaffDto.InputDateTo = dtpInputDateTo.Text.Equals(String.Empty) ? DateTime.MinValue : dtpInputDateTo.Value;
            //+ Guarantee Type
            lgListLGStaffDto.GuaranteeType = cbbGuaranteeType.Text.Trim();
            //+ Value Date From
            lgListLGStaffDto.ValueDateFrom = dtpValueDateFrom.Text.Equals(String.Empty) ? DateTime.MinValue : dtpValueDateFrom.Value;
            //+ Value Date To
            lgListLGStaffDto.ValueDateTo = dtpValueDateTo.Text.Equals(String.Empty) ? DateTime.MinValue : dtpValueDateTo.Value;
            //+ Expire Date From
            lgListLGStaffDto.ExpireDateFrom = dtpExpireDateFrom.Text.Equals(String.Empty) ? DateTime.MinValue : dtpExpireDateFrom.Value;
            //+ Expire Date To
            lgListLGStaffDto.ExpireDateTo = dtpExpireDateTo.Text.Equals(String.Empty) ? DateTime.MinValue : dtpExpireDateTo.Value;
            //+ Amount From
            lgListLGStaffDto.AmountFrom = txtAmountFrom.Text.Trim();
            //+ Amount To
            lgListLGStaffDto.AmountTo = txtAmountTo.Text.Trim();
                
            //Get data collection from database
            lgListLGStaffBus.GetListLGStaff(ref lgListLGStaffDto);
            //Suppend Layout
            dtgLGList.SuspendLayout();
            dtgLGList.SelectionChanged -= new EventHandler(dtgLGList_SelectionChanged); 
            //Set data collection to grid            
            foreach (LGStaffInformation objLGStaffInfo in lgListLGStaffDto.LstLGStaffInformation)
            {
                row = new DataGridViewRow();
                row.CreateCells(dtgLGList);
                row.Cells[dtgLGList.Columns[m_colCheck].Index].Value = "FALSE";
                row.Cells[dtgLGList.Columns[m_colSeqLG].Index].Value = objLGStaffInfo.SeqLG;
                row.Cells[dtgLGList.Columns[m_colLGNo].Index].Value = objLGStaffInfo.LGNo;
                row.Cells[dtgLGList.Columns[m_colPreviousLGNo].Index].Value = objLGStaffInfo.PreviousLGNo;
                row.Cells[dtgLGList.Columns[m_colType].Index].Value = objLGStaffInfo.Type;
                row.Cells[dtgLGList.Columns[m_colInputDate].Index].Value = objLGStaffInfo.InputDate;
                row.Cells[dtgLGList.Columns[m_colValueDate].Index].Value = objLGStaffInfo.ValueDate;
                row.Cells[dtgLGList.Columns[m_colBackValue].Index].Value = !objLGStaffInfo.BackValue.Equals(String.Empty) ? imgCheck : null;
                row.Cells[dtgLGList.Columns[m_colCustomerCode].Index].Value = objLGStaffInfo.CustomerCode;
                row.Cells[dtgLGList.Columns[m_colCustomerName].Index].Value = objLGStaffInfo.CustomerName;
                row.Cells[dtgLGList.Columns[m_colGLCode].Index].Value = objLGStaffInfo.GLCode;
                row.Cells[dtgLGList.Columns[m_colClaim].Index].Value = !objLGStaffInfo.Claim.Equals(String.Empty) ? imgCheck : null;
                row.Cells[dtgLGList.Columns[m_colFeeRate].Index].Value = objLGStaffInfo.FeeRate;                
                //+ Set Format (Currency)
                row.Cells[dtgLGList.Columns[m_colMinCCY].Index].Value = objLGStaffInfo.MinCCY;
                if (row.Cells[dtgLGList.Columns[m_colMinCCY].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colMinCCY].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colMin].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colMin].Index].Value = objLGStaffInfo.Min;                
                row.Cells[dtgLGList.Columns[m_colExpiryDate].Index].Value = objLGStaffInfo.ExpiryDate;
                row.Cells[dtgLGList.Columns[m_colGuaranteeType].Index].Value = objLGStaffInfo.GuaranteeType;
                row.Cells[dtgLGList.Columns[m_colBeneficiaryName].Index].Value = objLGStaffInfo.BeneficiaryName;
                row.Cells[dtgLGList.Columns[m_colTransCurrency].Index].Value = objLGStaffInfo.TransCurrency;
                row.Cells[dtgLGList.Columns[m_colChargeAccount].Index].Value = objLGStaffInfo.ChargeAccount;
                //+ Set Format (Currency)
                if (row.Cells[dtgLGList.Columns[m_colTransCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colTransCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colGuaranteeAmount].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colGuaranteeAmount].Index].Value = objLGStaffInfo.GuaranteeAmount;
                //+ Set Format (Currency)
                row.Cells[dtgLGList.Columns[m_colFeeCurrency].Index].Value = objLGStaffInfo.FeeCurrency;
                if (row.Cells[dtgLGList.Columns[m_colFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colFee].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colFee].Index].Value = objLGStaffInfo.Fee;                
                row.Cells[dtgLGList.Columns[m_colMultiTimesFee].Index].Value = objLGStaffInfo.MultiTimesFee;
                //+ Set Format (Currency)
                row.Cells[dtgLGList.Columns[m_colOverdueFeeCurrency].Index].Value = objLGStaffInfo.OverdueFeeCurrency;
                if (row.Cells[dtgLGList.Columns[m_colOverdueFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colOverdueFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colOverdueFee].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colOverdueFee].Index].Value = objLGStaffInfo.OverdueFee;
                //+ Set Format (Currency)
                row.Cells[dtgLGList.Columns[m_colOverdueClaimFeeCurrency].Index].Value = objLGStaffInfo.OverdueClaimFeeCurrency;
                if (row.Cells[dtgLGList.Columns[m_colOverdueClaimFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colOverdueClaimFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colOverdueClaimFee].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colOverdueClaimFee].Index].Value = objLGStaffInfo.OverdueClaimFee;                
                row.Cells[dtgLGList.Columns[m_colReportToSBV].Index].Value = int.Parse(objLGStaffInfo.ReportToSBV) > 0 ? imgCheck : null;
                //2013.05.09 ADD HTK S Smile Interface
                row.Cells[dtgLGList.Columns[m_colExportedSmile].Index].Value = objLGStaffInfo.ExportedSmile;
                row.Cells[dtgLGList.Columns[m_colRemark].Index].Value = objLGStaffInfo.Remark;
                //2013.05.09 ADD HTK E Smile Interface
                //+ LG Return Flag
                row.Cells[dtgLGList.Columns[m_colLGReturn].Index].Value = objLGStaffInfo.LGReturn;

                lstRows.Add(row);
            }
            //Resume Layout
            dtgLGList.Rows.AddRange(lstRows.ToArray());
            dtgLGList.ResumeLayout();
            dtgLGList.SelectionChanged += new EventHandler(dtgLGList_SelectionChanged);

            //Show/Hidden toolstrip
            ShowHiddenToolStrip();
        }

        /// <summary>
        /// Delete List LG Staff
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private bool DeleteListLGStaff()
        {
            //Declaration
            bool isError = false;
            List<LGStaffInformation> lstLGStaffInformation = new List<LGStaffInformation>();
            LGStaffInformation lgStaffInfo = new LGStaffInformation();
            string LGNo = String.Empty;
            int deletedRows = 0;            
            //History Header
            clsLGLogBase logBase = new clsLGLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Action = (int)CommonValue.ActionType.Delete;
            List<string> lstDeletedRows = new List<string>();

            //Deleting data if no error
            if (!isError)
            {
                #region Process of Deleting
                foreach (DataGridViewRow item in dtgLGList.Rows)
                {
                    if (item.Cells[m_colCheck].Value.ToString().ToUpper().Equals("TRUE"))
                    {
                        lgStaffInfo = new LGStaffInformation();

                        //Assign value
                        LGNo = item.Cells[m_colLGNo].Value.ToString().Trim();
                        lgStaffInfo.LGNo = LGNo;

                        if (lstLGStaffInformation.Count(x => x.LGNo == LGNo) == 0)
                        {
                            //Add data to delete
                            lstLGStaffInformation.Add(lgStaffInfo);
                            //History
                            lstDeletedRows.Add(LGNo.Substring(0, LGNo.IndexOf('-')));
                        }
                    }                    
                }
                deletedRows = m_LGBus.DeleteListLG(lstLGStaffInformation.Select(x => x.LGNo).ToList<String>(), lgListLGStaffBus.DAL);
                if (deletedRows != 0)
                {
                    isError = false;
                    //Write Log
                    logBase.Key = String.Join(",", lstDeletedRows.ToArray());
                    logBase.WirteLog(lgListLGStaffBus.DAL);
                }
                else
                {
                    isError = true;
                }
                #endregion
            }
            return !isError;
        }
        
        /// <summary>
        /// Export to excel
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem        
        /// @endcond
        private void ExportToExcel()
        {
            m_FileName = clsLGConstant.LG_REPORT_LIST_LG_STAFF;
            m_TemplateName = clsLGConstant.LG_REPORT_LIST_LG_STAFF_TEMPLATE;
            bool isOpened = false;
            m_ExcelBase = new ExcelBase(m_FileName, m_TemplateName, m_ProjectName, ref isOpened, clsLGCommonBus.Instance().GetServerDate().ToString(m_FormatReportDate));
            if (isOpened)
            {
                return;
            }
            btnExportExcel.Enabled = false;
            m_isNoTransaction = false;

            switch (m_FileName)
            {
                case clsLGConstant.LG_REPORT_LIST_LG_STAFF:
                    m_worker = new CWorker(ExportReportListLGStaff, Complete);
                    m_worker.Start();
                    break;
            }
        }

        /// <summary>
        /// Export Report List LG Staff
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void ExportReportListLGStaff()
        {
            if (dtgLGList.Rows.Count == 0)
            {
                m_isNoTransaction = true;
                return;
            }
            
            m_ExcelBase.InsertText(2, 2, clsLGConstant.LG_REPORT_LIST_LG_STAFF);
            int iColStart = 1;
            int iRowStart = 4;

            //Header name

            string[,] arrHeaderName = GetHeaderNameListLGStaff();
            m_arrData = FillDataForReport(dtgLGList.Rows.Count, m_iColCount);
            int iColEnd = iColStart + m_iColCount - 1;
            m_iRowCount = dtgLGList.Rows.Count;

            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowStart++, arrHeaderName);
            int iRowEnd = m_iRowCount + iRowStart - 1;
            iColEnd = iColStart + m_iColCount - 1;

            m_ExcelBase.ExportRange(iColStart, iRowStart, iColEnd, iRowEnd, m_arrData);
        }

        /// <summary>
        /// Get header name
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private string[,] GetHeaderNameListLGStaff()
        {
            string[,] arrResult = new string[1, m_iColCount];
            int pos = 0;
            for (int i = 0; i <= m_iColCount; i++)
            {
                if (dtgLGList.Columns[i + 1].Visible == true)
                {
                    arrResult[0, pos] = dtgLGList.Columns[i + 1].HeaderText;
                    pos++;
                }            
            }
            return arrResult;
        }

        /// <summary>
        /// Get data for report
        /// </summary>
        /// <param name="iRowCount"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private object[,] FillDataForReport(int iRowCount, int iColCount)
        {
            object[,] arrResult = new object[iRowCount, iColCount];
            int pos = 0;
            for (int i = 0; i < dtgLGList.Rows.Count; i++)
            {
                for (int j = 0; j <= iColCount; j++)
                {
                    if (dtgLGList.Rows[i].Cells[j + 1].Visible == true)
                    {
                        //For [Back Value] & [Claim]
                        if (dtgLGList.Rows[i].Cells[j + 1].GetType() == typeof(DataGridViewImageCell))
                        {
                            if (dtgLGList.Rows[i].Cells[j + 1].Value != null)
                            {
                                m_ExcelBase.InsertPicture(j, 5 + i, AppDomain.CurrentDomain.BaseDirectory + m_ProjectName + "_GUI\\ICON\\CHECK.PNG", 14, 14);
                                arrResult[i, pos] = null;
                            }
                        }
                        else
                        {
                            arrResult[i, pos] = dtgLGList.Rows[i].Cells[j + 1].FormattedValue;
                        }                        
                        pos++;
                    }                    
                }
                pos = 0;
            }
            return arrResult;
        }

        /// <summary>
        /// Handling when completed a thread
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void Complete()
        {
            btnExportExcel.Enabled = true;

            if (m_isNoTransaction == true)
            {
                m_ExcelBase.SaveFile(false);
                clsLGMesageCollection.MessageNoTransactions();      
            }
            else
            {
                m_ExcelBase.SaveFile(true);                
            }
            if (m_worker != null)
                m_worker.Stop();
        }

        /// <summary>
        /// Override ProceeCmdKey
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>  
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                //+ [Correction] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.R):
                    {
                        if (tsbCorrection.Visible == true)
                        {
                            tsbCorrection_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Amend Update] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.U):
                    {
                        if (tsbAmendUpdate.Visible == true)
                        {
                            tsbAmendUpdate_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Amend] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.A):
                    {
                        if (tsbAmend.Visible == true)
                        {
                            tsbAmend_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Terminate] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.T):
                    {
                        if (tsbTerminate.Visible == true)
                        {
                            tsbTerminate_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Display Claim] Toolstrip ShortCut Key                
                case (Keys.Alt | Keys.L):
                    {
                        if (tsbDisplayClaim.Visible == true)
                        {
                            tsbDisplayClaim_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Display Overdue] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.O):
                    {
                        if (tsbDisplayOverdue.Visible == true)
                        {
                            tsbDisplayOverdue_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Display Fee Collection] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.F):
                    {
                        if (tsbDisplayFeeCollection.Visible == true)
                        {
                            tsbDisplayFeeCollection_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Print Form] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.P):
                    {
                        if (tsbPrintForm.Visible == true)
                        {
                            tsbPrintForm_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Delete] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.D):
                    {
                        if (tsbDelete.Visible == true)
                        {
                            tsbDelete_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //2013.05.09 ADD HTK S Smile Interface
                //+ [Export To Smile] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.M):
                    {
                        if (tsbExportToSmile.Visible == true)
                        {
                            tsbExportToSmile_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Show Smile Log] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.G):
                    {
                        if (tsbShowSmileLog.Visible == true)
                        {
                            tsbShowSmileLog_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //2013.05.09 ADD HTK E Smile Interface
            }                      

            return base.ProcessCmdKey(ref msg, keyData);
        }

        /// <summary>
        /// Processes a dialog box key.
        /// </summary>
        /// <param name="keyData"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        protected override bool ProcessDialogKey(Keys keyData)
        {
            switch (keyData)
            {
                //+ [Correction] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.R):
                    {                        
                        break;
                    }
                //+ [Amend Update] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.U):
                    {                        
                        break;
                    }
                //+ [Amend] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.A):
                    {                        
                        break;
                    }
                //+ [Terminate] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.T):
                    {                        
                        break;
                    }
                //+ [Display Claim] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.L):
                    {
                        break;
                    }
                //+ [Display Overdue] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.O):
                    {
                        break;
                    }
                //+ [Display Fee Collection] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.F):
                    {
                        break;
                    }
                //+ [Print Form] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.P):
                    {
                        break;
                    }
                //+ [Delete] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.D):
                    {
                        break;
                    }
                //2013.05.09 ADD HTK S Smile Interface
                //+ [Export To Smile] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.M):
                    {
                        break;
                    }
                //+ [Show Smile Log] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.G):
                    {
                        break;
                    }
                //2013.05.09 ADD HTK E Smile Interface
                default:
                    {
                        return base.ProcessDialogKey(keyData);
                    }
            }

            return true;                        
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Correction event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbCorrection_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGAmend frm = new frmLGAmend(dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString(), CommonValue.LGAction.Correct);
                frm.StartPosition = FormStartPosition.CenterScreen;
                //2013.05.02 UPD HTK S Fix Feedback No.12 20130429 
                //frm.Show();
                //if (frm.DialogResult == DialogResult.OK)
                //{
                //    Search();
                //}                
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
                //2013.05.02 UPD HTK E Fix Feedback No.12 20130429
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Amend Update event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbAmendUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGAmend frm = new frmLGAmend(dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString(), CommonValue.LGAction.AmendUpdate);
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Amend event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbAmend_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGAmend frm = new frmLGAmend(dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString(),CommonValue.LGAction.Amend);
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Terminate event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbTerminate_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGTerminate frm = new frmLGTerminate(dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString());
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Display Claimed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbDisplayClaim_Click(object sender, EventArgs e)
        {
			try
			{
				clsLGClaimDTO claimObj = new clsLGClaimDTO();
				claimObj.LGNo = dtgLGList.SelectedRows[0].Cells[m_colLGNo].Value.ToString();
				claimObj.CustomerCode = dtgLGList.SelectedRows[0].Cells[m_colCustomerCode].Value.ToString();
				claimObj.CustomerName = dtgLGList.SelectedRows[0].Cells[m_colCustomerName].Value.ToString();
				claimObj.BeneficiaryName = dtgLGList.SelectedRows[0].Cells[m_colBeneficiaryName].Value.ToString();
                claimObj.SeqLG = int.Parse(dtgLGList.SelectedRows[0].Cells[m_colSeqLG].Value.ToString());

				//LG no = LGType + LGCode
				frmLGClaimList frm = new frmLGClaimList(claimObj);
				frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
			}
			catch (Exception ex)
			{
				clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
				clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
			}
        }

        /// <summary>
        /// Display Overdue event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbDisplayOverdue_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGUpdateFeeCollectionSchedule frm = new frmLGUpdateFeeCollectionSchedule(dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString(), dtgLGList.SelectedRows[0].Cells["colCustomerName"].Value.ToString(), dtgLGList.SelectedRows[0].Cells["colBeneficiaryName"].Value.ToString(), false);
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Display Fee event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbDisplayFeeCollection_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGUpdateFeeCollectionSchedule frm = new frmLGUpdateFeeCollectionSchedule(dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString(), dtgLGList.SelectedRows[0].Cells["colCustomerName"].Value.ToString(), dtgLGList.SelectedRows[0].Cells["colBeneficiaryName"].Value.ToString(),true);
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Print Form event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbPrintForm_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgLGList.Rows.Count == 0)
                {
                    return;
                }
                DataGridViewRow dtr = dtgLGList.SelectedRows[0];
                clsLGPrintFormDTO dto = new clsLGPrintFormDTO();
                dto.SeqLG = int.Parse(dtr.Cells[m_colSeqLG].Value.ToString().Trim());
                dto.LGNo = dtr.Cells[m_colLGNo].Value.ToString();
                dto.LGType = dto.LGNo.Substring(0, 1);
                dto.LGStatus = dtr.Cells[m_colType].Value.ToString();
                dto.GuaranteeType = dtr.Cells[m_colGuaranteeType].Value.ToString();
                dto.ArrLGNo.Add(dto.LGNo);
                frmLGPrintForm frm = new frmLGPrintForm(dto.SeqLG,dto.ArrLGNo, dto.LGStatus, dto.LGType, dto.GuaranteeType);
                frm.StartPosition = FormStartPosition.CenterScreen;
                //2013.05.02 ADD HTK S Fix Feedback No.9 20130429 
                //frm.ShowDialog();
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
                //2013.05.02 ADD HTK E Fix Feedback No.9 20130429
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Delete event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = clsLGMesageCollection.ShowMessage(3, String.Format(clsLGCommonMessage.CONFIRM_ACTION, clsLGConstant.ACTION_DELETE.ToLower(), clsLGConstant.LG_STAFF_NAME)); ;
                if (result == DialogResult.Yes)
                {
                    bool isSuccess = false;
                    isSuccess = DeleteListLGStaff();
                    if (isSuccess)
                    {
                        //Commit data if successful
                        lgListLGStaffBus.Commit();
                        clsLGMesageCollection.ShowMessage(2, String.Format(clsLGCommonMessage.INFOR_ACTION_SUCCESS, clsLGConstant.ACTION_DELETE, clsLGConstant.LG_STAFF_NAME));
                        //Search data again
                        Search();
                    }
                }
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                try
                {
                    lgListLGStaffBus.RollBack();
                }
                catch (System.Exception) { }

                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        //2013.05.09 ADD HTK S Smile Interface
        /// <summary>
        /// Export To Smile
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbExportToSmile_Click(object sender, EventArgs e)
        {
            try
            {
                string lgNo = dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString().Remove(6);
                string subCode = dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString().Remove(0, 7);
                //Do Something
                LG data = clsLGMasterBus.GetLG(lgNo);
                List<object> objList = new List<object>();
                if (data.Master.LgStatus == 1 || (data.Master.LgBeforeStatus == 1 && data.Master.LgStatus == 2))
                {
                    for (int i = 0; i < data.LstDetail.Count; i++)
                    {
                        if (data.LstDetail[i].Detail.ResultNew == 0)
                        {
                            clsLGONEWDto dto = new clsLGONEWDto();
                            dto.Page1Issue = clsSmileCommon.ConvertToSmileDate(data.Master.ValueDate);
                            dto.Page1Effective = dto.Page1Issue;
                            dto.Page1Customer = data.Master.CustomerCode;
                            dto.Page1Ccy = data.LstDetail[i].Detail.TransCurrency;
                            dto.Page1GL1 = data.Master.GlCode.Substring(0, 3);
                            dto.Page1GL2 = data.Master.GlCode.Substring(4, 4);
                            dto.Page1Trans1 = data.Master.LgCode;
                            dto.Page1Trans2 = data.LstDetail[i].Detail.SubCode;
                            if (clsLGCommonBus.Instance().MainCCYList.Contains(data.LstDetail[i].Detail.TransCurrency))
                            {
                                dto.Page2Trans = data.LstDetail[i].Detail.TransAmount.ToString("#,0");
                            }
                            else
                            {
                                dto.Page2Trans = data.LstDetail[i].Detail.TransAmount.ToString("#,0.00");
                            }
                            dto.Page2Exp = clsSmileCommon.ConvertToSmileDate(data.Master.ExpireDate);
                            dto.Page2GuaranteeType = data.Master.GuaranteeType;
                            dto.Page2FeeRate = data.Master.LgRate.ToString();
                            dto.Page2Adj = data.Master.CalculateType;
                            if (!data.Master.MinRateStandard)
                                dto.Page2Minimum = "Y";
                            else
                                dto.Page2Minimum = "";
                            if (data.Master.LgType == 1)
                            {
                                dto.Page2CHGAC1 = data.LstDetail[i].Detail.ChargeCurrency;
                                dto.Page2CHGAC2 = "511";
                                dto.Page2CHGAC3 = "3000";
                                //double d = double.Parse(data.LstDetail[i].Detail.ChargeAccount);
                                //dto.Page2CHGAC4 = Math.Truncate(d).ToString();
                                dto.Page2CHGAC4 = data.LstDetail[i].Detail.ChargeAccount;
                            }
                            else
                            {
                                dto.Page2CHGAC1 = data.LstDetail[i].Detail.ChargeCurrency;
                                dto.Page2CHGAC2 = "310";
                                dto.Page2CHGAC3 = "1000";
                                dto.Page2CHGAC4 = "000019";
                            }
                            dto.Page2Bene = dtgLGList.SelectedRows[0].Cells["colBeneficiaryName"].Value.ToString();
                            dto.MacroType = MacroType.LGONEW;
                            dto.ImportType = ImportType.LGIssue;
                            objList.Add(dto);
                        }
                        if (data.Master.LgStatus == 1 && data.LstDetail[i].Detail.ResultGenera == 0)
                        {
                            if (data.Master.MinRateStandard)
                            {
                                clsGTON01Dto dto2 = new clsGTON01Dto();

                                // Debit
                                if (data.LstDetail[i].Detail.ActualCollectionDate != DateTime.MinValue)
                                    dto2.DebitCcy = data.LstDetail[i].Detail.FeeCurrency;
                                else
                                    dto2.DebitCcy = data.LstDetail[i].LstFeeSchedule[0].ChargeCCY;
                                dto2.DebitValue = clsSmileCommon.ConvertToSmileDate(data.Master.ValueDate);
                                dto2.DebitAdvice = "Y";
                                //dto2.DebitGL1 = data.Master.GlCode.Substring(0, 3);
                                //dto2.DebitGL2 = data.Master.GlCode.Substring(4, 4);

                               

                                if (data.Master.LgType == 1)
                                {
                                    dto2.DebitGL1 = "511";
                                    dto2.DebitGL2 = "3000";
                                    dto2.DebitACNo = data.LstDetail[i].Detail.ChargeAccount;
                                }
                                else
                                {
                                    dto2.DebitGL1 = "310";
                                    dto2.DebitGL2 = "1000";
                                    dto2.DebitACNo = "000019";
                                }
                               // decimal d = data.LstDetail[i].Detail.TransAmount;
                                if (data.LstDetail[i].Detail.ActualCollectionDate != DateTime.MinValue)
                                {
                                    if (clsLGCommonBus.Instance().MainCCYList.Contains(dto2.DebitCcy))
                                        dto2.DebitAmount = data.LstDetail[i].Detail.Fee.ToString("#,0");
                                    else
                                    {
                                        dto2.DebitAmount = data.LstDetail[i].Detail.Fee.ToString("#,0.00");
                                    }
                                }
                                else
                                {
                                    decimal fee = 0;
                                    for (int j = 0; j < data.LstDetail[i].LstFeeSchedule.Count; j++)
                                    {
                                        fee += data.LstDetail[i].LstFeeSchedule[j].Fee;
                                    }

                                    //
                                    if (clsLGCommonBus.Instance().MainCCYList.Contains(dto2.DebitCcy))
                                    {
                                        dto2.DebitAmount = fee.ToString("#,0");
                                    }
                                    else
                                    {
                                        dto2.DebitAmount = fee.ToString("#,0.00");
                                    }
                                }
                                if (data.Master.LgType == 1)
                                    dto2.DebitNW = "N";
                                else
                                    dto2.DebitNW = "";
                                dto2.DebitReference = "LG" + data.Master.LgCode + "-" + data.LstDetail[i].Detail.SubCode;
                                dto2.DebitOurRef = "640";

                                // Credit
                                dto2.CreditCcy = dto2.DebitCcy;
                                dto2.CreditGL1 = "370";
                                dto2.CreditGL2 = "0000";
                                if (data.Master.LgType == 1)
                                    dto2.CreditACNo = "637100";
                                else
                                    dto2.CreditACNo = "638000";
                                if (data.LstDetail[i].Detail.ActualCollectionDate != DateTime.MinValue)
                                {
                                    if (clsLGCommonBus.Instance().MainCCYList.Contains(dto2.CreditCcy))
                                        dto2.CreditAmount = data.LstDetail[i].Detail.Fee.ToString("#,0");
                                    else
                                    {
                                        dto2.CreditAmount = data.LstDetail[i].Detail.Fee.ToString("#,0.00");
                                    }
                                }
                                else
                                {
                                    decimal fee = 0;
                                    for (int j = 0; j < data.LstDetail[i].LstFeeSchedule.Count; j++)
                                    {
                                        fee += data.LstDetail[i].LstFeeSchedule[j].Fee;
                                    }
                                    if (clsLGCommonBus.Instance().MainCCYList.Contains(dto2.DebitCcy))
                                    {
                                        dto2.CreditAmount = fee.ToString("#,0");
                                    }
                                    else
                                    {
                                        dto2.CreditAmount = fee.ToString("#,0.00");
                                    }
                                }
                                dto2.CreditCustomer = data.Master.CustomerCode;
                                dto2.CreditReference = dto2.DebitReference;

                                // Exchange
                                string ccy1 = data.LstDetail[i].Detail.TransCurrency;
                                string ccy2 = data.LstDetail[i].Detail.FeeCurrency;
                                if (data.Master.LgType == 0)
                                {
                                    if (ccy1.Equals("USD") && ccy2.Equals("USD"))
                                        dto2.Method = "";
                                    else if (ccy1.Equals("JPY") && ccy2.Equals("JPY"))
                                        dto2.Method = "NOEX";
                                    else if (ccy1.Equals("VND") && ccy2.Equals("VND"))
                                        dto2.Method = "NOEX";
                                    else if (ccy1.Equals("JPY") && ccy2.Equals("VND"))
                                        dto2.Method = "CRSP";
                                    else if (ccy1.Equals("USD") && ccy2.Equals("VND"))
                                        dto2.Method = "SPOT";
                                    else if (ccy1.Equals("USD") && ccy2.Equals("JPY"))
                                        dto2.Method = "SPOT";
                                    else
                                        dto2.Method = "";
                                }
                                else
                                {
                                    if (ccy2.Equals("USD") && ccy1.Equals("USD"))
                                        dto2.Method = "";
                                    else if (ccy2.Equals("JPY") && ccy1.Equals("JPY"))
                                        dto2.Method = "NOEX";
                                    else if (ccy2.Equals("VND") && ccy1.Equals("VND"))
                                        dto2.Method = "NOEX";
                                    else if (ccy2.Equals("JPY") && ccy1.Equals("VND"))
                                        dto2.Method = "CRSP";
                                    else if (ccy2.Equals("USD") && ccy1.Equals("VND"))
                                        dto2.Method = "SPOT";
                                    else if (ccy2.Equals("USD") && ccy1.Equals("JPY"))
                                        dto2.Method = "SPOT";
                                    else
                                        dto2.Method = "";
                                }
                                if (!dto2.Method.Equals("NOEX"))
                                    dto2.Cust = dto2.CreditCustomer;
                                else
                                    dto2.Cust = "00000000";
                                dto2.TransNo = data.Master.LgCode + "-" + data.LstDetail[i].Detail.SubCode;
                                dto2.MacroType = MacroType.GTON01;
                                dto2.ImportType = ImportType.GeneralTransfer;
                                objList.Add(dto2);
                            }
                        }
                    }
                }
                if (data.Master.LgStatus == 4 || (data.Master.LgBeforeStatus == 4 && data.Master.LgStatus == 2))
                {
                    LG before = clsLGMasterBus.GetLGBefore(lgNo);
                    for (int i = 0; i < before.LstDetail.Count; i++)
                    {
                        //terminate
                        if (before.LstDetail[i].Detail.ResultTerminate == 0)
                        {
                            clsLGOSETDto dto = new clsLGOSETDto();
                            dto.Value = before.Master.ValueDate.ToString("yyMMdd");//value date
                            dto.Customer = before.Master.CustomerCode;
                            dto.Ccy = before.LstDetail[i].Detail.TransCurrency;
                            dto.GL1 = before.Master.GlCode.Substring(0, 3);
                            dto.GL2 = before.Master.GlCode.Substring(4, 4);
                            dto.Trans1 = before.Master.LgCode;
                            dto.Trans2 = before.LstDetail[i].Detail.SubCode;
                            dto.MacroType = MacroType.LGOSET;
                            dto.ImportType = ImportType.LGTerminate;
                            objList.Add(dto);
                        }

                    }
                    for (int i = 0; i < data.LstDetail.Count; i++)
                    {
                        if (data.LstDetail[i].Detail.ResultNew == 0)
                        {
                            // LG Issue
                            if (data.LstDetail[i].Detail.ResultNew == 0)
                            {
                                clsLGONEWDto dto1 = new clsLGONEWDto();
                                dto1.Page1Issue = clsSmileCommon.ConvertToSmileDate(data.Master.ValueDate);
                                dto1.Page1Effective = dto1.Page1Issue;
                                dto1.Page1Customer = data.Master.CustomerCode;
                                dto1.Page1Ccy = data.LstDetail[i].Detail.TransCurrency;
                                dto1.Page1GL1 = data.Master.GlCode.Substring(0, 3);
                                dto1.Page1GL2 = data.Master.GlCode.Substring(4, 4);
                                dto1.Page1Trans1 = data.Master.LgCode;
                                dto1.Page1Trans2 = data.LstDetail[i].Detail.SubCode;
                                if (clsLGCommonBus.Instance().MainCCYList.Contains(data.LstDetail[i].Detail.TransCurrency))
                                {
                                    dto1.Page2Trans = data.LstDetail[i].Detail.TransAmount.ToString("#,0");
                                }
                                else
                                {
                                    dto1.Page2Trans = data.LstDetail[i].Detail.TransAmount.ToString("#,0.00");
                                }
                                dto1.Page2Exp = clsSmileCommon.ConvertToSmileDate(data.Master.ExpireDate);

                                dto1.Page2GuaranteeType = data.Master.GuaranteeType;
                                dto1.Page2FeeRate = data.Master.LgRate.ToString();
                                dto1.Page2Adj = data.Master.CalculateType;
                                if (!data.Master.MinRateStandard)
                                    dto1.Page2Minimum = "Y";
                                else
                                    dto1.Page2Minimum = "";
                                if (data.Master.LgType == 1)
                                {
                                    dto1.Page2CHGAC1 = data.LstDetail[i].Detail.ChargeCurrency;
                                    dto1.Page2CHGAC2 = "511";
                                    dto1.Page2CHGAC3 = "3000";
                                    //double d = double.Parse(data.LstDetail[i].Detail.ChargeAccount);
                                    //dto.Page2CHGAC4 = Math.Truncate(d).ToString();
                                    dto1.Page2CHGAC4 = data.LstDetail[i].Detail.ChargeAccount;
                                }
                                else
                                {
                                    dto1.Page2CHGAC1 = data.LstDetail[i].Detail.ChargeCurrency;
                                    dto1.Page2CHGAC2 = "310";
                                    dto1.Page2CHGAC3 = "1000";
                                    dto1.Page2CHGAC4 = "000019";
                                }

                                dto1.Page2Bene = dtgLGList.SelectedRows[0].Cells["colBeneficiaryName"].Value.ToString();

                                // cbbBeneficiary.SelectedItem
                                dto1.MacroType = MacroType.LGONEW;
                                dto1.ImportType = ImportType.LGIssue;
                                //macroList.Add(MacroType.LGONEW);
                                objList.Add(dto1);
                            }
                        }
                    }
                }
                clsErrorLogDto SmileErrorLog = new clsErrorLogDto();
                SmileErrorLog.Module = Module.LG.ToString();
                SmileErrorLog.TransNo = data.Master.LgCode;
                SmileErrorLog.ImportBy = clsUserInfo.UserName;

                frmAllSmileConfirmation frmConfirm = new frmAllSmileConfirmation(objList);
                frmConfirm.Tag = MdiParent;
                frmConfirm.ErrorLogInfo = SmileErrorLog;
                frmConfirm.StartPosition = FormStartPosition.CenterScreen;
                frmConfirm.ShowDialog();
                if (frmConfirm.DialogResult == DialogResult.OK)
                {
                    Search();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Show Smile Log
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbShowSmileLog_Click(object sender, EventArgs e)
        {
            try
            {
                //if (m_frmLog == null || m_frmLog.IsDisposed)
                //{
                //    string lgNo = dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString();
                //    m_frmLog = new frmAllSmileViewLog(lgNo, Module.LG);
                //    m_frmLog.MdiParent = MdiParent;
                //    m_frmLog.StartPosition = FormStartPosition.CenterScreen;
                //    m_frmLog.Show();
                //}
                //else
                //{
                //    m_frmLog.Visible = true;
                //    m_frmLog.Activate();
                //}
                clsSmileCommon.OpenViewLogForm(MdiParent, dtgLGList.SelectedRows[0].Cells["colLGNo"].Value.ToString(), Module.LG);
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }
        //2013.05.09 ADD HTK E Smile Interface

        /// <summary>
        /// Search LG list to the input conditions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Search();
                //No records
                if (dtgLGList.Rows.Count == 0)
                {
                    clsLGMesageCollection.MessageNoTransactions();

                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnIssueLG_Click(object sender, EventArgs e)
        {
            try
            {
                if (clsLGWorkSpace.Instance().FrmIssue == null || clsLGWorkSpace.Instance().FrmIssue.IsDisposed)
                {
                    clsLGWorkSpace.Instance().FrmIssue = new frmLGIssue();
                    clsLGWorkSpace.Instance().FrmIssue.StartPosition = FormStartPosition.CenterScreen;
                   clsLGWorkSpace.Instance().FrmIssue.MdiParent = this.MdiParent;
                    clsLGWorkSpace.Instance().FrmIssue.Show();                    
                }
                else
                {
                    clsLGWorkSpace.Instance().FrmIssue.BringToFront();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Export excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <summary>
        /// Load GLCode list
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            try
            {
                ExportToExcel();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }            
        }

        /// <summary>
        /// Form Closing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void frmLGListLGStaff_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //2013.05.02 ADD HTK S Fix Feedback No.9 20130429 
                if (m_worker != null && m_worker.IsBusy)
                {
                    e.Cancel = true;
                    return;
                }
                //2013.05.02 ADD HTK E Fix Feedback No.9 20130429
                if (e.CloseReason == CloseReason.UserClosing)
                {
                    if (!clsCommonFunctions.AllNoCheck(dtgLGList))
                    {
                        DialogResult result = clsLGMesageCollection.ShowMessage(0, clsLGCommonMessage.CONFIRM_SELECTED_ROWS); ;
                        if (result == DialogResult.Yes || result == DialogResult.Cancel)
                        {
                            e.Cancel = true;
                        }
                        else
                        {
                            e.Cancel = false;
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// General Search Checked Changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void radGeneralSearch_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radGeneralSearch.Checked)
                {
                    foreach (Control ctr in this.Controls)
                    {
                        if (ctr is TextBox || ctr is ComboBox || ctr is CheckBox || ctr is UserCtrl.BlankCalendar)
                        {
                            ctr.Enabled = true;
                        }
                    }
                }
                else
                {
                    foreach (Control ctr in this.Controls)
                    {
                        if (ctr is TextBox || ctr is ComboBox || ctr is CheckBox || ctr is UserCtrl.BlankCalendar)
                        {
                            ctr.Enabled = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Selected index changed event of currency combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void cbbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {                
                //Set properties for TextBox [txtAmountFrom] & [txtAmountTo]
                if (cbbCurrency.Text.Equals(clsLGConstant.LG_CURRENCY_VND) || cbbCurrency.Text.Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    //Do not allow to input decimal
                    //+ For [txtAmountFrom]
                    if (!txtAmountFrom.Text.Trim().Equals(String.Empty))
                    {
                        txtAmountFrom.NeedDecimal = false;
                        txtAmountFrom.StringFormat = "#,0";
                        txtAmountFrom.Refresh();
                    }                    
                    //+ For [txtAmountTo]
                    if (!txtAmountTo.Text.Trim().Equals(String.Empty))
                    {
                        txtAmountTo.NeedDecimal = false;
                        txtAmountTo.StringFormat = "#,0";
                        txtAmountTo.Refresh();
                    }                    
                }
                else
                {
                    //Do not allow to input decimal
                    //+ For [txtAmountFrom]
                    if (!txtAmountFrom.Text.Trim().Equals(String.Empty))
                    {
                        txtAmountFrom.NeedDecimal = true;
                        txtAmountFrom.StringFormat = clsLGConstant.FORMAT_DECIMAL;
                        txtAmountFrom.Refresh();
                    }                    
                    //+ For [txtAmountTo]
                    if (!txtAmountTo.Text.Trim().Equals(String.Empty))
                    {
                        txtAmountTo.NeedDecimal = true;
                        txtAmountTo.StringFormat = clsLGConstant.FORMAT_DECIMAL;
                        txtAmountTo.Refresh();
                    }                    
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Set readonly state for datagridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void dtgLGList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == dtgLGList.Columns[m_colCheck].Index)
                {
                    if (e.RowIndex >= 0)
                        dtgLGList[dtgLGList.Columns[m_colCheck].Index, e.RowIndex].Value = (!bool.Parse(dtgLGList[dtgLGList.Columns[m_colCheck].Index, e.RowIndex].Value.ToString())).ToString();
                }
                else
                    dtgLGList.ReadOnly = true;            
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Used for Show/Hidden [Delete] button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void dtgLGList_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == dtgLGList.Columns[m_colCheck].Index)
                {
                    //get list records is checked on grid OL
                    if (Boolean.Parse(dtgLGList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString()) == true)
                    {
                        lstSelectedRows.Add(e.RowIndex);
                    }
                    else
                    {
                        if (lstSelectedRows.Contains(e.RowIndex))
                        {
                            lstSelectedRows.Remove(e.RowIndex);
                        }                            
                    }
                    //Show/Hidden [Delete] button
                    if (lstSelectedRows.Count > 0)
                    {
                        tsbDelete.Visible = true;
                    }
                    else
                    {
                        tsbDelete.Visible = false;
                    }                    
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// dtgLGList_SelectionChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void dtgLGList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                ShowHiddenToolStrip();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }
        #endregion
	}
}