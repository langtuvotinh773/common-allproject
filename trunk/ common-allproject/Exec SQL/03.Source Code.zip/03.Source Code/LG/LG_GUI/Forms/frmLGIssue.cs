﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-01-16 14:30:00 +0700 (Wed, 16 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to management list LG staff
 * for LG module.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Smile.Com;
using Phoenix.Common.Smile.Gui;
using Phoenix.Common.Smile.Obj;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;
using UserCtrl;
using DataEncryption;

namespace Phoenix.Lg.Gui.Forms
{
	public partial class frmLGIssue : frmLGMaster
	{
		//clsLGBus m_LGBus = null;
 
		const string COL_FEE_SUGGESTION = "colFeeSuggestion";
		const string COL_SUB = "colSub";
		
		
        //public  List<clsLGFeeScheduleDTO> LstFeeSchedule;
        string m_LGNo = "";   
        string m_SeqLG = "";
        string m_LGStatus = "";
        //public string m_LGType = "";
        ArrayList m_arr;
        string m_Guarantee = "";
         string DEFAULT_MINRATE_CCY = Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["MinRateCCY"].ToString());
         decimal DEFAULT_MINRATE_AMOUNT = decimal.Parse(Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["MinRateAmount"].ToString()));
        List<string> m_ChangeValueControl = new List<string>();
        frmLGFeeCollectionSchedule frmCreateFee;
        List<clsLGLogBase> m_ListLogs;
        //frmAllSmileConfirmation frmConfirm = null;
        List<ParameterDTO> m_LstRepresentation; //default value of 3 representatuion
        bool isButtonSaveClick = false; // click save or not

        // Quan Add 20130510 -------------->
        private List<object> objList = null;
        private clsErrorLogDto SmileErrorLog = null;
        private frmLGPrintForm m_frmPrintForm = null;
        // <--------------------------------


        List<ParameterDTO> m_lstCCY;
		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		public frmLGIssue()
		{
			InitializeComponent();
            try
            {
                //init list fee schedule colection
                LstFeeSchedule = new List<clsLGFeeScheduleDTO>();
                //set common style for form
                SetFormStyleCommon();
                SetFormStyle();
                FillComboboxData();
                m_ListLogs = new List<clsLGLogBase>();

                m_lstCCY = new List<ParameterDTO>();
                m_lstCCY = clsLGCommonBus.Instance().GetListCurrency();
                // get list value of representation
                 m_LstRepresentation = clsLGCommonBus.Instance().GetListRepresentation();
                txtRepresentation1.Text = m_LstRepresentation[0].Name;
                txtRepresentation2.Text = m_LstRepresentation[1].Name;
                txtRepresentation3.Text = m_LstRepresentation[2].Name;

                _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
          
		}

        
		/// <summary>
		/// Fill combobox data
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void FillComboboxData()
		{
            cbbLGCategory.DataSource = clsLGCommonBus.Instance().LstLGCategory;
            cbbLGCategory.DisplayMember = "Name";
            cbbLGCategory.ValueMember = "Value";
            cbbLGCategory.DropDownStyle = ComboBoxStyle.DropDownList;
           
            cbbGuaranteeType.DataSource = clsLGCommonBus.Instance().GetListLGGuarantee();
            cbbGuaranteeType.DisplayMember = "Name";
            cbbGuaranteeType.ValueMember = "Value";
            cbbGuaranteeType.DropDownStyle = ComboBoxStyle.DropDownList;

            cbbCalculateType.DataSource = clsLGCommonBus.Instance().GetListLGCalculateType();
            cbbCalculateType.DisplayMember = "Name";
            cbbCalculateType.ValueMember = "Value";
            cbbCalculateType.DropDownStyle = ComboBoxStyle.DropDownList;
          
            cbbCurrency.DataSource = clsLGCommonBus.Instance().GetListCurrency();
            cbbCurrency.DisplayMember = "Name";
            cbbCurrency.ValueMember = "Value";
            cbbCurrency.DropDownStyle = ComboBoxStyle.DropDownList;
		
             new clsLGBus().GetListBeneficiaryForCombobox(cbbBeneficiary);
             new clsLGBus().GetListApplicantForCombobox(cbbApplicant);
		}

		/// <summary>
		/// Set form style
		/// </summary>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		private void SetFormStyle()
		{
			this.Text = "Issue LG"; 
			dtpInputDate.Enabled = false;
			//cbbCustomerName.Enabled = false;

			radStandard.Checked = true;
			cbbCurrency.Enabled = false;
			txtOrther.Enabled = false;
			txtOrther.Text = "";
			cbbCurrency.SelectedIndex = -1;
            cbbCustomerCode.DropDownStyle = ComboBoxStyle.DropDown;
            cbbCustomerName.DropDownStyle = ComboBoxStyle.DropDown;
			#region MAX LENGTH
			txtGLCode.MaxLength = clsLGConstant.LENGTH_GL_CODE;
			txtLGRate.MaxLength = clsLGConstant.LENGTH_LG_RATE;
			txtContractInformation.MaxLength = clsLGConstant.LENGTH_CONTRACT_INFORMATION;
			txtRepresentation1.MaxLength = clsLGConstant.LENGTH_REPRESENTATION_1;
			txtRepresentation2.MaxLength = clsLGConstant.LENGTH_REPRESENTATION_2;
			txtRepresentation3.MaxLength = clsLGConstant.LENGTH_REPRESENTATION_3;
			txtRemark.MaxLength = clsLGConstant.LENGTH_REMARK;
			#endregion
            // set datasource for 2 column CCY in datagrid
            ((DataGridViewComboBoxColumn)dtgLGList.Columns[1]).DataSource = clsLGCommonBus.Instance().GetListCurrency();
            ((DataGridViewComboBoxColumn)dtgLGList.Columns[1]).DisplayMember = "Name";
            ((DataGridViewComboBoxColumn)dtgLGList.Columns[1]).ValueMember = "Value";
         

            ((DataGridViewComboBoxColumn)dtgLGList.Columns[7]).DataSource = clsLGCommonBus.Instance().GetListCurrency();
            ((DataGridViewComboBoxColumn)dtgLGList.Columns[7]).DisplayMember = "Name";
            ((DataGridViewComboBoxColumn)dtgLGList.Columns[7]).ValueMember = "Value";
            // input date =  server date
            dtpExpireDate.Value = dtpInputDate.Value = dtpValueDate.Value = clsLGCommonBus.Instance().GetServerDate();

            txtLGRate.LostFocus += new EventHandler(txtLGRate_LostFocus);
           
		}

      
      
        void txtLGRate_LostFocus(object sender, EventArgs e)
        {
            if (txtLGRate.Text != "")
            {
                if (decimal.Parse(txtLGRate.Text) > 2)
                {
                    txtLGRate.Focus();


                    txtLGRate.Text = "";
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.LGRATE_LESS_THAN);

                }
                else
                {
                    if (decimal.Parse(txtLGRate.Text) < 0)
                    {
                        txtLGRate.Focus();


                        txtLGRate.Text = "";
                        clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.LGRATE_GREATE_THAN);

                    }
                }

            }

        }


		/// <summary>
		/// Close form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Phuong Lap Co
		/// @endcond
		private void btnClose_Click(object sender, EventArgs e)
		{
          
			this.Close();
		}

	
		 
 		/// <summary>
		/// Add an item on datagrid event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnAdd_Click(object sender, EventArgs e)
		{
            dtgLGList.Rows.Add(dtgLGList.Rows.Count.ToString("00"), null, null, false, null, null, null, null, null, null);
		}


        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            //if (keyData == Keys.Tab)
            //{
            //    if (btnRemove.Focused)
            //    {
            //        try
            //        {
            //            dtgLGList.CurrentCell = dtgLGList.Rows[0].Cells[0];
            //        }
            //        catch
            //        {
            //        }
            //    }
            //}
            return base.ProcessCmdKey(ref msg, keyData);
        }
		/// <summary>
		/// Add new applicant
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnApplicantAdd_Click(object sender, EventArgs e)
		{
            try
            {
                frmLGCreateApplicant frm = new frmLGCreateApplicant();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
                int i = cbbApplicant.SelectedIndex;
                new clsLGBus().GetListApplicantForComboboxReLoad(cbbApplicant);
                if (frm.NewApplicant != "")
                {
                    int index = cbbApplicant.FindString(frm.NewApplicant);
                    cbbApplicant.SelectedIndex = index;
                }
                else
                {
                    cbbApplicant.SelectedIndex = i;
                }

                
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
		}

		/// <summary>
		/// Add new beneficiary
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnAddBeneficiary_Click(object sender, EventArgs e)
		{
            try
            {
                frmLGCreateBeneficiary frm = new frmLGCreateBeneficiary();
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
                int i = cbbBeneficiary.SelectedIndex;
                new clsLGBus().GetListBeneficiaryForComboboxReload(cbbBeneficiary);
                if (frm.NewBeneficiary != "")
                {
                    int index = cbbBeneficiary.FindString(frm.NewBeneficiary);
                    cbbBeneficiary.SelectedIndex = index;
                }
                else
                {
                    cbbBeneficiary.SelectedIndex = i;
                }
            }
            catch(Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
            //cbbBeneficiary.Refresh();
		}
		
		/// <summary>
		/// Load form under proper category
		/// </summary>
		/// <param name="isShow"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void LoadFormWithProper(bool isShow)
		{
			//groupBox1.Visible = isShow;
			lblApplicantName.Visible = isShow;
			cbbApplicant.Visible = isShow;
            try
            {
                cbbApplicant.SelectedIndex = 0;
            }
            catch
            {
            }
			btnAddApplicant.Visible = isShow;

		}
		
		/// <summary>
		/// Selected value changed event on Category combobox
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void cbbLGCategory_SelectedValueChanged(object sender, EventArgs e)
		{
            // get type of this LG
            m_LGType = cbbLGCategory.SelectedValue.ToString();
            //clear list detail
            dtgLGList.Rows.Clear();
            //clear list fee schedule
            LstFeeSchedule.Clear();
			if (cbbLGCategory.Items.Count <= 0)
				return;
            if (((ParameterDTO)cbbLGCategory.SelectedItem).Value == "1")
			{
				LoadFormWithProper(false);
				

                txtGLCode.Text = clsLGConstant.LG_CATEGORY_PROPER;
                dtgLGList.Columns[3].ReadOnly = false;
                dtgLGList.Columns[3].DefaultCellStyle.BackColor = Color.White ;
			}
            else if (((ParameterDTO)cbbLGCategory.SelectedItem).Value == "2")
			{
				LoadFormWithProper(true);
				
                txtGLCode.Text = clsLGConstant.LG_CATEGORY_COUNTER;
                dtgLGList.Columns[3].ReadOnly = true;
                dtgLGList.Columns[3].DefaultCellStyle.BackColor = dtgLGList.Columns[3].DefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
                ((DataGridViewComboBoxColumn)dtgLGList.Columns[4]).DataSource = null;
                
            }
            cbbCustomerCode.DataSource = clsLGCommonBus.Instance().GetListCustomerByLGType(((ParameterDTO)cbbLGCategory.SelectedItem).Value);
            cbbCustomerCode.DisplayMember = "CustomerCode";
            cbbCustomerCode.ValueMember = "CustomerName";

		}

		/// <summary>
		/// Standard radiobutton checked changed event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void radStandard_CheckedChanged(object sender, EventArgs e)
		{
			if (radStandard.Checked == true)
			{
				cbbCurrency.Enabled = false;
				txtOrther.Enabled = false;
				txtOrther.Text = "";
				cbbCurrency.SelectedIndex = -1;
			}
			else
			{
				cbbCurrency.Enabled = true;
				txtOrther.Enabled = true;
			}


		}

		/// <summary>
		/// Selected index changed on currency combobox event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void cbbCurrency_SelectedIndexChanged(object sender, EventArgs e)
		{
			SetCurrencyFormat(cbbCurrency, txtOrther);
		}



		/// <summary>
		/// Delete an item on datagrid event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void btnRemove_Click(object sender, EventArgs e)
		{
            //remover schedule
            if (dtgLGList.SelectedRows.Count > 0)
            {
                int flagRecord = -1;
                for (int j = LstFeeSchedule.Count - 1; j >= 0; j--)
                {
                    if (LstFeeSchedule[j].SubID == dtgLGList.SelectedRows[0].Cells[0].Value.ToString())
                    {
                        LstFeeSchedule.RemoveAt(j);
                        flagRecord = j;
                    }
                }


                if (dtgLGList.Rows.Count > 0)
                    dtgLGList.Rows.RemoveAt(dtgLGList.Rows.IndexOf(dtgLGList.SelectedRows[0]));

                if (flagRecord >= 0)
                {
                    for (int k = flagRecord; k < LstFeeSchedule.Count; k++)
                    {
                        LstFeeSchedule[k].SubID = (int.Parse(LstFeeSchedule[k].SubID) - 1).ToString("00");
                    }
                }
                if (dtgLGList.Rows.Count > 0)
                {
                    for (int i = 0; i < dtgLGList.Rows.Count; i++)
                    {
                        dtgLGList.Rows[i].Cells[0].Value = i.ToString("00");
                    }
                }
            }
		}



        /// <summary>
        /// Set name base on customer code
        /// </summary>
        private void SetCustomerName()
        {
            dtgLGList.Rows.Clear();
            LstFeeSchedule.Clear();
            cbbCustomerName.Text = ((clsLGCustomerDTO)cbbCustomerCode.SelectedItem).CustomerName;
            if (cbbLGCategory.SelectedIndex == 0)
            {  
                clsLGIssueBus bus = new clsLGIssueBus();
                ((DataGridViewComboBoxColumn)dtgLGList.Columns[4]).DataSource = bus.GetListAccount(((clsLGCustomerDTO)cbbCustomerCode.SelectedItem).CustomerCode);
                ((DataGridViewComboBoxColumn)dtgLGList.Columns[4]).DisplayMember = "AccountNo";
                ((DataGridViewComboBoxColumn)dtgLGList.Columns[4]).ValueMember = "AccountNo";
                
            }
        }

        
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_ChangeValueControl.Count > 0)
                {
                    DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.CONFIRM_ACTION, new string[] { "save", "LG" });
                    if (result == DialogResult.Yes)
                    {
                        string error = Save();
                        if (error != "")
                        {
                            if (error != "None")
                                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                        }
                        else
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "LG" });

                            PopulateSmileData();
                            

                            CWorker worker = new CWorker(Run, Complete);
                            worker.Start();
                            isButtonSaveClick = true;
                            this.Close();
                        }
                    }
                    if (result == DialogResult.No)
                    {
                        isButtonSaveClick = true;
                        this.Close();
                        
                    }
                }
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
                
            }
        }

        bool CheckDate()
        {
            if (dtpExpireDate.Value < dtpValueDate.Value)
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.EXPRIREDATE_GREATER_VALUEDATE);
                DateTimePickerFormat fmt = dtpExpireDate.Format;
                 dtpExpireDate.Format = DateTimePickerFormat.Short;
                dtpExpireDate.Format = fmt;
                dtpExpireDate.Select();
                dtpExpireDate.Focus();
                return false;
                
            }
            if(radFledgeDeposit.Checked)
            {
                for (int i = 0; i < dtgLGList.Rows.Count; i++)
                {
                    try
                    {
                        if (clsLGCommonBus.Instance().CheckBankingDate(dtpExpireDate.Value, dtgLGList.Rows[i].Cells[1].Value.ToString()))
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.EXPIREDATE_IS_NOT_BANKING_DATE);
                            DateTimePickerFormat fmt = dtpExpireDate.Format;
                            dtpExpireDate.Format = DateTimePickerFormat.Short;
                            dtpExpireDate.Format = fmt;
                            dtpExpireDate.Select();
                            dtpExpireDate.Focus();
                            return false;
                        }

                        if (clsLGCommonBus.Instance().CheckBankingDate(dtpValueDate.Value, dtgLGList.Rows[i].Cells[1].Value.ToString()))
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.VALUEDATE_IS_NOT_BANKING_DATE);
                            DateTimePickerFormat fmt = dtpValueDate.Format;
                            dtpValueDate.Format = DateTimePickerFormat.Short;
                            dtpValueDate.Format = fmt;
                            dtpValueDate.Select();
                            dtpValueDate.Focus();
                            return false;
                        }
                    }
                    catch { }
                }
            }
            return true;
        }
        /// <summary>
        /// Save data from screen to database
        /// </summary>
        /// <returns></returns>
        private string Save()
        {
            if (CheckDate() == false) return "None";
            clsDataAccessLayer dal = new clsDataAccessLayer();

            //History Header
            clsLGLogBase logBase = new clsLGLogBase();
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Action = (int)CommonValue.ActionType.New;
            logBase.Module = clsLGConstant.LG_MODULE;
            string error = ""; // error occur during save data 
            try
            {
                clsLGIssueBus bus = new clsLGIssueBus();
                int lgType = int.Parse(cbbLGCategory.SelectedValue.ToString());
                string lgCode = "";
                m_LGNo = lgCode;



                //int numberEdit = 0;
                string glCode = txtGLCode.Text;                     
                //value date
                DateTime valueDate = dtpValueDate.Value;
                //input date
                DateTime inputDate = dtpInputDate.Value;
                //expire date
                DateTime expireDate = dtpExpireDate.Value;
                //customer code
                string customerCode = cbbCustomerCode.Text;
                //applicant
                int applicantCode = -1; // default if user not select applicant value = -1
                string applicantName = "";
                //beneficiary
                int beneficiaryCode = -1; // default = -1 if user not select beneficiary
                string beneficiaryName = "";
                //contactInfo 
                string contractInfo = txtContractInformation.Text;
                //representation
                string representation1 = txtRepresentation1.Text;
                string representation2 = txtRepresentation2.Text;
                string representation3 = txtRepresentation3.Text;

                bool bookPurpose = ckbBookingPurpose.Checked;
                bool minRateStandard = false; // 0 : Standart
                decimal minRateAmount = DEFAULT_MINRATE_AMOUNT;
                string minRateCurrency = DEFAULT_MINRATE_CCY;

                string remark = txtRemark.Text;
                byte lgStatus = 1; //New Entry
                byte lgBeforeStatus = 0;//none
                byte lgAction = 1;
                byte flagLG = 0;
                string conditionTermination = "";
                int overdureFeeTermination = 0;
                string currenceTermination = "";
                byte numReportSBV = 0;
                byte flagControlBook = 0;
                int createID = clsUserInfo.UserNo;

                if (customerCode == "")
                {
                    error = lblCustomerCode.Text;
                    cbbCustomerCode.Focus();
                    throw new System.ArgumentException("");
                }
                
               
                try
                {
                    beneficiaryCode = int.Parse((string)cbbBeneficiary.SelectedValue);
                    beneficiaryName = cbbBeneficiary.Text;
                }
                catch { }
                if (beneficiaryCode == -1)
                {
                    error = lblBeneficiary.Text;
                    cbbBeneficiary.Focus();
                    throw new System.ArgumentException("");
                }

                new clsLGBus().GetListBeneficiaryForComboboxReload(cbbBeneficiary);

                int indexBe = cbbBeneficiary.FindString(beneficiaryName);

                if (indexBe < 0)
                {
                    error = lblBeneficiary.Text + clsLGCommonMessage.BENEFICIARY_NOT_EXIST;
                    throw new System.ArgumentException("");
                }
                else
                {
                    cbbBeneficiary.SelectedIndex = indexBe;
                }
                
                try
                {
                    applicantCode = int.Parse((string)cbbApplicant.SelectedValue);
                    applicantName = cbbApplicant.Text;
                }
                catch { }
                if (applicantCode == -1 && cbbApplicant.Visible == true) //if user not select applicant -> show message
                {
                    error = lblApplicantName.Text;
                    cbbApplicant.Focus();
                    throw new System.ArgumentException("");
                }

                new clsLGBus().GetListApplicantForComboboxReLoad(cbbApplicant);

                int indexAp = cbbApplicant.FindString(applicantName);

                if (indexAp < 0)
                {
                    error = lblApplicantName.Text + clsLGCommonMessage.APPLICANT_NOT_EXIST;
                    throw new System.ArgumentException("");
                }
                else
                {
                    cbbApplicant.SelectedIndex = indexAp;
                }
               
                if ((string)cbbGuaranteeType.SelectedValue == "")
                {
                    error = lblGuaranteeType.Text;
                    cbbGuaranteeType.Focus();
                    throw new System.ArgumentException("");
                }
                string guaranteeType = (string)cbbGuaranteeType.SelectedValue;
               
                if ((string)cbbCalculateType.SelectedValue == "")
                {
                    cbbCalculateType.Focus();
                    error = lblCalculateType.Text;
                    throw new System.ArgumentException("");
                }
                string calculateType = (string)cbbCalculateType.SelectedValue;
               
                if (txtLGRate.Text == "")
                {
                    error = lblLGRate.Text;
                    txtLGRate.Focus();
                    throw new System.ArgumentException("");
                }
                decimal lgRate = decimal.Parse(txtLGRate.Text); 
                bool lgSecurity = true;
                if (radFledgeDeposit.Checked)
                {
                    lgSecurity = false;
                }
                
                if (radOthers.Checked)
                {
                    minRateStandard = true; // 1 : Orther
                    if (txtOrther.Text == "")
                    {
                        error = "Minimum Rate Amount";
                        txtOrther.Focus();
                        throw new System.ArgumentException("");
                    }
                    minRateAmount = decimal.Parse(txtOrther.Text.Replace(",", ""));


                    minRateCurrency = (string)cbbCurrency.SelectedValue;
                    if (minRateCurrency == "" || minRateCurrency == null)
                    {
                        error = "Minimum Rate Currency";
                        cbbCurrency.Focus();
                        throw new System.ArgumentException("");
                    }

                }

               
               

               
                SqlParameter[] parameters = new SqlParameter[35];
                parameters[32] = new SqlParameter("@inputDate", inputDate);
                parameters[0] = new SqlParameter("@lgCode", lgCode);

                parameters[1] = new SqlParameter("@lgType", lgType);
               // parameters[2] = new SqlParameter("@numberEdit", numberEdit);
                parameters[3] = new SqlParameter("@glCode", glCode);
                parameters[4] = new SqlParameter("@valueDate", valueDate);
                parameters[5] = new SqlParameter("@expireDate", expireDate);
                parameters[6] = new SqlParameter("@customerCode", customerCode);
                parameters[7] = new SqlParameter("@beneficiaryCode", beneficiaryCode);
                if(applicantCode != -1)
                    parameters[8] = new SqlParameter("@applicantCode", applicantCode);
                else parameters[8] = new SqlParameter("@applicantCode", DBNull.Value);
                parameters[9] = new SqlParameter("@contractInfo", contractInfo);
                parameters[10] = new SqlParameter("@representation1", representation1);
                parameters[11] = new SqlParameter("@representation2", representation2);
                parameters[12] = new SqlParameter("@representation3", representation3);
                parameters[13] = new SqlParameter("@guaranteeType", guaranteeType);
                parameters[14] = new SqlParameter("@calculateType", calculateType);
                parameters[15] = new SqlParameter("@lgRate", lgRate);
                parameters[16] = new SqlParameter("@lgSecurity", lgSecurity);
                parameters[17] = new SqlParameter("@bookPurpose", bookPurpose);
                parameters[18] = new SqlParameter("@minRateStandard", minRateStandard);
                parameters[19] = new SqlParameter("@minRateAmount", minRateAmount);
                parameters[20] = new SqlParameter("@remark", remark);
                parameters[21] = new SqlParameter("@lgStatus", lgStatus);
                parameters[22] = new SqlParameter("@lgBeforeStatus", lgBeforeStatus);
                parameters[23] = new SqlParameter("@lgAction", lgAction);
                parameters[24] = new SqlParameter("@flagLG", flagLG);
                parameters[25] = new SqlParameter("@conditionTermination", conditionTermination);
                parameters[26] = new SqlParameter("@overdureFeeTermination", overdureFeeTermination);
                parameters[27] = new SqlParameter("@currenceTermination", currenceTermination);
                parameters[28] = new SqlParameter("@numReportSBV", numReportSBV);
                parameters[29] = new SqlParameter("@flagControlBook", flagControlBook);
                parameters[30] = new SqlParameter("@createID", createID);
                int id = 0;
                parameters[31] = new SqlParameter("@id", id);
                parameters[31].Direction = ParameterDirection.Output;
                parameters[33] = new SqlParameter("@Code", id);
                parameters[33].Direction = ParameterDirection.Output;
                parameters[2] = new SqlParameter("@minRateCurrency", minRateCurrency);

                parameters[34] = new SqlParameter("@allow", cbLGAllowed.Checked);
                //parameters[33] = new SqlParameter("",);
                string lgNo = dal.ExecuteNonQueryOutString("dbo.spLG_InsertLGMaster", CommandType.StoredProcedure, parameters, "@id");
                m_SeqLG = lgNo;
                string Code = dal.GetParameterValue("@Code");
                m_LGNo = Code;
                //log key
                logBase.Key = lgNo + " " + Code;
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = "Seq LG",
                    OldValue = String.Empty,
                    NewValue = lgNo
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblLGNo.Text,
                    OldValue = String.Empty,
                    NewValue = Code
                });

                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblLGCategory.Text,
                    OldValue = String.Empty,
                    NewValue = cbbLGCategory.Text
                });

                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblGLCode.Text,
                    OldValue = String.Empty,
                    NewValue = txtGLCode.Text
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblInputDate.Text,
                    OldValue = String.Empty,
                    NewValue = dtpInputDate.Value.ToString()
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblValueDate.Text,
                    OldValue = String.Empty,
                    NewValue = dtpValueDate.Value.ToString()
                });

               
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblExpireDate.Text,
                    OldValue = String.Empty,
                    NewValue = dtpExpireDate.Value.ToString()
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {
                    //add Applicant Fax to insert history
                    FieldName = lblCustomerCode.Text,
                    OldValue = String.Empty,
                    NewValue = cbbCustomerCode.Text
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblBeneficiary.Text,
                    OldValue = String.Empty,
                    NewValue = cbbBeneficiary.Text
                });
                if (applicantCode != -1)
                    logBase.LstLogInformation.Add(new clsLGLogInformation
                    {

                        FieldName = lblApplicantName.Text,
                        OldValue = String.Empty,
                        NewValue = cbbApplicant.Text
                    });

                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblContractInformation.Text,
                    OldValue = String.Empty,
                    NewValue = txtContractInformation.Text
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblRepresentation1.Text,
                    OldValue = String.Empty,
                    NewValue = txtRepresentation1.Text
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblRepresentation2.Text,
                    OldValue = String.Empty,
                    NewValue = txtRepresentation2.Text
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {
                    FieldName = lblRepresentation3.Text,
                    OldValue = String.Empty,
                    NewValue = txtRepresentation3.Text
                });

                logBase.LstLogInformation.Add(new clsLGLogInformation
                {
                    FieldName = lblGuaranteeType.Text,
                    OldValue = String.Empty,
                    NewValue = guaranteeType
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {
                    FieldName = lblCalculateType.Text,
                    OldValue = String.Empty,
                    NewValue = calculateType
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {
                    FieldName = lblLGRate.Text,
                    OldValue = String.Empty,
                    NewValue = txtLGRate.Text
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {
                    FieldName = "LG Security",
                    OldValue = String.Empty,
                    NewValue = lgSecurity.ToString()
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {
                    FieldName = lblBookingPurpose.Text,
                    OldValue = String.Empty,
                    NewValue = bookPurpose.ToString()
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = "Min Rate Standard",
                    OldValue = String.Empty,
                    NewValue = minRateStandard.ToString()
                });

                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = "Min Rate Amount",
                    OldValue = String.Empty,
                    NewValue = minRateAmount.ToString()
                });

                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = "Min Rate CCY",
                    OldValue = String.Empty,
                    NewValue = minRateCurrency.ToString()
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblRemark.Text,
                    OldValue = String.Empty,
                    NewValue = txtRemark.Text
                });
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = "LG Status",
                    OldValue = String.Empty,
                    NewValue = "New Entry"
                });


                m_ListLogs.Add(logBase);
                dal.ClearParameter();
                if (dtgLGList.Rows.Count == 0)
                {
                    error = "LG Detail";
                  //  cbbCurrency.Focus();
                    btnAdd.Focus();
                    throw new System.ArgumentException("");
                }
                if (dtgLGList.Rows.Count > 0)
                {
                    for (int i = 0; i < dtgLGList.Rows.Count; i++)
                    {
                        clsLGLogBase log = new clsLGLogBase();
                        log.UserID = clsUserInfo.UserNo.ToString();
                        log.Action = (int)CommonValue.ActionType.New;
                        log.ApplicationName = this.Text;
                        log.Module = clsLGConstant.LG_MODULE;
                        log.Key = lgNo + " " + Code + " " + dtgLGList.Rows[i].Cells[0].Value.ToString();
                        parameters = new SqlParameter[15];
                        parameters[0] = new SqlParameter("@seqLG", int.Parse(lgNo));
                        
                        parameters[1] = new SqlParameter("@subCode", dtgLGList.Rows[i].Cells[0].Value.ToString());
                       
                        parameters[2] = new SqlParameter("@flagControlBook", Int16.Parse("0"));
                        log.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = dtgLGList.Columns[0].HeaderText,
                            OldValue = String.Empty,
                            NewValue = dtgLGList.Rows[i].Cells[0].Value.ToString()
                        });

                        log.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName ="Flag Controling Book",
                            OldValue = String.Empty,
                            NewValue = "0"
                        });

                        parameters[3] = new SqlParameter("@preSubCode", DBNull.Value);
                        log.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName ="PreSubCode",
                            OldValue = String.Empty,
                            NewValue = ""
                        });
                        if (dtgLGList.Rows[i].Cells[1].Value == null)
                        {
                            error = "CCY";
                            dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[1];
                        }
                        parameters[4] = new SqlParameter("@tranCurrency", dtgLGList.Rows[i].Cells[1].Value.ToString());
                        log.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName =dtgLGList.Columns[1].HeaderText,
                            OldValue = String.Empty,
                            NewValue = dtgLGList.Rows[i].Cells[1].Value.ToString()
                        });
                        parameters[5] = new SqlParameter("@transAmount", decimal.Parse(dtgLGList.Rows[i].Cells[2].Value.ToString()));
                        log.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName =dtgLGList.Columns[2].HeaderText,
                            OldValue = String.Empty,
                            NewValue = dtgLGList.Rows[i].Cells[2].Value.ToString()
                        });
                        
                        if (dtgLGList.Rows[i].Cells[3].Value == null)
                            dtgLGList.Rows[i].Cells[3].Value = false;

                        parameters[6] = new SqlParameter("@transientAccount", (bool)dtgLGList.Rows[i].Cells[3].Value);
                        log.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName =dtgLGList.Columns[3].HeaderText,
                            OldValue = String.Empty,
                            NewValue = dtgLGList.Rows[i].Cells[3].Value.ToString()
                        });
                        if (dtgLGList.Rows[i].Cells[4].Value == null)
                        {
                            error = "Charge Account";
                            dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[4];
                        }
                       // if(lgType == 1)
                        parameters[7] = new SqlParameter("@chargeCurrency", dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(3));
                        //else parameters[7] = new SqlParameter("@chargeCurrency", dtgLGList.Rows[i].Cells[1].Value.ToString()); // default value  ?? need QA

                        log.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName ="Charge CCY",
                            OldValue = String.Empty,
                            NewValue = dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(3)
                        });

                        
                        //if(lgType == 1)
                        parameters[8] = new SqlParameter("@chargeAccount", dtgLGList.Rows[i].Cells[4].Value == null ? "" : dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(0,4));

                        log.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName =dtgLGList.Columns[4].HeaderText,
                            OldValue = String.Empty,
                            NewValue = dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(0, 4)
                        });
                        // else parameters[8] = new SqlParameter("@chargeAccount", dtgLGList.Rows[i].Cells[4].Value == null ? "" : dtgLGList.Rows[i].Cells[4].Value.ToString());
                        parameters[9] = new SqlParameter("@fee", DBNull.Value);

                        parameters[10] = new SqlParameter("@feeCurrency", DBNull.Value);
                        if (dtgLGList.Rows[i].Cells[8].Value == null)
                        {
                            clsLGFeeScheduleDTO find = LstFeeSchedule.Find(delegate(clsLGFeeScheduleDTO dk)
                            {
                                return dk.SubID == dtgLGList.Rows[i].Cells[0].Value.ToString();
                            });

                            if (find == null)
                            {
                                error = "Create Charge Collection Schedule";
                                dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[8];
                                throw new System.ArgumentException("");
                            }
                            parameters[11] = new SqlParameter("@date", DBNull.Value);

                        }
                        else
                        {
                            parameters[11] = new SqlParameter("@date", (DateTime)dtgLGList.Rows[i].Cells[8].Value);
                           
                          
                            parameters[9] = new SqlParameter("@fee", decimal.Parse(dtgLGList.Rows[i].Cells[6].Value.ToString()));
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName =  dtgLGList.Columns[6].HeaderText,
                                OldValue = String.Empty,
                                NewValue = dtgLGList.Rows[i].Cells[6].Value.ToString()
                            });
                            if (dtgLGList.Rows[i].Cells[7].Value == null)
                            {
                                error = "Fee Currency";
                                dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[7];
                            }
                            parameters[10] = new SqlParameter("@feeCurrency", dtgLGList.Rows[i].Cells[7].Value.ToString());
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[7].HeaderText,
                                OldValue = String.Empty,
                                NewValue = dtgLGList.Rows[i].Cells[7].Value.ToString()
                            });
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[8].HeaderText,
                                OldValue = String.Empty,
                                NewValue = dtgLGList.Rows[i].Cells[8].Value.ToString()
                            });
                        }

                        m_ListLogs.Add(log);  
                        int outVl = 0;
                        parameters[12] = new SqlParameter("@out", outVl);
                        parameters[12].Direction = ParameterDirection.Output;

                        parameters[13] = new SqlParameter("@oldSeqLG", DBNull.Value);
                        parameters[14] = new SqlParameter("@oldSubCode", DBNull.Value);
                        dal.ExecuteNonQueryOutString("dbo.spLG_InsertLGDetail", CommandType.StoredProcedure, parameters, "@out");
                        dal.ClearParameter();

                        
                    }
                }
                  

                if (LstFeeSchedule.Count > 0)
                {
                    for (int i = 0; i < LstFeeSchedule.Count; i++)
                    {
                        clsLGLogBase logBase1 = new clsLGLogBase();
                        logBase1.ApplicationName = "Fee Schedule Collection";
                        logBase1.UserID = clsUserInfo.UserNo.ToString();
                        logBase1.Module = clsLGConstant.LG_MODULE;
                        logBase1.Action = (int)CommonValue.ActionType.New;
                        logBase1.Key = lgNo + " " + Code + " " + LstFeeSchedule[i].SubID + " " + LstFeeSchedule[i].No.ToString();
                        parameters = new SqlParameter[11];
                        parameters[0] = new SqlParameter("@seqLG", int.Parse(lgNo));

                        logBase1.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = "SeqLG",
                            OldValue = String.Empty,
                            NewValue = lgNo
                        });

                        parameters[1] = new SqlParameter("@subCode", LstFeeSchedule[i].SubID);
                        logBase1.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = "Sub Code",
                            OldValue = String.Empty,
                            NewValue = LstFeeSchedule[i].SubID
                        });

                        parameters[2] = new SqlParameter("@subItem", LstFeeSchedule[i].No);
                        logBase1.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = "Sub Item",
                            OldValue = String.Empty,
                            NewValue = LstFeeSchedule[i].No.ToString()
                        });
                        parameters[3] = new SqlParameter("@claimDate", LstFeeSchedule[i].ClaimedDate);
                        logBase1.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = "Claim Date",
                            OldValue = String.Empty,
                            NewValue = LstFeeSchedule[i].ClaimedDate.ToString()
                        });
                        if (LstFeeSchedule[i].ActualClaimedDate != DateTime.MinValue)
                        {
                            parameters[4] = new SqlParameter("@actualClaimDate", LstFeeSchedule[i].ActualClaimedDate);
                            logBase1.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Actual Claim Date",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].ActualClaimedDate.ToString()
                            });
                        }
                        else
                        {
                            parameters[4] = new SqlParameter("@actualClaimDate", DBNull.Value);
                            
                           
                        }
                        if (LstFeeSchedule[i].ReceivedDate != DateTime.MinValue)
                        {
                            parameters[5] = new SqlParameter("@receiveDate", LstFeeSchedule[i].ReceivedDate);
                            logBase1.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Receive Date",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].ReceivedDate.ToString()
                            });
                        }
                        else
                        {
                            parameters[5] = new SqlParameter("@receiveDate", DBNull.Value);                   
                        }
                        if (LstFeeSchedule[i].ChargeCCY != "")
                        {
                            parameters[6] = new SqlParameter("@ccy", LstFeeSchedule[i].ChargeCCY);
                            logBase1.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Charge CCY",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].ChargeCCY.ToString()
                            });
                        }
                        else
                        {
                            parameters[6] = new SqlParameter("@ccy", DBNull.Value);
                        }
                        if (LstFeeSchedule[i].ExchangeRate != -1)
                        {
                            parameters[7] = new SqlParameter("@exchangeRate", LstFeeSchedule[i].ExchangeRate);
                            logBase1.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Exchange Rate",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].ExchangeRate.ToString()
                            });
                        }
                        else
                        {
                            parameters[7] = new SqlParameter("@exchangeRate", DBNull.Value);
                        }
                        if (LstFeeSchedule[i].Fee != -1)
                        {
                            parameters[8] = new SqlParameter("@fee", LstFeeSchedule[i].Fee);
                            logBase1.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Fee",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].Fee.ToString()
                            });
                        }
                        else
                        {
                            parameters[8] = new SqlParameter("@fee", DBNull.Value);
                        }
                        parameters[9] = new SqlParameter("@createID", clsUserInfo.UserNo);

                        int outVl = 0; // this value not use, just need to complete this kind of execute query
                        parameters[10] = new SqlParameter("@out", outVl);
                        parameters[10].Direction = ParameterDirection.Output;
                        dal.ExecuteNonQueryOutString("dbo.spLG_InsertFeeSchedule", CommandType.StoredProcedure, parameters, "@out");
                        dal.ClearParameter();
                        m_ListLogs.Add(logBase1);

                    }

                }
                for (int i = 0; i < m_ListLogs.Count; i++)
                {
                    m_ListLogs[i].WirteLog(dal);
                }

                dal.Commit();
                this.DialogResult = DialogResult.OK;
                m_LGStatus = ((int)CommonValue.LGAction.NewEntry).ToString();
                m_LGNo = Code;

                m_LGType = cbbLGCategory.SelectedValue.ToString();
                m_Guarantee = cbbGuaranteeType.SelectedValue.ToString();
                 m_arr = new ArrayList();
                for (int i = 0; i < dtgLGList.Rows.Count; i++)
                {
                    m_arr.Add(m_LGNo + "-" + dtgLGList.Rows[i].Cells[0].Value.ToString());
                }
            }
            catch(Exception ex)
            {
                dal.RollBack();
                if (error == "")
                    throw (ex);
            }
            m_ListLogs.Clear();
            return error;
        }

        /// <summary>
        /// do nothing
        /// </summary>
        void Run()
        {
           
        }
        /// <summary>
        /// show print form
        /// </summary>
        void Complete()
        {
            m_frmPrintForm.StartPosition = FormStartPosition.CenterScreen;
            m_frmPrintForm.ShowDialog();
        }

        private void dtgLGList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2 || e.ColumnIndex == 1)
            {
                if (dtgLGList.Rows[e.RowIndex].Cells[1].Value != null)
                {

                    
                    decimal rate = 0;
                    try
                    {
                        rate = decimal.Parse(txtLGRate.Text);
                    }
                    catch
                    {
                    }
                    TimeSpan tp = dtpExpireDate.Value - dtpValueDate.Value.AddSeconds(-1);
                    decimal amount = (decimal)dtgLGList.Rows[e.RowIndex].Cells[2].Value;
                    int numDecimal = clsLGConstant.NUMBERDECIMAL;
                    if(clsLGCommonBus.Instance().MainCCYList.Contains(dtgLGList.Rows[e.RowIndex].Cells[1].Value.ToString()))
                    {
                        numDecimal = 0;
                        dtgLGList.Rows[e.RowIndex].Cells[2].Value = Math.Round((decimal)dtgLGList.Rows[e.RowIndex].Cells[2].Value, 0);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE3)
                    {
                        dtgLGList.Rows[e.RowIndex].Cells[5].Value = Math.Round(amount * RoundingUp((decimal)tp.Days / 30) * rate / 100  / 12, numDecimal);
                        dtgLGList.Rows[e.RowIndex].Cells[6].Value = Math.Round(amount * RoundingUp((decimal)tp.Days / 30) * rate / 100  / 12, numDecimal);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE2)
                    {
                        dtgLGList.Rows[e.RowIndex].Cells[5].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 360, numDecimal);
                        dtgLGList.Rows[e.RowIndex].Cells[6].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 360, numDecimal);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE1)
                    {
                        dtgLGList.Rows[e.RowIndex].Cells[5].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 365, numDecimal);
                        dtgLGList.Rows[e.RowIndex].Cells[6].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 365, numDecimal);
                    }


                }
                if (e.ColumnIndex == 1)
                {
                    if (dtgLGList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                    {
                        if (cbbLGCategory.SelectedValue.ToString() == ((int)CommonValue.LGType.Counter).ToString())
                        {

                            DataGridViewComboBoxCell combo = this.dtgLGList[4, e.RowIndex] as DataGridViewComboBoxCell;
                            combo.Value = null;
                            List<clsLGAccountInfoDTO> lst = new List<clsLGAccountInfoDTO>();
                            for (int i = 0; i < m_lstCCY.Count; i++)
                            {
                                if(m_lstCCY[i].Value != "")
                                lst.Add(new clsLGAccountInfoDTO(m_lstCCY[i].Value + "-" + clsLGConstant.LG_COUNTER_ACCOUNT, dtgLGList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() + "-" + clsLGConstant.LG_COUNTER_ACCOUNT));
                            }
                            combo.DataSource = lst;

                            combo.DisplayMember = "AccountNo";
                            combo.ValueMember = "AccountNo";
                            dtgLGList.Rows[e.RowIndex].Cells[4].Value = dtgLGList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() + "-" + clsLGConstant.LG_COUNTER_ACCOUNT;
                        }

                    

                        dtgLGList.Rows[e.RowIndex].Cells["colFeeCurrency"].Value = dtgLGList.Rows[e.RowIndex].Cells["colCurrency"].Value;

                    }
                    
                    
                }
            }
            
        }

        private void txtLGRate_TextChanged(object sender, EventArgs e)
        {
            ReCalculateValue();
        }
        /// <summary>
        /// Re calculate value in datagrid when 1 parameter change value
        /// </summary>
        private void ReCalculateValue()
        {
            decimal rate = 0;
            try
            {
                rate = decimal.Parse(txtLGRate.Text);
            }
            catch
            {
            }
            TimeSpan tp = dtpExpireDate.Value - dtpValueDate.Value.AddSeconds(-1);

            for (int i = 0; i < dtgLGList.Rows.Count; i++)
            {
                int numDecimal = clsLGConstant.NUMBERDECIMAL;
                if (dtgLGList.Rows[i].Cells[1].Value != null)
                {
                    if (clsLGCommonBus.Instance().MainCCYList.Contains(dtgLGList.Rows[i].Cells[1].Value.ToString()))
                    {
                        numDecimal = 0;
                    }
                    
                    decimal amount = (decimal)dtgLGList.Rows[i].Cells[2].Value;
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE3)
                    {
                        dtgLGList.Rows[i].Cells[5].Value = Math.Round(amount * RoundingUp((decimal)tp.Days / 30) * rate / 100 / 12, numDecimal);
                        dtgLGList.Rows[i].Cells[6].Value = Math.Round(amount * RoundingUp((decimal)tp.Days / 30) * rate / 100 / 12, numDecimal);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE2)
                    {
                        dtgLGList.Rows[i].Cells[5].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 360, numDecimal);
                        dtgLGList.Rows[i].Cells[6].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 360, numDecimal);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE1)
                    {
                        dtgLGList.Rows[i].Cells[5].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 365, numDecimal);
                        dtgLGList.Rows[i].Cells[6].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 365, numDecimal);
                    }
                }
            }
        }

        decimal RoundingUp(decimal input)
        {
            return Math.Ceiling(input);
        }
        private void dtpValueDate_ValueChanged(object sender, EventArgs e)
        {
         
            ReCalculateValue();
        }

        private void dtpExpireDate_ValueChanged(object sender, EventArgs e)
        {
            
            ReCalculateValue();
        }

        private void btnCreate_Click_1(object sender, EventArgs e)
        {
            //try
            //{
                //if (m_LstFeeLog.Count == 0)
                //{
                //    for (int i = 0; i < dtgLGList.Rows.Count; i++)
                //    {
                //        List<clsLGLogBase> lst = new List<clsLGLogBase>();
                //        m_LstFeeLog.Add(lst);
                //    }
                //}
                string error = CheckDataGrid();
                if (error != "")
                {
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                }
                else
                {
                    if (dtgLGList.SelectedRows != null && dtgLGList.SelectedRows.Count > 0)
                    {
                        // if (frmCreateFee == null)
                        frmCreateFee = new frmLGFeeCollectionSchedule(dtgLGList, this,cbbBeneficiary.Text, cbbCustomerName.Text);
                        if (frmCreateFee.IsCorrect == true)
                        {
                            frmCreateFee.ShowDialog();
                            frmCreateFee.BringToFront();
                            if (LstFeeSchedule.Count > 0)
                            {
                                dtgLGList.Columns["colDateOfActualCollection"].ReadOnly = true;
                            }
                            else
                                dtgLGList.Columns["colDateOfActualCollection"].ReadOnly = false;
                        }
                        else
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.CANNOT_CREATE_FEE_SCHEDULE);
                        }
                    }
                }
            //}
            //catch (Exception ex)
            //{
            //    ForceClose = true;
            //    clsError.ShowErrorScreen(ex.Message +
            //      Environment.NewLine +
            //      ex.TargetSite, this);
            //    clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            //}
        }
        /// <summary>
        /// check value null in datagridview
        /// </summary>
        /// <returns></returns>
        private string CheckDataGrid()
        {
            string error = "";
            if (dtgLGList.Rows.Count > 0)
            {
                
                for (int i = 0; i < dtgLGList.Rows.Count; i++)
                {

                    if (dtgLGList.Rows[i].Cells[1].Value == null)
                    {
                        dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[1];
                        return error = "Currency";
                       
                    }

                    if (dtgLGList.Rows[i].Cells[4].Value == null)
                    {
                        dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[4];
                        return error = "Account";
                    }

                    //if (dtgLGList.Rows[i].Cells[7].Value == null)
                    //{
                    //    return error = "Fee Currency (row " + (i + 1).ToString() + ")";
                    //}
                }
            }
           
            return error;
        }

        private void btnSaveAndContinue_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_ChangeValueControl.Count > 0)
                {
                    DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.CONFIRM_ACTION, new string[] { "save", "LG" });
                    if (result == DialogResult.Yes)
                    {

                        string error = Save();
                        if (error != "")
                        {
                            if (error != "")
                            {
                                if (error != "None")
                                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                            }
                            // clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                        }
                        else
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "LG" });

                            PopulateSmileData();

                            CWorker worker = new CWorker(Run, Complete);
                            worker.Start();
                            dtpExpireDate.Value = clsLGCommonBus.Instance().GetServerDate();
                            dtpValueDate.Value = clsLGCommonBus.Instance().GetServerDate();
                            cbbCustomerCode.SelectedIndex = 0;
                            cbbBeneficiary.SelectedIndex = 0;
                            radFledgeDeposit.Checked = true;
                            ckbBookingPurpose.Checked = false;
                            cbbApplicant.SelectedIndex = 0;
                            radStandard.Checked = true;
                            txtLGRate.Text = "0";
                            cbbGuaranteeType.SelectedIndex = 0;
                            cbbCalculateType.SelectedIndex = 0;
                            dtgLGList.Rows.Clear();
                            LstFeeSchedule.Clear();
                            txtRemark.Text = "";
                            txtContractInformation.Text = "";
                            txtRepresentation1.Text = m_LstRepresentation[0].Name;
                            txtRepresentation2.Text = m_LstRepresentation[1].Name;
                            txtRepresentation3.Text = m_LstRepresentation[2].Name;
                            dtgLGList.Columns["colDateOfActualCollection"].ReadOnly = false;
                            m_ChangeValueControl.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        private void cbbCalculateType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbbCalculateType.Text != "") // add this control to list control which change value
            {
                m_ChangeValueControl.Add(cbbCalculateType.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(cbbCalculateType.Name))
                {
                    m_ChangeValueControl.Remove(cbbCalculateType.Name);
                }
            }
            ReCalculateValue();

        }

        private void frmLGIssue_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (ForceClose == false) // strictly closing form
            {
                if (isButtonSaveClick == false) 
                {
                    if (m_ChangeValueControl.Count > 0)
                    {
                        DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.DO_YOU_WANT_SAVE);
                        if (result == DialogResult.Yes) // yes : save action
                        {
                            string error = Save();
                            if (error != "")
                            {
                                if (error != "None")
                                {
                                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });

                                }
                                e.Cancel = true;
                            }
                            else
                            {
                                // show print form
                                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "LG" });
                                PopulateSmileData();
                                CWorker worker = new CWorker(Run, Complete);
                                worker.Start();
                            }
                        }

                        if (result == DialogResult.Cancel) e.Cancel = true; // cancel closing form
                    }

                }
                if (e.Cancel != true) 
                {
                    this.Dispose();
                }
            }
        }

        private void cbbBeneficiary_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbbBeneficiary.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(cbbBeneficiary.Name);
            }
            else
            {
                if(m_ChangeValueControl.Contains(cbbBeneficiary.Name))
                {
                    m_ChangeValueControl.Remove(cbbBeneficiary.Name);
                }
            }
        }

        private void cbbApplicant_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbbApplicant.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(cbbApplicant.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(cbbApplicant.Name))
                {
                    m_ChangeValueControl.Remove(cbbApplicant.Name);
                }
            }
        }

        private void cbbGuaranteeType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbbGuaranteeType.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(cbbGuaranteeType.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(cbbGuaranteeType.Name))
                {
                    m_ChangeValueControl.Remove(cbbGuaranteeType.Name);
                }
            }
        }

        private void txtLGRate_TextChanged_1(object sender, EventArgs e)
        {
            if (txtLGRate.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                if(!m_ChangeValueControl.Contains(txtLGRate.Name))
                m_ChangeValueControl.Add(txtLGRate.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(txtLGRate.Name))
                {
                    m_ChangeValueControl.Remove(txtLGRate.Name);
                }
            }
            ReCalculateValue();
        }

        private void txtContractInformation_TextChanged(object sender, EventArgs e)
        {
            if (txtContractInformation.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(txtContractInformation.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(txtContractInformation.Name))
                {
                    m_ChangeValueControl.Remove(txtContractInformation.Name);
                }
            }
        }

        private void txtRepresentation1_TextChanged(object sender, EventArgs e)
        {
            if (txtRepresentation1.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(txtRepresentation1.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(txtRepresentation1.Name))
                {
                    m_ChangeValueControl.Remove(txtRepresentation1.Name);
                }
            }
        }

        private void txtRepresentation2_TextChanged(object sender, EventArgs e)
        {
            if (txtRepresentation2.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(txtRepresentation2.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(txtRepresentation2.Name))
                {
                    m_ChangeValueControl.Remove(txtRepresentation2.Name);
                }
            }
        }

        private void txtRepresentation3_TextChanged(object sender, EventArgs e)
        {
            if (txtRepresentation3.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(txtRepresentation3.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(txtRepresentation3.Name))
                {
                    m_ChangeValueControl.Remove(txtRepresentation3.Name);
                }
            }
        }

        private void radOthers_CheckedChanged(object sender, EventArgs e)
        {
            if (radOthers.Checked == true) // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(radOthers.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(radOthers.Name))
                {
                    m_ChangeValueControl.Remove(radOthers.Name);
                }
            }
        }

        private void txtRemark_TextChanged(object sender, EventArgs e)
        {
            if (txtRemark.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(txtRemark.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(txtRemark.Name))
                {
                    m_ChangeValueControl.Remove(txtRemark.Name);
                }
            }
        }

        private void dtgLGList_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if(!m_ChangeValueControl.Contains(dtgLGList.Name))
            m_ChangeValueControl.Add(dtgLGList.Name);
        }

        private void dtgLGList_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (dtgLGList.Rows.Count == 0)
            {
                if (m_ChangeValueControl.Contains(dtgLGList.Name)) 
                m_ChangeValueControl.Remove(dtgLGList.Name);
            }
        }

        protected override void OnShown(EventArgs e)
        {
            m_ChangeValueControl = new List<string>();
            base.OnShown(e);
        }

        private void dtgLGList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbbCustomerCode_SelectedValueChanged(object sender, EventArgs e)
        {
            SetCustomerName();
            if (cbbCustomerCode.Text != "") // add this name control to list  m_ChangeValueControl 
            {
                m_ChangeValueControl.Add(cbbCustomerCode.Name);
            }
            else
            {
                if (m_ChangeValueControl.Contains(cbbCustomerCode.Name))
                {
                    m_ChangeValueControl.Remove(cbbCustomerCode.Name);
                }
            }
        }

        private void dtgLGList_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dtgLGList.Rows[e.RowIndex].Cells["colCurrency"].Value != null)
            {
                if (clsLGCommonBus.Instance().MainCCYList.Contains((string)dtgLGList.Rows[e.RowIndex].Cells["colCurrency"].Value))
                {

                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colAmount"]).DecimalLength = 0;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colAmount"]).MaxInputLength = 10;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFeeSuggestion"]).DecimalLength = 0;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFeeSuggestion"]).MaxInputLength = 10;

                }
                else
                {
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colAmount"]).DecimalLength = 2;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colAmount"]).MaxInputLength = 13;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFeeSuggestion"]).DecimalLength = 2;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFeeSuggestion"]).MaxInputLength = 13;
                  
                }
            }
            if (dtgLGList.Rows[e.RowIndex].Cells["colFeeCurrency"].Value != null)
            {
                if (clsLGCommonBus.Instance().MainCCYList.Contains((string)dtgLGList.Rows[e.RowIndex].Cells["colFeeCurrency"].Value))
                {
                    
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFee"]).DecimalLength = 0;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFee"]).MaxInputLength = 10;
                }
                else
                {
                    
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFee"]).DecimalLength = 2;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFee"]).MaxInputLength = 13;
                }
            }

            
        }

        private void dtgLGList_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            // set value of fee and amount = 0 when CCY was changed
            if (e.ColumnIndex == 1 && e.RowIndex >= 0) // CCY
            {
                dtgLGList.Rows[e.RowIndex].Cells["colAmount"].Value = 0;

            }
            if (e.ColumnIndex == 7 && e.RowIndex >= 0) // Issues Fee CCY
            {
                dtgLGList.Rows[e.RowIndex].Cells["colFee"].Value = 0;
            }
        }

        private void dtgLGList_CellEnter(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PopulateSmileData()
        {
            // SMILE Interface
            LG data = clsLGMasterBus.GetLG(m_LGNo);
            objList = new List<object>();
            for (int i = 0; i < data.LstDetail.Count; i++)
            {
                clsLGONEWDto dto = new clsLGONEWDto();
                dto.Page1Issue = clsSmileCommon.ConvertToSmileDate(data.Master.ValueDate);
                dto.Page1Effective = dto.Page1Issue;
                dto.Page1Customer = data.Master.CustomerCode;
                dto.Page1Ccy = data.LstDetail[i].Detail.TransCurrency;
                dto.Page1GL1 = data.Master.GlCode.Substring(0, 3);
                dto.Page1GL2 = data.Master.GlCode.Substring(4, 4);
                dto.Page1Trans1 = data.Master.LgCode;
                dto.Page1Trans2 = data.LstDetail[i].Detail.SubCode;
                //
                if (clsLGCommonBus.Instance().MainCCYList.Contains(data.LstDetail[i].Detail.TransCurrency))
                {
                    dto.Page2Trans = data.LstDetail[i].Detail.TransAmount.ToString("#,0");
                }
                else
                {
                    dto.Page2Trans = data.LstDetail[i].Detail.TransAmount.ToString("#,0.00");
                }
                dto.Page2Exp = clsSmileCommon.ConvertToSmileDate(data.Master.ExpireDate);
                dto.Page2GuaranteeType = data.Master.GuaranteeType;
                dto.Page2FeeRate = data.Master.LgRate.ToString();
                dto.Page2Adj = data.Master.CalculateType;
                if (!data.Master.MinRateStandard)
                    dto.Page2Minimum = "Y";
                else
                    dto.Page2Minimum = "";
                if (data.Master.LgType == 1)
                {
                    dto.Page2CHGAC1 = data.LstDetail[i].Detail.ChargeCurrency;
                    dto.Page2CHGAC2 = "511";
                    dto.Page2CHGAC3 = "3000";
                    //double d = double.Parse(data.LstDetail[i].Detail.ChargeAccount);
                    //dto.Page2CHGAC4 = Math.Truncate(d).ToString();
                    dto.Page2CHGAC4 = data.LstDetail[i].Detail.ChargeAccount;
                }
                else
                {
                    dto.Page2CHGAC1 = data.LstDetail[i].Detail.ChargeCurrency;
                    dto.Page2CHGAC2 = "310";
                    dto.Page2CHGAC3 = "1000";
                    dto.Page2CHGAC4 = "000019";
                }
                cbbBeneficiary.SelectedValue = "2";
                cbbBeneficiary.SelectedValue = data.Master.SeqBenificiary.ToString();
                dto.Page2Bene = ((CbbObject)cbbBeneficiary.SelectedItem).Display;
                // cbbBeneficiary.SelectedItem
                dto.MacroType = MacroType.LGONEW;
                dto.ImportType = ImportType.LGIssue;
                objList.Add(dto);

                if (data.Master.MinRateStandard)
                {
                    clsGTON01Dto dto2 = new clsGTON01Dto();
                    if (dtgLGList.Rows[0].Cells["colDateOfActualCollection"].Value != null)
                        dto2.DebitCcy = data.LstDetail[i].Detail.FeeCurrency;
                    else
                        dto2.DebitCcy = data.LstDetail[i].LstFeeSchedule[0].ChargeCCY;
                    dto2.DebitValue = clsSmileCommon.ConvertToSmileDate(data.Master.ValueDate);
                    dto2.DebitAdvice = "Y";
                    //dto2.DebitGL1 = data.Master.GlCode.Substring(0, 3);
                    //dto2.DebitGL2 = data.Master.GlCode.Substring(4, 4);
                    if (data.Master.LgType == 1)
                    {
                        dto2.DebitGL1 = "511";
                        dto2.DebitGL2 = "3000";
                        dto2.DebitACNo = data.LstDetail[i].Detail.ChargeAccount;
                    }
                    else
                    {
                        dto2.DebitGL1 = "310";
                        dto2.DebitGL2 = "1000";
                        dto2.DebitACNo = "000019";
                    }
                    if (data.LstDetail[i].Detail.ActualCollectionDate != DateTime.MinValue)
                    {
                        if (clsLGCommonBus.Instance().MainCCYList.Contains(dto2.DebitCcy))
                            dto2.DebitAmount = data.LstDetail[i].Detail.Fee.ToString("#,0");
                        else
                        {
                            dto2.DebitAmount = data.LstDetail[i].Detail.Fee.ToString("#,0.00");
                        }
                    }
                    else
                    {
                        decimal fee = 0;
                        for (int j = 0; j < data.LstDetail[i].LstFeeSchedule.Count; j++)
                        {
                            fee += data.LstDetail[i].LstFeeSchedule[j].Fee;
                        }

                        //
                        if (clsLGCommonBus.Instance().MainCCYList.Contains(dto2.DebitCcy))
                        {
                            dto2.DebitAmount = fee.ToString("#,0");
                        }
                        else
                        {
                            dto2.DebitAmount = fee.ToString("#,0.00");
                        }
                    }


                    if (data.Master.LgType == 1)
                        dto2.DebitNW = "N";
                    else
                        dto2.DebitNW = String.Empty;
                    dto2.DebitReference = "LG" + data.Master.LgCode + "-" + data.LstDetail[i].Detail.SubCode;
                    dto2.DebitOurRef = "640";

                    // Credit
                    dto2.CreditCcy = dto2.DebitCcy;
                    dto2.CreditGL1 = "370";
                    dto2.CreditGL2 = "0000";
                    if (data.Master.LgType == 1)
                        dto2.CreditACNo = "637100";
                    else
                        dto2.CreditACNo = "638000";
                    if (data.LstDetail[i].Detail.ActualCollectionDate != DateTime.MinValue)
                    {
                        if (clsLGCommonBus.Instance().MainCCYList.Contains(dto2.CreditCcy))
                            dto2.CreditAmount = data.LstDetail[i].Detail.Fee.ToString("#,0");
                        else
                        {
                            dto2.CreditAmount = data.LstDetail[i].Detail.Fee.ToString("#,0.00");
                        }
                    }
                    else
                    {
                        decimal fee = 0;
                        for (int j = 0; j < data.LstDetail[i].LstFeeSchedule.Count; j++)
                        {
                            fee += data.LstDetail[i].LstFeeSchedule[j].Fee;
                        }

                        //
                        if (clsLGCommonBus.Instance().MainCCYList.Contains(dto2.DebitCcy))
                        {
                            dto2.CreditAmount = fee.ToString("#,0");
                        }
                        else
                        {
                            dto2.CreditAmount = fee.ToString("#,0.00");
                        }
                    }
                    dto2.CreditCustomer = data.Master.CustomerCode;
                    dto2.CreditReference = dto2.DebitReference;

                    // Exchange
                    string ccy1 = data.LstDetail[i].Detail.TransCurrency;
                    string ccy2 = data.LstDetail[i].Detail.FeeCurrency;
                    if (cbbLGCategory.SelectedIndex == 0)
                    {
                        if (ccy1.Equals("USD") && ccy2.Equals("USD"))
                            dto2.Method = String.Empty;
                        else if (ccy1.Equals("JPY") && ccy2.Equals("JPY"))
                            dto2.Method = "NOEX";
                        else if (ccy1.Equals("VND") && ccy2.Equals("VND"))
                            dto2.Method = "NOEX";
                        else if (ccy1.Equals("JPY") && ccy2.Equals("VND"))
                            dto2.Method = "CRSP";
                        else if (ccy1.Equals("USD") && ccy2.Equals("VND"))
                            dto2.Method = "SPOT";
                        else if (ccy1.Equals("USD") && ccy2.Equals("JPY"))
                            dto2.Method = "SPOT";
                        else
                            dto2.Method = String.Empty;
                    }
                    else
                    {
                        if (ccy2.Equals("USD") && ccy1.Equals("USD"))
                            dto2.Method = String.Empty;
                        else if (ccy2.Equals("JPY") && ccy1.Equals("JPY"))
                            dto2.Method = "NOEX";
                        else if (ccy2.Equals("VND") && ccy1.Equals("VND"))
                            dto2.Method = "NOEX";
                        else if (ccy2.Equals("JPY") && ccy1.Equals("VND"))
                            dto2.Method = "CRSP";
                        else if (ccy2.Equals("USD") && ccy1.Equals("VND"))
                            dto2.Method = "SPOT";
                        else if (ccy2.Equals("USD") && ccy1.Equals("JPY"))
                            dto2.Method = "SPOT";
                        else
                            dto2.Method = String.Empty;
                    }

                    if (!dto2.Method.Equals("NOEX"))
                        dto2.Cust = dto2.CreditCustomer;
                    else
                        dto2.Cust = String.Empty;
                    dto2.TransNo = data.Master.LgCode + "-" + data.LstDetail[i].Detail.SubCode;
                    dto2.MacroType = MacroType.GTON01;
                    dto2.ImportType = ImportType.GeneralTransfer;
                    objList.Add(dto2);
                }

                SmileErrorLog = new clsErrorLogDto();
                SmileErrorLog.Module = Module.LG.ToString();
                SmileErrorLog.TransNo = data.Master.LgCode;
                SmileErrorLog.ImportBy = clsUserInfo.UserName;

                m_frmPrintForm = new frmLGPrintForm(int.Parse(m_SeqLG), m_arr, m_LGStatus, m_LGType, m_Guarantee);
                m_frmPrintForm.Tag = MdiParent;
                m_frmPrintForm.AllowImportSmile = true;
                m_frmPrintForm.MacroList = objList;
                m_frmPrintForm.SmileLogInfo = SmileErrorLog;
            }
        }
    }
}