﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: htkhiem $
 * $Date: 2013-01-16 14:30:00 +0700 (Wed, 16 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to management list LG History
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGListLGHistory : frmLGMaster
    {
        #region Global Variable
        //DTO & BUS
        clsLGBus m_LGBus = new clsLGBus();
        private clsLGListLGHistoryDTO lgListLGHistoryDto = new clsLGListLGHistoryDTO();
        private clsLGListLGHistoryBus lgListLGHistoryBus = new clsLGListLGHistoryBus();
        //Used for show/hidden [Delete] button
        private List<int> lstSelectedRows = new List<int>();
        // For Security Checking
        clsSEAuthorizer _security = null;

        //For List LG History
        //+ [colSeqLG] Column
        private const string m_colSeqLG = "colSeqLG";
        //+ [colLGNo] Column
        private const string m_colLGNo = "colLGNo";
        //+ [colMngCode] Column
        private const string m_colMngCode = "colMngCode";
        //+ [colPreviousLGNo] Column
        private const string m_colPreviousLGNo = "colPreviousLGNo";
        //+ [colType] Column
        private const string m_colType = "colType";
        //+ [colInputDate] Column
        private const string m_colInputDate = "colInputDate";
        //+ [colValueDate] Column
        private const string m_colValueDate = "colValueDate";
        //+ [colBackValue] Column
        private const string m_colBackValue = "colBackValue";
        //+ [colCustomerCode] Column
        private const string m_colCustomerCode = "colCustomerCode";
        //+ [colCustomerName] Column
        private const string m_colCustomerName = "colCustomerName";
        //+ [colGLCode] Column
        private const string m_colGLCode = "colGLCode";
        //+ [colClaim] Column
        private const string m_colClaim = "colClaim";
        //+ [colFeeRate] Column
        private const string m_colFeeRate = "colFeeRate";
        //+ [colMin] Column
        private const string m_colMin = "colMin";
        //+ [colMinCCY] Column
        private const string m_colMinCCY = "colMinCCY";
        //+ [colExpiryDate] Column
        private const string m_colExpiryDate = "colExpiryDate";
        //+ [colGuaranteeType] Column
        private const string m_colGuaranteeType = "colGuaranteeType";
        //+ [colBeneficiaryName] Column
        private const string m_colBeneficiaryName = "colBeneficiaryName";
        //+ [colTransCurrency] Column
        private const string m_colTransCurrency = "colTransCurrency";
        //+ [colChargeAccount] Column
        private const string m_colChargeAccount = "colChargeAccount";
        //+ [colGuaranteeAmount] Column
        private const string m_colGuaranteeAmount = "colGuaranteeAmount";
        //+ [colFee] Column
        private const string m_colFee = "colFee";
        //+ [colFeeCCY] Column
        private const string m_colFeeCurrency = "colFeeCCY";
        //+ [colMultiTimesFee] Column
        private const string m_colMultiTimesFee = "colMultiTimesFee";
        //+ [colOverdueFee] Column
        private const string m_colOverdueFee = "colOverdueFee";
        //+ [colOverdueFeeCCY] Column
        private const string m_colOverdueFeeCurrency = "colOverdueFeeCCY";
        //+ [colOverdueClaimFee] Column
        private const string m_colOverdueClaimFee = "colOverdueClaimFee";
        //+ [colOverdueClaimFeeCCY] Column
        private const string m_colOverdueClaimFeeCurrency = "colOverdueClaimFeeCCY";
        //2013.05.09 ADD HTK S Fix change request No.017 => Add new column: [Amend Update Fee]
        //+ [colOverdueClaimFee] Column
        private const string m_colAmendUpdatedFee = "colAmendUpdatedFee";
        //+ [colOverdueClaimFeeCCY] Column
        private const string m_colAmendUpdatedFeeCurrency = "colAmendUpdatedFeeCCY";
        //2013.05.09 ADD HTK E Fix change request No.017 => Add new column: [Amend Update Fee]
        //+ [colReportToSBV] Column
        private const string m_colReportToSBV = "colReportToSBV";

        private const string m_colTerminateDate = "colUpdatedDate";

        //Check Image        
        private System.Drawing.Image imgCheck = new Bitmap((System.Drawing.Image)Properties.Resources.ResourceManager.GetObject("Check"), new Size(16, 16));
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public frmLGListLGHistory()
        {
            try
            {
                InitializeComponent();

                // Check authorization
                _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);

                //Set Fom Style
                cbbLGType.SelectedIndexChanged -= new EventHandler(cbbLGType_SelectedIndexChanged);
                base.SetFormStyleCommon();
                base.MaximizeBox = true;
                //Not generate columns
                dtgLGList.AutoGenerateColumns = false;
                m_LGBus = new clsLGBus();
                //Fill data to comboboxes
                FillAllComboboxes();
                //Intialize
                Init();
                //LG Type Selected Index Changed
                cbbLGType.SelectedIndexChanged += new EventHandler(cbbLGType_SelectedIndexChanged);
				_security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }                       
        }
        #endregion

        #region Member Method
        /// <summary>
        /// Fill All Comboboxes
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void FillAllComboboxes()
        {
            //[LG Security] Combobox
            clsLGCommonFunction.FillComboboxData(m_LGBus.GetListLGSecurity, cbbSecurity);
            //[GL Code] Combobox
            clsLGCommonFunction.FillComboboxData(m_LGBus.GetListGLType, cbbGLCode);
            //[Currency] Combobox
            clsLGCommonFunction.FillComboboxData(m_LGBus.GetListCurrency, cbbCurrency);
            //[Guarantee Type] Combobox
            clsLGCommonFunction.FillComboboxData(m_LGBus.GetListGuaranteeType, cbbGuaranteeType);
            //[LG Type] Combobox
            clsLGCommonFunction.FillComboboxData(m_LGBus.GetListLGType, cbbLGType);
            
            //[Type] Combobox for Grid
            DataGridViewComboBoxColumn classificationColumn = (DataGridViewComboBoxColumn)dtgLGList.Columns[m_colType];
            classificationColumn.DataSource = m_LGBus.GetListLGStatus();
            classificationColumn.DisplayMember = "Display";
            classificationColumn.ValueMember = "Value";            
        }

        /// <summary>
        /// Init
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void Init()
        {
            //Numeric Controls
            txtAmountFrom.Text = String.Empty;
            txtAmountTo.Text = String.Empty;
            //DateTime Picker
            //+ For [Input Date]
            dtpInputDateFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            dtpInputDateTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            dtpInputDateFrom.Text = String.Empty;
            dtpInputDateTo.Text = String.Empty;
            //+ For [Value Date]
            dtpValueDateFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            dtpValueDateTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            dtpValueDateFrom.Text = String.Empty;
            dtpValueDateTo.Text = String.Empty;
            //+ For [Expire Date]
            dtpExpireDateFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            dtpExpireDateTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            dtpExpireDateFrom.Text = String.Empty;
            dtpExpireDateTo.Text = String.Empty;
            //Show/Hidden toolstrip
            ShowHiddenToolStrip();
        }

        /// <summary>
        /// Show Hidden Tool Strip
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void ShowHiddenToolStrip()
        {
            int index;
            bool isCloseTechnique = false;
            //Has at least one row chosen
            if (dtgLGList.Rows.Count > 0 && dtgLGList.SelectedRows.Count > 0)
            {
                index = dtgLGList.Rows.IndexOf(dtgLGList.SelectedRows[0]);
                //Invisable toolstrip [tsbPrintForm] for following cases:
                //+ Close Technique
                isCloseTechnique = (dtgLGList.Rows[index].Cells[m_colType].Value.ToString() == "5" ? true : false);

                tsbPrintForm.Visible = isCloseTechnique ? false : true;                
            }
            //Has no row chosen, Unhide following toolstripbuttons
            else
            {             
                tsbPrintForm.Visible = false;             
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void Search()
        {
            //Declaration
            lgListLGHistoryDto = new clsLGListLGHistoryDTO();
            List<DataGridViewRow> lstRows = new List<DataGridViewRow>();
            DataGridViewRow row = new DataGridViewRow();
            lstSelectedRows = new List<int>();
            dtgLGList.Rows.Clear();
            //Default Cell Style
            dtgLGList.Columns[m_colBackValue].DefaultCellStyle.NullValue = null;
            dtgLGList.Columns[m_colClaim].DefaultCellStyle.NullValue = null;
            dtgLGList.Columns[m_colReportToSBV].DefaultCellStyle.NullValue = null;
            //Assign value from inputting
            //+ LG No
            lgListLGHistoryDto.LGNo = txtLGNo.Text.Trim();            
            //+ Customer Code
            lgListLGHistoryDto.CustomerCode = txtCustomerCode.Text.Trim();
            //+ Customer Name
            lgListLGHistoryDto.CustomerName = txtCustomerName.Text.Trim();
            //+ Security
            lgListLGHistoryDto.Security = cbbSecurity.SelectedValue.ToString();
            //+ Booking purpose
            //2013.05.09 UPD HTK S Change [Booking Purpose] From CheckBox To ComboBox
            //lgListLGStaffDto.BookingPurpose = ckbBookingPurpose.Checked.ToString();
            lgListLGHistoryDto.BookingPurpose = cbbBookingPurpose.Text;
            //2013.05.09 UPD HTK E Change [Booking Purpose] From CheckBox To ComboBox
            //+ GL Code
            lgListLGHistoryDto.GLCode = cbbGLCode.Text.Trim();
            //+ Currency
            lgListLGHistoryDto.Currency = cbbCurrency.Text.Trim();
            //+ Claim
            lgListLGHistoryDto.Claim = cbbClaim.Text.ToString();
            //+ Input Date From
            lgListLGHistoryDto.InputDateFrom = dtpInputDateFrom.Text.Equals(String.Empty) ? DateTime.MinValue : dtpInputDateFrom.Value;
            //+ Input Date To
            lgListLGHistoryDto.InputDateTo = dtpInputDateTo.Text.Equals(String.Empty) ? DateTime.MinValue : dtpInputDateTo.Value;
            //+ Guarantee Type
            lgListLGHistoryDto.GuaranteeType = cbbGuaranteeType.Text.Trim();
            //+ Value Date From
            lgListLGHistoryDto.ValueDateFrom = dtpValueDateFrom.Text.Equals(String.Empty) ? DateTime.MinValue : dtpValueDateFrom.Value;
            //+ Value Date To
            lgListLGHistoryDto.ValueDateTo = dtpValueDateTo.Text.Equals(String.Empty) ? DateTime.MinValue : dtpValueDateTo.Value;
            //+ Expire Date From
            lgListLGHistoryDto.ExpireDateFrom = dtpExpireDateFrom.Text.Equals(String.Empty) ? DateTime.MinValue : dtpExpireDateFrom.Value;
            //+ Expire Date To
            lgListLGHistoryDto.ExpireDateTo = dtpExpireDateTo.Text.Equals(String.Empty) ? DateTime.MinValue : dtpExpireDateTo.Value;
            //+ Amount From
            lgListLGHistoryDto.AmountFrom = txtAmountFrom.Text.Trim();
            //+ Amount To
            lgListLGHistoryDto.AmountTo = txtAmountTo.Text.Trim();

            //Get data collection from database
            lgListLGHistoryBus.GetListLGHistory(ref lgListLGHistoryDto);
            //[Type] CheckBox
            List<string> lstType = new List<string>();
            if (ckbNewEntry.Checked)
            {
                lstType.Add("1");
            }
            if (ckbCorrect.Checked)
            {
                lstType.Add("2");
            }
            if (ckbAmendUpdate.Checked)
            {
                lstType.Add("3");
            }
            if (ckbAmend.Checked)
            {
                lstType.Add("4");
            }
            if (ckbCloseTechnique.Checked)
            {
                lstType.Add("5");
            }
            if (ckbTemination.Checked)
            {
                lstType.Add("6");
            }
            lgListLGHistoryDto.LstLGHistoryInformation = lgListLGHistoryDto.LstLGHistoryInformation.Where(x => lstType.Contains(x.Type)).ToList<LGHistoryInformation>();

           

            //Suppend Layout
            dtgLGList.SuspendLayout();
            dtgLGList.SelectionChanged -= new EventHandler(dtgLGList_SelectionChanged);
           
            //Set data collection to grid
            foreach (LGHistoryInformation objLGHistoryInfo in lgListLGHistoryDto.LstLGHistoryInformation)
            {
                row = new DataGridViewRow();
                row.CreateCells(dtgLGList);
                row.Cells[dtgLGList.Columns[m_colSeqLG].Index].Value = objLGHistoryInfo.SeqLG;
                row.Cells[dtgLGList.Columns[m_colLGNo].Index].Value = objLGHistoryInfo.LGNo;
                row.Cells[dtgLGList.Columns[m_colMngCode].Index].Value = objLGHistoryInfo.MngCode;
                row.Cells[dtgLGList.Columns[m_colPreviousLGNo].Index].Value = objLGHistoryInfo.PreviousLGNo;
                row.Cells[dtgLGList.Columns[m_colType].Index].Value = objLGHistoryInfo.Type;
                row.Cells[dtgLGList.Columns[m_colInputDate].Index].Value = objLGHistoryInfo.InputDate;
                row.Cells[dtgLGList.Columns[m_colValueDate].Index].Value = objLGHistoryInfo.ValueDate;
                row.Cells[dtgLGList.Columns[m_colBackValue].Index].Value = !objLGHistoryInfo.BackValue.Equals(String.Empty) ? imgCheck : null;
                row.Cells[dtgLGList.Columns[m_colCustomerCode].Index].Value = objLGHistoryInfo.CustomerCode;
                row.Cells[dtgLGList.Columns[m_colCustomerName].Index].Value = objLGHistoryInfo.CustomerName;
                row.Cells[dtgLGList.Columns[m_colGLCode].Index].Value = objLGHistoryInfo.GLCode;
                row.Cells[dtgLGList.Columns[m_colClaim].Index].Value = !objLGHistoryInfo.Claim.Equals(String.Empty) ? imgCheck : null;
                row.Cells[dtgLGList.Columns[m_colFeeRate].Index].Value = objLGHistoryInfo.FeeRate;
                //fix issues 17/6/2013
                if(objLGHistoryInfo.Type == "6")
                    row.Cells[dtgLGList.Columns[m_colTerminateDate].Index].Value = objLGHistoryInfo.TerminateDate;

                //+ Set Format (Currency)
                row.Cells[dtgLGList.Columns[m_colMinCCY].Index].Value = objLGHistoryInfo.MinCCY;
                if (row.Cells[dtgLGList.Columns[m_colMinCCY].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colMinCCY].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colMin].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colMin].Index].Value = objLGHistoryInfo.Min;
                row.Cells[dtgLGList.Columns[m_colExpiryDate].Index].Value = objLGHistoryInfo.ExpiryDate;
                row.Cells[dtgLGList.Columns[m_colGuaranteeType].Index].Value = objLGHistoryInfo.GuaranteeType;
                row.Cells[dtgLGList.Columns[m_colBeneficiaryName].Index].Value = objLGHistoryInfo.BeneficiaryName;
                row.Cells[dtgLGList.Columns[m_colTransCurrency].Index].Value = objLGHistoryInfo.TransCurrency;
                row.Cells[dtgLGList.Columns[m_colChargeAccount].Index].Value = objLGHistoryInfo.ChargeAccount;
                //+ Set Format (Currency)
                if (row.Cells[dtgLGList.Columns[m_colTransCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colTransCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colGuaranteeAmount].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colGuaranteeAmount].Index].Value = objLGHistoryInfo.GuaranteeAmount;
                //+ Set Format (Currency)
                row.Cells[dtgLGList.Columns[m_colFeeCurrency].Index].Value = objLGHistoryInfo.FeeCurrency;
                if (row.Cells[dtgLGList.Columns[m_colFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colFee].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colFee].Index].Value = objLGHistoryInfo.Fee;
                row.Cells[dtgLGList.Columns[m_colMultiTimesFee].Index].Value = objLGHistoryInfo.MultiTimesFee;
                //+ Set Format (Currency)
                row.Cells[dtgLGList.Columns[m_colOverdueFeeCurrency].Index].Value = objLGHistoryInfo.OverdueFeeCurrency;
                if (row.Cells[dtgLGList.Columns[m_colOverdueFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colOverdueFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colOverdueFee].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colOverdueFee].Index].Value = objLGHistoryInfo.OverdueFee;
                //+ Set Format (Currency)
                row.Cells[dtgLGList.Columns[m_colOverdueClaimFeeCurrency].Index].Value = objLGHistoryInfo.OverdueClaimFeeCurrency;
                if (row.Cells[dtgLGList.Columns[m_colOverdueClaimFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colOverdueClaimFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colOverdueClaimFee].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colOverdueClaimFee].Index].Value = objLGHistoryInfo.OverdueClaimFee;
                //2013.05.09 ADD HTK S Fix change request No.017 => Add new column: [Amend Update Fee]
                //+ Set Format (Currency)
                row.Cells[dtgLGList.Columns[m_colAmendUpdatedFeeCurrency].Index].Value = objLGHistoryInfo.AmendUpdatedFeeCurrency;
                if (row.Cells[dtgLGList.Columns[m_colAmendUpdatedFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_VND)
                    || row.Cells[dtgLGList.Columns[m_colAmendUpdatedFeeCurrency].Index].Value.ToString().Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    row.Cells[dtgLGList.Columns[m_colAmendUpdatedFee].Index].Style.Format = clsLGConstant.FORMAT_NUMBER_N;
                }
                //+ Set Value (Currency)
                row.Cells[dtgLGList.Columns[m_colAmendUpdatedFee].Index].Value = objLGHistoryInfo.AmendUpdatedFee;
                //2013.05.09 ADD HTK E Fix change request No.017 => Add new column: [Amend Update Fee]
                row.Cells[dtgLGList.Columns[m_colReportToSBV].Index].Value = int.Parse(objLGHistoryInfo.ReportToSBV) > 0 ? imgCheck : null;

                lstRows.Add(row);
            }               
           
            //Resume Layout
            dtgLGList.Rows.AddRange(lstRows.ToArray());
            dtgLGList.ResumeLayout();
            dtgLGList.SelectionChanged += new EventHandler(dtgLGList_SelectionChanged);

            //No records
            if (lgListLGHistoryDto.LstLGHistoryInformation.Count == 0)
            {
                clsLGMesageCollection.MessageNoTransactions();
            }

            //Show/Hidden toolstrip
            ShowHiddenToolStrip();
        }

        /// <summary>
        /// Override ProceeCmdKey
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>  
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                //+ [Print Form] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.P):
                    {
                        if (tsbPrintForm.Visible == true)
                        {
                            tsbPrintForm_Click(new object(), new EventArgs());
                        }
                        break;
                    }                
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        /// <summary>
        /// Processes a dialog box key.
        /// </summary>
        /// <param name="keyData"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        protected override bool ProcessDialogKey(Keys keyData)
        {
            switch (keyData)
            {
                //+ [Print Form] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.P):
                    {
                        break;
                    }      
                default:
                    {
                        return base.ProcessDialogKey(keyData);
                    }
            }

            return true;
        }
        #endregion

        #region Event Functions       
        /// <summary>
        /// Print Form event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbPrintForm_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgLGList.Rows.Count == 0)
                {
                    return;
                }
                DataGridViewRow dtr = dtgLGList.SelectedRows[0];
                clsLGPrintFormDTO dto = new clsLGPrintFormDTO();
                dto.SeqLG = int.Parse(dtr.Cells[m_colSeqLG].Value.ToString().Trim());
                dto.LGNo = dtr.Cells[m_colLGNo].Value.ToString();
                dto.LGType = dto.LGNo.Substring(0, 1);
                dto.LGStatus = dtr.Cells[m_colType].Value.ToString();
                dto.GuaranteeType = dtr.Cells[m_colGuaranteeType].Value.ToString();
                dto.ArrLGNo.Add(dto.LGNo);
                frmLGPrintForm frm = new frmLGPrintForm(dto.SeqLG, dto.ArrLGNo, dto.LGStatus, dto.LGType, dto.GuaranteeType);
                frm.StartPosition = FormStartPosition.CenterScreen;
                //2013.05.02 ADD HTK S Fix Feedback No.9 20130429 
                //frm.ShowDialog();
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
                //2013.05.02 ADD HTK E Fix Feedback No.9 20130429
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }        

        /// <summary>
        /// Search LG list to the input conditions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Search();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Selected index changed event of currency combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void cbbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //Set properties for TextBox [txtAmountFrom] & [txtAmountTo]
                if (cbbCurrency.Text.Equals(clsLGConstant.LG_CURRENCY_VND) || cbbCurrency.Text.Equals(clsLGConstant.LG_CURRENCY_JPY))
                {
                    //Do not allow to input decimal
                    //+ For [txtAmountFrom]
                    if (!txtAmountFrom.Text.Trim().Equals(String.Empty))
                    {
                        txtAmountFrom.NeedDecimal = false;
                        txtAmountFrom.StringFormat = "#,0";
                        txtAmountFrom.Refresh();
                    }
                    //+ For [txtAmountTo]
                    if (!txtAmountTo.Text.Trim().Equals(String.Empty))
                    {
                        txtAmountTo.NeedDecimal = false;
                        txtAmountTo.StringFormat = "#,0";
                        txtAmountTo.Refresh();
                    }
                }
                else
                {
                    //Do not allow to input decimal
                    //+ For [txtAmountFrom]
                    if (!txtAmountFrom.Text.Trim().Equals(String.Empty))
                    {
                        txtAmountFrom.NeedDecimal = true;
                        txtAmountFrom.StringFormat = clsLGConstant.FORMAT_DECIMAL;
                        txtAmountFrom.Refresh();
                    }
                    //+ For [txtAmountTo]
                    if (!txtAmountTo.Text.Trim().Equals(String.Empty))
                    {
                        txtAmountTo.NeedDecimal = true;
                        txtAmountTo.StringFormat = clsLGConstant.FORMAT_DECIMAL;
                        txtAmountTo.Refresh();
                    }
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// dtgLGList_SelectionChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void dtgLGList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                ShowHiddenToolStrip();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// btnExportToControllingBook Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnExportToControllingBook_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = clsLGMesageCollection.ShowMessage(3, String.Format(clsLGCommonMessage.CONFIRM_ACTION, btnExportToControllingBook.Text.Replace("&", String.Empty).ToLower(), String.Empty));
                if (result == DialogResult.Yes)
                {
                    if (cbbLGType.Text.Trim().Equals(String.Empty))
                    {
                        clsLGMesageCollection.ShowMessage(2, String.Format(clsLGCommonMessage.FIELD_REQUIRED, lblLGCategory.Text));
                        cbbLGType.Focus();
                        return;
                    }
                    frmLGReportControllingBook frm = new frmLGReportControllingBook(cbbLGType.SelectedValue.ToString(), txtSequenceFromCounter.Text, txtSequenceToCounter.Text);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.ShowDialog();
                    //Set value for [Max Number Printed] Textbox again
                    txtMaxNumberPrinted.Text = lgListLGHistoryBus.GetMaxNumberPrinted(cbbLGType.SelectedValue.ToString());                    
                }                
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// cbbLGType Selected Index Changed Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void cbbLGType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cbbLGType.Text.Trim().Equals(String.Empty))
                {
                    txtMaxNumberPrinted.Text = String.Empty;
                    txtSequenceFromCounter.Text = String.Empty;
                    txtSequenceToCounter.Text = String.Empty;
                }
                else
                {
                    txtMaxNumberPrinted.Text = lgListLGHistoryBus.GetMaxNumberPrinted(cbbLGType.SelectedValue.ToString());                    
                    txtSequenceToCounter.Text = lgListLGHistoryBus.GetTotalOfRowsNeedToPrint(cbbLGType.SelectedValue.ToString());
                    txtSequenceFromCounter.Text = !txtMaxNumberPrinted.Text.Equals(txtSequenceToCounter.Text) ?
                        (decimal.Parse(txtMaxNumberPrinted.Text) + 1).ToString(clsLGConstant.FORMAT_NUMBER_N) : txtSequenceToCounter.Text;
                }                
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }
        #endregion

        private void dtgLGList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frmLGListLGHistory_Load(object sender, EventArgs e)
        {

        }
    }
}