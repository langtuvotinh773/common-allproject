﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-05 14:29:30 +0700 (Thu, 03 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to list Fee Collection Schedule list
 * for LG module.
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Security.Com;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;
using UserCtrl;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGFeeCollectionSchedule : frmLGMaster
    {
        const string COL_RELATED_SUB_CODE_NAME = "colRelatedSubCode";
        const string COL_PRINCIPAL_CCY = "colPrincipalCCY";
        const string COL_SUGGESTED_FEE = "colSuggestedFee";
        Form m_Owner; // form which show "this"
        string m_ccy = "";// CCY add to columns in datagirnd
        string m_ChagreCCY = ""; // charge ccy add to column in datagrid
        public bool IsCorrect = true; // data correct and allow user  to create Fee
        decimal feeSuggest = 0;
        List<RowIndexObject> lstComboboxSubCode;
        List<DataGridViewRow> m_lstDeleteRow;
        int curIndex = -1;//index of combobox subcode current
        int oldIndex = -1;//previous index of combobox subcode
        bool returnIndex = false; // not change index of subcode

        bool isChange = false; // form have value change
        //List<RowIndexObject
        /// <summary>
        /// Constructor of Fee collection schedule list form
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public frmLGFeeCollectionSchedule()
        {
            InitializeComponent();
            this.Name = clsLGConstant.OVERDUE_COLLECTION_SCHEDULE;
            SetFormStyleCommon();
            SetFormStyle();
            _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            _security.CheckAuthorizationOnScreen(this);

        }

        public frmLGFeeCollectionSchedule(string lgNo)
        {

        }

        public frmLGFeeCollectionSchedule(DataGridView dt, Form owner, string bene, string customerName)
        {
            InitializeComponent();
            this.Name = clsLGConstant.OVERDUE_COLLECTION_SCHEDULE;
            SetFormStyleCommon();
            SetFormStyle();
            m_Owner = owner;
            txtBenificiary.Text = bene;
            txtCustomer.Text = customerName;
            lstComboboxSubCode = new List<RowIndexObject>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                RowIndexObject row = new RowIndexObject();
                row.Index = (string)dt.Rows[i].Cells[0].Value;
                row.Row = dt.Rows[i];
                if (dt.Rows[i].Cells["colDateOfActualCollection"].Value == null)
                    lstComboboxSubCode.Add(row);
            }
            if (lstComboboxSubCode.Count == dt.Rows.Count)
            {
                cbbSubCode.DataSource = lstComboboxSubCode;
                cbbSubCode.DisplayMember = "Index";
                cbbSubCode.ValueMember = "Index";
            }
            else IsCorrect = false;
            m_lstDeleteRow = new List<DataGridViewRow>();

            ((DataGridViewComboBoxColumn)dtgOCSchedule.Columns["colChargeCCY"]).DataSource = clsLGCommonBus.Instance().GetListCurrency();
            ((DataGridViewComboBoxColumn)dtgOCSchedule.Columns["colChargeCCY"]).DisplayMember = "Name";
            ((DataGridViewComboBoxColumn)dtgOCSchedule.Columns["colChargeCCY"]).ValueMember = "Value";

            if (dt.SelectedRows.Count > 0)
            {
                cbbSubCode.SelectedValue = dt.SelectedRows[0].Cells[0].Value.ToString();
            }

            for (int i = 0; i < dtgOCSchedule.Columns.Count; i++)
            {
                dtgOCSchedule.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;

            }

        }



        /// <summary>
        /// Set fornm style
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void SetFormStyle()
        {
            this.Text = clsLGConstant.LG_FEE_COLLECTION_SCHEDULE;

        }

        /// <summary>
        /// Close form event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Add a new item to datagridview event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnAdd_Click(object sender, EventArgs e)
        {
            int newSubNo = 0;

            try
            {
                newSubNo = (int)dtgOCSchedule.Rows[dtgOCSchedule.Rows.Count - 1].Cells["RealSubNo"].Value + 1;
            }
            catch { }
            //dtgOCSchedule.Rows.Add();

            dtgOCSchedule.Rows.Add(dtgOCSchedule.Rows.Count, null, null, null, ((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells[5].Value, m_ccy, null, null, null, null, CommonValue.ActionType.New, -1, newSubNo);
        }

        /// <summary>
        /// Delete an item on datagridview event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnSub_Click(object sender, EventArgs e)
        {
            if (dtgOCSchedule.Rows.Count > 0)
            {
                if ((CommonValue.ActionType)dtgOCSchedule.SelectedRows[0].Cells[10].Value == CommonValue.ActionType.None || (CommonValue.ActionType)dtgOCSchedule.SelectedRows[0].Cells[10].Value == CommonValue.ActionType.None)
                {
                    m_lstDeleteRow.Add(dtgOCSchedule.SelectedRows[0]);
                }
                dtgOCSchedule.Rows.Remove(dtgOCSchedule.SelectedRows[0]);
            }


        }

        /// <summary>
        /// Row added event on datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void dtgOCSchedule_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            dtgOCSchedule.Rows[dtgOCSchedule.Rows.Count - 1].Cells[0].Value = dtgOCSchedule.Rows.Count;
            isChange = true;
        }

        /// <summary>
        /// Row removed event on datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void dtgOCSchedule_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            for (int i = 0; i < dtgOCSchedule.Rows.Count; i++)
                this.dtgOCSchedule.Rows[i].Cells[0].Value = i + 1;
            isChange = true;
        }

        /// <summary>
        /// Save event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {

            //if (dtgOCSchedule.Rows.Count > 0)
            //{
            if (isChange == true)
            {
                DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.CONFIRM_ACTION, new string[] { "save", "Fee Collection Schedule" });
                if (result == DialogResult.Yes)
                {
                    string error = Save(cbbSubCode.SelectedValue.ToString());
                    if (error != "")
                    {
                        if (error != "None")

                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                    }
                    else
                    {
                        clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "Fee Collection Schedule" });
                    }
                }
            }
            //}
            //else
            //{
            //    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, "You must create at least 1 fee schedule !");
            //}
        }
        /// <summary>
        /// check valid date
        /// </summary>
        /// <returns></returns>
        bool CheckDate()
        {
            for (int i = 0; i < dtgOCSchedule.Rows.Count; i++)
            {
                if (dtgOCSchedule.Rows[i].Cells[3].Value != null && (DateTime)dtgOCSchedule.Rows[i].Cells[3].Value > clsLGCommonBus.Instance().GetServerDate())
                {
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.RECIEVE_CURRENT);
                    return false;

                }
                if (dtgOCSchedule.Rows[i].Cells[2].Value != null && (DateTime)dtgOCSchedule.Rows[i].Cells[2].Value < (DateTime)dtgOCSchedule.Rows[i].Cells[1].Value)
                {
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.ACTUAL_CLAIM);
                    return false;
                }
                try
                {
                    if (clsLGCommonBus.Instance().CheckBankingDate((DateTime)dtgOCSchedule.Rows[i].Cells["colClaimedDate"].Value, (string)dtgOCSchedule.Rows[i].Cells["colChargeCCY"].Value))
                    {
                        clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.CLAIM_BANKING);
                        return false;
                    }
                }
                catch { }
            }
            return true;
        }
        /// <summary>
        /// Save Data
        /// </summary>
        /// <param name="subCode">selected subcode</param>
        /// <returns></returns>
        private string Save(string subCode)
        {
            string error = "";
            if (CheckDate() == false)
            {
                return "None";
            }
            try
            {
                List<clsLGFeeScheduleDTO> lst = new List<clsLGFeeScheduleDTO>();
                string subcode = subCode;

                // ((frmLGMaster)m_Owner).m_LstFeeLog[cbbSubCode.SelectedIndex] = new List<clsLGLogBase>();
                for (int i = ((frmLGMaster)m_Owner).LstFeeSchedule.Count - 1; i >= 0; i--)
                {
                    if (((frmLGMaster)m_Owner).LstFeeSchedule[i].SubID == subcode)
                        ((frmLGMaster)m_Owner).LstFeeSchedule.RemoveAt(i);
                }
                for (int i = 0; i < dtgOCSchedule.Rows.Count; i++)
                {

                    int no = (int)dtgOCSchedule.Rows[i].Cells["RealSubNo"].Value;
                    //check claim date
                    if (dtgOCSchedule.Rows[i].Cells[1].Value == null)
                    {
                        error = "Claim Date";
                        dtgOCSchedule.CurrentCell = dtgOCSchedule.Rows[i].Cells["colClaimedDate"];
                        break;
                    }
                    DateTime claimDate = (DateTime)dtgOCSchedule.Rows[i].Cells[1].Value;
                    DateTime actualClaimDate;
                    //check  actual claim date
                    try
                    {
                        actualClaimDate = (DateTime)dtgOCSchedule.Rows[i].Cells[2].Value;
                    }
                    catch
                    {
                        actualClaimDate = DateTime.MinValue;
                    }
                    //check recieved date

                    DateTime receiveDate;
                    try
                    {
                        receiveDate = (DateTime)dtgOCSchedule.Rows[i].Cells[3].Value;
                    }
                    catch
                    {
                        receiveDate = DateTime.MinValue;
                    }
                    string pricipalCcy = dtgOCSchedule.Rows[i].Cells[5].Value.ToString();

                    //check ccy

                    string chargeCcy;
                    try
                    {
                        chargeCcy = dtgOCSchedule.Rows[i].Cells[6].Value.ToString();

                    }
                    catch
                    {
                        chargeCcy = "";
                    }
                    if (i == 0) m_ChagreCCY = chargeCcy;
                    else
                    {
                        if (m_ChagreCCY != chargeCcy)
                        {
                            error = "Charge CCY as same value";
                            break;
                        }
                    }
                    //rate

                    Decimal rate;
                    try
                    {
                        rate = Decimal.Parse(dtgOCSchedule.Rows[i].Cells[7].Value.ToString());
                    }
                    catch
                    {
                        rate = 0;
                    }

                    decimal fee = -1;
                    if (dtgOCSchedule.Rows[i].Cells[8].Value != null)
                        fee = decimal.Parse(dtgOCSchedule.Rows[i].Cells[8].Value.ToString());


                    if (error == "")
                    {
                        ((frmLGMaster)m_Owner).LstFeeSchedule.Add(new clsLGFeeScheduleDTO("", subcode, no, claimDate, actualClaimDate, receiveDate, pricipalCcy, chargeCcy, rate, fee, (CommonValue.ActionType)dtgOCSchedule.Rows[i].Cells[10].Value, (int)dtgOCSchedule.Rows[i].Cells[11].Value));
                        isChange = false;
                    }


                }
                for (int i = 0; i < m_lstDeleteRow.Count; i++)
                {
                    ((frmLGMaster)m_Owner).LstFeeSchedule.Add(new clsLGFeeScheduleDTO("", "", (int)m_lstDeleteRow[i].Cells[0].Value, DateTime.Now, DateTime.Now, DateTime.Now, "", "", 0, 0, CommonValue.ActionType.Delete, -1));
                }
                ((frmLGMaster)m_Owner).IsFeeChange = true;
            }
            catch (Exception ex)
            {
            }
            if (error == "") isChange = false;
            return error;
        }


        private void cbbSubCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 
            if (curIndex == cbbSubCode.SelectedIndex)
                return;//nothing change
            oldIndex = curIndex;
            curIndex = cbbSubCode.SelectedIndex;


            List<clsLGFeeScheduleDTO> existList = new List<clsLGFeeScheduleDTO>();
            for (int i = 0; i < ((frmLGMaster)m_Owner).LstFeeSchedule.Count; i++)
            {
                if (((frmLGMaster)m_Owner).LstFeeSchedule[i].SubID == ((RowIndexObject)cbbSubCode.SelectedItem).Index)
                    existList.Add(((frmLGMaster)m_Owner).LstFeeSchedule[i]);
            }

            if (returnIndex == false)
            {
                if (dtgOCSchedule.Rows.Count > 0)
                {
                    if (isChange == true)
                    {
                        DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.CONFIRM_SAVE_CHANGES);
                        if (result == DialogResult.Yes)
                        {
                            string error = Save(((RowIndexObject)cbbSubCode.Items[oldIndex]).Index);
                            if (error != "")
                            {
                                if (error != "None")
                                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                                returnIndex = true;
                                cbbSubCode.SelectedIndex = oldIndex;

                                return;

                            }
                            else
                            {
                                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "Fee Collection Schedule" });
                                dtgOCSchedule.Rows.Clear();
                                isChange = false;

                                m_ccy = ((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colCurrency"].Value.ToString();
                                feeSuggest = (decimal)((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colFeeSuggestion"].Value;
                                m_ChagreCCY = "";

                            }
                        }
                        if (result == DialogResult.Cancel)
                        {
                            returnIndex = true;
                            cbbSubCode.SelectedIndex = oldIndex;
                            return;
                        }
                        if (result == DialogResult.No)
                        {
                            if (existList.Count == 0)
                                dtgOCSchedule.Rows.Clear();
                            isChange = false;
                            m_ccy = ((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colCurrency"].Value.ToString();
                            feeSuggest = (decimal)((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colFeeSuggestion"].Value;
                        }

                    }
                    else
                    {
                        if (existList.Count == 0)
                            dtgOCSchedule.Rows.Clear();
                        isChange = false;
                        m_ccy = ((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colCurrency"].Value.ToString();
                        feeSuggest = (decimal)((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colFeeSuggestion"].Value;
                    }
                }
                else
                {
                    isChange = false;
                    m_ccy = ((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colCurrency"].Value.ToString();
                    feeSuggest = (decimal)((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colFeeSuggestion"].Value;
                }
                if (existList.Count == 0)
                {
                }
                else
                {
                    dtgOCSchedule.Rows.Clear();
                    for (int i = 0; i < existList.Count; i++)
                    {

                        dtgOCSchedule.Rows.Add(dtgOCSchedule.Rows.Count, existList[i].ClaimedDate, null, null, existList[i].SuggessedFee, m_ccy, existList[i].ChargeCCY, null, null, "", existList[i].Type, i, existList[i].No);
                        if (existList[i].ActualClaimedDate != DateTime.MinValue)
                            dtgOCSchedule.Rows[dtgOCSchedule.Rows.Count - 1].Cells[2].Value = existList[i].ActualClaimedDate;
                        if (existList[i].ReceivedDate != DateTime.MinValue)
                            dtgOCSchedule.Rows[dtgOCSchedule.Rows.Count - 1].Cells[3].Value = existList[i].ReceivedDate;
                        if (existList[i].ExchangeRate != (decimal)-1)
                            dtgOCSchedule.Rows[dtgOCSchedule.Rows.Count - 1].Cells[7].Value = existList[i].ExchangeRate;
                        if (existList[i].Fee != -1)
                        {
                            dtgOCSchedule.Rows[dtgOCSchedule.Rows.Count - 1].Cells[8].Value = existList[i].Fee;
                        }
                    }
                    isChange = false;
                }


            }
            else
                returnIndex = false;



        }
        /// <summary>
        /// handle when a cell in datagrid has value change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgOCSchedule_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            isChange = true;

            if ((e.ColumnIndex == 3 || e.ColumnIndex == 6) && e.RowIndex >= 0) // change claimdate or CCY
            {
                if (dtgOCSchedule.Rows[e.RowIndex].Cells[3].Value != null && dtgOCSchedule.Rows[e.RowIndex].Cells[6].Value != null)
                {
                    string ccypair = ""; // CCY pair
                    if (((frmLGMaster)m_Owner).m_LGType == ((byte)CommonValue.LGType.Proper).ToString())
                    {
                        ccypair = (string)((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colCurrency"].Value + "/" + (string)dtgOCSchedule.Rows[e.RowIndex].Cells[6].Value;
                    }
                    else
                    {
                        ccypair = (string)dtgOCSchedule.Rows[e.RowIndex].Cells[6].Value + "/" + (string)((RowIndexObject)cbbSubCode.SelectedItem).Row.Cells["colCurrency"].Value;
                    }
                    decimal rate = clsLGCommonBus.Instance().GetRate((DateTime)dtgOCSchedule.Rows[e.RowIndex].Cells[3].Value, ccypair);
                    if (rate != -1)
                        dtgOCSchedule.Rows[e.RowIndex].Cells[7].Value = rate;
                    else
                        clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.CANNOT_GET_RATE);
                }
            }
            if (e.ColumnIndex != 10 && e.RowIndex >= 0 && e.ColumnIndex != 0)
            {
                if ((CommonValue.ActionType)dtgOCSchedule.Rows[e.RowIndex].Cells[10].Value == CommonValue.ActionType.None)
                {
                    dtgOCSchedule.Rows[e.RowIndex].Cells[10].Value = CommonValue.ActionType.Update;
                }
            }

        }
        /// <summary>
        /// format cell in datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgOCSchedule_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 8) // format decimal part
            {
                if (dtgOCSchedule.Rows[e.RowIndex].Cells[6].Value != null)
                {
                    if ((string)dtgOCSchedule.Rows[e.RowIndex].Cells[6].Value == clsLGConstant.MAIN_CCY || (string)dtgOCSchedule.Rows[e.RowIndex].Cells[6].Value == clsLGConstant.LG_CURRENCY_JPY)
                    {
                        //e.CellStyle.Format = "n0";
                        ((TNumEditDataGridViewCell)dtgOCSchedule.Rows[e.RowIndex].Cells[e.ColumnIndex]).DecimalLength = 0;
                        ((TNumEditDataGridViewCell)dtgOCSchedule.Rows[e.RowIndex].Cells[e.ColumnIndex]).MaxInputLength = 10;
                    }
                    else
                    {
                        ((TNumEditDataGridViewCell)dtgOCSchedule.Rows[e.RowIndex].Cells[e.ColumnIndex]).DecimalLength = 2;
                        ((TNumEditDataGridViewCell)dtgOCSchedule.Rows[e.RowIndex].Cells[e.ColumnIndex]).MaxInputLength = 13;
                    }
                }
            }
            //dtgOCSchedule.NotifyCurrentCellDirty(true);
        }

        private void frmLGFeeCollectionSchedule_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isChange == true)
            {
                DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.CONFIRM_ACTION, new string[] { "save", "" });
                if (result == DialogResult.Yes)
                {
                    string error = Save(cbbSubCode.SelectedValue.ToString());
                    if (error != "")
                    {
                        if (error != "None")

                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                    }
                    else
                    {
                        clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "Fee Collection Schedule" });
                    }
                }
                if (result == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
            }
        }




    }
    /// <summary>
    /// this class use in combobox SubCode : index + datagridview row
    /// </summary>
    public class RowIndexObject
    {
        private string index;

        public string Index
        {
            get { return index; }
            set { index = value; }
        }

        private DataGridViewRow row;

        public DataGridViewRow Row
        {
            get { return row; }
            set { row = value; }
        }
        public RowIndexObject()
        {

        }
    }
}