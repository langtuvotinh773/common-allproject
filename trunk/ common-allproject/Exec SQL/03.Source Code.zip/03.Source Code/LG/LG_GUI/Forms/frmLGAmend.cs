﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-05 14:29:30 +0700 (Thu, 03 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to amend coorect update LG
 * for LG module.
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.MasterData.Com;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dal;
using Phoenix.Lg.Dto;
using UserCtrl;
using Phoenix.Common.Security.Com;
using Phoenix.Common.Smile.Obj;
using Phoenix.Common.Smile.Gui;
using Phoenix.Common.Smile.Com;
using DataEncryption;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGAmend : frmLGMaster
    {
        const string COL_FEE_SUGGESTION = "colFeeSuggestion";
        const string COL_TRANSIENT_ACCOUNT = "colTransientAccount";
        const string COL_CHARGE_ACCOUNT = "colChargeAccount";
        //readonly background
        Color READ_ONLY_COLUMN_BACKGROUND = Config.Classes.clsCommonStyles.Instance().DGVReadOnlyColumnBG;
        //initial back color
        Color INITIAL_BACK_COLOR;

         string DEFAULT_MINRATE_CCY =  Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["MinRateCCY"].ToString());
         decimal DEFAULT_MINRATE_AMOUNT = decimal.Parse(Encryption.decrypt(System.Configuration.ConfigurationSettings.AppSettings["MinRateAmount"].ToString()));
        //selection fore color
       // public List<clsLGFeeScheduleDTO> LstFeeSchedule;
        clsLGBus m_LGBus = null;
        LG data;
        string m_LGNo = "";
        string m_SeqLG = "";
        string m_LGStatus = "";
        //string m_LGType = "";
        ArrayList m_arr;
        string m_Guarantee = "";

        List<string> m_DeleteDetails;
        CommonValue.LGAction m_Action;// action of LG : Amend, correct, amend update
        bool m_isSaveClick = false; // click button save or not
        int m_subCodeIncreate = 0;// in case amend LG, increate subcode
        List<ParameterDTO> m_lstCCY; // list CCY
        AmendFee m_amendFee;
        /// <summary>
        /// Constructor of Amend form
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public frmLGAmend(string input, CommonValue.LGAction action)
        {
            InitializeComponent();
           
            INITIAL_BACK_COLOR = dtgLGList.DefaultCellStyle.BackColor;
            
            m_Action = action;
            try
            {
                m_lstCCY = new List<ParameterDTO>();
                m_lstCCY = clsLGCommonBus.Instance().GetListCurrency();
                m_LGNo = input.Remove(6);
                data = clsLGMasterBus.GetLG(m_LGNo);
                //init list fee schedule collection
                LstFeeSchedule = new List<clsLGFeeScheduleDTO>();
                //set common style for form
                SetFormStyleCommon();
                SetFormStyle();
                //init LG bus
                m_LGBus = new clsLGBus();
                FillComboboxData();
                //init list detail is deleted
                m_DeleteDetails = new List<string>();
               
                // get LG no from input
               
                //get data for this LG
               

                FillData(data);
                GetInitValue();
                // init list log 
                m_ListLogs = new List<clsLGLogBase>();
                // get list Fee
                for (int i = 0; i < data.LstDetail.Count; i++)
                    LstFeeSchedule.AddRange(data.LstDetail[i].LstFeeSchedule);
                _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);


                if (radStandard.Checked == true)
                {

                    cbbCurrency.Enabled = false;
                    txtOrther.Enabled = false;
                    txtOrther.Text = "";
                    cbbCurrency.SelectedIndex = -1;
                }
                else
                {
                    cbbCurrency.Enabled = radOthers.Enabled;
                    txtOrther.Enabled = radOthers.Enabled;
                }

            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Calculate value when form shown
        /// </summary>
        /// <param name="e"></param>
        protected override void OnShown(EventArgs e)
        {
            ReCalculateValue();
            base.OnShown(e);
        }

        /// <summary>
        /// Save old value at initial form
        /// </summary>
        DateTime m_oldExpireTime;
        DateTime m_oldInputDate;
        DateTime m_oldValueDate;
        string m_oldCustomerCode;
        bool m_oldStndard;
        decimal m_oldMinRateAmount;
        string m_oldCCY;
        int m_oldBeneficiary;
        int m_oldApplicant;
        string m_oldGuarantee;
        string m_oldCalculateType;
        string m_oldRate;
        bool m_oldBookingPurpose;
        string m_oldContractInfo;
        string m_oldRepresentation1;
        string m_oldRepresentation2;
        string m_oldRepresentation3;
        string m_oldRemark;
        bool m_oldSecurity;
        List<clsLGLogBase> m_ListLogs;
        clsLGLogBase logBase = new clsLGLogBase(); 

        // Quan Add 20130510 -------------->
        private List<object> objList = null;
        private clsErrorLogDto SmileErrorLog = null;
        private frmLGPrintForm m_frmPrintForm = null;
        // <-------------------------------

        void GetInitValue()
        {
            m_oldInputDate = dtpInputDate.Value;
            m_oldValueDate = dtpValueDate.Value;
            m_oldExpireTime = dtpExpireDate.Value;
            m_oldCustomerCode = ((clsLGCustomerDTO)cbbCustomerCode.SelectedItem).CustomerCode;
            m_oldStndard = radStandard.Checked;
            if(radStandard.Checked)
            {
                m_oldMinRateAmount = DEFAULT_MINRATE_AMOUNT;
                m_oldCCY = DEFAULT_MINRATE_CCY;
            }
            else
            {
                m_oldMinRateAmount = decimal.Parse(txtOrther.Text.Replace(",",""));

                m_oldCCY = ((ParameterDTO)cbbCurrency.SelectedItem).Name;
    
            }
            m_oldBeneficiary = int.Parse((string)cbbBeneficiary.SelectedValue);
            try
            {
                if (cbbLGCategory.SelectedValue.ToString() == "2")
                    m_oldApplicant = int.Parse((string)cbbApplicant.SelectedValue);
            }
            catch { }
            m_oldGuarantee = ((ParameterDTO)cbbGuaranteeType.SelectedItem).Value;
            m_oldCalculateType = ((ParameterDTO)cbbCalculateType.SelectedItem).Value;
            m_oldRate = txtLGRate.Text;
            m_oldBookingPurpose = ckbBookingPurpose.Checked;
            m_oldContractInfo = txtContractInformation.Text;
            m_oldRepresentation1 = txtRepresentation1.Text;
            m_oldRepresentation2 = txtRepresentation2.Text;
            m_oldRepresentation3 = txtRepresentation3.Text;
            m_oldRemark = txtRemark.Text;
            m_oldSecurity = !radFledgeDeposit.Checked;

        }
        /// <summary>
        /// check change value and take history
        /// </summary>
        /// <returns></returns>
        bool CheckChangeValue()
        {
            dtgLGList.EndEdit();
            if (m_Action == CommonValue.LGAction.Amend)
            {
                for (int i = 0; i < dtgLGList.Rows.Count; i++)
                {
                    if ((CommonValue.ActionType)dtgLGList.Rows[i].Cells["Type"].Value == CommonValue.ActionType.None)
                        dtgLGList.Rows[i].Cells["Type"].Value = CommonValue.ActionType.Update;
                }
            }
            decimal minAmount = DEFAULT_MINRATE_AMOUNT;
            string ccy = DEFAULT_MINRATE_CCY;
            if (!radStandard.Checked)
            {
                try
                {
                    minAmount = decimal.Parse(txtOrther.Text.Replace(",", ""));

                    ccy = ((ParameterDTO)cbbCurrency.SelectedItem).Name;
                }
                catch { }
            }
            //check master data change???
            if (m_oldValueDate == dtpValueDate.Value &&
                m_oldCustomerCode == ((clsLGCustomerDTO)cbbCustomerCode.SelectedItem).CustomerCode &&
                m_oldStndard == radStandard.Checked &&  
                m_oldCCY == ccy &&
                m_oldMinRateAmount == minAmount &&
            m_oldExpireTime == dtpExpireDate.Value &&
            m_oldBeneficiary.ToString() == (string)cbbBeneficiary.SelectedValue &&
            (cbbApplicant.Visible == false || m_oldApplicant.ToString() ==(string)cbbApplicant.SelectedValue) &&
            m_oldGuarantee == ((ParameterDTO)cbbGuaranteeType.SelectedItem).Value &&
            m_oldCalculateType == ((ParameterDTO)cbbCalculateType.SelectedItem).Value &&
            m_oldRate == txtLGRate.Text &&
            m_oldBookingPurpose == ckbBookingPurpose.Checked &&
            m_oldContractInfo == txtContractInformation.Text &&
            m_oldRepresentation1 == txtRepresentation1.Text &&
            m_oldRepresentation2 == txtRepresentation2.Text &&
            m_oldRepresentation3 == txtRepresentation3.Text &&
            m_oldRemark == txtRemark.Text &&
            m_oldSecurity == !radFledgeDeposit.Checked)
            {

                //check datagrid data change??
                for (int i = 0; i < dtgLGList.Rows.Count; i++)
                {
                    if ((CommonValue.ActionType)dtgLGList.Rows[i].Cells["Type"].Value == CommonValue.ActionType.New)
                    {
                        break;
                    }
                    int relateIndex = (int)dtgLGList.Rows[i].Cells["oldSubCode"].Value;
                    if (dtgLGList.Rows[i].Cells["colCurrency"].Value.ToString() != data.LstDetail[relateIndex].Detail.TransCurrency ||
                        (decimal)dtgLGList.Rows[i].Cells["colAmount"].Value != data.LstDetail[relateIndex].Detail.TransAmount ||
                        (bool)dtgLGList.Rows[i].Cells["colTransientAccount"].Value != data.LstDetail[relateIndex].Detail.TransientAccount ||
                        (dtgLGList.Rows[i].Cells["colChargeAccount"].Value == null || dtgLGList.Rows[i].Cells["colChargeAccount"].Value.ToString() != data.LstDetail[relateIndex].Detail.ChargeCurrency + "-" + data.LstDetail[i].Detail.ChargeAccount) ||
                        (decimal)dtgLGList.Rows[i].Cells["colFee"].Value != data.LstDetail[relateIndex].Detail.Fee ||
                        dtgLGList.Rows[i].Cells["colFeeCurrency"].Value.ToString() != data.LstDetail[relateIndex].Detail.FeeCurrency ||
                       ((dtgLGList.Rows[i].Cells["colDateOfActualCollection"].Value == null && data.LstDetail[relateIndex].Detail.ActualCollectionDate != DateTime.MinValue) || (dtgLGList.Rows[i].Cells["colDateOfActualCollection"].Value != null && (DateTime)dtgLGList.Rows[i].Cells["colDateOfActualCollection"].Value != data.LstDetail[relateIndex].Detail.ActualCollectionDate)))
                    {
                        break;
                    }
                    if (i == dtgLGList.Rows.Count - 1)
                    {
                        if(IsFeeChange == false)
                            return false;
                    }

                }

               // return false;
            }

            logBase.ApplicationName = this.Text;
            logBase.Action = (int)CommonValue.ActionType.Update;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Key = data.Master.LgCode;
            logBase.Module = clsLGConstant.LG_MODULE;
            if (m_oldCCY != ccy)
            {
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = "Min Rate CCY",
                    OldValue = m_oldCCY,
                    NewValue = ccy
                }); 
            }
            if (m_oldMinRateAmount != minAmount)
            {
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName ="Min Rate Amount",
                    OldValue = m_oldMinRateAmount.ToString(),
                    NewValue = minAmount.ToString()
                }); 
            }

            if (m_oldValueDate != dtpValueDate.Value)
            {
                logBase.LstLogInformation.Add(new clsLGLogInformation
                {

                    FieldName = lblValueDate.Text,
                    OldValue = m_oldValueDate.ToString(),
                    NewValue = dtpValueDate.Value.ToString()
                }); 
            }
                  if (m_oldExpireTime != dtpExpireDate.Value)
                {

                    logBase.LstLogInformation.Add(new clsLGLogInformation
                    {

                        FieldName = lblExpireDate.Text,
                        OldValue = m_oldExpireTime.ToString(),
                        NewValue = dtpExpireDate.Value.ToString()
                    }); 
                }
                try
                {
                    if (m_oldBeneficiary != int.Parse((string)cbbBeneficiary.SelectedValue))
                    {

                        logBase.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = lblBeneficiary.Text,
                            OldValue = m_oldBeneficiary.ToString(),
                            NewValue = (string)cbbBeneficiary.Text
                        }); 
                    }
                }
                catch { }

                try
                {
                    if ((cbbApplicant.Visible != false && m_oldApplicant != int.Parse((string)cbbApplicant.SelectedValue)))
                    {

                        logBase.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = lblApplicantName.Text,
                            OldValue = m_oldApplicant.ToString(),
                            NewValue = (string)cbbApplicant.Text
                        }); 
                    }
                }
                catch { }
                try
                {
                    if (m_oldGuarantee != ((ParameterDTO)cbbGuaranteeType.SelectedItem).Value)
                    {

                        logBase.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = lblGuaranteeType.Text,
                            OldValue = m_oldGuarantee,
                            NewValue = ((ParameterDTO)cbbGuaranteeType.SelectedItem).Value
                        }); 
                    }
                }
                catch { }
                try
                {
                    if (m_oldCalculateType != ((ParameterDTO)cbbCalculateType.SelectedItem).Value)
                    {


                        logBase.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = lblCalculateType.Text,
                            OldValue = m_oldCalculateType,
                            NewValue = ((ParameterDTO)cbbCalculateType.SelectedItem).Value
                        }); 
                    }
                }
                catch { }
                if (m_oldRate != txtLGRate.Text)
                {


                    logBase.LstLogInformation.Add(new clsLGLogInformation
                    {

                        FieldName = lblLGRate.Text,
                        OldValue = m_oldRate,
                        NewValue = txtLGRate.Text
                    }); 
                }
                try
                {
                    if (m_oldBookingPurpose != ckbBookingPurpose.Checked)
                    {


                        logBase.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = lblBookingPurpose.Text,
                            OldValue = m_oldBookingPurpose.ToString(),
                            NewValue = ckbBookingPurpose.Checked.ToString()
                        }); 
                    }
                }
                catch { }
                try
                {
                    if (m_oldContractInfo != txtContractInformation.Text)
                    {


                        logBase.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = lblContractInformation.Text,
                            OldValue = m_oldContractInfo,
                            NewValue = txtContractInformation.Text
                        }); 
                    }
                }
                catch { }
                try
                {
                    if (m_oldRepresentation1 != txtRepresentation1.Text)
                    {


                        logBase.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = lblRepresentation1.Text,
                            OldValue = m_oldRepresentation1,
                            NewValue = txtRepresentation1.Text
                        }); 
                    }
                }
                catch { }
                try
                {
                    if (m_oldRepresentation2 != txtRepresentation2.Text)
                    {


                        logBase.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = lblRepresentation2.Text,
                            OldValue = m_oldRepresentation2,
                            NewValue = txtRepresentation2.Text
                        }); 
                    }
                }
                catch { }
                if (m_oldRepresentation3 != txtRepresentation3.Text)
                {


                    logBase.LstLogInformation.Add(new clsLGLogInformation
                    {

                        FieldName = lblRepresentation3.Text,
                        OldValue = m_oldRepresentation3,
                        NewValue = txtRepresentation3.Text
                    }); 
                }
                if (m_oldRemark != txtRemark.Text)
                {

                    logBase.LstLogInformation.Add(new clsLGLogInformation
                    {

                        FieldName = lblRemark.Text,
                        OldValue = m_oldRemark,
                        NewValue = txtRemark.Text
                    }); 
                }
            if(logBase.LstLogInformation.Count > 0)
                m_ListLogs.Add(logBase);
                for (int i = 0; i < dtgLGList.Rows.Count; i++) // log detail
                {
                    clsLGLogBase log = new clsLGLogBase();
                    log.ApplicationName = this.Text;
                    log.Key = data.Master.LgCode + " " + dtgLGList.Rows[i].Cells[0].Value.ToString();
                    log.UserID = clsUserInfo.UserNo.ToString();
                    if ((CommonValue.ActionType)dtgLGList.Rows[i].Cells["Type"].Value == CommonValue.ActionType.Update)
                    {
                        int j = (int)dtgLGList.Rows[i].Cells["OldSubCode"].Value;

                        log.Action = (int)CommonValue.ActionType.Update;
                        if (int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString()) + m_subCodeIncreate != int.Parse(data.LstDetail[j].Detail.SubCode))
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[0].HeaderText,
                                OldValue = data.LstDetail[j].Detail.SubCode,
                                NewValue = (int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString()) + m_subCodeIncreate).ToString("00")
                            });
                        }
                        if (dtgLGList.Rows[i].Cells["colCurrency"].Value.ToString() != data.LstDetail[j].Detail.TransCurrency)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[1].HeaderText,
                                OldValue = data.LstDetail[j].Detail.TransCurrency,
                                NewValue = dtgLGList.Rows[i].Cells[1].Value.ToString()
                            });
                        }
                        if ((decimal)dtgLGList.Rows[i].Cells["colAmount"].Value != data.LstDetail[j].Detail.TransAmount)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName =dtgLGList.Columns[2].HeaderText,
                                OldValue = data.LstDetail[j].Detail.TransAmount.ToString(),
                                NewValue = dtgLGList.Rows[i].Cells[2].Value.ToString()
                            });
                        }
                        if ((bool)dtgLGList.Rows[i].Cells["colTransientAccount"].Value != data.LstDetail[j].Detail.TransientAccount)
                        {
                            ;
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName =dtgLGList.Columns[3].HeaderText,
                                OldValue = data.LstDetail[j].Detail.TransientAccount.ToString(),
                                NewValue = dtgLGList.Rows[i].Cells[3].Value.ToString()
                            });
                        }

                        try // try to bget charge account , if exception occur, it will be show later
                        {
                            if (dtgLGList.Rows[i].Cells["colChargeAccount"].Value.ToString() != data.LstDetail[j].Detail.ChargeCurrency + "-" + data.LstDetail[i].Detail.ChargeAccount)
                            {
                                log.LstLogInformation.Add(new clsLGLogInformation
                                {

                                    FieldName = "Charge CCY",
                                    OldValue = data.LstDetail[j].Detail.ChargeCurrency,
                                    NewValue = dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(3)
                                });
                                log.LstLogInformation.Add(new clsLGLogInformation
                                {

                                    FieldName = dtgLGList.Columns[4].HeaderText,
                                    OldValue = data.LstDetail[i].Detail.ChargeAccount,
                                    NewValue = dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(0, 4)
                                });

                            }
                        }
                        catch { }
                        if ((decimal)dtgLGList.Rows[i].Cells["colFee"].Value != data.LstDetail[j].Detail.Fee)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[6].HeaderText,
                                OldValue = data.LstDetail[j].Detail.Fee.ToString(),
                                NewValue = dtgLGList.Rows[i].Cells[6].Value.ToString()
                            });
                        }
                        string feeCCY = dtgLGList.Rows[i].Cells["colFeeCurrency"].Value.ToString();
                        if (dtgLGList.Rows[i].Cells["colDateOfActualCollection"].Value == null)
                        {
                            feeCCY = "";
                        }
                        if (feeCCY != data.LstDetail[j].Detail.FeeCurrency)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName =dtgLGList.Columns[7].HeaderText,
                                OldValue = data.LstDetail[j].Detail.FeeCurrency,
                                NewValue = feeCCY
                            });
                        }
                        if ((dtgLGList.Rows[i].Cells["colDateOfActualCollection"].Value != null && (DateTime)dtgLGList.Rows[j].Cells["colDateOfActualCollection"].Value != data.LstDetail[i].Detail.ActualCollectionDate))
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName =dtgLGList.Columns[8].HeaderText,
                                OldValue = data.LstDetail[i].Detail.ActualCollectionDate.ToString(),
                                NewValue = dtgLGList.Rows[i].Cells[8].Value.ToString()
                            });
                        }
                        m_ListLogs.Add(log);
                    }
                    

                    //log when insert new
                    if ((CommonValue.ActionType)dtgLGList.Rows[i].Cells["Type"].Value == CommonValue.ActionType.New)
                    {
                        log.Action = (int)CommonValue.ActionType.New;
                        try
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Flag Controling Book",
                                OldValue = String.Empty,
                                NewValue = "0"
                            });
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[1].HeaderText,
                                OldValue = String.Empty,
                                NewValue = dtgLGList.Rows[i].Cells[1].Value.ToString()
                            });

                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[2].HeaderText,
                                OldValue = String.Empty,
                                NewValue = dtgLGList.Rows[i].Cells[2].Value.ToString()
                            });

                            if (dtgLGList.Rows[i].Cells[3].Value == null)
                                dtgLGList.Rows[i].Cells[3].Value = false;


                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[3].HeaderText,
                                OldValue = String.Empty,
                                NewValue = dtgLGList.Rows[i].Cells[3].Value.ToString()
                            });

                            try // try to get chargeacccount, if exception occur, it will be show later
                            {
                                log.LstLogInformation.Add(new clsLGLogInformation
                                {

                                    FieldName = "Charge CCY",
                                    OldValue = String.Empty,
                                    NewValue = dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(3)
                                });

                                log.LstLogInformation.Add(new clsLGLogInformation
                                {

                                    FieldName = dtgLGList.Columns[4].HeaderText,
                                    OldValue = String.Empty,
                                    NewValue = dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(0, 4)
                                });
                            }
                            catch { }
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[8].HeaderText,
                                OldValue = String.Empty,
                                NewValue = dtgLGList.Rows[i].Cells[8].Value.ToString()
                            });


                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[6].HeaderText,
                                OldValue = String.Empty,
                                NewValue = dtgLGList.Rows[i].Cells[6].Value.ToString()
                            });
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = dtgLGList.Columns[7].HeaderText,
                                OldValue = String.Empty,
                                NewValue = dtgLGList.Rows[i].Cells[7].Value.ToString()
                            });
                        }
                        catch { }
                        m_ListLogs.Add(log);
                    }

                   

                }
                if (m_DeleteDetails.Count > 0) // log deleted detail
                {
                    for (int i = 0; i < m_DeleteDetails.Count; i++)
                    {
                        clsLGLogBase log = new clsLGLogBase();
                        log.ApplicationName = this.Text;
                        log.Action = (int)CommonValue.ActionType.Delete;
                        log.UserID = clsUserInfo.UserNo.ToString();
                        log.Key = data.Master.LgCode + " " + m_DeleteDetails[i];
                        m_ListLogs.Add(log);
                    }
                }

                // log fee when there are some Changing Fee Schedule 
                for (int i = 0; i < LstFeeSchedule.Count; i++)
                {
                    if (LstFeeSchedule[i].Type == CommonValue.ActionType.New)
                    {
                        clsLGLogBase log = new clsLGLogBase();
                        log.ApplicationName = this.Text;
                        log.Action = (int)CommonValue.ActionType.New;
                        log.UserID = clsUserInfo.UserNo.ToString();
                        log.Key = data.Master.LgCode + " " + LstFeeSchedule[i].SubID + " " + LstFeeSchedule[i].No;
                        log.LstLogInformation.Add(new clsLGLogInformation
                        {

                            FieldName = "Claim Date",
                            OldValue = String.Empty,
                            NewValue = LstFeeSchedule[i].ClaimedDate.ToString()
                        });
                        if (LstFeeSchedule[i].ActualClaimedDate != DateTime.MinValue)
                        {

                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Actual Claim Date",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].ActualClaimedDate.ToString()
                            });
                        }
                        
                        if (LstFeeSchedule[i].ReceivedDate != DateTime.MinValue)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Receive Date",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].ReceivedDate.ToString()
                            });
                        }

                        if (LstFeeSchedule[i].ChargeCCY != "")
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Charge CCY",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].ChargeCCY.ToString()
                            });
                        }

                        if (LstFeeSchedule[i].ExchangeRate != -1)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Exchange Rate",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].ExchangeRate.ToString()
                            });
                        }

                        if (LstFeeSchedule[i].Fee != -1)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Fee",
                                OldValue = String.Empty,
                                NewValue = LstFeeSchedule[i].Fee.ToString()
                            });
                        }
                        m_ListLogs.Add(log);
                    }
                    if (LstFeeSchedule[i].Type == CommonValue.ActionType.Update)
                    {
                        LGDetail detail = data.LstDetail.Find(delegate (LGDetail dk)
                        {
                            return dk.Detail.SubCode == LstFeeSchedule[i].SubID;
                        });

                        clsLGFeeScheduleDTO fee = detail.LstFeeSchedule[LstFeeSchedule[i].OldSubNo];
                        clsLGLogBase log = new clsLGLogBase();
                        log.ApplicationName = this.Text;
                        log.Action = (int)CommonValue.ActionType.Update;
                        log.UserID = clsUserInfo.UserNo.ToString();
                        log.Key = data.Master.LgCode + " " + LstFeeSchedule[i].SubID + " " + LstFeeSchedule[i].No;
                        if (LstFeeSchedule[i].ClaimedDate != fee.ClaimedDate)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Claim Date",
                                OldValue = fee.ClaimedDate.ToString(), 
                                NewValue = LstFeeSchedule[i].ClaimedDate.ToString()
                            });
                        }
                        if (LstFeeSchedule[i].ActualClaimedDate != fee.ActualClaimedDate)
                        {

                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Actual Claim Date",
                                OldValue = fee.ActualClaimedDate.ToString(),
                                NewValue = LstFeeSchedule[i].ActualClaimedDate.ToString()
                            });
                        }

                        if (LstFeeSchedule[i].ReceivedDate != fee.ReceivedDate)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Receive Date",
                                OldValue = fee.ReceivedDate.ToString(),
                                NewValue = LstFeeSchedule[i].ReceivedDate.ToString()
                            });
                        }

                        if (LstFeeSchedule[i].ChargeCCY != fee.ChargeCCY)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Charge CCY",
                                OldValue = fee.ChargeCCY,
                                NewValue = LstFeeSchedule[i].ChargeCCY.ToString()
                            });
                        }

                        if (LstFeeSchedule[i].ExchangeRate != fee.ExchangeRate)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Exchange Rate",
                                OldValue = fee.ExchangeRate.ToString(),
                                NewValue = LstFeeSchedule[i].ExchangeRate.ToString()
                            });
                        }

                        if (LstFeeSchedule[i].Fee != fee.Fee)
                        {
                            log.LstLogInformation.Add(new clsLGLogInformation
                            {

                                FieldName = "Fee",
                                OldValue = fee.Fee.ToString(),
                                NewValue = LstFeeSchedule[i].Fee.ToString()
                            });
                        }
                        m_ListLogs.Add(log);
                    }
                    if (LstFeeSchedule[i].Type == CommonValue.ActionType.Delete)
                    {
                        clsLGLogBase log = new clsLGLogBase();
                        log.ApplicationName = this.Text;
                        log.Action = (int)CommonValue.ActionType.Delete;
                        log.UserID = clsUserInfo.UserNo.ToString();
                        log.Key = data.Master.LgCode + " " + LstFeeSchedule[i].SubID + " " + LstFeeSchedule[i].No;
                        m_ListLogs.Add(log);
                    }
                }
                return true;
            

        }

        /// <summary>
        /// Fill data to screen
        /// </summary>
        /// <param name="data"></param>
        void FillData(LG data)
        {
            cbbLGCategory.SelectedValue = data.Master.LgType.ToString();
            txtGLCode.Text = data.Master.GlCode;
            txtTranNo.Text = txtLGNo.Text = data.Master.LgCode;
            cbbCustomerCode.SelectedValue = data.Master.CustomerCode;
            dtpInputDate.Value = data.Master.InputDate;
            dtpExpireDate.Value = data.Master.ExpireDate;
            dtpValueDate.Value = data.Master.ValueDate;
            txtRepresentation1.Text = data.Master.Representation1;
            txtRepresentation2.Text = data.Master.Representation2;
            txtRepresentation3.Text = data.Master.Representation3;
            txtRemark.Text = data.Master.Remark;
            txtContractInformation.Text = data.Master.ContractInfo;
            cbLGAllowed.Checked = data.Master.Allowed;
            if (data.Master.LgSecurity == true)
            {
                radCleanBasis.Checked = true;
            }
            else
            {
                radFledgeDeposit.Checked = true;
            }

            ckbBookingPurpose.Checked = data.Master.BookPurpose;
            radStandard.Checked = !data.Master.MinRateStandard;
            if (!radStandard.Checked)
            {
                radOthers.Checked = true;
                txtOrther.Text = data.Master.MinRateAmount.ToString();
                cbbCurrency.Text = data.Master.MinRateCurrency;
            }

            txtLGRate.Text = data.Master.LgRate.ToString("0.00000");
            cbbBeneficiary.SelectedValue = data.Master.SeqBenificiary.ToString();
            cbbApplicant.SelectedValue = data.Master.SeqApplicant.ToString();
            cbbGuaranteeType.SelectedValue = data.Master.GuaranteeType;
            cbbCalculateType.SelectedValue = data.Master.CalculateType;
            LstFeeSchedule = new List<clsLGFeeScheduleDTO>();
            //fill LG detail to datagrid
            for (int i = 0; i < data.LstDetail.Count; i++)
            {
                DataGridViewComboBoxCell cell = new DataGridViewComboBoxCell();
                cell.Items.Add(data.LstDetail[i].Detail.TransCurrency);
                cell.Value = data.LstDetail[i].Detail.TransCurrency;
                if ((string)cbbLGCategory.SelectedValue == ((int)CommonValue.LGType.Proper).ToString()) // if LG Type is proper
                {
                    dtgLGList.Rows.Add(data.LstDetail[i].Detail.SubCode,
                       data.LstDetail[i].Detail.TransCurrency, data.LstDetail[i].Detail.TransAmount,
                        data.LstDetail[i].Detail.TransientAccount, data.LstDetail[i].Detail.ChargeCurrency + "-" + data.LstDetail[i].Detail.ChargeAccount.Trim(),
                        0, data.LstDetail[i].Detail.Fee, data.LstDetail[i].Detail.FeeCurrency, data.LstDetail[i].Detail.ActualCollectionDate,CommonValue.ActionType.None,i);
                }
                else // if LG type is counter
                {

                    dtgLGList.Rows.Add(data.LstDetail[i].Detail.SubCode,
                    data.LstDetail[i].Detail.TransCurrency, data.LstDetail[i].Detail.TransAmount,
                     data.LstDetail[i].Detail.TransientAccount, null,
                     0, data.LstDetail[i].Detail.Fee, data.LstDetail[i].Detail.FeeCurrency, data.LstDetail[i].Detail.ActualCollectionDate, CommonValue.ActionType.None, i);
                    DataGridViewComboBoxCell combo = this.dtgLGList[4, i] as DataGridViewComboBoxCell;
                    List<clsLGAccountInfoDTO> lst = new List<clsLGAccountInfoDTO>();
                    lst.Add(new clsLGAccountInfoDTO(data.LstDetail[i].Detail.ChargeCurrency + "-"+data.LstDetail[i].Detail.ChargeAccount.Trim(),data.LstDetail[i].Detail.ChargeCurrency + "-"+ data.LstDetail[i].Detail.ChargeAccount.Trim()));
                     combo.DataSource = lst;

                     combo.DisplayMember = "AccountNo";
                     combo.ValueMember = "AccountNo";
                     dtgLGList.Rows[i].Cells[4].Value =data.LstDetail[i].Detail.ChargeCurrency + "-"+ data.LstDetail[i].Detail.ChargeAccount.Trim();

                    
                }
                if (LstFeeSchedule.Count > 0)
                {
                    
                    dtgLGList.Columns["colDateOfActualCollection"].ReadOnly = true;
                }
                if (data.LstDetail[i].Detail.ActualCollectionDate == DateTime.MinValue)
                {
                    dtgLGList.Rows[i].Cells[8].Value = null;
                }
                
            }
            if(m_Action == CommonValue.LGAction.Amend)
                    m_subCodeIncreate = data.LstDetail.Count; // increate subcode when amend, in another case increate subcode = 0
        }
        /// <summary>
        /// Fill combobox data
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void FillComboboxData()
        {
            cbbLGCategory.DataSource = clsLGCommonBus.Instance().LstLGCategory;
            cbbLGCategory.DisplayMember = "Name";
            cbbLGCategory.ValueMember = "Value";
            cbbLGCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cbbGuaranteeType.DataSource = clsLGCommonBus.Instance().GetListLGGuarantee();
            cbbGuaranteeType.DisplayMember = "Name";
            cbbGuaranteeType.ValueMember = "Value";
            cbbGuaranteeType.DropDownStyle = ComboBoxStyle.DropDownList;

            cbbCalculateType.DataSource = clsLGCommonBus.Instance().GetListLGCalculateType();
            cbbCalculateType.DisplayMember = "Name";
            cbbCalculateType.ValueMember = "Value";
            cbbCalculateType.DropDownStyle = ComboBoxStyle.DropDownList;

            cbbCurrency.DataSource = clsLGCommonBus.Instance().GetListCurrency();
            cbbCurrency.DisplayMember = "Name";
            cbbCurrency.ValueMember = "Value";
            cbbCurrency.DropDownStyle = ComboBoxStyle.DropDownList;




            new clsLGBus().GetListBeneficiaryForCombobox(cbbBeneficiary);
            new clsLGBus().GetListApplicantForCombobox(cbbApplicant);

        }

      
      

        /// <summary>
        /// Load form in proper mode
        /// </summary>
        /// <param name="isShow">isShow: these control is shown or not</param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void LoadFormWithProper(bool isShow)
        {
            lblApplicantName.Visible = isShow;
            cbbApplicant.Visible = isShow;
            btnAddApplicant.Visible = isShow;
        }

        /// <summary>
        /// Set controls's style
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void SetFormStyle()
        {
            this.Text = "Amend LG";
            cbbLGCategory.Enabled = false;
            dtpInputDate.Enabled = false;
            dtpValueDate.Enabled = false;
            //dtpValueDate.Enabled = true;
            cbbCustomerCode.Enabled = false;
            cbbCustomerName.Enabled = false;

            cbbBeneficiary.Enabled = false;
            btnAddBeneficiary.Enabled = false;
            cbbApplicant.Enabled = false;
            btnAddApplicant.Enabled = false;
            cbbGuaranteeType.Enabled = false;
            //radOthers.Enabled = false;
            //radStandard.Enabled = false;
            txtContractInformation.Enabled = false;
            txtRepresentation1.Enabled = false;
            txtRepresentation2.Enabled = false;
            btnCreate.Visible = false;
            txtRepresentation3.Enabled = false;

            radFledgeDeposit.Enabled = false;
            radCleanBasis.Enabled = false;
            ckbBookingPurpose.Enabled = false;
            radStandard.Checked = true;
            cbbCurrency.Enabled = false;


            cbLGAllowed.Enabled = false;
            //txtOrther.Enabled = false;
            //txtRemark.Enabled = false;
            if (m_Action == CommonValue.LGAction.AmendUpdate || m_Action == CommonValue.LGAction.Correct)
            {
                if (m_Action == CommonValue.LGAction.AmendUpdate)
                {
                    for (int i = 0; i < dtgLGList.Columns.Count; i++)
                    {
                        dtgLGList.Columns[i].ReadOnly = true;
                        
                        dtgLGList.Columns[i].DefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
                    }
                }
                this.Text = "Amend (Update) LG";
                txtLGRate.Enabled = false;
                dtpExpireDate.Enabled = false;
                cbbBeneficiary.Enabled = true;
                btnAddBeneficiary.Enabled = true;
                cbbApplicant.Enabled = true;
                btnAddApplicant.Enabled = true;
                txtContractInformation.Enabled = true;
                txtRepresentation1.Enabled = true;
                radStandard.Enabled = false;
                radOthers.Enabled = false;
                txtRepresentation2.Enabled = true;
                txtRepresentation3.Enabled = true;
                txtRemark.Enabled = true;
                dtgLGList.StandardTab = true;
                btnAmendFee.Visible = true;
                if (m_Action == CommonValue.LGAction.Correct)
                {
                    this.Text = "Correct LG";
                  //  dtpInputDate.Enabled = true;
                    dtpValueDate.Enabled = true;
                    dtpExpireDate.Enabled = true;
                    cbbCustomerCode.Enabled = true;
                    txtLGRate.Enabled = true;
                    radOthers.Enabled = true;
                    btnCreate.Visible = true;
                    radStandard.Enabled = true;
                    btnAddBeneficiary.Enabled = true;
                  // cbbApplicant.Enabled = false;
                    btnAddApplicant.Enabled = true;
                    btnCreate.Enabled = true;
                    btnAdd.Enabled = true;
                    btnRemove.Enabled = true;
                    radFledgeDeposit.Enabled = true;
                    radCleanBasis.Enabled = true;
                    cbbGuaranteeType.Enabled = true;
                    ckbBookingPurpose.Enabled = true;
                    radStandard.Enabled = true;
                    radOthers.Enabled = true;
                    dtgLGList.StandardTab = false;
                    btnAmendFee.Visible = false;
                    btnUpdate.Visible = true;
                                        
                }

            }


            txtOrther.Text = "";
            cbbCustomerCode.DropDownStyle = ComboBoxStyle.DropDown;
            cbbCustomerName.DropDownStyle = ComboBoxStyle.DropDown;
            //cbbCurrency.SelectedIndex = -1;

            #region MAX LENGTH
            txtGLCode.MaxLength = clsLGConstant.LENGTH_GL_CODE;
            txtLGRate.MaxLength = clsLGConstant.LENGTH_LG_RATE;
            txtContractInformation.MaxLength = clsLGConstant.LENGTH_CONTRACT_INFORMATION;
            txtRepresentation1.MaxLength = clsLGConstant.LENGTH_REPRESENTATION_1;
            txtRepresentation2.MaxLength = clsLGConstant.LENGTH_REPRESENTATION_2;
            txtRepresentation3.MaxLength = clsLGConstant.LENGTH_REPRESENTATION_3;
            txtRemark.MaxLength = clsLGConstant.LENGTH_REMARK;
            #endregion


            ((DataGridViewComboBoxColumn)dtgLGList.Columns[1]).DataSource = clsLGCommonBus.Instance().GetListCurrency();
            ((DataGridViewComboBoxColumn)dtgLGList.Columns[1]).DisplayMember = "Name";
            ((DataGridViewComboBoxColumn)dtgLGList.Columns[1]).ValueMember = "Value";


            ((DataGridViewComboBoxColumn)dtgLGList.Columns[7]).DataSource = clsLGCommonBus.Instance().GetListCurrency();
            ((DataGridViewComboBoxColumn)dtgLGList.Columns[7]).DisplayMember = "Name";
            ((DataGridViewComboBoxColumn)dtgLGList.Columns[7]).ValueMember = "Value";

            txtLGRate.LostFocus += new EventHandler(txtLGRate_LostFocus);
        }

        void txtLGRate_LostFocus(object sender, EventArgs e)
        {
            if (txtLGRate.Text != "")
            {
                if (decimal.Parse(txtLGRate.Text) > 2)
                {
                    txtLGRate.Focus();


                    txtLGRate.Text = "";
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.LGRATE_LESS_THAN);

                }
                else
                {
                    if (decimal.Parse(txtLGRate.Text) < 0)
                    {
                        txtLGRate.Focus();


                        txtLGRate.Text = "";
                        clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.LGRATE_GREATE_THAN);

                    }
                }

            }

        }

        /// <summary>
        /// Add to LG list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnAdd_Click(object sender, EventArgs e)
        {
            dtgLGList.Rows.Add(dtgLGList.Rows.Count.ToString("00"), null, null, false, null, null, null, null, null,CommonValue.ActionType.New,null);
        }



       

        /// <summary>
        /// Add an applicant
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnApplicantAdd_Click(object sender, EventArgs e)
        {
            frmLGCreateApplicant frm = new frmLGCreateApplicant();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
            int i = cbbApplicant.SelectedIndex;
            new clsLGBus().GetListApplicantForComboboxReLoad(cbbApplicant);
            if (frm.NewApplicant != "")
            {
                int index = cbbApplicant.FindString(frm.NewApplicant);
                cbbApplicant.SelectedIndex = index;
            }
            else
            {
                cbbApplicant.SelectedIndex = i;
            }
        }

        /// <summary>
        /// Close form event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Standard radio checked changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void radStandard_CheckedChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (radStandard.Checked == true)
                {

                    cbbCurrency.Enabled = false;
                    txtOrther.Enabled = false;
                    txtOrther.Text = "";
                    cbbCurrency.SelectedIndex = -1;
                }
                else
                {
                    cbbCurrency.Enabled = true;
                    txtOrther.Enabled = true;
                }
            }
        }

        /// <summary>
        /// Selection changed event on datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void cbbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetCurrencyFormat(cbbCurrency, txtOrther);
        }

        private void btnAddBeneficiary_Click(object sender, EventArgs e)
        {

            frmLGCreateBeneficiary frm = new frmLGCreateBeneficiary();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
            int i = cbbBeneficiary.SelectedIndex;
            new clsLGBus().GetListBeneficiaryForComboboxReload(cbbBeneficiary);
            if (frm.NewBeneficiary != "")
            {
                int index = cbbBeneficiary.FindString(frm.NewBeneficiary);
                cbbBeneficiary.SelectedIndex = index;
            }
            else
            {
                cbbBeneficiary.SelectedIndex = i;
            }
        }



        private void cbbLGCategory_SelectedValueChanged(object sender, EventArgs e)
        {
            //get LG type
            m_LGType = cbbLGCategory.SelectedValue.ToString();
            if (cbbLGCategory.Items.Count <= 0)
                return;
            // init screen base on LG type
            if (((ParameterDTO)cbbLGCategory.SelectedItem).Value == "1")
            {
                LoadFormWithProper(false);
               
                txtGLCode.Text = clsLGConstant.LG_CATEGORY_PROPER;
                //dtgLGList.Columns[3].ReadOnly = false;
                //dtgLGList.Columns[3].DefaultCellStyle.BackColor = Color.White;
            }
            else if (((ParameterDTO)cbbLGCategory.SelectedItem).Value == "2")
            {
                LoadFormWithProper(true);
               
                txtGLCode.Text = clsLGConstant.LG_CATEGORY_COUNTER;
                //dtgLGList.Columns[3].ReadOnly = true;
                //dtgLGList.Columns[3].DefaultCellStyle.BackColor = dtgLGList.Columns[3].DefaultCellStyle.BackColor = clsCommonStyles.Instance().DGVReadOnlyColumnBG;
            }
            //get list customer code base on LG type
            cbbCustomerCode.DataSource = clsLGCommonBus.Instance().GetListCustomerByLGType(((ParameterDTO)cbbLGCategory.SelectedItem).Value);
            cbbCustomerCode.DisplayMember = "CustomerCode";
            cbbCustomerCode.ValueMember = "CustomerCode";
        }

        bool returnCustomerCode = false;
        private void cbbCustomerCode_SelectedValueChanged(object sender, EventArgs e)
        {
            if (returnCustomerCode == false)
            {
                if (this.Visible == true)
                {

                    DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm, clsLGCommonMessage.CHANGE_CUSTOMER_CONFIRM);
                    if (result == DialogResult.Yes)
                    {
                        SetCustomerName();
                        dtgLGList.Columns["colDateOfActualCollection"].ReadOnly = false;
                    }
                    else
                    {
                        returnCustomerCode = true;
                        cbbCustomerCode.SelectedValue = data.Master.CustomerCode;
                    }

                }
                else
                {
                    SetCustomerName();
                }
            }
            else
                returnCustomerCode = false;
        }

        /// <summary>
        /// Set name base on customer code
        /// </summary>
        private void SetCustomerName()
        {
            for (int i = 0; i < dtgLGList.Rows.Count; i++)
            {
                if ((CommonValue.ActionType)dtgLGList.Rows[i].Cells["Type"].Value == CommonValue.ActionType.None || (CommonValue.ActionType)dtgLGList.Rows[i].Cells["Type"].Value == CommonValue.ActionType.Update)
                {
                    m_DeleteDetails.Add(data.Master.LgCode + "-" + dtgLGList.Rows[i].Cells[0].Value.ToString());
                }
            }
            //clear list detail when customer code change
            dtgLGList.Rows.Clear();
            //clear list fee 
            LstFeeSchedule.Clear();
            
            cbbCustomerName.Text = ((clsLGCustomerDTO)cbbCustomerCode.SelectedItem).CustomerName;
            //when LG type = proper
            if (cbbLGCategory.SelectedIndex == 0)
            {

                clsLGIssueBus bus = new clsLGIssueBus();
                List<clsLGAccountInfoDTO> lst = bus.GetListAccount(((clsLGCustomerDTO)cbbCustomerCode.SelectedItem).CustomerCode);
                for (int i = 0; i < data.LstDetail.Count; i++)
                {
                    clsLGAccountInfoDTO acc = new clsLGAccountInfoDTO( data.LstDetail[i].Detail.ChargeAccount, data.LstDetail[i].Detail.ChargeCurrency);
                    acc.AccountNo = acc.Ccy + "-" + acc.AccountNo;
                    if (!lst.Exists(delegate (clsLGAccountInfoDTO dk){
                        return dk.AccountNo == acc.AccountNo;
                    }))
                    {
                        lst.Add(acc);
                    }
                }
                ((DataGridViewComboBoxColumn)dtgLGList.Columns[4]).DataSource = lst;
                ((DataGridViewComboBoxColumn)dtgLGList.Columns[4]).DisplayMember = "AccountNo";
                ((DataGridViewComboBoxColumn)dtgLGList.Columns[4]).ValueMember = "AccountNo";

            }

        }

       

        private void btnSave_Click(object sender, EventArgs e)
        {
           
            try
            {  
                // if have not changed value then return and do nothing
                if (CheckChangeValue() == false) return;
                // if have some value changed value -> confirm with user 
                DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.CONFIRM_ACTION, new string[] { "save", "LG" });
                if (result == DialogResult.Yes) // yes - > save action
                {
                    string error = Save();
                    if (error != "")
                    {
                        if (error != "None") // already show message in CheckDate funtion
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                    }
                    else
                    {
                        clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "LG" });

                        // Prepare data before importing into Smile
                        PrepareSmileObject();

                        CWorker worker = new CWorker(Run, Complete);
                        worker.Start();
                        m_isSaveClick = true;
                        this.Close();
                    }
                }
                if (result == DialogResult.No) // no : not save
                {
                    m_isSaveClick = true;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        private void PrepareSmileObject()
        {
            if (m_Action == CommonValue.LGAction.Amend)
            {
                // Phong will build a list of macro for amending LG(terminal, new issue and general transfer if any)
                LG newdata = clsLGMasterBus.GetLG(m_LGNo);
                objList = new List<object>();
                for (int i = 0; i < data.LstDetail.Count; i++)
                {
                    //terminate
                    clsLGOSETDto dto = new clsLGOSETDto();
                    //dto.Value = data.Master.ValueDate.ToString("yyMMdd");//value date
                    dto.Value = clsSmileCommon.ConvertToSmileDate(data.Master.ValueDate);
                    dto.Customer = data.Master.CustomerCode;
                    dto.Ccy = data.LstDetail[i].Detail.TransCurrency;
                    dto.GL1 = data.Master.GlCode.Substring(0, 3);
                    dto.GL2 = data.Master.GlCode.Substring(4, 4);
                    dto.Trans1 = data.Master.LgCode;
                    dto.Trans2 = data.LstDetail[i].Detail.SubCode;
                    dto.MacroType = MacroType.LGOSET;
                    dto.ImportType = ImportType.LGTerminate;
                    objList.Add(dto);

                }
                for (int i = 0; i < newdata.LstDetail.Count; i++)
                {

                    // LG Issue
                    clsLGONEWDto dto1 = new clsLGONEWDto();
                    dto1.Page1Issue = clsSmileCommon.ConvertToSmileDate(data.Master.ValueDate);
                    dto1.Page1Effective = dto1.Page1Issue;
                    dto1.Page1Customer = newdata.Master.CustomerCode;
                    dto1.Page1Ccy = newdata.LstDetail[i].Detail.TransCurrency;
                    dto1.Page1GL1 = newdata.Master.GlCode.Substring(0, 3);
                    dto1.Page1GL2 = newdata.Master.GlCode.Substring(4, 4);
                    dto1.Page1Trans1 = newdata.Master.LgCode;
                    dto1.Page1Trans2 = newdata.LstDetail[i].Detail.SubCode;
                    if (clsLGCommonBus.Instance().MainCCYList.Contains(newdata.LstDetail[i].Detail.TransCurrency))
                    {
                        dto1.Page2Trans = newdata.LstDetail[i].Detail.TransAmount.ToString("#,0");
                    }
                    else
                    {
                        dto1.Page2Trans = newdata.LstDetail[i].Detail.TransAmount.ToString("#,0.00");
                    }
                    dto1.Page2Exp = clsSmileCommon.ConvertToSmileDate(newdata.Master.ExpireDate);

                    dto1.Page2GuaranteeType = newdata.Master.GuaranteeType;
                    dto1.Page2FeeRate = newdata.Master.LgRate.ToString();
                    dto1.Page2Adj = newdata.Master.CalculateType;
                    if (!newdata.Master.MinRateStandard)
                        dto1.Page2Minimum = "Y";
                    else
                        dto1.Page2Minimum = "";
                    if (data.Master.LgType == 1)
                    {
                        dto1.Page2CHGAC1 = newdata.LstDetail[i].Detail.ChargeCurrency;
                        dto1.Page2CHGAC2 = "511";
                        dto1.Page2CHGAC3 = "3000";
                        //double d = double.Parse(newdata.LstDetail[i].Detail.ChargeAccount);
                        //dto1.Page2CHGAC4 = Math.Truncate(d).ToString();
                        dto1.Page2CHGAC4 = newdata.LstDetail[i].Detail.ChargeAccount;
                    }
                    else
                    {
                        dto1.Page2CHGAC1 = newdata.LstDetail[i].Detail.ChargeCurrency;
                        dto1.Page2CHGAC2 = "310";
                        dto1.Page2CHGAC3 = "1000";
                        dto1.Page2CHGAC4 = "000019";
                    }
                    dto1.Page2Bene = ((CbbObject)cbbBeneficiary.SelectedItem).Display;

                    // cbbBeneficiary.SelectedItem
                    dto1.MacroType = MacroType.LGONEW;
                    dto1.ImportType = ImportType.LGIssue;
                    objList.Add(dto1);
                }

                SmileErrorLog = new clsErrorLogDto();
                SmileErrorLog.Module = Module.LG.ToString();
                SmileErrorLog.TransNo = newdata.Master.LgCode;
                SmileErrorLog.ImportType = ImportType.LGAmend;
                SmileErrorLog.ImportBy = clsUserInfo.UserName;
            }

            m_frmPrintForm = new frmLGPrintForm(int.Parse(m_SeqLG), m_arr, m_LGStatus, m_LGType, m_Guarantee);
            if (m_Action == CommonValue.LGAction.Amend)
                m_frmPrintForm.AllowImportSmile = true;
            else
                m_frmPrintForm.AllowImportSmile = false;
            m_frmPrintForm.MacroList = objList;
            m_frmPrintForm.SmileLogInfo = SmileErrorLog;
            m_frmPrintForm.Tag = MdiParent;
        }

        private string Update()
        {
            dtgLGList.EndEdit();
            if (CheckDate() == false) return "None"; // already show message in CheckDate funtion
            clsDataAccessLayer dal = new clsDataAccessLayer();
            string error = "";
            try
            {
                clsLGIssueBus bus = new clsLGIssueBus();
                int lgType = int.Parse(cbbLGCategory.SelectedValue.ToString());

                m_LGNo = data.Master.LgCode;




               // string glCode = txtGLCode.Text;
                DateTime valueDate = dtpValueDate.Value;
                DateTime inputDate = dtpInputDate.Value;
                DateTime expireDate = dtpExpireDate.Value;
                string customerCode = cbbCustomerCode.Text;
                if (customerCode == "")
                {
                    error = lblCustomerCode.Text;
                    cbbCustomerCode.Focus();
                    throw new System.ArgumentException("");
                }

                int beneficiaryCode = -1;
                try
                {
                    beneficiaryCode = int.Parse((string)cbbBeneficiary.SelectedValue);
                }
                catch { }
                if (beneficiaryCode == -1)
                {
                    error = lblBeneficiary.Text;
                    cbbBeneficiary.Focus();
                    throw new System.ArgumentException("");
                }

                int applicantCode = -1;
                try
                {
                    applicantCode = int.Parse((string)cbbApplicant.SelectedValue);
                }
                catch { }
                if (cbbApplicant.Visible == true && applicantCode == -1)
                {
                    error = lblApplicantName.Text;
                    cbbApplicant.Focus();
                    throw new System.ArgumentException("");
                }

                string contractInfo = txtContractInformation.Text;

                string representation1 = txtRepresentation1.Text;
                string representation2 = txtRepresentation2.Text;
                string representation3 = txtRepresentation3.Text;

                if ((string)cbbGuaranteeType.SelectedValue == "")
                {
                    error = lblGuaranteeType.Text;
                    cbbGuaranteeType.Focus();
                    throw new System.ArgumentException("");
                }
                string guaranteeType = (string)cbbGuaranteeType.SelectedValue;

                if ((string)cbbCalculateType.SelectedValue == "")
                {

                    cbbCalculateType.Focus();
                    error = lblCalculateType.Text;
                    throw new System.ArgumentException("");
                }
                string calculateType = (string)cbbCalculateType.SelectedValue;

                if (txtLGRate.Text == "")
                {
                    error = lblLGRate.Text;
                    txtLGRate.Focus();
                    throw new System.ArgumentException("");
                }
                decimal lgRate = decimal.Parse(txtLGRate.Text);


                bool lgSecurity = true;
                if (radFledgeDeposit.Checked)
                {
                    lgSecurity = false;
                }
                bool bookPurpose = ckbBookingPurpose.Checked;
                bool minRateStandard = false; // 0 : Standart
                decimal minRateAmount = DEFAULT_MINRATE_AMOUNT;
                string minRateCurrency = DEFAULT_MINRATE_CCY;
                if (radOthers.Checked)
                {
                    minRateStandard = true; // 1 : Orther
                    if (txtOrther.Text == "")
                    {
                        error = "Minimun Rate Amount";
                        txtOrther.Focus();
                        throw new System.ArgumentException("");
                    }
                    minRateAmount = decimal.Parse(txtOrther.Text);


                    minRateCurrency = (string)cbbCurrency.SelectedValue;
                    if (minRateCurrency == "")
                    {
                        error = "Minimun Rate Currency";
                        cbbCurrency.Focus();
                        throw new System.ArgumentException("");
                    }

                }
                string remark = txtRemark.Text;
   

                SqlParameter[] parameters = new SqlParameter[20];
                parameters[0] = new SqlParameter("@seq", data.Master.SeqLG);
                parameters[1] = new SqlParameter("@ValueDate", valueDate);


                parameters[2] = new SqlParameter("@ExpireDate", expireDate);
                parameters[3] = new SqlParameter("@CustomerCode", customerCode);
                parameters[4] = new SqlParameter("@SeqBeneficiary", beneficiaryCode);
                if (applicantCode != -1)
                    parameters[5] = new SqlParameter("@SeqApplicant", applicantCode);
                else parameters[5] = new SqlParameter("@SeqApplicant", DBNull.Value);
                parameters[6] = new SqlParameter("@ContractInformation", contractInfo);
                parameters[7] = new SqlParameter("@Representation1", representation1);
                parameters[8] = new SqlParameter("@Representation2", representation2);
                parameters[9] = new SqlParameter("@Representation3", representation3);
                parameters[10] = new SqlParameter("@GuaranteeType", guaranteeType);
                parameters[11] = new SqlParameter("@CalculateType", calculateType);
                parameters[12] = new SqlParameter("@LGRate", lgRate);
                parameters[13] = new SqlParameter("@LGSecurity", lgSecurity);
                parameters[14] = new SqlParameter("@BookPurpose", bookPurpose);
                parameters[15] = new SqlParameter("@MinRateStandard", minRateStandard);
                parameters[16] = new SqlParameter("@MinRateAmount", minRateAmount);
                parameters[17] = new SqlParameter("@Remark", remark);
                parameters[18] = new SqlParameter("@MinRateCurrency", minRateCurrency);
                int id = 0;
                parameters[19] = new SqlParameter("@out", id);
                parameters[19].Direction = ParameterDirection.Output;
                dal.ExecuteNonQueryOutString("dbo.spLG_UpdateLGMaster", CommandType.StoredProcedure, parameters, "@out");
               
               


                dal.ClearParameter();

                //if (m_amendFee != null)
                //{
                //    parameters = new SqlParameter[7];
                //    parameters[0] = new SqlParameter("@seq", m_SeqLG);
                //    parameters[1] = new SqlParameter("@flatFee", m_amendFee.FlatFee);
                //    parameters[2] = new SqlParameter("@rate", m_amendFee.ExchangeRate);
                //    parameters[3] = new SqlParameter("@account", m_amendFee.Account);
                //    parameters[4] = new SqlParameter("@ccy", m_amendFee.CCY);
                //    parameters[5] = new SqlParameter("@amendFee", m_amendFee.Fee);
                //    parameters[6] = new SqlParameter("@out", id);
                //    parameters[6].Direction = ParameterDirection.InputOutput;
                //    dal.ExecuteNonQueryOutString("dbo.spLG_UpdateAmendFee", CommandType.StoredProcedure, parameters, "@out");
                //}

                if (dtgLGList.Rows.Count == 0)
                {
                    error = "LG Detail";
                    //  cbbCurrency.Focus();
                    btnAdd.Focus();
                    throw new System.ArgumentException("");
                }
                //delete details
                parameters = new SqlParameter[2];

                parameters[0] = new SqlParameter("@seq", data.Master.SeqLG);
                parameters[1] = new SqlParameter("@out", id);
                parameters[1].Direction = ParameterDirection.Output;
                dal.ExecuteNonQueryOutString("dbo.spLG_DeleteLGDetails", CommandType.StoredProcedure, parameters, "@out");
                //insert new details
                if (dtgLGList.Rows.Count > 0)
                {
                    for (int i = 0; i < dtgLGList.Rows.Count; i++)
                    {
                        parameters = new SqlParameter[15];
                        parameters[0] = new SqlParameter("@seqLG", data.Master.SeqLG);
                        parameters[1] = new SqlParameter("@subCode", (int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString()) + m_subCodeIncreate).ToString("00"));
                        if (i < data.LstDetail.Count && (CommonValue.ActionType)dtgLGList.Rows[i].Cells["Type"].Value != CommonValue.ActionType.New)
                            parameters[2] = new SqlParameter("@flagControlBook", data.LstDetail[i].Detail.FlagControlbook);
                        else parameters[2] = new SqlParameter("@flagControlBook", byte.Parse("0"));
                        if (m_Action == CommonValue.LGAction.Amend)
                            parameters[3] = new SqlParameter("@preSubCode", int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString()).ToString("00"));
                        else
                        {
                            if (i < data.LstDetail.Count && data.LstDetail[i].Detail.PreSubCode != "")
                            {
                                parameters[3] = new SqlParameter("@preSubCode", data.LstDetail[i].Detail.PreSubCode);
                            }
                            else parameters[3] = new SqlParameter("@preSubCode", DBNull.Value);
                        }
                        if (dtgLGList.Rows[i].Cells[1].Value == null)
                        {
                            error = "Currency";
                            dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[1];
                        }
                        parameters[4] = new SqlParameter("@tranCurrency", dtgLGList.Rows[i].Cells[1].Value.ToString());

                        parameters[5] = new SqlParameter("@transAmount", decimal.Parse(dtgLGList.Rows[i].Cells[2].Value.ToString()));
                        if (dtgLGList.Rows[i].Cells[3].Value == null)
                            dtgLGList.Rows[i].Cells[3].Value = false;

                        parameters[6] = new SqlParameter("@transientAccount", (bool)dtgLGList.Rows[i].Cells[3].Value);
                        if (dtgLGList.Rows[i].Cells[4].Value == null)
                        {
                            error = "Charge Account";
                            dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[4];
                        }
                        if (lgType == 1)
                            parameters[7] = new SqlParameter("@chargeCurrency", dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(3));
                        else parameters[7] = new SqlParameter("@chargeCurrency", dtgLGList.Rows[i].Cells[1].Value.ToString()); // default value  ?? need QA

                        //   if (lgType == 1)
                        parameters[8] = new SqlParameter("@chargeAccount", dtgLGList.Rows[i].Cells[4].Value == null ? "" : dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(0, 4));
                        //   else parameters[8] = new SqlParameter("@chargeAccount", dtgLGList.Rows[i].Cells[4].Value == null ? "" : dtgLGList.Rows[i].Cells[4].Value.ToString());
                        parameters[9] = new SqlParameter("@fee", DBNull.Value);
                        parameters[10] = new SqlParameter("@feeCurrency", DBNull.Value);
                        if (dtgLGList.Rows[i].Cells[8].Value == null)
                        {
                            clsLGFeeScheduleDTO find = LstFeeSchedule.Find(delegate(clsLGFeeScheduleDTO dk)
                            {
                                return dk.SubID == dtgLGList.Rows[i].Cells[0].Value.ToString();
                            });

                            if (find == null)
                            {
                                error = "Create Charge Collection Schedule";
                                throw new System.ArgumentException("");
                            }
                            parameters[11] = new SqlParameter("@date", DBNull.Value);
                        }
                        else
                        {
                            parameters[11] = new SqlParameter("@date", (DateTime)dtgLGList.Rows[i].Cells[8].Value);
                            parameters[9] = new SqlParameter("@fee", decimal.Parse(dtgLGList.Rows[i].Cells[6].Value.ToString()));
                            if (dtgLGList.Rows[i].Cells[7].Value == null)
                            {
                                error = "Fee Currency";
                                dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[7];
                            }
                            parameters[10] = new SqlParameter("@feeCurrency", dtgLGList.Rows[i].Cells[7].Value.ToString());
                        }

                        int outVl = 0;
                        parameters[12] = new SqlParameter("@out", outVl);
                        parameters[12].Direction = ParameterDirection.Output;
                        parameters[13] = new SqlParameter("@oldSeqLG", DBNull.Value);
                        parameters[14] = new SqlParameter("@oldSubCode", (int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString())).ToString("00"));
                        dal.ExecuteNonQueryOutString("dbo.spLG_InsertLGDetail", CommandType.StoredProcedure, parameters, "@out");
                        dal.ClearParameter();
                    }
                }
                //delete Fees
                parameters = new SqlParameter[2];

                parameters[0] = new SqlParameter("@seq", data.Master.SeqLG);
                parameters[1] = new SqlParameter("@out", id);
                parameters[1].Direction = ParameterDirection.Output;
                dal.ExecuteNonQueryOutString("dbo.spLG_DeleteLGFees", CommandType.StoredProcedure, parameters, "@out");
                if (LstFeeSchedule.Count > 0)
                {
                    for (int i = 0; i < LstFeeSchedule.Count; i++)
                    {
                        parameters = new SqlParameter[11];
                        parameters[0] = new SqlParameter("@seqLG", data.Master.SeqLG);
                        parameters[1] = new SqlParameter("@subCode", (int.Parse(LstFeeSchedule[i].SubID) + m_subCodeIncreate).ToString("00"));
                        parameters[2] = new SqlParameter("@subItem", LstFeeSchedule[i].No);
                        if (LstFeeSchedule[i].ClaimedDate != DateTime.MinValue)
                            parameters[3] = new SqlParameter("@claimDate", LstFeeSchedule[i].ClaimedDate);
                        else parameters[3] = new SqlParameter("@claimDate", DBNull.Value);
                        if (LstFeeSchedule[i].ActualClaimedDate != DateTime.MinValue)
                            parameters[4] = new SqlParameter("@actualClaimDate", LstFeeSchedule[i].ActualClaimedDate);
                        else parameters[4] = new SqlParameter("@actualClaimDate", DBNull.Value);
                        if (LstFeeSchedule[i].ReceivedDate != DateTime.MinValue)
                            parameters[5] = new SqlParameter("@receiveDate", LstFeeSchedule[i].ReceivedDate);
                        else parameters[5] = new SqlParameter("@receiveDate", DBNull.Value);
                        parameters[6] = new SqlParameter("@ccy", LstFeeSchedule[i].ChargeCCY);
                        parameters[7] = new SqlParameter("@exchangeRate", LstFeeSchedule[i].ExchangeRate);
                        parameters[8] = new SqlParameter("@fee", LstFeeSchedule[i].Fee);
                        parameters[9] = new SqlParameter("@createID", clsUserInfo.UserNo);
                        int outVl = 0;
                        parameters[10] = new SqlParameter("@out", outVl);
                        parameters[10].Direction = ParameterDirection.Output;
                        dal.ExecuteNonQueryOutString("dbo.spLG_InsertFeeSchedule", CommandType.StoredProcedure, parameters, "@out");
                        dal.ClearParameter();
                    }

                }
                // clsSaveLog.Save(history);
                for (int i = 0; i < m_ListLogs.Count; i++)
                {
                    m_ListLogs[i].Key = m_ListLogs[i].Key.Insert(0, m_SeqLG + " ");
                    m_ListLogs[i].WirteLog(dal);
                }
                dal.Commit();
                this.DialogResult = DialogResult.OK;
                m_LGStatus = ((int)m_Action).ToString();
                m_LGType = cbbLGCategory.SelectedValue.ToString();
                m_Guarantee = cbbGuaranteeType.SelectedValue.ToString();
                m_arr = new ArrayList();
                for (int i = 0; i < dtgLGList.Rows.Count; i++)
                {
                    m_arr.Add(m_LGNo + "-" + (int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString()) + m_subCodeIncreate).ToString("00"));
                }
            }
            catch (Exception ex)
            {
                dal.RollBack();
                if (error == "")
                    throw (ex);
            }
            m_ListLogs.Clear();
            return error;
        }
        /// <summary>
        /// Save data from screen to database
        /// </summary>
        /// <returns></returns>
        private string Save()
        {
            dtgLGList.EndEdit();
            if (CheckDate() == false) return "None"; // already show message in CheckDate funtion
            clsDataAccessLayer dal = new clsDataAccessLayer();
            string error = "";
            try
            {
                clsLGIssueBus bus = new clsLGIssueBus();
                int lgType = int.Parse(cbbLGCategory.SelectedValue.ToString());    

                m_LGNo = data.Master.LgCode;



              
                string glCode = txtGLCode.Text;
                DateTime valueDate = dtpValueDate.Value;
                DateTime inputDate = dtpInputDate.Value;
                DateTime expireDate = dtpExpireDate.Value;
                string customerCode = cbbCustomerCode.Text;
                if (customerCode == "")
                {
                    error = lblCustomerCode.Text;
                    cbbCustomerCode.Focus();
                    throw new System.ArgumentException("");
                }

                int beneficiaryCode = -1;
                try
                {
                    beneficiaryCode = int.Parse((string)cbbBeneficiary.SelectedValue);
                }
                catch { }
                if (beneficiaryCode == -1)
                {
                    error = lblBeneficiary.Text;
                    cbbBeneficiary.Focus();
                    throw new System.ArgumentException("");
                }

                int applicantCode = -1;
                try
                {
                    applicantCode = int.Parse((string)cbbApplicant.SelectedValue);
                }
                catch { }
                if (cbbApplicant.Visible == true && applicantCode == -1)
                {
                    error = lblApplicantName.Text;
                    cbbApplicant.Focus();
                    throw new System.ArgumentException("");
                }

                string contractInfo = txtContractInformation.Text;

                string representation1 = txtRepresentation1.Text;
                string representation2 = txtRepresentation2.Text;
                string representation3 = txtRepresentation3.Text;
                
                if ((string)cbbGuaranteeType.SelectedValue == "")
                {
                    error = lblGuaranteeType.Text;
                    cbbGuaranteeType.Focus();
                    throw new System.ArgumentException("");
                }
                string guaranteeType = (string)cbbGuaranteeType.SelectedValue;

                if ((string)cbbCalculateType.SelectedValue == "")
                {

                    cbbCalculateType.Focus();
                    error = lblCalculateType.Text;
                    throw new System.ArgumentException("");
                }
                string calculateType = (string)cbbCalculateType.SelectedValue;

                if (txtLGRate.Text == "")
                {
                    error = lblLGRate.Text;
                    txtLGRate.Focus();
                    throw new System.ArgumentException("");
                }
                decimal lgRate = decimal.Parse(txtLGRate.Text);


                bool lgSecurity = true;
                if (radFledgeDeposit.Checked)
                {
                    lgSecurity = false;
                }
                bool bookPurpose = ckbBookingPurpose.Checked;
                bool minRateStandard = false; // 0 : Standart
                decimal minRateAmount = DEFAULT_MINRATE_AMOUNT;
                string minRateCurrency = DEFAULT_MINRATE_CCY;
                if (radOthers.Checked)
                {
                    minRateStandard = true; // 1 : Orther
                    if (txtOrther.Text == "")
                    {
                        error = "Minimun Rate Amount";
                        txtOrther.Focus();
                        throw new System.ArgumentException("");
                    }
                    minRateAmount = decimal.Parse(txtOrther.Text);


                    minRateCurrency = (string)cbbCurrency.SelectedValue;
                    if (minRateCurrency == "")
                    {
                        error = "Minimun Rate Currency";
                        cbbCurrency.Focus();
                        throw new System.ArgumentException("");
                    }

                }
                string remark = txtRemark.Text;
                byte lgStatus = (byte)m_Action; //New Entry
                byte lgBeforeStatus = data.Master.LgStatus;//none

                byte lgAction = 1;
                byte flagLG = 0;
                string conditionTermination = "";
                int overdureFeeTermination = 0;
                string currenceTermination = "";
                byte numReportSBV = 0;
                byte flagControlBook = 0;
                int createID = clsUserInfo.UserNo;


                SqlParameter[] parameters = new SqlParameter[35];
                parameters[32] = new SqlParameter("@inputDate", inputDate);
                parameters[0] = new SqlParameter("@lgCode", m_LGNo);
                parameters[1] = new SqlParameter("@lgType", lgType);
                // parameters[2] = new SqlParameter("@numberEdit", numberEdit);
                parameters[3] = new SqlParameter("@glCode", glCode);
                parameters[4] = new SqlParameter("@valueDate", valueDate);
                parameters[5] = new SqlParameter("@expireDate", expireDate);
                parameters[6] = new SqlParameter("@customerCode", customerCode);
                parameters[7] = new SqlParameter("@beneficiaryCode", beneficiaryCode);
                if (applicantCode != -1)
                    parameters[8] = new SqlParameter("@applicantCode", applicantCode);
                else parameters[8] = new SqlParameter("@applicantCode", DBNull.Value);
                parameters[9] = new SqlParameter("@contractInfo", contractInfo);
                parameters[10] = new SqlParameter("@representation1", representation1);
                parameters[11] = new SqlParameter("@representation2", representation2);
                parameters[12] = new SqlParameter("@representation3", representation3);
                parameters[13] = new SqlParameter("@guaranteeType", guaranteeType);
                parameters[14] = new SqlParameter("@calculateType", calculateType);
                parameters[15] = new SqlParameter("@lgRate", lgRate);
                parameters[16] = new SqlParameter("@lgSecurity", lgSecurity);
                parameters[17] = new SqlParameter("@bookPurpose", bookPurpose);
                parameters[18] = new SqlParameter("@minRateStandard", minRateStandard);
                parameters[19] = new SqlParameter("@minRateAmount", minRateAmount);
                parameters[20] = new SqlParameter("@remark", remark);
                parameters[21] = new SqlParameter("@lgStatus", lgStatus);
                parameters[22] = new SqlParameter("@lgBeforeStatus", lgBeforeStatus);
                parameters[23] = new SqlParameter("@lgAction", lgAction);
                parameters[24] = new SqlParameter("@flagLG", flagLG);
                parameters[25] = new SqlParameter("@conditionTermination", conditionTermination);
                parameters[26] = new SqlParameter("@overdureFeeTermination", overdureFeeTermination);
                parameters[27] = new SqlParameter("@currenceTermination", currenceTermination);
                parameters[28] = new SqlParameter("@numReportSBV", numReportSBV);
                parameters[29] = new SqlParameter("@flagControlBook", flagControlBook);
                parameters[30] = new SqlParameter("@createID", createID);
                int id = 0;
                parameters[31] = new SqlParameter("@id", id);
                parameters[31].Direction = ParameterDirection.Output;
                parameters[33] = new SqlParameter("@Code", id);
                parameters[33].Direction = ParameterDirection.Output;
                parameters[2] = new SqlParameter("@minRateCurrency", minRateCurrency);

                parameters[34] = new SqlParameter("@allow", cbLGAllowed.Checked);
                //parameters[33] = new SqlParameter("",);
                string lgNo = dal.ExecuteNonQueryOutString("dbo.spLG_InsertLGMaster", CommandType.StoredProcedure, parameters, "@id");
                m_SeqLG = lgNo;

                string Code = dal.GetParameterValue("@Code");

                
                dal.ClearParameter();

                if (m_amendFee != null)
                {
                    parameters = new SqlParameter[7];
                    parameters[0] = new SqlParameter("@seq", m_SeqLG);
                    parameters[1] = new SqlParameter("@flatFee", m_amendFee.FlatFee);
                    parameters[2] = new SqlParameter("@rate", m_amendFee.ExchangeRate);
                    parameters[3] = new SqlParameter("@account", m_amendFee.Account);
                    parameters[4] = new SqlParameter("@ccy", m_amendFee.CCY);
                    parameters[5] = new SqlParameter("@amendFee", m_amendFee.Fee);
                    parameters[6] = new SqlParameter("@out", id);
                    parameters[6].Direction = ParameterDirection.InputOutput;
                    dal.ExecuteNonQueryOutString("dbo.spLG_UpdateAmendFee", CommandType.StoredProcedure, parameters, "@out");
                }

                if (dtgLGList.Rows.Count == 0)
                {
                    error = "LG Detail";
                    //  cbbCurrency.Focus();
                    btnAdd.Focus();
                    throw new System.ArgumentException("");
                }
                if (dtgLGList.Rows.Count > 0)
                {
                    for (int i = 0; i < dtgLGList.Rows.Count; i++)
                    {
                        parameters = new SqlParameter[15];
                        parameters[0] = new SqlParameter("@seqLG", int.Parse(lgNo));
                        parameters[1] = new SqlParameter("@subCode", (int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString()) + m_subCodeIncreate).ToString("00"));
                        if(i < data.LstDetail.Count && (CommonValue.ActionType)dtgLGList.Rows[i].Cells["Type"].Value != CommonValue.ActionType.New )
                        parameters[2] = new SqlParameter("@flagControlBook", data.LstDetail[i].Detail.FlagControlbook);
                        else parameters[2] = new SqlParameter("@flagControlBook", byte.Parse("0"));
                        if (m_Action == CommonValue.LGAction.Amend)
                            parameters[3] = new SqlParameter("@preSubCode", int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString()).ToString("00"));
                        else
                        {
                            if (i < data.LstDetail.Count && data.LstDetail[i].Detail.PreSubCode != "")
                            {
                                parameters[3] = new SqlParameter("@preSubCode", data.LstDetail[i].Detail.PreSubCode);
                            }
                            else parameters[3] = new SqlParameter("@preSubCode", DBNull.Value);
                        }
                        if (dtgLGList.Rows[i].Cells[1].Value == null)
                        {
                            error = "Currency";
                            dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[1];
                        }
                        parameters[4] = new SqlParameter("@tranCurrency", dtgLGList.Rows[i].Cells[1].Value.ToString());

                        parameters[5] = new SqlParameter("@transAmount", decimal.Parse(dtgLGList.Rows[i].Cells[2].Value.ToString()));
                        if (dtgLGList.Rows[i].Cells[3].Value == null)
                            dtgLGList.Rows[i].Cells[3].Value = false;

                        parameters[6] = new SqlParameter("@transientAccount", (bool)dtgLGList.Rows[i].Cells[3].Value);
                        if (dtgLGList.Rows[i].Cells[4].Value == null)
                        {
                            error = "Charge Account";
                            dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[4];
                        }
                        if (lgType == 1)
                            parameters[7] = new SqlParameter("@chargeCurrency", dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(3));
                        else parameters[7] = new SqlParameter("@chargeCurrency", dtgLGList.Rows[i].Cells[1].Value.ToString()); // default value  ?? need QA
                        
                     //   if (lgType == 1)
                            parameters[8] = new SqlParameter("@chargeAccount", dtgLGList.Rows[i].Cells[4].Value == null ? "" : dtgLGList.Rows[i].Cells[4].Value.ToString().Remove(0, 4));
                     //   else parameters[8] = new SqlParameter("@chargeAccount", dtgLGList.Rows[i].Cells[4].Value == null ? "" : dtgLGList.Rows[i].Cells[4].Value.ToString());
                            parameters[9] = new SqlParameter("@fee", DBNull.Value);
                            parameters[10] = new SqlParameter("@feeCurrency", DBNull.Value);
                            if (dtgLGList.Rows[i].Cells[8].Value == null)
                            {
                                clsLGFeeScheduleDTO find = LstFeeSchedule.Find(delegate(clsLGFeeScheduleDTO dk)
                                {
                                    return dk.SubID == dtgLGList.Rows[i].Cells[0].Value.ToString();
                                });

                                if (find == null)
                                {
                                    error = "Create Charge Collection Schedule";
                                    throw new System.ArgumentException("");
                                }
                                parameters[11] = new SqlParameter("@date", DBNull.Value);
                            }
                            else
                            {
                                parameters[11] = new SqlParameter("@date", (DateTime)dtgLGList.Rows[i].Cells[8].Value);
                                parameters[9] = new SqlParameter("@fee", decimal.Parse(dtgLGList.Rows[i].Cells[6].Value.ToString()));
                                if (dtgLGList.Rows[i].Cells[7].Value == null)
                                {
                                    error = "Fee Currency";
                                    dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[7];
                                }
                                parameters[10] = new SqlParameter("@feeCurrency", dtgLGList.Rows[i].Cells[7].Value.ToString());
                            }

                        int outVl = 0;
                        parameters[12] = new SqlParameter("@out", outVl);
                        parameters[12].Direction = ParameterDirection.Output;
                        parameters[13] = new SqlParameter("@oldSeqLG", data.Master.SeqLG);
                        parameters[14] = new SqlParameter("@oldSubCode", (int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString())).ToString("00"));
                        dal.ExecuteNonQueryOutString("dbo.spLG_InsertLGDetail", CommandType.StoredProcedure, parameters, "@out");
                        dal.ClearParameter();
                    }
                }

                if (LstFeeSchedule.Count > 0)
                {
                    for (int i = 0; i < LstFeeSchedule.Count; i++)
                    {
                        parameters = new SqlParameter[11];
                        parameters[0] = new SqlParameter("@seqLG", int.Parse(lgNo));
                        parameters[1] = new SqlParameter("@subCode", (int.Parse(LstFeeSchedule[i].SubID) + m_subCodeIncreate).ToString("00"));
                        parameters[2] = new SqlParameter("@subItem", LstFeeSchedule[i].No);
                        if (LstFeeSchedule[i].ClaimedDate != DateTime.MinValue)
                            parameters[3] = new SqlParameter("@claimDate", LstFeeSchedule[i].ClaimedDate);
                        else parameters[3] = new SqlParameter("@claimDate", DBNull.Value);
                        if (LstFeeSchedule[i].ActualClaimedDate != DateTime.MinValue)
                            parameters[4] = new SqlParameter("@actualClaimDate", LstFeeSchedule[i].ActualClaimedDate);
                        else parameters[4] = new SqlParameter("@actualClaimDate", DBNull.Value);
                        if (LstFeeSchedule[i].ReceivedDate != DateTime.MinValue)
                            parameters[5] = new SqlParameter("@receiveDate", LstFeeSchedule[i].ReceivedDate);
                        else parameters[5] = new SqlParameter("@receiveDate", DBNull.Value);
                        parameters[6] = new SqlParameter("@ccy", LstFeeSchedule[i].ChargeCCY);
                        parameters[7] = new SqlParameter("@exchangeRate", LstFeeSchedule[i].ExchangeRate);
                        parameters[8] = new SqlParameter("@fee", LstFeeSchedule[i].Fee);
                        parameters[9] = new SqlParameter("@createID", clsUserInfo.UserNo);
                        int outVl = 0;
                        parameters[10] = new SqlParameter("@out", outVl);
                        parameters[10].Direction = ParameterDirection.Output;
                        dal.ExecuteNonQueryOutString("dbo.spLG_InsertFeeSchedule", CommandType.StoredProcedure, parameters, "@out");
                        dal.ClearParameter();
                    }

                }
               // clsSaveLog.Save(history);
                for (int i = 0; i < m_ListLogs.Count; i++)
                {
                   m_ListLogs[i].Key =  m_ListLogs[i].Key.Insert(0, m_SeqLG + " ");
                    m_ListLogs[i].WirteLog(dal);
                }
                dal.Commit();
                this.DialogResult = DialogResult.OK;
                m_LGStatus = ((int)m_Action).ToString();
                m_LGType = cbbLGCategory.SelectedValue.ToString();
                m_Guarantee = cbbGuaranteeType.SelectedValue.ToString();
                m_arr = new ArrayList();
                for (int i = 0; i < dtgLGList.Rows.Count; i++)
                {
                    m_arr.Add(m_LGNo + "-" + (int.Parse(dtgLGList.Rows[i].Cells[0].Value.ToString()) + m_subCodeIncreate).ToString("00"));
                }
            }
            catch (Exception ex)
            {
                dal.RollBack();
                if (error == "")
                    throw (ex);
            }
            m_ListLogs.Clear();
            return error;
        }

        void Run()
        {

        }
        void Complete()
        {
            m_frmPrintForm.StartPosition = FormStartPosition.CenterScreen;
            m_frmPrintForm.Show();
        }
        /// <summary>
        /// check correct value in datetimpicker
        /// </summary>
        /// <returns></returns>
        bool CheckDate()
        {
            //check expire date and value date
            if (dtpExpireDate.Value < dtpValueDate.Value)
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.EXPRIREDATE_GREATER_VALUEDATE);
                DateTimePickerFormat fmt = dtpExpireDate.Format;
                dtpExpireDate.Format = DateTimePickerFormat.Short;
                dtpExpireDate.Format = fmt;
                dtpExpireDate.Select();
                dtpExpireDate.Focus();
                return false;

            }
            if (radFledgeDeposit.Checked) //in case Pledge Deposit sercurity, check banking date 
            {
                for (int i = 0; i < dtgLGList.Rows.Count; i++)
                {
                    try
                    {
                        if (clsLGCommonBus.Instance().CheckBankingDate(dtpExpireDate.Value, dtgLGList.Rows[i].Cells[1].Value.ToString()))
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.EXPIREDATE_IS_NOT_BANKING_DATE);
                            DateTimePickerFormat fmt = dtpExpireDate.Format;
                            dtpExpireDate.Format = DateTimePickerFormat.Short;
                            dtpExpireDate.Format = fmt;
                            dtpExpireDate.Select();
                            dtpExpireDate.Focus();
                            return false;
                        }

                        if (clsLGCommonBus.Instance().CheckBankingDate(dtpValueDate.Value, dtgLGList.Rows[i].Cells[1].Value.ToString()))
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.VALUEDATE_IS_NOT_BANKING_DATE);
                            DateTimePickerFormat fmt = dtpValueDate.Format;
                            dtpValueDate.Format = DateTimePickerFormat.Short;
                            dtpValueDate.Format = fmt;
                            dtpValueDate.Select();
                            dtpValueDate.Focus();
                            return false;
                        }
                    }
                    catch { }
                }
            }
            return true;
        }

        private void dtgLGList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtpExpireDate_ValueChanged(object sender, EventArgs e)
        {
            ReCalculateValue();
        }
        /// <summary>
        /// Re calculate value in datagrid when 1 parameter change value
        /// </summary>
        private void ReCalculateValue()
        {
            decimal rate = 0;
            try
            {
                rate = decimal.Parse(txtLGRate.Text);
            }
            catch
            {
            }
            TimeSpan tp = dtpExpireDate.Value - dtpValueDate.Value.AddSeconds(-1);

            for (int i = 0; i < dtgLGList.Rows.Count; i++)
            {
                int numDecimal = clsLGConstant.NUMBERDECIMAL;
                if (dtgLGList.Rows[i].Cells[1].Value != null) // when column CCY not null
                {
                    if (clsLGCommonBus.Instance().MainCCYList.Contains(dtgLGList.Rows[i].Cells[1].Value.ToString()))
                    {
                        numDecimal = 0;
                    }

                    decimal amount = (decimal)dtgLGList.Rows[i].Cells[2].Value;
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE3)
                    {
                        dtgLGList.Rows[i].Cells[5].Value = Math.Round(amount * RoundingUp((decimal)tp.Days / 30) * rate / 100 / 12, numDecimal);
                      //  dtgLGList.Rows[i].Cells[6].Value = Math.Round(amount * tp.Days * rate / 100 / 30 / 12, numDecimal);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE2)
                    {
                        dtgLGList.Rows[i].Cells[5].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 360, numDecimal);
                        //dtgLGList.Rows[i].Cells[6].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 360, numDecimal);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE1)
                    {
                        dtgLGList.Rows[i].Cells[5].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 365, numDecimal);
                       // dtgLGList.Rows[i].Cells[6].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 365, numDecimal);
                    }
                }
            }
        }

        private void txtLGRate_TextChanged(object sender, EventArgs e)
        {
            ReCalculateValue();
        }

        private void dtgLGList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2 || e.ColumnIndex == 1)
            {
                if (dtgLGList.Rows[e.RowIndex].Cells[1].Value != null)
                {
                    decimal rate = 0;
                    try
                    {
                        rate = decimal.Parse(txtLGRate.Text); // try to get rate, if user not input at textbox rate -> set rate = 0
                    }
                    catch
                    {
                    }
                    TimeSpan tp = dtpExpireDate.Value - dtpValueDate.Value.AddSeconds(-1); // calculate time between 2 dates

                    decimal amount = (decimal)dtgLGList.Rows[e.RowIndex].Cells[2].Value;
                    int numDecimal = clsLGConstant.NUMBERDECIMAL; // number decimal

                    if (clsLGCommonBus.Instance().MainCCYList.Contains(dtgLGList.Rows[e.RowIndex].Cells[1].Value.ToString()))
                    {
                        numDecimal = 0;
                        dtgLGList.Rows[e.RowIndex].Cells[2].Value = Math.Round((decimal)dtgLGList.Rows[e.RowIndex].Cells[2].Value, 0);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE3)
                    {
                        dtgLGList.Rows[e.RowIndex].Cells[5].Value = Math.Round(amount * RoundingUp((decimal)tp.Days / 30) * rate / 100 / 12, numDecimal);
                       // dtgLGList.Rows[e.RowIndex].Cells[6].Value = Math.Round(amount * tp.Days * rate / 100 / 30 / 12, numDecimal);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE2)
                    {
                        dtgLGList.Rows[e.RowIndex].Cells[5].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 360, numDecimal);
                      //  dtgLGList.Rows[e.RowIndex].Cells[6].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 360, numDecimal);
                    }
                    if ((string)cbbCalculateType.SelectedValue == clsLGConstant.LG_CALCULATE_TYPE1)
                    {
                        dtgLGList.Rows[e.RowIndex].Cells[5].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 365, numDecimal);
                       // dtgLGList.Rows[e.RowIndex].Cells[6].Value = Math.Round((amount * (tp.Days + 1)) * rate / 100 / 365, numDecimal);
                    }
                }

                if (e.ColumnIndex == 1)
                {
                    if (dtgLGList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                    {
                        if (cbbLGCategory.SelectedValue.ToString() == ((int)CommonValue.LGType.Counter).ToString())
                        {

                            DataGridViewComboBoxCell combo = this.dtgLGList[4, e.RowIndex] as DataGridViewComboBoxCell;
                            combo.Value = null;
                            List<clsLGAccountInfoDTO> lst = new List<clsLGAccountInfoDTO>();
                            for (int i = 0; i < m_lstCCY.Count; i++)
                            {
                                if (m_lstCCY[i].Value != "")
                                    lst.Add(new clsLGAccountInfoDTO(m_lstCCY[i].Value + "-" + clsLGConstant.LG_COUNTER_ACCOUNT, dtgLGList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() + "-" + clsLGConstant.LG_COUNTER_ACCOUNT));
                            }
                            combo.DataSource = lst;

                            combo.DisplayMember = "AccountNo";
                            combo.ValueMember = "AccountNo";
                            dtgLGList.Rows[e.RowIndex].Cells[4].Value = dtgLGList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() + "-" + clsLGConstant.LG_COUNTER_ACCOUNT;
                        }

                        if (clsLGCommonBus.Instance().MainCCYList.Contains(dtgLGList.Rows[e.RowIndex].Cells[1].Value.ToString()))
                        {
                            ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells[2]).DecimalLength = 0;
                        }
                        else
                        {
                            ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells[2]).DecimalLength = 2;
                        }

                        dtgLGList.Rows[e.RowIndex].Cells["colFeeCurrency"].Value = dtgLGList.Rows[e.RowIndex].Cells["colCurrency"].Value;

                    }


                }
            }
        }

        private void frmLGAmend_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (ForceClose == false) // strictly closing form
            {
                if (m_isSaveClick == false)
                {
                    if (CheckChangeValue() == true)
                    {
                        DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.DO_YOU_WANT_SAVE);
                        if (result == DialogResult.Yes)
                        {
                            string error = Save();
                            if (error != "") // if have error -> show message
                            {
                                if (error != "None") // already show message in CheckDate funtion
                                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                                e.Cancel = true;
                            }
                            else // else - > success
                            {
                                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "LG" });
                                PrepareSmileObject();
                                CWorker worker = new CWorker(Run, Complete);
                                worker.Start();

                            }
                        }
                        if (result == DialogResult.Cancel) // cancel close form
                            e.Cancel = true;
                    }
                }
            }
            
        }
        /// <summary>
        /// rounding up number
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        decimal RoundingUp(decimal input)
        {
            return Math.Ceiling(input); 
        }

        private void dtgLGList_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //format decimal leght for fee and amount in datagrid
            if (dtgLGList.Rows[e.RowIndex].Cells["colCurrency"].Value != null) 
            {
                if (clsLGCommonBus.Instance().MainCCYList.Contains((string)dtgLGList.Rows[e.RowIndex].Cells["colCurrency"].Value))
                {

                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colAmount"]).DecimalLength = 0;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colAmount"]).MaxInputLength = 10;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFeeSuggestion"]).DecimalLength = 0;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFeeSuggestion"]).MaxInputLength = 10;

                }
                else
                {
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colAmount"]).DecimalLength = 2;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colAmount"]).MaxInputLength = 13;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFeeSuggestion"]).DecimalLength = 2;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFeeSuggestion"]).MaxInputLength = 13;

                }
            }
            //format decimal lenght for Fee Suggess
            if (dtgLGList.Rows[e.RowIndex].Cells["colFeeCurrency"].Value != null)
            {
                if (clsLGCommonBus.Instance().MainCCYList.Contains((string)dtgLGList.Rows[e.RowIndex].Cells["colFeeCurrency"].Value))
                {

                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFee"]).DecimalLength = 0;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFee"]).MaxInputLength = 10;
                }
                else
                {

                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFee"]).DecimalLength = 2;
                    ((TNumEditDataGridViewCell)dtgLGList.Rows[e.RowIndex].Cells["colFee"]).MaxInputLength = 13;
                }
            }
        }



        private void dtgLGList_CellValueChanged_1(object sender, DataGridViewCellEventArgs e)
        {
            //set fee and amount = 0  in case CCY changed
            if (e.ColumnIndex == 1 && e.RowIndex >= 0) // CCY
            {
                dtgLGList.Rows[e.RowIndex].Cells["colAmount"].Value = 0;
              
            }
            if (e.ColumnIndex == 7 && e.RowIndex >= 0) // Issues Fee CCY
            {
                dtgLGList.Rows[e.RowIndex].Cells["colFee"].Value = 0;
            }
            if (e.ColumnIndex != 8 && e.RowIndex >= 0 && e.ColumnIndex != 5)
            {
                //check and change value of column Type (use to log)
                if ((CommonValue.ActionType)dtgLGList.Rows[e.RowIndex].Cells[9].Value == CommonValue.ActionType.None && this.Visible == true)
                {
                    dtgLGList.Rows[e.RowIndex].Cells[9].Value = CommonValue.ActionType.Update;
                }
            }

        }


        private void cbbCalculateType_SelectedValueChanged(object sender, EventArgs e)
        {
            ReCalculateValue();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                string error = CheckDataGrid();
                if (error != "")
                {
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                }
                else
                {
                    if (dtgLGList.SelectedRows != null && dtgLGList.SelectedRows.Count > 0)
                    {
                        // if (frmCreateFee == null)
                        frmLGFeeCollectionSchedule frm = new frmLGFeeCollectionSchedule(dtgLGList, this, cbbBeneficiary.Text, cbbCustomerName.Text);
                        if (frm.IsCorrect == true)
                        {
                            frm.ShowDialog();
                            frm.BringToFront();
                            if (LstFeeSchedule.Count > 0)
                            {
                                dtgLGList.Columns["colDateOfActualCollection"].ReadOnly = true;
                            }
                            else
                                dtgLGList.Columns["colDateOfActualCollection"].ReadOnly = false;
                        }
                        else
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.CANNOT_CREATE_FEE_SCHEDULE);
                        }
                    }
                }
               
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }

        }


        /// <summary>
        /// check value null in datagridview
        /// </summary>
        /// <returns></returns>
        private string CheckDataGrid()
        {
            string error = "";
            if (dtgLGList.Rows.Count > 0)
            {

                for (int i = 0; i < dtgLGList.Rows.Count; i++)
                {

                    if (dtgLGList.Rows[i].Cells[1].Value == null)
                    {
                        dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[1];
                        return error = "Currency";

                    }

                    if (dtgLGList.Rows[i].Cells[4].Value == null)
                    {
                        dtgLGList.CurrentCell = dtgLGList.Rows[i].Cells[4];
                        return error = "Account";
                    }
                }

            }

            return error;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dtgLGList.SelectedRows.Count > 0)
            {
                int flagRecord = -1; //save index of fee schedule in list LstFeeSchedule
                // List  1 , 2 , 3 , 4 , 5
                //           |
                //         flagRecord : remove at 2
                //           |
                //List   1 , 3 , 4 , 5 (must decreate index of 3, 4, 5 - > 2, 3 ,4)
                //  ->   1 , 2 , 3 , 4   

                for (int j = LstFeeSchedule.Count - 1; j >= 0; j--)
                {
                    if (LstFeeSchedule[j].SubID == dtgLGList.SelectedRows[0].Cells[0].Value.ToString())
                    {
                        if ((CommonValue.ActionType)dtgLGList.SelectedRows[0].Cells["Type"].Value == CommonValue.ActionType.New) // if new, just remove and dont care
                        {
                            if (LstFeeSchedule[j].Type != CommonValue.ActionType.Delete)
                            {
                                LstFeeSchedule.RemoveAt(j);
                                flagRecord = j; // saving index of record was removed
                            }
                        }
                        else // if it exist in database, change type to delete and write log
                        {
                            LstFeeSchedule[j].Type = CommonValue.ActionType.Delete;
                        }

                    }
                }
                if ((CommonValue.ActionType)dtgLGList.SelectedRows[0].Cells["Type"].Value == CommonValue.ActionType.None //if data already exist in database -> save log delete
                    || (CommonValue.ActionType)dtgLGList.SelectedRows[0].Cells["Type"].Value == CommonValue.ActionType.Update)
                {
                    m_DeleteDetails.Add(dtgLGList.SelectedRows[0].Cells[0].Value.ToString());
                }

                if (dtgLGList.Rows.Count > 0) // remove row at datagrid
                    dtgLGList.Rows.RemoveAt(dtgLGList.Rows.IndexOf(dtgLGList.SelectedRows[0]));

                if (flagRecord >= 0)
                {
                    for (int k = flagRecord; k < LstFeeSchedule.Count; k++)
                    {
                        LstFeeSchedule[k].SubID = (int.Parse(LstFeeSchedule[k].SubID) - 1).ToString("00");
                    }
                }
                if (dtgLGList.Rows.Count > 0)
                {
                    for (int i = 0; i < dtgLGList.Rows.Count; i++)
                    {
                        dtgLGList.Rows[i].Cells[0].Value = i.ToString("00");
                    }
                }
            }
        }
        public AmendFee m_fee;
        private void btnAmendFee_Click(object sender, EventArgs e)
        {
            if(m_fee == null)
            m_fee = clsLGMasterBus.GetAmentFee(data.Master.SeqLG.ToString());
            frmLGAmendUpdateFee frm = new frmLGAmendUpdateFee(data,m_fee);
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
            m_amendFee = frm.m_fee;
            m_fee = frm.m_fee;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // if have not changed value then return and do nothing
                if (CheckChangeValue() == false) return;
                // if have some value changed value -> confirm with user 
                DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.CONFIRM_ACTION, new string[] { "save", "LG" });
                if (result == DialogResult.Yes) // yes - > save action
                {
                    string error = Update();
                    if (error != "")
                    {
                        if (error != "None") // already show message in CheckDate funtion
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                    }
                    else
                    {
                        clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "LG" });

                        //// Prepare data before importing into Smile
                        //PrepareSmileObject();

                        //CWorker worker = new CWorker(Run, Complete);
                        //worker.Start();
                        m_isSaveClick = true;
                        this.Close();
                    }
                }
                if (result == DialogResult.No) // no : not save
                {
                    m_isSaveClick = true;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }
    }
}