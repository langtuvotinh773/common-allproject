﻿namespace Phoenix.Lg.Gui.Forms
{
    partial class frmLGListApplicant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLGListApplicant));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblApplicantCode = new System.Windows.Forms.Label();
            this.txtApplicantCode = new System.Windows.Forms.TextBox();
            this.txtApplicantName = new System.Windows.Forms.TextBox();
            this.lblApplicantName = new System.Windows.Forms.Label();
            this.txtApplicantAddress = new System.Windows.Forms.TextBox();
            this.lblApplicantAddress = new System.Windows.Forms.Label();
            this.txtApplicantNational = new System.Windows.Forms.TextBox();
            this.lblApplicantNational = new System.Windows.Forms.Label();
            this.txtApplicantTel = new System.Windows.Forms.TextBox();
            this.lblApplicantTel = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtgApplicantList = new System.Windows.Forms.DataGridView();
            this.colCheck = new UserCtrl.DataGridViewDisableCheckBoxColumn();
            this.colApplicantCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colApplicantName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colApplicantAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colApplicantNational = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colApplicantTel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colApplicantFax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNoChange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSeqApplicant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnClose = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbUpdateApplicant = new System.Windows.Forms.ToolStripButton();
            this.tsbDeleteApplicant = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.dataGridViewDisableCheckBoxColumn1 = new UserCtrl.DataGridViewDisableCheckBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgApplicantList)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblApplicantCode
            // 
            this.lblApplicantCode.AutoSize = true;
            this.lblApplicantCode.Location = new System.Drawing.Point(9, 22);
            this.lblApplicantCode.Name = "lblApplicantCode";
            this.lblApplicantCode.Size = new System.Drawing.Size(79, 13);
            this.lblApplicantCode.TabIndex = 0;
            this.lblApplicantCode.Text = "Applicant Code";
            // 
            // txtApplicantCode
            // 
            this.txtApplicantCode.Location = new System.Drawing.Point(130, 19);
            this.txtApplicantCode.Name = "txtApplicantCode";
            this.txtApplicantCode.Size = new System.Drawing.Size(320, 20);
            this.txtApplicantCode.TabIndex = 0;
            // 
            // txtApplicantName
            // 
            this.txtApplicantName.Location = new System.Drawing.Point(632, 19);
            this.txtApplicantName.Name = "txtApplicantName";
            this.txtApplicantName.Size = new System.Drawing.Size(320, 20);
            this.txtApplicantName.TabIndex = 1;
            // 
            // lblApplicantName
            // 
            this.lblApplicantName.AutoSize = true;
            this.lblApplicantName.Location = new System.Drawing.Point(518, 22);
            this.lblApplicantName.Name = "lblApplicantName";
            this.lblApplicantName.Size = new System.Drawing.Size(82, 13);
            this.lblApplicantName.TabIndex = 2;
            this.lblApplicantName.Text = "Applicant Name";
            // 
            // txtApplicantAddress
            // 
            this.txtApplicantAddress.Location = new System.Drawing.Point(130, 40);
            this.txtApplicantAddress.Name = "txtApplicantAddress";
            this.txtApplicantAddress.Size = new System.Drawing.Size(320, 20);
            this.txtApplicantAddress.TabIndex = 2;
            // 
            // lblApplicantAddress
            // 
            this.lblApplicantAddress.AutoSize = true;
            this.lblApplicantAddress.Location = new System.Drawing.Point(9, 43);
            this.lblApplicantAddress.Name = "lblApplicantAddress";
            this.lblApplicantAddress.Size = new System.Drawing.Size(92, 13);
            this.lblApplicantAddress.TabIndex = 4;
            this.lblApplicantAddress.Text = "Applicant Address";
            // 
            // txtApplicantNational
            // 
            this.txtApplicantNational.Location = new System.Drawing.Point(632, 40);
            this.txtApplicantNational.Name = "txtApplicantNational";
            this.txtApplicantNational.Size = new System.Drawing.Size(320, 20);
            this.txtApplicantNational.TabIndex = 3;
            // 
            // lblApplicantNational
            // 
            this.lblApplicantNational.AutoSize = true;
            this.lblApplicantNational.Location = new System.Drawing.Point(518, 43);
            this.lblApplicantNational.Name = "lblApplicantNational";
            this.lblApplicantNational.Size = new System.Drawing.Size(103, 13);
            this.lblApplicantNational.TabIndex = 6;
            this.lblApplicantNational.Text = "Applicant Nationality";
            // 
            // txtApplicantTel
            // 
            this.txtApplicantTel.Location = new System.Drawing.Point(130, 61);
            this.txtApplicantTel.Name = "txtApplicantTel";
            this.txtApplicantTel.Size = new System.Drawing.Size(320, 20);
            this.txtApplicantTel.TabIndex = 4;
            // 
            // lblApplicantTel
            // 
            this.lblApplicantTel.AutoSize = true;
            this.lblApplicantTel.Location = new System.Drawing.Point(9, 64);
            this.lblApplicantTel.Name = "lblApplicantTel";
            this.lblApplicantTel.Size = new System.Drawing.Size(69, 13);
            this.lblApplicantTel.TabIndex = 8;
            this.lblApplicantTel.Text = "Applicant Tel";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(878, 66);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtgApplicantList
            // 
            this.dtgApplicantList.AllowUserToAddRows = false;
            this.dtgApplicantList.AllowUserToDeleteRows = false;
            this.dtgApplicantList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgApplicantList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgApplicantList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgApplicantList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgApplicantList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgApplicantList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCheck,
            this.colApplicantCode,
            this.colApplicantName,
            this.colApplicantAddress,
            this.colApplicantNational,
            this.colApplicantTel,
            this.colApplicantFax,
            this.colNoChange,
            this.colSeqApplicant});
            this.dtgApplicantList.Location = new System.Drawing.Point(8, 129);
            this.dtgApplicantList.MultiSelect = false;
            this.dtgApplicantList.Name = "dtgApplicantList";
            this.dtgApplicantList.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgApplicantList.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dtgApplicantList.RowHeadersVisible = false;
            this.dtgApplicantList.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgApplicantList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgApplicantList.Size = new System.Drawing.Size(953, 281);
            this.dtgApplicantList.TabIndex = 1;
            this.dtgApplicantList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgApplicantList_CellClick);
            this.dtgApplicantList.SelectionChanged += new System.EventHandler(this.dtgApplicantList_SelectionChanged);
            // 
            // colCheck
            // 
            this.colCheck.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colCheck.HeaderText = "";
            this.colCheck.MinimumWidth = 30;
            this.colCheck.Name = "colCheck";
            this.colCheck.ReadOnly = true;
            this.colCheck.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCheck.Width = 30;
            // 
            // colApplicantCode
            // 
            this.colApplicantCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colApplicantCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.colApplicantCode.FillWeight = 287.4251F;
            this.colApplicantCode.HeaderText = "Applicant Code";
            this.colApplicantCode.MinimumWidth = 120;
            this.colApplicantCode.Name = "colApplicantCode";
            this.colApplicantCode.ReadOnly = true;
            this.colApplicantCode.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colApplicantCode.Width = 120;
            // 
            // colApplicantName
            // 
            this.colApplicantName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colApplicantName.DefaultCellStyle = dataGridViewCellStyle3;
            this.colApplicantName.FillWeight = 179.5642F;
            this.colApplicantName.HeaderText = "Applicant Name";
            this.colApplicantName.MinimumWidth = 200;
            this.colApplicantName.Name = "colApplicantName";
            this.colApplicantName.ReadOnly = true;
            this.colApplicantName.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colApplicantName.Width = 200;
            // 
            // colApplicantAddress
            // 
            this.colApplicantAddress.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colApplicantAddress.DefaultCellStyle = dataGridViewCellStyle4;
            this.colApplicantAddress.FillWeight = 39.37148F;
            this.colApplicantAddress.HeaderText = "Applicant Address";
            this.colApplicantAddress.MinimumWidth = 200;
            this.colApplicantAddress.Name = "colApplicantAddress";
            this.colApplicantAddress.ReadOnly = true;
            this.colApplicantAddress.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colApplicantAddress.Width = 200;
            // 
            // colApplicantNational
            // 
            this.colApplicantNational.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colApplicantNational.DefaultCellStyle = dataGridViewCellStyle5;
            this.colApplicantNational.FillWeight = 30.24742F;
            this.colApplicantNational.HeaderText = "Applicant Nationality";
            this.colApplicantNational.MinimumWidth = 200;
            this.colApplicantNational.Name = "colApplicantNational";
            this.colApplicantNational.ReadOnly = true;
            this.colApplicantNational.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colApplicantNational.Width = 200;
            // 
            // colApplicantTel
            // 
            this.colApplicantTel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colApplicantTel.DefaultCellStyle = dataGridViewCellStyle6;
            this.colApplicantTel.FillWeight = 32.51725F;
            this.colApplicantTel.HeaderText = "Applicant Tel";
            this.colApplicantTel.MinimumWidth = 100;
            this.colApplicantTel.Name = "colApplicantTel";
            this.colApplicantTel.ReadOnly = true;
            // 
            // colApplicantFax
            // 
            this.colApplicantFax.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colApplicantFax.DefaultCellStyle = dataGridViewCellStyle7;
            this.colApplicantFax.FillWeight = 30.87442F;
            this.colApplicantFax.HeaderText = "Applicant Fax";
            this.colApplicantFax.MinimumWidth = 100;
            this.colApplicantFax.Name = "colApplicantFax";
            this.colApplicantFax.ReadOnly = true;
            // 
            // colNoChange
            // 
            this.colNoChange.HeaderText = "NoChange";
            this.colNoChange.Name = "colNoChange";
            this.colNoChange.ReadOnly = true;
            this.colNoChange.Visible = false;
            this.colNoChange.Width = 83;
            // 
            // colSeqApplicant
            // 
            this.colSeqApplicant.HeaderText = "SeqApplicant";
            this.colSeqApplicant.Name = "colSeqApplicant";
            this.colSeqApplicant.ReadOnly = true;
            this.colSeqApplicant.Visible = false;
            this.colSeqApplicant.Width = 95;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(886, 416);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbUpdateApplicant,
            this.tsbDeleteApplicant});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(970, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.TabStop = true;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbUpdateApplicant
            // 
            this.tsbUpdateApplicant.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbUpdateApplicant.Image = ((System.Drawing.Image)(resources.GetObject("tsbUpdateApplicant.Image")));
            this.tsbUpdateApplicant.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUpdateApplicant.Name = "tsbUpdateApplicant";
            this.tsbUpdateApplicant.Size = new System.Drawing.Size(23, 22);
            this.tsbUpdateApplicant.Text = "Modify (Alt + U)";
            this.tsbUpdateApplicant.Click += new System.EventHandler(this.tsbUpdateApplicant_Click);
            // 
            // tsbDeleteApplicant
            // 
            this.tsbDeleteApplicant.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteApplicant.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteApplicant.Image")));
            this.tsbDeleteApplicant.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDeleteApplicant.Name = "tsbDeleteApplicant";
            this.tsbDeleteApplicant.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteApplicant.Text = "Delete (Alt + D)";
            this.tsbDeleteApplicant.Click += new System.EventHandler(this.tsbDeleteApplicant_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtApplicantNational);
            this.groupBox1.Controls.Add(this.lblApplicantCode);
            this.groupBox1.Controls.Add(this.txtApplicantCode);
            this.groupBox1.Controls.Add(this.lblApplicantName);
            this.groupBox1.Controls.Add(this.txtApplicantName);
            this.groupBox1.Controls.Add(this.lblApplicantAddress);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.txtApplicantAddress);
            this.groupBox1.Controls.Add(this.txtApplicantTel);
            this.groupBox1.Controls.Add(this.lblApplicantNational);
            this.groupBox1.Controls.Add(this.lblApplicantTel);
            this.groupBox1.Location = new System.Drawing.Point(5, 28);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(960, 95);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btnCreate
            // 
            this.btnCreate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCreate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCreate.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCreate.Location = new System.Drawing.Point(805, 416);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 23);
            this.btnCreate.TabIndex = 2;
            this.btnCreate.Text = "C&reate";
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // dataGridViewDisableCheckBoxColumn1
            // 
            this.dataGridViewDisableCheckBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewDisableCheckBoxColumn1.HeaderText = "";
            this.dataGridViewDisableCheckBoxColumn1.MinimumWidth = 30;
            this.dataGridViewDisableCheckBoxColumn1.Name = "dataGridViewDisableCheckBoxColumn1";
            this.dataGridViewDisableCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewDisableCheckBoxColumn1.Width = 30;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn1.FillWeight = 287.4251F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Applicant Code";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 120;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.Width = 120;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn2.FillWeight = 81.68714F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Applicant Name";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 200;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.Width = 200;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn3.FillWeight = 68.34335F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Address";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 200;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn3.Width = 200;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn4.FillWeight = 52.50527F;
            this.dataGridViewTextBoxColumn4.HeaderText = "National";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 200;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn4.Width = 200;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewTextBoxColumn5.FillWeight = 56.44538F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Tel";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 121;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewTextBoxColumn6.FillWeight = 53.59365F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Fax";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 116;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "NoChange";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Visible = false;
            this.dataGridViewTextBoxColumn7.Width = 83;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "SeqApplicant";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Visible = false;
            this.dataGridViewTextBoxColumn8.Width = 95;
            // 
            // frmLGListApplicant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(970, 451);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.dtgApplicantList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "frmLGListApplicant";
            this.Text = "List Applicant";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGListApplicant_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dtgApplicantList)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblApplicantCode;
        private System.Windows.Forms.TextBox txtApplicantCode;
        private System.Windows.Forms.TextBox txtApplicantName;
        private System.Windows.Forms.Label lblApplicantName;
        private System.Windows.Forms.TextBox txtApplicantAddress;
        private System.Windows.Forms.Label lblApplicantAddress;
        private System.Windows.Forms.TextBox txtApplicantNational;
        private System.Windows.Forms.Label lblApplicantNational;
        private System.Windows.Forms.TextBox txtApplicantTel;
        private System.Windows.Forms.Label lblApplicantTel;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dtgApplicantList;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbDeleteApplicant;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.ToolStripButton tsbUpdateApplicant;
        private System.Windows.Forms.Button btnCreate;
        private UserCtrl.DataGridViewDisableCheckBoxColumn colCheck;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApplicantCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApplicantName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApplicantAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApplicantNational;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApplicantTel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colApplicantFax;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNoChange;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSeqApplicant;
        private UserCtrl.DataGridViewDisableCheckBoxColumn dataGridViewDisableCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
    }
}