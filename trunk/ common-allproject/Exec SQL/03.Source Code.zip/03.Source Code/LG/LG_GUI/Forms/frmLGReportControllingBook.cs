﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: htkhiem $
 * $Date: 2013-01-16 14:30:00 +0700 (Wed, 16 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to report controlling book
 * for LG module.
 */

using System;
using System.Collections;
using System.Data;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Cpa.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Gui.Report;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGReportControllingBook : frmLGMaster
    {
        #region Global Variable
        //+ Bus
        private clsLGReportControllingBookBus lgReportControllingBookBus = new clsLGReportControllingBookBus();
        //For Reporting Controlling Book
        //+ Project Name
        private string m_ProjectName = clsLGConstant.LG_MODULE;
        //+ Data Source
        private string m_DataSource = "dtsReportControllingBook_tblReportControllingBook";
        //+ Template Name
        private string m_TemplateName = "_GUI\\REPORT\\rptReportControllingBook.rdlc";
        //+ Type
        private string lgType = String.Empty;
        //+ From Sequence
        private string sequenceFrom = String.Empty;
        //+ To Sequence
        private string sequenceTo = String.Empty;
        #endregion

        #region Constructor
        public frmLGReportControllingBook(string lgType, string sequenceFrom, string sequenceTo)
        {
            InitializeComponent();
            //Asign value
            this.lgType = lgType;
            this.sequenceFrom = sequenceFrom;
            this.sequenceTo = sequenceTo;
			_security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            _security.CheckAuthorizationOnScreen(this);
        }
        #endregion

        #region Event Method
        private void frmLGReportControllingBook_Load(object sender, EventArgs e)
        {
            try
            {
                //Declaration
                dtsReportControllingBook dtsReportCtrlBookObj = new dtsReportControllingBook();
                Hashtable htLGStatus = new Hashtable();
                //History Header
                clsLGLogBase logBase = new clsLGLogBase();
                logBase.ApplicationName = this.Text;
                logBase.UserID = clsUserInfo.UserNo.ToString();
                logBase.Action = (int)CommonValue.ActionType.Update;

                //Intialize htLGStatus
                htLGStatus.Add((clsLGConstant.LG_LG_STATUS_NEW.Split('-'))[0], (clsLGConstant.LG_LG_STATUS_NEW.Split('-'))[1]);
                htLGStatus.Add((clsLGConstant.LG_LG_STATUS_CORRECT.Split('-'))[0], (clsLGConstant.LG_LG_STATUS_CORRECT.Split('-'))[1]);
                htLGStatus.Add((clsLGConstant.LG_LG_STATUS_AMEND_UPDATE.Split('-'))[0], (clsLGConstant.LG_LG_STATUS_AMEND_UPDATE.Split('-'))[1]);
                htLGStatus.Add((clsLGConstant.LG_LG_STATUS_AMEND.Split('-'))[0], (clsLGConstant.LG_LG_STATUS_AMEND.Split('-'))[1]);
                
                //Set data
                DataTable dtReportCtrlBookObj = lgReportControllingBookBus.GetDataForReportControlingBook(lgType, sequenceFrom, sequenceTo);
                //No Transaction Found
                if (dtReportCtrlBookObj.Rows.Count == 0)
                {
                    clsLGMesageCollection.MessageNoTransactions();
                    this.Close();
                    return;
                }

                //Assign data to fields
                foreach (DataRow row in dtReportCtrlBookObj.Rows)
                {                    
                    dtsReportCtrlBookObj.tblReportControllingBook.Rows.Add(
                                                                                row["Seq"],
                                                                                row["RefNo"],
                                                                                htLGStatus[row["Status"].ToString()],
                                                                                row["Applicant"],
                                                                                row["Beneficiary"],
                                                                                DateTime.Parse(row["Appl"].ToString()).ToString(clsLGConstant.LG_FORMAT_YYYYMMDD),
                                                                                DateTime.Parse(row["Issuing"].ToString()).ToString(clsLGConstant.LG_FORMAT_YYYYMMDD),
                                                                                DateTime.Parse(row["Expiry"].ToString()).ToString(clsLGConstant.LG_FORMAT_YYYYMMDD),
                                                                                decimal.Parse(row["Duration"].ToString()).ToString(clsLGConstant.FORMAT_EXCEL_2_DECIMAL),                                                                                
                                                                                row["CCY"],
                                                                                decimal.Parse(row["AMT"].ToString()).ToString((row["CCY"].ToString().Equals(clsLGConstant.LG_CURRENCY_VND) 
                                                                                                                                || row["CCY"].ToString().Equals(clsLGConstant.LG_CURRENCY_JPY)) ? clsLGConstant.FORMAT_EXCEL_0_DECIMAL : clsLGConstant.FORMAT_EXCEL_2_DECIMAL),
                                                                                row["Rate"],
                                                                                row["CKR"],
                                                                                row["Maker"],
                                                                                row["Close"]
                                                                            ); 
                    //Log History
                    //There's changing
                    if (1 - int.Parse(row["FlagControlBook"].ToString()) > 0)
                    {
                        logBase.LstLogInformation.Clear();
                        logBase.Key = row["LGCode"] + " " + row["SubCode"];
                        clsLGLogInformation logInfo = new clsLGLogInformation();
                        logInfo.FieldName = "FlagControlBook";
                        logInfo.OldValue = "0";
                        logInfo.NewValue = "1";
                        logBase.LstLogInformation.Add(logInfo);
                        logBase.WirteLog(lgReportControllingBookBus.DAL);
                    }
                }                

                //Intialize reporting
                //+ Title
                Microsoft.Reporting.WinForms.ReportParameter rprameterReportTitle = new Microsoft.Reporting.WinForms.ReportParameter("ReportTitle", clsLGConstant.LG_REPORT_TITLE);
                Microsoft.Reporting.WinForms.ReportParameter rprameterLGType = new Microsoft.Reporting.WinForms.ReportParameter("LGType", lgType.Equals("1") ? clsLGConstant.LG_REPORT_LG_TYPE_PROPER : clsLGConstant.LG_REPORT_LG_TYPE_COUNTER);
                //+ 10 rows/page
                Microsoft.Reporting.WinForms.ReportParameter rprameterNumberOfRowsPerPage = new Microsoft.Reporting.WinForms.ReportParameter("NumRowsPerPage", clsLGConstant.LG_REPORT_NUMBER_OF_ROWS_PER_PAGES.ToString(), false);
                //+ Add parameters
                this.reportViewerReportControllingBook.LocalReport.SetParameters(new Microsoft.Reporting.WinForms.ReportParameter[] { rprameterReportTitle, rprameterLGType, rprameterNumberOfRowsPerPage });
                //+ Load report
                this.reportViewerReportControllingBook.ProcessingMode = Microsoft.Reporting.WinForms.ProcessingMode.Local;
                this.reportViewerReportControllingBook.LocalReport.ReportPath = AppDomain.CurrentDomain.BaseDirectory + m_ProjectName + m_TemplateName;
                this.reportViewerReportControllingBook.LocalReport.DataSources.Clear();
                this.reportViewerReportControllingBook.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource(m_DataSource, dtsReportCtrlBookObj.Tables[0]));
                this.reportViewerReportControllingBook.DocumentMapCollapsed = true;
                //Refresh reporting
                this.reportViewerReportControllingBook.RefreshReport();
                //Set Mode for ReportViewer
                this.reportViewerReportControllingBook.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);                
                
                //Commit data if successful
                lgReportControllingBookBus.Commit();
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                try
                {
                    lgReportControllingBookBus.RollBack();
                }
                catch (System.Exception) { }

                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                this.Close();
            }
        }
        #endregion
    }
}
