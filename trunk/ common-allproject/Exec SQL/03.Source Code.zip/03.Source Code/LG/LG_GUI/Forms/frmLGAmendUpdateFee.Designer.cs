﻿using UserCtrl;
namespace Phoenix.Lg.Gui.Forms
{
    partial class frmLGAmendUpdateFee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFlatFee = new UserCtrl.NumberOnlyTextBox();
            this.txtExchangeRate = new UserCtrl.NumberOnlyTextBox();
            this.txtSuggessFee = new UserCtrl.NumberOnlyTextBox();
            this.txtAmendFee = new UserCtrl.NumberOnlyTextBox();
            this.cbbCCY = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.cbbAccount = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // txtFlatFee
            // 
            this.txtFlatFee.CustomDecimal = 2;
            this.txtFlatFee.CustomLenght = 12;
            this.txtFlatFee.Location = new System.Drawing.Point(154, 12);
            this.txtFlatFee.Name = "txtFlatFee";
            this.txtFlatFee.NeedDecimal = true;
            this.txtFlatFee.Size = new System.Drawing.Size(185, 20);
            this.txtFlatFee.StringFormat = "#,0.00";
            this.txtFlatFee.TabIndex = 0;
            this.txtFlatFee.TextChanged += new System.EventHandler(this.txtFlatFee_TextChanged);
            // 
            // txtExchangeRate
            // 
            this.txtExchangeRate.CustomDecimal = 6;
            this.txtExchangeRate.CustomLenght = 9;
            this.txtExchangeRate.Enabled = false;
            this.txtExchangeRate.Location = new System.Drawing.Point(154, 38);
            this.txtExchangeRate.Name = "txtExchangeRate";
            this.txtExchangeRate.NeedDecimal = true;
            this.txtExchangeRate.Size = new System.Drawing.Size(185, 20);
            this.txtExchangeRate.StringFormat = "#,0.0000";
            this.txtExchangeRate.TabIndex = 1;
            this.txtExchangeRate.TextChanged += new System.EventHandler(this.txtExchangeRate_TextChanged);
            // 
            // txtSuggessFee
            // 
            this.txtSuggessFee.CustomDecimal = 2;
            this.txtSuggessFee.CustomLenght = 12;
            this.txtSuggessFee.Enabled = false;
            this.txtSuggessFee.Location = new System.Drawing.Point(154, 116);
            this.txtSuggessFee.Name = "txtSuggessFee";
            this.txtSuggessFee.NeedDecimal = true;
            this.txtSuggessFee.Size = new System.Drawing.Size(185, 20);
            this.txtSuggessFee.StringFormat = "#,0.00";
            this.txtSuggessFee.TabIndex = 4;
            // 
            // txtAmendFee
            // 
            this.txtAmendFee.CustomDecimal = 2;
            this.txtAmendFee.CustomLenght = 20;
            this.txtAmendFee.Location = new System.Drawing.Point(154, 142);
            this.txtAmendFee.Name = "txtAmendFee";
            this.txtAmendFee.NeedDecimal = true;
            this.txtAmendFee.Size = new System.Drawing.Size(185, 20);
            this.txtAmendFee.StringFormat = "#,0.00";
            this.txtAmendFee.TabIndex = 5;
            this.txtAmendFee.TextChanged += new System.EventHandler(this.txtAmendFee_TextChanged);
            // 
            // cbbCCY
            // 
            this.cbbCCY.FormattingEnabled = true;
            this.cbbCCY.Location = new System.Drawing.Point(154, 89);
            this.cbbCCY.Name = "cbbCCY";
            this.cbbCCY.Size = new System.Drawing.Size(185, 21);
            this.cbbCCY.TabIndex = 3;
            this.cbbCCY.SelectedIndexChanged += new System.EventHandler(this.cbbCCY_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Flat Fee (USD)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Exchange Rate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Charge Account";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Charge Account CCY";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Suggess Fee";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Amend Update Fee";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(81, 168);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(94, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(195, 168);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(94, 23);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cbbAccount
            // 
            this.cbbAccount.FormattingEnabled = true;
            this.cbbAccount.Location = new System.Drawing.Point(154, 62);
            this.cbbAccount.Name = "cbbAccount";
            this.cbbAccount.Size = new System.Drawing.Size(185, 21);
            this.cbbAccount.TabIndex = 2;
            this.cbbAccount.SelectedIndexChanged += new System.EventHandler(this.cbbAccount_SelectedIndexChanged);
            // 
            // frmLGAmendUpdateFee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 202);
            this.Controls.Add(this.cbbAccount);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbbCCY);
            this.Controls.Add(this.txtAmendFee);
            this.Controls.Add(this.txtSuggessFee);
            this.Controls.Add(this.txtExchangeRate);
            this.Controls.Add(this.txtFlatFee);
            this.Name = "frmLGAmendUpdateFee";
            this.Text = "Amend Update Fee";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGAmendUpdateFee_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private NumberOnlyTextBox txtFlatFee;
        private NumberOnlyTextBox txtExchangeRate;
        private NumberOnlyTextBox txtSuggessFee;
        private NumberOnlyTextBox txtAmendFee;
        private System.Windows.Forms.ComboBox cbbCCY;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cbbAccount;
    }
}