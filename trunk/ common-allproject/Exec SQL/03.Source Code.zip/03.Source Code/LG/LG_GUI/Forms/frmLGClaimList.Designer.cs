﻿using UserCtrl;
namespace Phoenix.Lg.Gui.Forms
{
	partial class frmLGClaimList
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCustomerName = new UserCtrl.DisableTextBox();
            this.txtBenificiaryName = new UserCtrl.DisableTextBox();
            this.txtCustomerCode = new UserCtrl.DisableTextBox();
            this.txtLGNo = new UserCtrl.DisableTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtgClaimList = new UserCtrl.TabOrderDatagridView();
            this.colNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colClaimedDate = new UserCtrl.ctrlLGCalendarColumn();
            this.colClaimedCCY = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colLGSubNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCurrentLGAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colClaimedAmount = new UserCtrl.TNumEditDataGridViewColumn();
            this.colPaid = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colClaimedPaymentDate = new UserCtrl.ctrlLGCalendarColumn();
            this.colRemark = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSeqLG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIsExist = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIsChange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIsDelete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgClaimList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRemove
            // 
            this.btnRemove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRemove.Location = new System.Drawing.Point(7, 19);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 1;
            this.btnRemove.Text = "&Remove";
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(793, 450);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(712, 450);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(9, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Benificiary Name";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(258, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Customer Code";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(480, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "Customer Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(9, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "LG No";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Format = "N0";
            dataGridViewCellStyle1.NullValue = null;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn1.FillWeight = 121.7501F;
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "No.";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.Width = 30;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn2.FillWeight = 168.7215F;
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "Claimed date";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "LG Sub No.";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "Current LG amount";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 120;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn5.Frozen = true;
            this.dataGridViewTextBoxColumn5.HeaderText = "Claimed amount";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Claimed payment date";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 117;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Remark";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 50;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerName.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCustomerName.ForeColor = System.Drawing.Color.Black;
            this.txtCustomerName.Location = new System.Drawing.Point(576, 15);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.ReadOnly = true;
            this.txtCustomerName.Size = new System.Drawing.Size(286, 20);
            this.txtCustomerName.TabIndex = 17;
            this.txtCustomerName.TabStop = false;
            this.txtCustomerName.Text = " ";
            // 
            // txtBenificiaryName
            // 
            this.txtBenificiaryName.BackColor = System.Drawing.SystemColors.Control;
            this.txtBenificiaryName.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtBenificiaryName.ForeColor = System.Drawing.Color.Black;
            this.txtBenificiaryName.Location = new System.Drawing.Point(103, 36);
            this.txtBenificiaryName.Name = "txtBenificiaryName";
            this.txtBenificiaryName.ReadOnly = true;
            this.txtBenificiaryName.Size = new System.Drawing.Size(356, 20);
            this.txtBenificiaryName.TabIndex = 17;
            this.txtBenificiaryName.TabStop = false;
            this.txtBenificiaryName.Text = " ";
            // 
            // txtCustomerCode
            // 
            this.txtCustomerCode.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerCode.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCustomerCode.ForeColor = System.Drawing.Color.Black;
            this.txtCustomerCode.Location = new System.Drawing.Point(349, 15);
            this.txtCustomerCode.Name = "txtCustomerCode";
            this.txtCustomerCode.ReadOnly = true;
            this.txtCustomerCode.Size = new System.Drawing.Size(110, 20);
            this.txtCustomerCode.TabIndex = 19;
            this.txtCustomerCode.TabStop = false;
            this.txtCustomerCode.Text = " ";
            // 
            // txtLGNo
            // 
            this.txtLGNo.BackColor = System.Drawing.SystemColors.Control;
            this.txtLGNo.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtLGNo.ForeColor = System.Drawing.Color.Black;
            this.txtLGNo.Location = new System.Drawing.Point(103, 15);
            this.txtLGNo.Name = "txtLGNo";
            this.txtLGNo.ReadOnly = true;
            this.txtLGNo.Size = new System.Drawing.Size(121, 20);
            this.txtLGNo.TabIndex = 18;
            this.txtLGNo.TabStop = false;
            this.txtLGNo.Text = " ";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.dtgClaimList);
            this.groupBox1.Controls.Add(this.btnRemove);
            this.groupBox1.Location = new System.Drawing.Point(9, 71);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(859, 373);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Claim";
            // 
            // dtgClaimList
            // 
            this.dtgClaimList.AllowUserToAddRows = false;
            this.dtgClaimList.AllowUserToDeleteRows = false;
            this.dtgClaimList.AllowUserToResizeColumns = false;
            this.dtgClaimList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgClaimList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgClaimList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgClaimList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dtgClaimList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgClaimList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colNo,
            this.colClaimedDate,
            this.colClaimedCCY,
            this.colLGSubNo,
            this.colCurrentLGAmount,
            this.colClaimedAmount,
            this.colPaid,
            this.colClaimedPaymentDate,
            this.colRemark,
            this.colSeqLG,
            this.colIsExist,
            this.colIsChange,
            this.colIsDelete});
            this.dtgClaimList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dtgClaimList.EnableHeadersVisualStyles = false;
            this.dtgClaimList.Location = new System.Drawing.Point(7, 48);
            this.dtgClaimList.MultiSelect = false;
            this.dtgClaimList.Name = "dtgClaimList";
            this.dtgClaimList.RowHeadersVisible = false;
            this.dtgClaimList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgClaimList.Size = new System.Drawing.Size(843, 319);
            this.dtgClaimList.TabIndex = 7;
            this.dtgClaimList.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgClaimList_CellValueChanged);
            this.dtgClaimList.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgClaimList_ColumnHeaderMouseClick);
            this.dtgClaimList.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dtgClaimList_CellFormatting);
            this.dtgClaimList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgClaimList_CellEndEdit);
            this.dtgClaimList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgClaimList_CellClick);
            this.dtgClaimList.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dtgClaimList_RowsRemoved);
            // 
            // colNo
            // 
            this.colNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colNo.DefaultCellStyle = dataGridViewCellStyle4;
            this.colNo.FillWeight = 287.4251F;
            this.colNo.HeaderText = "No";
            this.colNo.MinimumWidth = 30;
            this.colNo.Name = "colNo";
            this.colNo.ReadOnly = true;
            this.colNo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colNo.Width = 30;
            // 
            // colClaimedDate
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Format = "yyyy/MM/dd";
            this.colClaimedDate.DefaultCellStyle = dataGridViewCellStyle5;
            this.colClaimedDate.FillWeight = 81.68714F;
            this.colClaimedDate.HeaderText = "Claimed Date";
            this.colClaimedDate.MinimumWidth = 100;
            this.colClaimedDate.Name = "colClaimedDate";
            this.colClaimedDate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colClaimedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colClaimedCCY
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colClaimedCCY.DefaultCellStyle = dataGridViewCellStyle6;
            this.colClaimedCCY.FillWeight = 68.34335F;
            this.colClaimedCCY.HeaderText = "Claimed CCY";
            this.colClaimedCCY.MinimumWidth = 50;
            this.colClaimedCCY.Name = "colClaimedCCY";
            this.colClaimedCCY.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colClaimedCCY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colClaimedCCY.Width = 93;
            // 
            // colLGSubNo
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colLGSubNo.DefaultCellStyle = dataGridViewCellStyle7;
            this.colLGSubNo.FillWeight = 52.50527F;
            this.colLGSubNo.HeaderText = "LG Sub No";
            this.colLGSubNo.MinimumWidth = 50;
            this.colLGSubNo.Name = "colLGSubNo";
            this.colLGSubNo.ReadOnly = true;
            this.colLGSubNo.Width = 85;
            // 
            // colCurrentLGAmount
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "#,###.#####";
            dataGridViewCellStyle8.NullValue = "0";
            this.colCurrentLGAmount.DefaultCellStyle = dataGridViewCellStyle8;
            this.colCurrentLGAmount.FillWeight = 56.44538F;
            this.colCurrentLGAmount.HeaderText = "Current LG Amount";
            this.colCurrentLGAmount.MinimumWidth = 30;
            this.colCurrentLGAmount.Name = "colCurrentLGAmount";
            this.colCurrentLGAmount.ReadOnly = true;
            this.colCurrentLGAmount.Width = 122;
            // 
            // colClaimedAmount
            // 
            this.colClaimedAmount.DecimalLength = 5;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N5";
            dataGridViewCellStyle9.NullValue = "0";
            this.colClaimedAmount.DefaultCellStyle = dataGridViewCellStyle9;
            this.colClaimedAmount.FillWeight = 53.59365F;
            this.colClaimedAmount.HeaderText = "Claimed Amount";
            this.colClaimedAmount.MaxInputLength = 13;
            this.colClaimedAmount.MinimumWidth = 50;
            this.colClaimedAmount.Name = "colClaimedAmount";
            this.colClaimedAmount.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colClaimedAmount.Width = 108;
            // 
            // colPaid
            // 
            this.colPaid.HeaderText = "Paid";
            this.colPaid.Name = "colPaid";
            this.colPaid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colPaid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colPaid.Width = 53;
            // 
            // colClaimedPaymentDate
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.Format = "yyyy/MM/dd";
            this.colClaimedPaymentDate.DefaultCellStyle = dataGridViewCellStyle10;
            this.colClaimedPaymentDate.HeaderText = "Claimed Payment Date";
            this.colClaimedPaymentDate.MinimumWidth = 120;
            this.colClaimedPaymentDate.Name = "colClaimedPaymentDate";
            this.colClaimedPaymentDate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colClaimedPaymentDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colClaimedPaymentDate.Width = 139;
            // 
            // colRemark
            // 
            this.colRemark.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colRemark.DefaultCellStyle = dataGridViewCellStyle11;
            this.colRemark.HeaderText = "Remark";
            this.colRemark.MaxInputLength = 200;
            this.colRemark.MinimumWidth = 150;
            this.colRemark.Name = "colRemark";
            // 
            // colSeqLG
            // 
            this.colSeqLG.HeaderText = "SeqLG";
            this.colSeqLG.Name = "colSeqLG";
            this.colSeqLG.Visible = false;
            this.colSeqLG.Width = 65;
            // 
            // colIsExist
            // 
            this.colIsExist.HeaderText = "IsExist";
            this.colIsExist.Name = "colIsExist";
            this.colIsExist.Visible = false;
            this.colIsExist.Width = 62;
            // 
            // colIsChange
            // 
            this.colIsChange.HeaderText = "IsChange";
            this.colIsChange.Name = "colIsChange";
            this.colIsChange.Visible = false;
            this.colIsChange.Width = 77;
            // 
            // colIsDelete
            // 
            this.colIsDelete.HeaderText = "IsDelete";
            this.colIsDelete.Name = "colIsDelete";
            this.colIsDelete.Visible = false;
            this.colIsDelete.Width = 71;
            // 
            // frmLGClaimList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(877, 483);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.txtBenificiaryName);
            this.Controls.Add(this.txtCustomerCode);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtLGNo);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "frmLGClaimList";
            this.Text = "Claim List";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGClaimList_FormClosing);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgClaimList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnRemove;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnSave;
		private UserCtrl.DisableTextBox txtBenificiaryName;
		private UserCtrl.DisableTextBox txtCustomerCode;
		private System.Windows.Forms.Label label3;
        private UserCtrl.DisableTextBox txtLGNo;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
        private UserCtrl.DisableTextBox txtCustomerName;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
		private System.Windows.Forms.GroupBox groupBox1;
        private TabOrderDatagridView dtgClaimList;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNo;
        private ctrlLGCalendarColumn colClaimedDate;
        private System.Windows.Forms.DataGridViewComboBoxColumn colClaimedCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLGSubNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCurrentLGAmount;
        private TNumEditDataGridViewColumn colClaimedAmount;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colPaid;
        private ctrlLGCalendarColumn colClaimedPaymentDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRemark;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSeqLG;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIsExist;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIsChange;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIsDelete;
	}
}