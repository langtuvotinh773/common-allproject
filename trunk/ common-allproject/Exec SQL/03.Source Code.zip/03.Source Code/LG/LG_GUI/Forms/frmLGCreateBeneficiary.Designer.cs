﻿namespace Phoenix.Lg.Gui.Forms
{
	partial class frmLGCreateBeneficiary 
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBeneficiaryCode = new System.Windows.Forms.Label();
            this.txtBeneficiaryName = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryName = new System.Windows.Forms.Label();
            this.txtBeneficiaryAddress = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryAddress = new System.Windows.Forms.Label();
            this.txtBeneficiaryNational = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryNationality = new System.Windows.Forms.Label();
            this.txtBeneficiaryTel = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryTel = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtBeneficiaryFax = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryFax = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtBeneficiaryCode = new UserCtrl.DisableTextBox();
            this.SuspendLayout();
            // 
            // lblBeneficiaryCode
            // 
            this.lblBeneficiaryCode.AutoSize = true;
            this.lblBeneficiaryCode.Location = new System.Drawing.Point(14, 9);
            this.lblBeneficiaryCode.Name = "lblBeneficiaryCode";
            this.lblBeneficiaryCode.Size = new System.Drawing.Size(87, 13);
            this.lblBeneficiaryCode.TabIndex = 0;
            this.lblBeneficiaryCode.Text = "Beneficiary Code";
            // 
            // txtBeneficiaryName
            // 
            this.txtBeneficiaryName.Location = new System.Drawing.Point(128, 28);
            this.txtBeneficiaryName.Name = "txtBeneficiaryName";
            this.txtBeneficiaryName.Size = new System.Drawing.Size(370, 20);
            this.txtBeneficiaryName.TabIndex = 1;
            // 
            // lblBeneficiaryName
            // 
            this.lblBeneficiaryName.AutoSize = true;
            this.lblBeneficiaryName.Location = new System.Drawing.Point(14, 31);
            this.lblBeneficiaryName.Name = "lblBeneficiaryName";
            this.lblBeneficiaryName.Size = new System.Drawing.Size(90, 13);
            this.lblBeneficiaryName.TabIndex = 2;
            this.lblBeneficiaryName.Text = "Beneficiary Name";
            // 
            // txtBeneficiaryAddress
            // 
            this.txtBeneficiaryAddress.Location = new System.Drawing.Point(128, 49);
            this.txtBeneficiaryAddress.Name = "txtBeneficiaryAddress";
            this.txtBeneficiaryAddress.Size = new System.Drawing.Size(370, 20);
            this.txtBeneficiaryAddress.TabIndex = 2;
            // 
            // lblBeneficiaryAddress
            // 
            this.lblBeneficiaryAddress.AutoSize = true;
            this.lblBeneficiaryAddress.Location = new System.Drawing.Point(14, 52);
            this.lblBeneficiaryAddress.Name = "lblBeneficiaryAddress";
            this.lblBeneficiaryAddress.Size = new System.Drawing.Size(100, 13);
            this.lblBeneficiaryAddress.TabIndex = 4;
            this.lblBeneficiaryAddress.Text = "Beneficiary Address";
            // 
            // txtBeneficiaryNational
            // 
            this.txtBeneficiaryNational.Location = new System.Drawing.Point(128, 70);
            this.txtBeneficiaryNational.Name = "txtBeneficiaryNational";
            this.txtBeneficiaryNational.Size = new System.Drawing.Size(370, 20);
            this.txtBeneficiaryNational.TabIndex = 3;
            // 
            // lblBeneficiaryNationality
            // 
            this.lblBeneficiaryNationality.AutoSize = true;
            this.lblBeneficiaryNationality.Location = new System.Drawing.Point(14, 73);
            this.lblBeneficiaryNationality.Name = "lblBeneficiaryNationality";
            this.lblBeneficiaryNationality.Size = new System.Drawing.Size(111, 13);
            this.lblBeneficiaryNationality.TabIndex = 6;
            this.lblBeneficiaryNationality.Text = "Beneficiary Nationality";
            // 
            // txtBeneficiaryTel
            // 
            this.txtBeneficiaryTel.Location = new System.Drawing.Point(128, 91);
            this.txtBeneficiaryTel.Name = "txtBeneficiaryTel";
            this.txtBeneficiaryTel.Size = new System.Drawing.Size(370, 20);
            this.txtBeneficiaryTel.TabIndex = 4;
            // 
            // lblBeneficiaryTel
            // 
            this.lblBeneficiaryTel.AutoSize = true;
            this.lblBeneficiaryTel.Location = new System.Drawing.Point(14, 94);
            this.lblBeneficiaryTel.Name = "lblBeneficiaryTel";
            this.lblBeneficiaryTel.Size = new System.Drawing.Size(77, 13);
            this.lblBeneficiaryTel.TabIndex = 8;
            this.lblBeneficiaryTel.Text = "Beneficiary Tel";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(342, 138);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtBeneficiaryFax
            // 
            this.txtBeneficiaryFax.Location = new System.Drawing.Point(128, 112);
            this.txtBeneficiaryFax.Name = "txtBeneficiaryFax";
            this.txtBeneficiaryFax.Size = new System.Drawing.Size(370, 20);
            this.txtBeneficiaryFax.TabIndex = 5;
            // 
            // lblBeneficiaryFax
            // 
            this.lblBeneficiaryFax.AutoSize = true;
            this.lblBeneficiaryFax.Location = new System.Drawing.Point(14, 115);
            this.lblBeneficiaryFax.Name = "lblBeneficiaryFax";
            this.lblBeneficiaryFax.Size = new System.Drawing.Size(79, 13);
            this.lblBeneficiaryFax.TabIndex = 17;
            this.lblBeneficiaryFax.Text = "Beneficiary Fax";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(423, 138);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtBeneficiaryCode
            // 
            this.txtBeneficiaryCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtBeneficiaryCode.ForeColor = System.Drawing.Color.Black;
            this.txtBeneficiaryCode.Location = new System.Drawing.Point(128, 7);
            this.txtBeneficiaryCode.Name = "txtBeneficiaryCode";
            this.txtBeneficiaryCode.ReadOnly = true;
            this.txtBeneficiaryCode.Size = new System.Drawing.Size(370, 20);
            this.txtBeneficiaryCode.TabIndex = 0;
            this.txtBeneficiaryCode.TabStop = false;
            // 
            // frmLGCreateBeneficiary
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(510, 173);
            this.Controls.Add(this.txtBeneficiaryCode);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txtBeneficiaryFax);
            this.Controls.Add(this.lblBeneficiaryFax);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtBeneficiaryTel);
            this.Controls.Add(this.lblBeneficiaryTel);
            this.Controls.Add(this.txtBeneficiaryNational);
            this.Controls.Add(this.lblBeneficiaryNationality);
            this.Controls.Add(this.txtBeneficiaryAddress);
            this.Controls.Add(this.lblBeneficiaryAddress);
            this.Controls.Add(this.txtBeneficiaryName);
            this.Controls.Add(this.lblBeneficiaryName);
            this.Controls.Add(this.lblBeneficiaryCode);
            this.Name = "frmLGCreateBeneficiary";
            this.Text = "Create Beneficiary";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGCreateBeneficiary_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.Label lblBeneficiaryCode;
        private System.Windows.Forms.TextBox txtBeneficiaryName;
        private System.Windows.Forms.Label lblBeneficiaryName;
        private System.Windows.Forms.TextBox txtBeneficiaryAddress;
        private System.Windows.Forms.Label lblBeneficiaryAddress;
        private System.Windows.Forms.TextBox txtBeneficiaryNational;
        private System.Windows.Forms.Label lblBeneficiaryNationality;
        private System.Windows.Forms.TextBox txtBeneficiaryTel;
        private System.Windows.Forms.Label lblBeneficiaryTel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtBeneficiaryFax;
        private System.Windows.Forms.Label lblBeneficiaryFax;
        private System.Windows.Forms.Button btnClose;
		private UserCtrl.DisableTextBox txtBeneficiaryCode;
    }
}