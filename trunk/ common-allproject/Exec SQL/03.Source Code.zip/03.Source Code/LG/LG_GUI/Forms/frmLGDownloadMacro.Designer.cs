﻿namespace Phoenix.Lg.Gui.Forms
{
    partial class frmLGDownloadMacro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.lblLGNo = new System.Windows.Forms.Label();
			this.txtLGNo = new System.Windows.Forms.TextBox();
			this.cbbType = new System.Windows.Forms.ComboBox();
			this.lblType = new System.Windows.Forms.Label();
			this.btnPrint = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblLGNo
			// 
			this.lblLGNo.AutoSize = true;
			this.lblLGNo.Location = new System.Drawing.Point(9, 19);
			this.lblLGNo.Name = "lblLGNo";
			this.lblLGNo.Size = new System.Drawing.Size(38, 13);
			this.lblLGNo.TabIndex = 24;
			this.lblLGNo.Text = "LG No";
			// 
			// txtLGNo
			// 
			this.txtLGNo.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.txtLGNo.Location = new System.Drawing.Point(74, 12);
			this.txtLGNo.Name = "txtLGNo";
			this.txtLGNo.Size = new System.Drawing.Size(219, 20);
			this.txtLGNo.TabIndex = 0;
			this.txtLGNo.Text = "1000058-00";
			this.txtLGNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// cbbType
			// 
			this.cbbType.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.cbbType.FormattingEnabled = true;
			this.cbbType.Location = new System.Drawing.Point(74, 34);
			this.cbbType.Name = "cbbType";
			this.cbbType.Size = new System.Drawing.Size(219, 21);
			this.cbbType.TabIndex = 1;
			// 
			// lblType
			// 
			this.lblType.AutoSize = true;
			this.lblType.Location = new System.Drawing.Point(9, 41);
			this.lblType.Name = "lblType";
			this.lblType.Size = new System.Drawing.Size(31, 13);
			this.lblType.TabIndex = 34;
			this.lblType.Text = "Type";
			// 
			// btnPrint
			// 
			this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (246)))), ((int) (((byte) (247)))), ((int) (((byte) (253)))));
			this.btnPrint.Location = new System.Drawing.Point(137, 68);
			this.btnPrint.Name = "btnPrint";
			this.btnPrint.Size = new System.Drawing.Size(75, 23);
			this.btnPrint.TabIndex = 2;
			this.btnPrint.Text = "Download";
			this.btnPrint.UseVisualStyleBackColor = false;
			// 
			// btnCancel
			// 
			this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (246)))), ((int) (((byte) (247)))), ((int) (((byte) (253)))));
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(218, 68);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 23);
			this.btnCancel.TabIndex = 3;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = false;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// frmLGDownloadMacro
			// 
			this.AcceptButton = this.btnPrint;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (224)))), ((int) (((byte) (223)))), ((int) (((byte) (227)))));
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(302, 103);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnPrint);
			this.Controls.Add(this.cbbType);
			this.Controls.Add(this.lblType);
			this.Controls.Add(this.lblLGNo);
			this.Controls.Add(this.txtLGNo);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmLGDownloadMacro";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Download Macro";
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLGNo;
        private System.Windows.Forms.TextBox txtLGNo;
        private System.Windows.Forms.ComboBox cbbType;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnCancel;
    }
}