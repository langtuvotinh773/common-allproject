﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-01-16 14:30:00 +0700 (Wed, 16 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to management fee collection
 * for LG module.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGListOfFeeCollection : frmLGMaster
    {
        #region Variables
        private clsLGBus m_LGBus = null;
        private clsLGFeeCollectionBus m_FeeCollectionBus = null;
        private DateTime m_ReceivedDateFrom;
        private DateTime m_ReceivedDateTo;
        private DateTime m_ValueDateFrom;
        private DateTime m_ValueDateTo;
        private DateTime m_ActualClaimedDateFrom;
        private DateTime m_ActualClaimedDateTo;
        private string m_CustomerCode;
        private string m_CustomerName;
        private string m_LGNo;
        private string m_GLCode;
        private string m_Currency;
        private string m_GuaranteeType;
        private string m_FeeType;

        private ArrayList m_arrFeeType = new ArrayList();
        
        #endregion

        #region Contructors
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmLGListOfFeeCollection()
        {
            try
            {
                InitializeComponent();
                base.SetFormStyleCommon();
                SetFormStyle();
                //set vale datetimepicker on form
                SetCurrentDateForDateTimePicker();
                m_LGBus = new clsLGBus();
                m_FeeCollectionBus = new clsLGFeeCollectionBus();
                //Fill data to combobox
                clsLGCommonFunction.FillComboboxData(m_LGBus.GetListGuaranteeType, cbbGuaranteeType);
                clsLGCommonFunction.FillComboboxData(m_LGBus.GetListGLType, cbbGLCode);
                clsLGCommonFunction.FillComboboxData(m_LGBus.GetListCurrency, cbbCurrency);
                clsLGCommonFunction.FillComboboxData(m_LGBus.GetListFeeType, cbbFeeType);
                //Get list fee type from table parameter
                m_arrFeeType = m_LGBus.GetListFeeType();
				
				_security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }
        #endregion

        #region Event Functions


        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        /// <summary>
        /// Search LG list to the input conditions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                //fill data to grid Fee Collection
                FillData();
                //if count of row = 0 to show message 'No transaction found'
                if (dtgLGList.Rows.Count == 0)
                {
                    clsLGMesageCollection.MessageNoTransactions();
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        #endregion

        #region Private Functions
        /// <summary>
        /// Set form style
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void SetFormStyle()
        {
            txtCustomerCode.MaxLength = clsLGConstant.LENGTH_CUSTOMER_CODE;
            txtCustomerName.MaxLength = clsLGConstant.LENGTH_CUSTOMER_NAME;
            txtLGNo.MaxLength = clsLGConstant.LENGTH_LG_CODE;
        }

        /// <summary>
        /// Set Current Date for DateTimePicker on form
        /// </summary>
        /// @cond
        /// Author: phuong Lap Co
        /// @endcond
        private void SetCurrentDateForDateTimePicker()
        {
            dtpReceivedDateForm.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            dtpReceivedDateTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            dtpValueDateFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            dtpValueDateTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            dtpActualClaimedDateFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            dtpActualClaimedDateTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            dtpReceivedDateForm.Text = String.Empty;
            dtpReceivedDateTo.Text = String.Empty;
            dtpValueDateFrom.Text = String.Empty;
            dtpValueDateTo.Text = String.Empty;
            dtpActualClaimedDateFrom.Text = String.Empty;
            dtpActualClaimedDateTo.Text = String.Empty;
        }


        /// <summary>
        /// Get Data for Search Event
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataForSearch()
        {
            m_ReceivedDateFrom = string.IsNullOrEmpty(dtpReceivedDateForm.Text.Trim()) ? clsLGConstant.MIN_DATE_SERVER : dtpReceivedDateForm.Value;
            m_ReceivedDateTo = string.IsNullOrEmpty(dtpReceivedDateTo.Text.Trim()) ? clsLGConstant.MAX_DATE_SERVER : dtpReceivedDateTo.Value;
            m_ValueDateFrom = string.IsNullOrEmpty(dtpValueDateFrom.Text.Trim()) ? clsLGConstant.MIN_DATE_SERVER : dtpValueDateFrom.Value;
            m_ValueDateTo = string.IsNullOrEmpty(dtpValueDateTo.Text.Trim()) ? clsLGConstant.MAX_DATE_SERVER : dtpValueDateTo.Value;
            m_ActualClaimedDateFrom = string.IsNullOrEmpty(dtpActualClaimedDateFrom.Text.Trim()) ? clsLGConstant.MIN_DATE_SERVER : dtpActualClaimedDateFrom.Value;
            m_ActualClaimedDateTo = string.IsNullOrEmpty(dtpActualClaimedDateTo.Text.Trim()) ? clsLGConstant.MAX_DATE_SERVER : dtpActualClaimedDateTo.Value;
            m_CustomerCode = txtCustomerCode.Text.Trim();
            m_CustomerName = txtCustomerName.Text.Trim();
            m_LGNo = txtLGNo.Text.Trim();
            m_GLCode = cbbGLCode.SelectedValue.ToString();
            m_Currency = cbbCurrency.SelectedValue.ToString();
            m_GuaranteeType = cbbGuaranteeType.SelectedValue.ToString();
            m_FeeType = cbbFeeType.SelectedValue.ToString();
        }

        /// <summary>
        /// Fill data by search conditions on form
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillData()
        {
            //clear data on datagridview            
            dtgLGList.Rows.Clear();
            //get data on form for search
            GetDataForSearch();
            //get list fee collection by search conditions from database
            List<clsLGFeeCollectionDTO> lst = m_FeeCollectionBus.GetListFeeCollection(m_ReceivedDateFrom, m_ReceivedDateTo, m_ValueDateFrom, m_ValueDateTo,
                m_ActualClaimedDateFrom, m_ActualClaimedDateTo, m_CustomerCode, m_CustomerName, m_LGNo, m_GLCode,
                m_Currency, m_GuaranteeType, m_FeeType);

            if (lst.Count == 0)
            {
                return;
            }

            //Fill data into DataGridView Fee Collection
            for (int i = 0; i < lst.Count; i++)
            {
                dtgLGList.Rows.Add(lst[i].CustomerCode, lst[i].CustomerName, lst[i].LGNo,
                    clsLGCommonFunction.GetDisplay(m_arrFeeType, lst[i].FeeType), lst[i].FeeFormatCurrency, lst[i].FeeCurrency,
                    lst[i].ReceivedDate);
            }
        }

        #endregion

    }
}