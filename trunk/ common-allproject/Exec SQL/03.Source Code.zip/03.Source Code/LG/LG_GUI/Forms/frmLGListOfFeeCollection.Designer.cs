﻿namespace Phoenix.Lg.Gui.Forms
{
    partial class frmLGListOfFeeCollection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtgLGList = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblLGNo = new System.Windows.Forms.Label();
            this.txtLGNo = new System.Windows.Forms.TextBox();
            this.lblCustomerCode = new System.Windows.Forms.Label();
            this.txtCustomerCode = new System.Windows.Forms.TextBox();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.cbbGLCode = new System.Windows.Forms.ComboBox();
            this.lblGLCode = new System.Windows.Forms.Label();
            this.cbbCurrency = new System.Windows.Forms.ComboBox();
            this.lblCurrency = new System.Windows.Forms.Label();
            this.dtpReceivedDateForm = new UserCtrl.BlankCalendar();
            this.lblReceivedDate = new System.Windows.Forms.Label();
            this.dtpReceivedDateTo = new UserCtrl.BlankCalendar();
            this.label9 = new System.Windows.Forms.Label();
            this.cbbGuaranteeType = new System.Windows.Forms.ComboBox();
            this.lblGuaranteeType = new System.Windows.Forms.Label();
            this.dtpValueDateTo = new UserCtrl.BlankCalendar();
            this.lblValueDate = new System.Windows.Forms.Label();
            this.dtpValueDateFrom = new UserCtrl.BlankCalendar();
            this.dtpActualClaimedDateTo = new UserCtrl.BlankCalendar();
            this.lblActualClaimedDate = new System.Windows.Forms.Label();
            this.dtpActualClaimedDateFrom = new UserCtrl.BlankCalendar();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbFeeType = new System.Windows.Forms.ComboBox();
            this.colCustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLGNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFeeType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFeeCurrency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReceivedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgLGList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(775, 98);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 14;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtgLGList
            // 
            this.dtgLGList.AllowUserToAddRows = false;
            this.dtgLGList.AllowUserToDeleteRows = false;
            this.dtgLGList.AllowUserToResizeColumns = false;
            this.dtgLGList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgLGList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgLGList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgLGList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgLGList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgLGList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCustomerCode,
            this.colCustomerName,
            this.colLGNo,
            this.colFeeType,
            this.colFee,
            this.colFeeCurrency,
            this.colReceivedDate});
            this.dtgLGList.Location = new System.Drawing.Point(8, 129);
            this.dtgLGList.Name = "dtgLGList";
            this.dtgLGList.ReadOnly = true;
            this.dtgLGList.RowHeadersVisible = false;
            this.dtgLGList.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgLGList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgLGList.Size = new System.Drawing.Size(842, 379);
            this.dtgLGList.TabIndex = 15;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(774, 513);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 16;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblLGNo
            // 
            this.lblLGNo.AutoSize = true;
            this.lblLGNo.Location = new System.Drawing.Point(14, 79);
            this.lblLGNo.Name = "lblLGNo";
            this.lblLGNo.Size = new System.Drawing.Size(38, 13);
            this.lblLGNo.TabIndex = 22;
            this.lblLGNo.Text = "LG No";
            // 
            // txtLGNo
            // 
            this.txtLGNo.Location = new System.Drawing.Point(132, 76);
            this.txtLGNo.Name = "txtLGNo";
            this.txtLGNo.Size = new System.Drawing.Size(114, 20);
            this.txtLGNo.TabIndex = 9;
            // 
            // lblCustomerCode
            // 
            this.lblCustomerCode.AutoSize = true;
            this.lblCustomerCode.Location = new System.Drawing.Point(14, 58);
            this.lblCustomerCode.Name = "lblCustomerCode";
            this.lblCustomerCode.Size = new System.Drawing.Size(79, 13);
            this.lblCustomerCode.TabIndex = 24;
            this.lblCustomerCode.Text = "Customer Code";
            // 
            // txtCustomerCode
            // 
            this.txtCustomerCode.Location = new System.Drawing.Point(132, 55);
            this.txtCustomerCode.Name = "txtCustomerCode";
            this.txtCustomerCode.Size = new System.Drawing.Size(114, 20);
            this.txtCustomerCode.TabIndex = 7;
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(427, 56);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(82, 13);
            this.lblCustomerName.TabIndex = 26;
            this.lblCustomerName.Text = "Customer Name";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(515, 53);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(335, 20);
            this.txtCustomerName.TabIndex = 8;
            // 
            // cbbGLCode
            // 
            this.cbbGLCode.FormattingEnabled = true;
            this.cbbGLCode.Location = new System.Drawing.Point(515, 75);
            this.cbbGLCode.Name = "cbbGLCode";
            this.cbbGLCode.Size = new System.Drawing.Size(114, 21);
            this.cbbGLCode.TabIndex = 10;
            // 
            // lblGLCode
            // 
            this.lblGLCode.AutoSize = true;
            this.lblGLCode.Location = new System.Drawing.Point(427, 77);
            this.lblGLCode.Name = "lblGLCode";
            this.lblGLCode.Size = new System.Drawing.Size(49, 13);
            this.lblGLCode.TabIndex = 32;
            this.lblGLCode.Text = "GL Code";
            // 
            // cbbCurrency
            // 
            this.cbbCurrency.FormattingEnabled = true;
            this.cbbCurrency.Location = new System.Drawing.Point(741, 74);
            this.cbbCurrency.Name = "cbbCurrency";
            this.cbbCurrency.Size = new System.Drawing.Size(109, 21);
            this.cbbCurrency.TabIndex = 11;
            // 
            // lblCurrency
            // 
            this.lblCurrency.AutoSize = true;
            this.lblCurrency.Location = new System.Drawing.Point(680, 80);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(28, 13);
            this.lblCurrency.TabIndex = 34;
            this.lblCurrency.Text = "CCY";
            // 
            // dtpReceivedDateForm
            // 
            this.dtpReceivedDateForm.CustomFormat = "yyyy/MM/dd";
            this.dtpReceivedDateForm.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpReceivedDateForm.Location = new System.Drawing.Point(132, 11);
            this.dtpReceivedDateForm.Name = "dtpReceivedDateForm";
            this.dtpReceivedDateForm.Size = new System.Drawing.Size(114, 20);
            this.dtpReceivedDateForm.TabIndex = 1;
            this.dtpReceivedDateForm.Value = new System.DateTime(2013, 3, 28, 15, 29, 30, 325);
            // 
            // lblReceivedDate
            // 
            this.lblReceivedDate.AutoSize = true;
            this.lblReceivedDate.Location = new System.Drawing.Point(14, 15);
            this.lblReceivedDate.Name = "lblReceivedDate";
            this.lblReceivedDate.Size = new System.Drawing.Size(79, 13);
            this.lblReceivedDate.TabIndex = 38;
            this.lblReceivedDate.Text = "Received Date";
            // 
            // dtpReceivedDateTo
            // 
            this.dtpReceivedDateTo.CustomFormat = "yyyy/MM/dd";
            this.dtpReceivedDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpReceivedDateTo.Location = new System.Drawing.Point(264, 11);
            this.dtpReceivedDateTo.Name = "dtpReceivedDateTo";
            this.dtpReceivedDateTo.Size = new System.Drawing.Size(109, 20);
            this.dtpReceivedDateTo.TabIndex = 2;
            this.dtpReceivedDateTo.Value = new System.DateTime(2013, 3, 28, 15, 29, 30, 325);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(249, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 13);
            this.label9.TabIndex = 40;
            this.label9.Text = "~";
            // 
            // cbbGuaranteeType
            // 
            this.cbbGuaranteeType.FormattingEnabled = true;
            this.cbbGuaranteeType.Location = new System.Drawing.Point(132, 98);
            this.cbbGuaranteeType.Name = "cbbGuaranteeType";
            this.cbbGuaranteeType.Size = new System.Drawing.Size(114, 21);
            this.cbbGuaranteeType.TabIndex = 12;
            // 
            // lblGuaranteeType
            // 
            this.lblGuaranteeType.AutoSize = true;
            this.lblGuaranteeType.Location = new System.Drawing.Point(14, 101);
            this.lblGuaranteeType.Name = "lblGuaranteeType";
            this.lblGuaranteeType.Size = new System.Drawing.Size(84, 13);
            this.lblGuaranteeType.TabIndex = 41;
            this.lblGuaranteeType.Text = "Guarantee Type";
            // 
            // dtpValueDateTo
            // 
            this.dtpValueDateTo.CustomFormat = "yyyy/MM/dd";
            this.dtpValueDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpValueDateTo.Location = new System.Drawing.Point(641, 10);
            this.dtpValueDateTo.Name = "dtpValueDateTo";
            this.dtpValueDateTo.Size = new System.Drawing.Size(109, 20);
            this.dtpValueDateTo.TabIndex = 4;
            this.dtpValueDateTo.Value = new System.DateTime(2013, 3, 28, 15, 29, 30, 325);
            // 
            // lblValueDate
            // 
            this.lblValueDate.AutoSize = true;
            this.lblValueDate.Location = new System.Drawing.Point(427, 14);
            this.lblValueDate.Name = "lblValueDate";
            this.lblValueDate.Size = new System.Drawing.Size(60, 13);
            this.lblValueDate.TabIndex = 44;
            this.lblValueDate.Text = "Value Date";
            // 
            // dtpValueDateFrom
            // 
            this.dtpValueDateFrom.CustomFormat = "yyyy/MM/dd";
            this.dtpValueDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpValueDateFrom.Location = new System.Drawing.Point(515, 10);
            this.dtpValueDateFrom.Name = "dtpValueDateFrom";
            this.dtpValueDateFrom.Size = new System.Drawing.Size(109, 20);
            this.dtpValueDateFrom.TabIndex = 3;
            this.dtpValueDateFrom.Value = new System.DateTime(2013, 3, 28, 15, 29, 30, 325);
            // 
            // dtpActualClaimedDateTo
            // 
            this.dtpActualClaimedDateTo.CustomFormat = "yyyy/MM/dd";
            this.dtpActualClaimedDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpActualClaimedDateTo.Location = new System.Drawing.Point(265, 33);
            this.dtpActualClaimedDateTo.Name = "dtpActualClaimedDateTo";
            this.dtpActualClaimedDateTo.Size = new System.Drawing.Size(109, 20);
            this.dtpActualClaimedDateTo.TabIndex = 6;
            this.dtpActualClaimedDateTo.Value = new System.DateTime(2013, 3, 28, 15, 29, 30, 325);
            // 
            // lblActualClaimedDate
            // 
            this.lblActualClaimedDate.AutoSize = true;
            this.lblActualClaimedDate.Location = new System.Drawing.Point(14, 37);
            this.lblActualClaimedDate.Name = "lblActualClaimedDate";
            this.lblActualClaimedDate.Size = new System.Drawing.Size(103, 13);
            this.lblActualClaimedDate.TabIndex = 47;
            this.lblActualClaimedDate.Text = "Actual Claimed Date";
            // 
            // dtpActualClaimedDateFrom
            // 
            this.dtpActualClaimedDateFrom.CustomFormat = "yyyy/MM/dd";
            this.dtpActualClaimedDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpActualClaimedDateFrom.Location = new System.Drawing.Point(132, 33);
            this.dtpActualClaimedDateFrom.Name = "dtpActualClaimedDateFrom";
            this.dtpActualClaimedDateFrom.Size = new System.Drawing.Size(114, 20);
            this.dtpActualClaimedDateFrom.TabIndex = 5;
            this.dtpActualClaimedDateFrom.Value = new System.DateTime(2013, 3, 28, 15, 29, 30, 325);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(626, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 13);
            this.label15.TabIndex = 53;
            this.label15.Text = "~";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(249, 37);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 13);
            this.label16.TabIndex = 54;
            this.label16.Text = "~";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(427, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 32;
            this.label1.Text = "Fee Type";
            // 
            // cbbFeeType
            // 
            this.cbbFeeType.FormattingEnabled = true;
            this.cbbFeeType.Location = new System.Drawing.Point(515, 97);
            this.cbbFeeType.Name = "cbbFeeType";
            this.cbbFeeType.Size = new System.Drawing.Size(114, 21);
            this.cbbFeeType.TabIndex = 13;
            // 
            // colCustomerCode
            // 
            this.colCustomerCode.DataPropertyName = "CustomerCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCustomerCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.colCustomerCode.FillWeight = 28.53404F;
            this.colCustomerCode.HeaderText = "Customer Code";
            this.colCustomerCode.MinimumWidth = 100;
            this.colCustomerCode.Name = "colCustomerCode";
            this.colCustomerCode.ReadOnly = true;
            this.colCustomerCode.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // colCustomerName
            // 
            this.colCustomerName.DataPropertyName = "CustomerName";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colCustomerName.DefaultCellStyle = dataGridViewCellStyle3;
            this.colCustomerName.FillWeight = 464.6201F;
            this.colCustomerName.HeaderText = "Customer Name";
            this.colCustomerName.MinimumWidth = 200;
            this.colCustomerName.Name = "colCustomerName";
            this.colCustomerName.ReadOnly = true;
            this.colCustomerName.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // colLGNo
            // 
            this.colLGNo.DataPropertyName = "LGNo";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colLGNo.DefaultCellStyle = dataGridViewCellStyle4;
            this.colLGNo.FillWeight = 28.85465F;
            this.colLGNo.HeaderText = "LG No";
            this.colLGNo.MinimumWidth = 80;
            this.colLGNo.Name = "colLGNo";
            this.colLGNo.ReadOnly = true;
            this.colLGNo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // colFeeType
            // 
            this.colFeeType.DataPropertyName = "FeeType";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colFeeType.DefaultCellStyle = dataGridViewCellStyle5;
            this.colFeeType.FillWeight = 31.12422F;
            this.colFeeType.HeaderText = "Fee Type";
            this.colFeeType.MinimumWidth = 120;
            this.colFeeType.Name = "colFeeType";
            this.colFeeType.ReadOnly = true;
            // 
            // colFee
            // 
            this.colFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colFee.DataPropertyName = "Fee";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "#,0.0000";
            this.colFee.DefaultCellStyle = dataGridViewCellStyle6;
            this.colFee.FillWeight = 28.53404F;
            this.colFee.HeaderText = "Fee";
            this.colFee.MinimumWidth = 100;
            this.colFee.Name = "colFee";
            this.colFee.ReadOnly = true;
            // 
            // colFeeCurrency
            // 
            this.colFeeCurrency.DataPropertyName = "FeeCurrency";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colFeeCurrency.DefaultCellStyle = dataGridViewCellStyle7;
            this.colFeeCurrency.FillWeight = 28.53404F;
            this.colFeeCurrency.HeaderText = "Fee CCY";
            this.colFeeCurrency.MinimumWidth = 100;
            this.colFeeCurrency.Name = "colFeeCurrency";
            this.colFeeCurrency.ReadOnly = true;
            // 
            // colReceivedDate
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Format = "yyyy/MM/dd";
            this.colReceivedDate.DefaultCellStyle = dataGridViewCellStyle8;
            this.colReceivedDate.HeaderText = "ReceivedDate";
            this.colReceivedDate.MinimumWidth = 100;
            this.colReceivedDate.Name = "colReceivedDate";
            this.colReceivedDate.ReadOnly = true;
            // 
            // frmLGListOfFeeCollection
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(858, 539);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dtpActualClaimedDateTo);
            this.Controls.Add(this.lblActualClaimedDate);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dtpActualClaimedDateFrom);
            this.Controls.Add(this.dtpValueDateTo);
            this.Controls.Add(this.lblValueDate);
            this.Controls.Add(this.dtpValueDateFrom);
            this.Controls.Add(this.cbbGuaranteeType);
            this.Controls.Add(this.lblGuaranteeType);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dtpReceivedDateTo);
            this.Controls.Add(this.lblReceivedDate);
            this.Controls.Add(this.dtpReceivedDateForm);
            this.Controls.Add(this.cbbCurrency);
            this.Controls.Add(this.lblCurrency);
            this.Controls.Add(this.cbbFeeType);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbbGLCode);
            this.Controls.Add(this.lblGLCode);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.lblCustomerCode);
            this.Controls.Add(this.txtCustomerCode);
            this.Controls.Add(this.lblLGNo);
            this.Controls.Add(this.txtLGNo);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.dtgLGList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "frmLGListOfFeeCollection";
            this.Text = "List Of Fee Collection";
            ((System.ComponentModel.ISupportInitialize)(this.dtgLGList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.DataGridView dtgLGList;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblLGNo;
        private System.Windows.Forms.TextBox txtLGNo;
        private System.Windows.Forms.Label lblCustomerCode;
        private System.Windows.Forms.TextBox txtCustomerCode;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.ComboBox cbbGLCode;
        private System.Windows.Forms.Label lblGLCode;
        private System.Windows.Forms.ComboBox cbbCurrency;
        private System.Windows.Forms.Label lblCurrency;
        private UserCtrl.BlankCalendar dtpReceivedDateForm;
        private System.Windows.Forms.Label lblReceivedDate;
        private UserCtrl.BlankCalendar dtpReceivedDateTo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbbGuaranteeType;
        private System.Windows.Forms.Label lblGuaranteeType;
        private UserCtrl.BlankCalendar dtpValueDateTo;
        private System.Windows.Forms.Label lblValueDate;
        private UserCtrl.BlankCalendar dtpValueDateFrom;
        private UserCtrl.BlankCalendar dtpActualClaimedDateTo;
        private System.Windows.Forms.Label lblActualClaimedDate;
        private UserCtrl.BlankCalendar dtpActualClaimedDateFrom;
        private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbbFeeType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLGNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFeeType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFeeCurrency;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReceivedDate;
    }
}