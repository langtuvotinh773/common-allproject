﻿namespace Phoenix.Lg.Gui.Forms
{
    partial class frmLGListLGSupervisor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLGListLGSupervisor));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtgLGList = new System.Windows.Forms.DataGridView();
            this.colCheck = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colSeqLG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLGNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPreviousLGNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colInputDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colValueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBackValue = new System.Windows.Forms.DataGridViewImageColumn();
            this.colCustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGLCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colClaim = new System.Windows.Forms.DataGridViewImageColumn();
            this.colFeeRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMinCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colExpiryDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGuaranteeType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBeneficiaryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTransCurrency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colChargeAccount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGuaranteeAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFeeCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOverdueFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOverdueFeeCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOverdueClaimFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOverdueClaimFeeCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReportToSBV = new System.Windows.Forms.DataGridViewImageColumn();
            this.colExportedSmile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRemark = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMultiTimesFee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbReturn = new System.Windows.Forms.ToolStripButton();
            this.tsbAmendUpdate = new System.Windows.Forms.ToolStripButton();
            this.tsbAmend = new System.Windows.Forms.ToolStripButton();
            this.tsbTerminate = new System.Windows.Forms.ToolStripButton();
            this.tsbDisplayOverdue = new System.Windows.Forms.ToolStripButton();
            this.tsbDisplayFeeCollection = new System.Windows.Forms.ToolStripButton();
            this.tsbPrintForm = new System.Windows.Forms.ToolStripButton();
            this.tsbDelete = new System.Windows.Forms.ToolStripButton();
            this.tsbExportToSmile = new System.Windows.Forms.ToolStripButton();
            this.tsbShowSmileLog = new System.Windows.Forms.ToolStripButton();
            this.radGeneralSearch = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radOverdueChargeSchedule = new System.Windows.Forms.RadioButton();
            this.radChargeSchedule = new System.Windows.Forms.RadioButton();
            this.radOverdueExpire = new System.Windows.Forms.RadioButton();
            this.lblLGNo = new System.Windows.Forms.Label();
            this.txtLGNo = new System.Windows.Forms.TextBox();
            this.lblCustomerCode = new System.Windows.Forms.Label();
            this.txtCustomerCode = new System.Windows.Forms.TextBox();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.lblSecurity = new System.Windows.Forms.Label();
            this.cbbSecurity = new System.Windows.Forms.ComboBox();
            this.cbbGLCode = new System.Windows.Forms.ComboBox();
            this.lblGLCode = new System.Windows.Forms.Label();
            this.cbbCurrency = new System.Windows.Forms.ComboBox();
            this.lblCurrency = new System.Windows.Forms.Label();
            this.dtpInputDateFrom = new UserCtrl.BlankCalendar();
            this.lblInputDate = new System.Windows.Forms.Label();
            this.dtpInputDateTo = new UserCtrl.BlankCalendar();
            this.label9 = new System.Windows.Forms.Label();
            this.cbbGuaranteeType = new System.Windows.Forms.ComboBox();
            this.lblGuaranteeType = new System.Windows.Forms.Label();
            this.dtpValueDateTo = new UserCtrl.BlankCalendar();
            this.lblValueDate = new System.Windows.Forms.Label();
            this.dtpValueDateFrom = new UserCtrl.BlankCalendar();
            this.dtpExpireDateTo = new UserCtrl.BlankCalendar();
            this.lblExpireDate = new System.Windows.Forms.Label();
            this.dtpExpireDateFrom = new UserCtrl.BlankCalendar();
            this.lblAmount = new System.Windows.Forms.Label();
            this.txtAmountFrom = new UserCtrl.NumberOnlyTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtAmountTo = new UserCtrl.NumberOnlyTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnIssueLG = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cbbClaim = new System.Windows.Forms.ComboBox();
            this.lblClaim = new System.Windows.Forms.Label();
            this.cbbBookingPurpose = new System.Windows.Forms.ComboBox();
            this.lblBookingPurpose = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgLGList)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSearch.Location = new System.Drawing.Point(938, 159);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(94, 23);
            this.btnSearch.TabIndex = 18;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtgLGList
            // 
            this.dtgLGList.AllowUserToAddRows = false;
            this.dtgLGList.AllowUserToDeleteRows = false;
            this.dtgLGList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgLGList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgLGList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgLGList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgLGList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgLGList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCheck,
            this.colSeqLG,
            this.colLGNo,
            this.colPreviousLGNo,
            this.colType,
            this.colInputDate,
            this.colValueDate,
            this.colBackValue,
            this.colCustomerCode,
            this.colCustomerName,
            this.colGLCode,
            this.colClaim,
            this.colFeeRate,
            this.colMin,
            this.colMinCCY,
            this.colExpiryDate,
            this.colGuaranteeType,
            this.colBeneficiaryName,
            this.colTransCurrency,
            this.colChargeAccount,
            this.colGuaranteeAmount,
            this.colFee,
            this.colFeeCCY,
            this.colOverdueFee,
            this.colOverdueFeeCCY,
            this.colOverdueClaimFee,
            this.colOverdueClaimFeeCCY,
            this.colReportToSBV,
            this.colExportedSmile,
            this.colRemark,
            this.colMultiTimesFee});
            this.dtgLGList.EnableHeadersVisualStyles = false;
            this.dtgLGList.Location = new System.Drawing.Point(9, 186);
            this.dtgLGList.MultiSelect = false;
            this.dtgLGList.Name = "dtgLGList";
            this.dtgLGList.ReadOnly = true;
            this.dtgLGList.RowHeadersVisible = false;
            this.dtgLGList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgLGList.Size = new System.Drawing.Size(1024, 337);
            this.dtgLGList.TabIndex = 19;
            this.dtgLGList.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgLGList_CellValueChanged);
            this.dtgLGList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgLGList_CellClick);
            this.dtgLGList.SelectionChanged += new System.EventHandler(this.dtgLGList_SelectionChanged);
            // 
            // colCheck
            // 
            this.colCheck.Frozen = true;
            this.colCheck.HeaderText = "";
            this.colCheck.MinimumWidth = 30;
            this.colCheck.Name = "colCheck";
            this.colCheck.ReadOnly = true;
            this.colCheck.Width = 30;
            // 
            // colSeqLG
            // 
            this.colSeqLG.DataPropertyName = "SeqLG";
            this.colSeqLG.Frozen = true;
            this.colSeqLG.HeaderText = "SeqLG";
            this.colSeqLG.Name = "colSeqLG";
            this.colSeqLG.ReadOnly = true;
            this.colSeqLG.Visible = false;
            this.colSeqLG.Width = 65;
            // 
            // colLGNo
            // 
            this.colLGNo.DataPropertyName = "LGNo";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colLGNo.DefaultCellStyle = dataGridViewCellStyle2;
            this.colLGNo.FillWeight = 101.1236F;
            this.colLGNo.Frozen = true;
            this.colLGNo.HeaderText = "LG No";
            this.colLGNo.Name = "colLGNo";
            this.colLGNo.ReadOnly = true;
            this.colLGNo.Width = 63;
            // 
            // colPreviousLGNo
            // 
            this.colPreviousLGNo.DataPropertyName = "PreviousLGNo";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colPreviousLGNo.DefaultCellStyle = dataGridViewCellStyle3;
            this.colPreviousLGNo.FillWeight = 130.3745F;
            this.colPreviousLGNo.Frozen = true;
            this.colPreviousLGNo.HeaderText = "Previous LG No";
            this.colPreviousLGNo.Name = "colPreviousLGNo";
            this.colPreviousLGNo.ReadOnly = true;
            this.colPreviousLGNo.Width = 107;
            // 
            // colType
            // 
            this.colType.DataPropertyName = "Type";
            this.colType.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.colType.DropDownWidth = 100;
            this.colType.FillWeight = 109.0775F;
            this.colType.Frozen = true;
            this.colType.HeaderText = "Type";
            this.colType.MaxDropDownItems = 100;
            this.colType.MinimumWidth = 100;
            this.colType.Name = "colType";
            this.colType.ReadOnly = true;
            this.colType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colInputDate
            // 
            this.colInputDate.DataPropertyName = "InputDate";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.Format = "yyyy/MM/dd";
            this.colInputDate.DefaultCellStyle = dataGridViewCellStyle4;
            this.colInputDate.FillWeight = 83.79958F;
            this.colInputDate.HeaderText = "Input Date";
            this.colInputDate.Name = "colInputDate";
            this.colInputDate.ReadOnly = true;
            this.colInputDate.Width = 82;
            // 
            // colValueDate
            // 
            this.colValueDate.DataPropertyName = "ValueDate";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Format = "yyyy/MM/dd";
            this.colValueDate.DefaultCellStyle = dataGridViewCellStyle5;
            this.colValueDate.FillWeight = 90.08809F;
            this.colValueDate.HeaderText = "Value Date";
            this.colValueDate.Name = "colValueDate";
            this.colValueDate.ReadOnly = true;
            this.colValueDate.Width = 85;
            // 
            // colBackValue
            // 
            this.colBackValue.DataPropertyName = "BackValue";
            this.colBackValue.FillWeight = 85.53667F;
            this.colBackValue.HeaderText = "Back Value";
            this.colBackValue.Name = "colBackValue";
            this.colBackValue.ReadOnly = true;
            this.colBackValue.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colBackValue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colBackValue.Width = 87;
            // 
            // colCustomerCode
            // 
            this.colCustomerCode.DataPropertyName = "CustomerCode";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCustomerCode.DefaultCellStyle = dataGridViewCellStyle6;
            this.colCustomerCode.HeaderText = "Customer Code";
            this.colCustomerCode.Name = "colCustomerCode";
            this.colCustomerCode.ReadOnly = true;
            this.colCustomerCode.Width = 104;
            // 
            // colCustomerName
            // 
            this.colCustomerName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colCustomerName.DataPropertyName = "CustomerName";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colCustomerName.DefaultCellStyle = dataGridViewCellStyle7;
            this.colCustomerName.HeaderText = "Customer Name";
            this.colCustomerName.MinimumWidth = 200;
            this.colCustomerName.Name = "colCustomerName";
            this.colCustomerName.ReadOnly = true;
            this.colCustomerName.Width = 200;
            // 
            // colGLCode
            // 
            this.colGLCode.DataPropertyName = "GLCode";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colGLCode.DefaultCellStyle = dataGridViewCellStyle8;
            this.colGLCode.HeaderText = "GL Code";
            this.colGLCode.Name = "colGLCode";
            this.colGLCode.ReadOnly = true;
            this.colGLCode.Width = 74;
            // 
            // colClaim
            // 
            this.colClaim.DataPropertyName = "Claim";
            this.colClaim.HeaderText = "Claim";
            this.colClaim.Name = "colClaim";
            this.colClaim.ReadOnly = true;
            this.colClaim.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colClaim.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colClaim.Width = 57;
            // 
            // colFeeRate
            // 
            this.colFeeRate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colFeeRate.DataPropertyName = "FeeRate";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N5";
            this.colFeeRate.DefaultCellStyle = dataGridViewCellStyle9;
            this.colFeeRate.HeaderText = "LG Rate (%)";
            this.colFeeRate.Name = "colFeeRate";
            this.colFeeRate.ReadOnly = true;
            this.colFeeRate.Width = 89;
            // 
            // colMin
            // 
            this.colMin.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colMin.DataPropertyName = "Min";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "N2";
            this.colMin.DefaultCellStyle = dataGridViewCellStyle10;
            this.colMin.HeaderText = "Min";
            this.colMin.Name = "colMin";
            this.colMin.ReadOnly = true;
            this.colMin.Width = 49;
            // 
            // colMinCCY
            // 
            this.colMinCCY.DataPropertyName = "MinCCY";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colMinCCY.DefaultCellStyle = dataGridViewCellStyle11;
            this.colMinCCY.HeaderText = "Min CCY";
            this.colMinCCY.Name = "colMinCCY";
            this.colMinCCY.ReadOnly = true;
            this.colMinCCY.Width = 73;
            // 
            // colExpiryDate
            // 
            this.colExpiryDate.DataPropertyName = "ExpiryDate";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.Format = "yyyy/MM/dd";
            this.colExpiryDate.DefaultCellStyle = dataGridViewCellStyle12;
            this.colExpiryDate.HeaderText = "Expiry Date";
            this.colExpiryDate.Name = "colExpiryDate";
            this.colExpiryDate.ReadOnly = true;
            this.colExpiryDate.Width = 86;
            // 
            // colGuaranteeType
            // 
            this.colGuaranteeType.DataPropertyName = "GuaranteeType";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colGuaranteeType.DefaultCellStyle = dataGridViewCellStyle13;
            this.colGuaranteeType.HeaderText = "Guarantee Type";
            this.colGuaranteeType.Name = "colGuaranteeType";
            this.colGuaranteeType.ReadOnly = true;
            this.colGuaranteeType.Width = 109;
            // 
            // colBeneficiaryName
            // 
            this.colBeneficiaryName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colBeneficiaryName.DataPropertyName = "BeneficiaryName";
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colBeneficiaryName.DefaultCellStyle = dataGridViewCellStyle14;
            this.colBeneficiaryName.HeaderText = "Beneficiary Name";
            this.colBeneficiaryName.MinimumWidth = 200;
            this.colBeneficiaryName.Name = "colBeneficiaryName";
            this.colBeneficiaryName.ReadOnly = true;
            this.colBeneficiaryName.Width = 200;
            // 
            // colTransCurrency
            // 
            this.colTransCurrency.DataPropertyName = "TransCurrency";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colTransCurrency.DefaultCellStyle = dataGridViewCellStyle15;
            this.colTransCurrency.HeaderText = "CCY";
            this.colTransCurrency.Name = "colTransCurrency";
            this.colTransCurrency.ReadOnly = true;
            this.colTransCurrency.Width = 53;
            // 
            // colChargeAccount
            // 
            this.colChargeAccount.DataPropertyName = "ChargeAccount";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colChargeAccount.DefaultCellStyle = dataGridViewCellStyle16;
            this.colChargeAccount.HeaderText = "Charge Account";
            this.colChargeAccount.MinimumWidth = 125;
            this.colChargeAccount.Name = "colChargeAccount";
            this.colChargeAccount.ReadOnly = true;
            this.colChargeAccount.Width = 125;
            // 
            // colGuaranteeAmount
            // 
            this.colGuaranteeAmount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colGuaranteeAmount.DataPropertyName = "GuaranteeAmount";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle17.Format = "N2";
            this.colGuaranteeAmount.DefaultCellStyle = dataGridViewCellStyle17;
            this.colGuaranteeAmount.HeaderText = "Amount";
            this.colGuaranteeAmount.Name = "colGuaranteeAmount";
            this.colGuaranteeAmount.ReadOnly = true;
            this.colGuaranteeAmount.Width = 68;
            // 
            // colFee
            // 
            this.colFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colFee.DataPropertyName = "Fee";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle18.Format = "N2";
            this.colFee.DefaultCellStyle = dataGridViewCellStyle18;
            this.colFee.HeaderText = "Issuing Fee";
            this.colFee.Name = "colFee";
            this.colFee.ReadOnly = true;
            this.colFee.Width = 86;
            // 
            // colFeeCCY
            // 
            this.colFeeCCY.DataPropertyName = "FeeCurrency";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colFeeCCY.DefaultCellStyle = dataGridViewCellStyle19;
            this.colFeeCCY.HeaderText = "Issuing Fee CCY";
            this.colFeeCCY.Name = "colFeeCCY";
            this.colFeeCCY.ReadOnly = true;
            this.colFeeCCY.Width = 110;
            // 
            // colOverdueFee
            // 
            this.colOverdueFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colOverdueFee.DataPropertyName = "OverdueFee";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle20.Format = "N2";
            this.colOverdueFee.DefaultCellStyle = dataGridViewCellStyle20;
            this.colOverdueFee.HeaderText = "Overdue Fee";
            this.colOverdueFee.Name = "colOverdueFee";
            this.colOverdueFee.ReadOnly = true;
            this.colOverdueFee.Width = 94;
            // 
            // colOverdueFeeCCY
            // 
            this.colOverdueFeeCCY.DataPropertyName = "OverdueFeeCurrency";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colOverdueFeeCCY.DefaultCellStyle = dataGridViewCellStyle21;
            this.colOverdueFeeCCY.HeaderText = "Overdue Fee CCY";
            this.colOverdueFeeCCY.Name = "colOverdueFeeCCY";
            this.colOverdueFeeCCY.ReadOnly = true;
            this.colOverdueFeeCCY.Width = 118;
            // 
            // colOverdueClaimFee
            // 
            this.colOverdueClaimFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colOverdueClaimFee.DataPropertyName = "OverdueClaimFee";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle22.Format = "N2";
            this.colOverdueClaimFee.DefaultCellStyle = dataGridViewCellStyle22;
            this.colOverdueClaimFee.HeaderText = "Overdue Claim Fee";
            this.colOverdueClaimFee.Name = "colOverdueClaimFee";
            this.colOverdueClaimFee.ReadOnly = true;
            this.colOverdueClaimFee.Width = 122;
            // 
            // colOverdueClaimFeeCCY
            // 
            this.colOverdueClaimFeeCCY.DataPropertyName = "OverdueClaimFeeCurrency";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colOverdueClaimFeeCCY.DefaultCellStyle = dataGridViewCellStyle23;
            this.colOverdueClaimFeeCCY.HeaderText = "Overdue Claim Fee CCY";
            this.colOverdueClaimFeeCCY.Name = "colOverdueClaimFeeCCY";
            this.colOverdueClaimFeeCCY.ReadOnly = true;
            this.colOverdueClaimFeeCCY.Width = 146;
            // 
            // colReportToSBV
            // 
            this.colReportToSBV.DataPropertyName = "ReportToSBV";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle24.NullValue")));
            this.colReportToSBV.DefaultCellStyle = dataGridViewCellStyle24;
            this.colReportToSBV.HeaderText = "Report to SBV";
            this.colReportToSBV.Name = "colReportToSBV";
            this.colReportToSBV.ReadOnly = true;
            this.colReportToSBV.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colReportToSBV.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colExportedSmile
            // 
            this.colExportedSmile.HeaderText = "Exported (SMILE)";
            this.colExportedSmile.Name = "colExportedSmile";
            this.colExportedSmile.ReadOnly = true;
            this.colExportedSmile.Width = 115;
            // 
            // colRemark
            // 
            this.colRemark.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colRemark.DefaultCellStyle = dataGridViewCellStyle25;
            this.colRemark.HeaderText = "Remark";
            this.colRemark.MinimumWidth = 200;
            this.colRemark.Name = "colRemark";
            this.colRemark.ReadOnly = true;
            this.colRemark.Width = 200;
            // 
            // colMultiTimesFee
            // 
            this.colMultiTimesFee.HeaderText = "Multi-Times Fee";
            this.colMultiTimesFee.Name = "colMultiTimesFee";
            this.colMultiTimesFee.ReadOnly = true;
            this.colMultiTimesFee.Visible = false;
            this.colMultiTimesFee.Width = 106;
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportExcel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnExportExcel.Location = new System.Drawing.Point(833, 529);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(94, 23);
            this.btnExportExcel.TabIndex = 21;
            this.btnExportExcel.Text = "&Export Excel";
            this.btnExportExcel.UseVisualStyleBackColor = false;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(938, 529);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(94, 23);
            this.btnClose.TabIndex = 22;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbReturn,
            this.tsbAmendUpdate,
            this.tsbAmend,
            this.tsbTerminate,
            this.tsbDisplayOverdue,
            this.tsbDisplayFeeCollection,
            this.tsbPrintForm,
            this.tsbDelete,
            this.tsbExportToSmile,
            this.tsbShowSmileLog});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1041, 25);
            this.toolStrip1.TabIndex = 23;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbReturn
            // 
            this.tsbReturn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbReturn.Image = ((System.Drawing.Image)(resources.GetObject("tsbReturn.Image")));
            this.tsbReturn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbReturn.Name = "tsbReturn";
            this.tsbReturn.Size = new System.Drawing.Size(23, 22);
            this.tsbReturn.Text = "Return (Alt + R)";
            this.tsbReturn.Click += new System.EventHandler(this.tsbReturn_Click);
            // 
            // tsbAmendUpdate
            // 
            this.tsbAmendUpdate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAmendUpdate.Image = ((System.Drawing.Image)(resources.GetObject("tsbAmendUpdate.Image")));
            this.tsbAmendUpdate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAmendUpdate.Name = "tsbAmendUpdate";
            this.tsbAmendUpdate.Size = new System.Drawing.Size(23, 22);
            this.tsbAmendUpdate.Text = "Amend(Update) (Alt + U)";
            this.tsbAmendUpdate.Click += new System.EventHandler(this.tsbAmendUpdate_Click);
            // 
            // tsbAmend
            // 
            this.tsbAmend.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAmend.Image = ((System.Drawing.Image)(resources.GetObject("tsbAmend.Image")));
            this.tsbAmend.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAmend.Name = "tsbAmend";
            this.tsbAmend.Size = new System.Drawing.Size(23, 22);
            this.tsbAmend.Text = "Amend (Alt + A)";
            this.tsbAmend.Click += new System.EventHandler(this.tsbAmend_Click);
            // 
            // tsbTerminate
            // 
            this.tsbTerminate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbTerminate.Image = ((System.Drawing.Image)(resources.GetObject("tsbTerminate.Image")));
            this.tsbTerminate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTerminate.Name = "tsbTerminate";
            this.tsbTerminate.Size = new System.Drawing.Size(23, 22);
            this.tsbTerminate.Text = "Terminate (Alt + T)";
            this.tsbTerminate.Click += new System.EventHandler(this.tsbTerminate_Click);
            // 
            // tsbDisplayOverdue
            // 
            this.tsbDisplayOverdue.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDisplayOverdue.Image = ((System.Drawing.Image)(resources.GetObject("tsbDisplayOverdue.Image")));
            this.tsbDisplayOverdue.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDisplayOverdue.Name = "tsbDisplayOverdue";
            this.tsbDisplayOverdue.Size = new System.Drawing.Size(23, 22);
            this.tsbDisplayOverdue.Text = "Overdue Charge Schedule (Alt + O)";
            this.tsbDisplayOverdue.Click += new System.EventHandler(this.tsbDisplayOverdue_Click);
            // 
            // tsbDisplayFeeCollection
            // 
            this.tsbDisplayFeeCollection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDisplayFeeCollection.Image = ((System.Drawing.Image)(resources.GetObject("tsbDisplayFeeCollection.Image")));
            this.tsbDisplayFeeCollection.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDisplayFeeCollection.Name = "tsbDisplayFeeCollection";
            this.tsbDisplayFeeCollection.Size = new System.Drawing.Size(23, 22);
            this.tsbDisplayFeeCollection.Text = "Fee Collection Schedule (Alt + F)";
            this.tsbDisplayFeeCollection.Click += new System.EventHandler(this.tsbDisplayFeeCollection_Click);
            // 
            // tsbPrintForm
            // 
            this.tsbPrintForm.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPrintForm.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrintForm.Image")));
            this.tsbPrintForm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrintForm.Name = "tsbPrintForm";
            this.tsbPrintForm.Size = new System.Drawing.Size(23, 22);
            this.tsbPrintForm.Text = "Print Form (Alt + P)";
            this.tsbPrintForm.Click += new System.EventHandler(this.tsbPrintForm_Click);
            // 
            // tsbDelete
            // 
            this.tsbDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDelete.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelete.Image")));
            this.tsbDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelete.Name = "tsbDelete";
            this.tsbDelete.Size = new System.Drawing.Size(23, 22);
            this.tsbDelete.Text = "Delete (Alt + D)";
            this.tsbDelete.Click += new System.EventHandler(this.tsbDelete_Click);
            // 
            // tsbExportToSmile
            // 
            this.tsbExportToSmile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbExportToSmile.Image = ((System.Drawing.Image)(resources.GetObject("tsbExportToSmile.Image")));
            this.tsbExportToSmile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExportToSmile.Name = "tsbExportToSmile";
            this.tsbExportToSmile.Size = new System.Drawing.Size(23, 22);
            this.tsbExportToSmile.Text = "Export To Smile (Alt + M)";
            this.tsbExportToSmile.Click += new System.EventHandler(this.tsbExportToSmile_Click);
            // 
            // tsbShowSmileLog
            // 
            this.tsbShowSmileLog.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbShowSmileLog.Image = ((System.Drawing.Image)(resources.GetObject("tsbShowSmileLog.Image")));
            this.tsbShowSmileLog.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbShowSmileLog.Name = "tsbShowSmileLog";
            this.tsbShowSmileLog.Size = new System.Drawing.Size(23, 22);
            this.tsbShowSmileLog.Text = "Show Smile Log (Alt + G)";
            this.tsbShowSmileLog.Click += new System.EventHandler(this.tsbShowSmileLog_Click);
            // 
            // radGeneralSearch
            // 
            this.radGeneralSearch.AutoSize = true;
            this.radGeneralSearch.Checked = true;
            this.radGeneralSearch.Location = new System.Drawing.Point(16, 10);
            this.radGeneralSearch.Name = "radGeneralSearch";
            this.radGeneralSearch.Size = new System.Drawing.Size(99, 17);
            this.radGeneralSearch.TabIndex = 0;
            this.radGeneralSearch.TabStop = true;
            this.radGeneralSearch.Text = "General Search";
            this.radGeneralSearch.UseVisualStyleBackColor = true;
            this.radGeneralSearch.CheckedChanged += new System.EventHandler(this.radGeneralSearch_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radOverdueChargeSchedule);
            this.groupBox2.Controls.Add(this.radChargeSchedule);
            this.groupBox2.Controls.Add(this.radOverdueExpire);
            this.groupBox2.Controls.Add(this.radGeneralSearch);
            this.groupBox2.Location = new System.Drawing.Point(8, 28);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(819, 35);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // radOverdueChargeSchedule
            // 
            this.radOverdueChargeSchedule.AutoSize = true;
            this.radOverdueChargeSchedule.Location = new System.Drawing.Point(660, 12);
            this.radOverdueChargeSchedule.Name = "radOverdueChargeSchedule";
            this.radOverdueChargeSchedule.Size = new System.Drawing.Size(151, 17);
            this.radOverdueChargeSchedule.TabIndex = 4;
            this.radOverdueChargeSchedule.Text = "Overdue Charge Schedule";
            this.radOverdueChargeSchedule.UseVisualStyleBackColor = true;
            // 
            // radChargeSchedule
            // 
            this.radChargeSchedule.AutoSize = true;
            this.radChargeSchedule.Location = new System.Drawing.Point(463, 10);
            this.radChargeSchedule.Name = "radChargeSchedule";
            this.radChargeSchedule.Size = new System.Drawing.Size(127, 17);
            this.radChargeSchedule.TabIndex = 2;
            this.radChargeSchedule.Text = "Issuing Fee Schedule";
            this.radChargeSchedule.UseVisualStyleBackColor = true;
            // 
            // radOverdueExpire
            // 
            this.radOverdueExpire.AutoSize = true;
            this.radOverdueExpire.Location = new System.Drawing.Point(193, 10);
            this.radOverdueExpire.Name = "radOverdueExpire";
            this.radOverdueExpire.Size = new System.Drawing.Size(189, 17);
            this.radOverdueExpire.TabIndex = 1;
            this.radOverdueExpire.Text = "Overdue And Expire Within 7 Days";
            this.radOverdueExpire.UseVisualStyleBackColor = true;
            // 
            // lblLGNo
            // 
            this.lblLGNo.AutoSize = true;
            this.lblLGNo.Location = new System.Drawing.Point(9, 74);
            this.lblLGNo.Name = "lblLGNo";
            this.lblLGNo.Size = new System.Drawing.Size(38, 13);
            this.lblLGNo.TabIndex = 22;
            this.lblLGNo.Text = "LG No";
            // 
            // txtLGNo
            // 
            this.txtLGNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtLGNo.Location = new System.Drawing.Point(73, 70);
            this.txtLGNo.MaxLength = 9;
            this.txtLGNo.Name = "txtLGNo";
            this.txtLGNo.Size = new System.Drawing.Size(114, 20);
            this.txtLGNo.TabIndex = 1;
            // 
            // lblCustomerCode
            // 
            this.lblCustomerCode.AutoSize = true;
            this.lblCustomerCode.Location = new System.Drawing.Point(208, 74);
            this.lblCustomerCode.Name = "lblCustomerCode";
            this.lblCustomerCode.Size = new System.Drawing.Size(79, 13);
            this.lblCustomerCode.TabIndex = 24;
            this.lblCustomerCode.Text = "Customer Code";
            // 
            // txtCustomerCode
            // 
            this.txtCustomerCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCustomerCode.Location = new System.Drawing.Point(307, 70);
            this.txtCustomerCode.MaxLength = 8;
            this.txtCustomerCode.Name = "txtCustomerCode";
            this.txtCustomerCode.Size = new System.Drawing.Size(136, 20);
            this.txtCustomerCode.TabIndex = 2;
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(453, 74);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(82, 13);
            this.lblCustomerName.TabIndex = 26;
            this.lblCustomerName.Text = "Customer Name";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCustomerName.Location = new System.Drawing.Point(540, 70);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(493, 20);
            this.txtCustomerName.TabIndex = 3;
            // 
            // lblSecurity
            // 
            this.lblSecurity.AutoSize = true;
            this.lblSecurity.Location = new System.Drawing.Point(9, 95);
            this.lblSecurity.Name = "lblSecurity";
            this.lblSecurity.Size = new System.Drawing.Size(45, 13);
            this.lblSecurity.TabIndex = 28;
            this.lblSecurity.Text = "Security";
            // 
            // cbbSecurity
            // 
            this.cbbSecurity.FormattingEnabled = true;
            this.cbbSecurity.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbSecurity.Location = new System.Drawing.Point(73, 91);
            this.cbbSecurity.Name = "cbbSecurity";
            this.cbbSecurity.Size = new System.Drawing.Size(114, 21);
            this.cbbSecurity.TabIndex = 4;
            // 
            // cbbGLCode
            // 
            this.cbbGLCode.FormattingEnabled = true;
            this.cbbGLCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbGLCode.Location = new System.Drawing.Point(540, 91);
            this.cbbGLCode.Name = "cbbGLCode";
            this.cbbGLCode.Size = new System.Drawing.Size(114, 21);
            this.cbbGLCode.TabIndex = 6;
            // 
            // lblGLCode
            // 
            this.lblGLCode.AutoSize = true;
            this.lblGLCode.Location = new System.Drawing.Point(453, 95);
            this.lblGLCode.Name = "lblGLCode";
            this.lblGLCode.Size = new System.Drawing.Size(49, 13);
            this.lblGLCode.TabIndex = 32;
            this.lblGLCode.Text = "GL Code";
            // 
            // cbbCurrency
            // 
            this.cbbCurrency.FormattingEnabled = true;
            this.cbbCurrency.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbCurrency.Location = new System.Drawing.Point(700, 91);
            this.cbbCurrency.Name = "cbbCurrency";
            this.cbbCurrency.Size = new System.Drawing.Size(80, 21);
            this.cbbCurrency.TabIndex = 7;
            this.cbbCurrency.SelectedIndexChanged += new System.EventHandler(this.cbbCurrency_SelectedIndexChanged);
            // 
            // lblCurrency
            // 
            this.lblCurrency.AutoSize = true;
            this.lblCurrency.Location = new System.Drawing.Point(665, 95);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(28, 13);
            this.lblCurrency.TabIndex = 34;
            this.lblCurrency.Text = "CCY";
            // 
            // dtpInputDateFrom
            // 
            this.dtpInputDateFrom.CustomFormat = "yyyy/MM/dd";
            this.dtpInputDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInputDateFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpInputDateFrom.Location = new System.Drawing.Point(73, 113);
            this.dtpInputDateFrom.Name = "dtpInputDateFrom";
            this.dtpInputDateFrom.Size = new System.Drawing.Size(114, 20);
            this.dtpInputDateFrom.TabIndex = 9;
            this.dtpInputDateFrom.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // lblInputDate
            // 
            this.lblInputDate.AutoSize = true;
            this.lblInputDate.Location = new System.Drawing.Point(9, 117);
            this.lblInputDate.Name = "lblInputDate";
            this.lblInputDate.Size = new System.Drawing.Size(57, 13);
            this.lblInputDate.TabIndex = 38;
            this.lblInputDate.Text = "Input Date";
            // 
            // dtpInputDateTo
            // 
            this.dtpInputDateTo.CustomFormat = "yyyy/MM/dd";
            this.dtpInputDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInputDateTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpInputDateTo.Location = new System.Drawing.Point(207, 113);
            this.dtpInputDateTo.Name = "dtpInputDateTo";
            this.dtpInputDateTo.Size = new System.Drawing.Size(114, 20);
            this.dtpInputDateTo.TabIndex = 10;
            this.dtpInputDateTo.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(190, 117);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 13);
            this.label9.TabIndex = 40;
            this.label9.Text = "~";
            // 
            // cbbGuaranteeType
            // 
            this.cbbGuaranteeType.FormattingEnabled = true;
            this.cbbGuaranteeType.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbGuaranteeType.Location = new System.Drawing.Point(441, 113);
            this.cbbGuaranteeType.Name = "cbbGuaranteeType";
            this.cbbGuaranteeType.Size = new System.Drawing.Size(114, 21);
            this.cbbGuaranteeType.TabIndex = 11;
            // 
            // lblGuaranteeType
            // 
            this.lblGuaranteeType.AutoSize = true;
            this.lblGuaranteeType.Location = new System.Drawing.Point(347, 117);
            this.lblGuaranteeType.Name = "lblGuaranteeType";
            this.lblGuaranteeType.Size = new System.Drawing.Size(84, 13);
            this.lblGuaranteeType.TabIndex = 41;
            this.lblGuaranteeType.Text = "Guarantee Type";
            // 
            // dtpValueDateTo
            // 
            this.dtpValueDateTo.CustomFormat = "yyyy/MM/dd";
            this.dtpValueDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpValueDateTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpValueDateTo.Location = new System.Drawing.Point(207, 135);
            this.dtpValueDateTo.Name = "dtpValueDateTo";
            this.dtpValueDateTo.Size = new System.Drawing.Size(114, 20);
            this.dtpValueDateTo.TabIndex = 13;
            this.dtpValueDateTo.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // lblValueDate
            // 
            this.lblValueDate.AutoSize = true;
            this.lblValueDate.Location = new System.Drawing.Point(9, 139);
            this.lblValueDate.Name = "lblValueDate";
            this.lblValueDate.Size = new System.Drawing.Size(60, 13);
            this.lblValueDate.TabIndex = 44;
            this.lblValueDate.Text = "Value Date";
            // 
            // dtpValueDateFrom
            // 
            this.dtpValueDateFrom.CustomFormat = "yyyy/MM/dd";
            this.dtpValueDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpValueDateFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpValueDateFrom.Location = new System.Drawing.Point(73, 135);
            this.dtpValueDateFrom.Name = "dtpValueDateFrom";
            this.dtpValueDateFrom.Size = new System.Drawing.Size(114, 20);
            this.dtpValueDateFrom.TabIndex = 12;
            this.dtpValueDateFrom.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // dtpExpireDateTo
            // 
            this.dtpExpireDateTo.CustomFormat = "yyyy/MM/dd";
            this.dtpExpireDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpExpireDateTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpExpireDateTo.Location = new System.Drawing.Point(575, 135);
            this.dtpExpireDateTo.Name = "dtpExpireDateTo";
            this.dtpExpireDateTo.Size = new System.Drawing.Size(114, 20);
            this.dtpExpireDateTo.TabIndex = 15;
            this.dtpExpireDateTo.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // lblExpireDate
            // 
            this.lblExpireDate.AutoSize = true;
            this.lblExpireDate.Location = new System.Drawing.Point(347, 139);
            this.lblExpireDate.Name = "lblExpireDate";
            this.lblExpireDate.Size = new System.Drawing.Size(61, 13);
            this.lblExpireDate.TabIndex = 47;
            this.lblExpireDate.Text = "Expiry Date";
            // 
            // dtpExpireDateFrom
            // 
            this.dtpExpireDateFrom.CustomFormat = "yyyy/MM/dd";
            this.dtpExpireDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpExpireDateFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtpExpireDateFrom.Location = new System.Drawing.Point(441, 135);
            this.dtpExpireDateFrom.Name = "dtpExpireDateFrom";
            this.dtpExpireDateFrom.Size = new System.Drawing.Size(114, 20);
            this.dtpExpireDateFrom.TabIndex = 14;
            this.dtpExpireDateFrom.Value = new System.DateTime(2013, 3, 27, 19, 40, 16, 947);
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(700, 139);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(43, 13);
            this.lblAmount.TabIndex = 49;
            this.lblAmount.Text = "Amount";
            // 
            // txtAmountFrom
            // 
            this.txtAmountFrom.CustomDecimal = 5;
            this.txtAmountFrom.CustomLenght = 17;
            this.txtAmountFrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtAmountFrom.Location = new System.Drawing.Point(748, 135);
            this.txtAmountFrom.Name = "txtAmountFrom";
            this.txtAmountFrom.NeedDecimal = true;
            this.txtAmountFrom.Size = new System.Drawing.Size(134, 20);
            this.txtAmountFrom.StringFormat = "#,0.####";
            this.txtAmountFrom.TabIndex = 16;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(883, 139);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 13);
            this.label14.TabIndex = 51;
            this.label14.Text = "~";
            // 
            // txtAmountTo
            // 
            this.txtAmountTo.CustomDecimal = 5;
            this.txtAmountTo.CustomLenght = 17;
            this.txtAmountTo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtAmountTo.Location = new System.Drawing.Point(898, 135);
            this.txtAmountTo.Name = "txtAmountTo";
            this.txtAmountTo.NeedDecimal = true;
            this.txtAmountTo.Size = new System.Drawing.Size(134, 20);
            this.txtAmountTo.StringFormat = "#,0.####";
            this.txtAmountTo.TabIndex = 17;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(190, 139);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 13);
            this.label15.TabIndex = 53;
            this.label15.Text = "~";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(558, 139);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 13);
            this.label16.TabIndex = 54;
            this.label16.Text = "~";
            // 
            // btnIssueLG
            // 
            this.btnIssueLG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIssueLG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnIssueLG.Location = new System.Drawing.Point(728, 529);
            this.btnIssueLG.Name = "btnIssueLG";
            this.btnIssueLG.Size = new System.Drawing.Size(94, 23);
            this.btnIssueLG.TabIndex = 20;
            this.btnIssueLG.Text = "&Issue LG";
            this.btnIssueLG.UseVisualStyleBackColor = false;
            this.btnIssueLG.Click += new System.EventHandler(this.btnIssueLG_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridViewTextBoxColumn1.FillWeight = 101.1236F;
            this.dataGridViewTextBoxColumn1.HeaderText = "LG No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 63;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridViewTextBoxColumn2.FillWeight = 130.3745F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Previous LG No";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 107;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 109.0775F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Type";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 56;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle28;
            this.dataGridViewTextBoxColumn4.FillWeight = 83.79958F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Input Date";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 82;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridViewTextBoxColumn5.FillWeight = 90.08809F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Value Date";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 85;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.FillWeight = 85.53667F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Back Value";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 87;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle30;
            this.dataGridViewTextBoxColumn7.HeaderText = "Customer Code";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 104;
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridViewTextBoxColumn8.HeaderText = "Customer Name";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 107;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "GL Code";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 74;
            // 
            // dataGridViewTextBoxColumn10
            // 
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridViewTextBoxColumn10.HeaderText = "Fee Rate(%)";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 90;
            // 
            // dataGridViewTextBoxColumn11
            // 
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridViewTextBoxColumn11.HeaderText = "Min";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 49;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Min CCY";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 73;
            // 
            // dataGridViewTextBoxColumn13
            // 
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewTextBoxColumn13.HeaderText = "Expiry Date";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 86;
            // 
            // dataGridViewTextBoxColumn14
            // 
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewTextBoxColumn14.HeaderText = "Guarantee Type";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 109;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "Beneficiary";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 84;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.HeaderText = "CCY";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 53;
            // 
            // dataGridViewTextBoxColumn17
            // 
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn17.DefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridViewTextBoxColumn17.HeaderText = "Charge Account";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 109;
            // 
            // dataGridViewTextBoxColumn18
            // 
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn18.DefaultCellStyle = dataGridViewCellStyle37;
            this.dataGridViewTextBoxColumn18.HeaderText = "Guarantee Amount";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 121;
            // 
            // dataGridViewTextBoxColumn19
            // 
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle38;
            this.dataGridViewTextBoxColumn19.HeaderText = "Fee";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 50;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "Overdue Fee";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 94;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.HeaderText = "Overdue Claim Fee";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 122;
            // 
            // dataGridViewTextBoxColumn22
            // 
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn22.DefaultCellStyle = dataGridViewCellStyle39;
            this.dataGridViewTextBoxColumn22.HeaderText = "Report to SBV";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            // 
            // cbbClaim
            // 
            this.cbbClaim.FormattingEnabled = true;
            this.cbbClaim.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbClaim.Items.AddRange(new object[] {
            "",
            "Claim",
            "Not Claim"});
            this.cbbClaim.Location = new System.Drawing.Point(838, 91);
            this.cbbClaim.Name = "cbbClaim";
            this.cbbClaim.Size = new System.Drawing.Size(134, 21);
            this.cbbClaim.TabIndex = 8;
            // 
            // lblClaim
            // 
            this.lblClaim.AutoSize = true;
            this.lblClaim.Location = new System.Drawing.Point(790, 95);
            this.lblClaim.Name = "lblClaim";
            this.lblClaim.Size = new System.Drawing.Size(32, 13);
            this.lblClaim.TabIndex = 82;
            this.lblClaim.Text = "Claim";
            // 
            // cbbBookingPurpose
            // 
            this.cbbBookingPurpose.FormattingEnabled = true;
            this.cbbBookingPurpose.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbbBookingPurpose.Items.AddRange(new object[] {
            "",
            "Booking Purpose",
            "Not Booking Purpose"});
            this.cbbBookingPurpose.Location = new System.Drawing.Point(307, 91);
            this.cbbBookingPurpose.Name = "cbbBookingPurpose";
            this.cbbBookingPurpose.Size = new System.Drawing.Size(136, 21);
            this.cbbBookingPurpose.TabIndex = 5;
            // 
            // lblBookingPurpose
            // 
            this.lblBookingPurpose.AutoSize = true;
            this.lblBookingPurpose.Location = new System.Drawing.Point(208, 95);
            this.lblBookingPurpose.Name = "lblBookingPurpose";
            this.lblBookingPurpose.Size = new System.Drawing.Size(88, 13);
            this.lblBookingPurpose.TabIndex = 84;
            this.lblBookingPurpose.Text = "Booking Purpose";
            // 
            // frmLGListLGSupervisor
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1041, 559);
            this.Controls.Add(this.cbbBookingPurpose);
            this.Controls.Add(this.lblBookingPurpose);
            this.Controls.Add(this.cbbClaim);
            this.Controls.Add(this.lblClaim);
            this.Controls.Add(this.btnIssueLG);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtAmountTo);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtAmountFrom);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.dtpExpireDateTo);
            this.Controls.Add(this.lblExpireDate);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dtpExpireDateFrom);
            this.Controls.Add(this.dtpValueDateTo);
            this.Controls.Add(this.lblValueDate);
            this.Controls.Add(this.dtpValueDateFrom);
            this.Controls.Add(this.cbbGuaranteeType);
            this.Controls.Add(this.lblGuaranteeType);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dtpInputDateTo);
            this.Controls.Add(this.lblInputDate);
            this.Controls.Add(this.dtpInputDateFrom);
            this.Controls.Add(this.cbbCurrency);
            this.Controls.Add(this.lblCurrency);
            this.Controls.Add(this.cbbGLCode);
            this.Controls.Add(this.lblGLCode);
            this.Controls.Add(this.cbbSecurity);
            this.Controls.Add(this.lblSecurity);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.lblCustomerCode);
            this.Controls.Add(this.txtCustomerCode);
            this.Controls.Add(this.lblLGNo);
            this.Controls.Add(this.txtLGNo);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnExportExcel);
            this.Controls.Add(this.dtgLGList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = true;
            this.Name = "frmLGListLGSupervisor";
            this.Text = "List LG Supervisor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGListLGSupervisor_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dtgLGList)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dtgLGList;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.RadioButton radGeneralSearch;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radChargeSchedule;
        private System.Windows.Forms.RadioButton radOverdueExpire;
        private System.Windows.Forms.Label lblLGNo;
        private System.Windows.Forms.TextBox txtLGNo;
        private System.Windows.Forms.Label lblCustomerCode;
        private System.Windows.Forms.TextBox txtCustomerCode;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label lblSecurity;
        private System.Windows.Forms.ComboBox cbbSecurity;
        private System.Windows.Forms.ComboBox cbbGLCode;
        private System.Windows.Forms.Label lblGLCode;
        private System.Windows.Forms.ComboBox cbbCurrency;
        private System.Windows.Forms.Label lblCurrency;
        private UserCtrl.BlankCalendar dtpInputDateFrom;
        private System.Windows.Forms.Label lblInputDate;
        private UserCtrl.BlankCalendar dtpInputDateTo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbbGuaranteeType;
        private System.Windows.Forms.Label lblGuaranteeType;
        private UserCtrl.BlankCalendar dtpValueDateTo;
        private System.Windows.Forms.Label lblValueDate;
        private UserCtrl.BlankCalendar dtpValueDateFrom;
        private UserCtrl.BlankCalendar dtpExpireDateTo;
        private System.Windows.Forms.Label lblExpireDate;
        private UserCtrl.BlankCalendar dtpExpireDateFrom;
        private System.Windows.Forms.Label lblAmount;
        private UserCtrl.NumberOnlyTextBox txtAmountFrom;
        private System.Windows.Forms.Label label14;
        private UserCtrl.NumberOnlyTextBox txtAmountTo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnIssueLG;
        private System.Windows.Forms.ToolStripButton tsbReturn;
        private System.Windows.Forms.ToolStripButton tsbAmendUpdate;
        private System.Windows.Forms.ToolStripButton tsbAmend;
        private System.Windows.Forms.ToolStripButton tsbTerminate;
        private System.Windows.Forms.ToolStripButton tsbDisplayOverdue;
        private System.Windows.Forms.ToolStripButton tsbDisplayFeeCollection;
        private System.Windows.Forms.ToolStripButton tsbPrintForm;
        private System.Windows.Forms.ToolStripButton tsbDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.ComboBox cbbClaim;
        private System.Windows.Forms.Label lblClaim;
        private System.Windows.Forms.ToolStripButton tsbExportToSmile;
        private System.Windows.Forms.ToolStripButton tsbShowSmileLog;
        private System.Windows.Forms.ComboBox cbbBookingPurpose;
        private System.Windows.Forms.Label lblBookingPurpose;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colCheck;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSeqLG;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLGNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPreviousLGNo;
        private System.Windows.Forms.DataGridViewComboBoxColumn colType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colInputDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colValueDate;
        private System.Windows.Forms.DataGridViewImageColumn colBackValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGLCode;
        private System.Windows.Forms.DataGridViewImageColumn colClaim;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFeeRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMin;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMinCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colExpiryDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGuaranteeType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBeneficiaryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTransCurrency;
        private System.Windows.Forms.DataGridViewTextBoxColumn colChargeAccount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGuaranteeAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFeeCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOverdueFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOverdueFeeCCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOverdueClaimFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOverdueClaimFeeCCY;
        private System.Windows.Forms.DataGridViewImageColumn colReportToSBV;
        private System.Windows.Forms.DataGridViewTextBoxColumn colExportedSmile;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRemark;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMultiTimesFee;
        private System.Windows.Forms.RadioButton radOverdueChargeSchedule;
    }
}