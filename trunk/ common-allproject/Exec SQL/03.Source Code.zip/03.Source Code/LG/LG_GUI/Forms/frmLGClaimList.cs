﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-05 14:29:30 +0700 (Thu, 03 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to show Claim list
 * for LG module.
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Phoenix.Lg.Com;
using Phoenix.Lg.Dto;
using Phoenix.Lg.Bus;
using Phoenix.Common.MasterData.Com;
using Phoenix.Common.Functions;
using Phoenix.Lg.Common;
using Config.Classes;
using System.Collections;
using Phoenix.Common.Security.Com;
using UserCtrl;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGClaimList : frmLGMaster
    {
        #region Variables

        ///Datagrid column name
        private string m_colNo = "colNo";
        private string m_colSeqLG = "colSeqLG";
        private string m_colLGSubNo = "colLGSubNo";
        private string m_colCurrentLGAmount = "colCurrentLGAmount";
        private string m_colClaimedAmount = "colClaimedAmount";
        private string m_colPaid = "colPaid";
        private string m_colClaimedPaymentDate = "colClaimedPaymentDate";
        private string m_colRemark = "colRemark";
        private string m_colClaimedDate = "colClaimedDate";
        private string m_colClaimedCCY = "colClaimedCCY";
      //  private string m_colIsChange = "colIsChange";

        //SeqLG current
        private int m_SeqLG;
        /// ERROR CODE
        private const int UPDATE_ERROR = 0;
        private const int NEDD_REINPUT_REMARK = 1;
        private const int EXIST_EMPTY_FIELD = 2;
        private const int NO_ERROR = -1;

        private clsLGBus m_LGBus;
        private ArrayList m_ArrCurrency;
        private clsLGListClaimBus m_ClaimBus;
        //List of Claim
        private List<clsLGClaimDTO> m_LstClaim = new List<clsLGClaimDTO>();
        private List<clsLGClaimDTO> m_LstClaimBackup = new List<clsLGClaimDTO>();
        #endregion

        #region Contructor
        /// <summary>
        /// Constructor of form Claim list
        /// </summary>
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public frmLGClaimList(clsLGClaimDTO claimObj)
        {
            try
            {
                m_SeqLG = claimObj.SeqLG;
                InitializeComponent();
                SetFormStyle();
                //LG no = LGType + LGCode + Sub Code
                txtLGNo.Text = claimObj.LGNo.Substring(0, 6);
                txtCustomerCode.Text = claimObj.CustomerCode;
                txtCustomerName.Text = claimObj.CustomerName;
                txtBenificiaryName.Text = claimObj.BeneficiaryName;
                m_LGBus = new clsLGBus();
                m_ClaimBus = new clsLGListClaimBus();
                m_ArrCurrency = m_LGBus.GetListCurrency();
                //[Type] Combobox for Grid
                DataGridViewComboBoxColumn claimedCCYColumn = (DataGridViewComboBoxColumn)dtgClaimList.Columns[m_colClaimedCCY];
                claimedCCYColumn.DataSource = m_ArrCurrency;
                claimedCCYColumn.DisplayMember = "Display";
                claimedCCYColumn.ValueMember = "Value";
                //fill data on grid when load form
                FillData(claimObj.SeqLG);
                _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }
        #endregion

        #region Event functions
        /// <summary>
        /// Close event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        /// <summary>
        /// Remove a row on datagrid event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgClaimList.Rows.Count > 0)
                {
                    //get row is removed on grid
                    clsLGClaimDTO claimDto = new clsLGClaimDTO();
                    claimDto.SeqLG = int.Parse(dtgClaimList.SelectedRows[0].Cells[m_colSeqLG].Value.ToString());
                    claimDto.SubCode = dtgClaimList.SelectedRows[0].Cells[m_colLGSubNo].Value.ToString();
                    if (dtgClaimList.SelectedRows[0].Cells[m_colClaimedPaymentDate].Value != null)
                    {
                        clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                            clsLGCommonMessage.ERROR_CLAIM_WAS_PAYMENT);
                        return;
                    }
                    for (int i = 0; i < m_LstClaim.Count; i++)
                    {
                        if (m_LstClaim[i].SeqLG == claimDto.SeqLG && m_LstClaim[i].SubCode.Equals(claimDto.SubCode))
                        {
                            m_LstClaim[i].IsDelete = 1;
                            //remove row on grid
                            dtgClaimList.Rows.Remove(dtgClaimList.SelectedRows[0]);
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Row added event on claim list datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void dtgClaimList_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            try
            {
                if (dtgClaimList.Rows.Count <= 0)
                {
                    btnRemove.Enabled = false;
                }
                else
                {
                    btnRemove.Enabled = true;
                    dtgClaimList.CellValueChanged -= dtgClaimList_CellValueChanged;
                    //reset value on column 'No'
                    for (int i = 0; i < dtgClaimList.Rows.Count; i++)
                    {
                        this.dtgClaimList.Rows[i].Cells[m_colNo].Value = i + 1;
                    }
                    dtgClaimList.CellValueChanged += dtgClaimList_CellValueChanged;
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Column header mouse click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgClaimList_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (dtgClaimList.Rows.Count > 0)
                {
                    //reset value on column 'No'
                    for (int i = 0; i < dtgClaimList.Rows.Count; i++)
                    {
                        this.dtgClaimList.Rows[i].Cells[m_colNo].Value = i + 1;
                    }
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Check if there is any change on datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void dtgClaimList_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dtgClaimList.Rows.Count > 0)
                {
                    //get index of list claim is changed
                    int indexListClaim = m_LstClaim.FindIndex(c => c.SeqLG == int.Parse(dtgClaimList.SelectedRows[0].Cells[m_colSeqLG].Value.ToString())
                        && c.SubCode == dtgClaimList.SelectedRows[0].Cells[m_colLGSubNo].Value.ToString());
                    if (indexListClaim >= 0)
                    {
                        //set status is 'change' when data is changed
                        m_LstClaim[indexListClaim].IsChange = 1;
                        if (dtgClaimList.SelectedRows[0].Cells[m_colClaimedDate].Value != null)
                        {
                            m_LstClaim[indexListClaim].ClaimedDate = Convert.ToDateTime(dtgClaimList.SelectedRows[0].Cells[m_colClaimedDate].Value);
                        }
                        if (dtgClaimList.SelectedRows[0].Cells[m_colClaimedPaymentDate].Value != null)
                        {
                            m_LstClaim[indexListClaim].ClaimedPaymentDate = Convert.ToDateTime(dtgClaimList.SelectedRows[0].Cells[m_colClaimedPaymentDate].Value);
                        }
                        m_LstClaim[indexListClaim].ClaimedCCY = dtgClaimList.SelectedRows[0].Cells[m_colClaimedCCY].Value == null ? String.Empty : dtgClaimList.SelectedRows[0].Cells[m_colClaimedCCY].Value.ToString();
                        m_LstClaim[indexListClaim].ClaimedAmount = Decimal.Parse(dtgClaimList.SelectedRows[0].Cells[m_colClaimedAmount].Value.ToString());
                        m_LstClaim[indexListClaim].Paid = bool.Parse(dtgClaimList.SelectedRows[0].Cells[m_colPaid].Value.ToString());
                        m_LstClaim[indexListClaim].Remark = dtgClaimList.SelectedRows[0].Cells[m_colRemark].Value.ToString();
                    }
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Form closing event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void frmLGClaimList_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    //check data is changed on grid
                    if (IsChangeClaimOnDataGrid())
                    {
                        DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                            string.Format(clsLGCommonMessage.CONFIRM_SAVE_CHANGES));
                        if (result == DialogResult.Yes)
                        {
                            //save list claim on grid
                            if (!SaveListClaim())
                            {
                                e.Cancel = true;
                            }
                        }
                        else if (result == DialogResult.No)
                        {
                            e.Cancel = false;
                        }
                        else if (result == DialogResult.Cancel)
                        {
                            e.Cancel = true;
                        }
                    }
                }
                else
                {
                    //close form   
                    this.FormClosing -= new FormClosingEventHandler(frmLGClaimList_FormClosing);
                    this.Close();
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }
        /// <summary>
        /// Button save click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //check data on grid is changed
                if (IsChangeClaimOnDataGrid())
                {
                    DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                        String.Format(clsLGCommonMessage.CONFIRM_ACTION, clsLGConstant.ACTION_SAVE, clsLGConstant.LG_CLAIM_NAME));
                    if (result == DialogResult.Yes)
                    {
                        //save list claim on grid
                        SaveListClaim();
                    }
                    else if (result == DialogResult.No)
                    {
                        //close form
                        frmLGClaimList_FormClosing(null, null);
                    }
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_ClaimBus.RollBack();
                }
                catch (System.Exception) { }
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Cell end edit event on datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void dtgClaimList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == dtgClaimList.Columns[m_colClaimedAmount].Index)
                {
                    if (!(dtgClaimList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() == "0" ||
                        dtgClaimList.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().Trim() == ""))
                    {
                        //check Claim Amount > Current LG Amount to show message error
                        if (Decimal.Parse(dtgClaimList.Rows[e.RowIndex].Cells[m_colCurrentLGAmount].Value.ToString()) < Decimal.Parse(dtgClaimList.Rows[e.RowIndex].Cells[m_colClaimedAmount].Value.ToString()))
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                                String.Format(clsLGCommonMessage.ERROR_COMPARE_FIELD, dtgClaimList.Columns[m_colClaimedAmount].HeaderText, dtgClaimList.Columns[m_colCurrentLGAmount].HeaderText));
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }


        /// <summary>
        /// Cell click event on grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtgClaimList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dtgClaimList.Columns[e.ColumnIndex].Name.Equals(m_colPaid) && e.RowIndex >= 0)
                {
                    //set value of Paid cell when user checked             
                    dtgClaimList.Rows[e.RowIndex].Cells[m_colPaid].Value = !(bool)dtgClaimList.Rows[e.RowIndex].Cells[m_colPaid].Value;
                    dtgClaimList.EndEdit();
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        #endregion

        #region private functions
        /// <summary>
        /// Fill data to datagridview
        /// </summary>
        /// <param name="strSeqLG"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void FillData(int strSeqLG)
        {
            m_ClaimBus = new clsLGListClaimBus();
            //get list claim from database
            m_LstClaim = m_ClaimBus.GetListClaimed(strSeqLG);
            // backup list claim
            m_LstClaimBackup = m_LstClaim.ConvertAll(item => new clsLGClaimDTO(item));
            if (m_LstClaim.Count == 0)
            {
                btnRemove.Enabled = false;
                btnSave.Enabled = false;
                return;
            }
            btnRemove.Enabled = true;
            btnSave.Enabled = true;
            for (int i = 0; i < m_LstClaim.Count; i++)
            {
                //set data to grid Claim on form
                dtgClaimList.Rows.Add(
                    i + 1, m_LstClaim[i].ClaimedDate, m_LstClaim[i].ClaimedCCY, m_LstClaim[i].SubCode,
                    m_LstClaim[i].CurrentLGAmount, m_LstClaim[i].ClaimedAmount, m_LstClaim[i].Paid, m_LstClaim[i].ClaimedPaymentDate,
                    m_LstClaim[i].Remark, m_LstClaim[i].SeqLG, m_LstClaim[i].IsExist, m_LstClaim[i].IsChange, m_LstClaim[i].IsDelete);
            }
        }
        /// <summary>
        /// Set form style
        /// </summary>
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void SetFormStyle()
        {
            //set form style
            base.SetFormStyleCommon();
            //set max length
            txtBenificiaryName.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_NAME;
            txtCustomerCode.MaxLength = clsLGConstant.LENGTH_CUSTOMER_CODE;
            txtCustomerName.MaxLength = clsLGConstant.LENGTH_CUSTOMER_NAME;
        }

        /// <summary>
        /// Save claim list
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool SaveListClaim()
        {
            string nameValidation = string.Empty;
            List<clsLGLogBase> lstLogBase = new List<clsLGLogBase>();
            //Check cell value on grid
            if (!CheckDataOnGridNotNull(ref nameValidation))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, nameValidation));
                return false;
            }
            if (m_LstClaim.Count == 0)
            {
                return false;
            }

            List<clsLGClaimDTO> lst = new List<clsLGClaimDTO>();
            for (int i = 0; i < m_LstClaim.Count; i++)
            {
                clsLGLogBase logBase = new clsLGLogBase();
                //header history
                logBase.ApplicationName = this.Text;
                logBase.UserID = clsUserInfo.UserNo.ToString();
                logBase.Key = txtLGNo.Text.Trim() + "-" + m_LstClaim[i].SubCode;

                /* If IsExist = 1 : data exist in database
                 * If IsExist = 0 : data not exist in database
                 */
                if (m_LstClaim[i].IsExist == 1)
                {
                    /* If IsChange = 1 : data on row is changed
                     * If IsChange = 0 : data on row is not changed
                     * If IsDelete = 1 : data on row is deleted
                     * If IsDelete = 0 : data on row is not deleted
                     */
                    if (m_LstClaim[i].IsDelete == 1)
                    {
                        //+ Deleting Log 
                        logBase.Action = (int)CommonValue.ActionType.Delete;
                        //add logbase to list logbase
                        lstLogBase.Add(logBase);
                    }
                    else
                    {
                        if (m_LstClaim[i].IsChange == 1)
                        {
                            //+ Updating Log 
                            logBase.Action = (int)CommonValue.ActionType.Update;
                            //get List Log Information
                            logBase.LstLogInformation = GetLogInformationUpdate(m_LstClaimBackup[i], m_LstClaim[i]);
                            //add logbase to list logbase
                            lstLogBase.Add(logBase);
                        }
                        //add record on list claim to insert data again
                        lst.Add(m_LstClaim[i]);
                    }
                }
                else
                {
                    /* If IsChange = 1 : data on row is changed
                     * If IsChange = 0 : data on row is not changed
                     * If IsDelete = 1 : data on row is deleted
                     * If IsDelete = 0 : data on row is not deleted
                     */
                    if (m_LstClaim[i].IsChange == 1 && m_LstClaim[i].IsDelete == 0)
                    {
                        //+ Inserting Log 
                        logBase.Action = (int)CommonValue.ActionType.New;
                        //get List Log Information
                        logBase.LstLogInformation = GetLogInformationInsert(m_LstClaim[i]);
                        //add logbase to list logbase
                        lstLogBase.Add(logBase);
                        lst.Add(m_LstClaim[i]);
                    }
                }

                if (m_LstClaim[i].IsDelete == 0 && m_LstClaim[i].IsChange == 1)
                {
                    //lst.Add(m_LstClaim[i]);
                }
            }
            if (lst.Count > 0)
            {
                //insert list Claim is changed            
                if (m_ClaimBus.SaveListClaim(lst, m_SeqLG) > 0)
                {
                    //write list log history
                    WriteLog(lstLogBase);
                    //Commit data
                    m_ClaimBus.Commit();
                    //reset change status row on grid
                    ResetIsChangeRowOnGrid();
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                        string.Format(clsLGCommonMessage.INFOR_ACTION_SUCCESS, clsLGConstant.ACTION_SAVING, clsLGConstant.LG_CLAIM_NAME));
                    
                }
                else
                {
                    //rollback data
                    m_ClaimBus.RollBack();
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        string.Format(clsLGCommonMessage.ERROR_ACTION_FAIL, clsLGConstant.ACTION_SAVING, clsLGConstant.LG_CLAIM_NAME));
                    return false;
                }
            }
            return true;
        }


        /// <summary>
        /// Write list log history
        /// </summary>
        /// <param name="lstLogBase"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLog(List<clsLGLogBase> lstLogBase)
        {
            clsLGLogBase logBaseDelete = new clsLGLogBase();
            List<string> lstKey = new List<string>();
            for (int i = 0; i < lstLogBase.Count; i++)
            {
                //add key to list key to write log history for action 'Delete'
                if (lstLogBase[i].Action == (int)CommonValue.ActionType.Delete)
                {
                    lstKey.Add(lstLogBase[i].Key);
                }
                //write log history for action 'Insert' or 'Update'
                else if (lstLogBase[i].Action == (int)CommonValue.ActionType.New || lstLogBase[i].Action == (int)CommonValue.ActionType.Update)
                {
                    m_ClaimBus.WriteLog(lstLogBase[i]);
                }
            }
            //write log history for action 'Delete'
            if (lstKey.Count > 0)
            {
                logBaseDelete.ApplicationName = this.Text;
                logBaseDelete.UserID = clsUserInfo.UserNo.ToString();
                logBaseDelete.Action = (int)CommonValue.ActionType.Delete;
                logBaseDelete.Key = String.Join(",", lstKey.ToArray());
                m_ClaimBus.WriteLog(logBaseDelete);
            }
        }

        /// <summary>
        /// Get log information for action 'Insert' log history
        /// </summary>
        /// <param name="claimDto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private List<clsLGLogInformation> GetLogInformationInsert(clsLGClaimDTO claimDto)
        {
            List<clsLGLogInformation> lst = new List<clsLGLogInformation>();
            //set value for list Log Information to insert history
            lst.Add(new clsLGLogInformation
            {
                FieldName = dtgClaimList.Columns[m_colClaimedDate].HeaderText,
                NewValue = claimDto.ClaimedDate == null ? "" : claimDto.ClaimedDate.Value.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD)
            });
            lst.Add(new clsLGLogInformation
            {
                FieldName = dtgClaimList.Columns[m_colClaimedCCY].HeaderText,
                NewValue = claimDto.ClaimedCCY
            });
            lst.Add(new clsLGLogInformation
            {
                FieldName = dtgClaimList.Columns[m_colLGSubNo].HeaderText,
                NewValue = claimDto.SubCode
            });
            lst.Add(new clsLGLogInformation
            {
                FieldName = dtgClaimList.Columns[m_colClaimedAmount].HeaderText,
                NewValue = claimDto.ClaimedAmount.ToString()
            });
            lst.Add(new clsLGLogInformation
            {
                FieldName = dtgClaimList.Columns[m_colPaid].HeaderText,
                NewValue = claimDto.Paid.ToString()
            });
            lst.Add(new clsLGLogInformation
            {
                FieldName = dtgClaimList.Columns[m_colClaimedPaymentDate].HeaderText,
                NewValue = claimDto.ClaimedPaymentDate == null ? "" :
                    claimDto.ClaimedPaymentDate.Value.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD)
            });
            lst.Add(new clsLGLogInformation
            {
                FieldName = dtgClaimList.Columns[m_colRemark].HeaderText,
                NewValue = claimDto.Remark
            });
            return lst;
        }

        /// <summary>
        /// Get log information for action 'Update' log history
        /// </summary>
        /// <param name="claimDtoBackup"></param>
        /// <param name="claimDto"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private List<clsLGLogInformation> GetLogInformationUpdate(clsLGClaimDTO claimDtoBackup, clsLGClaimDTO claimDto)
        {
            List<clsLGLogInformation> lst = new List<clsLGLogInformation>();
            //set value for list Log Information to update history
            if (claimDtoBackup.ClaimedDate != claimDto.ClaimedDate)
            {
                lst.Add(new clsLGLogInformation
                {
                    FieldName = dtgClaimList.Columns[m_colClaimedDate].HeaderText,
                    OldValue = claimDtoBackup.ClaimedDate == null ? "" : claimDtoBackup.ClaimedDate.Value.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD),
                    NewValue = claimDto.ClaimedDate == null ? "" : claimDto.ClaimedDate.Value.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD)
                });
            }
            if (claimDtoBackup.ClaimedCCY != claimDto.ClaimedCCY)
            {
                lst.Add(new clsLGLogInformation
                {
                    FieldName = dtgClaimList.Columns[m_colClaimedCCY].HeaderText,
                    OldValue = claimDtoBackup.ClaimedCCY,
                    NewValue = claimDto.ClaimedCCY
                });
            }
            if (claimDtoBackup.SubCode != claimDto.SubCode)
            {
                lst.Add(new clsLGLogInformation
                {
                    FieldName = dtgClaimList.Columns[m_colLGSubNo].HeaderText,
                    OldValue = claimDtoBackup.SubCode,
                    NewValue = claimDto.SubCode
                });
            }
            if (claimDtoBackup.ClaimedAmount != claimDto.ClaimedAmount)
            {
                lst.Add(new clsLGLogInformation
                {
                    FieldName = dtgClaimList.Columns[m_colClaimedAmount].HeaderText,
                    OldValue = claimDtoBackup.ClaimedAmount.ToString(),
                    NewValue = claimDto.ClaimedAmount.ToString()
                });
            }
            if (claimDtoBackup.Paid != claimDto.Paid)
            {
                lst.Add(new clsLGLogInformation
                {
                    FieldName = dtgClaimList.Columns[m_colPaid].HeaderText,
                    OldValue = claimDtoBackup.Paid.ToString(),
                    NewValue = claimDto.Paid.ToString()
                });
            }
            if (claimDtoBackup.ClaimedPaymentDate != claimDto.ClaimedPaymentDate)
            {
                lst.Add(new clsLGLogInformation
                {
                    FieldName = dtgClaimList.Columns[m_colClaimedPaymentDate].HeaderText,
                    OldValue = claimDtoBackup.ClaimedPaymentDate == null ? "" :
                        claimDtoBackup.ClaimedPaymentDate.Value.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD),
                    NewValue = claimDto.ClaimedPaymentDate == null ? "" :
                        claimDto.ClaimedPaymentDate.Value.ToString(clsLGConstant.LG_FORMAT_YYYYMMDD)
                });
            }
            if (claimDtoBackup.Remark != claimDto.Remark)
            {
                lst.Add(new clsLGLogInformation
                {
                    FieldName = dtgClaimList.Columns[m_colRemark].HeaderText,
                    OldValue = claimDtoBackup.Remark,
                    NewValue = claimDto.Remark
                });
            }
            return lst;
        }

        /// <summary>
        /// Check change data on list Claim
        /// Return True: data is changed
        /// Return False: data isn't changed
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsChangeClaimOnDataGrid()
        {
            for (int i = 0; i < m_LstClaim.Count; i++)
            {
                /* If IsExist = 1 : data exist in database
                 * If IsExist = 0 : data not exist in database
                 */
                if (m_LstClaim[i].IsExist == 1)
                {
                    /* If IsChange = 1 : data on row is changed
                     * If IsChange = 0 : data on row is not changed
                     * If IsDelete = 1 : data on row is deleted
                     * If IsDelete = 0 : data on row is not deleted
                     */
                    if (m_LstClaim[i].IsChange == 1 || m_LstClaim[i].IsDelete == 1)
                    {
                        return true;
                    }
                }
                else
                {
                    /* If IsChange = 1 : data on row is changed
                     * If IsChange = 0 : data on row is not changed
                     * If IsDelete = 1 : data on row is deleted
                     * If IsDelete = 0 : data on row is not deleted
                     */
                    if (m_LstClaim[i].IsChange == 1 && m_LstClaim[i].IsDelete == 0)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Check data on grid
        /// If field on grid is null return false else return true
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool CheckDataOnGridNotNull(ref string nameValidation)
        {
            for (int i = 0; i < m_LstClaim.Count; i++)
            {
                /* If IsExist = 1 : data exist in database
                 * If IsExist = 0 : data not exist in database
                 */
                if (m_LstClaim[i].IsExist == 1)
                {
                    /* If IsChange = 1 : data on row is changed
                     * If IsChange = 0 : data on row is not changed
                     * If IsDelete = 1 : data on row is deleted
                     * If IsDelete = 0 : data on row is not deleted
                     */
                    if (m_LstClaim[i].IsChange == 1 && m_LstClaim[i].IsDelete == 0)
                    {
                        //check Claimed CCY when Paid is checked
                        if (m_LstClaim[i].Paid == true && String.IsNullOrEmpty(m_LstClaim[i].ClaimedCCY))
                        {
                            nameValidation = dtgClaimList.Columns[m_colClaimedCCY].HeaderText;
                            return false;
                        }
                        //check Claimed Amount when Paid is checked
                        if (m_LstClaim[i].Paid == true && m_LstClaim[i].ClaimedAmount <= 0)
                        {
                            nameValidation = dtgClaimList.Columns[m_colClaimedAmount].HeaderText;
                            return false;
                        }
                        //check Claimed Payment Date when Paid is checked
                        if (m_LstClaim[i].Paid == true && m_LstClaim[i].ClaimedPaymentDate == null)
                        {
                            nameValidation = dtgClaimList.Columns[m_colClaimedPaymentDate].HeaderText;
                            return false;
                        }
                    }
                }
                else
                {
                    /* If IsChange = 1 : data on row is changed
                     * If IsChange = 0 : data on row is not changed
                     * If IsDelete = 1 : data on row is deleted
                     * If IsDelete = 0 : data on row is not deleted
                     */
                    if (m_LstClaim[i].IsChange == 1 && m_LstClaim[i].IsDelete == 0)
                    {
                        ////check Claimed Date is null
                        if (m_LstClaim[i].ClaimedDate == null)
                        {
                            nameValidation = dtgClaimList.Columns[m_colClaimedDate].HeaderText;
                            return false;
                        }
                        //check Claimed CCY when Paid is checked
                        if (m_LstClaim[i].Paid == true && String.IsNullOrEmpty(m_LstClaim[i].ClaimedCCY))
                        {
                            nameValidation = dtgClaimList.Columns[m_colClaimedCCY].HeaderText;
                            return false;
                        }
                        //check Claimed Amount when Paid is checked
                        if (m_LstClaim[i].Paid == true && m_LstClaim[i].ClaimedAmount <= 0)
                        {
                            nameValidation = dtgClaimList.Columns[m_colClaimedAmount].HeaderText;
                            return false;
                        }
                        //check Claimed Payment Date when Paid is checked
                        if (m_LstClaim[i].Paid == true && m_LstClaim[i].ClaimedPaymentDate == null)
                        {
                            nameValidation = dtgClaimList.Columns[m_colClaimedPaymentDate].HeaderText;
                            return false;
                        }
                    }
                }
            }
            return true;
        }


        /// <summary>
        /// Reset change status on grid Claim
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void ResetIsChangeRowOnGrid()
        {
            //get list claim from database again            
            m_ClaimBus = new clsLGListClaimBus();
            //get list claim from database
            m_LstClaim = m_ClaimBus.GetListClaimed(m_SeqLG);
            // backup list claim
            m_LstClaimBackup = m_LstClaim.ConvertAll(item => new clsLGClaimDTO(item));
        }

        #endregion

        private void dtgClaimList_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (clsLGCommonBus.Instance().MainCCYList.Contains((string)dtgClaimList.Rows[e.RowIndex].Cells[2].Value))
            {

                ((TNumEditDataGridViewCell)dtgClaimList.Rows[e.RowIndex].Cells[5]).DecimalLength = 0;
                ((TNumEditDataGridViewCell)dtgClaimList.Rows[e.RowIndex].Cells[5]).MaxInputLength = 10;
              
            }
            else
            {
                ((TNumEditDataGridViewCell)dtgClaimList.Rows[e.RowIndex].Cells[5]).DecimalLength = 2;
                ((TNumEditDataGridViewCell)dtgClaimList.Rows[e.RowIndex].Cells[5]).MaxInputLength = 13;
             

            }
        }
    }
}