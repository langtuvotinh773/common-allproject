﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-01-21 09:30:00 +0700 (Mon, 21 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to management download macro
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGDownloadMacro : frmLGMaster
    {

        clsLGBus m_LGBus = null;

        /// <summary>
        /// Contructor
        /// </summary>
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmLGDownloadMacro()
        {
            InitializeComponent();
            m_LGBus = new clsLGBus();
            LoadDownloadMacroTypeList();
			SetFormStyleCommon();
			SetFormStyle();
        }
		// <summary>
		/// Set form style
		/// </summary>
		/// @cond
		/// Author: Yen Phan
		/// @endcond
		private void SetFormStyle() 
		{
			txtLGNo.MaxLength = clsLGConstant.LENGTH_GL_CODE;
		}
        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Load GLCode list
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void LoadDownloadMacroTypeList()
        {
            try
            {
                cbbType.DataSource = null;
                cbbType.Items.Clear();

                ArrayList arrOL = m_LGBus.GetDownloadMacroTypeList();
                if (arrOL.Count == 0)
                    return;
                cbbType.DataSource = arrOL;
                cbbType.DisplayMember = "Display";
                cbbType.ValueMember = "Value";
            }
            catch (Exception)
            {
                //clsLogFile.LogException(ex.Message); 
            }
        }
    }
}
