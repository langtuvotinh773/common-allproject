﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-22 16:00:00 +0700 (Fri, 22 Mar 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to create beneficiary
 * for LG module.
 */

using System;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGCreateBeneficiary : frmLGMaster
    {
        #region Variables

        private clsLGBeneficiaryDTO m_clsLGBeneficiaryDTO;
        private clsLGBeneficiaryBus m_clsLGBeneficiaryBus;
        public string NewBeneficiary = "";
        #endregion

        #region Contructor
        /// <summary>
        /// Initializes a new instance of the <see cref="frmFinalizeCPAData" /> class to create applicant 
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmLGCreateBeneficiary()
        {
            InitializeComponent();
            base.SetFormStyleCommon();
            SetFormStyle();
            m_clsLGBeneficiaryDTO = new clsLGBeneficiaryDTO();
            m_clsLGBeneficiaryBus = new clsLGBeneficiaryBus();
            _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
            _security.CheckAuthorizationOnScreen(this);
        }

        #endregion

        #region Event Functions

        /// <summary>
        /// Event btnSave applicant to database
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //show message confirm save data
                DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                    String.Format(clsLGCommonMessage.CONFIRM_ACTION, clsLGConstant.ACTION_SAVE, clsLGConstant.BENEFICIARY_NAME));
                if (result == DialogResult.Yes)
                {
                    //save data on form
                    SaveData();
                }
                else if (result == DialogResult.No)
                {
                    //close form
                    frmLGCreateBeneficiary_FormClosing(null, null);
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_clsLGBeneficiaryBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Event button Close Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Event Form Closing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void frmLGCreateBeneficiary_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    //[When this screen has already openned. If click again,this screen will be focused. (don't open more)]
                    // => refer form 'frmLGMaster' .Go to function 'frmLGMaster_Load'
                    if (e.CloseReason == CloseReason.UserClosing && btnSave.Tag != null && (bool)btnSave.Tag == true)
                    {
                        //check data is changed on form
                        if (IsChangeValueOnForm())
                        {
                            //show message confir save data
                            DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                                clsLGCommonMessage.CONFIRM_SAVE_CHANGES);
                            if (result == DialogResult.Yes)
                            {
                                //save data on form
                                if (!SaveData())
                                {
                                    e.Cancel = true;
                                }
                            }
                            else if (result == DialogResult.No)
                            {
                                e.Cancel = false;
                            }
                            else if (result == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                        }
                    }
                }
                else
                {
                    //close form
                    this.FormClosing -= new FormClosingEventHandler(frmLGCreateBeneficiary_FormClosing);
                    this.Close();
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }
        #endregion

        #region Private Functions

        /// <summary>
        /// Set Form Style
        /// </summary> 
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void SetFormStyle()
        {
            //set max length for textbox on form
            #region MAX LENGTH
            txtBeneficiaryAddress.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_ADDRESS;
            txtBeneficiaryCode.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_CODE;
            txtBeneficiaryFax.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_FAX;
            txtBeneficiaryName.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_NAME;
            txtBeneficiaryNational.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_NATIONAL;
            txtBeneficiaryTel.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_TEL;
            #endregion
        }


        /// <summary>
        /// Get Data on Form
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataValue()
        {
            //get data on form
            m_clsLGBeneficiaryDTO.BeneficiaryName = txtBeneficiaryName.Text.Trim();
            NewBeneficiary = m_clsLGBeneficiaryDTO.BeneficiaryName;
            m_clsLGBeneficiaryDTO.BeneficiaryAddress = txtBeneficiaryAddress.Text.Trim();
            m_clsLGBeneficiaryDTO.BeneficiaryNational = txtBeneficiaryNational.Text.Trim();
            m_clsLGBeneficiaryDTO.BeneficiaryTel = txtBeneficiaryTel.Text.Trim();
            m_clsLGBeneficiaryDTO.BeneficiaryFax = txtBeneficiaryFax.Text.Trim();
            m_clsLGBeneficiaryDTO.CreatedBy = clsUserInfo.UserNo;
        }

        /// <summary>
        /// Check Data Input On Form
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsCheckDataInputOnForm()
        {
            //check Beneficiary Name on form is null or empty
            if (String.IsNullOrEmpty(txtBeneficiaryName.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblBeneficiaryName.Text));
                txtBeneficiaryName.Focus();
                return false;
            }
            //check Beneficiary Address on form is null or empty
            if (String.IsNullOrEmpty(txtBeneficiaryAddress.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblBeneficiaryAddress.Text));
                txtBeneficiaryAddress.Focus();
                return false;
            }
            //check Beneficiary Nationality on form is null or empty
            if (String.IsNullOrEmpty(txtBeneficiaryNational.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblBeneficiaryNationality.Text));
                txtBeneficiaryNational.Focus();
                return false;
            }
            //check Beneficiary Tel on form is null or empty
            if (String.IsNullOrEmpty(txtBeneficiaryTel.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblBeneficiaryTel.Text));
                txtBeneficiaryTel.Focus();
                return false;
            }
            //check Beneficiary Fax on form is null or empty
            if (String.IsNullOrEmpty(txtBeneficiaryFax.Text.Trim()))
            {
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_FIELD_IS_NULL, lblBeneficiaryFax.Text));
                txtBeneficiaryFax.Focus();
                return false;
            }
            return true;
        }

        /// <summary>
        /// Save Data on Form
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool SaveData()
        {
            //check data on form is changed
            if (!IsCheckDataInputOnForm())
            {
                return false;
            }
            //get data for insert Beneficiary
            GetDataValue();
            //'returnValue' used to check data input database
            int returnValue = m_clsLGBeneficiaryBus.InsertBeneficiary(m_clsLGBeneficiaryDTO);
            if (returnValue == 1)
            {
                //write log history
                WriteLog(m_clsLGBeneficiaryDTO);
                //commit data
                m_clsLGBeneficiaryBus.Commit();
                this.DialogResult = DialogResult.OK;
                //show message after save data is success
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                    String.Format(clsLGCommonMessage.INFOR_ACTION_SUCCESS, clsLGConstant.ACTION_CREATING, clsLGConstant.BENEFICIARY_NAME));
                frmLGCreateBeneficiary_FormClosing(null, null);
            }
            else if (returnValue == -1)
            {
                //rollback data
                m_clsLGBeneficiaryBus.RollBack();
                //show message error after save data is failed
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_IS_EXISTED, txtBeneficiaryName.Text.Trim(), lblBeneficiaryName.Text));
                return false;
            }
            else
            {
                //rollback data
                m_clsLGBeneficiaryBus.RollBack();
                //show message error after save data is failed
                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                    String.Format(clsLGCommonMessage.ERROR_ACTION_FAIL, clsLGConstant.ACTION_CREATING, clsLGConstant.BENEFICIARY_NAME));
                return false;
            }
            return true;
        }

        /// <summary>
        /// Write log history
        /// </summary>
        /// <param name="applicantDto"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLog(clsLGBeneficiaryDTO beneficiaryDto)
        {
            clsLGLogBase logBase = new clsLGLogBase();
            //header history
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            logBase.Key = beneficiaryDto.BeneficiaryName;
            //+ Inserting Log 
            logBase.Action = (int)CommonValue.ActionType.New;
            //add information of log history
            logBase.LstLogInformation.Add(
                new clsLGLogInformation
                {
                    //add Beneficiary Address to insert history
                    FieldName = lblBeneficiaryAddress.Text,
                    OldValue = String.Empty,
                    NewValue = beneficiaryDto.BeneficiaryAddress
                });

            logBase.LstLogInformation.Add(
                new clsLGLogInformation
                {
                    //add Beneficiary Nationality to insert history
                    FieldName = lblBeneficiaryNationality.Text,
                    OldValue = String.Empty,
                    NewValue = beneficiaryDto.BeneficiaryNational
                });

            logBase.LstLogInformation.Add(
                new clsLGLogInformation
                {
                    //add Beneficiary Tel to insert history
                    FieldName = lblBeneficiaryTel.Text,
                    OldValue = String.Empty,
                    NewValue = beneficiaryDto.BeneficiaryTel
                });

            logBase.LstLogInformation.Add(
                new clsLGLogInformation
                {
                    //add Beneficiary Fax to insert history
                    FieldName = lblBeneficiaryFax.Text,
                    OldValue = String.Empty,
                    NewValue = beneficiaryDto.BeneficiaryFax
                });
            //write log data
            m_clsLGBeneficiaryBus.WriteLog(logBase);
        }

        /// <summary>
        /// Check data is changed on form
        /// Return true data is changed
        /// Return false data is not changed
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private bool IsChangeValueOnForm()
        {
            //check data on form is changed
            if (m_clsLGBeneficiaryDTO.BeneficiaryName != txtBeneficiaryName.Text.Trim() ||
                m_clsLGBeneficiaryDTO.BeneficiaryAddress != txtBeneficiaryAddress.Text.Trim() ||
                m_clsLGBeneficiaryDTO.BeneficiaryNational != txtBeneficiaryNational.Text.Trim() ||
                m_clsLGBeneficiaryDTO.BeneficiaryTel != txtBeneficiaryTel.Text.Trim() ||
                m_clsLGBeneficiaryDTO.BeneficiaryFax != txtBeneficiaryFax.Text.Trim())
            {
                return true;
            }
            return false;
        }
        #endregion

    }
}
