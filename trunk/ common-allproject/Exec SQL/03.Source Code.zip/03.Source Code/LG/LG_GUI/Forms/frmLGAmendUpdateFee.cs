﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Dto;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Config.Classes;
using Phoenix.Common.Functions;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGAmendUpdateFee : frmLGMaster
    {
        public AmendFee m_fee;
        List<string> m_lstChangeControls;
        LG m_data;
        decimal m_oldTextFee = 0;
        public frmLGAmendUpdateFee(LG data, AmendFee fee)
        {
            InitializeComponent();
            try
            {
                m_data = data;
                m_lstChangeControls = new List<string>();
                m_fee = fee;
                txtFlatFee.Text = m_fee.FlatFee.ToString(txtFlatFee.StringFormat);
                txtExchangeRate.Text = m_fee.ExchangeRate.ToString(txtExchangeRate.StringFormat);



                cbbCCY.DataSource = clsLGCommonBus.Instance().GetListCurrency();
                cbbCCY.DisplayMember = "Name";
                cbbCCY.ValueMember = "Value";
                cbbCCY.SelectedValue = m_fee.CCY;
                cbbAccount.DropDownStyle = ComboBoxStyle.DropDownList;
                cbbCCY.DropDownStyle = ComboBoxStyle.DropDownList;

                clsLGIssueBus bus = new clsLGIssueBus();
                List<clsLGAccountInfoDTO> lst = bus.GetListAccount(data.Master.CustomerCode);
                for (int i = 0; i < lst.Count; i++)
                {
                    if (lst[i].AccountNo != "")
                        lst[i].AccountNo = lst[i].AccountNo.Remove(0, 4);



                }
                if (data.Master.LgType == 2) //couter
                {
                    lst.Clear();
                    lst.Add(new clsLGAccountInfoDTO(clsLGConstant.LG_COUNTER_ACCOUNT, clsLGConstant.LG_COUNTER_ACCOUNT));
                }
                cbbAccount.DataSource = lst;
                cbbAccount.DisplayMember = "AccountNo";
                cbbAccount.ValueMember = "AccountNo";
                cbbAccount.SelectedValue = m_fee.Account;

                txtAmendFee.Text = m_fee.Fee.ToString(txtAmendFee.StringFormat);

                m_lstChangeControls.Clear();
                m_oldTextFee = decimal.Parse(txtFlatFee.Text.Replace(",", ""));
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_lstChangeControls.Count > 0)
                {
                    DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.CONFIRM_ACTION, new string[] { "save", "fee" });
                    if (result == DialogResult.Yes)
                    {
                        string error = Save();
                        if (error != "")
                        {
                            if (error != "None") // already show message in CheckDate funtion
                            {
                                m_fee = null;
                                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                            }
                        }
                        else
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "fee" });
                            m_lstChangeControls.Clear();
                            this.Close();
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        private string Save()
        {
            string error = "";
            m_fee.Account = cbbAccount.Text;
            if (cbbAccount.Text == "")
            {
                error = "Account";
                cbbAccount.Focus();

            }
            m_fee.CCY = cbbCCY.Text;
            if (cbbCCY.Text == "")
            {
                error = "Charge CCY";
                cbbCCY.Focus();
            }
            m_fee.ExchangeRate = decimal.Parse(txtExchangeRate.Text);
            m_fee.FlatFee = decimal.Parse(txtFlatFee.Text);
            m_fee.Fee =txtAmendFee.Text == "" ? 0 : decimal.Parse(txtAmendFee.Text);
            return error;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtFlatFee_TextChanged(object sender, EventArgs e)
        {
            if (txtFlatFee.Text != "" && decimal.Parse(txtFlatFee.Text.Replace(",", "")) != m_oldTextFee)
            {
                if (this.Visible)
                {
                    if (!m_lstChangeControls.Contains(txtFlatFee.Name))
                        m_lstChangeControls.Add(txtFlatFee.Name);
                }
                if (txtFlatFee.Text == "" || decimal.Parse(txtFlatFee.Text) == m_fee.FlatFee)
                {
                    if (m_lstChangeControls.Contains(txtFlatFee.Name))
                        m_lstChangeControls.Remove(txtFlatFee.Name);
                }
                ReCalculate();
                m_oldTextFee = decimal.Parse(txtFlatFee.Text.Replace(",", ""));
            }

        }

        private void txtExchangeRate_TextChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (!m_lstChangeControls.Contains(txtExchangeRate.Name))
                    m_lstChangeControls.Add(txtExchangeRate.Name);
            }
            if (txtExchangeRate.Text == "" || decimal.Parse(txtExchangeRate.Text) == m_fee.ExchangeRate)
            {
                if (m_lstChangeControls.Contains(txtExchangeRate.Name))
                    m_lstChangeControls.Remove(txtExchangeRate.Name);
            }
            ReCalculate();
        }

        private void cbbAccount_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (!m_lstChangeControls.Contains(cbbAccount.Name))
                    m_lstChangeControls.Add(cbbAccount.Name);
            }
            if (cbbAccount.SelectedText == "")
            {
                if (m_lstChangeControls.Contains(cbbAccount.Name))
                    m_lstChangeControls.Remove(cbbAccount.Name);
            }
        }

        private void cbbCCY_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (!m_lstChangeControls.Contains(cbbCCY.Name))
                    m_lstChangeControls.Add(cbbCCY.Name);
            }
            if (cbbCCY.SelectedText == "")
            {
                if (m_lstChangeControls.Contains(cbbCCY.Name))
                    m_lstChangeControls.Remove(cbbCCY.Name);
            }
            if(this.Visible)
                GetRate();
        }

        private void txtAmendFee_TextChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (!m_lstChangeControls.Contains(txtAmendFee.Name))
                    m_lstChangeControls.Add(txtAmendFee.Name);
            }
            if (txtAmendFee.Text == "" || decimal.Parse(txtAmendFee.Text) == m_fee.Fee)
            {
                if (m_lstChangeControls.Contains(txtAmendFee.Name))
                    m_lstChangeControls.Remove(txtAmendFee.Name);
            }
        }

        private void frmLGAmendUpdateFee_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (m_lstChangeControls.Count > 0)
                {
                    DialogResult result = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm, clsLGCommonMessage.DO_YOU_WANT_SAVE);
                    if (result == DialogResult.Yes)
                    {
                        string error = Save();
                        if (error != "")
                        {
                            if (error != "None")
                            {
                                m_fee = null;
                                clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.PLEASE_INPUT, new string[] { error });
                            }
                        }
                        else
                        {
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition, clsLGCommonMessage.INFOR_ACTION_SUCCESS, new string[] { "Saving", "fee" });
                            m_lstChangeControls.Clear();
                            // this.Close();
                        }
                    }
                    if (result == DialogResult.Cancel)
                        e.Cancel = true;

                }
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }
        private void GetRate()
        {
            try
            {
                if (cbbCCY.Text != "" && cbbCCY.Text != "USD")
                {
                    string ccypair = "";
                    if (m_data.Master.LgType == (byte)CommonValue.LGType.Proper)
                    {
                        ccypair = "USD" + "/" + cbbCCY.Text;
                    }
                    else
                    {
                        ccypair = cbbCCY.Text + "/" + "USD";
                    }
                    decimal rate = clsLGCommonBus.Instance().GetRate(clsLGCommonBus.Instance().GetServerDate(), ccypair);
                    if (rate != -1)
                        txtExchangeRate.Text = rate.ToString(txtExchangeRate.StringFormat);

                    else
                    {
                        txtExchangeRate.Text = "0";
                        if (this.Visible == true)
                            clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error, clsLGCommonMessage.CANNOT_GET_RATE);
                    }
                }
                else
                {
                    if (cbbCCY.Text == "USD")
                        txtExchangeRate.Text = "1";
                }
            }
            catch (Exception ex)
            {
                ForceClose = true;
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        private void ReCalculate()
        {
            if (txtExchangeRate.Text != "" && txtFlatFee.Text != "")
            {
                decimal suggess = decimal.Parse(txtFlatFee.Text) * decimal.Parse(txtExchangeRate.Text);
                txtSuggessFee.Text = suggess.ToString(txtSuggessFee.StringFormat);
                if(this.Visible)
                txtAmendFee.Text = suggess.ToString(txtSuggessFee.StringFormat);
            }
            else
            {
                txtSuggessFee.Text = "0";
                if(this.Visible)
                txtAmendFee.Text = "0";
            }

        }
    }
}
