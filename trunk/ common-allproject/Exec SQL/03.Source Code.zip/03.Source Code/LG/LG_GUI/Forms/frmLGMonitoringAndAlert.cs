﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-05 14:29:30 +0700 (Thu, 03 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to monitoring and alert
 * for LG module.
 */
using System;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGMonitoringAndAlert : frmLGMaster
    {
        #region variables

        private clsLGMonitoringAndAlertBus m_MontoringBUS;
        #endregion

        #region Contructos
        /// <summary>
        /// Constructor of mornitoring and alert form
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public frmLGMonitoringAndAlert()
        {
            try
            {
                InitializeComponent();
                base.SetFormStyleCommon();
                m_MontoringBUS = new clsLGMonitoringAndAlertBus();
                /*
                 * If exist Overdue Claim Date > Current Date to show sreen 'Monitoring and Alert'
                 * Else not show screen 'Monitoring and Alert'
                 */
                if (m_MontoringBUS.CheckExistingOverdueClaimDate())
                {
                    this.DialogResult = DialogResult.OK;
                }
				
				_security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }
        #endregion

        #region Event functions
        

        /// <summary>
        /// Process Click Event 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnProcess_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGListLGStaff frmListLGStaff = new frmLGListLGStaff(4);
                foreach (Form obj in Application.OpenForms)
                {
                    if (obj.Name == clsLGConstant.MAIN_FORM_NAME)
                    {
                        frmListLGStaff.MdiParent = obj;
                    }
                }
                //2013.05.03 ADD HTK S Fix Feedback 20130502
                frmListLGStaff.StartPosition = FormStartPosition.CenterScreen;
                //2013.05.03 ADD HTK S Fix Feedback 20130502
                frmListLGStaff.Show();
                this.Close();
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                  Environment.NewLine +
                  ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Cancel event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }       
        #endregion
    }
}
