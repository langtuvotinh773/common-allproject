﻿namespace Phoenix.Lg.Gui.Forms
{
    partial class frmLGCreateApplicant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblApplicantCode = new System.Windows.Forms.Label();
            this.txtApplicantName = new System.Windows.Forms.TextBox();
            this.lblApplicantName = new System.Windows.Forms.Label();
            this.txtApplicantAddress = new System.Windows.Forms.TextBox();
            this.lblApplicantAddress = new System.Windows.Forms.Label();
            this.txtApplicantNational = new System.Windows.Forms.TextBox();
            this.lblApplicantNationality = new System.Windows.Forms.Label();
            this.txtApplicantTel = new System.Windows.Forms.TextBox();
            this.lblApplicantTel = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtApplicantFax = new System.Windows.Forms.TextBox();
            this.lblApplicantFax = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtApplicantCode = new UserCtrl.DisableTextBox();
            this.SuspendLayout();
            // 
            // lblApplicantCode
            // 
            this.lblApplicantCode.AutoSize = true;
            this.lblApplicantCode.Location = new System.Drawing.Point(14, 9);
            this.lblApplicantCode.Name = "lblApplicantCode";
            this.lblApplicantCode.Size = new System.Drawing.Size(79, 13);
            this.lblApplicantCode.TabIndex = 0;
            this.lblApplicantCode.Text = "Applicant Code";
            // 
            // txtApplicantName
            // 
            this.txtApplicantName.Location = new System.Drawing.Point(128, 28);
            this.txtApplicantName.MaxLength = 200;
            this.txtApplicantName.Name = "txtApplicantName";
            this.txtApplicantName.Size = new System.Drawing.Size(370, 20);
            this.txtApplicantName.TabIndex = 1;
            // 
            // lblApplicantName
            // 
            this.lblApplicantName.AutoSize = true;
            this.lblApplicantName.Location = new System.Drawing.Point(14, 31);
            this.lblApplicantName.Name = "lblApplicantName";
            this.lblApplicantName.Size = new System.Drawing.Size(82, 13);
            this.lblApplicantName.TabIndex = 2;
            this.lblApplicantName.Text = "Applicant Name";
            // 
            // txtApplicantAddress
            // 
            this.txtApplicantAddress.Location = new System.Drawing.Point(128, 49);
            this.txtApplicantAddress.MaxLength = 100;
            this.txtApplicantAddress.Name = "txtApplicantAddress";
            this.txtApplicantAddress.Size = new System.Drawing.Size(370, 20);
            this.txtApplicantAddress.TabIndex = 2;
            // 
            // lblApplicantAddress
            // 
            this.lblApplicantAddress.AutoSize = true;
            this.lblApplicantAddress.Location = new System.Drawing.Point(14, 52);
            this.lblApplicantAddress.Name = "lblApplicantAddress";
            this.lblApplicantAddress.Size = new System.Drawing.Size(92, 13);
            this.lblApplicantAddress.TabIndex = 4;
            this.lblApplicantAddress.Text = "Applicant Address";
            // 
            // txtApplicantNational
            // 
            this.txtApplicantNational.Location = new System.Drawing.Point(128, 70);
            this.txtApplicantNational.MaxLength = 100;
            this.txtApplicantNational.Name = "txtApplicantNational";
            this.txtApplicantNational.Size = new System.Drawing.Size(370, 20);
            this.txtApplicantNational.TabIndex = 3;
            // 
            // lblApplicantNationality
            // 
            this.lblApplicantNationality.AutoSize = true;
            this.lblApplicantNationality.Location = new System.Drawing.Point(14, 73);
            this.lblApplicantNationality.Name = "lblApplicantNationality";
            this.lblApplicantNationality.Size = new System.Drawing.Size(103, 13);
            this.lblApplicantNationality.TabIndex = 6;
            this.lblApplicantNationality.Text = "Applicant Nationality";
            // 
            // txtApplicantTel
            // 
            this.txtApplicantTel.Location = new System.Drawing.Point(128, 91);
            this.txtApplicantTel.MaxLength = 50;
            this.txtApplicantTel.Name = "txtApplicantTel";
            this.txtApplicantTel.Size = new System.Drawing.Size(370, 20);
            this.txtApplicantTel.TabIndex = 4;
            // 
            // lblApplicantTel
            // 
            this.lblApplicantTel.AutoSize = true;
            this.lblApplicantTel.Location = new System.Drawing.Point(14, 94);
            this.lblApplicantTel.Name = "lblApplicantTel";
            this.lblApplicantTel.Size = new System.Drawing.Size(69, 13);
            this.lblApplicantTel.TabIndex = 8;
            this.lblApplicantTel.Text = "Applicant Tel";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(342, 138);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtApplicantFax
            // 
            this.txtApplicantFax.Location = new System.Drawing.Point(128, 112);
            this.txtApplicantFax.MaxLength = 50;
            this.txtApplicantFax.Name = "txtApplicantFax";
            this.txtApplicantFax.Size = new System.Drawing.Size(370, 20);
            this.txtApplicantFax.TabIndex = 5;
            // 
            // lblApplicantFax
            // 
            this.lblApplicantFax.AutoSize = true;
            this.lblApplicantFax.Location = new System.Drawing.Point(14, 115);
            this.lblApplicantFax.Name = "lblApplicantFax";
            this.lblApplicantFax.Size = new System.Drawing.Size(71, 13);
            this.lblApplicantFax.TabIndex = 17;
            this.lblApplicantFax.Text = "Applicant Fax";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(423, 138);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtApplicantCode
            // 
            this.txtApplicantCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtApplicantCode.ForeColor = System.Drawing.Color.Black;
            this.txtApplicantCode.Location = new System.Drawing.Point(128, 7);
            this.txtApplicantCode.Name = "txtApplicantCode";
            this.txtApplicantCode.ReadOnly = true;
            this.txtApplicantCode.Size = new System.Drawing.Size(370, 20);
            this.txtApplicantCode.TabIndex = 18;
            this.txtApplicantCode.TabStop = false;
            // 
            // frmLGCreateApplicant
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(510, 173);
            this.Controls.Add(this.txtApplicantCode);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txtApplicantFax);
            this.Controls.Add(this.lblApplicantFax);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtApplicantTel);
            this.Controls.Add(this.lblApplicantTel);
            this.Controls.Add(this.txtApplicantNational);
            this.Controls.Add(this.lblApplicantNationality);
            this.Controls.Add(this.txtApplicantAddress);
            this.Controls.Add(this.lblApplicantAddress);
            this.Controls.Add(this.txtApplicantName);
            this.Controls.Add(this.lblApplicantName);
            this.Controls.Add(this.lblApplicantCode);
            this.Name = "frmLGCreateApplicant";
            this.Text = "Create Applicant";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGCreateApplicant_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.Label lblApplicantCode;
        private System.Windows.Forms.TextBox txtApplicantName;
        private System.Windows.Forms.Label lblApplicantName;
        private System.Windows.Forms.TextBox txtApplicantAddress;
        private System.Windows.Forms.Label lblApplicantAddress;
        private System.Windows.Forms.TextBox txtApplicantNational;
        private System.Windows.Forms.Label lblApplicantNationality;
        private System.Windows.Forms.TextBox txtApplicantTel;
        private System.Windows.Forms.Label lblApplicantTel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtApplicantFax;
        private System.Windows.Forms.Label lblApplicantFax;
		private System.Windows.Forms.Button btnClose;
		private UserCtrl.DisableTextBox txtApplicantCode;
    }
}