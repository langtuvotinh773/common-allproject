﻿namespace Phoenix.Lg.Gui.Forms
{
    partial class frmLGPrintForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLGNo = new System.Windows.Forms.Label();
            this.txtLGNo = new UserCtrl.DisableTextBox();
            this.cbbType = new System.Windows.Forms.ComboBox();
            this.lblType = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblLGNo
            // 
            this.lblLGNo.AutoSize = true;
            this.lblLGNo.Location = new System.Drawing.Point(9, 19);
            this.lblLGNo.Name = "lblLGNo";
            this.lblLGNo.Size = new System.Drawing.Size(38, 13);
            this.lblLGNo.TabIndex = 24;
            this.lblLGNo.Text = "LG No";
            // 
            // txtLGNo
            // 
            this.txtLGNo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLGNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtLGNo.ForeColor = System.Drawing.Color.Black;
            this.txtLGNo.Location = new System.Drawing.Point(74, 12);
            this.txtLGNo.Multiline = true;
            this.txtLGNo.Name = "txtLGNo";
            this.txtLGNo.ReadOnly = true;
            this.txtLGNo.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLGNo.Size = new System.Drawing.Size(231, 20);
            this.txtLGNo.TabIndex = 1;
            this.txtLGNo.TabStop = false;
            this.txtLGNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cbbType
            // 
            this.cbbType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cbbType.FormattingEnabled = true;
            this.cbbType.Location = new System.Drawing.Point(74, 34);
            this.cbbType.Name = "cbbType";
            this.cbbType.Size = new System.Drawing.Size(231, 21);
            this.cbbType.TabIndex = 2;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(9, 41);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(31, 13);
            this.lblType.TabIndex = 34;
            this.lblType.Text = "Type";
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnPrint.Location = new System.Drawing.Point(149, 68);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 3;
            this.btnPrint.Text = "&Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(230, 68);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmLGPrintForm
            // 
            this.AcceptButton = this.btnPrint;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(314, 103);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.cbbType);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.lblLGNo);
            this.Controls.Add(this.txtLGNo);
            this.MinimizeBox = false;
            this.Name = "frmLGPrintForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Print Form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmLGPrintForm_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLGNo;
        private UserCtrl.DisableTextBox txtLGNo;
        private System.Windows.Forms.ComboBox cbbType;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnCancel;
    }
}