﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-22 16:00:00 +0700 (Fri, 22 Mar 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to management applicant
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;
using UserCtrl;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGListApplicant : frmLGMaster
    {
        #region Varibales

        private clsLGApplicantDTO m_AppDto;
        private clsLGApplicantBus m_AppBus;

        //name of column datagirdview
        private string m_colCheck = "colCheck";
        private string m_colApplicantCode = "colApplicantCode";
        private string m_colApplicantName = "colApplicantName";
        private string m_colSeqApplicant = "colSeqApplicant";
        //count of row when click cell checkbox on grid
        private int m_ListSelectIndex = 0;
        //Count of row is selected enable
        private int m_RowSelectCount = 0;
        //used to check all on grid
     //   private bool m_IsCheckAll = false;
        #endregion

        #region Contructors
        public frmLGListApplicant()
        {
            try
            {
                InitializeComponent();
                base.SetFormStyleCommon();
                SetFormStyle();
                m_AppDto = new clsLGApplicantDTO();
                m_AppBus = new clsLGApplicantBus();
                //fill data from database when form load
                FillData();
				_security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }
        #endregion

        #region Event Functions

        /// <summary>
        /// Show form dialog to create applicant
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGCreateApplicant frm = new frmLGCreateApplicant();
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //fill data on grid
                    FillData();
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }

        }

        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Update Applicant
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbUpdateApplicant_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgApplicantList.Rows.Count > 0)
                {
                    DataGridViewRow dr = dtgApplicantList.SelectedRows[0];
                    //get SeqApplicant to update data
                    m_AppDto.SeqApplicant = (int)dr.Cells[m_colSeqApplicant].Value;
                    //show screen 'Update Applicant' with SeqApplicant
                    frmLGUpdateApplicant frm = new frmLGUpdateApplicant(m_AppDto.SeqApplicant);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    if (!frm.IsDisposed)
                    {
                        if (frm.ShowDialog() == DialogResult.OK)
                        {
                            //fill data on grid
                            FillData();
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }

        }

        /// <summary>
        /// Search Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                //fill data on grid
                FillData();
                if (dtgApplicantList.Rows.Count == 0)
                {
                    tsbUpdateApplicant.Visible = false;
                    clsLGMesageCollection.MessageNoTransactions();
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }

        }

        /// <summary>
        /// Delete an item on datagridview event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void tsbDeleteApplicant_Click(object sender, EventArgs e)
        {
            try
            {
                //show message confirm delete applicant is chosen on grid
                DialogResult dlgResult = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                    String.Format(clsLGCommonMessage.CONFIRM_DETELE, clsLGConstant.APPLICANT_NAME, GetListApplicantForDelete()));
                if (dlgResult == DialogResult.No || dlgResult == DialogResult.Cancel)
                {
                    this.Focus();
                    return;
                }
                else
                {
                    //delete applicant is chosen on grid
                    DeleteApplicant();
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_AppBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }

        }

        /// <summary>
        /// Selection changed event on applicant list datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void dtgApplicantList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dtgApplicantList.Rows.Count > 0)
                {
                    tsbUpdateApplicant.Visible = true;
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Event Cell Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgApplicantList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex == 0)
                {
                    DataGridViewDisableCheckBoxCell cell = dtgApplicantList[0, e.RowIndex] as DataGridViewDisableCheckBoxCell;
                    if (cell.Enabled)
                    {
                        if (bool.Parse(dtgApplicantList[0, e.RowIndex].Value.ToString()))
                        {
                            m_ListSelectIndex--;
                        }
                        else
                        {
                            m_ListSelectIndex++;
                        }

                        dtgApplicantList[0, e.RowIndex].Value = (!bool.Parse(dtgApplicantList[0, e.RowIndex].Value.ToString())).ToString();

                        //if (m_ListSelectIndex == m_RowSelectCount)
                        //{
                        //    m_IsCheckAll = true;
                        //}
                        //else
                        //{
                        //    m_IsCheckAll = false;
                        //}

                        //set visible 'Delete Applicant' toolStrip
                        SetVisibleDeleteApplicant();
                    }
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Form Closing Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void frmLGListApplicant_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (m_ListSelectIndex > 0)
                {
                    DialogResult dlgResult = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                        String.Format(clsLGCommonMessage.CONFIRM_DETELE, clsLGConstant.APPLICANT_NAME, GetListApplicantForDelete()));
                    if (dlgResult == DialogResult.Yes)
                    {
                        //delete Applicant
                        DeleteApplicant();
                        e.Cancel = false;
                    }
                    if (dlgResult == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                    }
                    if (dlgResult == DialogResult.No)
                    {
                        e.Cancel = false;
                    }
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        #endregion

        #region Private Functions
        /// <summary>
        /// Set form style
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        private void SetFormStyle()
        {
            #region MAX LENGTH
            txtApplicantAddress.MaxLength = clsLGConstant.LENGTH_APPLICANT_ADDRESS;
            txtApplicantCode.MaxLength = clsLGConstant.LENGTH_APPLICANT_CODE;
            txtApplicantName.MaxLength = clsLGConstant.LENGTH_APPLICANT_NAME;
            txtApplicantNational.MaxLength = clsLGConstant.LENGTH_APPLICANT_NATIONAL;
            txtApplicantTel.MaxLength = clsLGConstant.LENGTH_APPLICANT_TEL;
            #endregion

            tsbUpdateApplicant.Visible = false;
            tsbDeleteApplicant.Visible = false;

        }

        /// <summary>
        /// Get Data on form for search
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataForSearch()
        {
            //get data on form for action Search
            m_AppDto.ApplicantCode = txtApplicantCode.Text.Trim();
            m_AppDto.ApplicantName = txtApplicantName.Text.Trim();
            m_AppDto.ApplicantAddress = txtApplicantAddress.Text.Trim();
            m_AppDto.ApplicantNational = txtApplicantNational.Text.Trim();
            m_AppDto.ApplicantTel = txtApplicantTel.Text.Trim();
        }


        /// <summary>
        /// Fila data to list Applicant
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillData()
        {
            //clear data on grid
            dtgApplicantList.Rows.Clear();
            //clear list index to check on grid
            m_ListSelectIndex = 0;
            //reset count of row is selected enable
            m_RowSelectCount = 0;
            //Reset checkall data of list Applicant
           // m_IsCheckAll = false;
            tsbDeleteApplicant.Visible = false;
            //get data for search
            GetDataForSearch();
            //get list Applicant by search conditions
            List<clsLGApplicantDTO> lst = m_AppBus.GetListApplicant(m_AppDto);
            if (lst.Count == 0)
            {
                return;
            }
            else
            {
                for (int i = 0; i < lst.Count; i++)
                {
                    //add row for datagirdview
                    dtgApplicantList.Rows.Add(false, lst[i].ApplicantCode, lst[i].ApplicantName, lst[i].ApplicantAddress, lst[i].ApplicantNational,
                        lst[i].ApplicantTel, lst[i].ApplicantFax, lst[i].NoChange, lst[i].SeqApplicant);
                    //get cell disable checkbox
                    DataGridViewDisableCheckBoxCell cell = dtgApplicantList.Rows[i].Cells[m_colCheck] as DataGridViewDisableCheckBoxCell;
                    // NoChange = 0, allow update,delete it
                    // NoChange != 0, don't allow update,delete it
                    if (lst[i].NoChange == 0)
                    {
                        cell.Enabled = true;
                        m_RowSelectCount++;
                    }
                    else
                    {
                        cell.Enabled = false;
                    }
                }
            }
        }

        /// <summary>
        /// Delete List Applicant is checked on grid
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void DeleteApplicant()
        {
            List<clsLGApplicantDTO> lst = new List<clsLGApplicantDTO>();
            for (int i = 0; i < dtgApplicantList.Rows.Count; i++)
            {
                if (Boolean.Parse(dtgApplicantList.Rows[i].Cells[m_colCheck].Value.ToString()) == true)
                {
                    //get list applicant to delete
                    clsLGApplicantDTO temp = new clsLGApplicantDTO();
                    temp.SeqApplicant = (int)dtgApplicantList.Rows[i].Cells[m_colSeqApplicant].Value;
                    temp.ApplicantCode = dtgApplicantList.Rows[i].Cells[m_colApplicantCode].Value.ToString();
                    temp.ApplicantName = dtgApplicantList.Rows[i].Cells[m_colApplicantName].Value.ToString();
                    lst.Add(temp);
                }
            }

            if (lst.Count > 0)
            {
                //Delete applicant
                if (m_AppBus.DeleteApplicant(lst) > 0)
                {
                    //write log for Delete Applicant
                    WriteLog(lst);
                    //commit data
                    m_AppBus.Commit();
                    //show message after save data is success
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                        String.Format(clsLGCommonMessage.INFOR_ACTION_SUCCESS, clsLGConstant.ACTION_DELETE, clsLGConstant.APPLICANT_NAME));
                    FillData();
                }
                else
                {
                    //rollback data when error happen
                    m_AppBus.RollBack();
                    //show message after save data is failed
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        String.Format(clsLGCommonMessage.ERROR_CAN_NOT_DELETE, clsLGConstant.APPLICANT_NAME, GetListApplicantForDelete()));
                }
            }
        }

        /// <summary>
        /// Write Delete information to Log History
        /// </summary>
        /// <param name="lst"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLog(List<clsLGApplicantDTO> lst)
        {
            clsLGLogBase logBase = new clsLGLogBase();
            // //header history
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            //+ Deleting Log 
            logBase.Action = (int)CommonValue.ActionType.Delete;

            if (lst.Count > 0)
            {
                logBase.Key = String.Join(",", lst.Select(a => a.ApplicantCode).ToArray());
                m_AppBus.WriteLog(logBase);
            }
        }

        /// <summary>
        /// Set Visible Delete Applicant 
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void SetVisibleDeleteApplicant()
        {
            //Check: cell checkbox is checked = true to visible 'Delete Applicant' toolstrip
            //else hidden it
            if (m_ListSelectIndex > 0)
            {
                tsbDeleteApplicant.Visible = true;
            }
            else
            {
                tsbDeleteApplicant.Visible = false;
            }
        }

        /// <summary>
        /// Get List Beneficiary to delete
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public string GetListApplicantForDelete()
        {
            string arr = "[";
            int indexArr = 0;
            for (int i = 0; i < dtgApplicantList.Rows.Count; i++)
            {
                if (Boolean.Parse(dtgApplicantList.Rows[i].Cells[m_colCheck].Value.ToString()) == true)
                {
                    if (indexArr == 0)
                    {
                        arr += dtgApplicantList.Rows[i].Cells[m_colApplicantCode].Value.ToString();
                    }
                    else
                    {
                        arr += "," + dtgApplicantList.Rows[i].Cells[m_colApplicantCode].Value.ToString();
                    }
                    indexArr++;
                }
            }
            arr += "]";
            return arr;
        }
        #endregion


        #region Protected Functions

        /// <summary>
        /// Override ProceeCmdKey
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Alt | Keys.U))
            {
                if (tsbUpdateApplicant.Visible == true)
                {
                    tsbUpdateApplicant_Click(new object(), new EventArgs());
                }
            }
            else if (keyData == (Keys.Alt | Keys.D))
            {
                if (tsbDeleteApplicant.Visible == true)
                {
                    tsbDeleteApplicant_Click(new object(), new EventArgs());
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        /// <summary>
        /// Processes a dialog box key.
        /// </summary>
        /// <param name="keyData"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (keyData == (Keys.Alt | Keys.U))
            {
                return true;
            }
            else if (keyData == (Keys.Alt | Keys.D))
            {
                return true;
            }
            else
            {
                return base.ProcessDialogKey(keyData);
            }
        }
        #endregion


    }
}