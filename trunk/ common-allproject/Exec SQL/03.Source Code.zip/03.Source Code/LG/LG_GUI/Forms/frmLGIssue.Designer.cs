﻿using UserCtrl;
namespace Phoenix.Lg.Gui.Forms
{
	partial class frmLGIssue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLGIssue));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnAddApplicant = new System.Windows.Forms.Button();
            this.cbbApplicant = new System.Windows.Forms.ComboBox();
            this.lblApplicantName = new System.Windows.Forms.Label();
            this.txtRemark = new System.Windows.Forms.RichTextBox();
            this.lblRemark = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtOrther = new UserCtrl.NumberOnlyTextBoxIsEmpty();
            this.radOthers = new System.Windows.Forms.RadioButton();
            this.radStandard = new System.Windows.Forms.RadioButton();
            this.cbbCurrency = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lblCurrency = new System.Windows.Forms.Label();
            this.txtRepresentation3 = new System.Windows.Forms.TextBox();
            this.txtRepresentation2 = new System.Windows.Forms.TextBox();
            this.lblRepresentation3 = new System.Windows.Forms.Label();
            this.lblRepresentation2 = new System.Windows.Forms.Label();
            this.txtRepresentation1 = new System.Windows.Forms.TextBox();
            this.lblRepresentation1 = new System.Windows.Forms.Label();
            this.txtContractInformation = new System.Windows.Forms.RichTextBox();
            this.lblContractInformation = new System.Windows.Forms.Label();
            this.grbSecurity = new System.Windows.Forms.GroupBox();
            this.radCleanBasis = new System.Windows.Forms.RadioButton();
            this.radFledgeDeposit = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblPercent = new System.Windows.Forms.Label();
            this.lblLGRate = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.grbDetailInformation = new System.Windows.Forms.GroupBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.dtgLGList = new UserCtrl.TabOrderDatagridView();
            this.colSub = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCurrency = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colAmount = new UserCtrl.TNumEditDataGridViewColumn();
            this.colTransientAccount = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colChargeAccount = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colFeeSuggestion = new UserCtrl.TNumEditDataGridViewColumn();
            this.colFee = new UserCtrl.TNumEditDataGridViewColumn();
            this.colFeeCurrency = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colDateOfActualCollection = new UserCtrl.ctrlLGCalendarColumn();
            this.grbGeneralInformation = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbLGAllowed = new System.Windows.Forms.CheckBox();
            this.btnAddBeneficiary = new System.Windows.Forms.Button();
            this.txtGLCode = new UserCtrl.DisableTextBox();
            this.txtLGRate = new UserCtrl.NumberOnlyTextBox();
            this.lblCalculateType = new System.Windows.Forms.Label();
            this.cbbCalculateType = new System.Windows.Forms.ComboBox();
            this.cbbBeneficiary = new System.Windows.Forms.ComboBox();
            this.lblBeneficiary = new System.Windows.Forms.Label();
            this.cbbCustomerName = new System.Windows.Forms.ComboBox();
            this.cbbCustomerCode = new UserCtrl.AutoCompleteCombobox();
            this.txtTranNo = new UserCtrl.DisableTextBox();
            this.lblTranNo = new System.Windows.Forms.Label();
            this.lblCustomerCode = new System.Windows.Forms.Label();
            this.lblGuaranteeType = new System.Windows.Forms.Label();
            this.txtLGNo = new UserCtrl.DisableTextBox();
            this.lblLGNo = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblSecurity = new System.Windows.Forms.Label();
            this.lblBookingPurpose = new System.Windows.Forms.Label();
            this.ckbBookingPurpose = new System.Windows.Forms.CheckBox();
            this.lblExpireDate = new System.Windows.Forms.Label();
            this.lblGLCode = new System.Windows.Forms.Label();
            this.dtpExpireDate = new System.Windows.Forms.DateTimePicker();
            this.lblValueDate = new System.Windows.Forms.Label();
            this.dtpInputDate = new System.Windows.Forms.DateTimePicker();
            this.dtpValueDate = new System.Windows.Forms.DateTimePicker();
            this.lblInputDate = new System.Windows.Forms.Label();
            this.cbbGuaranteeType = new System.Windows.Forms.ComboBox();
            this.lblLGCategory = new System.Windows.Forms.Label();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSaveAndContinue = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.cbbLGCategory = new System.Windows.Forms.ComboBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tNumEditDataGridViewColumn1 = new UserCtrl.TNumEditDataGridViewColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tNumEditDataGridViewColumn2 = new UserCtrl.TNumEditDataGridViewColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.grbSecurity.SuspendLayout();
            this.grbDetailInformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgLGList)).BeginInit();
            this.grbGeneralInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAddApplicant
            // 
            this.btnAddApplicant.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnAddApplicant.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddApplicant.BackgroundImage")));
            this.btnAddApplicant.Location = new System.Drawing.Point(769, 78);
            this.btnAddApplicant.Name = "btnAddApplicant";
            this.btnAddApplicant.Size = new System.Drawing.Size(20, 20);
            this.btnAddApplicant.TabIndex = 5;
            this.btnAddApplicant.UseVisualStyleBackColor = false;
            this.btnAddApplicant.Click += new System.EventHandler(this.btnApplicantAdd_Click);
            // 
            // cbbApplicant
            // 
            this.cbbApplicant.FormattingEnabled = true;
            this.cbbApplicant.Location = new System.Drawing.Point(515, 78);
            this.cbbApplicant.Name = "cbbApplicant";
            this.cbbApplicant.Size = new System.Drawing.Size(249, 21);
            this.cbbApplicant.TabIndex = 4;
            this.cbbApplicant.SelectedIndexChanged += new System.EventHandler(this.cbbApplicant_SelectedIndexChanged);
            // 
            // lblApplicantName
            // 
            this.lblApplicantName.AutoSize = true;
            this.lblApplicantName.Location = new System.Drawing.Point(424, 82);
            this.lblApplicantName.Name = "lblApplicantName";
            this.lblApplicantName.Size = new System.Drawing.Size(82, 13);
            this.lblApplicantName.TabIndex = 91;
            this.lblApplicantName.Text = "Applicant Name";
            // 
            // txtRemark
            // 
            this.txtRemark.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtRemark.Location = new System.Drawing.Point(389, 270);
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(396, 65);
            this.txtRemark.TabIndex = 16;
            this.txtRemark.Text = "";
            this.txtRemark.TextChanged += new System.EventHandler(this.txtRemark_TextChanged);
            // 
            // lblRemark
            // 
            this.lblRemark.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblRemark.AutoSize = true;
            this.lblRemark.Location = new System.Drawing.Point(339, 270);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(44, 13);
            this.lblRemark.TabIndex = 85;
            this.lblRemark.Text = "Remark";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtOrther);
            this.groupBox1.Controls.Add(this.radOthers);
            this.groupBox1.Controls.Add(this.radStandard);
            this.groupBox1.Controls.Add(this.cbbCurrency);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.lblCurrency);
            this.groupBox1.Location = new System.Drawing.Point(7, 270);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(291, 65);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Minimum Rate Amount";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Standard";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "$25";
            // 
            // txtOrther
            // 
            this.txtOrther.CustomDecimal = 5;
            this.txtOrther.CustomLenght = 13;
            this.txtOrther.Location = new System.Drawing.Point(175, 15);
            this.txtOrther.Name = "txtOrther";
            this.txtOrther.NeedDecimal = true;
            this.txtOrther.Size = new System.Drawing.Size(108, 20);
            this.txtOrther.StringFormat = "#,0.####";
            this.txtOrther.TabIndex = 2;
            // 
            // radOthers
            // 
            this.radOthers.AutoSize = true;
            this.radOthers.Location = new System.Drawing.Point(104, 20);
            this.radOthers.Name = "radOthers";
            this.radOthers.Size = new System.Drawing.Size(14, 13);
            this.radOthers.TabIndex = 1;
            this.radOthers.TabStop = true;
            this.radOthers.UseVisualStyleBackColor = true;
            this.radOthers.CheckedChanged += new System.EventHandler(this.radOthers_CheckedChanged);
            // 
            // radStandard
            // 
            this.radStandard.AutoSize = true;
            this.radStandard.Checked = true;
            this.radStandard.Location = new System.Drawing.Point(10, 20);
            this.radStandard.Name = "radStandard";
            this.radStandard.Size = new System.Drawing.Size(14, 13);
            this.radStandard.TabIndex = 0;
            this.radStandard.TabStop = true;
            this.radStandard.UseVisualStyleBackColor = true;
            this.radStandard.CheckedChanged += new System.EventHandler(this.radStandard_CheckedChanged);
            // 
            // cbbCurrency
            // 
            this.cbbCurrency.FormattingEnabled = true;
            this.cbbCurrency.Location = new System.Drawing.Point(175, 37);
            this.cbbCurrency.Name = "cbbCurrency";
            this.cbbCurrency.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cbbCurrency.Size = new System.Drawing.Size(108, 21);
            this.cbbCurrency.TabIndex = 3;
            this.cbbCurrency.SelectedIndexChanged += new System.EventHandler(this.cbbCurrency_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(124, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Others";
            // 
            // lblCurrency
            // 
            this.lblCurrency.AutoSize = true;
            this.lblCurrency.Location = new System.Drawing.Point(120, 41);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(28, 13);
            this.lblCurrency.TabIndex = 7;
            this.lblCurrency.Text = "CCY";
            // 
            // txtRepresentation3
            // 
            this.txtRepresentation3.Location = new System.Drawing.Point(121, 243);
            this.txtRepresentation3.Name = "txtRepresentation3";
            this.txtRepresentation3.Size = new System.Drawing.Size(670, 20);
            this.txtRepresentation3.TabIndex = 14;
            this.txtRepresentation3.TextChanged += new System.EventHandler(this.txtRepresentation3_TextChanged);
            // 
            // txtRepresentation2
            // 
            this.txtRepresentation2.Location = new System.Drawing.Point(121, 222);
            this.txtRepresentation2.Name = "txtRepresentation2";
            this.txtRepresentation2.Size = new System.Drawing.Size(670, 20);
            this.txtRepresentation2.TabIndex = 13;
            this.txtRepresentation2.TextChanged += new System.EventHandler(this.txtRepresentation2_TextChanged);
            // 
            // lblRepresentation3
            // 
            this.lblRepresentation3.AutoSize = true;
            this.lblRepresentation3.Location = new System.Drawing.Point(6, 246);
            this.lblRepresentation3.Name = "lblRepresentation3";
            this.lblRepresentation3.Size = new System.Drawing.Size(88, 13);
            this.lblRepresentation3.TabIndex = 77;
            this.lblRepresentation3.Text = "Representation 3";
            // 
            // lblRepresentation2
            // 
            this.lblRepresentation2.AutoSize = true;
            this.lblRepresentation2.Location = new System.Drawing.Point(6, 225);
            this.lblRepresentation2.Name = "lblRepresentation2";
            this.lblRepresentation2.Size = new System.Drawing.Size(88, 13);
            this.lblRepresentation2.TabIndex = 76;
            this.lblRepresentation2.Text = "Representation 2";
            // 
            // txtRepresentation1
            // 
            this.txtRepresentation1.Location = new System.Drawing.Point(121, 201);
            this.txtRepresentation1.Name = "txtRepresentation1";
            this.txtRepresentation1.Size = new System.Drawing.Size(670, 20);
            this.txtRepresentation1.TabIndex = 12;
            this.txtRepresentation1.TextChanged += new System.EventHandler(this.txtRepresentation1_TextChanged);
            // 
            // lblRepresentation1
            // 
            this.lblRepresentation1.AutoSize = true;
            this.lblRepresentation1.Location = new System.Drawing.Point(6, 204);
            this.lblRepresentation1.Name = "lblRepresentation1";
            this.lblRepresentation1.Size = new System.Drawing.Size(88, 13);
            this.lblRepresentation1.TabIndex = 75;
            this.lblRepresentation1.Text = "Representation 1";
            // 
            // txtContractInformation
            // 
            this.txtContractInformation.Location = new System.Drawing.Point(121, 158);
            this.txtContractInformation.Name = "txtContractInformation";
            this.txtContractInformation.Size = new System.Drawing.Size(670, 40);
            this.txtContractInformation.TabIndex = 11;
            this.txtContractInformation.Text = "";
            this.txtContractInformation.TextChanged += new System.EventHandler(this.txtContractInformation_TextChanged);
            // 
            // lblContractInformation
            // 
            this.lblContractInformation.AutoSize = true;
            this.lblContractInformation.Location = new System.Drawing.Point(6, 158);
            this.lblContractInformation.Name = "lblContractInformation";
            this.lblContractInformation.Size = new System.Drawing.Size(101, 13);
            this.lblContractInformation.TabIndex = 72;
            this.lblContractInformation.Text = "Contract information";
            // 
            // grbSecurity
            // 
            this.grbSecurity.Controls.Add(this.radCleanBasis);
            this.grbSecurity.Controls.Add(this.radFledgeDeposit);
            this.grbSecurity.Controls.Add(this.label10);
            this.grbSecurity.Controls.Add(this.label9);
            this.grbSecurity.Location = new System.Drawing.Point(121, 121);
            this.grbSecurity.Name = "grbSecurity";
            this.grbSecurity.Size = new System.Drawing.Size(242, 34);
            this.grbSecurity.TabIndex = 9;
            this.grbSecurity.TabStop = false;
            // 
            // radCleanBasis
            // 
            this.radCleanBasis.AutoSize = true;
            this.radCleanBasis.Location = new System.Drawing.Point(151, 15);
            this.radCleanBasis.Name = "radCleanBasis";
            this.radCleanBasis.Size = new System.Drawing.Size(14, 13);
            this.radCleanBasis.TabIndex = 1;
            this.radCleanBasis.TabStop = true;
            this.radCleanBasis.UseVisualStyleBackColor = true;
            // 
            // radFledgeDeposit
            // 
            this.radFledgeDeposit.AutoSize = true;
            this.radFledgeDeposit.Checked = true;
            this.radFledgeDeposit.Location = new System.Drawing.Point(7, 14);
            this.radFledgeDeposit.Name = "radFledgeDeposit";
            this.radFledgeDeposit.Size = new System.Drawing.Size(14, 13);
            this.radFledgeDeposit.TabIndex = 0;
            this.radFledgeDeposit.TabStop = true;
            this.radFledgeDeposit.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(171, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "Clean Basis";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 13);
            this.label9.TabIndex = 30;
            this.label9.Text = "Pledge deposit ";
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Location = new System.Drawing.Point(774, 104);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(15, 13);
            this.lblPercent.TabIndex = 70;
            this.lblPercent.Text = "%";
            // 
            // lblLGRate
            // 
            this.lblLGRate.AutoSize = true;
            this.lblLGRate.Location = new System.Drawing.Point(605, 104);
            this.lblLGRate.Name = "lblLGRate";
            this.lblLGRate.Size = new System.Drawing.Size(47, 13);
            this.lblLGRate.TabIndex = 69;
            this.lblLGRate.Text = "LG Rate";
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnAdd.Location = new System.Drawing.Point(6, 16);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "&Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // grbDetailInformation
            // 
            this.grbDetailInformation.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.grbDetailInformation.Controls.Add(this.btnRemove);
            this.grbDetailInformation.Controls.Add(this.btnAdd);
            this.grbDetailInformation.Controls.Add(this.dtgLGList);
            this.grbDetailInformation.Location = new System.Drawing.Point(7, 376);
            this.grbDetailInformation.Margin = new System.Windows.Forms.Padding(0);
            this.grbDetailInformation.Name = "grbDetailInformation";
            this.grbDetailInformation.Padding = new System.Windows.Forms.Padding(0);
            this.grbDetailInformation.Size = new System.Drawing.Size(827, 179);
            this.grbDetailInformation.TabIndex = 2;
            this.grbDetailInformation.TabStop = false;
            this.grbDetailInformation.Text = "Details information";
            // 
            // btnRemove
            // 
            this.btnRemove.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnRemove.Location = new System.Drawing.Point(87, 16);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 1;
            this.btnRemove.Text = "&Remove";
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // dtgLGList
            // 
            this.dtgLGList.AllowUserToAddRows = false;
            this.dtgLGList.AllowUserToDeleteRows = false;
            this.dtgLGList.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgLGList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgLGList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgLGList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSub,
            this.colCurrency,
            this.colAmount,
            this.colTransientAccount,
            this.colChargeAccount,
            this.colFeeSuggestion,
            this.colFee,
            this.colFeeCurrency,
            this.colDateOfActualCollection});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgLGList.DefaultCellStyle = dataGridViewCellStyle8;
            this.dtgLGList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dtgLGList.EnableHeadersVisualStyles = false;
            this.dtgLGList.Location = new System.Drawing.Point(5, 45);
            this.dtgLGList.MultiSelect = false;
            this.dtgLGList.Name = "dtgLGList";
            this.dtgLGList.RowHeadersVisible = false;
            this.dtgLGList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dtgLGList.Size = new System.Drawing.Size(819, 131);
            this.dtgLGList.TabIndex = 2;
            this.dtgLGList.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgLGList_CellValueChanged);
            this.dtgLGList.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dtgLGList_CellFormatting);
            this.dtgLGList.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dtgLGList_RowsAdded);
            this.dtgLGList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgLGList_CellEndEdit);
            this.dtgLGList.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgLGList_CellEnter);
            this.dtgLGList.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dtgLGList_RowsRemoved);
            this.dtgLGList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgLGList_CellContentClick);
            // 
            // colSub
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colSub.DefaultCellStyle = dataGridViewCellStyle2;
            this.colSub.FillWeight = 101.1236F;
            this.colSub.HeaderText = "Sub";
            this.colSub.Name = "colSub";
            this.colSub.ReadOnly = true;
            this.colSub.Width = 40;
            // 
            // colCurrency
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCurrency.DefaultCellStyle = dataGridViewCellStyle3;
            this.colCurrency.HeaderText = "CCY";
            this.colCurrency.Name = "colCurrency";
            this.colCurrency.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colCurrency.Width = 55;
            // 
            // colAmount
            // 
            this.colAmount.DecimalLength = 2;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N2";
            dataGridViewCellStyle4.NullValue = null;
            this.colAmount.DefaultCellStyle = dataGridViewCellStyle4;
            this.colAmount.HeaderText = "Amount";
            this.colAmount.MaxInputLength = 13;
            this.colAmount.Name = "colAmount";
            this.colAmount.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colTransientAccount
            // 
            this.colTransientAccount.HeaderText = "Transient Account";
            this.colTransientAccount.Name = "colTransientAccount";
            // 
            // colChargeAccount
            // 
            this.colChargeAccount.HeaderText = "Charge Account";
            this.colChargeAccount.Name = "colChargeAccount";
            this.colChargeAccount.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colFeeSuggestion
            // 
            this.colFeeSuggestion.DecimalLength = 5;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N5";
            dataGridViewCellStyle5.NullValue = null;
            this.colFeeSuggestion.DefaultCellStyle = dataGridViewCellStyle5;
            this.colFeeSuggestion.HeaderText = "Fee suggestion";
            this.colFeeSuggestion.Name = "colFeeSuggestion";
            this.colFeeSuggestion.ReadOnly = true;
            this.colFeeSuggestion.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colFeeSuggestion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colFeeSuggestion.Width = 95;
            // 
            // colFee
            // 
            this.colFee.DecimalLength = 2;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N2";
            this.colFee.DefaultCellStyle = dataGridViewCellStyle6;
            this.colFee.HeaderText = "Issuing Fee";
            this.colFee.MaxInputLength = 13;
            this.colFee.Name = "colFee";
            this.colFee.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colFee.Width = 80;
            // 
            // colFeeCurrency
            // 
            this.colFeeCurrency.HeaderText = "Issuing Fee CCY";
            this.colFeeCurrency.Name = "colFeeCurrency";
            this.colFeeCurrency.Width = 95;
            // 
            // colDateOfActualCollection
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "yyyy/MM/dd";
            this.colDateOfActualCollection.DefaultCellStyle = dataGridViewCellStyle7;
            this.colDateOfActualCollection.HeaderText = "Date Of Actual Collection";
            this.colDateOfActualCollection.Name = "colDateOfActualCollection";
            this.colDateOfActualCollection.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colDateOfActualCollection.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colDateOfActualCollection.Width = 150;
            // 
            // grbGeneralInformation
            // 
            this.grbGeneralInformation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbGeneralInformation.Controls.Add(this.label1);
            this.grbGeneralInformation.Controls.Add(this.cbLGAllowed);
            this.grbGeneralInformation.Controls.Add(this.btnAddBeneficiary);
            this.grbGeneralInformation.Controls.Add(this.btnAddApplicant);
            this.grbGeneralInformation.Controls.Add(this.cbbApplicant);
            this.grbGeneralInformation.Controls.Add(this.lblApplicantName);
            this.grbGeneralInformation.Controls.Add(this.txtGLCode);
            this.grbGeneralInformation.Controls.Add(this.txtRemark);
            this.grbGeneralInformation.Controls.Add(this.lblRemark);
            this.grbGeneralInformation.Controls.Add(this.groupBox1);
            this.grbGeneralInformation.Controls.Add(this.txtRepresentation3);
            this.grbGeneralInformation.Controls.Add(this.txtRepresentation2);
            this.grbGeneralInformation.Controls.Add(this.lblRepresentation3);
            this.grbGeneralInformation.Controls.Add(this.lblRepresentation2);
            this.grbGeneralInformation.Controls.Add(this.txtRepresentation1);
            this.grbGeneralInformation.Controls.Add(this.lblRepresentation1);
            this.grbGeneralInformation.Controls.Add(this.txtContractInformation);
            this.grbGeneralInformation.Controls.Add(this.lblContractInformation);
            this.grbGeneralInformation.Controls.Add(this.grbSecurity);
            this.grbGeneralInformation.Controls.Add(this.lblPercent);
            this.grbGeneralInformation.Controls.Add(this.txtLGRate);
            this.grbGeneralInformation.Controls.Add(this.lblLGRate);
            this.grbGeneralInformation.Controls.Add(this.lblCalculateType);
            this.grbGeneralInformation.Controls.Add(this.cbbCalculateType);
            this.grbGeneralInformation.Controls.Add(this.cbbBeneficiary);
            this.grbGeneralInformation.Controls.Add(this.lblBeneficiary);
            this.grbGeneralInformation.Controls.Add(this.cbbCustomerName);
            this.grbGeneralInformation.Controls.Add(this.cbbCustomerCode);
            this.grbGeneralInformation.Controls.Add(this.txtTranNo);
            this.grbGeneralInformation.Controls.Add(this.lblTranNo);
            this.grbGeneralInformation.Controls.Add(this.lblCustomerCode);
            this.grbGeneralInformation.Controls.Add(this.lblGuaranteeType);
            this.grbGeneralInformation.Controls.Add(this.txtLGNo);
            this.grbGeneralInformation.Controls.Add(this.lblLGNo);
            this.grbGeneralInformation.Controls.Add(this.lblCustomerName);
            this.grbGeneralInformation.Controls.Add(this.lblSecurity);
            this.grbGeneralInformation.Controls.Add(this.lblBookingPurpose);
            this.grbGeneralInformation.Controls.Add(this.ckbBookingPurpose);
            this.grbGeneralInformation.Controls.Add(this.lblExpireDate);
            this.grbGeneralInformation.Controls.Add(this.lblGLCode);
            this.grbGeneralInformation.Controls.Add(this.dtpExpireDate);
            this.grbGeneralInformation.Controls.Add(this.lblValueDate);
            this.grbGeneralInformation.Controls.Add(this.dtpInputDate);
            this.grbGeneralInformation.Controls.Add(this.dtpValueDate);
            this.grbGeneralInformation.Controls.Add(this.lblInputDate);
            this.grbGeneralInformation.Controls.Add(this.cbbGuaranteeType);
            this.grbGeneralInformation.Location = new System.Drawing.Point(7, 30);
            this.grbGeneralInformation.Name = "grbGeneralInformation";
            this.grbGeneralInformation.Size = new System.Drawing.Size(797, 339);
            this.grbGeneralInformation.TabIndex = 1;
            this.grbGeneralInformation.TabStop = false;
            this.grbGeneralInformation.Text = "General information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(485, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 93;
            this.label1.Text = "Allow Auto Claim";
            this.label1.Visible = false;
            // 
            // cbLGAllowed
            // 
            this.cbLGAllowed.AutoSize = true;
            this.cbLGAllowed.Location = new System.Drawing.Point(573, 133);
            this.cbLGAllowed.Name = "cbLGAllowed";
            this.cbLGAllowed.Size = new System.Drawing.Size(15, 14);
            this.cbLGAllowed.TabIndex = 92;
            this.cbLGAllowed.UseVisualStyleBackColor = true;
            this.cbLGAllowed.Visible = false;
            // 
            // btnAddBeneficiary
            // 
            this.btnAddBeneficiary.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnAddBeneficiary.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddBeneficiary.BackgroundImage")));
            this.btnAddBeneficiary.Location = new System.Drawing.Point(367, 79);
            this.btnAddBeneficiary.Name = "btnAddBeneficiary";
            this.btnAddBeneficiary.Size = new System.Drawing.Size(20, 20);
            this.btnAddBeneficiary.TabIndex = 5;
            this.btnAddBeneficiary.UseVisualStyleBackColor = false;
            this.btnAddBeneficiary.Click += new System.EventHandler(this.btnAddBeneficiary_Click);
            // 
            // txtGLCode
            // 
            this.txtGLCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtGLCode.ForeColor = System.Drawing.Color.Black;
            this.txtGLCode.Location = new System.Drawing.Point(121, 12);
            this.txtGLCode.Name = "txtGLCode";
            this.txtGLCode.ReadOnly = true;
            this.txtGLCode.Size = new System.Drawing.Size(114, 20);
            this.txtGLCode.TabIndex = 2;
            this.txtGLCode.TabStop = false;
            // 
            // txtLGRate
            // 
            this.txtLGRate.CustomDecimal = 5;
            this.txtLGRate.CustomLenght = 7;
            this.txtLGRate.Location = new System.Drawing.Point(658, 100);
            this.txtLGRate.Name = "txtLGRate";
            this.txtLGRate.NeedDecimal = true;
            this.txtLGRate.Size = new System.Drawing.Size(114, 20);
            this.txtLGRate.StringFormat = "#,0.00000";
            this.txtLGRate.TabIndex = 8;
            this.txtLGRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLGRate.TextChanged += new System.EventHandler(this.txtLGRate_TextChanged_1);
            // 
            // lblCalculateType
            // 
            this.lblCalculateType.AutoSize = true;
            this.lblCalculateType.Location = new System.Drawing.Point(305, 104);
            this.lblCalculateType.Name = "lblCalculateType";
            this.lblCalculateType.Size = new System.Drawing.Size(78, 13);
            this.lblCalculateType.TabIndex = 66;
            this.lblCalculateType.Text = "Calculate Type";
            // 
            // cbbCalculateType
            // 
            this.cbbCalculateType.FormattingEnabled = true;
            this.cbbCalculateType.Location = new System.Drawing.Point(392, 100);
            this.cbbCalculateType.Name = "cbbCalculateType";
            this.cbbCalculateType.Size = new System.Drawing.Size(195, 21);
            this.cbbCalculateType.TabIndex = 7;
            this.cbbCalculateType.SelectedIndexChanged += new System.EventHandler(this.cbbCalculateType_SelectedIndexChanged);
            // 
            // cbbBeneficiary
            // 
            this.cbbBeneficiary.FormattingEnabled = true;
            this.cbbBeneficiary.Location = new System.Drawing.Point(121, 78);
            this.cbbBeneficiary.Name = "cbbBeneficiary";
            this.cbbBeneficiary.Size = new System.Drawing.Size(244, 21);
            this.cbbBeneficiary.TabIndex = 3;
            this.cbbBeneficiary.SelectedIndexChanged += new System.EventHandler(this.cbbBeneficiary_SelectedIndexChanged);
            // 
            // lblBeneficiary
            // 
            this.lblBeneficiary.AutoSize = true;
            this.lblBeneficiary.Location = new System.Drawing.Point(6, 81);
            this.lblBeneficiary.Name = "lblBeneficiary";
            this.lblBeneficiary.Size = new System.Drawing.Size(90, 13);
            this.lblBeneficiary.TabIndex = 59;
            this.lblBeneficiary.Text = "Beneficiary Name";
            // 
            // cbbCustomerName
            // 
            this.cbbCustomerName.Enabled = false;
            this.cbbCustomerName.FormattingEnabled = true;
            this.cbbCustomerName.Location = new System.Drawing.Point(392, 56);
            this.cbbCustomerName.Name = "cbbCustomerName";
            this.cbbCustomerName.Size = new System.Drawing.Size(397, 21);
            this.cbbCustomerName.TabIndex = 9;
            // 
            // cbbCustomerCode
            // 
            this.cbbCustomerCode.FormattingEnabled = true;
            this.cbbCustomerCode.Location = new System.Drawing.Point(121, 56);
            this.cbbCustomerCode.Name = "cbbCustomerCode";
            this.cbbCustomerCode.Size = new System.Drawing.Size(114, 21);
            this.cbbCustomerCode.TabIndex = 2;
            this.cbbCustomerCode.SelectedValueChanged += new System.EventHandler(this.cbbCustomerCode_SelectedValueChanged);
            // 
            // txtTranNo
            // 
            this.txtTranNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtTranNo.ForeColor = System.Drawing.Color.Black;
            this.txtTranNo.Location = new System.Drawing.Point(675, 12);
            this.txtTranNo.Name = "txtTranNo";
            this.txtTranNo.ReadOnly = true;
            this.txtTranNo.Size = new System.Drawing.Size(114, 20);
            this.txtTranNo.TabIndex = 4;
            this.txtTranNo.TabStop = false;
            // 
            // lblTranNo
            // 
            this.lblTranNo.AutoSize = true;
            this.lblTranNo.Location = new System.Drawing.Point(575, 15);
            this.lblTranNo.Name = "lblTranNo";
            this.lblTranNo.Size = new System.Drawing.Size(46, 13);
            this.lblTranNo.TabIndex = 56;
            this.lblTranNo.Text = "Tran No";
            // 
            // lblCustomerCode
            // 
            this.lblCustomerCode.AutoSize = true;
            this.lblCustomerCode.Location = new System.Drawing.Point(6, 59);
            this.lblCustomerCode.Name = "lblCustomerCode";
            this.lblCustomerCode.Size = new System.Drawing.Size(79, 13);
            this.lblCustomerCode.TabIndex = 24;
            this.lblCustomerCode.Text = "Customer Code";
            // 
            // lblGuaranteeType
            // 
            this.lblGuaranteeType.AutoSize = true;
            this.lblGuaranteeType.Location = new System.Drawing.Point(6, 103);
            this.lblGuaranteeType.Name = "lblGuaranteeType";
            this.lblGuaranteeType.Size = new System.Drawing.Size(84, 13);
            this.lblGuaranteeType.TabIndex = 41;
            this.lblGuaranteeType.Text = "Guarantee Type";
            // 
            // txtLGNo
            // 
            this.txtLGNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.txtLGNo.ForeColor = System.Drawing.Color.Black;
            this.txtLGNo.Location = new System.Drawing.Point(392, 12);
            this.txtLGNo.Name = "txtLGNo";
            this.txtLGNo.ReadOnly = true;
            this.txtLGNo.Size = new System.Drawing.Size(114, 20);
            this.txtLGNo.TabIndex = 3;
            this.txtLGNo.TabStop = false;
            // 
            // lblLGNo
            // 
            this.lblLGNo.AutoSize = true;
            this.lblLGNo.Location = new System.Drawing.Point(305, 15);
            this.lblLGNo.Name = "lblLGNo";
            this.lblLGNo.Size = new System.Drawing.Size(38, 13);
            this.lblLGNo.TabIndex = 22;
            this.lblLGNo.Text = "LG No";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(305, 59);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(82, 13);
            this.lblCustomerName.TabIndex = 26;
            this.lblCustomerName.Text = "Customer Name";
            // 
            // lblSecurity
            // 
            this.lblSecurity.AutoSize = true;
            this.lblSecurity.Location = new System.Drawing.Point(6, 133);
            this.lblSecurity.Name = "lblSecurity";
            this.lblSecurity.Size = new System.Drawing.Size(45, 13);
            this.lblSecurity.TabIndex = 28;
            this.lblSecurity.Text = "Security";
            // 
            // lblBookingPurpose
            // 
            this.lblBookingPurpose.AutoSize = true;
            this.lblBookingPurpose.Location = new System.Drawing.Point(680, 133);
            this.lblBookingPurpose.Name = "lblBookingPurpose";
            this.lblBookingPurpose.Size = new System.Drawing.Size(88, 13);
            this.lblBookingPurpose.TabIndex = 30;
            this.lblBookingPurpose.Text = "Booking Purpose";
            // 
            // ckbBookingPurpose
            // 
            this.ckbBookingPurpose.AutoSize = true;
            this.ckbBookingPurpose.Location = new System.Drawing.Point(774, 132);
            this.ckbBookingPurpose.Name = "ckbBookingPurpose";
            this.ckbBookingPurpose.Size = new System.Drawing.Size(15, 14);
            this.ckbBookingPurpose.TabIndex = 10;
            this.ckbBookingPurpose.UseVisualStyleBackColor = true;
            // 
            // lblExpireDate
            // 
            this.lblExpireDate.AutoSize = true;
            this.lblExpireDate.Location = new System.Drawing.Point(575, 38);
            this.lblExpireDate.Name = "lblExpireDate";
            this.lblExpireDate.Size = new System.Drawing.Size(62, 13);
            this.lblExpireDate.TabIndex = 47;
            this.lblExpireDate.Text = "Expire Date";
            // 
            // lblGLCode
            // 
            this.lblGLCode.AutoSize = true;
            this.lblGLCode.Location = new System.Drawing.Point(6, 15);
            this.lblGLCode.Name = "lblGLCode";
            this.lblGLCode.Size = new System.Drawing.Size(49, 13);
            this.lblGLCode.TabIndex = 32;
            this.lblGLCode.Text = "GL Code";
            // 
            // dtpExpireDate
            // 
            this.dtpExpireDate.CustomFormat = "yyyy/MM/dd";
            this.dtpExpireDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpExpireDate.Location = new System.Drawing.Point(675, 34);
            this.dtpExpireDate.Name = "dtpExpireDate";
            this.dtpExpireDate.Size = new System.Drawing.Size(114, 20);
            this.dtpExpireDate.TabIndex = 1;
            this.dtpExpireDate.ValueChanged += new System.EventHandler(this.dtpExpireDate_ValueChanged);
            // 
            // lblValueDate
            // 
            this.lblValueDate.AutoSize = true;
            this.lblValueDate.Location = new System.Drawing.Point(305, 38);
            this.lblValueDate.Name = "lblValueDate";
            this.lblValueDate.Size = new System.Drawing.Size(60, 13);
            this.lblValueDate.TabIndex = 44;
            this.lblValueDate.Text = "Value Date";
            // 
            // dtpInputDate
            // 
            this.dtpInputDate.CustomFormat = "yyyy/MM/dd";
            this.dtpInputDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInputDate.Location = new System.Drawing.Point(121, 34);
            this.dtpInputDate.Name = "dtpInputDate";
            this.dtpInputDate.Size = new System.Drawing.Size(114, 20);
            this.dtpInputDate.TabIndex = 5;
            // 
            // dtpValueDate
            // 
            this.dtpValueDate.CustomFormat = "yyyy/MM/dd";
            this.dtpValueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpValueDate.Location = new System.Drawing.Point(392, 34);
            this.dtpValueDate.Name = "dtpValueDate";
            this.dtpValueDate.Size = new System.Drawing.Size(114, 20);
            this.dtpValueDate.TabIndex = 0;
            this.dtpValueDate.ValueChanged += new System.EventHandler(this.dtpValueDate_ValueChanged);
            // 
            // lblInputDate
            // 
            this.lblInputDate.AutoSize = true;
            this.lblInputDate.Location = new System.Drawing.Point(6, 38);
            this.lblInputDate.Name = "lblInputDate";
            this.lblInputDate.Size = new System.Drawing.Size(57, 13);
            this.lblInputDate.TabIndex = 38;
            this.lblInputDate.Text = "Input Date";
            // 
            // cbbGuaranteeType
            // 
            this.cbbGuaranteeType.FormattingEnabled = true;
            this.cbbGuaranteeType.Location = new System.Drawing.Point(121, 100);
            this.cbbGuaranteeType.Name = "cbbGuaranteeType";
            this.cbbGuaranteeType.Size = new System.Drawing.Size(114, 21);
            this.cbbGuaranteeType.TabIndex = 6;
            this.cbbGuaranteeType.SelectedIndexChanged += new System.EventHandler(this.cbbGuaranteeType_SelectedIndexChanged);
            // 
            // lblLGCategory
            // 
            this.lblLGCategory.AutoSize = true;
            this.lblLGCategory.Location = new System.Drawing.Point(15, 8);
            this.lblLGCategory.Name = "lblLGCategory";
            this.lblLGCategory.Size = new System.Drawing.Size(66, 13);
            this.lblLGCategory.TabIndex = 78;
            this.lblLGCategory.Text = "LG Category";
            // 
            // btnCreate
            // 
            this.btnCreate.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnCreate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnCreate.Location = new System.Drawing.Point(337, 558);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(201, 23);
            this.btnCreate.TabIndex = 3;
            this.btnCreate.Text = "Cr&eate Charge Collection Schedule";
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click_1);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(762, 558);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSaveAndContinue
            // 
            this.btnSaveAndContinue.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSaveAndContinue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSaveAndContinue.Location = new System.Drawing.Point(625, 558);
            this.btnSaveAndContinue.Name = "btnSaveAndContinue";
            this.btnSaveAndContinue.Size = new System.Drawing.Size(131, 23);
            this.btnSaveAndContinue.TabIndex = 5;
            this.btnSaveAndContinue.Text = "Save and C&ontinue";
            this.btnSaveAndContinue.UseVisualStyleBackColor = false;
            this.btnSaveAndContinue.Click += new System.EventHandler(this.btnSaveAndContinue_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(544, 558);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cbbLGCategory
            // 
            this.cbbLGCategory.FormattingEnabled = true;
            this.cbbLGCategory.Location = new System.Drawing.Point(97, 5);
            this.cbbLGCategory.Name = "cbbLGCategory";
            this.cbbLGCategory.Size = new System.Drawing.Size(121, 21);
            this.cbbLGCategory.TabIndex = 0;
            this.cbbLGCategory.SelectedValueChanged += new System.EventHandler(this.cbbLGCategory_SelectedValueChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn1.FillWeight = 101.1236F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Sub";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // tNumEditDataGridViewColumn1
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "N0";
            dataGridViewCellStyle10.NullValue = null;
            this.tNumEditDataGridViewColumn1.DefaultCellStyle = dataGridViewCellStyle10;
            this.tNumEditDataGridViewColumn1.HeaderText = "Amount";
            this.tNumEditDataGridViewColumn1.Name = "tNumEditDataGridViewColumn1";
            this.tNumEditDataGridViewColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.HeaderText = "Transient Account";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle11.Format = "N5";
            dataGridViewCellStyle11.NullValue = null;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn2.HeaderText = "Fee suggestion";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tNumEditDataGridViewColumn2
            // 
            this.tNumEditDataGridViewColumn2.DecimalLength = 5;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle12.Format = "N5";
            this.tNumEditDataGridViewColumn2.DefaultCellStyle = dataGridViewCellStyle12;
            this.tNumEditDataGridViewColumn2.HeaderText = "Fee";
            this.tNumEditDataGridViewColumn2.Name = "tNumEditDataGridViewColumn2";
            this.tNumEditDataGridViewColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.tNumEditDataGridViewColumn2.Width = 60;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewTextBoxColumn3.HeaderText = "Date Of Actual  Collection";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // frmLGIssue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(844, 590);
            this.Controls.Add(this.cbbLGCategory);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSaveAndContinue);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.grbDetailInformation);
            this.Controls.Add(this.grbGeneralInformation);
            this.Controls.Add(this.lblLGCategory);
            this.Name = "frmLGIssue";
            this.Text = "List LG";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGIssue_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grbSecurity.ResumeLayout(false);
            this.grbSecurity.PerformLayout();
            this.grbDetailInformation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgLGList)).EndInit();
            this.grbGeneralInformation.ResumeLayout(false);
            this.grbGeneralInformation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.Button btnAddApplicant;
		private System.Windows.Forms.ComboBox cbbApplicant;
		private System.Windows.Forms.Label lblApplicantName;
		private UserCtrl.DisableTextBox txtGLCode;
		private System.Windows.Forms.RichTextBox txtRemark;
		private System.Windows.Forms.Label lblRemark;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label4;
		private UserCtrl.NumberOnlyTextBoxIsEmpty  txtOrther;
		private System.Windows.Forms.RadioButton radOthers;
		private System.Windows.Forms.RadioButton radStandard;
		private System.Windows.Forms.ComboBox cbbCurrency;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label lblCurrency;
		private System.Windows.Forms.TextBox txtRepresentation3;
		private System.Windows.Forms.TextBox txtRepresentation2;
		private System.Windows.Forms.Label lblRepresentation3;
		private System.Windows.Forms.Label lblRepresentation2;
		private System.Windows.Forms.TextBox txtRepresentation1;
		private System.Windows.Forms.Label lblRepresentation1;
		private System.Windows.Forms.RichTextBox txtContractInformation;
		private System.Windows.Forms.Label lblContractInformation;
		private System.Windows.Forms.GroupBox grbSecurity;
		private System.Windows.Forms.RadioButton radCleanBasis;
		private System.Windows.Forms.RadioButton radFledgeDeposit;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label lblPercent;
        private NumberOnlyTextBox txtLGRate;
		private System.Windows.Forms.Label lblLGRate;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.GroupBox grbDetailInformation;
        private TabOrderDatagridView dtgLGList;
		private System.Windows.Forms.GroupBox grbGeneralInformation;
		private System.Windows.Forms.Label lblCalculateType;
		private System.Windows.Forms.ComboBox cbbCalculateType;
		private System.Windows.Forms.ComboBox cbbBeneficiary;
		private System.Windows.Forms.Label lblBeneficiary;
		private System.Windows.Forms.ComboBox cbbCustomerName;
        private AutoCompleteCombobox cbbCustomerCode;
		private UserCtrl.DisableTextBox txtTranNo;
		private System.Windows.Forms.Label lblTranNo;
		private System.Windows.Forms.Label lblCustomerCode;
		private System.Windows.Forms.Label lblGuaranteeType;
		private UserCtrl.DisableTextBox txtLGNo;
		private System.Windows.Forms.Label lblLGNo;
		private System.Windows.Forms.Label lblCustomerName;
		private System.Windows.Forms.Label lblSecurity;
		private System.Windows.Forms.Label lblBookingPurpose;
		private System.Windows.Forms.CheckBox ckbBookingPurpose;
		private System.Windows.Forms.Label lblExpireDate;
		private System.Windows.Forms.Label lblGLCode;
		private System.Windows.Forms.DateTimePicker dtpExpireDate;
		private System.Windows.Forms.Label lblValueDate;
		private System.Windows.Forms.DateTimePicker dtpInputDate;
		private System.Windows.Forms.DateTimePicker dtpValueDate;
		private System.Windows.Forms.Label lblInputDate;
		private System.Windows.Forms.ComboBox cbbGuaranteeType;
		private System.Windows.Forms.Label lblLGCategory;
		private System.Windows.Forms.Button btnCreate;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnSaveAndContinue;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Button btnAddBeneficiary;
		private System.Windows.Forms.ComboBox cbbLGCategory;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private TNumEditDataGridViewColumn tNumEditDataGridViewColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private TNumEditDataGridViewColumn tNumEditDataGridViewColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSub;
        private System.Windows.Forms.DataGridViewComboBoxColumn colCurrency;
        private TNumEditDataGridViewColumn colAmount;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colTransientAccount;
        private System.Windows.Forms.DataGridViewComboBoxColumn colChargeAccount;
        private TNumEditDataGridViewColumn colFeeSuggestion;
        private TNumEditDataGridViewColumn colFee;
        private System.Windows.Forms.DataGridViewComboBoxColumn colFeeCurrency;
        private ctrlLGCalendarColumn colDateOfActualCollection;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbLGAllowed;

	}
}