﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: plco $
 * $Date: 2013-03-22 16:00:00 +0700 (Fri, 22 Mar 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to management beneficiary
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;
using UserCtrl;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGListBeneficiary : frmLGMaster
    {
        #region Variables
        private clsLGBeneficiaryDTO m_BenDto;
        private clsLGBeneficiaryBus m_BenBus;
        //Name of column
        private string m_colCheck = "colCheck";
        private string m_colBeneficiaryCode = "colBeneficiaryCode";
        //private string m_colBeneficiaryName = "colBeneficiaryName";
        //private string m_colBeneficiaryAddress = "colBeneficiaryAddress";
        //private string m_colBeneficiaryNational = "colBeneficiaryNational";
        //private string m_colBeneficiaryTel = "colBeneficiaryTel";
        //private string m_colBeneficiaryFax = "colBeneficiaryFax";
        //private string m_colNoChange = "colNoChange";
        private string m_colSeqBeneficiary = "colSeqBeneficiary";

        //count of row when click cell checkbox on grid
        private int m_ListSelectIndex = 0;
        //Count of row is selected enable
        private int m_RowSelectCount = 0;

        //used to check all on grid
        //private bool m_IsCheckAll = false;
        #endregion

        #region Contructors
        /// <summary>
        /// Constructor of Beneficiary list form
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public frmLGListBeneficiary()
        {
            try
            {
                InitializeComponent();
                base.SetFormStyleCommon();
                SetFormStyle();

                m_BenDto = new clsLGBeneficiaryDTO();
                m_BenBus = new clsLGBeneficiaryBus();
                //fill data from database when form load
                FillData();                
				_security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Show form dialog to create applicant
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGCreateBeneficiary frm = new frmLGCreateBeneficiary();
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    FillData();
                }

            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Update Beneficiary
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbUpdateBeneficiary_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgBeneficiaryList.Rows.Count > 0)
                {
                    DataGridViewRow dr = dtgBeneficiaryList.SelectedRows[0];
                    m_BenDto.SeqBeneficiary = (int)dr.Cells[m_colSeqBeneficiary].Value;
                    m_BenDto.BeneficiaryCode = dr.Cells[m_colBeneficiaryCode].Value.ToString();

                    frmLGUpdateBeneficiary frm = new frmLGUpdateBeneficiary(m_BenDto);
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    if (!frm.IsDisposed)
                    {
                        if (frm.ShowDialog() == DialogResult.OK)
                        {
                            FillData();
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }

        }

        /// <summary>
        /// Search event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                //fill data on grid
                FillData();
                if (dtgBeneficiaryList.Rows.Count == 0)
                {
                    tsbUpdateBeneficiary.Visible = false;
                    clsLGMesageCollection.MessageNoTransactions();
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }

        }

        /// <summary>
        /// Delete an item on datagrid event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void tsbDeleteBeneficiary_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult dlgResult = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.YesNoConfirm,
                    String.Format(clsLGCommonMessage.CONFIRM_DETELE, clsLGConstant.BENEFICIARY_NAME, GetListBeneficiaryForDelete()));
                if (dlgResult == DialogResult.No || dlgResult == DialogResult.Cancel)
                {
                    return;
                }
                else
                {
                    //delete beneficiary
                    DeleteBeneficiary();
                }
            }
            catch (System.Exception ex)
            {
                try
                {
                    //rollback data
                    m_BenBus.RollBack();
                }
                catch (System.Exception)
                {

                }
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }

        }

        /// <summary>
        /// Selection changed event on datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgBeneficiaryList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dtgBeneficiaryList.Rows.Count > 0)
                {
                    tsbUpdateBeneficiary.Visible = true;
                }
            }
            catch (System.Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }

        }

        /// <summary>
        /// Event Cell Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void dtgBeneficiaryList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex == 0)
                {
                    DataGridViewDisableCheckBoxCell cell = dtgBeneficiaryList[0, e.RowIndex] as DataGridViewDisableCheckBoxCell;
                    if (cell.Enabled)
                    {
                        if (bool.Parse(dtgBeneficiaryList[0, e.RowIndex].Value.ToString()))
                        {
                            m_ListSelectIndex--;
                        }
                        else
                        {
                            m_ListSelectIndex++;
                        }

                        dtgBeneficiaryList[0, e.RowIndex].Value = (!bool.Parse(dtgBeneficiaryList[0, e.RowIndex].Value.ToString())).ToString();

                        //if (m_ListSelectIndex == m_RowSelectCount)
                        //{
                        //    m_IsCheckAll = true;
                        //}
                        //else
                        //{
                        //    m_IsCheckAll = false;
                        //}

                        //set visible 'Delete Beneficiary' toolStrip
                        SetVisibleDeleteBeneficiary();
                    }
                }

            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }

        /// <summary>
        /// Form Closing Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void frmLGListBeneficiary_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (m_ListSelectIndex > 0)
                {
                    DialogResult dlgResult = clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Confirm,
                    String.Format(clsLGCommonMessage.CONFIRM_DETELE, clsLGConstant.BENEFICIARY_NAME, GetListBeneficiaryForDelete()));
                    if (dlgResult == DialogResult.Yes)
                    {
                        //delete Beneficiary
                        DeleteBeneficiary();
                        e.Cancel = false;
                    }
                    if (dlgResult == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                    }
                    if (dlgResult == DialogResult.No)
                    {
                        e.Cancel = false;
                    }
                }
            }
            catch (Exception ex)
            {
                clsError.ShowErrorScreen(ex.Message +
                   Environment.NewLine +
                   ex.TargetSite, this);
                clsLogFile.LogException(ex.Message, clsLGConstant.LG_MODULE);
            }
        }
        #endregion

        #region Private Functions

        /// <summary>
        /// init layout for datagirdview
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void SetFormStyle()
        {
            #region MAX LENGTH
            txtBeneficiaryAddress.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_ADDRESS;
            txtBeneficiaryCode.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_CODE;
            txtBeneficiaryName.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_NAME;
            txtBeneficiaryNational.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_NATIONAL;
            txtBeneficiaryTel.MaxLength = clsLGConstant.LENGTH_BENEFICIARY_TEL;
            #endregion

            tsbUpdateBeneficiary.Visible = false;
            tsbDeleteBeneficiary.Visible = false;
        }

        /// <summary>
        /// Get Data on form for search
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void GetDataForSearch()
        {
            m_BenDto.BeneficiaryCode = txtBeneficiaryCode.Text.Trim();
            m_BenDto.BeneficiaryName = txtBeneficiaryName.Text.Trim();
            m_BenDto.BeneficiaryAddress = txtBeneficiaryAddress.Text.Trim();
            m_BenDto.BeneficiaryNational = txtBeneficiaryNational.Text.Trim();
            m_BenDto.BeneficiaryTel = txtBeneficiaryTel.Text.Trim();
        }


        /// <summary>
        /// Fila data to list Beneficiary
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void FillData()
        {
            //clear data on grid
            dtgBeneficiaryList.Rows.Clear();
            //clear list index to check on grid
            m_ListSelectIndex = 0;
            //reset count of row is selected enable
            m_RowSelectCount = 0;
            //Reset checkall data of list Beneficiary
          //  m_IsCheckAll = false;
            tsbDeleteBeneficiary.Visible = false;
            //get data for search
            GetDataForSearch();
            //get list Beneficiary by search conditions
            List<clsLGBeneficiaryDTO> lst = m_BenBus.GetListBeneficiary(m_BenDto);
            if (lst.Count == 0)
            {
                return;
            }
            else
            {
                for (int i = 0; i < lst.Count; i++)
                {
                    //add row for datagirdview
                    dtgBeneficiaryList.Rows.Add(false, lst[i].BeneficiaryCode, lst[i].BeneficiaryName, lst[i].BeneficiaryAddress, lst[i].BeneficiaryNational,
                        lst[i].BeneficiaryTel, lst[i].BeneficiaryFax, lst[i].NoChange, lst[i].SeqBeneficiary);
                    //get cell disable checkbox
                    DataGridViewDisableCheckBoxCell cell = dtgBeneficiaryList.Rows[i].Cells[m_colCheck] as DataGridViewDisableCheckBoxCell;
                    // NoChange = 0, allow update,delete it
                    // NoChange != 0, don't allow update,delete it
                    if (lst[i].NoChange == 0)
                    {
                        cell.Enabled = true;
                        m_RowSelectCount++;
                    }
                    else
                    {
                        cell.Enabled = false;
                    }
                }
            }
        }

        /// <summary>
        /// Delete List Beneficiary is checked on grid
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public void DeleteBeneficiary()
        {
            List<clsLGBeneficiaryDTO> lst = new List<clsLGBeneficiaryDTO>();
            for (int i = 0; i < dtgBeneficiaryList.Rows.Count; i++)
            {
                if (Boolean.Parse(dtgBeneficiaryList.Rows[i].Cells[m_colCheck].Value.ToString()) == true)
                {
                    clsLGBeneficiaryDTO temp = new clsLGBeneficiaryDTO();
                    temp.SeqBeneficiary = (int)dtgBeneficiaryList.Rows[i].Cells[m_colSeqBeneficiary].Value;
                    temp.BeneficiaryCode = dtgBeneficiaryList.Rows[i].Cells[m_colBeneficiaryCode].Value.ToString();
                    lst.Add(temp);
                }
            }

            if (lst.Count > 0)
            {
                //delete Beneficiary
                if (m_BenBus.DeleteBeneficiary(lst) > 0)
                {
                    //write log data for delete beneficiary
                    WriteLog(lst);
                    //commit data
                    m_BenBus.Commit();
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Infomaition,
                        String.Format(clsLGCommonMessage.INFOR_ACTION_SUCCESS, clsLGConstant.ACTION_DELETE, clsLGConstant.BENEFICIARY_NAME));
                    //fill data on grid
                    FillData();
                }
                else
                {
                    //rollback data
                    m_BenBus.RollBack();
                    clsLGMesageCollection.ShowMessage((int)CommonValue.MessageType.Error,
                        String.Format(clsLGCommonMessage.ERROR_CAN_NOT_DELETE, clsLGConstant.BENEFICIARY_NAME, GetListBeneficiaryForDelete()));

                }
            }
        }

        /// <summary>
        /// Write Delete information to Log History
        /// </summary>
        /// <param name="lst"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void WriteLog(List<clsLGBeneficiaryDTO> lst)
        {
            clsLGLogBase logBase = new clsLGLogBase();
            // //header history
            logBase.ApplicationName = this.Text;
            logBase.UserID = clsUserInfo.UserNo.ToString();
            //+ Deleting Log 
            logBase.Action = (int)CommonValue.ActionType.Delete;

            if (lst.Count > 0)
            {
                logBase.Key = String.Join(",", lst.Select(a => a.BeneficiaryCode).ToArray());
                m_BenBus.WriteLog(logBase);
            }
        }

        /// <summary>
        /// Set Visible Delete Beneficiary 
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        private void SetVisibleDeleteBeneficiary()
        {
            //Check: cell checkbox is checked = true to visible 'Delete Beneficiary' toolstrip
            //else hidden it
            if (m_ListSelectIndex > 0)
            {
                tsbDeleteBeneficiary.Visible = true;
            }
            else
            {
                tsbDeleteBeneficiary.Visible = false;
            }
        }

        /// <summary>
        /// Get List Beneficiary For Delete
        /// </summary>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public string GetListBeneficiaryForDelete()
        {
            string arr = "[";
            int indexArr = 0;
            for (int i = 0; i < dtgBeneficiaryList.Rows.Count; i++)
            {
                if (Boolean.Parse(dtgBeneficiaryList.Rows[i].Cells[m_colCheck].Value.ToString()) == true)
                {
                    if (indexArr == 0)
                    {
                        arr += dtgBeneficiaryList.Rows[i].Cells[m_colBeneficiaryCode].Value.ToString();
                    }
                    else
                    {
                        arr += "," + dtgBeneficiaryList.Rows[i].Cells[m_colBeneficiaryCode].Value.ToString();
                    }
                    indexArr++;
                }
            }
            arr += "]";
            return arr;
        }
        #endregion

        #region Protected Functions

        /// <summary>
        /// Override ProceeCmdKey
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Alt | Keys.U))
            {
                if (tsbUpdateBeneficiary.Visible == true)
                {
                    tsbUpdateBeneficiary_Click(new object(), new EventArgs());
                }
            }
            if (keyData == (Keys.Alt | Keys.D))
            {
                if (tsbDeleteBeneficiary.Visible == true)
                {
                    tsbDeleteBeneficiary_Click(new object(), new EventArgs());
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        /// <summary>
        /// Processes a dialog box key.
        /// </summary>
        /// <param name="keyData"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (keyData == (Keys.Alt | Keys.U))
            {
                return true;
            }
            else if (keyData == (Keys.Alt | Keys.D))
            {
                return true;
            }
            else
            {
                return base.ProcessDialogKey(keyData);
            }
        }
        #endregion

    }
}
