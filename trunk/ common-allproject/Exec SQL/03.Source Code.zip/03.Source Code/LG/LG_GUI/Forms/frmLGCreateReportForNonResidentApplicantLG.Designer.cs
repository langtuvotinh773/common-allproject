﻿using UserCtrl;
namespace Phoenix.Lg.Gui.Forms
{
	partial class frmLGCreateReportForNonResidentApplicantLG
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        /// 

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblMonthYear = new System.Windows.Forms.Label();
            this.btnProcess = new System.Windows.Forms.Button();
            this.dtgCurrencyList = new TabOrderDatagridView();
            this.monthYearfrom = new Phoenix.Cpa.Common.MonthYearCalendar();
            this.colCurrency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colExchangeRate = new UserCtrl.TNumEditDataGridViewColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCurrencyList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(257, 181);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.Location = new System.Drawing.Point(338, 181);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblMonthYear
            // 
            this.lblMonthYear.AutoSize = true;
            this.lblMonthYear.Location = new System.Drawing.Point(29, 18);
            this.lblMonthYear.Name = "lblMonthYear";
            this.lblMonthYear.Size = new System.Drawing.Size(37, 13);
            this.lblMonthYear.TabIndex = 20;
            this.lblMonthYear.Text = "Month";
            // 
            // btnProcess
            // 
            this.btnProcess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnProcess.Location = new System.Drawing.Point(206, 13);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(75, 23);
            this.btnProcess.TabIndex = 1;
            this.btnProcess.Text = "&Process";
            this.btnProcess.UseVisualStyleBackColor = false;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // dtgCurrencyList
            // 
            this.dtgCurrencyList.AllowUserToAddRows = false;
            this.dtgCurrencyList.AllowUserToDeleteRows = false;
            this.dtgCurrencyList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgCurrencyList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgCurrencyList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgCurrencyList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgCurrencyList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCurrency,
            this.colExchangeRate});
            this.dtgCurrencyList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dtgCurrencyList.EnableHeadersVisualStyles = false;
            this.dtgCurrencyList.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.dtgCurrencyList.Location = new System.Drawing.Point(5, 52);
            this.dtgCurrencyList.Name = "dtgCurrencyList";
            this.dtgCurrencyList.RowHeadersVisible = false;
            this.dtgCurrencyList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgCurrencyList.Size = new System.Drawing.Size(407, 124);
            this.dtgCurrencyList.TabIndex = 2;
            this.dtgCurrencyList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgCurrencyList_CellEndEdit);
            // 
            // monthYearfrom
            // 
            this.monthYearfrom.CustomFormat = "MM/yyyy";
            this.monthYearfrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.monthYearfrom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.monthYearfrom.Location = new System.Drawing.Point(98, 12);
            this.monthYearfrom.Name = "monthYearfrom";
            this.monthYearfrom.ShowUpDown = true;
            this.monthYearfrom.Size = new System.Drawing.Size(79, 20);
            this.monthYearfrom.TabIndex = 0;
            this.monthYearfrom.Value = new System.DateTime(2013, 1, 1, 0, 0, 0, 0);
            // 
            // colCurrency
            // 
            this.colCurrency.DataPropertyName = "TransCurrency";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCurrency.DefaultCellStyle = dataGridViewCellStyle1;
            this.colCurrency.FillWeight = 51.0466F;
            this.colCurrency.HeaderText = "Currency";
            this.colCurrency.Name = "colCurrency";
            this.colCurrency.ReadOnly = true;
            this.colCurrency.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colExchangeRate
            // 
            this.colExchangeRate.DataPropertyName = "ExchangeRate";
            this.colExchangeRate.DecimalLength = 5;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N5";
            this.colExchangeRate.DefaultCellStyle = dataGridViewCellStyle2;
            this.colExchangeRate.FillWeight = 150.077F;
            this.colExchangeRate.HeaderText = "Exchange Rate (To USD)";
            this.colExchangeRate.MaxInputLength = 13;
            this.colExchangeRate.Name = "colExchangeRate";
            this.colExchangeRate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colExchangeRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // frmLGCreateReportForNonResidentApplicantLG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(223)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(418, 211);
            this.Controls.Add(this.dtgCurrencyList);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.monthYearfrom);
            this.Controls.Add(this.lblMonthYear);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "frmLGCreateReportForNonResidentApplicantLG";
            this.Text = "Create Report For Non-Resident Applicant LG";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGCreateUpdateReportForNonResidentApplicantLG_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dtgCurrencyList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private Phoenix.Cpa.Common.MonthYearCalendar monthYearfrom;
        private System.Windows.Forms.Label lblMonthYear;
        private System.Windows.Forms.Button btnProcess;
        private TabOrderDatagridView dtgCurrencyList;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCurrency;
        private UserCtrl.TNumEditDataGridViewColumn colExchangeRate;
    }
}