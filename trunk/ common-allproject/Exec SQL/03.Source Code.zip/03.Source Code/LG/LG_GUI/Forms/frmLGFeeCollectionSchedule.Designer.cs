﻿using UserCtrl;
namespace Phoenix.Lg.Gui.Forms
{
	partial class frmLGFeeCollectionSchedule
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtRefNo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbbSubCode = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dtgOCSchedule = new UserCtrl.TabOrderDatagridView();
            this.colNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colClaimedDate = new UserCtrl.ctrlLGCalendarColumn();
            this.colActualClaimedDdate = new UserCtrl.ctrlLGCalendarColumn();
            this.colReceivedDate = new UserCtrl.ctrlLGCalendarColumn();
            this.colSuggestedFee = new UserCtrl.TNumEditDataGridViewColumn();
            this.colPrincipalCCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colChargeCCY = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colExchangeRate = new UserCtrl.TNumEditDataGridViewColumn();
            this.colFee = new UserCtrl.TNumEditDataGridViewColumn();
            this.colRelatedSubCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oldSubCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RealSubNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtBenificiary = new UserCtrl.DisableTextBox();
            this.txtCustomer = new UserCtrl.DisableTextBox();
            this.disableTextBox1 = new UserCtrl.DisableTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgOCSchedule)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtRefNo
            // 
            this.txtRefNo.BackColor = System.Drawing.Color.Transparent;
            this.txtRefNo.Location = new System.Drawing.Point(12, 7);
            this.txtRefNo.Name = "txtRefNo";
            this.txtRefNo.Size = new System.Drawing.Size(79, 20);
            this.txtRefNo.TabIndex = 4;
            this.txtRefNo.Text = "Ref No";
            this.txtRefNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Customer Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(446, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sub Code";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbbSubCode
            // 
            this.cbbSubCode.FormattingEnabled = true;
            this.cbbSubCode.Location = new System.Drawing.Point(542, 8);
            this.cbbSubCode.Name = "cbbSubCode";
            this.cbbSubCode.Size = new System.Drawing.Size(121, 21);
            this.cbbSubCode.TabIndex = 0;
            this.cbbSubCode.SelectedIndexChanged += new System.EventHandler(this.cbbSubCode_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(446, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Beneficiary Name";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnSave.Location = new System.Drawing.Point(773, 452);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(854, 452);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRemove.Location = new System.Drawing.Point(87, 19);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 1;
            this.btnRemove.Text = "&Remove";
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnSub_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(253)))));
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAdd.Location = new System.Drawing.Point(6, 19);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "&Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dtgOCSchedule
            // 
            this.dtgOCSchedule.AllowUserToAddRows = false;
            this.dtgOCSchedule.AllowUserToResizeRows = false;
            this.dtgOCSchedule.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgOCSchedule.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgOCSchedule.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgOCSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgOCSchedule.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colNo,
            this.colClaimedDate,
            this.colActualClaimedDdate,
            this.colReceivedDate,
            this.colSuggestedFee,
            this.colPrincipalCCY,
            this.colChargeCCY,
            this.colExchangeRate,
            this.colFee,
            this.colRelatedSubCode,
            this.Type,
            this.oldSubCode,
            this.RealSubNo});
            this.dtgOCSchedule.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dtgOCSchedule.Location = new System.Drawing.Point(6, 48);
            this.dtgOCSchedule.MultiSelect = false;
            this.dtgOCSchedule.Name = "dtgOCSchedule";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgOCSchedule.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dtgOCSchedule.RowHeadersVisible = false;
            this.dtgOCSchedule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dtgOCSchedule.Size = new System.Drawing.Size(910, 334);
            this.dtgOCSchedule.TabIndex = 2;
            this.dtgOCSchedule.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgOCSchedule_CellValueChanged);
            this.dtgOCSchedule.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dtgOCSchedule_CellFormatting);
            this.dtgOCSchedule.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dtgOCSchedule_RowsAdded);
            this.dtgOCSchedule.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dtgOCSchedule_RowsRemoved);
            // 
            // colNo
            // 
            this.colNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Format = "N0";
            dataGridViewCellStyle2.NullValue = null;
            this.colNo.DefaultCellStyle = dataGridViewCellStyle2;
            this.colNo.FillWeight = 121.7501F;
            this.colNo.HeaderText = "No.";
            this.colNo.MinimumWidth = 30;
            this.colNo.Name = "colNo";
            this.colNo.ReadOnly = true;
            this.colNo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colNo.Width = 49;
            // 
            // colClaimedDate
            // 
            this.colClaimedDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "yyyy/MM/dd";
            this.colClaimedDate.DefaultCellStyle = dataGridViewCellStyle3;
            this.colClaimedDate.FillWeight = 168.7215F;
            this.colClaimedDate.HeaderText = "Claimed Date";
            this.colClaimedDate.MinimumWidth = 100;
            this.colClaimedDate.Name = "colClaimedDate";
            this.colClaimedDate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colClaimedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colActualClaimedDdate
            // 
            this.colActualClaimedDdate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.Format = "yyyy/MM/dd";
            this.colActualClaimedDdate.DefaultCellStyle = dataGridViewCellStyle4;
            this.colActualClaimedDdate.FillWeight = 168.7215F;
            this.colActualClaimedDdate.HeaderText = "Actual Claimed Date";
            this.colActualClaimedDdate.MinimumWidth = 100;
            this.colActualClaimedDdate.Name = "colActualClaimedDdate";
            this.colActualClaimedDdate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colActualClaimedDdate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colActualClaimedDdate.Width = 128;
            // 
            // colReceivedDate
            // 
            this.colReceivedDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Format = "yyyy/MM/dd";
            this.colReceivedDate.DefaultCellStyle = dataGridViewCellStyle5;
            this.colReceivedDate.HeaderText = "Received Date";
            this.colReceivedDate.MinimumWidth = 100;
            this.colReceivedDate.Name = "colReceivedDate";
            this.colReceivedDate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colReceivedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colReceivedDate.Width = 104;
            // 
            // colSuggestedFee
            // 
            this.colSuggestedFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colSuggestedFee.DecimalLength = 5;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Format = "N5";
            this.colSuggestedFee.DefaultCellStyle = dataGridViewCellStyle6;
            this.colSuggestedFee.HeaderText = "Suggested Fee";
            this.colSuggestedFee.Name = "colSuggestedFee";
            this.colSuggestedFee.ReadOnly = true;
            this.colSuggestedFee.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colSuggestedFee.Width = 104;
            // 
            // colPrincipalCCY
            // 
            this.colPrincipalCCY.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colPrincipalCCY.DefaultCellStyle = dataGridViewCellStyle7;
            this.colPrincipalCCY.HeaderText = "Principal CCY";
            this.colPrincipalCCY.Name = "colPrincipalCCY";
            this.colPrincipalCCY.ReadOnly = true;
            this.colPrincipalCCY.Width = 96;
            // 
            // colChargeCCY
            // 
            this.colChargeCCY.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colChargeCCY.DefaultCellStyle = dataGridViewCellStyle8;
            this.colChargeCCY.HeaderText = "Charge CCY";
            this.colChargeCCY.Name = "colChargeCCY";
            this.colChargeCCY.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colChargeCCY.Width = 71;
            // 
            // colExchangeRate
            // 
            this.colExchangeRate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colExchangeRate.DecimalLength = 5;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N5";
            this.colExchangeRate.DefaultCellStyle = dataGridViewCellStyle9;
            this.colExchangeRate.HeaderText = "Exchange Rate";
            this.colExchangeRate.MaxInputLength = 13;
            this.colExchangeRate.Name = "colExchangeRate";
            this.colExchangeRate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colExchangeRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colExchangeRate.Width = 87;
            // 
            // colFee
            // 
            this.colFee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colFee.DecimalLength = 2;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "N2";
            this.colFee.DefaultCellStyle = dataGridViewCellStyle10;
            this.colFee.HeaderText = "Fee";
            this.colFee.MaxInputLength = 13;
            this.colFee.MinimumWidth = 80;
            this.colFee.Name = "colFee";
            this.colFee.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colFee.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colFee.Width = 80;
            // 
            // colRelatedSubCode
            // 
            this.colRelatedSubCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colRelatedSubCode.DefaultCellStyle = dataGridViewCellStyle11;
            this.colRelatedSubCode.HeaderText = "Related Sub Code";
            this.colRelatedSubCode.MinimumWidth = 3;
            this.colRelatedSubCode.Name = "colRelatedSubCode";
            this.colRelatedSubCode.ReadOnly = true;
            this.colRelatedSubCode.Width = 119;
            // 
            // Type
            // 
            this.Type.HeaderText = "Column1";
            this.Type.Name = "Type";
            this.Type.Visible = false;
            this.Type.Width = 73;
            // 
            // oldSubCode
            // 
            this.oldSubCode.HeaderText = "Column1";
            this.oldSubCode.Name = "oldSubCode";
            this.oldSubCode.Visible = false;
            this.oldSubCode.Width = 73;
            // 
            // RealSubNo
            // 
            this.RealSubNo.HeaderText = "Column1";
            this.RealSubNo.Name = "RealSubNo";
            this.RealSubNo.Visible = false;
            this.RealSubNo.Width = 73;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.Format = "N0";
            dataGridViewCellStyle13.NullValue = null;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewTextBoxColumn1.FillWeight = 121.7501F;
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "No.";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.Width = 30;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewTextBoxColumn2.FillWeight = 168.7215F;
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "Claimed date";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridViewTextBoxColumn3.FillWeight = 168.7215F;
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "Actual Claimed date";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "Received Date";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 87;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn5.Frozen = true;
            this.dataGridViewTextBoxColumn5.HeaderText = "Suggested fee";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 86;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn6.Frozen = true;
            this.dataGridViewTextBoxColumn6.HeaderText = "Principal CCY";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 87;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Exchange Rate";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 111;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Fee";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 111;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "Related sub code";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 111;
            // 
            // txtBenificiary
            // 
            this.txtBenificiary.BackColor = System.Drawing.SystemColors.Control;
            this.txtBenificiary.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtBenificiary.ForeColor = System.Drawing.Color.Black;
            this.txtBenificiary.Location = new System.Drawing.Point(542, 30);
            this.txtBenificiary.Name = "txtBenificiary";
            this.txtBenificiary.ReadOnly = true;
            this.txtBenificiary.Size = new System.Drawing.Size(291, 20);
            this.txtBenificiary.TabIndex = 5;
            this.txtBenificiary.TabStop = false;
            this.txtBenificiary.Text = " ";
            // 
            // txtCustomer
            // 
            this.txtCustomer.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomer.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtCustomer.ForeColor = System.Drawing.Color.Black;
            this.txtCustomer.Location = new System.Drawing.Point(102, 30);
            this.txtCustomer.Name = "txtCustomer";
            this.txtCustomer.ReadOnly = true;
            this.txtCustomer.Size = new System.Drawing.Size(338, 20);
            this.txtCustomer.TabIndex = 5;
            this.txtCustomer.TabStop = false;
            this.txtCustomer.Text = " ";
            // 
            // disableTextBox1
            // 
            this.disableTextBox1.BackColor = System.Drawing.SystemColors.Control;
            this.disableTextBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.disableTextBox1.ForeColor = System.Drawing.Color.Black;
            this.disableTextBox1.Location = new System.Drawing.Point(102, 9);
            this.disableTextBox1.Name = "disableTextBox1";
            this.disableTextBox1.ReadOnly = true;
            this.disableTextBox1.Size = new System.Drawing.Size(121, 20);
            this.disableTextBox1.TabIndex = 5;
            this.disableTextBox1.TabStop = false;
            this.disableTextBox1.Text = " ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnRemove);
            this.groupBox1.Controls.Add(this.dtgOCSchedule);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Location = new System.Drawing.Point(12, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(922, 388);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LG Fee Collection Schedule";
            // 
            // frmLGFeeCollectionSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(941, 487);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cbbSubCode);
            this.Controls.Add(this.txtBenificiary);
            this.Controls.Add(this.txtCustomer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.disableTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtRefNo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "frmLGFeeCollectionSchedule";
            this.Text = "LG Fee Collection Schedule";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLGFeeCollectionSchedule_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dtgOCSchedule)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label txtRefNo;
        private UserCtrl.DisableTextBox disableTextBox1;
		private System.Windows.Forms.Label label1;
        private UserCtrl.DisableTextBox txtCustomer;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cbbSubCode;
		private System.Windows.Forms.Label label3;
        private UserCtrl.DisableTextBox txtBenificiary;
		private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnRemove;
		private System.Windows.Forms.Button btnAdd;
        private TabOrderDatagridView dtgOCSchedule;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNo;
        private UserCtrl.ctrlLGCalendarColumn colClaimedDate;
        private UserCtrl.ctrlLGCalendarColumn colActualClaimedDdate;
        private UserCtrl.ctrlLGCalendarColumn colReceivedDate;
        private UserCtrl.TNumEditDataGridViewColumn colSuggestedFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrincipalCCY;
        private System.Windows.Forms.DataGridViewComboBoxColumn colChargeCCY;
        private UserCtrl.TNumEditDataGridViewColumn colExchangeRate;
        private UserCtrl.TNumEditDataGridViewColumn colFee;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRelatedSubCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn oldSubCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn RealSubNo;
	}
}