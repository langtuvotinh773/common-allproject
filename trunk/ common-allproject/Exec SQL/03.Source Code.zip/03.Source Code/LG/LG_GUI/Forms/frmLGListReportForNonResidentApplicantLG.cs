﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: htkhiem $
 * $Date: 2013-01-16 14:30:00 +0700 (Wed, 16 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * This class is used to List Report For Non Resident Applicant 
 * for LG module.
 */

using System;
using System.Collections;
using System.Linq;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Cpa.Bus;
using Phoenix.Lg.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Gui.Forms
{
    public partial class frmLGListReportForNonResidentApplicantLG : frmLGMaster
    {
        #region Global Variable
        //DTO & BUS
        private clsLGReportForNonResidentAppBus lgExchangeRateBus = new clsLGReportForNonResidentAppBus();
        private clsLGListReportForNonResidentAppDTO lgExchangeRateDTO = new clsLGListReportForNonResidentAppDTO();

        //Export to word
        private object _wordApplication = null;
        private object _wordDocument = null;
        private clsLGWordBase wordBase = new clsLGWordBase();                        

        //For List Report For Non Resident App
        //+ [colMonthYear] Column
        private string m_colMonthYear = "colMonthYear";
        //+ [colLockStatus] Column
        private string m_colLockStatus = "colLockStatus";

        //For Reporting
        //+ Word File Name
        private string fileName = "REPORT FOR NON-RESIDENT APPLICANT LG.doc";
        //+ Project Name
        private string projectName = clsLGConstant.LG_MODULE;
        //+ Template Word File Name
        private string templateName = "Mau baocao Baolanh.cv28.doc";
        //+ [Company Name] Field
        private string fieldCompanyName = "#CompanyName";
        //+ [Month] Field
        private string fieldMonth = "#month";
        //+ [Year] Field
        private string fieldYear = "#year";
        //+ [Within Sum VND] Field
        private string fieldWithin_Sum_VND = "#Within_Sum_VND";
        //+ [Within Sum USD] Field
        private string fieldWithin_Sum_USD = "#Within_Sum_USD";
        //+ [End Sum VND] Field
        private string fieldEnd_Sum_VND = "#End_Sum_VND";
        //+ [End Sum USD] Field
        private string fieldEnd_Sum_USD = "#End_Sum_USD";

        //Check Loading
        private bool isLoading = true;

        // For Security Checking
        clsSEAuthorizer _security = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor of report form
        /// </summary>
        /// @cond
        /// Author: Yen Phan
        /// @endcond
        public frmLGListReportForNonResidentApplicantLG()
        {
            try
            {
                InitializeComponent();
                // Check authorization
                _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);

                Init();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }            
        }
        #endregion

        #region Member Method        
        /// <summary>
        /// Initialize
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void Init()
        {
            SetFormStyleCommon();
            //Not allow to generate columns automatically
            dtgMonthList.AutoGenerateColumns = false;            
            //Set value
            DateTime serverDate = clsLGCommonBus.Instance().GetServerDate();
            monthYearfrom.Value = new DateTime(serverDate.Year, serverDate.Month, 1, 0, 0, 0);
            monthYearTo.Value = new DateTime(serverDate.Year, serverDate.Month, 1, 0, 0, 0);
            //Searching
            Search();
            //Show/Hide toolstrip
            ShowHideToolStrip();
        }

        /// <summary>
        /// Search
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void Search()
        {
            //Declaration
            lgExchangeRateDTO = new clsLGListReportForNonResidentAppDTO();
            //Assign value from inputting
            lgExchangeRateDTO.MonthYearFr = monthYearfrom.Value;
            lgExchangeRateDTO.MonthYearTo = monthYearTo.Value;
            //Get data collection from database
            lgExchangeRateBus.GetListExchangeRateForListing(ref lgExchangeRateDTO);
            //Set data collection to grid
            dtgMonthList.DataSource = lgExchangeRateDTO.LstNonResidentAppInformation;

            //No records
            if (lgExchangeRateDTO.LstNonResidentAppInformation.Count == 0 && !isLoading)
            {
                clsLGMesageCollection.MessageNoTransactions();
            }  
        }

        /// <summary>
        /// Show Hide Tool Strip by parameter
        /// </summary>
        /// <param name="isLocked"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void ShowHideToolStrip()
        {
            //Declaration
            bool isLocked = false;
            //Grid Empty
            if (dtgMonthList.Rows.Count == 0 || dtgMonthList.SelectedRows.Count == 0)
            {
                tsbUnlock.Visible = false;
                tsbPrint.Visible = false;
                tsbLock.Visible = false;
                tsbUpdate.Visible = false;
                return;
            }
            //Grid not empty
            int index = dtgMonthList.Rows.IndexOf(dtgMonthList.SelectedRows[0]);
            isLocked = dtgMonthList.Rows[index].Cells[m_colLockStatus].Value.ToString() == "0" ? false : true;
            //- Selected Row has status Locked: 
            //+ Unhide: tsbUnlock, tsbPrint
            //+ Hide: tsbLock, tsbUpdate            
            if (isLocked)
            {
                tsbUnlock.Visible = true;
                tsbPrint.Visible = true;
                tsbLock.Visible = false;
                tsbUpdate.Visible = false;
            }
            //- Selected Row has status Unlocked: 
            //+ Unhide: tsbLock, tsbUpdate
            //+ Hide: tsbUnlock, tsbPrint
            else
            {
                tsbUnlock.Visible = false;
                tsbPrint.Visible = false;
                tsbLock.Visible = true;
                tsbUpdate.Visible = true;
            }
        }

        /// <summary>
        /// Update Status Exchange Rate
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void UpdateStatusExchangeRate()
        {
            //Declaration
            NonResidentAppInformation objNonResidentAppInfo = new NonResidentAppInformation();

            //Get value of selected row
            int index = dtgMonthList.Rows.IndexOf(dtgMonthList.SelectedRows[0]);
            objNonResidentAppInfo.MonthYear = DateTime.Parse(dtgMonthList.Rows[index].Cells[m_colMonthYear].Value.ToString());
            objNonResidentAppInfo.LockStatus = dtgMonthList.Rows[index].Cells[m_colLockStatus].Value.ToString() == "0" ? "1" : "0";

            //Validation (Existing)            
            if (!lgExchangeRateBus.CheckExistingTransCurrency(objNonResidentAppInfo.MonthYear.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH)))
            {               
                clsLGMesageCollection.ShowMessage(1, String.Format(clsLGCommonMessage.FIELD_NOT_EXISTED, clsLGConstant.EXCHANGE_RATE_NAME + String.Format(" [{0}]", objNonResidentAppInfo.MonthYear.ToString(clsLGConstant.LG_FORMAT_STANDARD))));
                Search();
                return;
            }

            DialogResult result = clsLGMesageCollection.ShowMessage(3, String.Format(clsLGCommonMessage.CONFIRM_ACTION, dtgMonthList.Rows[index].Cells[m_colLockStatus].Value.ToString() == "0" ?
                                        clsLGConstant.ACTION_LOCK.ToLower() : clsLGConstant.ACTION_UNLOCK.ToLower(), clsLGConstant.EXCHANGE_RATE_NAME)); ;
            if (result == DialogResult.Yes)
            {
                bool isSuccess = false;
                isSuccess = lgExchangeRateBus.UpdateExchangeRate(objNonResidentAppInfo) != 0 ? true : false;
                if (isSuccess)
                {                    
                    //History Header
                    clsLGLogBase logBase = new clsLGLogBase();
                    logBase.ApplicationName = this.Text;
                    logBase.UserID = clsUserInfo.UserNo.ToString();
                    logBase.Action = (int)CommonValue.ActionType.Update;
                    logBase.Key = DateTime.Parse(dtgMonthList.Rows[index].Cells[m_colMonthYear].Value.ToString()).ToString(clsLGConstant.LG_FORMAT_MMM_yy);
                    //History Details
                    clsLGLogInformation logInfo = new clsLGLogInformation();
                    logInfo.FieldName = objNonResidentAppInfo.MonthYear.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH);
                    logInfo.OldValue = objNonResidentAppInfo.LockStatus == "0" ? "1" : "0";
                    logInfo.NewValue = objNonResidentAppInfo.LockStatus;
                    logBase.LstLogInformation.Add(logInfo);                    
                    //Write Log                    
                    logBase.WirteLog(lgExchangeRateBus.DAL);

                    //Commit data if successful
                    lgExchangeRateBus.Commit();
                    clsLGMesageCollection.ShowMessage(2, String.Format(clsLGCommonMessage.INFOR_ACTION_SUCCESS, dtgMonthList.Rows[index].Cells[m_colLockStatus].Value.ToString() == "0" ?
                                clsLGConstant.ACTION_LOCK : clsLGConstant.ACTION_UNLOCK, clsLGConstant.EXCHANGE_RATE_NAME));
                    Search();
                }
            }
        }

        /// <summary>
        /// Export to Word
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void ExportToWord(NonResidentAppInformation objNonResidentAppInfo)
        {            
            //Declaration            
            Hashtable htData = new Hashtable();

            _wordApplication = clsLGDocumentExporter.AppClass;

            _wordDocument = wordBase.CreateWordDoc(fileName, _wordApplication, false, projectName, templateName, clsLGCommonBus.Instance().GetServerDate());

            //Add Value
            htData.Add(fieldCompanyName, objNonResidentAppInfo.LstExchangeRateForReporting.FirstOrDefault().CompanyName);
            htData.Add(fieldMonth, objNonResidentAppInfo.MonthYear.ToString("MM"));
            htData.Add(fieldYear, objNonResidentAppInfo.MonthYear.ToString("yyyy"));
            htData.Add(fieldWithin_Sum_VND, objNonResidentAppInfo.LstExchangeRateForReporting.FirstOrDefault().Within_Sum_VND);
            htData.Add(fieldWithin_Sum_USD, objNonResidentAppInfo.LstExchangeRateForReporting.FirstOrDefault().Within_Sum_USD);
            htData.Add(fieldEnd_Sum_VND, objNonResidentAppInfo.LstExchangeRateForReporting.FirstOrDefault().End_Sum_VND);
            htData.Add(fieldEnd_Sum_USD, objNonResidentAppInfo.LstExchangeRateForReporting.FirstOrDefault().End_Sum_USD);

            if (_wordApplication != null && _wordDocument != null)
            {
                wordBase.FindReplace(_wordDocument, _wordApplication, htData);
            }                       
        }

        /// <summary>
        /// Override ProceeCmdKey
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                //+ [Update] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.U):
                    {
                        if (tsbUpdate.Visible == true)
                        {
                            tsbUpdate_Click(new object(), new EventArgs());                        
                        }
                        break;
                    }
                //+ [Print] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.P):
                    {
                        if (tsbPrint.Visible == true)
                        {
                            tsbPrint_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Lock] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.L):
                    {
                        if (tsbLock.Visible == true)
                        {
                            tsbLock_Click(new object(), new EventArgs());
                        }
                        break;
                    }
                //+ [Unlock] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.N):
                    {
                        if (tsbUnlock.Visible == true)
                        {
                            tsbUnlock_Click(new object(), new EventArgs());
                        }
                        break;
                    }                
            }

            return base.ProcessCmdKey(ref msg, keyData);                        
        }

        /// <summary>
        /// Processes a dialog box key.
        /// </summary>
        /// <param name="keyData"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        protected override bool ProcessDialogKey(Keys keyData)
        {
            switch (keyData)
            {
                //+ [Update] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.U):
                    {
                        break;
                    }
                //+ [Print] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.P):
                    {
                        break;
                    }
                //+ [Lock] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.L):
                    {
                        break;
                    }
                //+ [Unlock] Toolstrip ShortCut Key
                case (Keys.Alt | Keys.N):
                    {
                        break;
                    }
                default:
                    {
                        return base.ProcessDialogKey(keyData);
                    }
            }

            return true;
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                isLoading = false;
                Search();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Show form dialog to create applicant
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                frmLGCreateReportForNonResidentApplicantLG frm = new frmLGCreateReportForNonResidentApplicantLG();
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Show form update 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                //Get value of selected row
                int index = dtgMonthList.Rows.IndexOf(dtgMonthList.SelectedRows[0]);
                DateTime exchangeRateDate = DateTime.Parse(dtgMonthList.Rows[index].Cells[m_colMonthYear].Value.ToString());
                //Validation (Existing)            
                if (!lgExchangeRateBus.CheckExistingTransCurrency(exchangeRateDate.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH)))
                {
                    clsLGMesageCollection.ShowMessage(1, String.Format(clsLGCommonMessage.FIELD_NOT_EXISTED, clsLGConstant.EXCHANGE_RATE_NAME + String.Format(" [{0}]", exchangeRateDate.ToString(clsLGConstant.LG_FORMAT_STANDARD))));
                    Search();
                    return;
                }

                frmLGUpdateReportForNonResidentApplicantLG frm = new frmLGUpdateReportForNonResidentApplicantLG(exchangeRateDate);
                frm.StartPosition = FormStartPosition.CenterScreen;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    Search();
                }
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Lock
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbLock_Click(object sender, EventArgs e)
        {
            try
            {
                UpdateStatusExchangeRate();
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                try
                {
                    lgExchangeRateBus.RollBack();
                }
                catch (System.Exception) { } 

                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Unlock
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbUnlock_Click(object sender, EventArgs e)
        {
            try
            {
                UpdateStatusExchangeRate();
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                try
                {
                    lgExchangeRateBus.RollBack();
                }
                catch (System.Exception) { } 

                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Export
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void tsbPrint_Click(object sender, EventArgs e)
        {
            try
            {
                //Declaration
                NonResidentAppInformation objNonResidentAppInfo = new NonResidentAppInformation();
                //Get value of selected row
                int index = dtgMonthList.Rows.IndexOf(dtgMonthList.SelectedRows[0]);
                DateTime exchangeRateDate = DateTime.Parse(dtgMonthList.Rows[index].Cells[m_colMonthYear].Value.ToString());
                objNonResidentAppInfo.MonthYear = exchangeRateDate;
                //Validation (Existing)            
                if (!lgExchangeRateBus.CheckExistingTransCurrency(exchangeRateDate.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH)))
                {
                    clsLGMesageCollection.ShowMessage(1, String.Format(clsLGCommonMessage.FIELD_NOT_EXISTED, clsLGConstant.EXCHANGE_RATE_NAME + String.Format(" [{0}]", exchangeRateDate.ToString(clsLGConstant.LG_FORMAT_STANDARD))));
                    Search();
                    return;
                }

                lgExchangeRateBus.GetListExchangeRateForReporting(ref objNonResidentAppInfo);
                
                //Export                
                ExportToWord(objNonResidentAppInfo);
            }
            catch (Exception ex)
            {
                if (_wordDocument != null)
                {
                    wordBase.CloseWordDoc(_wordDocument, true);
                }
                if (_wordApplication != null)
                {
                    wordBase.CloseWordApp(_wordApplication);
                }

                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Selected changed event for Grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void dtgMonthList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                ShowHideToolStrip();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }
        #endregion
    }
}
