﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: htkhiem $
 * $Date: 2013-01-16 16:00:00 +0700 (Wed, 16 Jan 2013) $
 * $Revision: 5023 $ 
 * ========================================================
 * 
 * This class is used to create Exchange Rate
 * for LG module.
 */

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Config.Classes;
using Phoenix.Common.Functions;
using Phoenix.Common.Security.Com;
using Phoenix.Cpa.Bus;
using Phoenix.Lg.Com;
using Phoenix.Lg.Common;
using Phoenix.Lg.Dto;

namespace Phoenix.Lg.Gui.Forms
{
	public partial class frmLGCreateReportForNonResidentApplicantLG : frmLGMaster
    {
        #region Global Variable
        private clsLGReportForNonResidentAppBus lgExchangeRateBus = new clsLGReportForNonResidentAppBus();
        private clsLGCUReportForNonResidentAppDTO lgExchangeRateDTO = new clsLGCUReportForNonResidentAppDTO();

        //Used for checking changes
        private bool isChanged = false;

        //For Grid Exchange Rate
        //+ [colCurrency] Column
        private string m_colCurrency = "colCurrency";
        //+ [colExchangeRate] Column
        private string m_colExchangeRate = "colExchangeRate";

        // For Security Checking
        clsSEAuthorizer _security = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        public frmLGCreateReportForNonResidentApplicantLG()
        {
            try
            {
                InitializeComponent();
                // Check authorization
                _security = new clsSEAuthorizer(clsUserInfo.UserNo, this.Name);
                _security.CheckAuthorizationOnScreen(this);
                //Intialize
                Init();            
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }                        
        }
        #endregion

        #region Member Method
        /// <summary>
        /// Initialize
        /// </summary>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void Init()
        {
            SetFormStyleCommon();            
            //Not allow to generate columns automatically
            dtgCurrencyList.AutoGenerateColumns = false;       
            //Set value for monthYearfrom
            monthYearfrom.Value = DateTime.Today;            
        }

        /// <summary>
        /// Save Data
        /// </summary>
        /// <returns>Result</returns>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private bool Save()
        {
            //Declaration
            bool isError = false;            
            lgExchangeRateDTO = new clsLGCUReportForNonResidentAppDTO();
            int insertedRow = 0;
            //History List
            List<clsLGLogBase> lstLogBase = new List<clsLGLogBase>();

            //Assign Value
            lgExchangeRateDTO.MonthYear = monthYearfrom.Value;
            lgExchangeRateDTO.CreatedBy = clsUserInfo.UserNo.ToString();

            //Check validation
            if (lgExchangeRateBus.CheckExistingTransCurrency(monthYearfrom.Value.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH)))
            {
                isError = true;
                clsLGMesageCollection.ShowMessage(1, String.Format(clsLGCommonMessage.FIELD_EXISTED, clsLGConstant.EXCHANGE_RATE_NAME + String.Format(" [{0}]", monthYearfrom.Value.ToString(clsLGConstant.LG_FORMAT_STANDARD))));
            }

            //Saving data if no error
            if(!isError)
            {
                #region Process of Saving
                foreach (DataGridViewRow item in dtgCurrencyList.Rows)
                {
                    ExchangeRateInformation objExchangeRateInfo = new ExchangeRateInformation();
                    //History Header
                    clsLGLogBase logBase = new clsLGLogBase();
                    logBase.ApplicationName = this.Text;
                    logBase.UserID = clsUserInfo.UserNo.ToString();
                    logBase.Key = lgExchangeRateDTO.MonthYear.ToString(clsLGConstant.LG_FORMAT_YEAR_MONTH) + " " + item.Cells[m_colCurrency].Value.ToString();

                    //Assign value
                    objExchangeRateInfo.TransCurrency = item.Cells[m_colCurrency].Value.ToString().Trim();
                    objExchangeRateInfo.ExchangeRate = Decimal.Parse(item.Cells[m_colExchangeRate].Value.ToString().Trim());
                    objExchangeRateInfo.LockStatus = 0;
                    //Add list exchange rate
                    lgExchangeRateDTO.LstExchangeRateInformation.Add(objExchangeRateInfo);

                    //History Details
                    //+ Inserting Log                    
                    logBase.Action = (int)CommonValue.ActionType.New;
                    //+ [Exchange Rate (To USD)] Column                        
                    clsLGLogInformation logInfo = new clsLGLogInformation();
                    logInfo.FieldName = item.Cells[m_colExchangeRate].OwningColumn.HeaderText;
                    logInfo.OldValue = String.Empty;
                    logInfo.NewValue = item.Cells[m_colExchangeRate].FormattedValue.ToString();

                    logBase.LstLogInformation.Add(logInfo);
                    //Add to List of History
                    lstLogBase.Add(logBase);
                }
                insertedRow = lgExchangeRateBus.InsertExchangeRate(lgExchangeRateDTO);
                if (insertedRow != 0)
                {
                    isError = false;
                    //Write Log
                    foreach (clsLGLogBase logBase in lstLogBase)
                    {
                        logBase.WirteLog(lgExchangeRateBus.DAL);
                    }
                }
                else
                {
                    isError = true;
                }
                #endregion
            }
            return !isError;
        }
        #endregion

        #region Event Functions
        /// <summary>
        /// Process event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnProcess_Click(object sender, EventArgs e)
        {
            try
            {                                
                //Clear Grid
                dtgCurrencyList.Rows.Clear();
                //Declaration
                lgExchangeRateDTO = new clsLGCUReportForNonResidentAppDTO();             
                //Assign value from inputting
                lgExchangeRateDTO.MonthYear = monthYearfrom.Value;
                //Get data collection from database
                lgExchangeRateBus.GetListExchangeRateForCreating(ref lgExchangeRateDTO);
                //Set data collection to grid
                foreach (ExchangeRateInformation objExchangeRateInfo in lgExchangeRateDTO.LstExchangeRateInformation)
                {
                    dtgCurrencyList.Rows.Add(objExchangeRateInfo.TransCurrency, objExchangeRateInfo.ExchangeRate, objExchangeRateInfo.OldExchangeRate);
                }
                //Set currency format
                foreach (DataGridViewRow row in dtgCurrencyList.Rows)
                {
                    DataGridViewTextBoxCell currencyCell = (DataGridViewTextBoxCell)row.Cells[m_colCurrency];
                    UserCtrl.TNumEditDataGridViewCell exchangeRateCell = (UserCtrl.TNumEditDataGridViewCell)row.Cells[m_colExchangeRate];
                    if (currencyCell.Value.Equals(clsLGConstant.LG_CURRENCY_JPY))
                    {
                        exchangeRateCell.DecimalLength = 0;
                        exchangeRateCell.MaxInputLength = 7;
                    }
                }                
                //Reset controls
                btnSave.Enabled = true;
                isChanged = false;

                //No records
                if (lgExchangeRateDTO.LstExchangeRateInformation.Count == 0)
                {
                    clsLGMesageCollection.MessageNoTransactions();
                    btnSave.Enabled = false;                    
                }                
            }
            catch (Exception ex)
            {                
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }            
        }

        /// <summary>
        /// Event btnSave applicant to database
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = clsLGMesageCollection.ShowMessage(3, String.Format(clsLGCommonMessage.CONFIRM_ACTION, clsLGConstant.ACTION_SAVE, clsLGConstant.EXCHANGE_RATE_NAME)); ;
                if (result == DialogResult.Yes)
                {
                    bool isSuccess = false;
                    isSuccess = Save();
                    if (isSuccess)
                    {
                        //Commit data if successful
                        lgExchangeRateBus.Commit();
                        clsLGMesageCollection.ShowMessage(2, String.Format(clsLGCommonMessage.INFOR_ACTION_SUCCESS, clsLGConstant.ACTION_CREATE, clsLGConstant.EXCHANGE_RATE_NAME));
                        isChanged = false;
                        //Set Dialog Result
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                //Rollback if having errors
                try
                {
                    lgExchangeRateBus.RollBack();
                }
                catch (System.Exception){}                
                
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Event btnClose form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }

        /// <summary>
        /// Event frorm closing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void frmLGCreateUpdateReportForNonResidentApplicantLG_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    if (e.CloseReason == CloseReason.UserClosing && btnSave.Tag != null && (bool)btnSave.Tag == true)
                    {
                        if (isChanged)
                        {
                            DialogResult result = clsLGMesageCollection.ShowMessage(0, clsLGCommonMessage.CONFIRM_SAVE_CHANGES);
                            if (result == DialogResult.Yes)
                            {
                                bool isSuccess = false;
                                isSuccess = Save();
                                if (isSuccess)
                                {
                                    //Commit data if successful
                                    lgExchangeRateBus.Commit();
                                    clsLGMesageCollection.ShowMessage(2, String.Format(clsLGCommonMessage.INFOR_ACTION_SUCCESS, clsLGConstant.ACTION_CREATE, clsLGConstant.EXCHANGE_RATE_NAME));
                                    isChanged = false;
                                    //Set Dialog Result
                                    this.DialogResult = DialogResult.OK;
                                    e.Cancel = false;
                                }
                                else
                                {
                                    e.Cancel = true;
                                }
                            }
                            else if (result == DialogResult.No)
                            {
                                e.Cancel = false;
                            }
                            else if (result == DialogResult.Cancel)
                            {
                                e.Cancel = true;
                            }
                        }
                    }                    
                }
                else
                {
                    this.FormClosing -= new FormClosingEventHandler(frmLGCreateUpdateReportForNonResidentApplicantLG_FormClosing);
                    this.Close();
                }
            }
            catch (System.Exception ex)
            {
                //Rollback if having errors
                try
                {
                    lgExchangeRateBus.RollBack();
                }
                catch (System.Exception) { }   

                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
            }      
        }

        /// <summary>
        /// dtgCurrencyList_CellEndEdit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// @cond
        /// Author: Huynh Thien Khiem
        /// @endcond
        private void dtgCurrencyList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                isChanged = true;
            }
            catch (Exception ex)
            {
                clsLogFile.LogException(ex.Message,clsLGConstant.LG_MODULE);
                clsError.ShowErrorScreen(ex.Message + Environment.NewLine + ex.TargetSite, this);
            }
        }
        #endregion
	}
}