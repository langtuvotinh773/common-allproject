﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: HTKhiem $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define structure of DTO for Listing LG Staff
 * for LG module.
 */
using System;
using System.Collections.Generic;

namespace Phoenix.Lg.Dto
{
    public class clsLGListLGStaffDTO
    {
        #region Declaration
        //Header
        //Seaching Type: 0: General Search 
        //+ 1: General Search
        //+ 2: Overdue And Expire Within 7 Days (Current Date  - Expire Date >= -7)
        //+ 3: Charge Schedule (Having data in [Fee Collection Schedule] Table & ReceivedDate IS NULL)
        int searchingType = 0; //Default
        //+ LG No
        string lgNo = String.Empty;
        //+ Customer Code
        string customerCode = String.Empty;
        //+ Customer Name
        string customerName = String.Empty;
        //+ Security
        string security = String.Empty;
        //+ Booking purpose
        string bookingPurpose = String.Empty;
        //+ GL Code
        string glCode = String.Empty;
        //+ Currency
        string currency = String.Empty;
        //+ Claim
        string claim = String.Empty;
        //+ Input Date From
        DateTime inputDateFrom = new DateTime();
        //+ Input Date To
        DateTime inputDateTo = new DateTime();
        //+ Guarantee Type
        string guaranteeType = String.Empty;
        //+ Value Date From
        DateTime valueDateFrom = new DateTime();
        //+ Value Date To
        DateTime valueDateTo = new DateTime();
        //+ Expire Date From
        DateTime expireDateFrom = new DateTime();
        //+ Expire Date To
        DateTime expireDateTo = new DateTime();
        //+ Amount From
        string amountFrom = String.Empty;
        //+ Amount To
        string amountTo = String.Empty;

        //List Of LG Staff Information
        private List<LGStaffInformation> lstLGStaffInformation = new List<LGStaffInformation>();
        #endregion

        #region Properties
        //Header
        //Seaching Type: 0: General Search
        //+ 1: Overdue And Expire Within 7 Days 
        //+ 2: Charge Schedule
        //+ 3: Charge Schedule
        public int SearchingType
        {
            get 
            { 
                return searchingType; 
            }
            set 
            { 
                searchingType = value; 
            }
        }
        //+ LG No        
        public string LGNo
        {
            get 
            { 
                return lgNo; 
            }
            set 
            { 
                lgNo = value; 
            }
        }
        //+ Customer Code        
        public string CustomerCode
        {
            get 
            { 
                return customerCode; 
            }
            set 
            { 
                customerCode = value; 
            }
        }
        //+ Customer Name        
        public string CustomerName
        {
            get 
            { 
                return customerName; 
            }
            set 
            { 
                customerName = value; 
            }
        }
        //+ Security        
        public string Security
        {
            get 
            { 
                return security; 
            }
            set 
            { 
                security = value; 
            }
        }
        //+ Booking purpose        
        public string BookingPurpose
        {
            get 
            { 
                return bookingPurpose; 
            }
            set 
            { 
                bookingPurpose = value; 
            }
        }
        //+ GL Code        
        public string GLCode
        {
            get 
            { 
                return glCode; 
            }
            set 
            { 
                glCode = value; 
            }
        }
        //+ Currency        
        public string Currency
        {
            get 
            { 
                return currency; 
            }
            set 
            { 
                currency = value; 
            }
        }
        //+ Claim        
        public string Claim
        {
            get 
            { 
                return claim; 
            }
            set 
            { 
                claim = value; 
            }
        }
        //+ Input Date From        
        public DateTime InputDateFrom
        {
            get 
            { 
                return inputDateFrom; 
            }
            set 
            { 
                inputDateFrom = value; 
            }
        }
        //+ Input Date To        
        public DateTime InputDateTo
        {
            get 
            { 
                return inputDateTo; 
            }
            set 
            { 
                inputDateTo = value; 
            }
        }
        //+ Guarantee Type
        public string GuaranteeType
        {
            get 
            { 
                return guaranteeType; 
            }
            set 
            { 
                guaranteeType = value; 
            }
        }
        //+ Value Date From        
        public DateTime ValueDateFrom
        {
            get 
            { 
                return valueDateFrom; 
            }
            set 
            { 
                valueDateFrom = value; 
            }
        }
        //+ Value Date To        
        public DateTime ValueDateTo
        {
            get 
            { 
                return valueDateTo; 
            }
            set 
            { 
                valueDateTo = value; 
            }
        }
        //+ Expire Date From        
        public DateTime ExpireDateFrom
        {
            get 
            { 
                return expireDateFrom; 
            }
            set 
            { 
                expireDateFrom = value; 
            }
        }
        //+ Expire Date To        
        public DateTime ExpireDateTo
        {
            get 
            { 
                return expireDateTo; 
            }
            set 
            { 
                expireDateTo = value; 
            }
        }
        //+ Amount From        
        public string AmountFrom
        {
            get 
            { 
                return amountFrom; 
            }
            set 
            { 
                amountFrom = value; 
            }
        }
        //+ Amount To        
        public string AmountTo
        {
            get 
            { 
                return amountTo; 
            }
            set 
            { 
                amountTo = value; 
            }
        }

        //List Of LG Staff Information
        public List<LGStaffInformation> LstLGStaffInformation
        {
            get 
            { 
                return lstLGStaffInformation; 
            }
            set 
            { 
                lstLGStaffInformation = value; 
            }
        }
        #endregion
    }

    //LG Staff Information
    public class LGStaffInformation
    {
        #region Declaration
        //+ Sequence
        string seqLG = String.Empty;
        //+ LG No
        string lgNo = String.Empty;
        //+ Previous LG No
        string previousLGNo = String.Empty;
        //+ Type
        string type = String.Empty;
        //+ Input Date
        DateTime inputDate = new DateTime();
        //+ Value Date
        DateTime valueDate = new DateTime();
        //+ Back Value
        string backValue = String.Empty;
        //+ Customer Code
        string customerCode = String.Empty;
        //+ Customer Name
        string customerName = String.Empty;
        //+ GL Code
        string glCode = String.Empty;
        //+ Claim
        string claim = String.Empty;
        //+ Fee Rate(%)
        decimal feeRate = 0;
        //+ Min
        decimal min = 0;
        //+ Min CCY
        string minCCY = String.Empty;
        //+ Expiry Date
        DateTime expiryDate = new DateTime();
        //+ Guarantee Type
        string guaranteeType = String.Empty;
        //+ Sequence Beneficiary
        string seqBeneficiary = String.Empty;
        //+ Beneficiary Name
        string beneficiaryName = String.Empty;
        //+ Trans Currency
        string transCurrency = String.Empty;
        //+ Charge Account
        string chargeAccount = String.Empty;
        //+ Guarantee Amount
        decimal guaranteeAmount = 0;
        //+ Fee
        decimal fee = 0;
        //+ Fee Currency
        string feeCurrency = String.Empty;
        //+ MultiTimesFee
        string multiTimesFee = String.Empty;
        //+ Overdue Fee
        decimal overdueFee = 0;
        //+ Overdue Fee Currency
        string overdueFeeCurrency = String.Empty;        
        //+ Overdue Claim Fee
        decimal overdueClaimFee = 0;
        //+ Overdue Claim Fee Currency
        string overdueClaimFeeCurrency = String.Empty;
        //+ Report to SBV
        string reportToSBV = String.Empty;
        //2013.05.09 ADD HTK S Smile Interface
        //+ Reported (SMILE)
        string exportedSmile = String.Empty;
        //+ Remark
        string remark = String.Empty;
        //2013.05.09 ADD HTK E Smile Interface
        //+ LG Return Flag
        string lgReturn = String.Empty;        
        #endregion

        #region Properties
        //+ Sequence
        public string SeqLG
        {
            get 
            { 
                return seqLG; 
            }
            set 
            { 
                seqLG = value; 
            }
        }
        //+ LG No        
        public string LGNo
        {
            get 
            { 
                return lgNo; 
            }
            set 
            { 
                lgNo = value; 
            }
        }
        //+ Previous LG No        
        public string PreviousLGNo
        {
            get 
            { 
                return previousLGNo; 
            }
            set 
            { 
                previousLGNo = value; 
            }
        }
        //+ Type        
        public string Type
        {
            get 
            { 
                return type; 
            }
            set 
            { 
                type = value; 
            }
        }
        //+ Input Date        
        public DateTime InputDate
        {
            get 
            { 
                return inputDate; 
            }
            set
            { 
                inputDate = value; 
            }
        }
        //+ Value Date        
        public DateTime ValueDate
        {
            get 
            { 
                return valueDate; 
            }
            set 
            { 
                valueDate = value; 
            }
        }
        //+ Back Value        
        public string BackValue
        {
            get 
            { 
                return backValue; 
            }
            set 
            { 
                backValue = value; 
            }
        }
        //+ Customer Code        
        public string CustomerCode
        {
            get 
            { 
                return customerCode; 
            }
            set 
            { 
                customerCode = value; 
            }
        }
        //+ Customer Name        
        public string CustomerName
        {
            get 
            { 
                return customerName; 
            }
            set 
            { 
                customerName = value; 
            }
        }
        //+ GL Code        
        public string GLCode
        {
            get 
            { 
                return glCode; 
            }
            set 
            { 
                glCode = value; 
            }
        }
        //+ Claim        
        public string Claim
        {
            get 
            { 
                return claim; 
            }
            set 
            { 
                claim = value; 
            }
        }
        //+ Fee Rate(%)        
        public decimal FeeRate
        {
            get 
            { 
                return feeRate; 
            }
            set 
            { 
                feeRate = value; 
            }
        }
        //+ Min        
        public decimal Min
        {
            get 
            { 
                return min; 
            }
            set
            {
                min = value; 
            }
        }
        //+ Min CCY        
        public string MinCCY
        {
            get 
            { 
                return minCCY; 
            }
            set 
            { 
                minCCY = value; 
            }
        }
        //+ Expiry Date        
        public DateTime ExpiryDate
        {
            get 
            { 
                return expiryDate; 
            }
            set 
            { 
                expiryDate = value; 
            }
        }
        //+ Guarantee Type        
        public string GuaranteeType
        {
            get 
            { 
                return guaranteeType; 
            }
            set 
            { 
                guaranteeType = value; 
            }
        }
        //+ Sequence Beneficiary        
        public string SeqBeneficiary
        {
            get 
            { 
                return seqBeneficiary; 
            }
            set 
            { 
                seqBeneficiary = value; 
            }
        }
        //+ Beneficiary Name        
        public string BeneficiaryName
        {
            get 
            { 
                return beneficiaryName; 
            }
            set 
            { 
                beneficiaryName = value; 
            }
        }
        //+ CCY        
        public string TransCurrency
        {
            get 
            {
                return transCurrency; 
            }
            set 
            {
                transCurrency = value; 
            }
        }
        //+ Charge Account        
        public string ChargeAccount
        {
            get 
            { 
                return chargeAccount; 
            }
            set 
            { 
                chargeAccount = value; 
            }
        }
        //+ Guarantee Amount        
        public decimal GuaranteeAmount
        {
            get 
            { 
                return guaranteeAmount; 
            }
            set 
            { 
                guaranteeAmount = value; 
            }
        }
        //+ Fee        
        public decimal Fee
        {
            get 
            { 
                return fee; 
            }
            set 
            { 
                fee = value; 
            }
        }
        //+ Fee Currency
        public string FeeCurrency
        {
            get 
            { 
                return feeCurrency; 
            }
            set 
            { 
                feeCurrency = value; 
            }
        }
        //+ MultiTimesFee
        public string MultiTimesFee
        {
            get
            {
                return multiTimesFee;
            }
            set
            {
                multiTimesFee = value;
            }
        }
        //+ Overdue Fee        
        public decimal OverdueFee
        {
            get 
            { 
                return overdueFee; 
            }
            set 
            { 
                overdueFee = value; 
            }
        }
        //+ Overdue Fee Currency
        public string OverdueFeeCurrency
        {
            get 
            { 
                return overdueFeeCurrency; 
            }
            set 
            { 
                overdueFeeCurrency = value; 
            }
        }
        //+ Overdue Claim Fee        
        public decimal OverdueClaimFee
        {
            get 
            { 
                return overdueClaimFee; 
            }
            set 
            { 
                overdueClaimFee = value; 
            }
        }
        //+ Overdue Claim Fee Currency
        public string OverdueClaimFeeCurrency
        {
            get 
            { 
                return  overdueClaimFeeCurrency; 
            }
            set 
            { 
                overdueClaimFeeCurrency = value;
            }
        }
        //+ Report to SBV        
        public string ReportToSBV
        {
            get 
            { 
                return reportToSBV; 
            }
            set 
            { 
                reportToSBV = value; 
            }
        }
        //2013.05.09 ADD HTK S Smile Interface
        //+ Exported Smile
        public string ExportedSmile
        {
            get 
            { 
                return exportedSmile; 
            }
            set 
            { 
                exportedSmile = value; 
            }
        }
        //+ Remark
        public string Remark
        {
            get 
            { 
                return remark; 
            }
            set 
            { 
                remark = value; 
            }
        }
        //2013.05.09 ADD HTK E Smile Interface
        //+ LG Return
        public string LGReturn
        {
            get 
            { 
                return lgReturn; 
            }
            set 
            { 
                lgReturn = value; 
            }
        }
        #endregion        
    }
}
