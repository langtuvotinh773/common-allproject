﻿using System;
using System.Data;

namespace Phoenix.Lg.Dto
{
    public class clsLGDetailDTO
    {
        Int64 seqLG;

        public Int64 SeqLG
        {
            get { return seqLG; }
            set { seqLG = value; }
        }
        string subCode;

        public string SubCode
        {
            get { return subCode; }
            set { subCode = value; }
        }
        byte flagControlbook;

        public byte FlagControlbook
        {
            get { return flagControlbook; }
            set { flagControlbook = value; }
        }
        string preSubCode;

        public string PreSubCode
        {
            get { return preSubCode; }
            set { preSubCode = value; }
        }
        string transCurrency;

        public string TransCurrency
        {
            get { return transCurrency; }
            set { transCurrency = value; }
        }
        decimal transAmount;

        public decimal TransAmount
        {
            get { return transAmount; }
            set { transAmount = value; }
        }
        bool transientAccount;

        public bool TransientAccount
        {
            get { return transientAccount; }
            set { transientAccount = value; }
        }
        string chargeCurrency;

        public string ChargeCurrency
        {
            get { return chargeCurrency; }
            set { chargeCurrency = value; }
        }
        string chargeAccount;

        public string ChargeAccount
        {
            get { return chargeAccount; }
            set { chargeAccount = value; }
        }
        decimal fee;

        public decimal Fee
        {
            get { return fee; }
            set { fee = value; }
        }
        string feeCurrency;

        public string FeeCurrency
        {
            get { return feeCurrency; }
            set { feeCurrency = value; }
        }
        DateTime actualCollectionDate;

        public DateTime ActualCollectionDate
        {
            get { return actualCollectionDate; }
            set { actualCollectionDate = value; }
        }
        byte importNew;

        public byte ImportNew
        {
            get { return importNew; }
            set { importNew = value; }
        }
        byte resultNew;

        public byte ResultNew
        {
            get { return resultNew; }
            set { resultNew = value; }
        }
        byte importGenera;

        public byte ImportGenera
        {
            get { return importGenera; }
            set { importGenera = value; }
        }
        byte resultGenera;

        public byte ResultGenera
        {
            get { return resultGenera; }
            set { resultGenera = value; }
        }
        byte numTerminate;

        public byte NumTerminate
        {
            get { return numTerminate; }
            set { numTerminate = value; }
        }
        byte resultTerminate;

        public byte ResultTerminate
        {
            get { return resultTerminate; }
            set { resultTerminate = value; }
        }
        public clsLGDetailDTO(DataRow row)
        {
             seqLG = (Int64)row["SeqLG"];
             subCode= (string)row["SubCode"];
             flagControlbook= (byte)row["FlagControlBook"];
             preSubCode = row["PreSubCode"] == DBNull.Value ? "" : (string)row["PreSubCode"];
             transCurrency= (string)row["TransCurrency"];
             transAmount= (decimal)row["TransAmount"];
             transientAccount= (bool)row["TransientAccount"];
             chargeCurrency= (string)row["ChargeCurrency"];
             chargeAccount= ((string)row["ChargeAccount"]).Trim();
             fee = row["Fee"] == DBNull.Value ? 0: (decimal)row["Fee"];
             feeCurrency = row["FeeCurrency"] == DBNull.Value ? "" : (string)row["FeeCurrency"];
             try
             {
                 actualCollectionDate = (DateTime)row["ActualCollectionDate"];
             }
             catch
             {
             }

             importNew = row["NumImportSmileNewLG"] == DBNull.Value ? (byte)0 : (byte)row["NumImportSmileNewLG"];
             resultNew = row["ResultImportSmileNewLG"] == DBNull.Value ? (byte)0 : (byte)row["ResultImportSmileNewLG"];
             importGenera = row["NumImportSmileGeneralTransfer"] == DBNull.Value ? (byte)0 : (byte)row["NumImportSmileGeneralTransfer"];
             resultGenera = row["ResultImportSmileGeneralTransfer"] == DBNull.Value ? (byte)0 : (byte)row["ResultImportSmileGeneralTransfer"];
             numTerminate = row["NumImportSmileTerminate"] == DBNull.Value ? (byte)0 : (byte)row["NumImportSmileTerminate"];
             resultTerminate = row["ResultImportSmileTerminate"] == DBNull.Value ? (byte)0 : (byte)row["ResultImportSmileTerminate"];
             

        }
    }
}
