﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for Applicant
 * for LG module.
 */
using System;
using System.Data;
using Phoenix.Lg.Com;

namespace Phoenix.Lg.Dto
{
	public class clsLGFeeCollectionDTO
	{
        private string m_CustomerCode;
        private string m_CustomerName;
        private string m_LGNo;
        private string m_FeeType;
        private Decimal m_Fee;
        private string m_FeeCurrency;
        private string m_FeeFormatCurrency;
        private string m_ReceivedDate;
        
        public string CustomerCode
        {
            get { return m_CustomerCode; }
            set { m_CustomerCode = value; }
        }

        public string CustomerName
        {
            get { return m_CustomerName; }
            set { m_CustomerName = value; }
        }

        public string LGNo
        {
            get { return m_LGNo; }
            set { m_LGNo = value; }
        }

        public string FeeType
        {
            get { return m_FeeType; }
            set { m_FeeType = value; }
        }

        public Decimal Fee
        {
            get { return m_Fee; }
            set { m_Fee = value; }
        }

        public string FeeFormatCurrency
        {
            get { return m_FeeFormatCurrency; }
            set { m_FeeFormatCurrency = value; }
        }

        public string FeeCurrency
        {
            get { return m_FeeCurrency; }
            set { m_FeeCurrency = value; }
        }

        public string ReceivedDate
        {
            get { return m_ReceivedDate; }
            set { m_ReceivedDate = value; }
        }

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsLGFeeCollectionDTO()
		{
			
		}

        /// <summary>
        /// Get Applicant for search
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond 
        public clsLGFeeCollectionDTO GetFeeCollectionForSearch(DataRow row)
        {
            this.CustomerCode = row["CustomerCode"].GetType() == typeof(DBNull) ? "" : ((string)row["CustomerCode"]).Trim();
            this.CustomerName = row["CustomerName"].GetType() == typeof(DBNull) ? "" : ((string)row["CustomerName"]).Trim();
            this.LGNo = row["LGNo"].GetType() == typeof(DBNull) ? "" : ((string)row["LGNo"]).Trim();
            this.FeeType = row["FeeType"].GetType() == typeof(DBNull) ? "" : ((int)row["FeeType"]).ToString().Trim();
            this.Fee = row["Fee"].GetType() == typeof(DBNull) ? 0 : Decimal.Parse((row["Fee"].ToString()));
            this.FeeCurrency = row["FeeCurrency"].GetType() == typeof(DBNull) ? "" : ((string)row["FeeCurrency"]).Trim();
            if (this.FeeCurrency.Equals(clsLGConstant.LG_CURRENCY_VND) || this.FeeCurrency.Equals(clsLGConstant.LG_CURRENCY_JPY))
            {
                this.FeeFormatCurrency = this.Fee.ToString(clsLGConstant.FORMAT_NUMBER_N);
            }
            else
            {
                this.FeeFormatCurrency = this.Fee.ToString(clsLGConstant.FORMAT_NUMBER_N2);
            }
            this.ReceivedDate = row["ReceivedDate"].GetType() == typeof(DBNull) ? "" : ((DateTime)row["ReceivedDate"]).ToString(clsLGConstant.LG_FORMAT_YYYYMMDD);
            return this;
        }


	}
}