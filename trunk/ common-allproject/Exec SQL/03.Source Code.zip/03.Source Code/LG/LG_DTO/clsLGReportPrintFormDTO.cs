﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phuong Lap Co $
 * $Date: 2013-03-29 $
 * $Revision: $ 
 * ========================================================
 * This class is used to define structure of DTO for report PERFORMANCE GUARANTEE FINAL 02.06.05
 * for LG module.
 */
using System;
using System.Data;
using Phoenix.Lg.Com;

namespace Phoenix.Lg.Dto
{
    public class clsLGReportPrintFormDTO
    {
        private string m_ApplicantName;
        private string m_ApplicantAddress;
        private string m_ApplicantNational;
        private string m_ApplicantTel;
        private string m_ApplicantFax;
        private string m_BeneficiaryName;
        private string m_BeneficiaryAddress;
        private string m_BeneficiaryNational;
        private string m_BeneficiaryTel;
        private string m_BeneficiaryFax;
        private string m_TransCurrency;
        private Decimal m_TransAmount;
        private DateTime m_ValueDate;
        private DateTime m_ExpireDate;
        private string m_TransAmountFormat;
        private string m_GuaranteeType;
        private string m_GuaranteeTypeName;
        private string m_ContractInformation;
        private int m_LGStatus;
        private string m_LGCode;
        private string m_SubCode;
        private string m_LGNo;
        private string m_Representation1;
        private string m_Representation2;
        private string m_Representation3;
        private string m_CustomerName;
        private string m_CustomerAddress;
        private int m_NumReportSBV;
        
        public string ApplicantName
        {
            get { return m_ApplicantName; }
            set { m_ApplicantName = value; }
        }

        public string ApplicantAddress
        {
            get { return m_ApplicantAddress; }
            set { m_ApplicantAddress = value; }
        }

        public string ApplicantNational
        {
            get { return m_ApplicantNational; }
            set { m_ApplicantNational = value; }
        }

        public string ApplicantTel
        {
            get { return m_ApplicantTel; }
            set { m_ApplicantTel = value; }
        }

        public string ApplicantFax
        {
            get { return m_ApplicantFax; }
            set { m_ApplicantFax = value; }
        }

        public string BeneficiaryName
        {
            get { return m_BeneficiaryName; }
            set { m_BeneficiaryName = value; }
        }

        public string BeneficiaryAddress
        {
            get { return m_BeneficiaryAddress; }
            set { m_BeneficiaryAddress = value; }
        }

        public string BeneficiaryNational
        {
            get { return m_BeneficiaryNational; }
            set { m_BeneficiaryNational = value; }
        }

        public string BeneficiaryTel
        {
            get { return m_BeneficiaryTel; }
            set { m_BeneficiaryTel = value; }
        }

        public string BeneficiaryFax
        {
            get { return m_BeneficiaryFax; }
            set { m_BeneficiaryFax = value; }
        }

        public string TransCurrency
        {
            get { return m_TransCurrency; }
            set { m_TransCurrency = value; }
        }

        public Decimal TransAmount
        {
            get { return m_TransAmount; }
            set { m_TransAmount = value; }
        }

        public DateTime ValueDate
        {
            get { return m_ValueDate; }
            set { m_ValueDate = value; }
        }

        public DateTime ExpireDate
        {
            get { return m_ExpireDate; }
            set { m_ExpireDate = value; }
        }

        public string TransAmountFormat
        {
            get { return m_TransAmountFormat; }
            set { m_TransAmountFormat = value; }
        }

        public string GuaranteeType
        {
            get { return m_GuaranteeType; }
            set { m_GuaranteeType = value; }
        }

        public string GuaranteeTypeName
        {
            get { return m_GuaranteeTypeName; }
            set { m_GuaranteeTypeName = value; }
        }

        public string ContractInformation
        {
            get { return m_ContractInformation; }
            set { m_ContractInformation = value; }
        }

        public int LGStatus
        {
            get { return m_LGStatus; }
            set { m_LGStatus = value; }
        }

        public string LGCode
        {
            get { return m_LGCode; }
            set { m_LGCode = value; }
        }

        public string SubCode
        {
            get { return m_SubCode; }
            set { m_SubCode = value; }
        }

        public string LGNo
        {
            get { return m_LGNo; }
            set { m_LGNo = value; }
        }

        public string Representation1
        {
            get { return m_Representation1; }
            set { m_Representation1 = value; }
        }

        public string Representation2
        {
            get { return m_Representation2; }
            set { m_Representation2 = value; }
        }

        public string Representation3
        {
            get { return m_Representation3; }
            set { m_Representation3 = value; }
        }

        public string CustomerName
        {
            get { return m_CustomerName; }
            set { m_CustomerName = value; }
        }

        public string CustomerAddress
        {
            get { return m_CustomerAddress; }
            set { m_CustomerAddress = value; }
        }

        public int NumReportSBV
        {
            get { return m_NumReportSBV; }
            set { m_NumReportSBV = value; }
        }

        public clsLGReportPrintFormDTO()
        {

        }

        /// <summary>
        /// Get report print form
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public clsLGReportPrintFormDTO GetReportPrintFormDto(DataRow row)
        {
            this.BeneficiaryName = row["BeneficiaryName"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryName"]).Trim();
            this.ApplicantName = row["ApplicantName"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantName"]).Trim();
            this.BeneficiaryAddress = row["BeneficiaryAddress"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryAddress"]).Trim();
            this.TransCurrency = row["TransCurrency"].GetType() == typeof(DBNull) ? "" : ((string)row["TransCurrency"]).Trim();
            this.TransAmount = row["TransAmount"].GetType() == typeof(DBNull) ? 0 : ((Decimal)row["TransAmount"]);
            this.ValueDate = row["ValueDate"].GetType() == typeof(DBNull) ? DateTime.MinValue : (DateTime)row["ValueDate"];
            this.ExpireDate = row["ExpireDate"].GetType() == typeof(DBNull) ? DateTime.MinValue : (DateTime)row["ExpireDate"];
            if (this.TransCurrency.Equals(clsLGConstant.LG_CURRENCY_VND) || this.TransCurrency.Equals(clsLGConstant.LG_CURRENCY_JPY))
            {
                this.TransAmountFormat = this.TransAmount.ToString(clsLGConstant.FORMAT_NUMBER_N);
            }
            else
            {
                this.TransAmountFormat = this.TransAmount.ToString(clsLGConstant.FORMAT_NUMBER_N2);
            }
            this.GuaranteeType = row["GuaranteeType"].GetType() == typeof(DBNull) ? "" : ((string)row["GuaranteeType"]).Trim();
            this.LGCode = row["LGCode"].GetType() == typeof(DBNull) ? "" : ((string)row["LGCode"]).Trim();
            this.SubCode = row["SubCode"].GetType() == typeof(DBNull) ? "" : ((string)row["SubCode"]).Trim();
            this.Representation1 = row["Representation1"].GetType() == typeof(DBNull) ? "" : ((string)row["Representation1"]).Trim();
            this.Representation2 = row["Representation2"].GetType() == typeof(DBNull) ? "" : ((string)row["Representation2"]).Trim();
            this.Representation3 = row["Representation3"].GetType() == typeof(DBNull) ? "" : ((string)row["Representation3"]).Trim();

            //2013.05.22 ADD HTK S Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7
            this.ContractInformation = row["ContractInformation"].GetType() == typeof(DBNull) ? "" : ((string)row["ContractInformation"]).Trim();
            this.CustomerName = row["CustomerName"].GetType() == typeof(DBNull) ? "" : ((string)row["CustomerName"]).Trim();
            //2013.05.22 ADD HTK E Fix bug [Phoenix-LG-BugsTrackingList-ver_2 2.xls] No.7

            /*
             * 1. Another case
             * "640LG" + Guarantee Type (abbriviation BB(651), PB(741),RF(771))+ Tran No ( Ref code only)
             * Ex: 640LG BB 100001-00
             * 2. CB(781)
             * "LG" + Tran No ( Ref code only)
             * Ex: LG 100002-00
             * 
             */
            if (this.GuaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_CB))
            {
                this.LGNo = clsLGConstant.LG_MODULE + this.LGCode + "-" + this.SubCode;
            }
            else
            {
                if (this.GuaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_BB))
                {
                    this.LGNo = "640" + clsLGConstant.LG_MODULE + clsLGConstant.GUARANTEE_NAME_BB + this.LGCode + "-" + this.SubCode;
                }
                else if (this.GuaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_PB))
                {
                    this.LGNo = "640" + clsLGConstant.LG_MODULE + clsLGConstant.GUARANTEE_NAME_PB + this.LGCode + "-" + this.SubCode;
                }
                else if (this.GuaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_RF))
                {
                    this.LGNo = "640" + clsLGConstant.LG_MODULE + clsLGConstant.GUARANTEE_NAME_RF + this.LGCode + "-" + this.SubCode;
                }
            }

            return this;
        }

        /// <summary>
        /// Get report print form SBV File
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public clsLGReportPrintFormDTO GetReportPrintFormDtoForReportSBV(DataRow row)
        {
            this.Representation1 = row["Representation1"].GetType() == typeof(DBNull) ? "" : ((string)row["Representation1"]).Trim();
            this.Representation2 = row["Representation2"].GetType() == typeof(DBNull) ? "" : ((string)row["Representation2"]).Trim();
            this.Representation3 = row["Representation3"].GetType() == typeof(DBNull) ? "" : ((string)row["Representation3"]).Trim();
            this.ApplicantName = row["ApplicantName"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantName"]).Trim();
            this.ApplicantAddress = row["ApplicantAddress"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantAddress"]).Trim();
            this.ApplicantNational = row["ApplicantNational"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantNational"]).Trim();
            this.ApplicantTel = row["ApplicantTel"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantTel"]).Trim();
            this.ApplicantFax = row["ApplicantFax"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantFax"]).Trim();
            this.BeneficiaryName = row["BeneficiaryName"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryName"]).Trim();
            this.BeneficiaryAddress = row["BeneficiaryAddress"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryAddress"]).Trim();
            this.BeneficiaryNational = row["BeneficiaryNational"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryNational"]).Trim();
            this.BeneficiaryTel = row["BeneficiaryTel"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryTel"]).Trim();
            this.BeneficiaryFax = row["BeneficiaryFax"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryFax"]).Trim();
            this.TransCurrency = row["TransCurrency"].GetType() == typeof(DBNull) ? "" : ((string)row["TransCurrency"]).Trim();
            this.TransAmount = row["TransAmount"].GetType() == typeof(DBNull) ? 0 : ((Decimal)row["TransAmount"]);
            this.ValueDate = row["ValueDate"].GetType() == typeof(DBNull) ? DateTime.MinValue : (DateTime)row["ValueDate"];
            this.ExpireDate = row["ExpireDate"].GetType() == typeof(DBNull) ? DateTime.MinValue : (DateTime)row["ExpireDate"];
            if (this.TransCurrency.Equals(clsLGConstant.LG_CURRENCY_VND) || this.TransCurrency.Equals(clsLGConstant.LG_CURRENCY_JPY))
            {
                this.TransAmountFormat = this.TransAmount.ToString(clsLGConstant.FORMAT_NUMBER_N);
            }
            else
            {
                this.TransAmountFormat = this.TransAmount.ToString(clsLGConstant.FORMAT_NUMBER_N2);
            }
            this.CustomerName = row["CustomerName"].GetType() == typeof(DBNull) ? "" : ((string)row["CustomerName"]).Trim();
            this.CustomerAddress = row["CustomerAddress"].GetType() == typeof(DBNull) ? "" : ((string)row["CustomerAddress"]).Trim();
            this.GuaranteeType = row["GuaranteeType"].GetType() == typeof(DBNull) ? "" : ((string)row["GuaranteeType"]).Trim();
            this.ContractInformation = row["ContractInformation"].GetType() == typeof(DBNull) ? "" : ((string)row["ContractInformation"]).Trim();
            this.LGStatus = row["LGStatus"].GetType() == typeof(DBNull) ? 0 : ((byte)row["LGStatus"]);
            this.LGCode = row["LGCode"].GetType() == typeof(DBNull) ? "" : ((string)row["LGCode"]).Trim();
            this.SubCode = row["SubCode"].GetType() == typeof(DBNull) ? "" : ((string)row["SubCode"]).Trim();
            this.LGNo = this.LGCode + "-" + this.SubCode;
            if (this.GuaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_CB))
            {
                this.GuaranteeTypeName = clsLGConstant.GUARANTEE_NAME_CB;
            }
            else if (this.GuaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_BB))
            {
                this.GuaranteeTypeName = clsLGConstant.GUARANTEE_NAME_BB;
            }
            else if (this.GuaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_PB))
            {
                this.GuaranteeTypeName = clsLGConstant.GUARANTEE_NAME_PB;
            }
            else if (this.GuaranteeType.Equals(clsLGConstant.GUARANTEE_VALUE_RF))
            {
                this.GuaranteeTypeName = clsLGConstant.GUARANTEE_NAME_RF;
            }
            this.NumReportSBV = row["NumReportSBV"].GetType() == typeof(DBNull) ? 0 : ((byte)row["NumReportSBV"]);
            return this;
        }
    }
}
