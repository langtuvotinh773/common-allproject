﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-23 9:37:30 +0700 (Sun, 23 mar 2013) $
 * $Revision: 11465 $ 
 * ========================================================
 * This class is used to create Overdue Schedule DTO
 * in LG module.
 */
using System;
using System.Data;
using Config.Classes;


namespace Phoenix.Lg.Dto
{
    public class clsLGFeeScheduleDTO
    {
        Int64 seqLG;

        public Int64 SeqLG
        {
            get { return seqLG; }
            set { seqLG = value; }
        }
        string refNo;

        public string RefNo
        {
            get { return refNo; }
            set { refNo = value; }
        }
        string subID;

        public string SubID
        {
            get { return subID; }
            set { subID = value; }
        }
        int no;

        public int No
        {
            get { return no; }
            set { no = value; }
        }
        DateTime claimedDate;

        public DateTime ClaimedDate
        {
            get { return claimedDate; }
            set { claimedDate = value; }
        }
        DateTime actualClaimedDatel;

        public DateTime ActualClaimedDate
        {
            get { return actualClaimedDatel; }
            set { actualClaimedDatel = value; }
        }
        DateTime receivedDate;

        public DateTime ReceivedDate
        {
            get { return receivedDate; }
            set { receivedDate = value; }
        }
        decimal suggessedFee;

        public decimal SuggessedFee
        {
            get { return suggessedFee; }
            set { suggessedFee = value; }
        }
        string principalCCY;

        public string PrincipalCCY
        {
            get { return principalCCY; }
            set { principalCCY = value; }
        }
        string chargeCCY;

        public string ChargeCCY
        {
            get { return chargeCCY; }
            set { chargeCCY = value; }
        }
        decimal exchangeRate;

        public decimal ExchangeRate
        {
            get { return exchangeRate; }
            set { exchangeRate = value; }
        }
        decimal fee;

        public decimal Fee
        {
            get { return fee; }
            set { fee = value; }
        }
        CommonValue.ActionType type;

        private int isExist;

        public int IsExist
        {
            get { return isExist; }
            set { isExist = value; }
        }

        private int isChange;

        public int IsChange
        {
            get { return isChange; }
            set { isChange = value; }
        }

        private int isDelete;

        public int IsDelete
        {
            get { return isDelete; }
            set { isDelete = value; }
        }

        public CommonValue.ActionType Type
        {
            get { return type; }
            set { type = value; }
        }

        int oldSubNo;

        public int OldSubNo
        {
            get { return oldSubNo; }
            set { oldSubNo = value; }
        }

        public clsLGFeeScheduleDTO()
        {

        }

        public clsLGFeeScheduleDTO(DataRow row)
        {

            seqLG = (Int64)row["SeqLG"];
            subID = (string)row["SubCode"];
            //  no = (byte)row["SubItem"];
            claimedDate = (DateTime)row["ClaimedDate"];
            try
            {
                actualClaimedDatel = (DateTime)row["ActualClaimedDate"];
            }
            catch (Exception ex)
            {
                actualClaimedDatel = DateTime.MinValue;
            }
            no = int.Parse(((byte)row["SubItem"]).ToString());
            try
            {
                receivedDate = (DateTime)row["ReceivedDate"];
            }
            catch
            {
                receivedDate = DateTime.MinValue;
            }
            //   principalCCY = ()row;

            chargeCCY = row["Currency"] == DBNull.Value ? "" : (string)row["Currency"];
            exchangeRate = row["ExchangeRate"] == DBNull.Value ? -1 : (decimal)row["ExchangeRate"];
            fee = row["Fee"] == DBNull.Value ? -1 : (decimal)row["Fee"];
            isExist = 1;
            isChange = 0;
            type = CommonValue.ActionType.None;
        }
        
        public clsLGFeeScheduleDTO(string strRefNo, string strSubID,int strNo,DateTime claim, DateTime actualClaim,DateTime received,string pricipalCcy,string chargeCcy,decimal exchange,decimal fe , CommonValue.ActionType ty,int oldSub)
        {
            refNo = strRefNo;
            subID = strSubID;

            claimedDate = claim;
            actualClaimedDatel = actualClaim;
            no = strNo;
            receivedDate = received;
            principalCCY = pricipalCcy;
            chargeCCY = chargeCcy;
            exchangeRate = exchange;
            fee = fe;
            type = ty;
            oldSubNo = oldSub;
        }

    }
}
