﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for Applicant
 * for LG module.
 */
using System.Collections;

namespace Phoenix.Lg.Dto
{
    public class clsLGPrintFormDTO
    {
        //+ Sequence LG
        private int m_SeqLG;        
        //+ LG No
        private string m_LGNo;
        //+ LG Status
        private string m_LGStatus;
        //+ LG Type
        private string m_LGType;
        //+ Guarantee Type
        private string m_GuaranteeType;
        // Array of LG No
        private ArrayList m_ArrLGNo;

        //+ Property of Sequence LG
        public int SeqLG
        {
            get { return m_SeqLG; }
            set { m_SeqLG = value; }
        }
        //+ Property of Guarantee Type
        public string GuaranteeType
        {
            get { return m_GuaranteeType; }
            set { m_GuaranteeType = value; }
        }
        //+ Property of LG Type
        public string LGType
        {
            get { return m_LGType; }
            set { m_LGType = value; }
        }
        //+ Property of LG Status
        public string LGStatus
        {
            get { return m_LGStatus; }
            set { m_LGStatus = value; }
        }
        //+ Property of LG No
        public string LGNo
        {
            get { return m_LGNo; }
            set { m_LGNo = value; }
        }
        //+ Property of Array Of LG No
        public ArrayList ArrLGNo
        {
            get { return m_ArrLGNo; }
            set { m_ArrLGNo = value; }
        }
        //+ Constructor
        public clsLGPrintFormDTO()
        {
            m_LGNo = string.Empty; ;
            m_LGStatus = string.Empty;
            m_LGType = string.Empty;
            m_GuaranteeType = string.Empty;
            m_ArrLGNo = new ArrayList();
        }
    }
}