﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-23 9:37:30 +0700 (Sun, 23 mar 2013) $
 * $Revision: 11465 $ 
 * ========================================================
 * This class is used to create object for report Parameters
 * for LG module.
 */
using System.Data;

namespace Phoenix.Lg.Dto
{
    public class ParameterDTO
    {
         private string value;

        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public ParameterDTO()
        {
            value = "";
            name = "";
        }
        /// <summary>
        /// Create PArameterDTO from datarow
        /// </summary>
        /// <param name="row"></param>
        public ParameterDTO(DataRow row)
        {
            value = ((string)row["Value"]).Trim();
            name = ((string)row["Name"]).Trim();
        }

        /// <summary>
        /// Create ParameterDTO from input name and value
        /// </summary>
        /// <param name="strName"></param>
        /// <param name="strValue"></param>
        public ParameterDTO(string strName, string strValue)
        {
            value = strValue;
            name = strName;
        }
    }
}
