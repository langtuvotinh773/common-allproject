﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for monitoring and alert
 * for LG module.
 */
using System;
using System.Data;

namespace Phoenix.Lg.Dto
{
    public class clsLGMonitoringAndAlertDTO
    {
        private int m_Count;

        public int Count
        {
            get { return m_Count; }
            set { m_Count = value; }
        }


        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsLGMonitoringAndAlertDTO()
        {

        }

        /// <summary>
        /// Get Monitoring anh Alert DTO 
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsLGMonitoringAndAlertDTO GetMornitoringAndAlert(DataRow row)
        {
            this.Count = row["CountClaimDate"].GetType() == typeof(DBNull) ? 0 : ((int)row["CountClaimDate"]);
            return this;
        }

    }
}