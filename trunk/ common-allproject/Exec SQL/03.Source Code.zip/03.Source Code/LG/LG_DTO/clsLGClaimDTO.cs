﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for Claimed Object
 * for LG module.
 */
using System;
using System.Data;

namespace Phoenix.Lg.Dto
{
    public class clsLGClaimDTO
    {
        private int seqLG;
        private string subCode;
        private DateTime? claimedDate;
        private DateTime? claimedPaymentDate;
        private string claimedCCY;
        private Decimal claimedAmount;
        private bool paid;
        private string remark;
        private int createdID;
        private DateTime updatedDate;
        private string lgNo;
        private string customerCode;
        private string customerName;
        private string beneficiaryName;
        private Decimal currentClaimedAmount;
        private int isExist;
        private int isChange;
        private int isDelete;

        public int SeqLG
        {
            get { return seqLG; }
            set { seqLG = value; }
        }
        public string SubCode
        {
            get { return subCode; }
            set { subCode = value; }
        }

        public DateTime? ClaimedDate
        {
            get { return claimedDate; }
            set { claimedDate = value; }
        }

        public DateTime? ClaimedPaymentDate
        {
            get { return claimedPaymentDate; }
            set { claimedPaymentDate = value; }
        }
        public string ClaimedCCY
        {
            get { return claimedCCY; }
            set { claimedCCY = value; }
        }

        public Decimal ClaimedAmount
        {
            get { return claimedAmount; }
            set { claimedAmount = value; }
        }

        public bool Paid
        {
            get { return paid; }
            set { paid = value; }
        }

        public string Remark
        {
            get { return remark; }
            set { remark = value; }
        }

        public int CreatedID
        {
            get { return createdID; }
            set { createdID = value; }
        }

        public DateTime UpdatedDate
        {
            get { return updatedDate; }
            set { updatedDate = value; }
        }
        public string LGNo
        {
            get { return lgNo; }
            set { lgNo = value; }
        }
        public string CustomerCode
        {
            get { return customerCode; }
            set { customerCode = value; }
        }
        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }
        public string BeneficiaryName
        {
            get { return beneficiaryName; }
            set { beneficiaryName = value; }
        }
        public Decimal CurrentLGAmount
        {
            get { return currentClaimedAmount; }
            set { currentClaimedAmount = value; }
        }
        public int IsExist
        {
            get { return isExist; }
            set { isExist = value; }
        }
        public int IsChange
        {
            get { return isChange; }
            set { isChange = value; }
        }

        public int IsDelete
        {
            get { return isDelete; }
            set { isDelete = value; }
        }

        public clsLGClaimDTO()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="claimDto"></param>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsLGClaimDTO(clsLGClaimDTO claimDto)
        {
            this.SeqLG = claimDto.SeqLG;
            this.SubCode = claimDto.SubCode;
            this.CurrentLGAmount = claimDto.CurrentLGAmount;
            this.ClaimedDate = claimDto.ClaimedDate;
            this.ClaimedPaymentDate = claimDto.ClaimedPaymentDate;
            this.ClaimedCCY = claimDto.ClaimedCCY;
            this.ClaimedAmount = claimDto.ClaimedAmount;
            this.Paid = claimDto.Paid;
            this.Remark = claimDto.Remark;
            this.IsExist = claimDto.IsExist;
            this.IsChange = claimDto.IsChange;
            this.IsDelete = claimDto.IsDelete;
        }

        /// <summary>
        /// Get Claim Dto
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsLGClaimDTO GetLGClaim(DataRow row)
        {
            this.SeqLG = row["SeqLG"].GetType() == typeof(DBNull) ? 0 : int.Parse(row["SeqLG"].ToString());
            this.SubCode = row["SubCode"].GetType() == typeof(DBNull) ? "" : ((string)row["SubCode"]).Trim();
            this.CurrentLGAmount = row["CurrentLGAmount"].GetType() == typeof(DBNull) ? 0 : Decimal.Parse((row["CurrentLGAmount"].ToString()));
            this.ClaimedDate = row["ClaimedDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)row["ClaimedDate"];
            this.ClaimedPaymentDate = row["ClaimedPaymentDate"].GetType() == typeof(DBNull) ? new Nullable<DateTime>() : (DateTime)row["ClaimedPaymentDate"];
            this.ClaimedCCY = row["ClaimedCCY"].GetType() == typeof(DBNull) ? "" : ((string)row["ClaimedCCY"]).Trim();
            this.ClaimedAmount = row["ClaimedAmount"].GetType() == typeof(DBNull) ? 0 : Decimal.Parse((row["ClaimedAmount"].ToString()));
            this.Paid = row["Paid"].GetType() == typeof(DBNull) ? false : (bool)row["Paid"];
            this.Remark = row["Remark"].GetType() == typeof(DBNull) ? "" : ((string)row["Remark"]).Trim();
            this.IsExist = row["IsExist"].GetType() == typeof(DBNull) ? 0 : (int)row["IsExist"];
            this.IsChange = 0;
            this.IsDelete = 0;
            return this;
        }
    }
}