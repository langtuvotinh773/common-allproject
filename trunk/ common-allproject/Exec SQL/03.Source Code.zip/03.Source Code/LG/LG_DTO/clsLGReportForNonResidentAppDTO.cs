﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: HTKhiem $
 * $Date: 2013-01-18 14:29:30 +0700 (Fri, 18 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define structure of DTO for List/Create/Update Report For Non Resident App
 * for LG module.
 */
using System;
using System.Collections.Generic;

namespace Phoenix.Lg.Dto
{
    /// <summary>
    /// Summary description for Create/Update Report For Non Resident App
    /// </summary>
    public class clsLGCUReportForNonResidentAppDTO
    {
        #region Declaration        
        //Header 
        //+ Month Year
        private DateTime monthYear = new DateTime();
        //+ Created By
        public string createdBy = String.Empty;
        //+ Created Date
        public DateTime createdDate = new DateTime();
        //List Of Repayment Information
        private List<ExchangeRateInformation> lstExchangeRateInformation = new List<ExchangeRateInformation>();
        #endregion

        #region Properties
        //+ Month Year
        public DateTime MonthYear
        {
            get 
            {
                return this.monthYear;
            }
            set
            {
                this.monthYear = value;
            }
        }

        //+ Created By
        public string CreatedBy
        {
            get
            {
                return this.createdBy;
            }
            set
            {
                this.createdBy = value;
            }
        }

        //+ Create Date
        public DateTime CreateDate
        {
            get
            {
                return this.createdDate;
            }
            set
            {
                this.createdDate = value;
            }
        }

        //List Of Repayment Information
        public List<ExchangeRateInformation> LstExchangeRateInformation
        {
            get
            {
                return this.lstExchangeRateInformation;
            }
            set
            {
                this.lstExchangeRateInformation = value;
            }
        }
        #endregion
    }

    //Exchange Rate Information
    public class ExchangeRateInformation
    {        
        //Declaration
        //+ CCY
        public string TransCurrency { get; set; }
        //+ Exchange Rate
        public decimal ExchangeRate { get; set; }
        //+ Lock Status
        public int LockStatus { get; set; }
        //+ Is Inserted
        public string OldExchangeRate { get; set; }
    }

    /// <summary>
    /// Summary description for List Report For Non Resident App
    /// </summary>
    public class clsLGListReportForNonResidentAppDTO
    {
        #region Declaration
        //Header 
        //+ Month Year From
        private DateTime monthYearFr = new DateTime();
        //+ Month Year To
        private DateTime monthYearTo = new DateTime();
        //List Of Non Resident App Information
        private List<NonResidentAppInformation> lstNonResidentAppInformation = new List<NonResidentAppInformation>();
        #endregion

        #region Properties
        //+ Month Year From
        public DateTime MonthYearFr
        {
            get
            {
                return this.monthYearFr;
            }
            set
            {
                this.monthYearFr = value;
            }
        }

        //+ Month Year To
        public DateTime MonthYearTo
        {
            get
            {
                return this.monthYearTo;
            }
            set
            {
                this.monthYearTo = value;
            }
        }

        //List Of Non Resident App Information
        public List<NonResidentAppInformation> LstNonResidentAppInformation
        {
            get
            {
                return this.lstNonResidentAppInformation;
            }
            set
            {
                this.lstNonResidentAppInformation = value;
            }
        }
        #endregion
    }

    //Non Resident App Information
    public class NonResidentAppInformation
    {
        //Declaration
        //+ monthYear
        public DateTime MonthYear { get; set; }
        //+ Lock Status
        public string LockStatus { get; set; }
        //List Of Exchange Rate For Reporting
        private List<ExchangeRateForReporting> lstExchangeRateForReporting = new List<ExchangeRateForReporting>();
        //List Of Exchange Rate For Reporting
        public List<ExchangeRateForReporting> LstExchangeRateForReporting
        {
            get
            {
                return this.lstExchangeRateForReporting;
            }
            set
            {
                this.lstExchangeRateForReporting = value;
            }
        }
    }

    //Exchange Rate For Reporting
    public class ExchangeRateForReporting
    {
        //Declaration
        //+ Reported Company Name
        public string CompanyName { get; set; }
        //+ Printed Date
        public DateTime PrintedDate { get; set; }
        //+ Beneficiary (VND) (Within quarter)
        public string Within_Sum_VND { get; set; }
        //+ Beneficiary (Foreign Exchange) (Winthin quarter)
        public string Within_Sum_USD { get; set; }
        //+ Beneficiary (VND) (End of quarter)
        public string End_Sum_VND { get; set; }
        //+ Beneficiary (Foreign Exchange) (End of quarter)
        public string End_Sum_USD { get; set; }
    }
}
