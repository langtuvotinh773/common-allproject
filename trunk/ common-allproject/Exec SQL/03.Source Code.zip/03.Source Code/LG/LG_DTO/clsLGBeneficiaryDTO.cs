﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for Beneficiary
 * for LG module.
 */
using System;
using System.Data;

namespace Phoenix.Lg.Dto
{
    public class clsLGBeneficiaryDTO
    {
        private int m_SeqBeneficiary;
        private string m_BeneficiaryCode;
        private string m_BeneficiaryName;
        private string m_BeneficiaryAddress;
        private string m_BeneficiaryNational;
        private string m_BeneficiaryTel;
        private string m_BeneficiaryFax;
        private int m_CreatedBy;
        private DateTime m_CreatedDate;
        private int m_NoChange;

        public int SeqBeneficiary
        {
            get { return m_SeqBeneficiary; }
            set { m_SeqBeneficiary = value; }
        }

        public string BeneficiaryCode
        {
            get { return m_BeneficiaryCode; }
            set { m_BeneficiaryCode = value; }
        }

        public string BeneficiaryName
        {
            get { return m_BeneficiaryName; }
            set { m_BeneficiaryName = value; }
        }

        public string BeneficiaryAddress
        {
            get { return m_BeneficiaryAddress; }
            set { m_BeneficiaryAddress = value; }
        }
       
        public string BeneficiaryNational
        {
            get { return m_BeneficiaryNational; }
            set { m_BeneficiaryNational = value; }
        }

        public string BeneficiaryTel
        {
            get { return m_BeneficiaryTel; }
            set { m_BeneficiaryTel = value; }
        }

        public string BeneficiaryFax
        {
            get { return m_BeneficiaryFax; }
            set { m_BeneficiaryFax = value; }
        }

        public int CreatedBy
        {
            get { return m_CreatedBy; }
            set { m_CreatedBy = value; }
        }

        public DateTime CreatedDate
        {
            get { return m_CreatedDate; }
            set { m_CreatedDate = value; }
        }

        public int NoChange
        {
            get { return m_NoChange; }
            set { m_NoChange = value; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// @cond
        /// Author: Phan Tran Hoang Yen
        /// @endcond
        public clsLGBeneficiaryDTO()
        {
            this.BeneficiaryCode = "";
            this.BeneficiaryName = "";
            this.BeneficiaryAddress = "";
            this.BeneficiaryNational = "";
            this.BeneficiaryTel = "";
            this.BeneficiaryFax = "";
        }

        /// <summary>
        /// Get Beneficiary for update
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond
        public clsLGBeneficiaryDTO GetBeneficiaryForUpdate(DataRow row)
        {
            this.SeqBeneficiary = row["SeqBeneficiary"].GetType() == typeof(DBNull) ? 0 : ((int)row["SeqBeneficiary"]);
            this.BeneficiaryCode = row["BeneficiaryCode"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryCode"]).Trim();
            this.BeneficiaryName = row["BeneficiaryName"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryName"]).Trim();
            this.BeneficiaryAddress = row["BeneficiaryAddress"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryAddress"]).Trim();
            this.BeneficiaryNational = row["BeneficiaryNational"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryNational"]).Trim();
            this.BeneficiaryTel = row["BeneficiaryTel"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryTel"]).Trim();
            this.BeneficiaryFax = row["BeneficiaryFax"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryFax"]).Trim();
            return this;
        }


        /// <summary>
        /// Get Beneficiary for search
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond 
        public clsLGBeneficiaryDTO GetBeneficiaryForSearch(DataRow row)
        {
            this.SeqBeneficiary = row["SeqBeneficiary"].GetType() == typeof(DBNull) ? 0 : ((int)row["SeqBeneficiary"]);
            this.BeneficiaryCode = row["BeneficiaryCode"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryCode"]).Trim();
            this.BeneficiaryName = row["BeneficiaryName"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryName"]).Trim();
            this.BeneficiaryAddress = row["BeneficiaryAddress"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryAddress"]).Trim();
            this.BeneficiaryNational = row["BeneficiaryNational"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryNational"]).Trim();
            this.BeneficiaryTel = row["BeneficiaryTel"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryTel"]).Trim();
            this.BeneficiaryFax = row["BeneficiaryFax"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryFax"]).Trim();
            this.NoChange = row["NoChange"].GetType() == typeof(DBNull) ? 0 : ((int)row["NoChange"]);
            return this;
        }
    }
}