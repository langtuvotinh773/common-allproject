﻿using System;
using System.Data;

namespace Phoenix.Lg.Dto
{
    public class clsLGMasterDTO
    {
        Int64 seqLG;

        public Int64 SeqLG
        {
            get { return seqLG; }
            set { seqLG = value; }
        }
        string lgCode;

        public string LgCode
        {
            get { return lgCode; }
            set { lgCode = value; }
        }
        byte lgType;

        public byte LgType
        {
            get { return lgType; }
            set { lgType = value; }
        }
        byte numEdit;

        public byte NumEdit
        {
            get { return numEdit; }
            set { numEdit = value; }
        }
        string glCode;

        public string GlCode
        {
            get { return glCode; }
            set { glCode = value; }
        }
        DateTime inputDate;

        public DateTime InputDate
        {
            get { return inputDate; }
            set { inputDate = value; }
        }
        DateTime valueDate;

        public DateTime ValueDate
        {
            get { return valueDate; }
            set { valueDate = value; }
        }
        DateTime expireDate;

        public DateTime ExpireDate
        {
            get { return expireDate; }
            set { expireDate = value; }
        }
        string customerCode;

        public string CustomerCode
        {
            get { return customerCode; }
            set { customerCode = value; }
        }
        int seqBenificiary;

        public int SeqBenificiary
        {
            get { return seqBenificiary; }
            set { seqBenificiary = value; }
        }
        int seqApplicant;

        public int SeqApplicant
        {
            get { return seqApplicant; }
            set { seqApplicant = value; }
        }
        string contractInfo;

        public string ContractInfo
        {
            get { return contractInfo; }
            set { contractInfo = value; }
        }
        string representation1;

        public string Representation1
        {
            get { return representation1; }
            set { representation1 = value; }
        }
        string representation2;

        public string Representation2
        {
            get { return representation2; }
            set { representation2 = value; }
        }
        string representation3;

        public string Representation3
        {
            get { return representation3; }
            set { representation3 = value; }
        }
        string guaranteeType;

        public string GuaranteeType
        {
            get { return guaranteeType; }
            set { guaranteeType = value; }
        }
        string calculateType;

        public string CalculateType
        {
            get { return calculateType; }
            set { calculateType = value; }
        }
        decimal lgRate;

        public decimal LgRate
        {
            get { return lgRate; }
            set { lgRate = value; }
        }
        bool lgSecurity;

        public bool LgSecurity
        {
            get { return lgSecurity; }
            set { lgSecurity = value; }
        }
        bool bookPurpose;

        public bool BookPurpose
        {
            get { return bookPurpose; }
            set { bookPurpose = value; }
        }
        bool minRateStandard;

        public bool MinRateStandard
        {
            get { return minRateStandard; }
            set { minRateStandard = value; }
        }
        decimal minRateAmount;

        public decimal MinRateAmount
        {
            get { return minRateAmount; }
            set { minRateAmount = value; }
        }
        string minRateCurrency;

        public string MinRateCurrency
        {
            get { return minRateCurrency; }
            set { minRateCurrency = value; }
        }
        string remark;

        public string Remark
        {
            get { return remark; }
            set { remark = value; }
        }
        byte lgStatus;

        public byte LgStatus
        {
            get { return lgStatus; }
            set { lgStatus = value; }
        }
        byte lgBeforeStatus;

        public byte LgBeforeStatus
        {
            get { return lgBeforeStatus; }
            set { lgBeforeStatus = value; }
        }
        byte lgAction;

        public byte LgAction
        {
            get { return lgAction; }
            set { lgAction = value; }
        }
        byte lgReturn;

        public byte LGReturn
        {
            get { return lgReturn; }
            set { lgReturn = value; }
        }
        string conditionTermination;


        public string ConditionTermination
        {
            get { return conditionTermination; }
            set { conditionTermination = value; }
        }
        decimal overdueFeeTermination;

        public decimal OverdueFeeTermination
        {
            get { return overdueFeeTermination; }
            set { overdueFeeTermination = value; }
        }
        string currencyTermination;

        public string CurrencyTermination
        {
            get { return currencyTermination; }
            set { currencyTermination = value; }
        }
        byte numReportSBV;

        public byte NumReportSBV
        {
            get { return numReportSBV; }
            set { numReportSBV = value; }
        }
        byte flagControlingBook;

        public byte FlagControlingBook
        {
            get { return flagControlingBook; }
            set { flagControlingBook = value; }
        }
        short createdID;

        public short CreatedID
        {
            get { return createdID; }
            set { createdID = value; }
        }

        bool allowed;

        public bool Allowed
        {
            get { return allowed; }
            set { allowed = value; }
        }

        private DateTime updateDate;

        public DateTime UpdateDate
        {
            get { return updateDate; }
            set { updateDate = value; }
        }

        public clsLGMasterDTO(DataRow row)
        {
             seqLG = (Int64)row["SeqLG"];
             lgCode = (string)row["LGCode"];
             lgType = (byte)row["LGType"];
             numEdit = (byte)row["NumEdit"];
             glCode = (string)row["GLCode"];
             inputDate = (DateTime)row["InputDate"];
             valueDate = (DateTime)row["ValueDate"];

             expireDate = (DateTime)row["ExpireDate"];
             updateDate = row["UpdatedDate"] == DBNull.Value ? DateTime.MinValue : (DateTime)row["UpdatedDate"];

             customerCode = (string)row["CustomerCode"];
             seqBenificiary = row["SeqBeneficiary"] == DBNull.Value ? -1 : (int)row["SeqBeneficiary"];
             seqApplicant = row["SeqApplicant"] == DBNull.Value ? -1 : (int)row["SeqApplicant"];
             contractInfo = (string)row["ContractInformation"];
             representation1 = (string)row["Representation1"];
             representation2 = (string)row["Representation2"];
             representation3 = (string)row["Representation3"];
             guaranteeType = (string)row["GuaranteeType"];
             calculateType = (string)row["CalculateType"];
             lgRate = (decimal)row["LGRate"];
             lgSecurity = (bool)row["LGSecurity"];
             bookPurpose = (bool)row["BookPurpose"];
             minRateStandard = (bool)row["MinRateStandard"];
             minRateAmount = (decimal)row["MinRateAmount"];
             minRateCurrency = (string)row["MinRateCurrency"];
             remark = (string)row["Remark"];
             lgStatus = (byte)row["LGStatus"];
             lgBeforeStatus = row["LGBeforeStatus"] == DBNull.Value ? (byte)0 :(byte)row["LGBeforeStatus"];
             lgAction = (byte)row["LGAction"];
             lgReturn = (byte)row["LGReturn"];
             conditionTermination = row["ConditionTernination"] == DBNull.Value ? "" :(string)row["ConditionTernination"];
             overdueFeeTermination = row["OverdureFeeTermination"] == DBNull.Value ? 0 : (decimal)row["OverdureFeeTermination"];
             currencyTermination = row["CurrencyTermination"] == DBNull.Value ? "" : (string)row["CurrencyTermination"];
             numReportSBV = row["NumReportSBV"] == DBNull.Value ? (byte)0 : (byte)row["NumReportSBV"];
            // flagControlingBook = row["FlagControlBook"] == DBNull.Value ? (byte)0 : (byte)row["FlagControlBook"];
             createdID = (short)row["CreatedID"];

             allowed = row["LGAllowed"] == DBNull.Value ? false : (bool)row["LGAllowed"];
        }
        
    }
}
