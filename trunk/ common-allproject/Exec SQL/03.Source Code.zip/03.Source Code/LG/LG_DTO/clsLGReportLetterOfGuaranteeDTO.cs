﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Nguyen Danh Tho $
 * $Date: 2013-03-29 $
 * $Revision: $ 
 * ========================================================
 * This class is used to define structure of DTO for report LETTER OF GUARANTEE - NEW ENTRY and LETTER OF GUARANTEE-TERMINATION
 * for LG module.
 */
using System;
using System.Data;
using Phoenix.Lg.Com;

namespace Phoenix.Lg.Dto
{
    public class clsLGReportLetterOfGuaranteeDTO
    {
        private string lGNo;
        public string LGNo
        {
            get { return lGNo; }
            set { lGNo = value; }
        }

        private string inputDate;
        public string InputDate
        {
            get { return inputDate; }
            set { inputDate = value; }
        }

        private string valueDate;
        public string ValueDate
        {
            get { return valueDate; }
            set { valueDate = value; }
        }

        private string kind;
        public string Kind
        {
            get { return kind; }
            set { kind = value; }
        }

        private string customerCode;
        public string CustomerCode
        {
            get { return customerCode; }
            set { customerCode = value; }
        }

        private string customerName;
        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        private string currency;
        public string Currency
        {
            get { return currency; }
            set { currency = value; }
        }

        private string gLCode;
        public string GLCode
        {
            get { return gLCode; }
            set { gLCode = value; }
        }

        private decimal guaranteeAmount;
        public decimal GuaranteeAmount
        {
            get { return guaranteeAmount; }
            set { guaranteeAmount = value; }
        }

        private string expireDate;
        public string ExpireDate
        {
            get { return expireDate; }
            set { expireDate = value; }
        }

        private string guaranteeType;
        public string GuaranteeType
        {
            get { return guaranteeType; }
            set { guaranteeType = value; }
        }

        private string beneficiaryName;
        public string BeneficiaryName
        {
            get { return beneficiaryName; }
            set { beneficiaryName = value; }
        }

        private string acc;
        public string Acc
        {
            get { return acc; }
            set { acc = value; }
        }

        private decimal rate;
        public decimal Rate
        {
            get { return rate; }
            set { rate = value; }
        }

        private decimal min;
        public decimal Min
        {
            get { return min; }
            set { min = value; }
        }

        private string m_MinCurrency;

        public string MinCurrency
        {
            get { return m_MinCurrency; }
            set { m_MinCurrency = value; }
        }

        private decimal fee;
        public decimal Fee
        {
            get { return fee; }
            set { fee = value; }
        }

        private int row;
        public int Row
        {
            get { return row; }
            set { row = value; }
        }

        private string m_FeeCurrency;

        public string FeeCurrency
        {
            get { return m_FeeCurrency; }
            set { m_FeeCurrency = value; }
        }
        private string updateDate;

        public string UpdateDate
        {
            get { return updateDate; }
            set { updateDate = value; }
        }

        public clsLGReportLetterOfGuaranteeDTO()
        {
            this.row = 0;
            lGNo = string.Empty;
            inputDate = string.Empty;
            valueDate = string.Empty;
            kind = string.Empty;
            customerCode = string.Empty;
            customerName = string.Empty;
            currency = string.Empty;
            gLCode = string.Empty;
            guaranteeAmount = 0;
            expireDate = string.Empty;
            guaranteeType = string.Empty;
            beneficiaryName = string.Empty;
            acc = string.Empty;
            rate = 0;
            min = 0;
            fee = 0;
            updateDate = string.Empty;
        }

        /// <summary>
        /// Get report letter of guarantee
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public clsLGReportLetterOfGuaranteeDTO GetLGReportLetterOfGuarantee(DataRow row)
        {
            this.row = 1;
            this.InputDate = row["InputDate"].GetType() == typeof(DBNull) ? "" : String.Format(clsLGConstant.LG_FORMAT_YEAR_MONTH_DAY, row["InputDate"]).Trim();
            this.ValueDate = row["ValueDate"].GetType() == typeof(DBNull) ? "" : String.Format(clsLGConstant.LG_FORMAT_YEAR_MONTH_DAY, row["ValueDate"]).Trim();
            this.Kind = row["Kind"].GetType() == typeof(DBNull) ? "" : Convert.ToString(row["Kind"]).Trim();
            this.CustomerCode = row["CustomerCode"].GetType() == typeof(DBNull) ? "" : ((string)row["CustomerCode"]).Trim();
            this.CustomerName = row["CustomerName"].GetType() == typeof(DBNull) ? "" : ((string)row["CustomerName"]).Trim();
            this.Currency = row["Currency"].GetType() == typeof(DBNull) ? "" : ((string)row["Currency"]).Trim();
            this.GLCode = row["GLCode"].GetType() == typeof(DBNull) ? "" : ((string)row["GLCode"]).Trim();
            this.GuaranteeAmount = row["GuaranteeAmount"].GetType() == typeof(DBNull) ? 0 : Convert.ToDecimal(row["GuaranteeAmount"]);
            this.ExpireDate = row["ExpireDate"].GetType() == typeof(DBNull) ? "" : String.Format(clsLGConstant.LG_FORMAT_YEAR_MONTH_DAY, row["ExpireDate"]).Trim();
            this.GuaranteeType = row["GuaranteeType"].GetType() == typeof(DBNull) ? "" : ((string)row["GuaranteeType"]).Trim();
            this.BeneficiaryName = row["BeneficiaryName"].GetType() == typeof(DBNull) ? "" : ((string)row["BeneficiaryName"]).Trim();
            this.Acc = row["Acc"].GetType() == typeof(DBNull) ? "" : ((string)row["Acc"]).Trim();
            this.Rate = row["Rate"].GetType() == typeof(DBNull) ? 0 : Convert.ToDecimal(row["Rate"]);
            this.Min = row["Min"].GetType() == typeof(DBNull) ? 0 : Convert.ToDecimal(row["Min"]);
            this.MinCurrency = row["MinCurrency"].GetType() == typeof(DBNull) ? "" : ((string)row["MinCurrency"]).Trim();
            this.Fee = row["Fee"].GetType() == typeof(DBNull) ? 0 : Convert.ToDecimal(row["Fee"]);
            this.FeeCurrency = row["FeeCurrency"].GetType() == typeof(DBNull) ? "" : ((string)row["FeeCurrency"]).Trim();
            this.updateDate = row["UpdatedDate"].GetType() == typeof(DBNull) ? "" : String.Format(clsLGConstant.LG_FORMAT_YEAR_MONTH_DAY, row["UpdatedDate"]).Trim();
            return this;
        }

    }
}
