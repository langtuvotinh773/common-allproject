﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-12 20:37:30 +0700 (Tue, 12 mar 2013) $
 * $Revision: 3978 $ 
 * ========================================================
 * This class is used to create object for Applicant
 * for LG module.
 */
using System;
using System.Data;

namespace Phoenix.Lg.Dto
{
	public class clsLGApplicantDTO
	{
        private int m_SeqApplicant;
		private string m_ApplicantCode;
        private string m_ApplicantName;
        private string m_ApplicantAddress;
        private string m_ApplicantNational;
        private string m_ApplicantTel;
        private string m_ApplicantFax;
        private int m_CreatedBy;
        private DateTime m_CreatedDate;
        private int m_NoChange;

        public int SeqApplicant
        {
            get { return m_SeqApplicant; }
            set { m_SeqApplicant = value; }
        }

		public string ApplicantCode
		{
            get { return m_ApplicantCode; }
            set { m_ApplicantCode = value; }
		}
		
		public string ApplicantName
		{
			get { return m_ApplicantName; }
			set { m_ApplicantName = value; }
		}
		
		public string ApplicantAddress
		{
			get { return m_ApplicantAddress; }
			set { m_ApplicantAddress = value; }
		}
		
		public string ApplicantNational
		{
			get { return m_ApplicantNational; }
			set { m_ApplicantNational = value; }
		}
		
		public string ApplicantTel
		{
			get { return m_ApplicantTel; }
			set { m_ApplicantTel = value; }
		}
		
		public string ApplicantFax
		{
			get { return m_ApplicantFax; }
			set { m_ApplicantFax = value; }
		}

        public int CreatedBy
        {
            get { return m_CreatedBy; }
            set { m_CreatedBy = value; }
        }

        public DateTime CreatedDate
        {
            get { return m_CreatedDate; }
            set { m_CreatedDate = value; }
        }

        public int NoChange
        {
            get { return m_NoChange; }
            set { m_NoChange = value; }
        }

		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsLGApplicantDTO()
		{
			this.ApplicantCode = "";
			this.ApplicantName= "";
			this.ApplicantAddress= "";
			this.ApplicantNational= "";
			this.ApplicantTel= "";
			this.ApplicantFax= "";
		}
		/// <summary>
		/// Constructor
		/// </summary>
		/// @cond
		/// Author: Phan Tran Hoang Yen
		/// @endcond
		public clsLGApplicantDTO(string _applicantCode, string _applicantName, string _address, string _national, string _telephone, string _fax)
		{
			this.ApplicantCode = _applicantCode.Trim();
			this.ApplicantName = _applicantName.Trim();
			this.ApplicantAddress = _address.Trim();
			this.ApplicantNational = _national.Trim();
			this.ApplicantTel = _telephone.Trim();
			this.ApplicantFax = _fax.Trim();
		}

        /// <summary>
        /// Get Applicant for update
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond 
        public clsLGApplicantDTO GetApplicantForUpdate(DataRow row)
        {
            this.SeqApplicant = row["SeqApplicant"].GetType() == typeof(DBNull) ? 0 : ((int)row["SeqApplicant"]);
            this.ApplicantCode = row["ApplicantCode"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantCode"]).Trim();
            this.ApplicantName = row["ApplicantName"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantName"]).Trim();
            this.ApplicantAddress = row["ApplicantAddress"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantAddress"]).Trim();
            this.ApplicantNational = row["ApplicantNational"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantNational"]).Trim();
            this.ApplicantTel = row["ApplicantTel"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantTel"]).Trim();
            this.ApplicantFax = row["ApplicantFax"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantFax"]).Trim();
            return this;
        }


        /// <summary>
        /// Get Applicant for search
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// @cond
        /// Author: Phuong Lap Co
        /// @endcond 
        public clsLGApplicantDTO GetApplicantForSearch(DataRow row)
        {
            this.SeqApplicant = row["SeqApplicant"].GetType() == typeof(DBNull) ? 0 : ((int)row["SeqApplicant"]);
            this.ApplicantCode = row["ApplicantCode"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantCode"]).Trim();
            this.ApplicantName = row["ApplicantName"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantName"]).Trim();
            this.ApplicantAddress = row["ApplicantAddress"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantAddress"]).Trim();
            this.ApplicantNational = row["ApplicantNational"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantNational"]).Trim();
            this.ApplicantTel = row["ApplicantTel"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantTel"]).Trim();
            this.ApplicantFax = row["ApplicantFax"].GetType() == typeof(DBNull) ? "" : ((string)row["ApplicantFax"]).Trim();
            this.NoChange = row["NoChange"].GetType() == typeof(DBNull) ? 0 : ((int)row["NoChange"]);
            return this;
        }
	}
}