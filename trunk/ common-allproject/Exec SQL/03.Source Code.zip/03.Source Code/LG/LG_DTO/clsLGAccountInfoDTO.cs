﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: Phong Nguyen $
 * $Date: 2013-03-23 9:37:30 +0700 (Sun, 23 mar 2013) $
 * $Revision: 11465 $ 
 * ========================================================
 * This class is used to create Account infomaiton
 * in LG module.
 */
using System.Data;

namespace Phoenix.Lg.Dto
{
    public class clsLGAccountInfoDTO
    {
        private string accountNo;

        public string AccountNo
        {
            get { return accountNo; }
            set { accountNo = value; }
        }
        private string ccy;

        public string Ccy
        {
            get { return ccy; }
            set { ccy = value; }
        }

        public clsLGAccountInfoDTO()
        {
            ccy = "";
            accountNo = "";
        }
        public clsLGAccountInfoDTO(string strAccount, string strCcy)
        {
            ccy = strCcy;
            accountNo = strAccount;
        }
        public clsLGAccountInfoDTO(DataRow row)
        {
            ccy = ((string)row["Ccy"]).Trim();
            accountNo = ((string)row["Ac No"]).Trim();
            accountNo = ccy + "-" + accountNo;
        }
    }
}
