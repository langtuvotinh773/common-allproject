﻿/*
 * Copyright (c) 2013 BTMU
 * $Author: pthyen $
 * $Date: 2013-03-13 14:29:30 +0700 (Wed, 13 Jan 2013) $
 * $Revision: 4802 $ 
 * ========================================================
 * This class is used to define LG DTO object
 * for LG module.
 */

namespace Phoenix.Lg.Dto
{
	/// <summary>
	/// Object class to display item on combobox
	/// </summary>
	/// @cond
	/// Author: Phan Tran Hoang Yen
	/// @endcond
	public class clsComboboxObjectDTO
	{
		private string m_Display;
		private string m_Value;
		public clsComboboxObjectDTO(string Value, string Display)
		{
			m_Display = Display;
			m_Value = Value;
		}
		public string Display
		{
			get { return m_Display; }
		}
		public string Value
		{
			get { return m_Value; }
		}
	}
}