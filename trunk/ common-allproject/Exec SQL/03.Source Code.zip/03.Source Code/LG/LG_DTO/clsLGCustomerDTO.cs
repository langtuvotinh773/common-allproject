﻿using System.Data;

namespace Phoenix.Lg.Dto
{
   public class clsLGCustomerDTO
    {
        private string code;

        public string CustomerCode
        {
            get { return code; }
            set { code = value; }
        }
        private string name;

        public string CustomerName
        {
            get { return name; }
            set { name = value; }
        }
        public clsLGCustomerDTO(DataRow row)
        {
            code = (string)row["CustomerCode"];
            name = (string)row["Name"];
        }
        public clsLGCustomerDTO()
        {
            code = "";
            name ="";
        }
    }
}
